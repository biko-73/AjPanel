import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile
except: iMove = iCopyfile = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VV191S   = "v7.3.0"
VVpfwY    = "11-10-2022"
EASY_MODE    = 0
VVli8I   = 0
VVDb0h   = 0
VVKPve  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVGc43  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVhL6f    = "/media/usb/"
VVZyaX    = "/usr/share/enigma2/picon/"
VVh8e9 = "/etc/enigma2/blacklist"
VVslLY   = "/etc/enigma2/"
VVf5ke  = "ajpanel_update_url"
VVmVo9   = "AJPan"
VVk7lM  = "AUTO FIND"
VVqdlh  = "Custom"
VVKliC    = ""
VVw7NR = "Regular"
VVMbWE = "Fixed"
VVL9lY  = "AJP_Main"
VVrGjB = "AJP_Terminal"
VVGWDl = "AJP_System"
VVOCsc  = VVw7NR
VVStMY      = "-" * 80
VVbzyo    = ("-" * 100, )
VVLQSn    = ""
VVp7GH   = " && echo 'Successful' || echo 'Failed!'"
VVS8qG    = []
VVQZPP  = "Cannot continue (No Enough Memory) !"
VVpo5P  = False
VVdBoH  = False
VVhP34 = False
VVXQaf     = 0
VVHcRy    = 1
VVXRSp    = 2
VVkJ1U   = 3
VVW7yA    = 4
VV0RYQ    = 5
VVQhck = 6
VVn6dg = 7
VVEXzS  = 8
VVL14D   = 9
VV3Iw8  = 10
VV4xIc  = 11
VV752q = 12
VVFcCy    = 13
VVarsQ   = 14
VVZeE3   = 15
VVXIC2    = 16
VVdmEc    = 17
VV6Nc5  = 18
VVYzBB    = 19
VVZIpo   = 0
VVM50Z   = 1
VVGmpm   = 2
def FFCwuA():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVOCsc
  if VVL9lY in lst and CFG.fontPathMain.getValue(): VVOCsc = VVL9lY
  else               : VVOCsc = VVw7NR
  return lst
 else:
  return [VVw7NR]
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[ ("v", "Virtual Keyboard"), ("s", "System Default") ])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[ ("d", "Directory Up"), ("e", "Exit File Manage") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices=[ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVk7lM, visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.PIconsPath     = ConfigDirectory(default=VVZyaX, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVhL6f, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
tmp = [("srt", "FROM SRT FILE"), ("#00FFFF", "Aqua"), ("#000000", "Black"), ("#0000FF", "Blue"), ("#FF00FF", "Fuchsia"), ("#808080", "Gray"), ("#008000", "Green"), ("#00FF00", "Lime"), ("#800000", "Maroon"), ("#000080", "Navy"), ("#808000", "Olive"), ("#800080", "Purple"), ("#FF0000", "Red"), ("#C0C0C0", "Silver"), ("#008080", "Teal"), ("#FFFFFF", "White"), ("#FFFF00", "Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVOCsc, choices=[(x,  x) for x in FFCwuA()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[ ("0", "Left"), ("1", "Center"), ("2", "Right") ])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FFiU0B():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVRC16  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VV7ial = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVRC16  : return 0
  elif VV7ial : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
COLOR_SCHEME_NUM = FFiU0B()
VVNUkq = VVcK7G = VV0rNQ = VVmIAH = VVHKA4 = VVhTQL = VVlWiV = VV7q9v = VV80BT = VV4YPU = VVSqFX = VVXaO9 = VVHJRy = VVtjbM = VVuRbD = VV1R4z = ""
def FFobN3()  : FFE0bh(FFlTdL())
def FFQ5k1()  : FFE0bh(FF7YRa())
def FFj9NE(tDict): FFE0bh(iDumps(tDict, indent=4, sort_keys=True))
def FF9zWw(*args): FFHMmc(True, True, *args)
def FFE0bh(*args) : FFHMmc(True , False , *args)
def FFpJq1(*args): FFHMmc(False, False, *args)
def FFHMmc(addSep=True, isArray=True, *args):
 if VVli8I:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(key.ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFtVWk(*args):
 if VVli8I:
  path = "/tmp/ajpanel_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FFpJq1("Added to : %s" % path)
def FF7DIp(txt, isAppend=True, ignoreErr=False):
 if VVli8I:
  tm = FFlazR()
  err = ""
  if not ignoreErr:
   err = FF7YRa()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFE0bh(err)
  FFE0bh("Output Log File : %s" % fileName)
def FF7YRa():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFlazR()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFlTdL():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVxhxd = 0
def FFRNvM():
 global VVxhxd
 VVxhxd = iTime()
def FF7ATV(txt=""):
 FFE0bh(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VVxhxd)).rstrip("0"), txt))
VVS8qG = []
def FFyfbj(win):
 global VVS8qG
 if not win in VVS8qG:
  VVS8qG.append(win)
def FFtWwG(*args):
 global VVS8qG
 for win in VVS8qG:
  try:
   win.close()
  except:
   pass
 VVS8qG = []
def FFirCE():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVFJgt = FFirCE()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FF49qE()    : return PluginDescriptor(fnc=FFtKvH, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FFGbdt()      : return getDescriptor(FFuRdN , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFplHt()     : return getDescriptor(FFkZRE  , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FF4bsp()  : return getDescriptor(FFyfyM, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FF1Qun() : return getDescriptor(FFnevc , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FFrg79()  : return getDescriptor(FFAmQ7 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFdpKi()  : return getDescriptor(FFT8w6  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFOnr3()    : return getDescriptor(FFGx0d, [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFplHt() , FFGbdt() , FF49qE() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FF4bsp())
  result.append(FF1Qun())
  result.append(FFrg79())
  result.append(FFdpKi())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFOnr3())
 return result
def FFtKvH(reason, **kwargs):
 if reason == 0:
  FFOjaF()
  if "session" in kwargs:
   session = kwargs["session"]
   FF5i4A(session)
   CCrTb2(session)
def FFuRdN(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFkZRE, PLUGIN_NAME, 45)]
 else:
  return []
def FFkZRE(session, **kwargs):
 session.open(Main_Menu)
def FFyfyM(session, **kwargs):
 session.open(CCeH84)
def FFnevc(session, **kwargs):
 session.open(CCaayN)
def FFAmQ7(session, **kwargs):
 CCcojD.VVEI1u(session, isFromExternal=True)
def FFT8w6(session, **kwargs):
 FF3UUy(session, reopen=True)
def FFGx0d(session, **kwargs):
 session.open(CCnfxp, fncMode=CCnfxp.VVUzCH)
def FF9YTV():
 FFefWI(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FF4bsp(), FF1Qun(), FFrg79(), FFdpKi() ])
 FFefWI(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFOnr3() ])
def FFefWI(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VV6pD9 = None
def FFOjaF():
 try:
  global VV6pD9
  if VV6pD9 is None:
   VV6pD9    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFbhd8
  ChannelContextMenu.FFFYL0 = FFFYL0
 except:
  pass
def FFbhd8(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VV6pD9(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , BF(SELF.FFFYL0, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , BF(SELF.FFFYL0, title1, csel, isFind=True))))
def FFFYL0(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFHIlX(refCode)
 except:
  pass
 self.session.open(BF(CCY9K8, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FF5i4A(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = BF(FFn12a, session, "lok")
 hk.actions['longCancel'] = BF(FFn12a, session, "lesc")
 hk.actions['longRed']  = BF(FFn12a, session, "lred")
def FFn12a(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CCTDYj.VVgpqK:
    CCTDYj.VVgpqK.close()
   if not CCcojD.VVkJzO:
    CCcojD.VVEI1u(session, isFromExternal=True)
  except:
   pass
def FFGxwH(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FFqVmU(SELF, title="", addLabel=False, addScrollLabel=False, VVwSHr=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFNk49()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CChIHC(SELF)
 if VVwSHr:
  SELF["myMenu"] = MenuList(VVwSHr)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVmBrJ        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFnqTm(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFd1Hk, SELF, "0") ,
  "1" : BF(FFd1Hk, SELF, "1") ,
  "2" : BF(FFd1Hk, SELF, "2") ,
  "3" : BF(FFd1Hk, SELF, "3") ,
  "4" : BF(FFd1Hk, SELF, "4") ,
  "5" : BF(FFd1Hk, SELF, "5") ,
  "6" : BF(FFd1Hk, SELF, "6") ,
  "7" : BF(FFd1Hk, SELF, "7") ,
  "8" : BF(FFd1Hk, SELF, "8") ,
  "9" : BF(FFd1Hk, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFwtxD, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFd1Hk(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VV1R4z:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VV1R4z + SELF.keyPressed + VVcK7G)
    txt = VVcK7G + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFMYB5(SELF, txt)
def FFwtxD(SELF, tableObj, colNum):
 FFMYB5(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VVm16r(i)
     break
 except:
  pass
def FFulUr(SELF, setMenuAction=True):
 if setMenuAction:
  global VVLQSn
  VVLQSn = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFNk49():
 return ("  %s" % VVLQSn)
def FFTGpi(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFGlcE(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFUCM9(color):
 return parseColor(color).argb()
def FFilsZ(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFAMY6(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFSeS9(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFw6UZ(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VV1R4z)
 else:
  return ""
def FFN8GC(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVStMY, word, VVStMY, VV1R4z)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVStMY, word, VVStMY)
def FFNkac(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VV1R4z
def FFoIr5(color):
 if color: return "echo -e '%s' %s;" % (VVStMY, FFw6UZ(VVStMY, VVSqFX))
 else : return "echo -e '%s';" % VVStMY
def FFYH2Y(title, color):
 title = "%s\n%s\n%s\n" % (VVStMY, title, VVStMY)
 return FFNkac(title, color)
def FFpkQc(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFJGGi(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFuqQK(callBackFunction):
 tCons = CCPx0q()
 tCons.ePopen("echo", BF(FFAtAq, callBackFunction))
def FFAtAq(callBackFunction, result, retval):
 callBackFunction()
def FFqXEj(SELF, fnc, title="Processing ...", clearMsg=True):
 FFMYB5(SELF, title)
 tCons = CCPx0q()
 tCons.ePopen("echo", BF(FFE88Z, SELF, fnc, clearMsg))
def FFE88Z(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFMYB5(SELF)
def FFnUjX(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVQZPP
  else       : return ""
def FFIsyt(cmd):
 txt = FFnUjX(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFnz9X(cmd):
 lines = FFIsyt(cmd)
 if lines: return lines[0]
 else : return ""
def FFKUi6(SELF, cmd):
 lines = FFIsyt(cmd)
 VVmJ2p = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVmJ2p.append((key, val))
  elif line:
   VVmJ2p.append((line, ""))
 if VVmJ2p:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFyLgY(SELF, None, header=header, VVd40u=VVmJ2p, VVLpvM=widths, VV2ql8=28)
 else:
  FFGC8R(SELF, cmd)
def FFGC8R(    SELF, cmd, **kwargs): SELF.session.open(CClcu8, VVwcGi=cmd, VV4lzZ=True, VVDaM8=VVM50Z, **kwargs)
def FFr3ln(  SELF, cmd, **kwargs): SELF.session.open(CClcu8, VVwcGi=cmd, **kwargs)
def FF7AMX(   SELF, cmd, **kwargs): SELF.session.open(CClcu8, VVwcGi=cmd, VVIDCC=True, VVKWR3=True, VVDaM8=VVM50Z, **kwargs)
def FFSiFd(  SELF, cmd, **kwargs): SELF.session.open(CClcu8, VVwcGi=cmd, VVIDCC=True, VVKWR3=True, VVDaM8=VVGmpm, **kwargs)
def FFCHwU(  SELF, cmd, **kwargs): SELF.session.open(CClcu8, VVwcGi=cmd, VV8ntC=True , **kwargs)
def FFOXCA( SELF, cmd, **kwargs): SELF.session.open(CClcu8, VVwcGi=cmd, VViYG9=True   , **kwargs)
def FFi3Gr( SELF, cmd, **kwargs): SELF.session.open(CClcu8, VVwcGi=cmd, VV5YO7=True  , **kwargs)
def FFlWZ0(cmd):
 return cmd + " > /dev/null 2>&1"
def FFpeT0(cmd):
 return cmd + " 2> /dev/null"
def FFuSel():
 return " > /dev/null 2>&1"
def FF0CKG(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFaJMY(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFGwKB():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFnz9X(cmd)
VVNE2g     = 0
VVadVa      = 1
VVT5Tj   = 2
VVfQeQ      = 3
VVcV6O      = 4
VV9nnc     = 5
VVJBI8     = 6
VVUj18 = 7
VV2M4Y = 8
VVFbVd = 9
VVhG5k  = 10
VVhiem     = 11
VVbRax  = 12
VVFY8T  = 13
def FFeJzm(parmNum, grepTxt):
 if   parmNum == VVNE2g  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVadVa   : param = ["list"   , "apt list" ]
 elif parmNum == VVT5Tj: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFGwKB()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFtNvi(parmNum, package):
 if   parmNum == VVfQeQ      : param = ["info"      , "apt show"         ]
 elif parmNum == VVcV6O      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VV9nnc     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVJBI8     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVUj18 : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VV2M4Y : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VVFbVd : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVhG5k  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVhiem     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVbRax  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVFY8T  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFGwKB()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFlS4l():
 result = FFnz9X("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFtNvi(VVJBI8 , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFlWZ0("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFlWZ0("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFw6UZ(failed1, VVSqFX))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFw6UZ(failed2, VVSqFX))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFw6UZ(failed3, VV0rNQ))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFNMcU(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFtNvi(VVJBI8 , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFlWZ0("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFw6UZ(failed1, VVSqFX))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFw6UZ(failed2, VV0rNQ))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FF9q7B(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFlWZ0('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFlWZ0("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFa594(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCor0x.VV6pNt()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FF7up6(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFa594(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFsBYR(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFtd04(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFa594(path, maxSize=maxSize, encLst=encLst)
  if lines: FFheEQ(SELF, lines, title=title, VVDaM8=VVM50Z)
  else : FF8QNX(SELF, path, title=title)
 else:
  FFXl6w(SELF, path, title)
def FFK3qq(SELF, path, title):
 if fileExists(path):
  txt = FFa594(path)
  txt = txt.replace("#W#", VV1R4z)
  txt = txt.replace("#Y#", VVXaO9)
  txt = txt.replace("#G#", VVcK7G)
  txt = txt.replace("#C#", VVHJRy)
  txt = txt.replace("#P#", VVHKA4)
  FFheEQ(SELF, txt, title=title)
 else:
  FFXl6w(SELF, path, title)
def FFoQ29(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFFUBh(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFThW1(parent)
 else    : return FFTAAa(parent)
def FFck77(path):
 return os.path.basename(os.path.normpath(path))
def FFtd04(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFblrr(path):
 try:
  os.remove(path)
 except:
  pass
def FFThW1(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFTAAa(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFqkJV():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVKPve)
 paths.append(VVKPve.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFoQ29(ba)
 for p in list:
  p = ba + p + VVKPve
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVmVo9, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVKPve, VVmVo9 , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVshnJ, VVdSQY = FFqkJV()
def FFtAvw():
 def VVpUxe(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VVgBfk   = VVpUxe(CFG.backupPath, CCKVDO.VV5ZNp())
 VVCrVN   = VVpUxe(CFG.downloadedPackagesPath, t)
 VV5Za9  = VVpUxe(CFG.exportedTablesPath, t)
 VVXXkO  = VVpUxe(CFG.exportedPIconsPath, t)
 VVzzvD   = VVpUxe(CFG.packageOutputPath, t)
 global VVhL6f
 VVhL6f = FFThW1(CFG.backupPath.getValue())
 if VVgBfk or VVzzvD or VVCrVN or VV5Za9 or VVXXkO or oldMovieDownloadPath:
  configfile.save()
 return VVgBfk, VVzzvD, VVCrVN, VV5Za9, VVXXkO, oldMovieDownloadPath
def FFN6Yw(path):
 path = FFTAAa(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFTjP0(SELF, pathList, tarFileName, addTimeStamp=True):
 VVd40u = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVd40u.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVd40u.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVd40u.append(path)
 if not VVd40u:
  FFAvZA(SELF, "Files not found!")
 elif not pathExists(VVhL6f):
  FFAvZA(SELF, "Path not found!\n\n%s" % VVhL6f)
 else:
  VVBorG = FFThW1(VVhL6f)
  tarFileName = "%s%s" % (VVBorG, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFLFgj())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVd40u:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVStMY
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFw6UZ(tarFileName, VV80BT))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFw6UZ(failed, VV80BT))
  cmd += "fi;"
  cmd +=  sep
  FFr3ln(SELF, cmd)
def FFuN11(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFpx0D(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFpx0D(SELF["keyInfo"], "info")
def FFpx0D(barObj, fName):
 path = "%s%s%s" % (VVdSQY, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFeGzm(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFqpI8(satNum)
  return satName
def FFqpI8(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFfCA9(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFeGzm(val)
  else  : sat = FFqpI8(val)
 return sat
def FFJ0oY(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFeGzm(num)
 except:
  pass
 return sat
def FFF1NR(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFbgUV(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFCNz5(info, iServiceInformation.sServiceref)
   prov = FFCNz5(info, iServiceInformation.sProvider)
   state = str(FFCNz5(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFNWS8(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFuK1e(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFCNz5(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FF2ErX(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFHIlX(refCode):
 info = FFDwp4(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFDZ6V(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFg7kC(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFDwp4(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVFnSu = eServiceCenter.getInstance()
  if VVFnSu:
   info = VVFnSu.info(service)
 return info
def FFf8Q6(SELF, refCode, VVIqkw=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFft24(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVIqkw:
   FFIdBb(SELF, isFromSession)
 try:
  VVreUe = InfoBar.instance
  if VVreUe:
   VVjitm = VVreUe.servicelist
   if VVjitm:
    servRef = eServiceReference(refCode)
    VVjitm.saveChannel(servRef)
 except:
  pass
def FFft24(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CC3oLs()
    if pr.VVGbY9(refCode, chName, decodedUrl, iptvRef):
     pr.VVw0dy(SELF, isFromSession)
def FFNWS8(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FF3iML(url): return FFQf5u(url) or FFz5m2(url)
def FFQf5u(url)  : return any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFz5m2(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFuK1e(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFPduo(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFPduo(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFC3CV(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFjsDH(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFHuvq(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFdGBV(txt):
 try:
  return FFjsDH(FFHuvq(txt)) == txt
 except:
  return False
def FFLuBK(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FFThW1(newPath), patt))
def FFIdBb(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: CCcojD.VVEI1u(session, isFromExternal=isFromSession)
 else      : FF3UUy(session, reopen=True)
def FF3UUy(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FF3UUy, session), CCTDYj)
  except:
   try:
    FFRXxh(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFarkl(refCode):
 tp = CCpEt4()
 if tp.VV7yl9(refCode) : return True
 else        : return False
def FFxJPq(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFjpsW(True)
     return True
 return False
def FFjpsW(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FFKJ9M()
def FFKJ9M():
 VVreUe = InfoBar.instance
 if VVreUe:
  VVjitm = VVreUe.servicelist
  if VVjitm:
   VVjitm.setMode()
def FFyIuW(root):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVFnSu = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVFnSu.info(service)
    lst.append((service.toString(), info.getName(service)))
 except:
  pass
 return lst
def FFXZbX():
 VV9WSF = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVwBvo = list(VV9WSF)
 return VVwBvo, VV9WSF
def FFI36Q():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFpJ0E(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FFLaSW(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFbS0L():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFLFgj():
 return FFbS0L().replace(" ", "_").replace("-", "").replace(":", "")
def FFQjGS(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFlazR():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FF8zMR(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCaayN.VVBGRU(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCaayN.VV4PiN(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFlWZ0("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFQBdn(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FFEOCn(num):
 return "s" if num > 1 else ""
def FFrVTn(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFzS0X(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFdA1L(a, b):
 return (a > b) - (a < b)
def FF8kED(a, b):
 def VVClIh(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VVClIh(a)
 b = VVClIh(b)
 return (a > b) - (a < b)
def FFucwL(mycmp):
 class CCSPMK(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CCSPMK
def FF6b7h(SELF, message, title="", VVUStE=None):
 SELF.session.openWithCallback(VVUStE, CC7it8, title=title, message=message, VVHoVk=True)
def FFheEQ(SELF, message, title="", VVDaM8=VVM50Z, VVUStE=None, **kwargs):
 SELF.session.openWithCallback(VVUStE, CC7it8, title=title, message=message, VVDaM8=VVDaM8, **kwargs)
def FFAvZA(SELF, message, title="")  : FFRXxh(SELF.session, message, title)
def FFXl6w(SELF, path, title="") : FFRXxh(SELF.session, "File not found !\n\n%s" % path, title)
def FF8QNX(SELF, path, title="") : FFRXxh(SELF.session, "File is empty !\n\n%s"  % path, title)
def FF0QO3(SELF, title="")  : FFRXxh(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFRXxh(session, message, title="") : session.open(BF(CCc6iq, title=title, message=message))
def FFJC4A(SELF, VVUStE, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVUStE, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVUStE, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFAvZA(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFOjga(SELF, callBack_Yes, VVByb6, callBack_No=None, title="", VVA7RB=False, VV8V8a=True):
 return SELF.session.openWithCallback(BF(FFpAy6, callBack_Yes, callBack_No)
          , BF(CCbt2B, title=title, VVByb6=VVByb6, VV8V8a=VV8V8a, VVA7RB=VVA7RB))
def FFpAy6(callBack_Yes, callBack_No, FFOjgaed):
 if FFOjgaed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFMYB5(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFAMY6(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFAQF9(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFRJ8Y(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVc558 = eTimer()
def FFAQF9(SELF, milliSeconds=1000):
 SELF.onClose.append(BF(FFJxxw, SELF))
 fnc = BF(FFJxxw, SELF)
 try:
  t = VVc558.timeout.connect(fnc)
 except:
  VVc558.callback.append(fnc)
 VVc558.start(milliSeconds, 1)
def FFJxxw(SELF):
 VVc558.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFyLgY(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCTHnd, **kwargs))
  else   : win = SELF.session.open(BF(CCTHnd, **kwargs))
  FFyfbj(win)
  return win
 except:
  return None
def FFKX6p(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CCK3F9, **kwargs))
 FFyfbj(win)
 return win
def FFDhQn(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFQTAA(SELF, **kwargs):
 SELF.session.open(CCnfxp, **kwargs)
def FFBmK5(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFJvZs(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFqDWf(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVOCsc, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFQGfp(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFqDWf(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize  = winInst.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFEFsT():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFfwAy(VV2ql8):
 screenSize  = FFEFsT()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VV2ql8)
 return bodyFontSize
def FFCOh0(VV2ql8, extraSpace):
 font = gFont(VVOCsc, VV2ql8)
 VVSYmq = fontRenderClass.getInstance().getLineHeight(font) or (VV2ql8 * 1.25)
 return int(VVSYmq + VVSYmq * extraSpace)
def FFheJw(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True):
 screenSize = FFEFsT()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVOCsc, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFCOh0(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVOCsc, titleFontSize, alignLeftCenter)
 if winType == VVXQaf or winType == VVHcRy:
  if winType == VVHcRy : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VV6Nc5:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == VVdmEc:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVOCsc, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d"    position="1,%d" size="%d,%d" zPosition="6" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VVFcCy:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FF6b7hL = b2Left2 + timeW + marginLeft
  FF6b7hW = b2Left3 - marginLeft - FF6b7hL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FF6b7hL , b2Top, FF6b7hW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVarsQ:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVW7yA:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVXRSp:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVkJ1U:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVOCsc, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVOCsc, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VV3Iw8:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVOCsc, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVZeE3:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVOCsc, fontH, alignCenter)
 elif winType in (VV4xIc, VV752q):
  if winType == VV4xIc: totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  else         : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - boxT) / totRows)
  picH = int(boxH * picR)
  lblH = int(boxH * lblR) - 2
  lblT = boxT + picH + 2
  lblFont = int(lblH * 0.65)
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VV4xIc:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h , fg, bg[i]  , VVOCsc, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h , fg, bg[i+3], VVOCsc, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVOCsc, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVOCsc, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h , fg, bg, VVOCsc, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h , fg, bg, VVOCsc, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00FFFF00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2, transpBG)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVOCsc, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVXIC2:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VV0RYQ:
  tmp += '<widget name="myPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (marginLeft, bodyTop, bodyW, bodyH)
 else:
  if   winType == VVn6dg : align = alignLeftCenter
  elif winType == VVQhck : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVL14D:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVOCsc
  if usefixedFont and winType == VVQhck:
   fLst = FFCwuA()
   if   VVrGjB in fLst and CFG.fontPathTerm.getValue(): fontName = VVrGjB
   elif VVMbWE in fLst         : fontName = VVMbWE
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VV2ql8 = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVOCsc, VV2ql8, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VV9Ea0 = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVOCsc, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VV9Ea0[i], VVOCsc, barFont, alignCenter)
   left += btnW + gap
 if winType == VVQhck:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VV9Ea0 = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VV9Ea0[i], VVOCsc, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFheJw(VVXQaf, 800, 950, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VVuNFw = ""
  self.themsList  = []
  s = "  "
  VVwSHr = []
  if VVDb0h:
   VVwSHr.append(("-- MY TEST --"    , "myTest"   ))
  VVwSHr.append((s + "File Manager"     , "FileManager"  ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append((s + "Services/Channels"   , "ChannelsTools" ))
  VVwSHr.append((s + "IPTV"       , "IptvTools"  ))
  VVwSHr.append((s + "PIcons"      , "PIconsTools"  ))
  VVwSHr.append((s + "SoftCam"      , "SoftCam"   ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append((s + "Plugins"      , "PluginsTools" ))
  VVwSHr.append((s + "Terminal"      , "Terminal"  ))
  VVwSHr.append((s + "Backup & Restore"    , "BackupRestore" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append((s + "Date/Time"     , "Date_Time"  ))
  VVwSHr.append((s + "Check Internet Connection" , "CheckInternet" ))
  self.totalItems = len(VVwSHr)
  FFqVmU(self, VVwSHr=VVwSHr)
  FFTGpi(self["keyRed"] , "Exit")
  FFTGpi(self["keyGreen"] , "Settings")
  FFTGpi(self["keyYellow"], "Dev. Info.")
  FFTGpi(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close      ,
   "green"   : self.VVBIns     ,
   "yellow"  : self.VVpP7K     ,
   "blue"   : self.VVqJJr     ,
   "info"   : self.VVqJJr     ,
   "next"   : self.VVrFWj     ,
   "menu"   : self.VV4H46   ,
   "0"    : BF(self.VVUgm3, 0)  ,
   "1"    : BF(self.VVJ47T, 1)   ,
   "2"    : BF(self.VVJ47T, 2)   ,
   "3"    : BF(self.VVJ47T, 3)   ,
   "4"    : BF(self.VVJ47T, 4)   ,
   "5"    : BF(self.VVJ47T, 5)   ,
   "6"    : BF(self.VVJ47T, 6)   ,
   "7"    : BF(self.VVJ47T, 7)   ,
   "8"    : BF(self.VVJ47T, 8)   ,
   "9"    : BF(self.VVJ47T, 9)
  })
  self.onShown.append(self.VVevf4)
  self.onClose.append(self.onExit)
  global VVpo5P, VVdBoH, VVhP34
  VVpo5P = VVdBoH = VVhP34 = False
 def VVmBrJ(self):
  item = FFulUr(self)
  self.VVJ47T(item)
 def VVJ47T(self, item):
  if item is not None:
   if item in range(1, 9):
    self["myMenu"].moveToIndex(item + 1)
    item = FFulUr(self)
   if   item == "myTest"     : self.VVvqy9()
   elif item in ("FileManager"  , 1) : self.session.open(CCeH84)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCKtc8)
   elif item in ("IptvTools"  , 3) : self.session.open(CCaayN)
   elif item in ("PIconsTools"  , 4) : self.VVJww5()
   elif item in ("SoftCam"   , 5) : self.session.open(CC5OGS)
   elif item in ("PluginsTools" , 6) : self.session.open(CC5116)
   elif item in ("Terminal"  , 7) : self.session.open(CCGmAs)
   elif item in ("BackupRestore" , 8) : self.session.open(CCVYZ0)
   elif item in ("Date_Time"  , 9) : self.session.open(CCHCTj)
   elif item in ("CheckInternet" , 10) : self.session.open(CCsbwx)
   else         : self.close()
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  FFpkQc(self["myMenu"])
  FFQGfp(self)
  FFBmK5(self)
  FFuN11(self)
  title = "  %s - %s" % (PLUGIN_NAME, VV191S)
  self["myTitle"].setText(title)
  VVgBfk, VVzzvD, VVCrVN, VV5Za9, VVXXkO, oldMovieDownloadPath = FFtAvw()
  self.VV8OD5()
  if VVgBfk or VVzzvD or VVCrVN or VV5Za9 or VVXXkO or oldMovieDownloadPath:
   VVQesM = lambda path, subj: "%s:\n%s\n\n" % (subj, FFNkac(path, VVmIAH)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVQesM(VVgBfk   , "Backup/Restore Path"    )
   txt += VVQesM(VVzzvD  , "Created Package Files (IPK/DEB)" )
   txt += VVQesM(VVCrVN  , "Download Packages (from feeds)" )
   txt += VVQesM(VV5Za9 , "Exported Tables"     )
   txt += VVQesM(VVXXkO , "Exported PIcons"     )
   txt += VVQesM(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFheEQ(self, txt, title="Settings Paths")
  if (EASY_MODE or VVli8I or VVDb0h):
   FFAMY6(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFMYB5(self, "Welcome", 300)
  FFuqQK(BF(self.VVlcl0, title))
 def VVlcl0(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCKVDO.VVjAP0()
   if url:
    newWebVer = CCKVDO.VVNuqZ(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFlWZ0("rm /tmp/ajpanel*"))
  global VVpo5P, VVdBoH, VVhP34
  VVpo5P = VVdBoH = VVhP34 = False
 def VVUgm3(self, digit):
  self.VVuNFw += str(digit)
  ln = len(self.VVuNFw)
  global VVpo5P, VVhP34
  if ln == 4:
   if self.VVuNFw == "0" * ln:
    VVpo5P = True
    FFAMY6(self["myTitle"], "#800080")
   else:
    self.VVuNFw = "x"
  elif self.VVuNFw == "0" * 8:
   VVhP34 = True
 def VVrFWj(self):
  self.VVuNFw += ">"
  if self.VVuNFw == "0" * 4 + ">" * 2:
   global VVdBoH
   VVdBoH = True
   FFAMY6(self["myTitle"], "#dd5588")
 def VVJww5(self):
  found = False
  pPath = CCVrfy.VVNV04()
  if pathExists(pPath):
   for fName, fType in CCVrfy.VVrCgj(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCVrfy)
  else:
   VVwSHr = []
   VVwSHr.append(("PIcons Tools" , "CCVrfy" ))
   VVwSHr.append(VVbzyo)
   VVwSHr.append(CCVrfy.VVW9HU())
   VVwSHr.append(VVbzyo)
   VVwSHr += CCVrfy.VV2gmI()
   FFKX6p(self, self.VVZNfr, VVwSHr=VVwSHr)
 def VVZNfr(self, item=None):
  if item:
   if   item == "CCVrfy"   : self.session.open(CCVrfy)
   elif item == "VVdLtF"  : CCVrfy.VVdLtF(self)
   elif item == "VVbFW1"  : CCVrfy.VVbFW1(self)
   elif item == "findPiconBrokenSymLinks" : CCVrfy.VVzqlw(self, True)
   elif item == "FindAllBrokenSymLinks" : CCVrfy.VVzqlw(self, False)
 def VVBIns(self):
  self.session.open(CCKVDO)
 def VVpP7K(self):
  self.session.open(CCve6t)
 def VVqJJr(self):
  changeLogFile = VVdSQY + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FF7up6(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFNkac("\n%s\n%s\n%s" % (VVStMY, line, VVStMY), VVSqFX, VV1R4z)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FFNkac(line, VVcK7G, VV1R4z)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFheEQ(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VV191S, PLUGIN_DESCRIPTION), VV2ql8=26)
 def VV4H46(self):
  title = "Style Changer"
  c1, c2, c3, c4 = VV4YPU, VVmIAH, VVXaO9, VVhTQL
  VVwSHr = []
  VVwSHr.append((c1 + "Change Title Colors"    , "title"  ))
  VVwSHr.append((c1 + "Change Menu Area Colors"   , "body"  ))
  VVwSHr.append((c1 + "Change Menu Pointer Colors"  , "cursor"  ))
  VVwSHr.append((c1 + "Change Bottom Bar Colors"  , "bar"   ))
  VVwSHr.append((c2 + "Reset Colors"     , "resetColor" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append((c3 + "Change %s Font" % PLUGIN_NAME , "mainFont" ))
  VVwSHr.append((c3 + "Change Termianl Font"    , "termFont" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append((c4 + "Change System Font"     , "sysFont"  ))
  FFKX6p(self, BF(self.VVZUo2, title), VVwSHr=VVwSHr, width=800, title=title)
 def VVZUo2(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VV3bhS()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVyubW, tDict, item), CC6XYk, defFG=fg, defBG=bg)
   elif item == "resetColor" : FFOjga(self, self.VVNA3p, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVtADS(VVL9lY  )
   elif item == "termFont"  : self.VVtADS(VVrGjB)
   elif item == "sysFont"  : self.VVtADS(VVGWDl  )
 def VVmwEk(self):
  return VVhL6f + "ajpanel_colors"
 def VV3bhS(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVmwEk()
  if fileExists(p):
   txt = FFa594(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVyubW(self, tDict, item, fg, bg):
  if fg:
   self.VVqzir(item, fg)
   self.VVaOVp(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVxlEg(tDict)
 def VVxlEg(self, tDict):
   p = self.VVmwEk()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVqzir(self, item, fg):
  if   item == "title" : FFilsZ(self["myTitle"], fg)
  elif item == "body"  :
   FFilsZ(self["myMenu"], fg)
   FFilsZ(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFAMY6(self["myBar"], fg)
   FFilsZ(self["keyRed"], fg)
   FFilsZ(self["keyGreen"], fg)
   FFilsZ(self["keyYellow"], fg)
   FFilsZ(self["keyBlue"], fg)
 def VVaOVp(self, item, bg):
  if   item == "title" : FFAMY6(self["myTitle"], bg)
  elif item == "body"  :
   FFAMY6(self["myMenu"], bg)
   FFAMY6(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFAMY6(self["myBar"], bg)
 def VVNA3p(self):
  os.system(FFlWZ0("rm %s" % self.VVmwEk()))
  self.close()
 def VV8OD5(self):
  tDict = self.VV3bhS()
  self.VVxeMB(tDict, "title")
  self.VVxeMB(tDict, "body")
  self.VVxeMB(tDict, "cursor")
  self.VVxeMB(tDict, "bar")
 def VVxeMB(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVqzir(name, fg)
  if bg: self.VVaOVp(name, bg)
 def VVtADS(self, name):
  if   name == VVL9lY : fPath, title = CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif name == VVrGjB: fPath, title = CFG.fontPathTerm.getValue(), "Terminal "
  elif name == VVGWDl : fPath, title = CFG.fontPathSys.getValue() , "System"
  title  = "Change %s Font" % title
  VVwSHr = []
  default = None
  fntPath = resolveFilename(SCOPE_FONTS)
  for path in FFLuBK(fntPath, "*.[tToO][tT][fF]"):
   VVwSHr.append((os.path.splitext(os.path.basename(path))[0], path))
  txt = " (Requires GUI Restart)" if name == VVGWDl else ""
  VVwSHr.sort(key=lambda x: x[0].lower())
  VVwSHr.insert(0, VVbzyo)
  VVwSHr.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if fPath:
   for ndx, item in enumerate(VVwSHr):
    if len(item) == 2 and item[1] == fPath:
     VVwSHr[ndx] = (VV80BT + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVwSHr[curIndex] = (VV80BT + VVwSHr[curIndex][0], VVwSHr[curIndex][1])
  if VVwSHr:
   menuInstance = FFKX6p(self, BF(self.VVY4Vz, name, title), title=title, VVwSHr=VVwSHr, VVCNiH="#00221111", VVIhEb="#00221111")
   menuInstance.VVEPkY(curIndex)
  else:
   FFAvZA(self, "No fonts found in:\n\n%s" % fntPath, title=title)
 def VVY4Vz(self, name, title, item):
  if item:
   path = "" if item == "DEFAULT" else item
   if   name == VVL9lY : FFGxwH(CFG.fontPathMain, path)
   elif name == VVrGjB: FFGxwH(CFG.fontPathTerm, path)
   elif name == VVGWDl : FFGxwH(CFG.fontPathSys , path)
   err = Main_Menu.VVZ1kI(name)
   if err          : FFAvZA(self, err, title=title)
   elif name == VVL9lY   : self.close()
   elif name == VVrGjB  : FFMYB5(self, "Terminal font applied", 1500, isGrn=True)
   elif name == VVGWDl and path : FFMYB5(self, "System font applied", 1500, isGrn=True)
   elif name == VVGWDl   : FFOjga(self, BF(Main_Menu.VViYG9, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VViYG9(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVZ1kI(name):
  if   name == VVL9lY : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VVrGjB: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VVGWDl : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FFCwuA()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VVGWDl:
   nameLst = []
   for nm in FFCwuA():
    if not nm in (VVL9lY, VVrGjB):
     nameLst.append(nm)
  else:
   nameLst = [name]
  for fntName in nameLst:
   totDone = 0
   try:
    addFont(path, fntName, 100, repl)
    totDone += 1
   except:
    try:
     addFont(path, fntName, 100, repl, 0)
     totDone += 1
    except:
     pass
  if totDone > 0: FFCwuA()
  else    : return "Could not add font"
 def VVvqy9(self):
  CCcojD.VVEI1u(self.session)
class CCor0x():
 @staticmethod
 def VV6pNt():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VV7fgv(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFyLgY(SELF, None, VVd40u=lst, VV2ql8=30, VVtvxl=True)
 @staticmethod
 def VVCSs3(path, SELF=None):
  for enc in CCor0x.VV6pNt():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFAvZA(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVNdUZ(SELF, path, cbFnc, defEnc="utf8", onlyWorkingEnc=True, title="Select Encoding"):
  FFMYB5(SELF)
  lst = CCor0x.VVwAn4(path, onlyWorkingEnc=onlyWorkingEnc)
  if lst:
   VVwSHr = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if defEnc == enc:
     txt = FFNkac(txt, VV80BT)
    VVwSHr.append((txt, enc))
   if onlyWorkingEnc: VVCNiH, VVIhEb = "#22003344", "#22002233"
   else    : VVCNiH, VVIhEb = "#22220000", "#22220000"
   FFKX6p(SELF, cbFnc, title=title, VVwSHr=VVwSHr, width=900, VVCNiH=VVCNiH, VVIhEb=VVIhEb)
  else:
   FFMYB5(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVwAn4(path, onlyWorkingEnc=True):
  encLst = []
  cPath = VVdSQY + "codecs"
  if fileExists(cPath):
   lines = FF7up6(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCor0x.VV6pNt())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if onlyWorkingEnc:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CCve6t(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFheJw(VVXQaf, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVwSHr = []
  VVwSHr.append(("Settings File"        , "SettingsFile"   ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Box Info"          , "VV2h8N"    ))
  VVwSHr.append(("Tuners Info"         , "VVfWAO"   ))
  VVwSHr.append(("Python Version"        , "VVBKiK"   ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Screen Size"         , "ScreenSize"    ))
  VVwSHr.append(("Language/Locale"        , "Locale"     ))
  VVwSHr.append(("Processor"         , "Processor"    ))
  VVwSHr.append(("Operating System"        , "OperatingSystem"   ))
  VVwSHr.append(("Drivers"          , "drivers"     ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("System Users"         , "SystemUsers"    ))
  VVwSHr.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVwSHr.append(("Uptime"          , "Uptime"     ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Host Name"         , "HostName"    ))
  VVwSHr.append(("MAC Address"         , "MACAddress"    ))
  VVwSHr.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVwSHr.append(("Network Status"        , "NetworkStatus"   ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Disk Usage"         , "VVZ4Cl"    ))
  VVwSHr.append(("Mount Points"         , "MountPoints"    ))
  VVwSHr.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVwSHr.append(("USB Devices"         , "USB_Devices"    ))
  VVwSHr.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVwSHr.append(("Directory Size"        , "DirectorySize"   ))
  VVwSHr.append(("Memory"          , "Memory"     ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVwSHr.append(("Running Processes"       , "RunningProcesses"  ))
  VVwSHr.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFqVmU(self, VVwSHr=VVwSHr, title="Device Information")
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  FFpkQc(self["myMenu"])
  FFQGfp(self)
 def VVmBrJ(self):
  global VVLQSn
  VVLQSn = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CC7Nor)
   elif item == "VV2h8N"    : self.VV2h8N()
   elif item == "VVfWAO"   : self.VVfWAO()
   elif item == "VVBKiK"   : self.VVBKiK()
   elif item == "ScreenSize"    : FFheEQ(self, "Width\t: %s\nHeight\t: %s" % (FFEFsT()[0], FFEFsT()[1]))
   elif item == "Locale"     : CCor0x.VV7fgv(self)
   elif item == "Processor"    : self.VVzdUi()
   elif item == "OperatingSystem"   : FFGC8R(self, "uname -a"        )
   elif item == "drivers"     : self.VVEPce()
   elif item == "SystemUsers"    : FFGC8R(self, "id"          )
   elif item == "LoggedInUsers"   : FFGC8R(self, "who -a"         )
   elif item == "Uptime"     : FFGC8R(self, "uptime"         )
   elif item == "HostName"     : FFGC8R(self, "hostname"        )
   elif item == "MACAddress"    : self.VVSbeR()
   elif item == "NetworkConfiguration"  : FFGC8R(self, "ifconfig %s %s" % (FFw6UZ("HWaddr", VVuRbD), FFw6UZ("addr:", VVSqFX)))
   elif item == "NetworkStatus"   : FFGC8R(self, "netstat -tulpn"       )
   elif item == "VVZ4Cl"    : self.VVZ4Cl()
   elif item == "MountPoints"    : FFGC8R(self, "mount %s" % (FFw6UZ(" on ", VVSqFX)))
   elif item == "FileSystemTable"   : FFGC8R(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFGC8R(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFGC8R(self, "blkid"         )
   elif item == "DirectorySize"   : FFGC8R(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVRXt6="Reading size ...")
   elif item == "Memory"     : FFGC8R(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VV6v6R()
   elif item == "RunningProcesses"   : FFGC8R(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFGC8R(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVKpa9()
   else         : self.close()
 def VVSbeR(self):
  res = FFnUjX("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFheEQ(self, txt)
  else:
   FFGC8R(self, "ip link")
 def VV7zdF(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFIsyt(cmd)
  return lines
 def VVIx3F(self, lines, headerRepl, widths, VVe5VU):
  VVmJ2p = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVmJ2p.append(parts)
  if VVmJ2p and len(header) == len(widths):
   VVmJ2p.sort(key=lambda x: x[0].lower())
   FFyLgY(self, None, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=28, VVtvxl=True)
   return True
  else:
   return False
 def VVZ4Cl(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFnUjX(cmd)
  if not "invalid option" in txt:
   lines  = self.VV7zdF(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVe5VU = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVIx3F(lines, headerRepl, widths, VVe5VU)
  else:
   cmd = "df -h"
   lines  = self.VV7zdF(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVe5VU = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVIx3F(lines, headerRepl, widths, VVe5VU)
  if not allOK:
   lines = FFIsyt(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFTAAa(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VV80BT:
     note = "\n%s" % FFNkac("Green = Mounted Partitions", VV80BT)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVSqFX
     elif line.endswith(mountList) : color = VV80BT
     else       : color = VVcK7G
     txt += FFNkac(line, color) + "\n"
    FFheEQ(self, txt + note)
   else:
    FFAvZA(self, "Not data from system !")
 def VV6v6R(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VV7zdF(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVe5VU = (LEFT , CENTER, LEFT )
  allOK = self.VVIx3F(lines, headerRepl, widths, VVe5VU)
  if not allOK:
   FFGC8R(self, cmd)
 def VVEPce(self):
  cmd = FFeJzm(VVT5Tj, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFGC8R(self, cmd)
  else : FF0QO3(self)
 def VVzdUi(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFGC8R(self, cmd)
 def VVKpa9(self):
  cmd = FFeJzm(VVadVa, "| grep secondstage")
  if cmd : FFGC8R(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FF0QO3(self)
 def VV2h8N(self):
  c = VV80BT
  VVd40u = []
  VVd40u.append((FFNkac("Box Type"  , c), FFNkac(self.VVtdnX("boxtype").upper(), c)))
  VVd40u.append((FFNkac("Board Version", c), FFNkac(self.VVtdnX("board_revision") , c)))
  VVd40u.append((FFNkac("Chipset"  , c), FFNkac(self.VVtdnX("chipset")  , c)))
  VVd40u.append((FFNkac("S/N"   , c), FFNkac(self.VVtdnX("sn")    , c)))
  VVd40u.append((FFNkac("Version"  , c), FFNkac(self.VVtdnX("version")  , c)))
  VV0SRR   = []
  VVRR9g = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVRR9g = SystemInfo[key]
     else:
      VV0SRR.append((FFNkac(str(key), VVHJRy), FFNkac(str(SystemInfo[key]), VVHJRy)))
  except:
   pass
  if VVRR9g:
   VVWRw5 = self.VVrWMK(VVRR9g)
   if VVWRw5:
    VVWRw5.sort(key=lambda x: x[0].lower())
    VVd40u += VVWRw5
  if VV0SRR:
   VV0SRR.sort(key=lambda x: x[0].lower())
   VVd40u += VV0SRR
  if VVd40u:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFyLgY(self, None, header=header, VVd40u=VVd40u, VVLpvM=widths, VV2ql8=28, VVtvxl=True)
  else:
   FFheEQ(self, "Could not read info!")
 def VVtdnX(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FF7up6(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVrWMK(self, mbDict):
  try:
   mbList = list(mbDict)
   VVd40u = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVd40u.append((FFNkac(subject, VVSqFX), FFNkac(value, VVSqFX)))
  except:
   pass
  return VVd40u
 def VVfWAO(self):
  txt = self.VVDmXL("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVDmXL("/proc/bus/nim_sockets")
  if not txt: txt = self.VVCG5o()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFheEQ(self, txt)
 def VVCG5o(self):
  txt = ""
  VVQesM = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVQesM("Slot Name" , slot.getSlotName())
     txt += FFNkac(slotName, VVSqFX)
     txt += VVQesM("Description"  , slot.getFullDescription())
     txt += VVQesM("Frontend ID"  , slot.frontend_id)
     txt += VVQesM("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVDmXL(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FF7up6(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFNkac(line, VVSqFX)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVBKiK(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFheEQ(self, txt)
 @staticmethod
 def VV9WRq():
  def VVQesM(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VVQesM(v,0), "/etc/issue.net": VVQesM(v,1), "/etc/image-version": VVQesM(v,2)}
  for p1, d in v.items():
   img = CCve6t.VVpNpj(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VVQesM(v,0), p + "Plugins/": VVQesM(v,1), VVGc43: VVQesM(v,2), VVKPve: VVQesM(v,3)}
  for p1, d in v.items():
   img = CCve6t.VViRXf(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VVpNpj(path, d):
  if fileExists(path):
   txt = FFa594(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VViRXf(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CC7Nor(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFheJw(VVXQaf, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVwSHr = []
  VVwSHr.append(("Settings (All)"   , "Settings_All"   ))
  VVwSHr.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVwSHr.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVwSHr.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVwSHr.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVwSHr.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVwSHr.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VVdBoH:
   VVwSHr.append(VVbzyo)
   VVwSHr.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVwSHr.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FFqVmU(self, VVwSHr=VVwSHr)
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  FFpkQc(self["myMenu"])
  FFQGfp(self)
 def VVmBrJ(self):
  global VVLQSn
  VVLQSn = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %ssettings" % VVslLY
   grep = " | grep "
   if   item == "Settings_All"    : FFGC8R(self, cmd                )
   elif item == "Settings_HotKeys"   : FFGC8R(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_ajp"    : FFGC8R(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME     )
   elif item == "Settings_FHDG_17"   : FFGC8R(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFGC8R(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFGC8R(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFGC8R(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFGC8R(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFGC8R(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CC5OGS(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFheJw(VVXQaf, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVOuHB, VVRVDT, VVtvwB, camCommand = CC5OGS.VVTESq()
  self.VVRVDT = VVRVDT
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VVRVDT:
   c = VV4YPU if VVtvwB else VVtjbM
   if   "oscam" in VVRVDT : camName, oC = "OSCam", c
   elif "ncam"  in VVRVDT : camName, nC = "NCam" , c
  VVwSHr = []
  VVwSHr.append(("OSCam Files" , "OSCamFiles"  ))
  VVwSHr.append(("NCam Files" , "NCamFiles"  ))
  VVwSHr.append(("CCcam Files" , "CCcamFiles"  ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append((VVXaO9 + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VVPdi2" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVwSHr.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVwSHr.append(VVbzyo)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  if VVRVDT: VVwSHr.append((c + txt  , "camInfo" ))
  else  : VVwSHr.append((txt  ,    ))
  VVwSHr.append(VVbzyo)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VVRVDT:
   for item in camLst: VVwSHr.append(item)
  else:
   for item in camLst: VVwSHr.append((item[0], ))
  FFqVmU(self, VVwSHr=VVwSHr)
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  FFpkQc(self["myMenu"])
  FFQGfp(self)
 def VVmBrJ(self):
  global VVLQSn
  VVLQSn = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCvDOf, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCvDOf, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCvDOf, "cccam"))
   elif item == "VVPdi2" : self.VVPdi2()
   elif item == "OSCamReaders"  : self.VVwPA5("os")
   elif item == "NSCamReaders"  : self.VVwPA5("n")
   elif item == "camInfo"   : FFKUi6(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CC5OGS.VVGDMg(self.session, CCzK42.VVwE8Y)
   elif item == "camLiveReaders" : CC5OGS.VVGDMg(self.session, CCzK42.VVm9CP)
   elif item == "camLiveLog"  : CC5OGS.VVGDMg(self.session, CCzK42.VVOi3i)
   else       : self.close()
 def VVPdi2(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVhL6f, FFLFgj())
  if fileExists(path):
   lines = FF7up6("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VVQesM = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VVQesM("label"    , "CCcam-Line-%d" % ndx))
      f.write(VVQesM("description"  , "CCcam-Line-%d" % ndx))
      f.write(VVQesM("protocol"   , "cccam"))
      f.write(VVQesM("device"    , "%s,%s" % (host, port)))
      f.write(VVQesM("user"    , User))
      f.write(VVQesM("password"   , Pass))
      f.write(VVQesM("fallback"   , "1"))
      f.write(VVQesM("group"    , "64"))
      f.write(VVQesM("cccversion"   , "2.3.2"))
      f.write(VVQesM("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FF6b7h(self, "Output = %d Reader%s in:\n\n%s" % (tot, FFEOCn(tot), outFile))
   else:
    FFMYB5(self, "No valid CCcam lines", 1500)
  else:
   FFMYB5(self, "%s not found" % path, 1500)
 def VVwPA5(self, camPrefix):
  VVmJ2p = self.VVTIEQ(camPrefix)
  if VVmJ2p:
   VVmJ2p.sort(key=lambda x: int(x[0]))
   if self.VVRVDT and self.VVRVDT.startswith(camPrefix):
    VVcZtS = ("Toggle State", self.VVmd9W, [camPrefix], "Changing State ...")
   else:
    VVcZtS = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVe5VU  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFyLgY(self, None, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVcZtS=VVcZtS, VV1YOp=True)
 def VVTIEQ(self, camPrefix):
  readersFile = self.VVOuHB + camPrefix + "cam.server"
  VVmJ2p = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FF7up6(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVmJ2p.append((str(len(VVmJ2p) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVmJ2p:
    FFAvZA(self, "No readers found !")
  else:
   FFXl6w(self, readersFile)
  return VVmJ2p
 def VVmd9W(self, VVl7Cx, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVOuHB, camPrefix)
  readerState  = VVl7Cx.VVboCB(1)
  readerLabel  = VVl7Cx.VVboCB(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CC5OGS.VVK7Ol(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVl7Cx.VVTKmx()
    FFAvZA(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVmJ2p = self.VVTIEQ(camPrefix)
   if VVmJ2p:
    VVl7Cx.VVfoGr(VVmJ2p)
  else:
   VVl7Cx.VVTKmx()
 @staticmethod
 def VVK7Ol(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FF7up6(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFAvZA(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFAvZA(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFXl6w(SELF, confFile)
   return None
  if not iRequest:
   FFAvZA(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CC5OGS.VV8lQd(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FFAvZA(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VV8lQd(SELF):
  if iElem:
   return True
  else:
   FFAvZA(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVGDMg(session, VVJP7y):
  VVOuHB, VVRVDT, VVtvwB, camCommand = CC5OGS.VVTESq()
  if VVRVDT:
   runLog = False
   if   VVJP7y == CCzK42.VVwE8Y : runLog = True
   elif VVJP7y == CCzK42.VVm9CP : runLog = True
   elif not VVtvwB          : FFRXxh(session, message="SoftCam not started yet!")
   elif fileExists(VVtvwB)        : runLog = True
   else             : FFRXxh(session, message="File not found !\n\n%s" % VVtvwB)
   if runLog:
    session.open(BF(CCzK42, VVOuHB=VVOuHB, VVRVDT=VVRVDT, VVtvwB=VVtvwB, VVJP7y=VVJP7y))
  else:
   FFRXxh(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VVTESq():
  VVOuHB = "/etc/tuxbox/config/"
  VVRVDT = None
  VVtvwB  = None
  camCommand = FFnz9X("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VVRVDT = "oscam"
   elif camCmd.startswith("ncam") : VVRVDT = "ncam"
  if VVRVDT:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFa594(path), IGNORECASE)
     if span:
      VVOuHB = FFThW1(span.group(1))
      break
   else:
    path = FFnz9X(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FFThW1(path)
    if pathExists(path):
     VVOuHB = path
   tFile = FFThW1(VVOuHB) + VVRVDT + ".conf"
   tFile = FFnz9X("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVtvwB = tFile
  return VVOuHB, VVRVDT, VVtvwB, camCommand
class CCvDOf(Screen):
 def __init__(self, VVrBel, session, args=0):
  self.skin, self.skinParam = FFheJw(VVXQaf, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVOuHB, VVRVDT, VVtvwB, camCommand = CC5OGS.VVTESq()
  if   VVrBel == "ncam" : self.prefix = "n"
  elif VVrBel == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVwSHr = []
  if self.prefix == "":
   VVwSHr.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVwSHr.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVwSHr.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVwSHr.append(("constant.cw"         , "x_constant_cw" ))
   VVwSHr.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVwSHr.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVwSHr.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVwSHr.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVwSHr.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVwSHr.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVwSHr.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVwSHr.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVwSHr.append(VVbzyo)
   VVwSHr.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVwSHr.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVwSHr.append(VVbzyo)
   VVwSHr.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVwSHr.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVwSHr.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFqVmU(self, VVwSHr=VVwSHr)
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  FFpkQc(self["myMenu"])
  FFQGfp(self)
 def VVmBrJ(self):
  global VVLQSn
  VVLQSn = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFsBYR(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFsBYR(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFsBYR(self, self.VVOuHB + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFsBYR(self, self.VVOuHB + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVq0Z3("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVq0Z3("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVq0Z3("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVq0Z3("cam.provid"        )
   elif item == "x_cam_server"  : self.VVq0Z3("cam.server"        )
   elif item == "x_cam_services" : self.VVq0Z3("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVq0Z3("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVq0Z3("cam.user"        )
   elif item == "x_VVStMY"   : pass
   elif item == "x_SoftCam_Key" : self.VVvkzc()
   elif item == "x_CCcam_cfg"  : FFsBYR(self, self.VVOuHB + "CCcam.cfg"    )
   elif item == "x_VVStMY"   : pass
   elif item == "x_cam_log"  : FFsBYR(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFsBYR(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFsBYR(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVq0Z3(self, fileName):
  FFsBYR(self, self.VVOuHB + self.prefix + fileName)
 def VVvkzc(self):
  path = self.VVOuHB + "SoftCam.Key"
  if fileExists(path) : FFsBYR(self, path)
  else    : FFsBYR(self, path.replace(".Key", ".key"))
class CCzK42(Screen):
 VVwE8Y  = 0
 VVm9CP = 1
 VVOi3i = 2
 def __init__(self, session, VVOuHB="", VVRVDT="", VVtvwB="", VVJP7y=VVwE8Y):
  self.skin, self.skinParam = FFheJw(VVQhck, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVtvwB   = VVtvwB
  self.VVJP7y  = VVJP7y
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVOuHB + VVRVDT + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVRVDT : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVOuHB, self.camPrefix)
  if self.VVJP7y == self.VVwE8Y:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVJP7y == self.VVm9CP:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFqVmU(self, self.Title, addScrollLabel=True)
  FFTGpi(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VV6cTb
  self.onShown.append(self.VVevf4)
  self.onClose.append(self.onExit)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  self["myLabel"].VV3oQu(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFBmK5(self)
  self.VV6cTb()
 def onExit(self):
  self.timer.stop()
 def VVMWbv(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVzu8z)
  except:
   self.timer.callback.append(self.VVzu8z)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFMYB5(self, "Started", 1000)
 def VVeNt2(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVzu8z)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFMYB5(self, "Stopped", 1000)
 def VV6cTb(self):
  if self.timerRunning:
   self.VVeNt2()
  else:
   self.VVMWbv()
   if self.VVJP7y == self.VVwE8Y or self.VVJP7y == self.VVm9CP:
    if self.VVJP7y == self.VVwE8Y : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CC5OGS.VVK7Ol(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFuqQK(self.VVptk6)
    else:
     self.close()
   else:
    self.VVJeWK()
 def VVzu8z(self):
  if self.timerRunning:
   if   self.VVJP7y == self.VVwE8Y : self.VVN0ZL()
   elif self.VVJP7y == self.VVm9CP : self.VVN0ZL()
   else            : self.VVJeWK()
 def VVJeWK(self):
  if fileExists(self.VVtvwB):
   fTime = FFLaSW(os.path.getmtime(self.VVtvwB))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVxzOH(), VVDaM8=VVGmpm)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVtvwB)
 def VVptk6(self):
  self.VVN0ZL()
 def VVN0ZL(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFNkac("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVHKA4))
   self.camWebIfErrorFound = True
   self.VVeNt2()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVJP7y == self.VVwE8Y : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFNkac("Error while parsing data elements !\n\nError = %s" % str(e), VV0rNQ)
   self.camWebIfErrorFound = True
   self.VVeNt2()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVpXy2(root)
  self["myLabel"].setText(txt, VVDaM8=VVGmpm)
  self["myBar"].setText("Last Update : %s" % FFbS0L())
 def VVpXy2(self, rootElement):
  def VVQesM(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVJP7y == self.VVwE8Y:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFNkac(status, VV80BT)
    else          : status = FFNkac(status, VV0rNQ)
    txt += VVStMY + "\n"
    txt += VVQesM("Name"  , name)
    txt += VVQesM("Description" , desc)
    txt += VVQesM("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVQesM("Protocol" , protocol)
    txt += VVQesM("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFNkac("Yes", VV80BT)
    else    : enabTxt = FFNkac("No", VV0rNQ)
    txt += VVStMY + "\n"
    txt += VVQesM("Label"  , label)
    txt += VVQesM("Protocol" , protocol)
    txt += VVQesM("Enabled" , enabTxt)
  return txt
 def VVxzOH(self):
  lines = FFIsyt("tail -n %d %s" % (100, self.VVtvwB))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VVhTQL + line[:19] + VVcK7G + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVlWiV + "WebIf" + VVcK7G)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VVHJRy + h1 + h2 + VVcK7G + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VV80BT + span.group(2) + VVXaO9 + span.group(3) + VVcK7G + span.group(4)
    line = self.VVeYnk(line, VVXaO9, ("(webif)", ))
    line = self.VVeYnk(line, VVXaO9, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VVeYnk(line, VV80BT, ("OSCam", "NCam", "log switched"))
    line = self.VVeYnk(line, VVmIAH, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVSqFX + line[ndx + 3:] + VVcK7G
   elif line.startswith("----") or ">>" in line:
    line = FFNkac(line, VV1R4z)
   txt += line + "\n"
  return txt
 def VVeYnk(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVcK7G + t3
  return line
class CCVYZ0(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFheJw(VVXQaf, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVwSHr = []
  VVwSHr.append(("Backup Channels"    , "VVahOk"   ))
  VVwSHr.append(("Restore Channels"    , "Restore_Channels"  ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Backup SoftCAM Files"   , "VVaM7q" ))
  VVwSHr.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVwSHr.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVwSHr.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Backup Network Settings"  , "VVxx2e"   ))
  VVwSHr.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVdBoH:
   VVwSHr.append(VVbzyo)
   VVwSHr.append((VVHKA4 + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VVNPmj"   ))
   VVwSHr.append((VV80BT + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVpfwY) , "createMyIpk"   ))
   VVwSHr.append((VV80BT + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVpfwY) , "createMyDeb"   ))
   VVwSHr.append((VVHJRy + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVwSHr.append((VVHJRy + "Decode %s Crash Report"   % PLUGIN_NAME     , "VVZEgq" ))
  FFqVmU(self, VVwSHr=VVwSHr)
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  FFpkQc(self["myMenu"])
  FFQGfp(self)
 def VVmBrJ(self):
  global VVLQSn
  VVLQSn = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVahOk"    : self.VVahOk()
   elif item == "Restore_Channels"    : self.VV9VUn("channels_backup*.tar.gz", self.VVFruz, isChan=True)
   elif item == "VVaM7q"   : self.VVaM7q()
   elif item == "Restore_SoftCAM_Files"  : self.VV9VUn("softcam_backup*.tar.gz", self.VV6JNl)
   elif item == "Backup_TunerDiSEqC"   : self.VVHZW0("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VV9VUn("tuner_backup*.backup", BF(self.VVgSYQ, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVHZW0("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VV9VUn("hotkey_*backup*.backup", BF(self.VVgSYQ, "misc"))
   elif item == "VVxx2e"    : self.VVxx2e()
   elif item == "Restore_Network"    : self.VV9VUn("network_backup*.tar.gz", self.VV6PbO)
   elif item == "VVNPmj"     : FFOjga(self, BF(FFqXEj, self, BF(CCVYZ0.VVNPmj, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVZCsk(False)
   elif item == "createMyDeb"     : self.VVZCsk(True)
   elif item == "createMyTar"     : self.VVhlp3()
   elif item == "VVZEgq"   : self.VVZEgq()
 @staticmethod
 def VVNPmj(SELF):
  OBF_Path = VVshnJ + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVshnJ, VV191S, VVpfwY)
   if err : FFAvZA(SELF, err)
   else : FFheEQ(SELF, txt)
  else:
   FFXl6w(SELF, OBF_Path)
 def VVZCsk(self, VVM65w):
  OBF_Path = VVshnJ + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFAvZA(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVshnJ)
  os.system("mv -f %s %s" % (VVshnJ + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVshnJ + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVshnJ + "plugin.py"))
  self.session.openWithCallback(self.VViFw4, BF(CCjcS8, path=VVshnJ, VVM65w=VVM65w))
 def VViFw4(self):
  os.system("mv -f %s %s" % (VVshnJ + "OBF/main.py"  , VVshnJ))
  os.system("mv -f %s %s" % (VVshnJ + "OBF/plugin.py" , VVshnJ))
 def VVZEgq(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFAvZA(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFAvZA(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVag9y("%s*.list" % path)
  if err:
   FFXl6w(self, path + "*.list")
   return
  srcF, err = self.VVag9y("%s*main_final.py" % path)
  if err:
   FFXl6w(self, path + "*.final.py")
   return
  VVd40u = []
  for f in files:
   f = os.path.basename(f)
   VVd40u.append((f, f))
  FFKX6p(self, BF(self.VV0x7P, path, codF, srcF), VVwSHr=VVd40u)
 def VV0x7P(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFXl6w(self, logF)
   else     : FFqXEj(self, BF(self.VVra1Z, logF, codF, srcF))
 def VVra1Z(self, logF, codF, srcF):
  lst  = []
  lines = FF7up6(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFAvZA(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVwPu5(lst, logF, newLogF)
  totSrc  = self.VVwPu5(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFheEQ(self, txt)
 def VVag9y(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVwPu5(self, lst, f1, f2):
  txt = FFa594(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVhlp3(self):
  VVd40u = []
  VVd40u.append("%s%s" % (VVshnJ, "*.py"))
  VVd40u.append("%s%s" % (VVshnJ, "*.png"))
  VVd40u.append("%s%s" % (VVshnJ, "*.xml"))
  VVd40u.append("%s"  % (VVdSQY))
  FFTjP0(self, VVd40u, "%s_%s" % (PLUGIN_NAME, VV191S), addTimeStamp=False)
 def VVahOk(self):
  path1 = VVslLY
  path2 = "/etc/tuxbox/"
  VVd40u = []
  VVd40u.append("%s%s" % (path1, "*.tv"))
  VVd40u.append("%s%s" % (path1, "*.radio"))
  VVd40u.append("%s%s" % (path1, "*list"))
  VVd40u.append("%s%s" % (path1, "lamedb*"))
  VVd40u.append("%s%s" % (path2, "*.xml"))
  FFTjP0(self, VVd40u, self.VVwqej("channels_backup"), addTimeStamp=True)
 def VVaM7q(self):
  VVd40u = []
  VVd40u.append("/etc/tuxbox/config/")
  VVd40u.append("/usr/keys/")
  VVd40u.append("/usr/scam/")
  VVd40u.append("/etc/CCcam.cfg")
  FFTjP0(self, VVd40u, self.VVwqej("softcam_backup"), addTimeStamp=True)
 def VVxx2e(self):
  VVd40u = []
  VVd40u.append("/etc/hostname")
  VVd40u.append("/etc/default_gw")
  VVd40u.append("/etc/resolv.conf")
  VVd40u.append("/etc/wpa_supplicant*.conf")
  VVd40u.append("/etc/network/interfaces")
  VVd40u.append("%snameserversdns.conf" % VVslLY)
  FFTjP0(self, VVd40u, self.VVwqej("network_backup"), addTimeStamp=True)
 def VVwqej(self, fName):
  img = CCve6t.VV9WRq()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVFruz(self, fileName=None):
  if fileName:
   FFOjga(self, BF(FFqXEj, self, BF(self.VVQ2so, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VVQ2so(self, fileName):
  path = "%s%s" % (VVhL6f, fileName)
  if fileExists(path):
   if CCeH84.VVIB0Q(path):
    VVNxww , VVBBkW = CCKtc8.VVdWKU()
    VVYCHr, VV5hi2 = CCKtc8.VVZdgR()
    cmd  = FFlWZ0("cd %s" % VVslLY) + ";"
    cmd += FFlWZ0("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VVBBkW, VV5hi2))+ ";"
    cmd += "tar -xzf '%s' -C /" % path
    res = os.system(cmd)
    FFjpsW()
    if res == 0 : FF6b7h(self, "Channels Restored.")
    else  : FFAvZA(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FFAvZA(self, "Invalid tar file:\n\n%s" % path)
  else:
   FFXl6w(self, path)
 def VV6JNl(self, fileName=None):
  if fileName:
   FFOjga(self, BF(self.VVv8Ox, fileName), "Overwrite SoftCAM files ?")
 def VVv8Ox(self, fileName):
  fileName = "%s%s" % (VVhL6f, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVStMY
   note = "You may need to restart your SoftCAM."
   FFSiFd(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFw6UZ(note, VVSqFX), sep))
  else:
   FFXl6w(self, fileName)
 def VV6PbO(self, fileName=None):
  if fileName:
   FFOjga(self, BF(self.VV3b9o, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VV3b9o(self, fileName):
  fileName = "%s%s" % (VVhL6f, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFCHwU(self,  cmd)
  else:
   FFXl6w(self, fileName)
 def VV9VUn(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFNk49()
  if pathExists(VVhL6f):
   myFiles = FFLuBK(VVhL6f, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVd40u = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVd40u.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VV7qf7 = ("Sat. List", self.VVMGh7)
    elif isChan and iTar: VV7qf7 = ("Bouquets Importer", CC70ak.VVrsE8)
    else    : VV7qf7 = None
    VVoZDD = ("Delete File", self.VVEXcp)
    FFKX6p(self, callBackFunction, title=title, width=1200, VVwSHr=VVd40u, VV7qf7=VV7qf7, VVoZDD=VVoZDD)
   else:
    FFAvZA(self, "No files found in:\n\n%s" % VVhL6f, title)
  else:
   FFAvZA(self, "Path not found:\n\n%s" % VVhL6f, title)
 def VVEXcp(self, VVZPLhObj, path):
  FFOjga(self, BF(self.VVMf0l, VVZPLhObj, path), "Delete this file ?\n\n%s" % path)
 def VVMf0l(self, VVZPLhObj, path):
  path = VVhL6f + path
  FFblrr(path)
  if fileExists(path) : FFMYB5(VVZPLhObj, "Not deleted", 1000)
  else    : VVZPLhObj.VVPjeT()
 def VVHZW0(self, filePrefix, wordsFilter):
  settingFile = "%ssettings" % VVslLY
  tCons = CCPx0q()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VVsp8i, filePrefix))
 def VVsp8i(self, filePrefix, result, retval):
  title = FFNk49()
  if pathExists(VVhL6f):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFAvZA(self, "Cannot read settings file", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVhL6f, filePrefix, self.VVwqej(""), FFLFgj())
    try:
     VVd40u = str(result.strip()).split()
     if VVd40u:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVd40u:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVStMY, FFNkac(fName, VVSqFX), VVStMY)
       FFheEQ(self, txt, title=title, VVDaM8=VVGmpm)
      else:
       FFAvZA(self, "File creation failed!", title)
     else:
      FFAvZA(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFlWZ0("rm %s" % fName))
     FFAvZA(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFlWZ0("rm %s" % fName))
     FFAvZA(self, "Error while writing file.")
  else:
   FFAvZA(self, "Path not found:\n\n%s" % VVhL6f, title)
 def VVgSYQ(self, mode, path=None):
  if path:
   path = "%s%s" % (VVhL6f, path)
   if fileExists(path):
    lines = FF7up6(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFOjga(self, BF(self.VVrWPm, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FF8QNX(self, path, title=FFNk49())
   else:
    FFXl6w(self, path)
 def VVrWPm(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVwcGi = []
  VVwcGi.append("echo -e 'Reading current settings ...'")
  VVwcGi.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVwcGi.append("echo -e 'Preparing new settings ...'")
  VVwcGi.append(settingsLines)
  VVwcGi.append("echo -e 'Applying new settings ...'")
  VVwcGi.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFi3Gr(self, VVwcGi)
 def VVMGh7(self, VVZPLhObj, path):
  if not path:
   return
  path = VVhL6f + path
  if not fileExists(path):
   FFXl6w(self, path)
   return
  txt = FFa594(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVd40u  = []
   for item in satList:
    VVd40u.append("%s\t%s" % (item[0], FFeGzm(item[1])))
   FFheEQ(self, VVd40u, title="  Satellites List")
  else:
   FFAvZA(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CC70ak():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VVrsE8(SELF, fName):
  bi = CC70ak(SELF)
  bi.instance = bi
  bi.VVdVOf(SELF, fName)
 @staticmethod
 def VV5nEP(SELF):
  bi = CC70ak(SELF)
  bi.instance = bi
  bi.VVVo46()
 def VVdVOf(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVhL6f + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FFqXEj(waitObg, self.VVyNKy, title="Reading bouquets ...")
  else      : self.VVV9Dv(self.filePath)
 def VVWyxg(self, txt) : FFAvZA(self.SELF, txt, title=self.Title)
 def VViqYq(self, txt)  : FFMYB5(self, txt, 1500)
 def VVV9Dv(self, path) : FFXl6w(self.SELF, path, title=self.Title)
 def VVVo46(self):
  if pathExists(VVhL6f):
   lst = FFLuBK(VVhL6f, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VVCndv())
   if len(lst) > 0:
    VVwSHr = []
    for item in lst:
     item = os.path.basename(item)
     txt = FFNkac(item, VVXaO9) if item.endswith(".zip") else item
     VVwSHr.append((txt, item))
    VVwSHr.sort(key=lambda x: x[1].lower())
    OKBtnFnc = self.VVUeEj
    FFKX6p(self.SELF, self.VVHi21, title=self.Title, width=1200, VVwSHr=VVwSHr, OKBtnFnc=OKBtnFnc, VVCNiH="#22111111", VVIhEb="#22111111")
   else:
    self.VVWyxg("No valid backup files found in:\n\n%s" % VVhL6f)
  else:
   self.VVWyxg("Backup Directory not found:\n\n%s" % VVhL6f)
 def VVUeEj(self, item=None):
  if item:
   menuInstance, txt, fName, ndx = item
   self.VVdVOf(menuInstance, fName)
 def VVHi21(self, item=None):
  if not item and self.instance:
   del self.instance
 def VVCndv(self):
  files = FFLuBK(VVhL6f, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VVyNKy(self):
  lines, err = CC70ak.VVxPsW(self.filePath, "bouquets.tv")
  if err:
   self.VVWyxg(err)
   return
  bTvSortLst  = self.VVXx8g(lines)
  lines, err = CC70ak.VVxPsW(self.filePath, "bouquets.radio")
  if err:
   self.VVWyxg(err)
   return
  bRadSortLst = self.VVXx8g(lines)
  VVmJ2p = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VV6PKm(f, mode, len(VVmJ2p), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVmJ2p.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VV6PKm(f, mode, len(VVmJ2p), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VV6PKm(f, mode, len(VVmJ2p), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVmJ2p.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VV6PKm(f, mode, len(VVmJ2p), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVmJ2p:
   VVmJ2p.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVmJ2p): VVmJ2p[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVmJ2p):
     if key == os.path.basename(row[9]):
      VVmJ2p = VVmJ2p[:ndx+1] + lst + VVmJ2p[ndx+1:]
      break
   for ndx, item in enumerate(VVmJ2p): VVmJ2p[ndx][0] = str(ndx + 1)
   VV9Ea0 = "#11000600"
   VVVt3G  = ("Show Services" , self.VVBcuH  , [], "Reading ..." )
   VVq3zo = ("Options"  , self.VVGs9C, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 43   , 7  , 7   , 7  , 7  , 7   , 7   , 8   ,  0.01 )
   VVe5VU  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER ,  LEFT )
   FFyLgY(self.SELF, None, title=self.Title, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=24, VVVt3G=VVVt3G, VVq3zo=VVq3zo, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVCNiH=VV9Ea0, VVIhEb=VV9Ea0, VV9Ea0=VV9Ea0, VV0HYK="#11ffffff", VVZozG="#00004455", VVsrIN="#0a282828")
  else:
   self.VVWyxg("No valid bouquets in:\n\n%s" % self.filePath)
 def VVXx8g(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VVGs9C(self, VVl7Cx, title, txt, colList):
  mSel = CCEd9P(self.SELF, VVl7Cx)
  if VVl7Cx.VVUCzo:
   totSel = VVl7Cx.VVmvz4()
   if totSel: VVwSHr = [("Import %s Bouquet%s" % (FFNkac(str(totSel), VV80BT), FFEOCn(totSel)), "imp")]
   else  : VVwSHr = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FFNkac(bName, VV80BT)
   VVwSHr = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FFqXEj, VVl7Cx, BF(CC70ak.VVQGIe, self.SELF, VVl7Cx, self.filePath))}
  mSel.VV5TZ4(VVwSHr, cbFncDict)
 def VVBcuH(self, VVl7Cx, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CC70ak.VVxPsW(self.filePath, "lamedb")
   if err:
    self.VVWyxg(err)
    return
   dbServLst = CCKtc8.VVeylW(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totLoc, totMrk, totBnb, fName = VVl7Cx.VVRTTA()
   lines, err = CC70ak.VVxPsW(self.filePath, os.path.basename(fName))
   if err:
    self.VVWyxg(err)
    return
   VVmJ2p = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVmJ2p.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVmJ2p.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVmJ2p.append((span.group(1).strip() or "-", "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVmJ2p.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVmJ2p.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CCKtc8.VVVyY3(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVmJ2p.append((name.strip() or "-", FFfCA9(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVmJ2p):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CC70ak.VVxPsW(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVmJ2p[ndx] = (bName, descr)
   if VVmJ2p:
    VV9Ea0 = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VVe5VU = (LEFT  , CENTER)
    FFyLgY(self.SELF, None, title="Services in : %s" % bName, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=28, VVCNiH=VV9Ea0, VVIhEb=VV9Ea0, VV9Ea0=VV9Ea0, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FFMYB5(VVl7Cx, err, 1500)
  else : VVl7Cx.VVTKmx()
 def VV6PKm(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VVWyxg("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VV6J2i(var):
   return str(var) if var else VVNUkq + str(var)
  totItem = VVSqFX + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VVHKA4   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVXaO9, "Sub-B."
  else  : bColor, totBnb = ""      , VV6J2i(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VV6J2i(totDVB), VV6J2i(totIptv), VV6J2i(totLoc), VV6J2i(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VVQGIe(SELF, VVl7Cx, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVslLY + "bouquets.tv"
  radBouquetFile = VVslLY + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FFXl6w(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FFXl6w(SELF, radBouquetFile, title=title)
   return
  isMulti = VVl7Cx.VVUCzo
  if isMulti : rows = VVl7Cx.VVQwmL()
  else  : rows = [VVl7Cx.VVRTTA()]
  for num, bName, bMode, totItem, totDVB, totIptv, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FFAvZA(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FFGlcE(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FFGlcE(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVslLY + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVslLY + newFile
    CC70ak.VVpWd5(archPath, fName, VVslLY, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   CCCBMo.VVsHDO(tvBouquetFile)
   CCCBMo.VVsHDO(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CC70ak.VVoT82(SELF, archPath, bList)
   FFjpsW()
  txt  = FFNkac("Added:\n", VVXaO9)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FFNkac("Imported to lamedab:\n", VVXaO9)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FFNkac("Missing from archived lamedb:\n", VVHKA4)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FFheEQ(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVoT82(SELF, archPath, bList):
  VVNxww, err = CCKtc8.VV6HVq(SELF, VVKx0m=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CCKtc8.VVTGMh(VVNxww, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FF7up6(VVslLY + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CCKtc8.VVVyY3(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CCKtc8.VVf7vV(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CC70ak.VV1qOh(archPath, dbName)
   CC70ak.VVpWd5(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CCKtc8.VVTGMh(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CCKtc8.VVTGMh(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CCKtc8.VVTGMh(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CCKtc8.VVTGMh(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFblrr(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VVNxww + ".tmp"
   lines   = FF7up6(VVNxww)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   os.system(FFlWZ0("mv -f '%s' '%s'" % (tmpDbFile, VVNxww)))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VVMqof(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VV1qOh(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVpWd5(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VVxPsW(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CC5116(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFheJw(VVXQaf, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVwSHr = []
  VVwSHr.append(("Plugins Browser List"       , "VVkfl0"   ))
  VVwSHr.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVwSHr.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Download/Install Packages (from image feeds)" , "downloadInstallPackages"  ))
  VVwSHr.append(("Remove Packages (show all)"     , "VV6VuDsAll"   ))
  VVwSHr.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Update List of Available Packages"   , "VVdJLg"   ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Packaging Tool"        , "VVgUuK"    ))
  VVwSHr.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFqVmU(self, VVwSHr=VVwSHr)
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  FFpkQc(self["myMenu"])
  FFQGfp(self)
 def VVmBrJ(self):
  global VVLQSn
  VVLQSn = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVkfl0"   : self.VVkfl0()
   elif item == "pluginsMenus"     : self.VVu61Q(0)
   elif item == "pluginsStartup"    : self.VVu61Q(1)
   elif item == "pluginsDirList"    : self.VVLcp5()
   elif item == "downloadInstallPackages"  : FFqXEj(self, BF(self.VVZHuI, 0, ""))
   elif item == "VV6VuDsAll"   : FFqXEj(self, BF(self.VVZHuI, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFqXEj(self, BF(self.VVZHuI, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVdJLg"   : self.VVdJLg()
   elif item == "VVgUuK"    : self.VVgUuK()
   elif item == "packagesFeeds"    : self.VVoGeF()
   else          : self.close()
 def VVLcp5(self):
  extDirs  = FFoQ29(VVKPve)
  sysDirs  = FFoQ29(VVGc43)
  VVd40u  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVd40u.append((item, VVKPve + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVd40u.append((item, VVGc43 + item))
  if VVd40u:
   VVd40u.sort(key=lambda x: x[0].lower())
   VVq3zo = ("Package Info.", self.VVhi7P, [])
   VVrIQY = ("Open in File Manager", BF(self.VVciZd, 1), [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFyLgY(self, None, header=header, VVd40u=VVd40u, VVLpvM=widths, VV2ql8=28, VVq3zo=VVq3zo, VVrIQY=VVrIQY)
  else:
   FFAvZA(self, "Nothing found!")
 def VVhi7P(self, VVl7Cx, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVKPve) : loc = "extensions"
  elif path.startswith(VVGc43) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVvAdc(package)
  else:
   FFAvZA(self, "No info!")
 def VVoGeF(self):
  pkg = FFGwKB()
  if pkg : FFGC8R(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FF0QO3(self)
 def VVkfl0(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVQesM(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVStMY + "\n"
    txt += VVQesM("Number"   , str(c))
    txt += VVQesM("Name"   , FFNkac(str(p.name), VVSqFX))
    txt += VVQesM("Path"  , p.path  )
    txt += VVQesM("Description" , p.description )
    txt += VVQesM("Icon"  , p.iconstr  )
    txt += VVQesM("Wakeup Fnc" , p.wakeupfnc )
    txt += VVQesM("NeedsRestart", p.needsRestart)
    txt += VVQesM("Internal" , p.internal )
    txt += VVQesM("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFheEQ(self, txt)
 def VVu61Q(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVd40u = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVd40u.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVd40u:
   VVd40u.sort(key=lambda x: x[0].lower())
   VVrIQY = ("Open in File Manager", BF(self.VVciZd, 4), [])
   header   = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths   = (19  , 25 , 20  , 27   , 9  )
   FFyLgY(self, None, title=title, header=header, VVd40u=VVd40u, VVLpvM=widths, VV2ql8=26, VVrIQY=VVrIQY)
  else:
   FFAvZA(self, "Nothing Found", title=title)
 def VVciZd(self, pathColNum, VVl7Cx, title, txt, colList):
  path = colList[pathColNum].strip()
  if pathExists(path) : self.session.open(CCeH84, mode=CCeH84.VVvR6q, VVXtjq=path)
  else    : FFMYB5(VVl7Cx, "Path not found !", 1500)
 def VVdJLg(self):
  cmd = FFeJzm(VVNE2g, "")
  if cmd : FFCHwU(self, cmd, checkNetAccess=True)
  else : FF0QO3(self)
 def VVgUuK(self):
  pkg = FFGwKB()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FF6b7h(self, txt)
 def VVZHuI(self, mode, grep, VVl7Cx=None, title=""):
  if   mode == 0: cmd = FFeJzm(VVadVa    , grep)
  elif mode == 1: cmd = FFeJzm(VVT5Tj , grep)
  elif mode == 2: cmd = FFeJzm(VVT5Tj , grep)
  if not cmd:
   FF0QO3(self)
   return
  VVmJ2p = FFIsyt(cmd)
  if not VVmJ2p:
   if VVl7Cx: VVl7Cx.VVTKmx()
   FFAvZA(self, "No packages found!")
   return
  elif len(VVmJ2p) == 1 and VVmJ2p[0] == VVQZPP:
   FFAvZA(self, VVQZPP)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVd40u  = []
  for item in VVmJ2p:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVd40u.append((name, package, version))
  if mode > 0:
   extensions = FFIsyt("ls %s -l | grep '^d' | awk '{print $9}'" % VVKPve)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVd40u:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVd40u.append((name, VVKPve + item, "-"))
   systemPlugins = FFIsyt("ls %s -l | grep '^d' | awk '{print $9}'" % VVGc43)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVd40u:
      if item.lower() == row[0].lower():
       break
     else:
      VVd40u.append((item, VVGc43 + item, "-"))
  if not VVd40u:
   FFAvZA(self, "No packages found!")
   return
  if VVl7Cx:
   VVd40u.sort(key=lambda x: x[0].lower())
   VVl7Cx.VVfoGr(VVd40u, title)
  else:
   widths = (20, 50, 30)
   VVcZtS = None
   VVrIQY = None
   if mode == 0:
    VVlNkE = ("Install" , self.VVj6pV   , [])
    VVcZtS = ("Download" , self.VVSjo2   , [])
    VVrIQY = ("Filter"  , self.VVFNL1 , [])
   elif mode == 1:
    VVlNkE = ("Uninstall", self.VV6VuD, [])
   elif mode == 2:
    VVlNkE = ("Uninstall", self.VV6VuD, [])
    widths= (18, 57, 25)
   VVd40u.sort(key=lambda x: x[0].lower())
   VVq3zo = ("Package Info.", self.VVaFNA, [])
   header   = ("Name" ,"Package" , "Version" )
   FFyLgY(self, None, header=header, VVd40u=VVd40u, VVLpvM=widths, VV2ql8=28, VVlNkE=VVlNkE, VVcZtS=VVcZtS, VVq3zo=VVq3zo, VVrIQY=VVrIQY, VVBEEG=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVCNiH="#22110011", VVIhEb="#22191111", VV9Ea0="#22191111", VVZozG="#00003030", VVsrIN="#00333333")
 def VVaFNA(self, VVl7Cx, title, txt, colList):
  package = colList[1]
  self.VVvAdc(package)
 def VVFNL1(self, VVl7Cx, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVwSHr = []
  VVwSHr.append(("All Packages", "all"))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVwSHr.append(VVbzyo)
  for word in words:
   VVwSHr.append((word, word))
  FFKX6p(self, BF(self.VV7bsa, VVl7Cx), VVwSHr=VVwSHr, title="Select Filter")
 def VV7bsa(self, VVl7Cx, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFqXEj(VVl7Cx, BF(self.VVZHuI, 0, grep, VVl7Cx, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VV6VuD(self, VVl7Cx, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVKPve, VVGc43)):
   FFOjga(self, BF(self.VVhSZ3, VVl7Cx, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVwSHr = []
   VVwSHr.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVwSHr.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVwSHr.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFKX6p(self, BF(self.VVrpwH, VVl7Cx, package), VVwSHr=VVwSHr)
 def VVhSZ3(self, VVl7Cx, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVp7GH)
  FFCHwU(self, cmd, VVFApn=BF(self.VVaLAE, VVl7Cx))
 def VVrpwH(self, VVl7Cx, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVhiem
   elif item == "remove_ForceRemove"  : cmdOpt = VVbRax
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVFY8T
   FFOjga(self, BF(self.VVjPTI, VVl7Cx, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVjPTI(self, VVl7Cx, package, cmdOpt):
  self.lastSelectedRow = VVl7Cx.VVf913()
  cmd = FFtNvi(cmdOpt, package)
  if cmd : FFCHwU(self, cmd, VVFApn=BF(self.VVaLAE, VVl7Cx))
  else : FF0QO3(self)
 def VVaLAE(self, VVl7Cx):
  VVl7Cx.cancel()
  FFI36Q()
 def VVj6pV(self, VVl7Cx, title, txt, colList):
  package  = colList[1]
  VVwSHr = []
  VVwSHr.append(("Install Package"         , "install_CheckVersion" ))
  VVwSHr.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVwSHr.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VVwSHr.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVwSHr.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFKX6p(self, BF(self.VVrGKw, package), VVwSHr=VVwSHr)
 def VVrGKw(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVJBI8
   elif item == "install_ForceReinstall" : cmdOpt = VVUj18
   elif item == "install_ForceOverwrite" : cmdOpt = VV2M4Y
   elif item == "install_ForceDowngrade" : cmdOpt = VVFbVd
   elif item == "install_IgnoreDepends" : cmdOpt = VVhG5k
   FFOjga(self, BF(self.VVoBXO, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVoBXO(self, package, cmdOpt):
  cmd = FFtNvi(cmdOpt, package)
  if cmd : FFCHwU(self, cmd, VVFApn=FFI36Q, checkNetAccess=True)
  else : FF0QO3(self)
 def VVSjo2(self, VVl7Cx, title, txt, colList):
  package  = colList[1]
  FFOjga(self, BF(self.VVYe24, package), "Download Package ?\n\n%s" % package)
 def VVYe24(self, package):
  if FF9q7B():
   cmd = FFtNvi(VV9nnc, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFw6UZ(success, VV80BT))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFw6UZ(fail, VV0rNQ))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFCHwU(self, cmd, VVHvPK=[VV0rNQ, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FF0QO3(self)
  else:
   FFAvZA(self, "No internet connection !")
 def VVvAdc(self, package):
  infoCmd  = FFtNvi(VVfQeQ, package)
  filesCmd = FFtNvi(VVcV6O, package)
  listInstCmd = FFeJzm(VVT5Tj, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFoIr5(VVSqFX)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFw6UZ(notInst, VVHKA4))
   cmd += "else "
   cmd +=   FFN8GC("System Info", VVSqFX)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFN8GC("Related Files", VVSqFX)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FF7AMX(self, cmd)
  else:
   FF0QO3(self)
class CCwlDM():
 def VVbB1U(self, isRef):
  self.shareIsRef   = isRef
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VVR7Lm()
 def VVR7Lm(self):
  files = FFLuBK(VVhL6f, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVwSHr = []
   for fil in files:
    VVwSHr.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVCNiH, VVIhEb = "#22221133", "#22221133"
   else    : VVCNiH, VVIhEb = "#22003344", "#22002233"
   VV7qf7  = ("Add new File", self.VVjlqC)
   VVoZDD = ("Delete File", self.VVSlfo)
   FFKX6p(self, self.VVEY9E, VVwSHr=VVwSHr, width=1100, VV7qf7=VV7qf7, VVoZDD=VVoZDD, minRows=4, VVCNiH=VVCNiH, VVIhEb=VVIhEb)
  else:
   FFOjga(self, self.VVfvKv, "No files found.\n\nCreate a new file ?")
 def VVfvKv(self):
  path = self.VVURxC()
  if fileExists(path) : self.VVR7Lm()
  else    : FFMYB5(self, "Cannot create file", 1500)
 def VVjlqC(self, menuInstance, path):
  path = self.VVURxC()
  menuInstance.VV0FMl((os.path.basename(path), path), isSort=True)
 def VVURxC(self):
  path = "%s%s%s.xml" % (VVhL6f, self.shareFilePrefix, FFLFgj())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VVSlfo(self, menuInstance, path):
  FFOjga(self, BF(self.VVHsyB, menuInstance, path), "Delete this file ?\n\n%s" % path)
 def VVHsyB(self, menuInstance, path):
  FFblrr(path)
  if fileExists(path) : FFMYB5(menuInstance, "Not deleted", 1000)
  else    : menuInstance.VVPjeT()
 def VVEY9E(self, path=None):
  if path:
   FFqXEj(self, BF(self.VVRLrl, path))
 def VVRLrl(self, path):
  if not fileExists(path):
   FFXl6w(self, path)
   return
  elif not CCeH84.VVnVuy(self, path, FFNk49()):
   return
  else:
   self.shareFilePath = path
  if not CC5OGS.VV8lQd(self):
   return
  tree = CCKtc8.VVfgxW(self, self.shareFilePath)
  if not tree:
   return
  refLst = CCCBMo.VVxivD()
  def VVQesM(refCode):
   if   FFarkl(refCode): return FFNkac("DVB", VV4YPU)
   elif refCode in refLst     : return FFNkac("IPTV", VV4YPU)
   else         : return ""
  VVmJ2p= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VV3Rfx(ch)
   if ok:
    srcTxt = VVQesM(srcRef)
    dstTxt = VVQesM(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVmJ2p:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVmJ2p.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVmJ2p:
   if self.shareIsRef : VVCNiH, VVIhEb, optTxt = "#22221133", "#22221133", "Share Reference"
   else    : VVCNiH, VVIhEb, optTxt = "#1a003344", "#1a002233", "Copy EPG/PIcons"
   VV3zZz = (""    , BF(self.VVTN1N, dupl), [])
   VV0QzM = (""    , self.VVtXg4    , [])
   VVlNkE = ("Delete Entry" , self.VV619n   , [])
   VVcZtS = ("Add Entry"  , self.VVeJRq   , [])
   VVq3zo = (optTxt   , self.VV4KJ2  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VVe5VU = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVl7Cx = FFyLgY(self, None, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=24, VV3zZz=VV3zZz, VV0QzM=VV0QzM, VVlNkE=VVlNkE, VVcZtS=VVcZtS, VVq3zo=VVq3zo, VV1YOp=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVCNiH=VVCNiH, VVIhEb=VVIhEb, VV9Ea0=VVIhEb, VV0HYK="#00ffffaa", VVZozG="#0a000000")
  else:
   FFAvZA(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VVTN1N(self, dupl, VVl7Cx, title, txt, colList):
  if dupl:
   VVl7Cx.VVguPD("Skipped %d duplicate%s" % (dupl, FFEOCn(dupl)), 2000)
 def VVtXg4(self, VVl7Cx, title, txt, colList):
  def VVQesM(key, val): return "%s\t: %s\n" % (key, val or FFNkac("?", VVmIAH))
  Keys = VVl7Cx.VVEoLZ()
  Vals = VVl7Cx.VVRTTA()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VVQesM(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VV80BT, VVmIAH
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FFheEQ(self, txt + txt1, title=title)
 def VV3Rfx(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VV619n(self, VVl7Cx, title, txt, colList):
  if VVl7Cx.VVf913() == 0 and VVl7Cx.VVm6b9() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FFOjga(self, BF(self.VVzYnV, isLast, VVl7Cx), ques)
 def VVzYnV(self, isLast, VVl7Cx):
  if isLast:
   FFblrr(self.shareFilePath)
   VVl7Cx.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVl7Cx.VVRTTA()
   if self.VVgd7E(srcName, srcRef, dstName, dstRef):
    VVl7Cx.VVu68F()
    VVl7Cx.VVu8Ft()
    FFMYB5(VVl7Cx, "Deleted", 500, isGrn=True)
   else:
    FFMYB5(VVl7Cx, "Cannot delete from file", 2000)
 def VVeJRq(self, VVl7Cx, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VVvQYE(VVl7Cx, isDvb=True)
  else    : self.VVUwZy(VVl7Cx, "Source Channel", "#22003344", "#22002233")
 def VVUwZy(self, mainTableInst, title, VVCNiH, VVIhEb):
  FFKX6p(self, BF(self.VVaePH, mainTableInst, title), VVwSHr=[("DVB", "DVB"), ("IPTV", "IPTV")], title=title + " Type", width=800, VVCNiH=VVCNiH, VVIhEb=VVIhEb)
 def VVaePH(self, mainTableInst, title, item=None):
  if item:
   FFqXEj(mainTableInst, BF(self.VVmRKq, mainTableInst, title, item), clearMsg=False)
 def VVmRKq(self, mainTableInst, title, item):
  FFMYB5(mainTableInst)
  if item == "DVB": self.VVvQYE(mainTableInst, isDvb=True)
  else   : self.VVvQYE(mainTableInst, isDvb=False)
 def VVrcJc(self, mainTableInst, chType, VVl7Cx, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVl7Cx.VVf913()
  if   chType == "DVB" : FFGxwH(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FFGxwH(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVBOVP()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FFAvZA(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VVwBc6(srcName, srcRef, dstName, dstRef):
      mainTableInst.VVSGdt((str(mainTableInst.VVm6b9() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FFMYB5(mainTableInst, "Added", 500, isGrn=True)
     else:
      FFMYB5(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FFMYB5(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VVvQYE(mainTableInst, isDvb=False)
   else    : FFuqQK(BF(self.VVUwZy, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVl7Cx.cancel()
 def VVm035(self, item, VVl7Cx, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVl7Cx.VVm16r(ndx)
 def VVvQYE(self, VVl7Cx, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VVrcJc, VVl7Cx, typ)
  doneFnc = BF(self.VVm035, typ)
  if isDvb: CCwlDM.VVmxZr(VVl7Cx , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CCwlDM.VVquGQ(VVl7Cx, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VVmxZr(SELF, title, okFnc, doneFnc=None):
  FFqXEj(SELF, BF(CCwlDM.VV9VmK, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VV9VmK(SELF, title, okFnc, doneFnc=None):
  VVmJ2p, err = CCKtc8.VVwRJt(SELF, CCKtc8.VVRx2u)
  if VVmJ2p:
   color = "#0a000022"
   VVmJ2p.sort(key=lambda x: x[0].lower())
   VVVt3G = ("Select" , okFnc, [])
   VV3zZz= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VVe5VU = (LEFT  , LEFT  , CENTER, LEFT    )
   FFyLgY(SELF, None, title=title, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVCNiH=color, VVIhEb=color, VV9Ea0=color, VVVt3G=VVVt3G, VV3zZz=VV3zZz, lastFindConfigObj=CFG.lastFindServices)
  else:
   FFAvZA(SELF, "No DVB Services !")
 @staticmethod
 def VVquGQ(SELF, title, okFnc, doneFnc=None):
  FFqXEj(SELF, BF(CCwlDM.VVbu8V, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VVbu8V(SELF, title, okFnc, doneFnc=None):
  VVmJ2p = CCwlDM.VVtOS7()
  if VVmJ2p:
   color = "#0a112211"
   VVmJ2p.sort(key=lambda x: x[0].lower())
   VVVt3G = ("Select" , okFnc, [])
   VV3zZz= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FFyLgY(SELF, None, title=title, header=header, VVd40u=VVmJ2p, VVLpvM=widths, VV2ql8=26, VVCNiH=color, VVIhEb=color, VV9Ea0=color, VVVt3G=VVVt3G, VV3zZz=VV3zZz, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFAvZA(SELF, "No IPTV Services !")
 @staticmethod
 def VVtOS7():
  VVmJ2p = []
  files  = CCaayN.VVHIur()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFa594(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VV10Wd = span.group(1)
    else : VV10Wd = ""
    VV10Wd_lCase = VV10Wd.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVmJ2p.append((chName, VV10Wd, url, refCode))
  return VVmJ2p
 def VVwBc6(self, srcName, srcRef, dstName, dstRef):
  tree = CCKtc8.VVfgxW(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VVjhca(tree, root)
  return True
 def VVgd7E(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CCKtc8.VVfgxW(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VV3Rfx(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VVjhca(tree, root)
  return found
 def VVjhca(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CCKtc8.VVmQi8(xmlTxt)
  parser = CCKtc8.CCWR8K()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VV4KJ2(self, VVl7Cx, title, txt, colList):
  VVwSHr = []
  if self.shareIsRef:
   FFOjga(self, BF(FFqXEj, VVl7Cx, BF(self.VVsohw, VVl7Cx)), "Copy all References from Source to Destination ?")
  else:
   VVwSHr.append(("Copy EPG\t (All List)" , "epg"  ))
   VVwSHr.append(("Copy Picons\t (All List)" , "picon" ))
   FFKX6p(self, BF(self.VVXoly, VVl7Cx), VVwSHr=VVwSHr, width=1000)
 def VVXoly(self, VVl7Cx, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VV1auo  , "EPG"
   elif item == "picon": fnc, txt = self.VVwQ4Q , "PIcons"
   title = "Copy %s" % txt
   tot   = VVl7Cx.VVm6b9()
   FFOjga(self, BF(FFqXEj, VVl7Cx, BF(fnc, VVl7Cx, title)), "Overwrite %s for %d Service%s ?" % (FFNkac(txt, VVSqFX), tot, FFEOCn(tot)), title=title)
 def VVsohw(self, VVl7Cx):
  files = CCaayN.VVHIur()
  totChange = 0
  if files:
   for path in files:
    txt = FFa594(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVl7Cx.VVBOVP():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFjpsW()
  tot = VVl7Cx.VVm6b9()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FFheEQ(self, txt)
 def VVwQ4Q(self, VVl7Cx, title):
  if not iCopyfile:
   FFAvZA(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CCVrfy.VVNV04()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVl7Cx.VVBOVP():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVl7Cx.VVm6b9()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FFheEQ(self, txt, title=title)
 def VV1auo(self, VVl7Cx, title):
  from enigma import eEPGCache
  totFound = totEvents = totSuccess = totInvalid = 0
  epgInst = eEPGCache.getInstance()
  if not epgInst:
   FFAvZA(self, "Cannot access EPG Cache !", title=title)
   return
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVl7Cx.VVBOVP():
   if remark == "0":
    evList = epgInst.lookupEvent(["BDTSE", (srcRef, 0, -1, 20160)])
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CCnfxp.VVHist(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CCwlDM.VVQqzH()
  txt  = "Services\t: %d\n"  % VVl7Cx.VVm6b9()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  FFheEQ(self, txt, title=title)
 class CCWR8K(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VVfgxW(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CCKtc8.CCWR8K())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FFNkac("XML Parse Error in:", VVmIAH), path)
   txt += "%s\n%s\n\n" % (FFNkac("Error:", VVmIAH), str(e))
   FFheEQ(SELF, txt, VV9Ea0="#11220000", title=title)
   return None
 @staticmethod
 def VVmQi8(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
 @staticmethod
 def VVQqzH():
  try:
   from enigma import eEPGCache
   epgInst = eEPGCache.getInstance()
   if epgInst and hasattr(eEPGCache, "save"):
    epgInst.save()
  except:
   pass
class CCKtc8(Screen, CCwlDM):
 VVSsh9  = 0
 VVbkss = 1
 VV242z  = 2
 VV2CQY  = 3
 VVATCv = 4
 VVlGns = 5
 VVp1YJ = 6
 VVRx2u   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FFheJw(VVXQaf, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VV0YgN = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVwSHr = self.VV9kNe()
  FFqVmU(self, VVwSHr=VVwSHr, title="Services/Channels")
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self["myMenu"].setList(self.VV9kNe())
  FFpkQc(self["myMenu"])
  FFQGfp(self)
 def VV9kNe(self):
  VVwSHr = []
  c = VV4YPU
  VVwSHr.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVwSHr.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVwSHr.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVwSHr.append(VVbzyo)
  c = VVXaO9
  VVwSHr.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVwSHr.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVwSHr.append((VVmIAH + "More tables ..."     , "VVLtO4"    ))
  c = VVtjbM
  VVwSHr.append(VVbzyo)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVwSHr.append((c + txt          , "VV5nEP"  ))
  else : VVwSHr.append((txt           ,          ))
  VVwSHr.append((c + 'Export Services to "channels.xml"'    , "VVyXbN"      ))
  VVwSHr.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VVhTQL
  VVwSHr.append(VVbzyo)
  VVwSHr.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVwSHr.append((c + "Invalid Services Cleaner"       , "VVcGJs"    ))
  c = VVhTQL
  VVwSHr.append(VVbzyo)
  VVwSHr.append((c + "Delete Channels with no names"     , "VViA8H"    ))
  VVwSHr.append((c + "Delete Empty Bouquets"       , "VVIMVV"     ))
  VVwSHr.append(VVbzyo)
  VVNxww, VVBBkW = CCKtc8.VVdWKU()
  if fileExists(VVNxww):
   enab = fileExists(VVBBkW)
   if enab: VVwSHr.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVwSHr.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVwSHr.append(("Reset Parental Control Settings"      , "VVBYAA"    ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Reload Channels and Bouquets"       , "VVHX0d"      ))
  return VVwSHr
 def VVmBrJ(self):
  global VVLQSn
  VVLQSn = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCcojD.VVEI1u(self.session)
   elif item == "openSignal"       : FF3UUy(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFQTAA(self, fncMode=CCnfxp.VVUzCH)
   elif item == "lameDB_allChannels_with_refCode"  : FFqXEj(self, self.VVawor)
   elif item == "lameDB_allChannels_with_tranaponder" : FFqXEj(self, self.VVFzCJ)
   elif item == "VVLtO4"     : self.VVLtO4()
   elif item == "VV5nEP"  : CC70ak.VV5nEP(self)
   elif item == "VVyXbN"      : self.VVyXbN()
   elif item == "copyEpgPicons"      : self.VVbB1U(False)
   elif item == "SatellitesCleaner"     : FFqXEj(self, self.FFqXEj_SatellitesCleaner)
   elif item == "VVcGJs"    : FFqXEj(self, BF(self.VVcGJs))
   elif item == "VViA8H"    : FFqXEj(self, self.VViA8H)
   elif item == "VVIMVV"     : self.VVIMVV(self)
   elif item == "enableHiddenChannels"     : self.VV3OTn(True)
   elif item == "disableHiddenChannels"    : self.VV3OTn(False)
   elif item == "VVBYAA"    : FFOjga(self, self.VVBYAA, "Reset and Restart ?")
   elif item == "VVHX0d"      : FFqXEj(self, BF(CCKtc8.VVHX0d, self))
 def VVLtO4(self):
  VVwSHr = []
  VVwSHr.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVwSHr.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVwSHr.append(("Services with PIcons for the System"  , "VVCKdb"     ))
  VVwSHr.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVwSHr.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"     ))
  FFKX6p(self, self.VVDr8z, VVwSHr=VVwSHr, title="Service Information", VVto4D=True)
 def VVDr8z(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FFqXEj(self, BF(self.VVuMVB, title))
   elif ref == "parentalControlChannels"   : FFqXEj(self, BF(self.VVhqBt, title))
   elif ref == "showHiddenChannels"    : FFqXEj(self, BF(self.VVymAd, title))
   elif ref == "VVCKdb"    : FFqXEj(self, BF(self.VVkdud, title))
   elif ref == "servicesWithMissingPIcons"   : FFqXEj(self, BF(self.VVxqvb, title))
   elif ref == "TranspondersStats"     : FFqXEj(self, BF(self.VV53PL, title))
   elif ref == "SatellitesXmlStats"    : FFqXEj(self, BF(self.VVSjK2, title))
 def VVyXbN(self):
  VVwSHr = []
  VVwSHr.append(("All DVB-S/C/T Services", "all"))
  VVwSHr.extend(CCCBMo.VV1eYH())
  FFKX6p(self, self.VVveIq, VVwSHr=VVwSHr, title="", VVto4D=True)
 def VVveIq(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCKtc8.VVsGi1("1:7:")
   else   : lst = FFyIuW(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFfCA9(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFNWS8(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FFThW1(CFG.exportedTablesPath.getValue()), FFLFgj())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FF6b7h(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFMYB5(self, "No Services found !", 1500)
 @staticmethod
 def VVHX0d(SELF):
  FFjpsW()
  FF6b7h(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVawor(self):
  self.VV0YgN = None
  self.lastfilterUsed  = None
  self.filterObj   = CC6QfU(self)
  VVmJ2p, err = CCKtc8.VVwRJt(self, self.VVSsh9)
  if VVmJ2p:
   VVmJ2p.sort(key=lambda x: x[0].lower())
   VVVt3G  = ("Zap"   , self.VVJ2Re     , [])
   VV0QzM = (""    , self.VVJgrZ   , [])
   VVq3zo = ("Options"  , self.VV7tYC , [])
   VVcZtS = ("Current Service", self.VVQn5n , [])
   VVrIQY = ("Filter"   , self.VVsQvM  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVe5VU  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFyLgY(self, None, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVVt3G=VVVt3G, VV0QzM=VV0QzM, VVcZtS=VVcZtS, VVq3zo=VVq3zo, VVrIQY=VVrIQY, lastFindConfigObj=CFG.lastFindServices)
 def VVFzCJ(self):
  self.VV0YgN = None
  self.lastfilterUsed  = None
  self.filterObj   = CC6QfU(self)
  VVmJ2p, err = CCKtc8.VVwRJt(self, self.VVbkss)
  if VVmJ2p:
   VVmJ2p.sort(key=lambda x: x[0].lower())
   VVVt3G  = ("Zap"   , self.VVJ2Re      , [])
   VV0QzM = (""    , self.VVJgrZ    , [])
   VVcZtS = ("Current Service", self.VVQn5n  , [])
   VVq3zo = ("Options"  , self.VVBZun , [])
   VVrIQY = ("Filter"   , self.VV2NKe  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVe5VU  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFyLgY(self, None, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVVt3G=VVVt3G, VV0QzM=VV0QzM, VVcZtS=VVcZtS, VVq3zo=VVq3zo, VVrIQY=VVrIQY, lastFindConfigObj=CFG.lastFindServices)
 def VV7tYC(self, VVl7Cx, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CCEd9P(self, VVl7Cx)
  VVwSHr = []
  isMulti = VVl7Cx.VVUCzo
  if isMulti:
   refCodeList = VVl7Cx.VVwG2k(3)
   if refCodeList:
    VVwSHr.append(("Add Selection to Parental Control"    , "parentalControl_sel_add"  ))
    VVwSHr.append(("Remove Selection from Parental Control"   , "parentalControl_sel_remove" ))
    VVwSHr.append(VVbzyo)
    VVwSHr.append(("Add Selection to Hidden Services"    , "hiddenServices_sel_add"  ))
    VVwSHr.append(("Remove Selection from Hidden Services"   , "hiddenServices_sel_remove" ))
    VVwSHr.append(VVbzyo)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVwSHr.append((txt1, "parentalControl_add" ))
    VVwSHr.append((txt2,       ))
   else:
    VVwSHr.append((txt1,       ))
    VVwSHr.append((txt2, "parentalControl_remove"))
   VVwSHr.append(VVbzyo)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVwSHr.append((txt1, "hiddenServices_add" ))
    VVwSHr.append((txt2,       ))
   else:
    VVwSHr.append((txt1,       ))
    VVwSHr.append((txt2, "hiddenServices_remove" ))
   VVwSHr.append(VVbzyo)
  cbFncDict = { "parentalControl_add"   : BF(self.VVgKrm, VVl7Cx, refCode, True)
     , "parentalControl_remove"  : BF(self.VVgKrm, VVl7Cx, refCode, False)
     , "hiddenServices_add"   : BF(self.VV5xye, VVl7Cx, refCode, True)
     , "hiddenServices_remove"  : BF(self.VV5xye, VVl7Cx, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVqbze, VVl7Cx, True)
     , "parentalControl_sel_remove" : BF(self.VVqbze, VVl7Cx, False)
     , "hiddenServices_sel_add"  : BF(self.VVEvVP, VVl7Cx, True)
     , "hiddenServices_sel_remove" : BF(self.VVEvVP, VVl7Cx, False)
     }
  VVwSHr1, cbFncDict1 = CCKtc8.VV7R7I(self, VVl7Cx, servName, 3)
  VVwSHr.extend(VVwSHr1)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VV5TZ4(VVwSHr, cbFncDict)
 def VVBZun(self, VVl7Cx, title, txt, colList):
  servName = colList[0]
  mSel = CCEd9P(self, VVl7Cx)
  VVwSHr, cbFncDict = CCKtc8.VV7R7I(self, VVl7Cx, servName, 3)
  mSel.VV5TZ4(VVwSHr, cbFncDict)
 @staticmethod
 def VV7R7I(SELF, VVl7Cx, servName, refCodeCol):
  tot = VVl7Cx.VVmvz4()
  if tot > 0:
   sTxt = FFNkac("%d Service%s" % (tot, FFEOCn(tot)), VVXaO9)
   VVwSHr = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FFGlcE(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FFNkac(servName, VVXaO9)
   VVwSHr = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CCKtc8.VVfAtF, SELF, VVl7Cx, refCodeCol, True)
     , "addToBouquet_one" : BF(CCKtc8.VVfAtF, SELF, VVl7Cx, refCodeCol, False)
     }
  return VVwSHr, cbFncDict
 @staticmethod
 def VVfAtF(SELF, VVl7Cx, refCodeCol, isMulti):
  picker = CCCBMo(SELF, VVl7Cx, "Add to Bouquet", BF(CCKtc8.VVxAYF, VVl7Cx, refCodeCol, isMulti))
 @staticmethod
 def VVxAYF(VVl7Cx, refCodeCol, isMulti):
  if isMulti : refCodeList = VVl7Cx.VVwG2k(refCodeCol)
  else  : refCodeList = [VVl7Cx.VVRTTA()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VVgKrm(self, VVl7Cx, refCode, isAddToBlackList):
  VVl7Cx.VV07Vz("Processing ...")
  FFuqQK(BF(self.VVKC69, VVl7Cx, [refCode], isAddToBlackList))
 def VVqbze(self, VVl7Cx, isAddToBlackList):
  refCodeList = VVl7Cx.VVwG2k(3)
  if not refCodeList:
   FFAvZA(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVl7Cx.VV07Vz("Processing ...")
  FFuqQK(BF(self.VVKC69, VVl7Cx, refCodeList, isAddToBlackList))
 def VVKC69(self, VVl7Cx, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVh8e9, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVh8e9):
   lines = FF7up6(VVh8e9)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVh8e9, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVl7Cx.VVUCzo
   if isMulti:
    self.VV89fR(VVl7Cx, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVwbeu(VVl7Cx, refCode)
    VVl7Cx.VVTKmx()
  else:
   VVl7Cx.VVguPD("No changes")
 def VV5xye(self, VVl7Cx, refCode, isHide):
  title = "Change Hidden State"
  if FFarkl(refCode):
   VVl7Cx.VV07Vz("Processing ...")
   ret = FFxJPq(refCode, isHide)
   if ret : FFqXEj(self, BF(self.VVwbeu, VVl7Cx, refCode))
   else : FFAvZA(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFAvZA(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVwbeu(self, VVl7Cx, refCode):
  VVmJ2p, err = CCKtc8.VVwRJt(self, self.VVSsh9, VVKekW=[3, [refCode], False])
  done = False
  if VVmJ2p:
   data = VVmJ2p[0]
   if data[3] == refCode:
    done = VVl7Cx.VV3N4D(data)
  if not done:
   self.VVYFgT(VVl7Cx, VVl7Cx.VVWhqJ(), self.VVSsh9)
  VVl7Cx.VVTKmx()
 def VV89fR(self, VVl7Cx, totRefCodes):
  VVmJ2p, err = CCKtc8.VVwRJt(self, self.VVSsh9, VVKekW=self.VV0YgN)
  VVl7Cx.VVfoGr(VVmJ2p)
  VVl7Cx.VVDfQL(False)
  VVl7Cx.VVguPD("%d Processed" % totRefCodes)
 def VVEvVP(self, VVl7Cx, isHide):
  refCodeList = VVl7Cx.VVwG2k(3)
  if not refCodeList:
   FFAvZA(self, "Nothing selected", title="Change Hidden State")
   return
  VVl7Cx.VV07Vz("Processing ...")
  FFuqQK(BF(self.VVJu8t, VVl7Cx, refCodeList, isHide))
 def VVJu8t(self, VVl7Cx, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFxJPq(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFjpsW(True)
   self.VV89fR(VVl7Cx, len(refCodeList))
  else:
   VVl7Cx.VVguPD("No changes")
 def VVsQvM(self, VVl7Cx, title, txt, colList):
  inFilterFnc = BF(self.VVZIHE, VVl7Cx) if self.VV0YgN else None
  self.filterObj.VVPWEf(1, VVl7Cx, 2, BF(self.VVKFpK, VVl7Cx), inFilterFnc=inFilterFnc)
 def VVKFpK(self, VVl7Cx, item):
  self.VV7HeP(VVl7Cx, False, item, 2, self.VVSsh9)
 def VVZIHE(self, VVl7Cx, menuInstance, item):
  self.VV7HeP(VVl7Cx, True, item, 2, self.VVSsh9)
 def VV2NKe(self, VVl7Cx, title, txt, colList):
  inFilterFnc = BF(self.VVezlX, VVl7Cx) if self.VV0YgN else None
  self.filterObj.VVPWEf(2, VVl7Cx, 4, BF(self.VViMAq, VVl7Cx), inFilterFnc=inFilterFnc)
 def VViMAq(self, VVl7Cx, item):
  self.VV7HeP(VVl7Cx, False, item, 4, self.VVbkss)
 def VVezlX(self, VVl7Cx, menuInstance, item):
  self.VV7HeP(VVl7Cx, True, item, 4, self.VVbkss)
 def VVLOfk(self, VVl7Cx, title, txt, colList):
  inFilterFnc = BF(self.VV8fen, VVl7Cx) if self.VV0YgN else None
  self.filterObj.VVPWEf(0, VVl7Cx, 4, BF(self.VV3nnJ, VVl7Cx), inFilterFnc=inFilterFnc)
 def VV3nnJ(self, VVl7Cx, item):
  self.VV7HeP(VVl7Cx, False, item, 4, self.VV242z)
 def VV8fen(self, VVl7Cx, menuInstance, item):
  self.VV7HeP(VVl7Cx, True, item, 4, self.VV242z)
 def VV7HeP(self, VVl7Cx, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVl7Cx.VVboCB(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VV0YgN = None
  else:
   words, asPrefix = CC6QfU.VVfYn9(words)
   self.VV0YgN = [col, words, asPrefix]
  if words: FFqXEj(VVl7Cx, BF(self.VVYFgT, VVl7Cx, title, mode), clearMsg=False)
  else : FFMYB5(VVl7Cx, "Incorrect filter", 2000)
 def VVYFgT(self, VVl7Cx, title, mode):
  VVmJ2p, err = CCKtc8.VVwRJt(self, mode, VVKekW=self.VV0YgN, VVajqq=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVl7Cx.VVBOVP():
    try:
     ndx = VVmJ2p.index(tuple(list(map(str.strip, row))))
     lst.append(VVmJ2p[ndx])
    except:
     pass
   VVmJ2p = lst
  if VVmJ2p:
   VVmJ2p.sort(key=lambda x: x[0].lower())
   VVl7Cx.VVfoGr(VVmJ2p, title)
  else:
   FFMYB5(VVl7Cx, "Not found!", 1500)
 def VVPNAb(self, title, VVd40u, VVVt3G=None, VV0QzM=None, VVlNkE=None, VVcZtS=None, VVq3zo=None, VVrIQY=None):
  VVcZtS = ("Current Service", self.VVQn5n, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVe5VU = (LEFT  , LEFT  , CENTER, LEFT    )
  FFyLgY(self, None, title=title, header=header, VVd40u=VVd40u, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVVt3G=VVVt3G, VV0QzM=VV0QzM, VVlNkE=VVlNkE, VVcZtS=VVcZtS, VVq3zo=VVq3zo, VVrIQY=VVrIQY, lastFindConfigObj=CFG.lastFindServices)
 def VVQn5n(self, VVl7Cx, title, txt, colList):
  self.VVbNjL(VVl7Cx)
 def VVsQMN(self, VVl7Cx, title, txt, colList):
  self.VVbNjL(VVl7Cx, True)
 def VVbNjL(self, VVl7Cx, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVl7Cx.VVzboj(colDict, VViqYq=True)
   else:
    VVl7Cx.VVjNJH(3, refCode, True)
   return
  FFAvZA(self, "Colud not read current Reference Code !")
 def VVuMVB(self, title):
  self.VV0YgN = None
  self.lastfilterUsed  = None
  self.filterObj   = CC6QfU(self)
  VVmJ2p, err = CCKtc8.VVwRJt(self, self.VV242z)
  if VVmJ2p:
   VVmJ2p.sort(key=lambda x: x[0].lower())
   VV0QzM = (""    , self.VVncPU , []      )
   VVcZtS = ("Current Service", self.VVsQMN  , []      )
   VVrIQY = ("Filter"   , self.VVLOfk   , [], "Loading Filters ..." )
   VVVt3G  = ("Zap"   , self.VVQZwJ      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVe5VU  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFyLgY(self, None, title=title, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVVt3G=VVVt3G, VV0QzM=VV0QzM, VVcZtS=VVcZtS, VVrIQY=VVrIQY, lastFindConfigObj=CFG.lastFindServices)
 def VVncPU(self, VVl7Cx, title, txt, colList):
  refCode  = self.VV0vFC(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFQTAA(self, fncMode=CCnfxp.VVaJmG, refCode=refCode, chName=chName, text=txt)
 def VVQZwJ(self, VVl7Cx, title, txt, colList):
  refCode = self.VV0vFC(colList)
  FFf8Q6(self, refCode)
 def VVJ2Re(self, VVl7Cx, title, txt, colList):
  FFf8Q6(self, colList[3])
 def VV0vFC(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVTGMh(VVNxww, mode=0):
  lines = FF7up6(VVNxww, encLst=["UTF-8"])
  return CCKtc8.VVeylW(lines, mode)
 @staticmethod
 def VVeylW(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VVwRJt(SELF, mode, VVKekW=None, VVajqq=True, VVKx0m=True):
  VVNxww, err = CCKtc8.VV6HVq(SELF, VVKx0m)
  if err:
   return None, err
  asPrefix = False
  if VVKekW:
   filterCol = VVKekW[0]
   filterWords = VVKekW[1]
   asPrefix = VVKekW[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCKtc8.VVSsh9:
   blackList = None
   if fileExists(VVh8e9):
    blackList = FF7up6(VVh8e9)
    if blackList:
     blackList = set(blackList)
  elif mode == CCKtc8.VVbkss:
   tp = CCpEt4()
  VVwBvo, VV9WSF = FFXZbX()
  if mode in (CCKtc8.VVlGns, CCKtc8.VVp1YJ):
   VVmJ2p = {}
  else:
   VVmJ2p = []
  tagFound = False
  with ioOpen(VVNxww, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFqpI8(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCKtc8.VV242z:
       if sTypeInt in VVwBvo:
        STYPE = VV9WSF[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVmJ2p.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVmJ2p.append(tRow)
       else:
        VVmJ2p.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCKtc8.VVRx2u:
        VVmJ2p.append((chName, chProv, sat, refCode))
       elif mode == CCKtc8.VVlGns:
        VVmJ2p[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCKtc8.VVp1YJ:
        VVmJ2p[chName] = refCode
       elif mode == CCKtc8.VVSsh9:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVmJ2p.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVmJ2p.append(tRow)
        else:
         VVmJ2p.append(tRow)
       elif mode == CCKtc8.VVbkss:
        if sTypeInt in VVwBvo:
         STYPE = VV9WSF[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVn847(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVmJ2p.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVmJ2p.append(tRow)
        else:
         VVmJ2p.append(tRow)
       elif mode == CCKtc8.VV2CQY:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVmJ2p.append((chName, chProv, sat, refCode))
       elif mode == CCKtc8.VVATCv:
        VVmJ2p.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVmJ2p and VVajqq:
   FFAvZA(SELF, "No services found!")
  return VVmJ2p, ""
 def VVhqBt(self, title):
  if fileExists(VVh8e9):
   lines = FF7up6(VVh8e9)
   if lines:
    newRows = []
    VVmJ2p, err = CCKtc8.VVwRJt(self, self.VVATCv)
    if VVmJ2p:
     lines = set(lines)
     for item in VVmJ2p:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVmJ2p = newRows
      VVmJ2p.sort(key=lambda x: x[0].lower())
      VV0QzM = ("", self.VVJgrZ, [])
      VVVt3G = ("Zap", self.VVJ2Re, [])
      self.VVPNAb(title, VVmJ2p, VVVt3G=VVVt3G, VV0QzM=VV0QzM)
     else:
      FFheEQ(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVmJ2p)))
   else:
    FF6b7h(self, "No active Parental Control services.", FFNk49())
  else:
   FFXl6w(self, VVh8e9)
 def VVymAd(self, title):
  VVmJ2p, err = CCKtc8.VVwRJt(self, self.VV2CQY)
  if VVmJ2p:
   VVmJ2p.sort(key=lambda x: x[0].lower())
   VV0QzM = ("" , self.VVJgrZ, [])
   VVVt3G  = ("Zap", self.VVJ2Re, [])
   self.VVPNAb(title, VVmJ2p, VVVt3G=VVVt3G, VV0QzM=VV0QzM)
  elif err:
   pass
  else:
   FF6b7h(self, "No hidden services.", FFNk49())
 def VVcGJs(self):
  title = "Services unused in Tuner Configuration"
  VVNxww, err = CCKtc8.VV6HVq(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CCKtc8.VVr0h3()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VV0n85(str(item[0]))
    nsLst.add(ns)
  sysLst = CCKtc8.VVsGi1("1:7:")
  tpLst  = CCKtc8.VVTGMh(VVNxww, mode=1)
  VVmJ2p = []
  for refCode, chName in sysLst:
   servID = CCKtc8.VVVyY3(refCode)
   tpID = CCKtc8.VVf7vV(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVmJ2p.append((chName, FFfCA9(refCode, False), refCode, servID))
  if VVmJ2p:
   VVmJ2p.sort(key=lambda x: x[0].lower())
   VVq3zo = ("Options"   , BF(self.VVtL8H, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VVe5VU  = (LEFT  , CENTER , LEFT   , CENTER   )
   FFyLgY(self, None, title=title, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVq3zo=VVq3zo, VVCNiH="#0a001122", VVIhEb="#0a001122", VV9Ea0="#0a001122", VVZozG="#00004455", VVsrIN="#0a333333", VVn0US="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FF6b7h(self, "No invalid service found !", title=title)
 def VVtL8H(self, Title, VVl7Cx, title, txt, colList):
  mSel = CCEd9P(self, VVl7Cx)
  isMulti = VVl7Cx.VVUCzo
  if isMulti : txt = "Remove %s Services" % FFNkac(str(VVl7Cx.VVmvz4()), VVmIAH)
  else  : txt = "Remove : %s" % FFNkac(VVl7Cx.VVRTTA()[0], VVmIAH)
  VVwSHr = [(txt, "del")]
  cbFncDict = {"del": BF(FFqXEj, VVl7Cx, BF(self.VVpzsM, VVl7Cx, Title))}
  mSel.VV5TZ4(VVwSHr, cbFncDict)
 def VVpzsM(self, VVl7Cx, title):
  VVNxww, err = CCKtc8.VV6HVq(self, title=title)
  if err:
   return
  isMulti = VVl7Cx.VVUCzo
  skipLst = []
  if isMulti : skipLst = VVl7Cx.VVwG2k(3)
  else  : skipLst = [VVl7Cx.VVRTTA()[3]]
  tpLst = CCKtc8.VVTGMh(VVNxww, mode=0)
  servLst = CCKtc8.VVTGMh(VVNxww, mode=10)
  tmpDbFile = VVNxww + ".tmp"
  lines   = FF7up6(VVNxww)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  os.system(FFlWZ0("mv -f '%s' '%s'" % (tmpDbFile, VVNxww)))
  VVmJ2p = []
  for row in VVl7Cx.VVBOVP():
   if not row[3] in skipLst:
    VVmJ2p.append(row)
  FFjpsW()
  FFheEQ(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVmJ2p:
   VVl7Cx.VVfoGr(VVmJ2p, title)
   VVl7Cx.VVDfQL(False)
  else:
   VVl7Cx.cancel()
 def VV53PL(self, title):
  VVNxww, err = CCKtc8.VV6HVq(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VVYtd0(VVNxww)
  txt = FFNkac("Total Transponders:\n\n", VVHJRy)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFNkac("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVHJRy)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFF1NR(item), satList.count(item))
  FFheEQ(self, txt, title)
 def VVYtd0(self, VVNxww):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVNxww, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVSjK2(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFXl6w(self, path, title=title)
   return
  elif not CCeH84.VVnVuy(self, path, title):
   return
  if not CC5OGS.VV8lQd(self):
   return
  tree = CCKtc8.VVfgxW(self, path, title=title)
  if not tree:
   return
  VVmJ2p = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FFqpI8(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVmJ2p.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVmJ2p:
   VVmJ2p.sort(key=lambda x: int(x[1]))
   VVcZtS = ("Current Satellite", BF(self.VVKqVo, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VVe5VU  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FFyLgY(self, None, title=title, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=25, VVkbOA=1, VVcZtS=VVcZtS, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFAvZA(self, "No data found !", title=title)
 def VVKqVo(self, satCol, VVl7Cx, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self)
  sat = FFfCA9(refCode, False)
  for ndx, row in enumerate(VVl7Cx.VVBOVP()):
   if sat == row[satCol].strip():
    VVl7Cx.VVm16r(ndx)
    break
  else:
   FFMYB5(VVl7Cx, "No listed !", 1500)
 def FFqXEj_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FFAvZA(self, "No Satellites found !")
   return
  usedSats = CCKtc8.VVr0h3()
  VVmJ2p = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVmJ2p.append((sat[1], posTxt, FFqpI8(sat[0]), tuners, str(posVal)))
  if VVmJ2p:
   VV9Ea0 = "#11222222"
   VVmJ2p.sort(key=lambda x: int(x[1]))
   VVcZtS = ("Current Satellite" , BF(self.VVKqVo, 2) , [])
   VVq3zo = ("Options"   , self.VVIYh3  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VVe5VU  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FFyLgY(self, None, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=28, VVcZtS=VVcZtS, VVq3zo=VVq3zo, VVCNiH=VV9Ea0, VVIhEb=VV9Ea0, VV9Ea0=VV9Ea0, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFAvZA(self, "No data found !")
 def VVIYh3(self, VVl7Cx, title, txt, colList):
  mSel = CCEd9P(self, VVl7Cx)
  isMulti = VVl7Cx.VVUCzo
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FFNkac(str(VVl7Cx.VVmvz4()), VVmIAH)
  else  : txt = "Remove ALL Services on : %s" % FFNkac(VVl7Cx.VVRTTA()[0], VVmIAH)
  VVwSHr = []
  VVwSHr.append((txt, "deleteSat"))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Delete Empty Bouquets", "VVIMVV"))
  cbFncDict = { "deleteSat"   : BF(FFqXEj, VVl7Cx, BF(self.VVw6br, VVl7Cx))
     , "VVIMVV" : BF(self.VVIMVV, VVl7Cx)
     }
  mSel.VV5TZ4(VVwSHr, cbFncDict)
 def VVw6br(self, VVl7Cx):
  posLst = []
  isMulti = VVl7Cx.VVUCzo
  posLst = []
  if isMulti : posLst = VVl7Cx.VVwG2k(4)
  else  : posLst = [VVl7Cx.VVRTTA()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VV0n85(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VVgriv(nsLst)
  FFjpsW(True)
  FFheEQ(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VVIMVV(self, winObj):
  title = "Delete Empty Bouquets"
  FFOjga(self, BF(FFqXEj, winObj, BF(self.VVe3qm, title)), "Delete bouquets with no services ?", title=title)
 def VVe3qm(self, title):
  bList = CCCBMo.VVK4Z1()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CCCBMo.VVEbUz(bRef)
    bPath = VVslLY + bFile
    FFblrr(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVslLY + fil
     if fileExists(path):
      lines = FF7up6(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFjpsW(True)
  if bNames: txt = "%s\n\n%s" % (FFNkac("Deleted Bouquets:", VVXaO9), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FFheEQ(self, txt, title=title)
 def VV0n85(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VVgriv(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVslLY)
  for srcF in files:
   if fileExists(srcF):
    lines = FF7up6(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFDZ6V(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VVkdud(self, title)   : self.VVCKdb(title, True)
 def VVxqvb(self, title) : self.VVCKdb(title, False)
 def VVCKdb(self, title, isWithPIcons):
  piconsPath = CCVrfy.VVNV04()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCVrfy.VVrCgj(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVmJ2p, err = CCKtc8.VVwRJt(self, self.VVATCv)
    if VVmJ2p:
     channels = []
     for (chName, chProv, sat, refCode) in VVmJ2p:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFg7kC(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVmJ2p)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVQesM(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVQesM("PIcons Path"  , piconsPath)
     txt += VVQesM("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVQesM("Total services" , totalServices)
     txt += VVQesM("With PIcons"  , totalWithPIcons)
     txt += VVQesM("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFheEQ(self, txt)
     else:
      VV0QzM     = (""      , self.VVJgrZ , [])
      if isWithPIcons : VVrIQY = ("Export Current PIcon", self.VVzqQa  , [])
      else   : VVrIQY = None
      VVq3zo     = ("Statistics", FFheEQ, [txt])
      VVVt3G      = ("Zap", self.VVJ2Re, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVPNAb(title, channels, VVVt3G=VVVt3G, VV0QzM=VV0QzM, VVq3zo=VVq3zo, VVrIQY=VVrIQY)
   else:
    FFAvZA(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFAvZA(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVJgrZ(self, VVl7Cx, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFQTAA(self, fncMode=CCnfxp.VVaJmG, refCode=refCode, chName=chName, text=txt)
 def VVzqQa(self, VVl7Cx, title, txt, colList):
  png, path = CCVrfy.VVDael(colList[3], colList[0])
  if path:
   CCVrfy.VVg41j(self, png, path)
 @staticmethod
 def VVdWKU():
  VVNxww  = "%slamedb" % VVslLY
  VVBBkW = "%slamedb.disabled" % VVslLY
  return VVNxww, VVBBkW
 @staticmethod
 def VVZdgR():
  VVYCHr  = "%slamedb5" % VVslLY
  VV5hi2 = "%slamedb5.disabled" % VVslLY
  return VVYCHr, VV5hi2
 def VV3OTn(self, isEnable):
  VVNxww, VVBBkW = CCKtc8.VVdWKU()
  if isEnable and not fileExists(VVBBkW):
   FF6b7h(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVNxww):
   FFAvZA(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFOjga(self, BF(self.VVGDPz, isEnable), "%s Hidden Channels ?" % word)
 def VVGDPz(self, isEnable):
  VVNxww , VVBBkW = CCKtc8.VVdWKU()
  VVYCHr, VV5hi2 = CCKtc8.VVZdgR()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVBBkW, VVBBkW, VVNxww)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VV5hi2, VV5hi2, VVYCHr)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (VVNxww  , VVNxww , VVBBkW)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (VVYCHr , VVYCHr, VV5hi2)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVBBkW, VVNxww )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VV5hi2, VVYCHr)
  res = os.system(cmd)
  FFjpsW()
  if res == 0 : FF6b7h(self, "Hidden List %s" % word)
  else  : FFAvZA(self, "Error while restoring:\n\n%s" % fileName)
 def VVBYAA(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %ssettings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVslLY
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %ssettings" % VVslLY
  FFi3Gr(self, cmd)
 def VViA8H(self):
  VVNxww, err = CCKtc8.VV6HVq(self)
  if err:
   return
  tmpFile = "/tmp/ajpanel_lamedb"
  FFblrr(tmpFile)
  totChan = totRemoved = 0
  lines = FF7up6(VVNxww, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FFOjga(self, BF(FFqXEj, self, BF(self.VVKDm5, tmpFile, VVNxww, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FFEOCn(totRemoved), totChan, FFEOCn(totChan))
      , callBack_No=BF(self.VVmRth, tmpFile))
  else:
   FFheEQ(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVKDm5(self, tmpFile, VVNxww, totRemoved, totChan):
  os.system(FFlWZ0("mv -f '%s' '%s'" % (tmpFile, VVNxww)))
  FFjpsW()
  FFheEQ(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VVmRth(self, tmpFile):
  FFblrr(tmpFile)
 @staticmethod
 def VV6HVq(SELF, VVKx0m=True, title=""):
  VVNxww, VVBBkW = CCKtc8.VVdWKU()
  if   not fileExists(VVNxww)       : err = "File not found !\n\n%s" % VVNxww
  elif not CCeH84.VVnVuy(SELF, VVNxww) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VVKx0m:
   FFAvZA(SELF, err, title=title)
  return VVNxww, err
 @staticmethod
 def VVf7vV(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VVVyY3(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VVsGi1(servTypes):
  VVFnSu  = eServiceCenter.getInstance()
  VVT7ir   = '%s ORDER BY name' % servTypes
  VVttQK   = eServiceReference(VVT7ir)
  VVZtvq = VVFnSu.list(VVttQK)
  if VVZtvq: return VVZtvq.getContent("CN", False)
  else     : return []
 @staticmethod
 def VVr0h3():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CCnfxp(Screen):
 VVUzCH  = 0
 VVwxyw   = 1
 VVnHwO   = 2
 VVaJmG    = 3
 VV40Xm    = 4
 VVHO2a   = 5
 VV7OJJ   = 6
 VVbsHW    = 7
 VVAR6g   = 8
 VVwR5T   = 9
 VVvSJc   = 10
 VVGouR   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFheJw(VVQhck, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVUzCH)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFNkac("%s\n", VVNUkq) % VVStMY
  self.picViewer  = None
  FFqVmU(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVCrjU })
  self["myPicF"]  = Label()
  self["myPicB"]  = Label()
  self["myPic"]  = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVevf4)
  self.onClose.append(self.onExit)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  self["myLabel"].VV3oQu(outputFileToSave="chann_info")
  if   self.fncMode == self.VVUzCH : fnc = self.VVP3xh
  elif self.fncMode == self.VVwxyw  : fnc = self.VVP3xh
  elif self.fncMode == self.VVnHwO  : fnc = self.VVP3xh
  elif self.fncMode == self.VVaJmG  : fnc = self.VVwevP
  elif self.fncMode == self.VV40Xm  : fnc = self.VVvysy
  elif self.fncMode == self.VVHO2a  : fnc = self.VVg3Hi
  elif self.fncMode == self.VV7OJJ  : fnc = self.VVSUgc
  elif self.fncMode == self.VVbsHW  : fnc = self.VVGiyG
  elif self.fncMode == self.VVAR6g  : fnc = self.VVdlPh
  elif self.fncMode == self.VVwR5T : fnc = self.VVoA8d
  elif self.fncMode == self.VVvSJc  : fnc = self.VV9vlu
  elif self.fncMode == self.VVGouR : fnc = self.VVw79q
  self["myLabel"].setText("\n   Reading Info ...")
  FFuqQK(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VV3ETZ()
 def VVhaHy(self, err):
  self["myLabel"].setText(err)
  FFAMY6(self["myTitle"], "#22200000")
  FFAMY6(self["myBody"], "#22200000")
  self["myLabel"].VVK2CA("#22200000")
  self["myLabel"].VVy5sP()
 def VVP3xh(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self)
  self.refCode = refCode
  self.VVh1Gc(chName)
 def VVwevP(self):
  self.VVh1Gc(self.chName)
 def VVvysy(self):
  self.VVh1Gc(self.chName)
 def VVg3Hi(self):
  self.VVh1Gc(self.chName)
 def VVSUgc(self):
  self.VVh1Gc("Picon Info")
 def VVGiyG(self):
  self.VVh1Gc(self.chName)
 def VVdlPh(self):
  self.VVh1Gc(self.chName)
 def VVoA8d(self):
  self.VVh1Gc(self.chName)
 def VV9vlu(self):
  self.chUrl = self.refCode + self.callingSELF.VVFrmH(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVh1Gc(self.chName)
 def VVw79q(self):
  self.VVh1Gc(self.chName)
 def VVh1Gc(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFbgUV(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VV8OVe(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFNkac(self.VVKpe7(tUrl), VVcK7G)
  if not self.epg:
   epg = self.VVbuoc(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVYkVa(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCVrfy.VVDael(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVYkVa(path)
  self.VVIVwS()
  self.VVSDcJ()
  self["myLabel"].setText(self.text or "   No active service", VVDaM8=VVM50Z)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVy5sP(minHeight=minH)
 def VVSDcJ(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFNWS8(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVKFp3(FFPduo(url))
  if epg:
   self.text += "\n" + FFYH2Y("EPG:", VVXaO9) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVIVwS()
 def VVIVwS(self):
  if not self.piconShown and self.picUrl:
   path, err = FF8zMR(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVYkVa(path)
    if self.piconShown and self.refCode:
     self.VVqdjh(path, self.refCode)
 def VVqdjh(self, path, refCode):
  if path and fileExists(path) and os.system(FFlWZ0("which ffmpeg")) == 0:
   pPath = CCVrfy.VVNV04()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CCnfxp.VVxhyv(path)
    cmd += FFlWZ0("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVYkVa(self, path):
  if path and fileExists(path):
   err, w, h = self.VVoH9C(path)
   if not err:
    if h > w:
     self.VVg1Nd(self["myPicF"], w, h, True)
     self.VVg1Nd(self["myPicB"], w, h, False)
     self.VVg1Nd(self["myPic"] , w, h, False)
   self.picViewer = CCZBdY.VVLSHJ(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VVg1Nd(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVoH9C(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFnz9X(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VV8OVe(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFNkac(chName, VVXaO9)
  txt += self.VVQesM(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFNkac(state, VVHKA4)
   txt += "State\t: %s\n" % state
  w = FFCNz5(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFCNz5(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVEyP4(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVQesM(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVQesM(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVQesM(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVa57i()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVaEuW()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCnfxp.VVGHgl(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFNkac("IPTV", VVHJRy)
   txt += self.VVma0h(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVC7fL(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCpEt4()
    tpTxt, namespace = tp.VVqRJd(refCode)
    if tpTxt:
     txt += FFNkac("Tuner:\n", VVXaO9)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFNkac("Codes:\n", VVXaO9)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVQesM(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVQesM(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVQesM(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVQesM(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVQesM(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVQesM(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVQesM(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVQesM(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVQesM(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVEyP4(info):
  if info:
   aspect = FFCNz5(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVQesM(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFCNz5(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVldXs(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVldXs(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVa57i(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VVaEuW(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVC7fL(self, refCode, iptvRef, chName):
  refCode = FF2ErX(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFa594(VVslLY + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFa594(VVslLY + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VVd40u = []
  tmpRefCode = FFPduo(refCode)
  for item in fList:
   path = VVslLY + item
   if fileExists(path):
    txt = FFa594(path)
    if tmpRefCode in FFPduo(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVd40u.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VVd40u:
   if len(VVd40u) == 1:
    txt += "%s\t: %s%s\n" % (FFNkac("Bouquet", VVXaO9), VVd40u[0][0], " (%s)" % VVd40u[0][1] if VVpo5P else "")
   else:
    txt += FFNkac("Bouquets:\n", VVXaO9)
    for ndx, item in enumerate(VVd40u):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVpo5P else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVbuoc(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVqeM0(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVqeM0(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVqeM0(event, 0)
     except:
      pass
  return epg
 def VVqeM0(self, event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCnfxp.VVURvq(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = CCnfxp.VVEGxt(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FFNkac(evName, VVXaO9)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FFNkac(evNameTransl, VVXaO9))
    if evTime           : txt += "Start Time\t: %s\n" % FFLaSW(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFLaSW(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFQjGS(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFQjGS(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFQjGS(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFNkac(evShort, VVtjbM)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFNkac(evDesc , VVtjbM)
    if txt:
     txt = FFNkac("\n%s\n%s Event:\n%s\n" % (VVStMY, ("Current", "Next")[evNum], VVStMY), VVXaO9) + txt
  return txt
 def VVma0h(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFuK1e(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCcf6M()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV1sn4(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFNkac("URL:", VVHJRy) + "\n%s\n" % self.VVKpe7(decodedUrl)
  else:
   txt = "\n"
   txt += FFNkac("Reference:", VVHJRy) + "\n%s\n" % refCode
  return txt
 def VVKpe7(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVdBoH:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").replace("%3A", ":").strip()
 def VVKFp3(self, decodedUrl):
  if not FF9q7B():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCaayN.VVBGRU(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCaayN.VVokhy(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVl3YL(tDict)
   elif uType == "movie" : epg, picUrl = CCnfxp.VVc46z(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVl3YL(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCaayN.VV6hiq(item, "title"    , is_base64=True )
     lang    = CCaayN.VV6hiq(item, "lang"         ).upper()
     description   = CCaayN.VV6hiq(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCaayN.VV6hiq(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCaayN.VV6hiq(item, "start_timestamp"      )
     stop_timestamp  = CCaayN.VV6hiq(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCaayN.VV6hiq(item, "stop_timestamp"       )
     now_playing   = CCaayN.VV6hiq(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VV1R4z, ""
      else     : color, txt = VVHKA4 , "    (CURRENT EVENT)"
      epg += FFNkac("_" * 32 + "\n", VVNUkq)
      epg += FFNkac("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFNkac(description, VVcK7G)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVHist(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVc46z(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCaayN.VV6hiq(item, "movie_image" )
    genre  = CCaayN.VV6hiq(item, "genre"   ) or "-"
    plot  = CCaayN.VV6hiq(item, "plot"   ) or "-"
    cast  = CCaayN.VV6hiq(item, "cast"   ) or "-"
    rating  = CCaayN.VV6hiq(item, "rating"   ) or "-"
    director = CCaayN.VV6hiq(item, "director"  ) or "-"
    releasedate = CCaayN.VV6hiq(item, "releasedate" ) or "-"
    duration = CCaayN.VV6hiq(item, "duration"  ) or "-"
    try:
     lang = CCaayN.VV6hiq(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFNkac(cast, VVcK7G)
    epg += "Plot:\n%s"    % FFNkac(CCnfxp.VVEGxt(plot), VVcK7G)
   except:
    pass
  return epg, movie_image
 @staticmethod
 def VVEGxt(evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = CCnfxp.VVS7E3(evTxt, lang)
   return CCnfxp.VVa576(txt).strip() or evTxt
 def VVCrjU(self):
  if VVdBoH:
   def VVQesM(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVQesM(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCcf6M()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV1sn4(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVQesM(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (VVStMY, txt))
   FFMYB5(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVa576(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VV20OD(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   try:
    from enigma import eEPGCache
    eCache = eEPGCache.getInstance()
    if eCache:
     event = eCache.lookupEventTime(serv, -1, 0)
     if event: return CCnfxp.VVURvq(event)
   except:
    pass
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event: return CCnfxp.VVURvq(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVURvq(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCnfxp.VV8pvx(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVqonL(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   try:
    from enigma import eEPGCache
    eCache = eEPGCache.getInstance()
    if eCache:
     for evNum in range(2):
      event = eCache.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CCnfxp.VVURvq(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FFLaSW(evTime)
       evEndTxt  = FFLaSW(evEnd)
       evDurTxt  = FFQjGS(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FFQjGS(evPos)
        evRem = evEnd - now
        evRemTxt = FFQjGS(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FFQjGS(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VVS7E3(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFC3CV(txt))
   txt, err = CCaayN.VVokhy(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFPduo(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVHist(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VVg8Nl(SELF):
  if not CCXk4n.VV9Kgc(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(SELF)
  err = url =  fSize = resumable = ""
  if FF3iML(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCcf6M.VVOmqb(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCcf6M.VVReea(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFAvZA(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCeH84.VVpYrc(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFNkac(" (M3U/M3U8 File)", VVcK7G)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCEgwO.VVdDAR(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VV6J2i(subj, val):
   return "%s\n%s\n\n" % (FFNkac("%s:" % subj, VVXaO9), val)
  title = "File Size"
  txt  = VV6J2i(title , fSize or "?")
  txt += VV6J2i("Name" , chName)
  txt += VV6J2i("URL" , url)
  if resumable: txt += VV6J2i("Supports Download-Resume", resumable)
  if err  : txt += FFNkac("Error:\n", VVHKA4) + err
  FFheEQ(SELF, txt, title=title)
 @staticmethod
 def VVGHgl(SELF):
  fPath, fDir, fName = CCeH84.VVYryR(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VV8pvx(event):
  genre = PR = ""
  try:
   genre  = CCnfxp.VVXumZ(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCnfxp.VVDv2c(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVDv2c(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVXumZ(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCnfxp.VVzbR2()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVzbR2():
  path = VVdSQY + "genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFa594(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFa594(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVxhyv(path):
  return "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
 @staticmethod
 def VV36by(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CCVrfy.VVNV04() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VVgF5Q(serv):
  isLocal = isIptv = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if FFNWS8(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFDZ6V(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCcf6M():
 def __init__(self):
  self.VVAWkd   = ""
  self.VVsRGc    = ""
  self.VVEAvm   = ""
  self.VVqScn = ""
  self.VVIDZT  = ""
  self.VV36m6 = 0
  self.VVpxBy    = ""
  self.VVeit9   = "#f#11ffffaa#User"
  self.VVEgWB   = "#f#11aaffff#Server"
 def VVskzm(self, url, mac, ph1="", VViqYq=True):
  self.VVAWkd   = ""
  self.VVsRGc    = ""
  self.VVEAvm   = ""
  self.VVqScn = ""
  self.VVIDZT  = ""
  self.VV36m6 = 0
  self.VVpxBy    = {"s": "/server/load.php", "p": "/portal.php"}.get(ph1, "")
  host = self.VVfNc3(url)
  if not host:
   if VViqYq:
    self.VVWyxg("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VV3fef(mac)
  if not host:
   if VViqYq:
    self.VVWyxg("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVAWkd = host
  self.VVsRGc  = mac
  return True
 def VVfNc3(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VV3fef(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVebjv(self):
  res, err = self.VVV79X(self.VVCfjS())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VVAWkd:
   self.VVAWkd = self.VVAWkd.replace(urlPath, "")
   res, err = self.VVV79X(self.VVCfjS())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCaayN.VV6hiq(tDict["js"], "token")
    rand  = CCaayN.VV6hiq(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VV3GzM(self, VViqYq=True):
  if not self.VVpxBy:
   self.VVpxBy = self.VVKebR()
  err = blkMsg = FF6b7hTxt = ""
  try:
   token, rand, err = self.VVebjv()
   if token:
    self.VVEAvm = token
    self.VVqScn = rand
    if rand:
     self.VV36m6 = 2
    prof, retTxt = self.VVDHTS(True)
    if prof:
     self.VVIDZT = retTxt
     if "device_id mismatch" in retTxt:
      self.VV36m6 = 3
      prof, retTxt = self.VVDHTS(False)
      if retTxt:
       self.VVIDZT = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FF6b7hTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FF6b7hTxt: tErr += "\n%s" % FF6b7hTxt
  if VViqYq:
   self.VVWyxg(tErr)
  return "", "", tErr
 def VVKebR(self):
  try:
   import requests
   res = requests.get("%s/c/xpcom.common.js" % self.VVAWkd, headers=CCcf6M.VVReea(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       return span.group(1)
  except:
   pass
  return ""
 def VVDHTS(self, capMac):
  res, err = self.VVV79X(self.VVUSMM(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCaayN.VV6hiq(tDict["js"], "block_%s" % word)
    FF6b7hTxt = CCaayN.VV6hiq(tDict["js"], word)
    return tDict, FF6b7hTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVUSMM(self, capMac):
  param = ""
  if self.VVIDZT or self.VVqScn:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVsRGc.upper() if capMac else self.VVsRGc.lower(), self.VVqScn))
  return self.VVSsjn() + "type=stb&action=get_profile" + param
 exec(FFHuvq("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gID0gIiZhdXRoX3NlY29uZF9zdGVwPTEmaHdfdmVyc2lvbj0yLjE3LUlCLTAwJmh3X3ZlcnNpb25fMj02MiZzbj0lcyZkZXZpY2VfaWQ9JXMmZGV2aWNlX2lkMj0lcyZzaWduYXR1cmU9JXMiICUgKElkWzBdLCBJZFsxXSwgSWRbMV0sIElkWzJdKQ0KIHJldHVybiBwYXJhbSArICcmbWV0cmljcz17Im1hYyI6IiVzIiwic24iOiIlcyIsInR5cGUiOiJTVEIiLCJtb2RlbCI6Ik1BRzI1MCIsInJhbmRvbSI6IiVzIn0nICUgKElkWzNdLCBJZFswXSwgSWRbNF0pDQpkZWYgZ2V0TW9yZUF1dGhfSURzKHNlbGYsIG0sIHIpOg0KIGltcG9ydCBoYXNobGliDQogbWFjVXRmOCA9IG0uZW5jb2RlKCd1dGYtOCcpDQogcyA9IGhhc2hsaWIubWQ1KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKClbOjEzXQ0KIHJldHVybiBzLCBoYXNobGliLnNoYTI1NihtYWNVdGY4KS5oZXhkaWdlc3QoKS51cHBlcigpLCBoYXNobGliLnNoYTI1NigocyArIG0pLmVuY29kZSgndXRmLTgnKSkuaGV4ZGlnZXN0KCkudXBwZXIoKSwgbSwgcg=="))
 def VVM8cS(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VV5AOp()
  if len(rows) < 10:
   rows = self.VVsOfR()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVAWkd ))
   rows.append(("MAC (from URL)" , self.VVsRGc ))
   rows.append(("Token"   , self.VVEAvm ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVeit9  , "MAC" , self.VVsRGc ))
   rows.append(("2", self.VVEgWB, "Host" , self.VVAWkd ))
   rows.append(("2", self.VVEgWB, "Token" , self.VVEAvm ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVTZin(self, isPhp=True, VViqYq=False):
  token, profile, tErr = self.VV3GzM(VViqYq)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VV6kxh()
  res, err = self.VVV79X(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCaayN.VV6hiq(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFC3CV(span.group(2))
     pass1 = FFC3CV(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VV5AOp(self):
  m3u_Url, host, user1, pass1, err = self.VVTZin()
  rows = []
  if m3u_Url:
   res, err = self.VVV79X(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFLaSW(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVeit9, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFLaSW(int(val))
      else      : val = str(val)
      rows.append(("2", self.VVEgWB, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVsOfR(self):
  token, profile, tErr = self.VV3GzM()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFdGBV(val): val = FFHuvq(val.decode("UTF-8"))
     else     : val = self.VVsRGc
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFLaSW(int(parts[1]))
      if parts[2] : ends = FFLaSW(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFLaSW(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVFrmH(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VV3GzM(VViqYq=False)
  if not token:
   return ""
  crLinkUrl = self.VV3aOB(mode, chCm, epNum, epId)
  res, err = self.VVV79X(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCaayN.VV6hiq(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVSsjn(self):
  return self.VVAWkd + (self.VVpxBy or "/server/load.php") + "?"
 def VVCfjS(self):
  return self.VVSsjn() + "type=stb&action=handshake&token=&mac=%s" % self.VVsRGc
 def VVpji8(self, mode):
  url = self.VVSsjn() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVhn9e(self, catID):
  return self.VVSsjn() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVIXMg(self, mode, catID, page):
  url = self.VVSsjn() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVOGkN(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VVSsjn() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVoPQu(self, mode, catID):
  return self.VVSsjn() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VV3aOB(self, mode, chCm, serCode, serId):
  url = self.VVSsjn() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=false" % (mode, chCm)
  return url
 def VV6kxh(self):
  return self.VVSsjn() + "type=itv&action=create_link"
 def VVhsnx(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVe9M6(catID, stID, chNum)
  query = self.VVx3FM(mode, self.VVpxBy[1:2], FFjsDH(host), FFjsDH(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVx3FM(self, mode, ph1, host, mac, serCode, serId, chCm):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VV1sn4(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVx3FM(mode, ph1, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFHuvq(host)
  mac   = FFHuvq(mac)
  valid = False
  if self.VVfNc3(playHost) and self.VVfNc3(host) and self.VVfNc3(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVV79X(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCcf6M.VVReea()
   if self.VVEAvm:
    headers["Authorization"] = "Bearer %s" % self.VVEAvm
   if useCookies : cookies = {"mac": self.VVsRGc, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok :
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VV6nkC(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCcf6M.VVReea(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVReea():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVIoZs(host, mac, tType, action, keysList=[]):
  myPortal = CCcf6M()
  ph1 = "s"
  pref = "/portal.php" if par == "p" else "/server/load.php"
  ok = myPortal.VVskzm(host, mac, ph1)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VV3GzM(VViqYq=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s%s?type=%s&action=%s" % (host, ph1, tType, action)
  res, err = myPortal.VVV79X(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVUcXU(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVUcXU(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVWyxg(self, err, title="Portal Browser"):
  FFAvZA(self, str(err), title=title)
 def VV7tAu(self, mode):
  if   mode in ("itv"  , CCaayN.VV4VOZ , CCaayN.VVQefs)  : return "Live"
  elif mode in ("vod"  , CCaayN.VVR1Az , CCaayN.VVC1pl)  : return "VOD"
  elif mode in ("series" , CCaayN.VVKr2f , CCaayN.VVNWLS) : return "Series"
  else                          : return "IPTV"
 def VV8bS5(self, mode, searchName):
  return 'Find in %s : %s' % (self.VV7tAu(mode), FFNkac(searchName, VVcK7G))
 def VVG7y8(self, catchup=False):
  VVwSHr = []
  VVwSHr.append(("Live"    , "live"  ))
  VVwSHr.append(("VOD"    , "vod"   ))
  VVwSHr.append(("Series"   , "series"  ))
  if catchup:
   VVwSHr.append(VVbzyo)
   VVwSHr.append(("Catch-up TV" , "catchup"  ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Account Info." , "accountInfo" ))
  return VVwSHr
 @staticmethod
 def VVSD0s(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCcf6M()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV1sn4(decodedUrl)
  if valid:
   ok = p.VVskzm(host, mac, ph1, VViqYq=False)
   if ok:
    m3u_Url, host, user1, pass1, err = p.VVTZin(isPhp=False, VViqYq=False)
    streamId = CCcf6M.VVDfLz(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err
 @staticmethod
 def VVDfLz(decodedUrl):
  p = CCcf6M()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV1sn4(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFHuvq(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVOmqb(decodedUrl):
  p = CCcf6M()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV1sn4(decodedUrl)
  if valid:
   if CCcf6M.VV9th9(chCm):
    return FFPduo(chCm)
   else:
    ok = p.VVskzm(host, mac, ph1, VViqYq=False)
    if ok:
     try:
      chUrl = p.VVFrmH(mode, chCm, epNum, epId)
      return FFPduo(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VV9th9(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
class CC3oLs(CCcf6M):
 def __init__(self):
  CCcf6M.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVGbY9(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = self.VV1sn4(decodedUrl)
  if valid:
   if self.VVskzm(host, mac, ph1, VViqYq=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVw0dy(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVFrmH(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CCcf6M.VV9th9(self.chCm):
   chUrl = FFPduo(self.chCm)
   chUrl = FFC3CV(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVAJbG(chUrl)
  bPath = CCCBMo.VV5Mvc()
  if newIptvRef:
   if passedSELF:
    FFf8Q6(passedSELF, newIptvRef, VVIqkw=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFf8Q6(self, newIptvRef, VVIqkw=False, fromPrtalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VVIZt3(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VVAJbG(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVIZt3(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("&ph1=s", "&ph1=p", "&ph1=")
   for param in params: newPar = newPar.replace(param, "")
   lines = FF7up6(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for param in params: filePar = filePar.replace(param, "")
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFjpsW()
class CCrTb2(CC3oLs):
 def __init__(self, passedSession):
  CC3oLs.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVZ1kI(VVL9lY  )
  Main_Menu.VVZ1kI(VVrGjB)
  Main_Menu.VVZ1kI(VVGWDl  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVzeh5, iPlayableService.evEOF: self.VVVr6H, iPlayableService.evEnd: self.VV69uT})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVU3Y6)
  except:
   self.timer2.callback.append(self.VVU3Y6)
  self.timer2.start(3000, False)
  self.VVU3Y6()
 def VVU3Y6(self):
  if not CFG.downloadMonitor.getValue():
   self.VVD9sf()
   return
  lst = CCEgwO.VVbJ3i()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFtd04(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCEgwO.VVn2f1(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin:
    self.dnldWin = self.passedSession.instantiateDialog(CCs2ey, txt, 30)
    self.dnldWin.instance.move(ePoint(30, 20))
    self.dnldWin.show()
    FFJvZs(self.dnldWin["myWinTitle"], "#440000", 1)
   else:
    self.dnldWin["myWinTitle"].setText(txt)
  elif self.dnldWin:
   self.VVD9sf()
 def VVD9sf(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVzeh5(self):
  self.startTime = iTime()
 def VVVr6H(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self.passedSession, isFromSession=True)
    if iptvRef and not FF3iML(decodedUrl):
     self.isFromEOF = True
     CCpCNj(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VV69uT(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVqMWQ)
  except:
   self.timer1.callback.append(self.VVqMWQ)
  self.timer1.start(100, True)
 def VVqMWQ(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVGbY9(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCcojD.VVkJzO:
       self.isFromEOF = False
       self.VVw0dy(self.passedSession, isFromSession=True)
class CClSwG():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-z0-9\/\-._:|\]\[]+[\])|:](.+)")
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "xxi", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.adultWords2 = ("\u042d\u0440\u043e\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0435", "dla doros\u0142ych")
 def VVBiv6(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCaayN.VVdedl(name):
   return CCaayN.VV7OYN(name)
  name = self.VVWKrh(name)
  return name.strip() or name
 def VVWKrh(self, name):
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     return tName
  return name
 def VVitvc(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVWKrh(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVQTrH(self, name):
  if self.hideAdult:
   if any(x in name.lower() for x in self.adultWords):
    return ""
   elif any(x in name.encode('ascii', 'backslashreplace').decode('utf-8').lower() for x in self.adultWords2):
    return ""
  return name.strip()
 def VVSYak(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVG6gq(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCXk4n(CCcf6M):
 def __init__(self):
  CCcf6M.__init__(self)
 def VVtadr(self):
  if CCXk4n.VV9Kgc(self):
   FFqXEj(self, BF(self.VV4Rj3, 2), title="Searching ...")
 def VVcT5J(self, winSession, url, mac):
  if CCXk4n.VV9Kgc(self):
   if self.VVskzm(url, mac):
    FFqXEj(winSession, self.VVH8Sw, title="Checking Server ...")
   else:
    FFAvZA(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVPFSA(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CCor0x.VVCSs3(path, self)
   if enc == -1:
    return
   self.session.open(CCfZJl, barTheme=CCfZJl.VVZDZW
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVODLM, path, enc)
       , VVUStE = BF(self.VVLYl0, menuInstance, path))
 def VVODLM(self, path, enc, VVvSz8):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVvSz8.VVO1nT(totLines)
  VVvSz8.VVwBP2 = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVvSz8 or VVvSz8.isCancelled:
     return
    VVvSz8.VVPK2y(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVfNc3(url)
     mac  = self.VV3fef(mac)
     if host and mac and VVvSz8:
      VVvSz8.VVwBP2.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVfNc3(url)
      mac  = self.VV3fef(mac)
      if host and mac and not mac.startswith("AC") and VVvSz8:
       VVvSz8.VVwBP2.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVLYl0(self, menuInstance, path, VVbt6k, VVwBP2, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVwBP2:
   VVlNkE  = ("Home Menu"  , FFtWwG            , [])
   VVq3zo = ("Edit File"  , BF(self.VV5ClY, path)       , [])
   VVcZtS = ("M3U Options" , self.VV4vaW         , [])
   VVrIQY = ("Check & Filter" , BF(self.VVOQaU, menuInstance, path), [])
   VVVt3G  = ("Select"   , self.VVs8Wk      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVe5VU  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVl7Cx = FFyLgY(self, None, title=title, header=header, VVd40u=VVwBP2, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVVt3G=VVVt3G, VVlNkE=VVlNkE, VVcZtS=VVcZtS, VVq3zo=VVq3zo, VVrIQY=VVrIQY, VVCNiH="#0a001122", VVIhEb="#0a001122", VV9Ea0="#0a001122", VVZozG="#00004455", VVsrIN="#0a333333", VVn0US="#11331100", VV1YOp=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VVbt6k:
    FFMYB5(VVl7Cx, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVbt6k:
    FFAvZA(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VV4vaW(self, VVl7Cx, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVwSHr = []
  VVwSHr.append(("Browse as M3U"  , "browse"))
  VVwSHr.append(("Download M3U File" , "downld"))
  FFKX6p(self, BF(self.VVG9ss, VVl7Cx, host, mac), title=title, VVwSHr=VVwSHr, width=600, VVto4D=True)
 def VVG9ss(self, VVl7Cx, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FFqXEj(VVl7Cx, BF(self.VVTi7g, VVl7Cx, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFOjga(self, BF(FFqXEj, VVl7Cx, BF(self.VVTi7g, VVl7Cx, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVTi7g(self, VVl7Cx, title, host, mac, item):
  p = CCcf6M()
  m3u_Url = ""
  ok = p.VVskzm(host, mac, VViqYq=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VVTZin(VViqYq=False)
  if m3u_Url:
   if   item == "browse": self.VVbDLe(title, m3u_Url)
   elif item == "downld": self.VV9en0(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FFAvZA(self, err or "No response from Server !", title=title)
 def VVs8Wk(self, VVl7Cx, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVcT5J(VVl7Cx, url, mac)
 def VV5ClY(self, path, VVl7Cx, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCRb0q(self, path, VVUStE=BF(self.VVSMdh, VVl7Cx), curRowNum=rowNum)
  else    : FFXl6w(self, path)
 def VVOQaU(self, menuInstance, path, VVl7Cx, title, txt, colList):
  self.session.open(CCfZJl, barTheme=CCfZJl.VVBjE0
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVbesm, VVl7Cx)
      , VVUStE = BF(self.VVr8AQ, menuInstance, VVl7Cx, path))
 def VVbesm(self, VVl7Cx, VVvSz8):
  VVvSz8.VVwBP2 = []
  VVvSz8.VVO1nT(VVl7Cx.VVm6b9())
  for row in VVl7Cx.VVBOVP():
   if not VVvSz8 or VVvSz8.isCancelled:
    return
   VVvSz8.VVPK2y(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVskzm(host, mac, VViqYq=False):
    token, profile, tErr = self.VV3GzM(VViqYq=False)
    if token and VVvSz8 and not VVvSz8.isCancelled:
     res, err = self.VVV79X(self.VVpji8("itv"))
     if res and VVvSz8 and not VVvSz8.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVvSz8.VVPK2y(0, showFound=True)
       VVvSz8.VVwBP2.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVvSz8:
    return
 def VVr8AQ(self, menuInstance, VVl7Cx, path, VVbt6k, VVwBP2, threadCounter, threadTotal, threadErr):
  if VVwBP2:
   VVl7Cx.close()
   menuInstance.close()
   newPath = "%s_OK_%s.txt" % (path, FFLFgj())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVwBP2:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FFNkac(str(threadCounter), VVHKA4)
    skipped = FFNkac(str(threadTotal - threadCounter), VVHKA4)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVwBP2)
   txt += "%s\n\n%s"    %  (FFNkac("Result File:", VVXaO9), newPath)
   FFheEQ(self, txt, title="Accessible Portals")
  elif VVbt6k:
   FFAvZA(self, "No portal access found !", title="Accessible Portals")
 def VVgrEN(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFHuvq(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVH8Sw(self):
  token, profile, tErr = self.VV3GzM()
  if token:
   dots = "." * self.VV36m6
   dots += "+" if self.VVpxBy[1:2] == "p" else ""
   VVwSHr  = self.VVG7y8()
   OKBtnFnc = self.VViwoA
   VVMcss = ("Home Menu", FFtWwG)
   VVoZDD= ("Add to Menu", BF(CCaayN.VVyi3Y, self, True, self.VVAWkd + "\t" + self.VVsRGc))
   VVWYuC = ("Bookmark Server", BF(CCaayN.VVKobU, self, True, self.VVAWkd + "\t" + self.VVsRGc))
   FFKX6p(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVsRGc, dots), VVwSHr=VVwSHr, OKBtnFnc=OKBtnFnc, VVMcss=VVMcss, VVoZDD=VVoZDD, VVWYuC=VVWYuC)
 def VViwoA(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFqXEj(menuInstance, BF(self.VVDpHX, mode), title="Reading Categories ...")
   else : FFqXEj(menuInstance, BF(self.VVoGhy, menuInstance, title), title="Reading Account ...")
 def VVoGhy(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVM8cS(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVsRGc)
  VVlNkE  = ("Home Menu" , FFtWwG         , [])
  VVcZtS  = None
  if VVpo5P:
   VVcZtS = ("Get JS"  , BF(self.VVbTG1, self.VVAWkd), [])
  if totCols == 2:
   VVrIQY = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVrIQY = ("More Info.", BF(self.VVatFc, menuInstance)  , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFyLgY(self, None, title=title, width=1200, header=header, VVd40u=rows, VVLpvM=widths, VV2ql8=26, VVlNkE=VVlNkE, VVcZtS=VVcZtS, VVrIQY=VVrIQY, VVCNiH="#0a00292B", VVIhEb="#0a002126", VV9Ea0="#0a002126", VVZozG="#00000000", searchCol=searchCol)
 def VVbTG1(self, url, VVl7Cx, title, txt, colList):
  FFqXEj(VVl7Cx, BF(self.VVG2nQ, url), title="Getting JS ...")
 def VVG2nQ(self, url):
  txt = "// Host\t: %s\n" % url
  verOK = False
  ver, err = self.VVab89("%s/c/version.js" % url)
  if err:
   txt += err
  else:
   txt += "// Version\t: %s\n\n" % ver
   js, err = self.VVab89("%s/c/xpcom.common.js" % url)
   if err: txt += err
   else  : txt += "%s" % js
  FFheEQ(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VVab89(self, url):
  res, err = self.VVV79X(url)
  if err:
   return "", "Error: %s" % err
  else:
   cont = res.headers.get("content-type")
   if "javascript" in cont : return res.text, ""
   else     : return "", "\nError: content-type = %s" % cont
 def VVatFc(self, menuInstance, VVl7Cx, title, txt, colList):
  VVl7Cx.cancel()
  FFqXEj(menuInstance, BF(self.VVoGhy, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVDpHX(self, mode):
  token, profile, tErr = self.VV3GzM()
  if not token:
   return
  res, err = self.VVV79X(self.VVpji8(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     VVkxWB = CClSwG()
     chList = tDict["js"]
     for item in chList:
      Id   = CCaayN.VV6hiq(item, "id"       )
      Title  = CCaayN.VV6hiq(item, "title"      )
      censored = CCaayN.VV6hiq(item, "censored"     )
      Title = VVkxWB.VVQTrH(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVpo5P:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VV7tAu(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVCNiH, VVIhEb, VV9Ea0, VVZozG = self.VVph1O(mode)
   mName = self.VV7tAu(mode)
   VVVt3G   = ("Show List"   , BF(self.VV0gvb, mode)   , [])
   VVlNkE  = ("Home Menu"   , FFtWwG        , [])
   if mode in ("vod", "series"):
    VVq3zo = ("Find in %s" % mName , BF(self.VVOjFk, mode, False), [])
    VVrIQY = ("Find in Selected" , BF(self.VVOjFk, mode, True) , [])
   else:
    VVq3zo = None
    VVrIQY = None
   header   = None
   widths   = (100   , 0  )
   FFyLgY(self, None, title=title, width=1200, header=header, VVd40u=list, VVLpvM=widths, VV2ql8=30, VVlNkE=VVlNkE, VVq3zo=VVq3zo, VVrIQY=VVrIQY, VVVt3G=VVVt3G, VVCNiH=VVCNiH, VVIhEb=VVIhEb, VV9Ea0=VV9Ea0, VVZozG=VVZozG, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVIDZT:
     txt += "\n\n( %s )" % self.VVIDZT
   else:
    txt = "Could not get Categories from server!"
   FFAvZA(self, txt, title=title)
 def VVcZnF(self, mode, VVl7Cx, title, txt, colList):
  FFqXEj(VVl7Cx, BF(self.VVFiWw, mode, VVl7Cx, title, txt, colList), title="Downloading ...")
 def VVFiWw(self, mode, VVl7Cx, title, txt, colList):
  token, profile, tErr = self.VV3GzM()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVV79X(self.VVhn9e(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCaayN.VV6hiq(item, "id"    )
      actors   = CCaayN.VV6hiq(item, "actors"   )
      added   = CCaayN.VV6hiq(item, "added"   )
      age    = CCaayN.VV6hiq(item, "age"   )
      category_id  = CCaayN.VV6hiq(item, "category_id" )
      description  = CCaayN.VV6hiq(item, "description" )
      director  = CCaayN.VV6hiq(item, "director"  )
      genres_str  = CCaayN.VV6hiq(item, "genres_str"  )
      name   = CCaayN.VV6hiq(item, "name"   )
      path   = CCaayN.VV6hiq(item, "path"   )
      screenshot_uri = CCaayN.VV6hiq(item, "screenshot_uri" )
      series   = CCaayN.VV6hiq(item, "series"   )
      cmd    = CCaayN.VV6hiq(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VVVt3G  = ("Play"    , BF(self.VVX08W, mode)       , [])
   VV0QzM = (""     , BF(self.VV3Qba, mode)     , [])
   VVlNkE = ("Home Menu"   , FFtWwG            , [])
   VVcZtS = ("Download Options" , BF(self.VVxXDh, mode, "sp", seriesName) , [])
   VVq3zo = ("Options"   , BF(self.VV3TtO, "pEp", mode, seriesName) , [])
   VVrIQY = ("Posters Mode"  , BF(self.VVUru6, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVe5VU  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFyLgY(self, None, title=seriesName, width=1200, header=header, VVd40u=list, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVVt3G=VVVt3G, VV0QzM=VV0QzM, VVlNkE=VVlNkE, VVcZtS=VVcZtS, VVq3zo=VVq3zo, VVrIQY=VVrIQY, lastFindConfigObj=CFG.lastFindIptv, VVCNiH="#0a00292B", VVIhEb="#0a002126", VV9Ea0="#0a002126", VVZozG="#00000000")
  else:
   FFAvZA(self, "Could not get Episodes from server!", title=seriesName)
 def VVOjFk(self, mode, searchInCat, VVl7Cx, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVwSHr = []
  VVwSHr.append(("Keyboard"  , "manualEntry"))
  VVwSHr.append(("From Filter" , "fromFilter"))
  FFKX6p(self, BF(self.VVJxv0, VVl7Cx, mode, searchCatId), title="Input Type", VVwSHr=VVwSHr, width=400)
 def VVJxv0(self, VVl7Cx, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFJC4A(self, BF(self.VV9oQF, VVl7Cx, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CC6QfU(self)
    filterObj.VVefsy(BF(self.VV9oQF, VVl7Cx, mode, searchCatId))
 def VV9oQF(self, VVl7Cx, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FFGxwH(CFG.lastFindIptv, searchName)
   title = self.VV8bS5(mode, searchName)
   if "," in searchName : FFAvZA(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FFAvZA(self, "Enter at least 3 characters.", title=title)
   else     :
    VVkxWB = CClSwG()
    if CFG.hideIptvServerAdultWords.getValue() and VVkxWB.VVSYak([searchName]):
     FFAvZA(self, VVkxWB.VVG6gq(), title=title)
    else:
     self.VVgcFS(mode, searchName, "", searchName, searchCatId)
 def VV0gvb(self, mode, VVl7Cx, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVgcFS(mode, bName, catID, "", "")
 def VVgcFS(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CCfZJl, barTheme=CCfZJl.VVZDZW
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVAjk2, mode, bName, catID, searchName, searchCatId)
      , VVUStE = BF(self.VVOPwb, mode, bName, catID, searchName, searchCatId))
 def VVOPwb(self, mode, bName, catID, searchName, searchCatId, VVbt6k, VVwBP2, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VV8bS5(mode, searchName)
  else   : title = "%s : %s" % (self.VV7tAu(mode), bName)
  if VVwBP2:
   VVcZtS = None
   VVq3zo = None
   if mode == "series":
    VVCNiH, VVIhEb, VV9Ea0, VVZozG = self.VVph1O("series2")
    VVVt3G  = ("Episodes"   , BF(self.VVcZnF, mode)           , [])
   else:
    VVCNiH, VVIhEb, VV9Ea0, VVZozG = self.VVph1O("")
    VVVt3G  = ("Play"    , BF(self.VVX08W, mode)           , [])
    VVcZtS = ("Download Options" , BF(self.VVxXDh, mode, "vp" if mode == "vod" else "", "") , [])
    VVq3zo = ("Options"   , BF(self.VV3TtO, "pCh", mode, bName)      , [])
   VV0QzM = (""      , BF(self.VVDEyH, mode)         , [])
   VVlNkE = ("Home Menu"    , FFtWwG                , [])
   VVrIQY = ("Posters Mode"   , BF(self.VVUru6, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Category/Genre" , "Logo")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25    , 6  )
   VVe5VU  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT    , CENTER)
   VVl7Cx = FFyLgY(self, None, title=title, header=header, VVd40u=VVwBP2, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVlNkE=VVlNkE, VVcZtS=VVcZtS, VVq3zo=VVq3zo, VVrIQY=VVrIQY, lastFindConfigObj=CFG.lastFindIptv, VVVt3G=VVVt3G, VV0QzM=VV0QzM, VVCNiH=VVCNiH, VVIhEb=VVIhEb, VV9Ea0=VV9Ea0, VVZozG=VVZozG, VV1YOp=True, searchCol=1)
   if not VVbt6k:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVl7Cx.VVWtBD(VVl7Cx.VVWhqJ() + tot)
    if threadErr: FFMYB5(VVl7Cx, "Error while reading !", 2000)
    else  : FFMYB5(VVl7Cx, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFAvZA(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFAvZA(self, "Could not get list from server !", title=title)
 def VVDEyH(self, mode, VVl7Cx, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFQTAA(self, fncMode=CCnfxp.VVGouR, portalHost=self.VVAWkd, portalMac=self.VVsRGc, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVvKSU(mode, VVl7Cx, title, txt, colList)
 def VV3Qba(self, mode, VVl7Cx, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFNkac(colList[10], VVcK7G)
  txt += "Description:\n%s" % FFNkac(colList[11], VVcK7G)
  self.VVvKSU(mode, VVl7Cx, title, txt, colList)
 def VVvKSU(self, mode, VVl7Cx, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVY6sZ(mode, colList)
  refCode, chUrl = self.VVhsnx(self.VVAWkd, self.VVsRGc, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFQTAA(self, fncMode=CCnfxp.VVvSJc, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVAjk2(self, mode, bName, catID, searchName, searchCatId, VVvSz8):
  try:
   token, profile, tErr = self.VV3GzM()
   if not token:
    return
   if VVvSz8.isCancelled:
    return
   VVvSz8.VVwBP2, total_items, max_page_items, err = self.VVypP7(mode, catID, 1, 1, searchName, searchCatId)
   if VVvSz8.isCancelled:
    return
   if VVvSz8.VVwBP2 and total_items > -1 and max_page_items > -1:
    VVvSz8.VVO1nT(total_items)
    VVvSz8.VVPK2y(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVvSz8.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVypP7(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVvSz8.VVKIGf()
     if VVvSz8.isCancelled:
      return
     if list:
      VVvSz8.VVwBP2 += list
      VVvSz8.VVPK2y(len(list), True)
  except:
   pass
 def VVypP7(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVOGkN(mode, searchName, searchCatId, page)
  else   : url = self.VVIXMg(mode, catID, page)
  res, err = self.VVV79X(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVBb8g(CCaayN.VV6hiq(item, "total_items" ))
     max_page_items = self.VVBb8g(CCaayN.VV6hiq(item, "max_page_items" ))
     VVkxWB = CClSwG()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCaayN.VV6hiq(item, "id"    )
      name   = CCaayN.VV6hiq(item, "name"   )
      o_name   = CCaayN.VV6hiq(item, "o_name"   )
      tv_genre_id  = CCaayN.VV6hiq(item, "tv_genre_id" )
      number   = CCaayN.VV6hiq(item, "number"   ) or str(counter)
      logo   = CCaayN.VV6hiq(item, "logo"   )
      screenshot_uri = CCaayN.VV6hiq(item, "screenshot_uri" )
      cmd    = CCaayN.VV6hiq(item, "cmd"   )
      censored  = CCaayN.VV6hiq(item, "censored"  )
      genres_str  = CCaayN.VV6hiq(item, "genres_str"  )
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       span = iSearch(r"stream=(.+)&", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
       else:
        span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      isIcon = "Yes" if picon else ""
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVAWkd + picon).replace(sp * 2, sp)
      counter += 1
      name = VVkxWB.VVBiv6(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd, genres_str, isIcon))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVBb8g(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVX08W(self, mode, VVl7Cx, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVY6sZ(mode, colList)
  refCode, chUrl = self.VVhsnx(self.VVAWkd, self.VVsRGc, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVdedl(chName):
   FFMYB5(VVl7Cx, "This is a marker!", 300)
  else:
   FFqXEj(VVl7Cx, BF(self.VVby4o, mode, VVl7Cx, chUrl), title="Playing ...")
 def VVby4o(self, mode, VVl7Cx, chUrl):
  FFf8Q6(self, chUrl, VVIqkw=False)
  CCcojD.VVEI1u(self.session, iptvTableParams=(self, VVl7Cx, mode))
 def VVI1hv(self, mode, VVl7Cx, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVY6sZ(mode, colList)
  refCode, chUrl = self.VVhsnx(self.VVAWkd, self.VVsRGc, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVY6sZ(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VV9Kgc(SELF):
  try:
   import requests
   return True
  except:
   title = 'Install "Requests"'
   VVwSHr = []
   VVwSHr.append((title        , "inst" ))
   VVwSHr.append(("Update Packages then %s" % title , "updInst" ))
   FFKX6p(SELF, BF(CCXk4n.VVu0cB, SELF), title='This requires Python "Requests" library', VVwSHr=VVwSHr)
   return False
 @staticmethod
 def VVu0cB(SELF, item=None):
  if item:
   from sys import version_info
   cmdUpd = FFeJzm(VVNE2g, "")
   if cmdUpd:
    cmdInst = FFtNvi(VVJBI8, "python-requests")
    if version_info[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFCHwU(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library')
   else:
    FF0QO3(SELF)
class CCaayN(Screen, CCXk4n, CCwlDM):
 VVPSOy    = 0
 VVAmdD    = 1
 VVuQHM    = 2
 VV4oOH    = 3
 VV8Xyw     = 4
 VVMAt4     = 5
 VVtBah     = 6
 VV4Jwj     = 7
 VVmtXq     = 8
 VVWiP4      = 9
 VVU8l4     = 10
 VVDRHd     = 11
 VVqnfM     = 12
 VVnv8a     = 13
 VVfkef      = 14
 VVclfE      = 15
 VVX0xW      = 16
 VVFqjE      = 17
 VVmGqI      = 18
 VVv8dN    = 0
 VV4VOZ   = 1
 VVR1Az   = 2
 VVKr2f   = 3
 VVN68P  = 4
 VVtwFD  = 5
 VVQefs   = 6
 VVC1pl   = 7
 VVNWLS  = 8
 VVgrGk  = 9
 VVgPgj  = 10
 VV2eZ3 = 0
 VV46pN = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFheJw(VVXQaf, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVl7Cx    = None
  self.tableTitle     = "IPTV Channels List"
  self.VVwa50Data    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CCaayN.VVHIur(atLeastOne=True)
  self.isFirstTime    = True
  CCXk4n.__init__(self)
  VVwSHr = self.VV9kNe()
  FFqVmU(self, title="IPTV", VVwSHr=VVwSHr)
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self["myMenu"].setList(self.VV9kNe())
  FFQGfp(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFpkQc(self["myMenu"])
   FFyfbj(self)
   if self.m3uOrM3u8File:
    self.VVlCE3(self.m3uOrM3u8File, (0, (), False, ""))
 def VV9kNe(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VVhTQL
  VVwSHr = []
  if isFav1: VVwSHr.append((c +  "Favourite Playlist Server"   , "VVxy8C" ))
  if isFav2: VVwSHr.append((c +  "Favourite Portal Server"    , "VVjuR4Portal" ))
  VVwSHr.append(("IPTV Server Browser (from Playlists)"     , "VVwa50_fromPlayList" ))
  VVwSHr.append(("IPTV Server Browser (from Portal List)"    , "VVwa50_fromMac"  ))
  VVwSHr.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VVwa50_fromM3u"  ))
  qUrl, iptvRef = self.VVcjyd()
  item = "IPTV Server Browser (from Current Channel)"
  if qUrl or "chCode" in iptvRef : VVwSHr.append((item     , "VVwa50_fromCurrChan" ))
  else       : VVwSHr.append((item     ,       ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("M3U/M3U8 File Browser"        , "VV3gE5"   ))
  if self.iptvFileAvailable:
   VVwSHr.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVwSHr.append(VVbzyo)
  item1 = "Update Current Bouquet EPG (from IPTV Server)"
  item2 = "Update Current Bouquet PIcons (from IPTV Server)"
  if qUrl or "chCode" in iptvRef:
   VVwSHr.append((item1            , "refreshIptvEPG"   ))
   VVwSHr.append((item2            , "refreshIptvPicons"  ))
  else:
   VVwSHr.append((item1            ,       ))
   VVwSHr.append((item2            ,       ))
  if self.iptvFileAvailable:
   VVwSHr.append(VVbzyo)
   c1, c2 = VVtjbM, VVXaO9
   t1 = FFNkac("auto-match names", VVhTQL)
   t2 = FFNkac("from xml file"  , VVhTQL)
   VVwSHr.append((c1 + "Count Available IPTV Channels"    , "VVAk4f"    ))
   VVwSHr.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVwSHr.append(VVbzyo)
   VVwSHr.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVwSHr.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VVP4v8" ))
   VVwSHr.append((VVmIAH + "More Reference Tools ..."  , "VVhppU"   ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Reload Channels and Bouquets"       , "VVHX0d"   ))
  VVwSHr.append(VVbzyo)
  if not CCEgwO.VV84hj():
   VVwSHr.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVwSHr.append(("Download Manager ... No donwloads"    ,       ))
  return VVwSHr
 def VVJ47T(self, item):
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVy82J"   : self.VVy82J()
   elif item == "VVQjvD" : FFOjga(self, self.VVQjvD, "Change Current List References to Unique Codes ?")
   elif item == "VV2RE2_rows" : FFOjga(self, BF(FFqXEj, self.VVl7Cx, self.VV2RE2), "Change Current List References to Identical Codes ?")
   elif item == "VVlHuu"   : self.VVlHuu(tTitle)
   elif item == "VVBdRX"   : self.VVBdRX(tTitle)
   elif item == "VVxy8C" : self.VVjuR4(False)
   elif item == "VVjuR4Portal" : self.VVjuR4(True)
   elif item == "VVwa50_fromPlayList" : FFqXEj(self, BF(self.VV4Rj3, 1), title=title)
   elif item == "VVwa50_fromM3u"  : FFqXEj(self, BF(self.VVjIoM, 0), title=title)
   elif item == "VVwa50_fromMac"  : self.VVtadr()
   elif item == "VVwa50_fromCurrChan" : self.VVpjaw()
   elif item == "VV3gE5"   : self.VV3gE5()
   elif item == "iptvTable_all"   : FFqXEj(self, BF(self.VVaAJ8, self.VVPSOy), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VVVKF9()
   elif item == "refreshIptvPicons"  : self.VVsQT8()
   elif item == "VVAk4f"    : FFqXEj(self, self.VVAk4f)
   elif item == "copyEpgPicons"   : self.VVbB1U(False)
   elif item == "renumIptvRef_fromFile" : self.VVbB1U(True)
   elif item == "VVP4v8" : FFOjga(self, BF(FFqXEj, self, self.VVP4v8), VVByb6="Continue ?")
   elif item == "VVhppU"    : self.VVhppU()
   elif item == "VVHX0d"   : FFqXEj(self, BF(CCKtc8.VVHX0d, self))
   elif item == "dload_stat"    : CCEgwO.VVloZW(self)
 def VV3gE5(self):
  if CCXk4n.VV9Kgc(self):
   FFqXEj(self, BF(self.VVjIoM, 1), title="Searching ...")
 def VVmBrJ(self):
  global VVLQSn
  VVLQSn = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVJ47T(item)
 def VVaAJ8(self, mode):
  VVmJ2p = self.VVa5mL(mode)
  if VVmJ2p:
   VVcZtS = ("Current Service", self.VVkIrv , [])
   VVq3zo = ("Options"  , self.VVe2sl   , [])
   VVrIQY = ("Filter"   , self.VVYxfF   , [])
   VVVt3G  = ("Play"   , BF(self.VVMe5V)  , [])
   VV0QzM = (""    , self.VVjAF0    , [])
   VV3zZz = (""    , self.VVdN3V     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VVe5VU  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FFyLgY(self, None, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26
     , VVVt3G=VVVt3G, VVcZtS=VVcZtS, VVq3zo=VVq3zo, VVrIQY=VVrIQY, VV0QzM=VV0QzM, VV3zZz=VV3zZz
     , VVCNiH="#0a00292B", VVIhEb="#0a002126", VV9Ea0="#0a002126", VVZozG="#00000000", VV1YOp=True, searchCol=1)
  else:
   if mode == self.VVmtXq: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFAvZA(self, err)
 def VVdN3V(self, VVl7Cx, title, txt, colList):
  self.VVl7Cx = VVl7Cx
 def VVe2sl(self, VVl7Cx, title, txt, colList):
  VVwSHr = []
  VVwSHr.append(("Add Current List to a New Bouquet"    , "VVy82J"  ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Change Current List References to Unique Codes" , "VVQjvD"))
  VVwSHr.append(("Change Current List References to Identical Codes", "VV2RE2_rows" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Share Reference with DVB Service (manual entry)" , "VVlHuu"   ))
  VVwSHr.append(("Share Reference with DVB Service (auto-find)"  , "VVBdRX"   ))
  FFKX6p(self, self.VVJ47T, title="IPTV Tools", VVwSHr=VVwSHr)
 def VVYxfF(self, VVl7Cx, title, txt, colList):
  VVwSHr = []
  VVwSHr.append(("All"         , "all"   ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Prefix of Selected Channel"   , "sameName" ))
  VVwSHr.append(("Suggest Words from Selected Channel" , "partName" ))
  VVwSHr.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVwSHr.append(("Duplicate References"     , "depRef"  ))
  VVwSHr.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVwSHr.append(FFDhQn("Category"))
  VVwSHr.append(("Live TV"        , "live"  ))
  VVwSHr.append(("VOD"         , "vod"   ))
  VVwSHr.append(("Series"        , "series"  ))
  VVwSHr.append(("Uncategorised"      , "uncat"  ))
  VVwSHr.append(FFDhQn("Media"))
  VVwSHr.append(("Video"        , "video"  ))
  VVwSHr.append(("Audio"        , "audio"  ))
  VVwSHr.append(FFDhQn("File Type"))
  VVwSHr.append(("MKV"         , "MKV"   ))
  VVwSHr.append(("MP4"         , "MP4"   ))
  VVwSHr.append(("MP3"         , "MP3"   ))
  VVwSHr.append(("AVI"         , "AVI"   ))
  VVwSHr.append(("FLV"         , "FLV"   ))
  VVwSHr.extend(CCCBMo.VV1eYH(prefix="__b__"))
  inFilterFnc = BF(self.VVcU5N, VVl7Cx) if VVl7Cx.VVWhqJ().startswith("IPTV Filter ") else None
  filterObj = CC6QfU(self)
  filterObj.VV7Ltt(VVwSHr, VVwSHr, BF(self.VVMlGo, VVl7Cx, False), inFilterFnc=inFilterFnc)
 def VVcU5N(self, VVl7Cx, menuInstance, item):
  self.VVMlGo(VVl7Cx, True, item)
 def VVMlGo(self, VVl7Cx, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVl7Cx.VVboCB(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVPSOy , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVAmdD , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVuQHM , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VV4oOH , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVtBah  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VV4Jwj  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "live"    : mode, words, title = self.VVmtXq  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVWiP4   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVU8l4  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVDRHd  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVqnfM  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVnv8a  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVfkef   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVclfE   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVX0xW   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVFqjE   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVmGqI   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VV8Xyw  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVMAt4  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVuQHM:
   VVwSHr = []
   chName = VVl7Cx.VVboCB(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVwSHr.append((item, item))
    if not VVwSHr and chName:
     VVwSHr.append((chName, chName))
    FFKX6p(self, BF(self.VV7oyV, title), title="Words from Current Selection", VVwSHr=VVwSHr)
   else:
    VVl7Cx.VVguPD("Invalid Channel Name")
  else:
   words, asPrefix = CC6QfU.VVfYn9(words)
   if not words and mode in (self.VV8Xyw, self.VVMAt4):
    FFMYB5(self.VVl7Cx, "Incorrect filter", 2000)
   else:
    FFqXEj(self.VVl7Cx, BF(self.VVBVId, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VV7oyV(self, title, word=None):
  if word:
   words = [word.lower()]
   FFqXEj(self.VVl7Cx, BF(self.VVBVId, self.VVuQHM, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VV7OYN(txt):
  return "#f#11ffff00#" + txt
 def VVBVId(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVmJ2p = self.VVieXd(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVmJ2p = self.VVa5mL(mode=mode, words=words, asPrefix=asPrefix)
  if VVmJ2p : self.VVl7Cx.VVfoGr(VVmJ2p, title)
  else  : self.VVl7Cx.VVguPD("Not found")
 def VVieXd(self, mode=0, words=None, asPrefix=False):
  VVmJ2p = []
  for row in self.VVl7Cx.VVBOVP():
   row = list(map(str.strip, row))
   chNum, chName, VV10Wd, chType, refCode, url = row
   if self.VVzpyj(mode, refCode, FFPduo(url).lower(), chName, words, VV10Wd.lower(), asPrefix):
    VVmJ2p.append(row)
  VVmJ2p = self.VVVbi3(mode, VVmJ2p)
  return VVmJ2p
 def VVa5mL(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVmJ2p = []
  files  = self.VVencK()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFa594(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VV10Wd = span.group(1)
    else : VV10Wd = ""
    VV10Wd_lCase = VV10Wd.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVdedl(chName): chNameMod = self.VV7OYN(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VV10Wd, chType, refCode, url)
     if self.VVzpyj(mode, refCode, FFPduo(url).lower(), chName, words, VV10Wd_lCase, asPrefix):
      VVmJ2p.append(row)
      chNum += 1
  VVmJ2p = self.VVVbi3(mode, VVmJ2p)
  return VVmJ2p
 def VVVbi3(self, mode, VVmJ2p):
  newRows = []
  if VVmJ2p and mode == self.VVtBah:
   from collections import Counter
   counted  = Counter(elem[4] for elem in VVmJ2p)
   for item in VVmJ2p:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVmJ2p
 def VVzpyj(self, mode, refCode, tUrl, chName, words, VV10Wd_lCase, asPrefix):
  if   mode == self.VVPSOy : return True
  elif mode == self.VVtBah : return True
  elif mode == self.VV4Jwj  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VVqnfM  : return CCaayN.VVBGRU(tUrl, getAudVid=True) == "vid"
  elif mode == self.VVnv8a  : return CCaayN.VVBGRU(tUrl, getAudVid=True) == "aud"
  elif mode == self.VVmtXq  : return CCaayN.VVBGRU(tUrl, compareType="live")
  elif mode == self.VVWiP4  : return CCaayN.VVBGRU(tUrl, compareType="movie")
  elif mode == self.VVU8l4 : return CCaayN.VVBGRU(tUrl, compareType="series")
  elif mode == self.VVDRHd  : return CCaayN.VVBGRU(tUrl, compareType="")
  elif mode == self.VVfkef  : return CCaayN.VVBGRU(tUrl, compareExt="mkv")
  elif mode == self.VVclfE  : return CCaayN.VVBGRU(tUrl, compareExt="mp4")
  elif mode == self.VVX0xW  : return CCaayN.VVBGRU(tUrl, compareExt="mp3")
  elif mode == self.VVFqjE  : return CCaayN.VVBGRU(tUrl, compareExt="avi")
  elif mode == self.VVmGqI  : return CCaayN.VVBGRU(tUrl, compareExt="flv")
  elif mode == self.VVAmdD: return chName.lower().startswith(words[0])
  elif mode == self.VVuQHM: return words[0] in chName.lower()
  elif mode == self.VV4oOH: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VV8Xyw : return words[0] == VV10Wd_lCase
  elif mode == self.VVMAt4 :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVy82J(self):
  picker = CCCBMo(self, self.VVl7Cx, "Add to Bouquet", self.VVZkcg)
 def VVZkcg(self):
  chUrlLst = []
  for row in self.VVl7Cx.VVBOVP():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VVhppU(self):
  c1 = VV4YPU
  t1 = FFNkac("Bouquet", VVhTQL)
  t2 = FFNkac("ALL", VVhTQL)
  refTxt = "(1/4097/5001/5002/8192/8193)"
  VVwSHr = []
  VVwSHr.append((c1 + "Check System Acceptable Reference Types" , "VVGc4h"    ))
  if self.iptvFileAvailable:
   VVwSHr.append((c1 + "Check Reference Codes Format"  , "VVVXpZ"    ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(('Change %s Ref. Types to %s ..' % (t1, refTxt) , "VVMDPV" ))
  VVwSHr.append(('Change %s Ref. Types to %s ..' % (t2, refTxt) , "VVs65Q_all"  ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Change %s References to Unique Codes" % t2 , "VVq1Y6"  ))
  VVwSHr.append(("Change %s References to Identical Codes" % t2 , "VV2RE2_all"  ))
  OKBtnFnc = self.VV24dv
  FFKX6p(self, None, width=1200, title="Reference Tools", VVwSHr=VVwSHr, OKBtnFnc=OKBtnFnc)
 def VV24dv(self, item=None):
  if item:
   ques = "Continue ?"
   menuInstance, txt, item, ndx = item
   if   item == "VVGc4h"    : FFqXEj(menuInstance, self.VVGc4h)
   elif item == "VVVXpZ"     : FFqXEj(menuInstance, self.VVVXpZ)
   elif item == "VVMDPV" : self.VVMDPV(menuInstance)
   elif item == "VVs65Q_all"  : self.VVjinN(menuInstance, None, None)
   elif item == "VVq1Y6"  : FFOjga(self, BF(self.VVq1Y6 , menuInstance, txt), title=txt, VVByb6=ques)
   elif item == "VV2RE2_all"  : FFOjga(self, BF(FFqXEj, menuInstance, self.VV2RE2), title=txt, VVByb6=ques)
 def VVjinN(self, menuInstance, bName, bPath):
  txt = "Stream Type "
  VVwSHr = []
  VVwSHr.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVwSHr.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVwSHr.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVwSHr.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVwSHr.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVwSHr.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFKX6p(self, BF(self.VVYtUm, menuInstance, bName, bPath), width=750, title="Change Reference Types to:", VVwSHr=VVwSHr)
 def VVYtUm(self, menuInstance, bName, bPath, item=None):
  if item:
   if   item == "RT_1"  : self.VV16WN(menuInstance, bName, bPath, "1"   )
   elif item == "RT_4097" : self.VV16WN(menuInstance, bName, bPath, "4097")
   elif item == "RT_5001" : self.VV16WN(menuInstance, bName, bPath, "5001")
   elif item == "RT_5002" : self.VV16WN(menuInstance, bName, bPath, "5002")
   elif item == "RT_8192" : self.VV16WN(menuInstance, bName, bPath, "8192")
   elif item == "RT_8193" : self.VV16WN(menuInstance, bName, bPath, "8193")
 def VVMDPV(self, menuInstance):
  VVwSHr = CCCBMo.VV1eYH()
  if VVwSHr:
   FFKX6p(self, BF(self.VVqKmW, menuInstance), VVwSHr=VVwSHr, title="IPTV Bouquets", VVto4D=True)
  else:
   FFMYB5(menuInstance, "No bouquets Found !", 1500)
 def VVqKmW(self, menuInstance, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVslLY + span.group(1)
    if fileExists(bPath): self.VVjinN(menuInstance, bName, bPath)
    else    : FFMYB5(menuInstance, "Bouquet file not found!", 2000)
   else:
    FFMYB5(menuInstance, "Cannot process bouquet !", 2000)
 def VV16WN(self, menuInstance, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FFNkac(bName, VVSqFX)
  else : title = "Change for %s" % FFNkac("All IPTV Services", VVSqFX)
  FFOjga(self, BF(FFqXEj, menuInstance, BF(self.VVAVQO, menuInstance, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FFNkac(rType, VVSqFX), title=title)
 def VVAVQO(self, menuInstance, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = self.VVencK()
  if files:
   newRType = rType + ":"
   piconPath = CCVrfy.VVNV04()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CCeH84.VVnVuy(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FFAvZA(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           os.system(FFlWZ0("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png")))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    os.system(FFlWZ0(cmd))
  self.VVHksM(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VVAk4f(self):
  totFiles = 0
  files  = self.VVencK()
  if files:
   totFiles = len(files)
  totChans = 0
  VVmJ2p = self.VVa5mL()
  if VVmJ2p:
   totChans = len(VVmJ2p)
  FFheEQ(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVVXpZ(self):
  files  = self.VVencK()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFa594(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VV80BT
   else    : color = VVHKA4
   totInvalid = FFNkac(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFNkac("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFheEQ(self, txt, title="Check IPTV References")
 def VVGc4h(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  chUrlLst  = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CCCBMo.VVnLWk(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVSMPM = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVSMPM:
   VVfQIA = FFyIuW(VVSMPM)
   if VVfQIA:
    for service in VVfQIA:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVslLY + userBName
  bFile = VVslLY + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFlWZ0("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFlWZ0("rm -f '%s'" % path)
  os.system(cmd)
  FFjpsW()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VV80BT
    else     : res, color = "No" , VVHKA4
    txt += "    %s\t: %s\n" % (item, FFNkac(res, color))
   FFheEQ(self, txt, title=title)
  else:
   txt = FFAvZA(self, "Could not complete the test on your system!", title=title)
 def VVP4v8(self):
  VVg870, err = CCKtc8.VVwRJt(self, CCKtc8.VVp1YJ)
  if VVg870:
   totChannels = 0
   totChange = 0
   for path in self.VVencK():
    toSave = False
    txt = FFa594(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVg870.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVHksM(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFAvZA(self, 'No channels in "lamedb" !')
 def VVq1Y6(self, menuInstance, title):
  bFiles = self.VVencK()
  if bFiles:
   self.session.open(CCfZJl, barTheme=CCfZJl.VVBjE0
       , titlePrefix = "Renumbering References"
       , fncToRun  = BF(self.VVElzc, bFiles)
       , VVUStE = BF(self.VVeMi0, title))
  else:
   FFMYB5(menuInstance, "No bouquets files !", 1500)
 def VVElzc(self, bFiles, VVvSz8):
  VVvSz8.VVwBP2 = ""
  VVvSz8.VV6VDY("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FF7up6(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVvSz8 or VVvSz8.isCancelled:
   return
  elif not totLines:
   VVvSz8.VVwBP2 = "No IPTV Services !"
   return
  else:
   VVvSz8.VVO1nT(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVvSz8 or VVvSz8.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FF7up6(path)
    for ndx, line in enumerate(lines):
     if not VVvSz8 or VVvSz8.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVvSz8:
       VVvSz8.VV6VDY("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVvSz8:
       VVvSz8.VVPK2y(1)
      refCode, startId, startNS = CCCBMo.VVqdPj(rType, CCCBMo.VV3gaV, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVvSz8:
        VVvSz8.VVwBP2 = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VVeMi0(self, title, VVbt6k, VVwBP2, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVwBP2:
   txt += "\n\n%s\n%s" % (FFNkac("Ended with Error:", VVHKA4), VVwBP2)
  self.VVHksM(True, title, txt)
 def VVQjvD(self):
  bFiles = self.VVencK()
  if not bFiles:
   FFMYB5(self.VVl7Cx, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVl7Cx.VVBOVP():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FFMYB5(self.VVl7Cx, "Cannot read list", 1500)
   return
  self.session.open(CCfZJl, barTheme=CCfZJl.VVBjE0
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVml6L, bFiles, tableRefList)
      , VVUStE = BF(self.VVeMi0, "Change Current List References to Unique Codes"))
 def VVml6L(self, bFiles, tableRefList, VVvSz8):
  VVvSz8.VVwBP2 = ""
  VVvSz8.VV6VDY("Reading System References ...")
  refLst = CCCBMo.VVdheu(CCCBMo.VV3gaV, stripRType=True)
  if not VVvSz8 or VVvSz8.isCancelled:
   return
  VVvSz8.VVO1nT(len(tableRefList))
  rType  = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVvSz8 or VVvSz8.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFa594(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVvSz8 or VVvSz8.isCancelled:
     return
    VVvSz8.VV6VDY("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVvSz8 or VVvSz8.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVvSz8.VVPK2y(1)
      refCode, startId, startNS = CCCBMo.VVqdPj(rType, CCCBMo.VV3gaV, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVvSz8:
        VVvSz8.VVwBP2 = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VV2RE2(self):
  list = None
  if self.VVl7Cx:
   list = []
   for row in self.VVl7Cx.VVBOVP():
    list.append(row[4] + row[5])
  files  = self.VVencK()
  totChange = 0
  if files:
   for path in files:
    lines = FF7up6(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VVHksM(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVHksM(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFjpsW()
   if refreshTable and self.VVl7Cx:
    VVmJ2p = self.VVa5mL()
    if VVmJ2p and self.VVl7Cx:
     self.VVl7Cx.VVfoGr(VVmJ2p, self.tableTitle)
     self.VVl7Cx.VVguPD(txt)
   FFheEQ(self, txt, title=title)
  else:
   FF6b7h(self, "No changes.")
 def VVencK(self):
  return CCaayN.VVHIur()
 @staticmethod
 def VVHIur(atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVslLY + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFa594(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVjAF0(self, VVl7Cx, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFPduo(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFQTAA(self, fncMode=CCnfxp.VVbsHW, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVCu06(self, VVl7Cx, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVMe5V(self, VVl7Cx, title, txt, colList):
  chName, chUrl = self.VVCu06(VVl7Cx, colList)
  self.VVLelz(VVl7Cx, chName, chUrl, "localIptv")
 def VVQWoA(self, mode, VVl7Cx, colList):
  chName, chUrl, picUrl, refCode = self.VVEHNO(mode, colList)
  return chName, chUrl
 def VVVRUc(self, mode, VVl7Cx, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVEHNO(mode, colList)
  self.VVLelz(VVl7Cx, chName, chUrl, mode)
 def VVLelz(self, VVl7Cx, chName, chUrl, playerFlag):
  chName = FFGlcE(chName)
  if self.VVdedl(chName):
   FFMYB5(VVl7Cx, "This is a marker!", 300)
  else:
   FFqXEj(VVl7Cx, BF(self.VVJUWR, VVl7Cx, chUrl, playerFlag), title="Playing ...")
 def VVJUWR(self, VVl7Cx, chUrl, playerFlag):
  FFf8Q6(self, chUrl, VVIqkw=False)
  CCcojD.VVEI1u(self.session, iptvTableParams=(self, VVl7Cx, playerFlag))
 @staticmethod
 def VVdedl(chName):
  mark = ("--", "__", "==", "##",  "**", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVkIrv(self, VVl7Cx, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self)
  if refCode:
   url1 = FFPduo(origUrl.strip())
   for ndx, row in enumerate(VVl7Cx.VVBOVP()):
    if refCode in row[4]:
     tableRow = FFPduo(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVl7Cx.VVm16r(ndx)
      break
   else:
    FFMYB5(VVl7Cx, "No found", 1000)
 def VVjIoM(self, m3uMode):
  lines = self.VVAZrI(3)
  if lines:
   lines.sort()
   VVwSHr = []
   for line in lines:
    VVwSHr.append((line, line))
   if m3uMode == self.VV2eZ3:
    title = "Browse Server from M3U URLs"
    VVWYuC = ("All to Playlist", self.VVDGhl)
   else:
    title = "M3U/M3U8 File Browser"
    VVWYuC = None
   OKBtnFnc = BF(self.VVXM7u, m3uMode, title)
   VV7qf7  = ("Show Full Path", self.VVtb4l)
   VVoZDD = ("Delete File", self.VV4jJI)
   FFKX6p(self, None, title=title, VVwSHr=VVwSHr, width=1200, OKBtnFnc=OKBtnFnc, VV7qf7=VV7qf7, VVoZDD=VVoZDD, VVWYuC=VVWYuC, VVCNiH="#11221122", VVIhEb="#11221122")
 def VVXM7u(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == self.VV2eZ3:
    FFqXEj(menuInstance, BF(self.VVr6dD, title, path))
   else:
    self.VVl9eg(menuInstance, path)
 def VVl9eg(self, menuInstance, path=None):
  if path:
   VVwSHr = []
   VVwSHr.append(("All"         , "all"   ))
   VVwSHr.append(FFDhQn("Category"))
   VVwSHr.append(("Live TV"        , "live"  ))
   VVwSHr.append(("VOD"         , "vod"   ))
   VVwSHr.append(("Series"        , "series"  ))
   VVwSHr.append(("Uncategorised"      , "uncat"  ))
   VVwSHr.append(FFDhQn("Media"))
   VVwSHr.append(("Video"        , "video"  ))
   VVwSHr.append(("Audio"        , "audio"  ))
   VVwSHr.append(FFDhQn("File Type"))
   VVwSHr.append(("MKV"         , "MKV"   ))
   VVwSHr.append(("MP4"         , "MP4"   ))
   VVwSHr.append(("MP3"         , "MP3"   ))
   VVwSHr.append(("AVI"         , "AVI"   ))
   VVwSHr.append(("FLV"         , "FLV"   ))
   filterObj = CC6QfU(self, VVCNiH="#11552233", VVIhEb="#11552233")
   filterObj.VV7Ltt(VVwSHr, [], BF(self.VVexSl, menuInstance, path), inFilterFnc=None)
 def VVexSl(self, menuInstance, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VVPSOy , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VVmtXq  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VVWiP4  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VVU8l4  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VVDRHd  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VVqnfM  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VVnv8a  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VVfkef  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VVclfE  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VVX0xW  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVFqjE  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VVmGqI  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVMAt4  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CC6QfU.VVfYn9(words)
   if not mode == self.VVPSOy:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FFNkac(fTitle, VVcK7G)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FFqXEj(menuInstance, BF(self.VVlCE3, path, m3uFilterParam))
 def VVlCE3(self, srcPath, m3uFilterParam):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFa594(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  VVkxWB = CClSwG()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVJLt8(propLine, "group-title") or "-"
   if not group == "-" and VVkxWB.VVBiv6(group):
    groups.add(group)
  VVmJ2p = []
  if len(groups) > 0:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   for group in groups:
    VVmJ2p.append((group, group))
   VVmJ2p.append(("ALL", ""))
   VVmJ2p.sort(key=lambda x: x[0].lower())
   VVPypB = self.VVfzcm
   VVVt3G  = ("Select" , BF(self.VVskSj, srcPath, m3uFilterParam), [])
   widths   = (100  , 0)
   VVe5VU  = (LEFT  , LEFT)
   FFyLgY(self, None, title=title, width= 1000, header=None, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=30, VVVt3G=VVVt3G, VVPypB=VVPypB, lastFindConfigObj=CFG.lastFindIptv
     , VVCNiH="#11110022", VVIhEb="#11110022", VV9Ea0="#11110022", VVZozG="#00444400")
  else:
   txt = FFa594(srcPath)
   self.VVjjf6(txt, "", m3uFilterParam)
 def VVskSj(self, srcPath, m3uFilterParam, VVl7Cx, title, txt, colList):
  group = colList[1]
  txt = FFa594(srcPath)
  self.VVjjf6(txt, group, m3uFilterParam)
 def VVjjf6(self, txt, filterGroup="", m3uFilterParam=None):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CCfZJl, barTheme=CCfZJl.VVZDZW
       , titlePrefix = "Reading File Lines"
       , fncToRun  = BF(self.VVC8uf, lst, filterGroup, m3uFilterParam)
       , VVUStE = BF(self.VVgBWC, title, bName))
  else:
   self.VVgHxd("Not valid lines found !", title)
 def VVC8uf(self, lst, filterGroup, m3uFilterParam, VVvSz8):
  VVvSz8.VVwBP2 = []
  VVvSz8.VVO1nT(len(lst))
  VVkxWB = CClSwG()
  num = 0
  for cols in lst:
   if not VVvSz8 or VVvSz8.isCancelled:
    return
   VVvSz8.VVPK2y(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVJLt8(propLine, "tvg-logo")
   group = self.VVJLt8(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not VVkxWB.VVBiv6(group) : skip = True
    elif chName and not VVkxWB.VVBiv6(chName) : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VVzpyj(mode, "", FFPduo(url).lower(), chName, words, "", asPrefix)
    if not skip and VVvSz8:
     num += 1
     VVvSz8.VVwBP2.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if VVvSz8:
   VVvSz8.VVofeK("Loading %d Channels" % len(VVvSz8.VVwBP2))
 def VVgBWC(self, title, bName, VVbt6k, VVwBP2, threadCounter, threadTotal, threadErr):
  if VVwBP2:
   VVPypB = self.VVfzcm
   VVVt3G  = ("Select"   , BF(self.VVwJTf, title)   , [])
   VV0QzM = (""    , self.VVxOxR        , [])
   VVcZtS = ("Download PIcons", self.VViuY4       , [])
   VVq3zo = ("Options"  , BF(self.VV3TtO, "m3Ch", "", bName) , [])
   VVrIQY = ("Posters Mode" , BF(self.VVUru6, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVe5VU  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFyLgY(self, None, title=title, header=header, VVd40u=VVwBP2, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=28, VVVt3G=VVVt3G, VVPypB=VVPypB, VV0QzM=VV0QzM, VVcZtS=VVcZtS, VVq3zo=VVq3zo, VVrIQY=VVrIQY, lastFindConfigObj=CFG.lastFindIptv, VV1YOp=True, searchCol=1
     , VVCNiH="#0a00192B", VVIhEb="#0a00192B", VV9Ea0="#0a00192B", VVZozG="#00000000")
  else:
   self.VVgHxd("Not found !", title)
 def VViuY4(self, VVl7Cx, title, txt, colList):
  self.VVira2(VVl7Cx, "m3u/m3u8")
 def VVurgs(self, rowNum, url, chName):
  refCode = self.VVsx3d(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFC3CV(url), chName)
  return chUrl
 def VVsx3d(self, rowNum, url, chName):
  span = iSearch(r"\/(\d{2,})", url, IGNORECASE)
  if span : stID = span.group(1)
  else : stID = "444"
  catID = "333"
  chNum = str(rowNum + 1)
  refCode = self.VVe9M6(catID, stID, chNum)
  return refCode
 def VVJLt8(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVwJTf(self, Title, VVl7Cx, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFqXEj(VVl7Cx, BF(self.VViACT, Title, VVl7Cx, colList), title="Checking Server ...")
  else:
   self.VVfcH6(VVl7Cx, url, chName)
 def VViACT(self, title, VVl7Cx, colList):
  if not CCXk4n.VV9Kgc(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCcf6M.VV6nkC(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVwSHr = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCaayN.VV2pD7(url, fPath)
     VVwSHr.append((resol, fullUrl))
    if VVwSHr:
     if len(VVwSHr) > 1:
      FFKX6p(self, BF(self.VVXlEQ, VVl7Cx, chName), VVwSHr=VVwSHr, title="Resolution", VVto4D=True, VVL5Ba=True)
     else:
      self.VVfcH6(VVl7Cx, VVwSHr[0][1], chName)
    else:
     self.VVWyxg("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVjjf6(txt, filterGroup="")
      return
    self.VVfcH6(VVl7Cx, url, chName)
   else:
    self.VVgHxd("Cannot process this channel !", title)
  else:
   self.VVgHxd(err, title)
 def VVXlEQ(self, VVl7Cx, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVfcH6(VVl7Cx, resolUrl, chName)
 def VVfcH6(self, VVl7Cx, url, chName):
  FFqXEj(VVl7Cx, BF(self.VVlVzp, VVl7Cx, url, chName), title="Playing ...")
 def VVlVzp(self, VVl7Cx, url, chName):
  chUrl = self.VVurgs(VVl7Cx.VVf913(), url, chName)
  FFf8Q6(self, chUrl, VVIqkw=False)
  CCcojD.VVEI1u(self.session, iptvTableParams=(self, VVl7Cx, "m3u/m3u8"))
 def VVpi7F(self, VVl7Cx, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVurgs(VVl7Cx.VVf913(), url, chName)
  return chName, chUrl
 def VVxOxR(self, VVl7Cx, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFQTAA(self, fncMode=CCnfxp.VVbsHW, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVgHxd(self, err, title):
  FFAvZA(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVfzcm(self, VVl7Cx):
  if self.m3uOrM3u8File:
   self.close()
  VVl7Cx.cancel()
 def VVDGhl(self, VVZPLhObj, item=None):
  FFqXEj(VVZPLhObj, BF(self.VVXW8d, VVZPLhObj, item))
 def VVXW8d(self, VVZPLhObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVZPLhObj.VVwSHr):
    path = item[1]
    if fileExists(path):
     enc = CCor0x.VVCSs3(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VVHVZi(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCaayN.VVxHN4()
    pListF = "%sPlaylist_%s.txt" % (path, FFLFgj())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVZPLhObj.VVwSHr)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFheEQ(self, txt, title=title)
   else:
    FFAvZA(self, "Could not obtain URLs from this file list !", title=title)
 def VV4Rj3(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVs00K
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VVPFSA
  lines = self.VVAZrI(mode)
  if lines:
   lines.sort()
   VVwSHr = []
   for line in lines:
    VVwSHr.append((FFNkac(line, VVXaO9) if "Bookmarks" in line else line, line))
   VVoZDD = ("Delete File", self.VV4jJI)
   VV7qf7  = ("Show Full Path", self.VVtb4l)
   FFKX6p(self, None, title=title, VVwSHr=VVwSHr, width=1200, OKBtnFnc=okFnc, VV7qf7 =VV7qf7 , VVoZDD=VVoZDD)
 def VVtb4l(self, menuInstance, url):
  FFheEQ(self, url, title="Full Path")
 def VV4jJI(self, VVZPLhObj, path):
  FFOjga(self, BF(self.VVzZXO, VVZPLhObj, path), "Delete this file ?\n\n%s" % path)
 def VVzZXO(self, VVZPLhObj, path):
  FFblrr(path)
  if fileExists(path) : FFMYB5(VVZPLhObj, "Not deleted", 1000)
  else    : VVZPLhObj.VVPjeT()
 def VVs00K(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFqXEj(menuInstance, BF(self.VVN8xV, menuInstance, path), title="Processing File ...")
 def VVN8xV(self, VVjdiV, path):
  enc = CCor0x.VVCSs3(path, self)
  if enc == -1:
   return
  VVmJ2p = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFThW1(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCaayN.VVh5Pt(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVmJ2p:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVmJ2p.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVmJ2p:
   title = "Playlist File : %s" % os.path.basename(path)
   VVVt3G  = ("Start"    , BF(self.VVAHuK, "Playlist File")      , [])
   VVlNkE = ("Home Menu"   , FFtWwG             , [])
   VVcZtS = ("Download M3U File" , self.VV3meB         , [])
   VVq3zo = ("Edit File"   , BF(self.VVBNca, path)        , [])
   VVrIQY = ("Check & Filter"  , BF(self.VVo95p, VVjdiV, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVe5VU  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFyLgY(self, None, title=title, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVVt3G=VVVt3G, VVlNkE=VVlNkE, VVrIQY=VVrIQY, VVcZtS=VVcZtS, VVq3zo=VVq3zo, VVCNiH="#11001116", VVIhEb="#11001116", VV9Ea0="#11001116", VVZozG="#00003635", VVsrIN="#0a333333", VVn0US="#11331100", VV1YOp=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FFAvZA(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VV3meB(self, VVl7Cx, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFOjga(self, BF(FFqXEj, VVl7Cx, BF(self.VV9en0, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VV9en0(self, title, url):
  path, err = FF8zMR(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFAvZA(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFa594(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFblrr(path)
    FFAvZA(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFblrr(path)
    FFAvZA(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCaayN.VVxHN4() + fName
    os.system(FFlWZ0("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FF6b7h(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFAvZA(self, "Could not download the M3U file!", title=errTitle)
 def VVAHuK(self, Title, VVl7Cx, title, txt, colList):
  url = colList[6]
  FFqXEj(VVl7Cx, BF(self.VVbDLe, Title, url), title="Checking Server ...")
 def VVBNca(self, path, VVl7Cx, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCRb0q(self, path, VVUStE=BF(self.VVSMdh, VVl7Cx), curRowNum=rowNum)
  else    : FFXl6w(self, path)
 def VVSMdh(self, VVl7Cx, fileChanged):
  if fileChanged:
   VVl7Cx.cancel()
 def VVlHuu(self, title):
  curChName = self.VVl7Cx.VVboCB(1)
  FFJC4A(self, BF(self.VVNbvz, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVNbvz(self, title, name):
  if name:
   VVg870, err = CCKtc8.VVwRJt(self, CCKtc8.VVATCv, VVajqq=False, VVKx0m=False)
   list = []
   if VVg870:
    VVkxWB = CClSwG()
    name = VVkxWB.VVitvc(name)
    ratio = "1"
    for item in VVg870:
     if name in item[0].lower():
      list.append((item[0], FFJ0oY(item[2]), item[3], ratio))
   if list : self.VV6oDw(list, title)
   else : FFAvZA(self, "Not found:\n\n%s" % name, title=title)
 def VVBdRX(self, title):
  curChName = self.VVl7Cx.VVboCB(1)
  self.session.open(CCfZJl, barTheme=CCfZJl.VVZDZW
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VV4cWS
      , VVUStE = BF(self.VVwTa7, title, curChName))
 def VV4cWS(self, VVvSz8):
  curChName = self.VVl7Cx.VVboCB(1)
  VVg870, err = CCKtc8.VVwRJt(self, CCKtc8.VVlGns, VVajqq=False, VVKx0m=False)
  if not VVg870 or not VVvSz8 or VVvSz8.isCancelled:
   return
  VVvSz8.VVwBP2 = []
  VVvSz8.VVO1nT(len(VVg870))
  VVkxWB = CClSwG()
  curCh = VVkxWB.VVitvc(curChName)
  for refCode in VVg870:
   chName, sat, inDB = VVg870.get(refCode, ("", "", 0))
   ratio = CCVrfy.VVry3E(chName.lower(), curCh)
   if not VVvSz8 or VVvSz8.isCancelled:
    return
   VVvSz8.VVPK2y(1, True)
   if VVvSz8 and ratio > 50:
    VVvSz8.VVwBP2.append((chName, FFJ0oY(sat), refCode.replace("_", ":"), str(ratio)))
 def VVwTa7(self, title, curChName, VVbt6k, VVwBP2, threadCounter, threadTotal, threadErr):
  if VVwBP2: self.VV6oDw(VVwBP2, title)
  elif VVbt6k: FFAvZA(self, "No similar names found for:\n\n%s" % curChName, title)
 def VV6oDw(self, VVmJ2p, title):
  curChName = self.VVl7Cx.VVboCB(1)
  VVblT3 = self.VVl7Cx.VVboCB(4)
  curUrl  = self.VVl7Cx.VVboCB(5)
  VVmJ2p.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVVt3G  = ("Share Sat/C/T Ref.", BF(self.VVtggG, title, curChName, VVblT3, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFyLgY(self, None, title=title, header=header, VVd40u=VVmJ2p, VVLpvM=widths, VV2ql8=26, VVVt3G=VVVt3G, VVCNiH="#0a00112B", VVIhEb="#0a001126", VV9Ea0="#0a001126", VVZozG="#00000000")
 def VVtggG(self, newtitle, curChName, VVblT3, curUrl, VVl7Cx, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVblT3, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFOjga(self.VVl7Cx, BF(FFqXEj, self.VVl7Cx, BF(self.VV4vG9, VVl7Cx, data)), ques, title=newtitle, VVA7RB=True)
 def VV4vG9(self, VVl7Cx, data):
  VVl7Cx.cancel()
  title, curChName, VVblT3, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVblT3 = VVblT3.strip()
  newRefCode = newRefCode.strip()
  if not VVblT3.endswith(":") : VVblT3 += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVblT3, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVblT3 + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVencK():
    txt = FFa594(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFjpsW()
    newRow = []
    for i in range(6):
     newRow.append(self.VVl7Cx.VVboCB(i))
    newRow[4] = newRefCode
    done = self.VVl7Cx.VV3N4D(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFuqQK(BF(FF6b7h , self, resTxt, title=title))
  elif resErr: FFuqQK(BF(FFAvZA, self, resErr, title=title))
 def VVo95p(self, VVjdiV, path, VVl7Cx, title, txt, colList):
  self.session.open(CCfZJl, barTheme=CCfZJl.VVBjE0
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVJ1jA, VVl7Cx)
      , VVUStE = BF(self.VVP7dU, VVjdiV, path, VVl7Cx))
 def VVJ1jA(self, VVl7Cx, VVvSz8):
  VVvSz8.VVO1nT(VVl7Cx.VV1Heh())
  VVvSz8.VVwBP2 = []
  for row in VVl7Cx.VVBOVP():
   if not VVvSz8 or VVvSz8.isCancelled:
    return
   VVvSz8.VVPK2y(1, True)
   qUrl = self.VVRQ38(self.VVv8dN, row[6])
   txt, err = self.VVokhy(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VV6hiq(item, "auth") == "0":
       VVvSz8.VVwBP2.append(qUrl)
    except:
     pass
 def VVP7dU(self, VVjdiV, path, VVl7Cx, VVbt6k, VVwBP2, threadCounter, threadTotal, threadErr):
  if VVbt6k:
   list = VVwBP2
   title = "Authorized Servers"
   if list:
    totChk = VVl7Cx.VV1Heh()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFLFgj()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VV4Rj3(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFNkac(str(totAuth), VV80BT)
     txt += "%s\n\n%s"    %  (FFNkac("Result File:", VVXaO9), newPath)
     FFheEQ(self, txt, title=title)
     VVl7Cx.close()
     VVjdiV.close()
    else:
     FF6b7h(self, "All URLs are authorized.", title=title)
   else:
    FFAvZA(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVokhy(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVh5Pt(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVBGRU(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CCOLsm.VVWj5y()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVmuAb(decodedUrl):
  return CCaayN.VVBGRU(decodedUrl, justRetDotExt=True)
 def VVRQ38(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVh5Pt(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVv8dN   : return "%s"            % url
  elif mode == self.VV4VOZ   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVR1Az   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVKr2f  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVN68P  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVtwFD : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVQefs   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVC1pl    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVNWLS  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVgPgj : return "%s&action=get_live_streams"      % url
  elif mode == self.VVgrGk  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VV6hiq(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFLaSW(int(val))
    elif is_base64 : val = FFHuvq(val)
    elif isToHHMMSS : val = FFQjGS(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVr6dD(self, title, path):
  if fileExists(path):
   enc = CCor0x.VVCSs3(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VVHVZi(line)
     if qUrl:
      break
   if qUrl : self.VVbDLe(title, qUrl)
   else : FFAvZA(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFAvZA(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVpjaw(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVcjyd()
  if qUrl or "chCode" in iptvRef:
   p = CCcf6M()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VV1sn4(iptvRef)
   if valid:
    self.VVcT5J(self, host, mac)
    return
   elif qUrl:
    FFqXEj(self, BF(self.VVbDLe, title, qUrl), title="Checking Server ...")
    return
  FFAvZA(self, "Error in current channel URL !", title=title)
 def VVcjyd(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self)
  qUrl = self.VVHVZi(decodedUrl)
  return qUrl, iptvRef
 def VVHVZi(self, url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVbDLe(self, title, url):
  self.VVwa50Data = {}
  qUrl = self.VVRQ38(self.VVv8dN, url)
  txt, err = self.VVokhy(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVwa50Data = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVwa50Data["username"    ] = self.VV6hiq(item, "username"        )
    self.VVwa50Data["password"    ] = self.VV6hiq(item, "password"        )
    self.VVwa50Data["message"    ] = self.VV6hiq(item, "message"        )
    self.VVwa50Data["auth"     ] = self.VV6hiq(item, "auth"         )
    self.VVwa50Data["status"    ] = self.VV6hiq(item, "status"        )
    self.VVwa50Data["exp_date"    ] = self.VV6hiq(item, "exp_date"    , isDate=True )
    self.VVwa50Data["is_trial"    ] = self.VV6hiq(item, "is_trial"        )
    self.VVwa50Data["active_cons"   ] = self.VV6hiq(item, "active_cons"       )
    self.VVwa50Data["created_at"   ] = self.VV6hiq(item, "created_at"   , isDate=True )
    self.VVwa50Data["max_connections"  ] = self.VV6hiq(item, "max_connections"      )
    self.VVwa50Data["allowed_output_formats"] = self.VV6hiq(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVwa50Data[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVwa50Data["url"    ] = self.VV6hiq(item, "url"        )
    self.VVwa50Data["port"    ] = self.VV6hiq(item, "port"        )
    self.VVwa50Data["https_port"  ] = self.VV6hiq(item, "https_port"      )
    self.VVwa50Data["server_protocol" ] = self.VV6hiq(item, "server_protocol"     )
    self.VVwa50Data["rtmp_port"   ] = self.VV6hiq(item, "rtmp_port"       )
    self.VVwa50Data["timezone"   ] = self.VV6hiq(item, "timezone"       )
    self.VVwa50Data["timestamp_now"  ] = self.VV6hiq(item, "timestamp_now"  , isDate=True )
    self.VVwa50Data["time_now"   ] = self.VV6hiq(item, "time_now"       )
    VVwSHr  = self.VVG7y8(True)
    OKBtnFnc = self.VVMAoN
    VVMcss = ("Home Menu", FFtWwG)
    VVoZDD= ("Add to Menu", BF(CCaayN.VVyi3Y, self, False, self.VVwa50Data["playListURL"]))
    VVWYuC = ("Bookmark Server", BF(CCaayN.VVKobU, self, False, self.VVwa50Data["playListURL"]))
    FFKX6p(self, None, title="IPTV Server Resources", VVwSHr=VVwSHr, OKBtnFnc=OKBtnFnc, VVMcss=VVMcss, VVoZDD=VVoZDD, VVWYuC=VVWYuC)
   else:
    err = "Could not get data from server !"
  if err:
   FFAvZA(self, err, title=title)
  FFMYB5(self)
 def VVMAoN(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFqXEj(menuInstance, BF(self.VVAPit, self.VV4VOZ  , title=title), title=wTxt)
   elif ref == "vod"   : FFqXEj(menuInstance, BF(self.VVAPit, self.VVR1Az  , title=title), title=wTxt)
   elif ref == "series"  : FFqXEj(menuInstance, BF(self.VVAPit, self.VVKr2f , title=title), title=wTxt)
   elif ref == "catchup"  : FFqXEj(menuInstance, BF(self.VVAPit, self.VVN68P , title=title), title=wTxt)
   elif ref == "accountInfo" : FFqXEj(menuInstance, BF(self.VVAkQ5           , title=title), title=wTxt)
 def VVAkQ5(self, title):
  rows = []
  for key, val in self.VVwa50Data.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VVEgWB
   else:
    num, part = "1", self.VVeit9
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVlNkE  = ("Home Menu", FFtWwG, [])
  VVcZtS  = None
  if VVpo5P:
   VVcZtS = ("Get JS" , BF(self.VVbTG1, "/".join(self.VVwa50Data["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFyLgY(self, None, title=title, width=1200, header=header, VVd40u=rows, VVLpvM=widths, VV2ql8=26, VVlNkE=VVlNkE, VVcZtS=VVcZtS, VVCNiH="#0a00292B", VVIhEb="#0a002126", VV9Ea0="#0a002126", VVZozG="#00000000", searchCol=2)
 def VV6Adq(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    VVkxWB = CClSwG()
    if mode in (self.VVQefs, self.VVgrGk):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VV6hiq(item, "num"         )
      name     = self.VV6hiq(item, "name"        )
      stream_id    = self.VV6hiq(item, "stream_id"       )
      stream_icon    = self.VV6hiq(item, "stream_icon"       )
      epg_channel_id   = self.VV6hiq(item, "epg_channel_id"      )
      added     = self.VV6hiq(item, "added"    , isDate=True )
      is_adult    = self.VV6hiq(item, "is_adult"       )
      category_id    = self.VV6hiq(item, "category_id"       )
      tv_archive    = self.VV6hiq(item, "tv_archive"       )
      direct_source   = self.VV6hiq(item, "direct_source"      )
      tv_archive_duration  = self.VV6hiq(item, "tv_archive_duration"     )
      name = VVkxWB.VVBiv6(name, is_adult)
      if name:
       if mode == self.VVQefs or mode == self.VVgrGk and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVC1pl:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VV6hiq(item, "num"         )
      name    = self.VV6hiq(item, "name"        )
      stream_id   = self.VV6hiq(item, "stream_id"       )
      stream_icon   = self.VV6hiq(item, "stream_icon"       )
      added    = self.VV6hiq(item, "added"    , isDate=True )
      is_adult   = self.VV6hiq(item, "is_adult"       )
      category_id   = self.VV6hiq(item, "category_id"       )
      container_extension = self.VV6hiq(item, "container_extension"     ) or "mp4"
      name = VVkxWB.VVBiv6(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VVNWLS:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VV6hiq(item, "num"        )
      name    = self.VV6hiq(item, "name"       )
      series_id   = self.VV6hiq(item, "series_id"      )
      cover    = self.VV6hiq(item, "cover"       )
      genre    = self.VV6hiq(item, "genre"       )
      episode_run_time = self.VV6hiq(item, "episode_run_time"    )
      category_id   = self.VV6hiq(item, "category_id"      )
      container_extension = self.VV6hiq(item, "container_extension"    ) or "mp4"
      name = VVkxWB.VVBiv6(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVAPit(self, mode, title):
  cList, err = self.VVCQoP(mode)
  if cList and mode == self.VVN68P:
   cList = self.VVAXeC(cList)
  if err:
   FFAvZA(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVCNiH, VVIhEb, VV9Ea0, VVZozG = self.VVph1O(mode)
   mName = self.VV7tAu(mode)
   if   mode == self.VV4VOZ  : fMode = self.VVQefs
   elif mode == self.VVR1Az  : fMode = self.VVC1pl
   elif mode == self.VVKr2f : fMode = self.VVNWLS
   elif mode == self.VVN68P : fMode = self.VVgrGk
   if mode == self.VVN68P:
    VVq3zo = None
    VVrIQY = None
   else:
    VVq3zo = ("Find in %s" % mName , BF(self.VVVpGi, fMode, True) , [])
    VVrIQY = ("Find in Selected" , BF(self.VVVpGi, fMode, False) , [])
   VVVt3G   = ("Show List"   , BF(self.VVRpXN, mode)  , [])
   VVlNkE  = ("Home Menu"   , FFtWwG         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFyLgY(self, None, title=title, width=1200, header=header, VVd40u=cList, VVLpvM=widths, VV2ql8=30, VVlNkE=VVlNkE, VVq3zo=VVq3zo, VVrIQY=VVrIQY, VVVt3G=VVVt3G, VVCNiH=VVCNiH, VVIhEb=VVIhEb, VV9Ea0=VV9Ea0, VVZozG=VVZozG, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFAvZA(self, "No list from server !", title=title)
  FFMYB5(self)
 def VVCQoP(self, mode):
  qUrl  = self.VVRQ38(mode, self.VVwa50Data["playListURL"])
  txt, err = self.VVokhy(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    VVkxWB = CClSwG()
    for item in tDict:
     category_id  = self.VV6hiq(item, "category_id"  )
     category_name = self.VV6hiq(item, "category_name" )
     parent_id  = self.VV6hiq(item, "parent_id"  )
     category_name = VVkxWB.VVQTrH(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVAXeC(self, catList):
  mode  = self.VVgrGk
  qUrl  = self.VVRQ38(mode, self.VVwa50Data["playListURL"])
  txt, err = self.VVokhy(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VV6Adq(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVRpXN(self, mode, VVl7Cx, title, txt, colList):
  title = colList[1]
  FFqXEj(VVl7Cx, BF(self.VVTzbE, mode, VVl7Cx, title, txt, colList), title="Downloading ...")
 def VVTzbE(self, mode, VVl7Cx, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VV7tAu(mode) + " : "+ bName
  if   mode == self.VV4VOZ  : mode = self.VVQefs
  elif mode == self.VVR1Az  : mode = self.VVC1pl
  elif mode == self.VVKr2f : mode = self.VVNWLS
  elif mode == self.VVN68P : mode = self.VVgrGk
  qUrl  = self.VVRQ38(mode, self.VVwa50Data["playListURL"], catID)
  txt, err = self.VVokhy(qUrl)
  list  = []
  if not err and mode in (self.VVQefs, self.VVC1pl, self.VVNWLS, self.VVgrGk):
   list, err = self.VV6Adq(mode, txt)
  if err:
   FFAvZA(self, err, title=title)
  elif list:
   VVlNkE  = ("Home Menu"   , FFtWwG            , [])
   if mode in (self.VVQefs, self.VVgrGk):
    VVCNiH, VVIhEb, VV9Ea0, VVZozG = self.VVph1O(mode)
    VV0QzM = (""     , BF(self.VVE77a, mode)      , [])
    VVcZtS = ("Download Options" , BF(self.VVxXDh, mode, "", "")   , [])
    VVq3zo = ("Options"   , BF(self.VV3TtO, "lv", mode, bName)   , [])
    VVrIQY = ("Posters Mode"  , BF(self.VVUru6, mode, False)     , [])
    if mode == self.VVQefs:
     VVVt3G = ("Play"    , BF(self.VVVRUc, mode)       , [])
    else:
     VVVt3G = ("Programs"   , BF(self.VVMJ31, mode, bName) , [])
   elif mode == self.VVC1pl:
    VVCNiH, VVIhEb, VV9Ea0, VVZozG = self.VVph1O(mode)
    VVVt3G  = ("Play"    , BF(self.VVVRUc, mode)       , [])
    VV0QzM = (""     , BF(self.VVE77a, mode)      , [])
    VVcZtS = ("Download Options" , BF(self.VVxXDh, mode, "v", "")   , [])
    VVq3zo = ("Options"   , BF(self.VV3TtO, "v", mode, bName)   , [])
    VVrIQY = ("Posters Mode"  , BF(self.VVUru6, mode, False)     , [])
   elif mode == self.VVNWLS:
    VVCNiH, VVIhEb, VV9Ea0, VVZozG = self.VVph1O("series2")
    VVVt3G  = ("Show Seasons"  , BF(self.VVT6Zq, mode)       , [])
    VV0QzM = (""     , BF(self.VVD0fJ, mode)     , [])
    VVcZtS = None
    VVq3zo = None
    VVrIQY = ("Posters Mode"  , BF(self.VVUru6, mode, True)      , [])
   header, widths, VVe5VU = self.VVGWJL(mode)
   FFyLgY(self, None, title=title, header=header, VVd40u=list, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVVt3G=VVVt3G, VVlNkE=VVlNkE, VVcZtS=VVcZtS, VVq3zo=VVq3zo, VVrIQY=VVrIQY, lastFindConfigObj=CFG.lastFindIptv, VV0QzM=VV0QzM, VVCNiH=VVCNiH, VVIhEb=VVIhEb, VV9Ea0=VV9Ea0, VVZozG=VVZozG, VV1YOp=True, searchCol=1)
  else:
   FFAvZA(self, "No Channels found !", title=title)
  FFMYB5(self)
 def VVGWJL(self, mode):
  if mode in (self.VVQefs, self.VVgrGk):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VVe5VU  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVC1pl:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VVe5VU  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VVNWLS:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VVe5VU  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VVe5VU
 def VVMJ31(self, mode, bName, VVl7Cx, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVwa50Data["playListURL"]
  ok_fnc  = BF(self.VVrx1o, hostUrl, chName, catId, streamId)
  FFqXEj(VVl7Cx, BF(CCaayN.VVT4Ch, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVrx1o(self, chUrl, chName, catId, streamId, VVl7Cx, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCaayN.VVh5Pt(chUrl)
   chNum = "333"
   refCode = CCaayN.VVe9M6(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFf8Q6(self, chUrl, VVIqkw=False)
   CCcojD.VVEI1u(self.session)
  else:
   FFAvZA(self, "Incorrect Timestamp", pTitle)
 def VVT6Zq(self, mode, VVl7Cx, title, txt, colList):
  title = colList[1]
  FFqXEj(VVl7Cx, BF(self.VVjx0F, mode, VVl7Cx, title, txt, colList), title="Downloading ...")
 def VVjx0F(self, mode, VVl7Cx, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVRQ38(self.VVtwFD, self.VVwa50Data["playListURL"], series_id)
  txt, err = self.VVokhy(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VV6hiq(tDict["info"], "name"   )
      category_id = self.VV6hiq(tDict["info"], "category_id" )
      icon  = self.VV6hiq(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      VVkxWB = CClSwG()
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VV6hiq(EP, "id"     )
        episode_num   = self.VV6hiq(EP, "episode_num"   )
        epTitle    = self.VV6hiq(EP, "title"     )
        container_extension = self.VV6hiq(EP, "container_extension" )
        seasonNum   = self.VV6hiq(EP, "season"    )
        epTitle = VVkxWB.VVBiv6(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFAvZA(self, err, title=title)
  elif list:
   VVlNkE = ("Home Menu"   , FFtWwG          , [])
   VVcZtS = ("Download Options" , BF(self.VVxXDh, mode, "s", title), [])
   VVq3zo = ("Options"   , BF(self.VV3TtO, "s", mode, title) , [])
   VVrIQY = ("Posters Mode"  , BF(self.VVUru6, mode, False)   , [])
   VV0QzM = (""     , BF(self.VVE77a, mode)    , [])
   VVVt3G  = ("Play"    , BF(self.VVVRUc, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVe5VU  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFyLgY(self, None, title=title, header=header, VVd40u=list, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVlNkE=VVlNkE, VVcZtS=VVcZtS, VVVt3G=VVVt3G, VV0QzM=VV0QzM, VVq3zo=VVq3zo, VVrIQY=VVrIQY, lastFindConfigObj=CFG.lastFindIptv, VVCNiH="#0a00292B", VVIhEb="#0a002126", VV9Ea0="#0a002126", VVZozG="#00000000")
  else:
   FFAvZA(self, "No Channels found !", title=title)
  FFMYB5(self)
 def VVVpGi(self, mode, isAll, VVl7Cx, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVwSHr = []
  VVwSHr.append(("Keyboard"  , "manualEntry"))
  VVwSHr.append(("From Filter" , "fromFilter"))
  FFKX6p(self, BF(self.VVr3Ir, VVl7Cx, mode, onlyCatID), title="Input Type", VVwSHr=VVwSHr, width=400)
 def VVr3Ir(self, VVl7Cx, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFJC4A(self, BF(self.VVbRcM, VVl7Cx, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CC6QfU(self)
    filterObj.VVefsy(BF(self.VVbRcM, VVl7Cx, mode, onlyCatID))
 def VVbRcM(self, VVl7Cx, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FFGxwH(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CC6QfU.VVfYn9(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FFAvZA(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FFAvZA(self, "All words must be at least 3 characters !", title=title)
        return
     VVkxWB = CClSwG()
     if CFG.hideIptvServerAdultWords.getValue() and VVkxWB.VVSYak(words):
      FFAvZA(self, VVkxWB.VVG6gq(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CCfZJl, barTheme=CCfZJl.VVZDZW
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVdetu, VVl7Cx, mode, onlyCatID, title, words, toFind, asPrefix, VVkxWB)
          , VVUStE = BF(self.VVKoTq, mode, toFind, title))
   if not words:
    FFMYB5(VVl7Cx, "Nothing to find !", 1500)
 def VVdetu(self, VVl7Cx, mode, onlyCatID, title, words, toFind, asPrefix, VVkxWB, VVvSz8):
  VVvSz8.VVO1nT(VVl7Cx.VVm6b9() if onlyCatID is None else 1)
  VVvSz8.VVwBP2 = []
  for row in VVl7Cx.VVBOVP():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVvSz8 or VVvSz8.isCancelled:
    return
   VVvSz8.VVPK2y(1)
   VVvSz8.VVBSm7(catName)
   qUrl  = self.VVRQ38(mode, self.VVwa50Data["playListURL"], catID)
   txt, err = self.VVokhy(qUrl)
   if not err:
    tList, err = self.VV6Adq(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = VVkxWB.VVBiv6(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       VVvSz8.VVwBP2.append(item)
 def VVKoTq(self, mode, toFind, title, VVbt6k, VVwBP2, threadCounter, threadTotal, threadErr):
  if VVwBP2:
   title = self.VV8bS5(mode, toFind)
   if mode == self.VVQefs or mode == self.VVC1pl:
    if mode == self.VVC1pl : typ = "v"
    else          : typ = ""
    bName   = CCaayN.VV4PiN(toFind)
    VVVt3G  = ("Play"     , BF(self.VVVRUc, mode)     , [])
    VVcZtS = ("Download Options" , BF(self.VVxXDh, mode, typ, "") , [])
    VVq3zo = ("Options"   , BF(self.VV3TtO, "fnd", mode, bName), [])
    VVrIQY = ("Posters Mode"  , BF(self.VVUru6, mode, False)   , [])
   elif mode == self.VVNWLS:
    VVVt3G  = ("Show Seasons"  , BF(self.VVT6Zq, mode)     , [])
    VVq3zo = None
    VVcZtS = None
    VVrIQY = ("Posters Mode"  , BF(self.VVUru6, mode, True)    , [])
   VV0QzM  = (""     , BF(self.VVE77a, mode)    , [])
   VVlNkE  = ("Home Menu"   , FFtWwG          , [])
   header, widths, VVe5VU = self.VVGWJL(mode)
   VVl7Cx = FFyLgY(self, None, title=title, header=header, VVd40u=VVwBP2, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVVt3G=VVVt3G, VVlNkE=VVlNkE, VVcZtS=VVcZtS, VVq3zo=VVq3zo, VVrIQY=VVrIQY, VV0QzM=VV0QzM, VVCNiH="#0a00292B", VVIhEb="#0a002126", VV9Ea0="#0a002126", VVZozG="#00000000", VV1YOp=True, searchCol=1)
   if not VVbt6k:
    FFMYB5(VVl7Cx, "Stopped" , 1000)
  else:
   if VVbt6k:
    FFAvZA(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVEHNO(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VVQefs, self.VVgrGk):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVC1pl:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FFGlcE(chName)
  url = self.VVwa50Data["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVh5Pt(url)
  refCode = self.VVe9M6(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVE77a(self, mode, VVl7Cx, title, txt, colList):
  FFqXEj(VVl7Cx, BF(self.VVKFbh, mode, VVl7Cx, title, txt, colList))
 def VVKFbh(self, mode, VVl7Cx, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVEHNO(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFQTAA(self, fncMode=CCnfxp.VVAR6g, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVD0fJ(self, mode, VVl7Cx, title, txt, colList):
  FFqXEj(VVl7Cx, BF(self.VVs8NB, mode, VVl7Cx, title, txt, colList))
 def VVs8NB(self, mode, VVl7Cx, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFQTAA(self, fncMode=CCnfxp.VVwR5T, chName=name, text=txt, picUrl=Cover)
 def VVUru6(self, mode, isSerNames, VVl7Cx, title, txt, colList):
  if   mode in ("itv"  , CCaayN.VVQefs, CCaayN.VVgrGk): category = "live"
  elif mode in ("vod"  , CCaayN.VVC1pl )          : category = "vod"
  elif mode in ("series" , CCaayN.VVNWLS)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VVQefs : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVgrGk : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVC1pl  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVNWLS : picCol, descCol, descTxt = 5, 0, "Season"
  FFqXEj(VVl7Cx, BF(self.session.open, CCG0qT, VVl7Cx, category, nameCol, picCol, descCol, descTxt))
 def VVxXDh(self, mode, typ, seriesName, VVl7Cx, title, txt, colList):
  VVwSHr = []
  isMulti = VVl7Cx.VVUCzo
  tot  = VVl7Cx.VVmvz4()
  if isMulti:
   if tot < 1:
    FFMYB5(VVl7Cx, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVwSHr.append(("Download %s PIcon%s" % (name, FFEOCn(tot)), "dnldPicons" ))
  if typ:
   VVwSHr.append(VVbzyo)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVwSHr.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVwSHr.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVwSHr.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCEgwO.VV84hj():
    VVwSHr.append(VVbzyo)
    VVwSHr.append(("Download Manager"      , "dload_stat" ))
  FFKX6p(self, BF(self.VVbB25, VVl7Cx, mode, typ, seriesName, colList), title="Download Options", VVwSHr=VVwSHr)
 def VVbB25(self, VVl7Cx, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVira2(VVl7Cx, mode)
   elif item == "dnldSel"  : self.VVDK7J(VVl7Cx, mode, typ, colList, True)
   elif item == "addSel"  : self.VVDK7J(VVl7Cx, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVZmfx(VVl7Cx, mode, typ, seriesName)
   elif item == "dload_stat" : CCEgwO.VVloZW(self)
 def VVDK7J(self, VVl7Cx, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVRkMz(mode, typ, colList)
  if startDnld:
   CCEgwO.VV3DSl(self, decodedUrl)
  else:
   self.VVtfKV(VVl7Cx, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVZmfx(self, VVl7Cx, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVl7Cx.VVBOVP():
   chName, decodedUrl = self.VVRkMz(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVtfKV(VVl7Cx, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVtfKV(self, VVl7Cx, title, chName, decodedUrl_list, startDnld):
  FFOjga(self, BF(self.VVJhbq, VVl7Cx, decodedUrl_list, startDnld), chName, title=title)
 def VVJhbq(self, VVl7Cx, decodedUrl_list, startDnld):
  added, skipped = CCEgwO.VVe5Q6(decodedUrl_list)
  FFMYB5(VVl7Cx, "Added", 1000)
 def VVRkMz(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVEHNO(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVY6sZ(mode, colList)
   refCode, chUrl = self.VVhsnx(self.VVAWkd, self.VVsRGc, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFuK1e(chUrl)
  return chName, decodedUrl
 def VVira2(self, VVl7Cx, mode):
  if os.system(FFlWZ0("which ffmpeg")) == 0:
   self.session.open(CCfZJl, barTheme=CCfZJl.VVBjE0
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVritD, VVl7Cx, mode)
       , VVUStE = self.VV9DbT)
  else:
   FFOjga(self, BF(CCaayN.VVz8nj, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VV9DbT(self, VVbt6k, VVwBP2, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVwBP2["proces"], VVwBP2["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVwBP2["ok"], VVwBP2["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVwBP2["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVwBP2["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVwBP2["badURL"]
  txt += "Download Failure\t: %d\n"   % VVwBP2["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVwBP2["path"]
  if not VVbt6k  : color = "#11402000"
  elif VVwBP2["err"]: color = "#11201000"
  else     : color = None
  if VVwBP2["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVwBP2["err"], txt)
  title = "PIcons Download Result"
  if not VVbt6k:
   title += "  (cancelled)"
  FFheEQ(self, txt, title=title, VV9Ea0=color)
 def VVritD(self, VVl7Cx, mode, VVvSz8):
  isMulti = VVl7Cx.VVUCzo
  if isMulti : totRows = VVl7Cx.VVmvz4()
  else  : totRows = VVl7Cx.VVm6b9()
  VVvSz8.VVO1nT(totRows)
  VVvSz8.VVVXid(0)
  counter     = VVvSz8.counter
  maxValue    = VVvSz8.maxValue
  pPath     = CCVrfy.VVNV04()
  VVvSz8.VVwBP2 = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for rowNum, row in enumerate(VVl7Cx.VVBOVP()):
    if VVvSz8.isCancelled:
     break
    if not isMulti or VVl7Cx.VVU8qn(rowNum):
     VVvSz8.VVwBP2["proces"] += 1
     VVvSz8.VVPK2y(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVY6sZ(mode, row)
      refCode = CCaayN.VVe9M6(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVsx3d(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVEHNO(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVvSz8.VVwBP2["attempt"] += 1
       path, err = FF8zMR(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVvSz8:
         VVvSz8.VVwBP2["ok"] += 1
         VVvSz8.VVVXid(VVvSz8.VVwBP2["ok"])
        if FFtd04(path) > 0:
         cmd = CCnfxp.VVxhyv(path)
         cmd += FFlWZ0("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         if VVvSz8:
          VVvSz8.VVwBP2["size0"] += 1
         FFblrr(path)
       elif err:
        if VVvSz8:
         VVvSz8.VVwBP2["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVvSz8:
          VVvSz8.VVwBP2["err"] = err.title()
         break
      else:
       if VVvSz8:
        VVvSz8.VVwBP2["exist"] += 1
     else:
      if VVvSz8:
       VVvSz8.VVwBP2["badURL"] += 1
  except:
   pass
 def VVsQT8(self):
  title = "Download PIcons for Current Bouquet"
  if os.system(FFlWZ0("which ffmpeg")) == 0:
   self.session.open(CCfZJl, barTheme=CCfZJl.VVBjE0
       , titlePrefix = ""
       , fncToRun  = self.VVqJvZ
       , VVUStE = BF(self.VVNesz, title))
  else:
   FFOjga(self, BF(CCaayN.VVz8nj, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VVqJvZ(self, VVvSz8):
  bName = CCCBMo.VVTC7K()
  pPath = CCVrfy.VVNV04()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVvSz8.VVwBP2 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CCCBMo.VV1MWD()
  if not VVvSz8 or VVvSz8.isCancelled:
   return
  if not services or len(services) == 0:
   VVvSz8.VVwBP2 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVvSz8.VVO1nT(totCh)
  VVvSz8.VVVXid(0)
  for serv in services:
   if not VVvSz8 or VVvSz8.isCancelled:
    return
   VVvSz8.VVwBP2 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVvSz8.VVPK2y(1)
   VVvSz8.VVVXid(totPic)
   fullRef  = serv[0]
   if FFNWS8(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFuK1e(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CCcf6M.VVSD0s(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CCaayN.VVBGRU(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInv += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCaayN.VVokhy(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CCnfxp.VVc46z(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FF8zMR(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVvSz8:
     VVvSz8.VVVXid(totPic)
    if FFtd04(path) > 0:
     cmd = CCnfxp.VVxhyv(path)
     cmd += FFlWZ0("mv -f '%s' '%s'" % (path, pPath)) + ";"
     os.system(cmd)
     totPicOK += 1
    else:
     totSize0
     FFblrr(path)
  if VVvSz8:
   VVvSz8.VVwBP2 = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVNesz(self, title, VVbt6k, VVwBP2, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVwBP2
  if err:
   FFAvZA(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FFNkac(str(totExist)  , VVHKA4)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFNkac(str(totNotIptv)  , VVHKA4)
    if totServErr : txt += "Server Errors\t: %s\n" % FFNkac(str(totServErr) + t1, VVHKA4)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FFNkac(str(totParseErr) , VVHKA4)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FFNkac(str(totInvServ)  , VVHKA4)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FFNkac(str(totInvPicUrl) , VVHKA4)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FFNkac(str(totSize0)  , VVHKA4)
   if not VVbt6k:
    title += "  (stopped)"
   FFheEQ(self, txt, title=title)
 @staticmethod
 def VVz8nj(SELF):
  cmd = FFtNvi(VVJBI8, "ffmpeg")
  if cmd : FFCHwU(SELF, cmd, title="Installing FFmpeg")
  else : FF0QO3(SELF)
 def VVVKF9(self):
  self.session.open(CCfZJl, barTheme=CCfZJl.VVBjE0
      , titlePrefix = ""
      , fncToRun  = self.VVUWkj
      , VVUStE = self.VVomfF)
 def VVUWkj(self, VVvSz8):
  bName = CCCBMo.VVTC7K()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVvSz8.VVwBP2 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CCCBMo.VV1MWD()
  if not VVvSz8 or VVvSz8.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVvSz8.VVO1nT(totCh)
   for serv in services:
    if not VVvSz8 or VVvSz8.isCancelled:
     return
    VVvSz8.VVPK2y(1)
    fullRef = serv[0]
    if FFNWS8(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFuK1e(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     if span:
      valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CCcf6M.VVSD0s(decodedUrl)
      if valid and mode == "itv" : uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
      else      : uHost = uUser = uPass = uId = uChName = ""
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCaayN.VVBGRU(m3u_Url)
     if VVvSz8:
      VVvSz8.VVE03S(totEpgOK, uChName)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCaayN.VVgYB2(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCnfxp.VVHist(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if VVvSz8:
     VVvSz8.VVwBP2 = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVvSz8.VVwBP2 = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VVomfF(self, VVbt6k, VVwBP2, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVwBP2
  title = "IPTV EPG Import"
  if err:
   FFAvZA(self, err, title=title)
  else:
   if VVbt6k and totEpgOK > 0:
    CCwlDM.VVQqzH()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFNkac(str(totNotIptv), VVHKA4)
    if totServErr : txt += "Server Errors\t: %s\n" % FFNkac(str(totServErr) + t1, VVHKA4)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFNkac(str(totInv), VVHKA4)
   if not VVbt6k:
    title += "  (stopped)"
   FFheEQ(self, txt, title=title)
 @staticmethod
 def VVgYB2(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCaayN.VVh5Pt(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCaayN.VVokhy(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCaayN.VV6hiq(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CCaayN.VV6hiq(item, "lang"        ).upper()
    now_playing   = CCaayN.VV6hiq(item, "now_playing"      )
    start    = CCaayN.VV6hiq(item, "start"        )
    start_timestamp  = CCaayN.VV6hiq(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCaayN.VV6hiq(item, "start_timestamp"     )
    stop_timestamp  = CCaayN.VV6hiq(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCaayN.VV6hiq(item, "stop_timestamp"      )
    tTitle    = CCaayN.VV6hiq(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVe9M6(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCaayN.VVeYhy(catID, MAX_4b)
  TSID = CCaayN.VVeYhy(chNum, MAX_4b)
  ONID = CCaayN.VVeYhy(chNum, MAX_4b)
  NS  = CCaayN.VVeYhy(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVeYhy(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VV4PiN(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVph1O(mode):
  if   mode in ("itv"  , CCaayN.VV4VOZ)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCaayN.VVR1Az)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCaayN.VVKr2f) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCaayN.VVN68P) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCaayN.VVgrGk    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVAZrI(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVk7lM:
   excl = FFaJMY(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFAvZA(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFIsyt('find %s %s %s' % (path, excl, par))
  if not files:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFAvZA(self, err)
  elif len(files) == 1 and files[0] == VVQZPP:
   FFAvZA(self, VVQZPP)
  else:
   return files
 @staticmethod
 def VVxHN4():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FFThW1(path)
  return "/"
 @staticmethod
 def VVT4Ch(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CCaayN.VVgYB2(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FFAvZA(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVCNiH, VVIhEb, VV9Ea0, VVZozG = CCaayN.VVph1O("")
   VVlNkE = ("Home Menu" , FFtWwG, [])
   VVVt3G  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVe5VU  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFyLgY(SELF, None, title="Programs for : " + chName, header=header, VVd40u=pList, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=24, VVVt3G=VVVt3G, VVlNkE=VVlNkE, VVCNiH=VVCNiH, VVIhEb=VVIhEb, VV9Ea0=VV9Ea0, VVZozG=VVZozG)
  else:
   FFAvZA(SELF, "No Programs from server", title=title)
 @staticmethod
 def VV2pD7(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VVyi3Y(self, isPortal, line, VVZPLhObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FFOjga(self, BF(self.VVAIdP, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FFGxwH(confItem, line)
   FF6b7h(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VVAIdP(self, title, confItem):
  FFGxwH(confItem, "")
  FF6b7h(self, "Removed from IPTV Menu.", title=title)
 def VVjuR4(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VVcT5J(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FFqXEj(self, BF(self.VVbDLe, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FFAvZA(self, "Incorrect server data !")
 @staticmethod
 def VVKobU(SELF, isPortal, line, VVZPLhObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCaayN.VVxHN4()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFAvZA(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FF6b7h(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFAvZA(SELF, "Error:\n\n%s" % str(e), title=title)
 def VV3TtO(self, source, mode, curBName, VVl7Cx, title, txt, colList):
  isMulti = VVl7Cx.VVUCzo
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVl7Cx.VVmvz4()
   totTxt = "%d Service%s" % (tot, FFEOCn(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FFNkac(totTxt, VVXaO9)
  mSel = CCEd9P(self, VVl7Cx, addSep=False)
  VVwSHr, cbFncDict = [], None
  VVwSHr.append(VVbzyo)
  if itemsOK:
   VVwSHr.append(("Add %s to New Bouquet : %s" % (totTxt, FFNkac(curBName, VV80BT)), "addToCur"))
   VVwSHr.append(("Add %s to Other Bouquet ..." % (totTxt)          , "addToNew"))
   cbFncDict = { "addToCur": BF(FFqXEj, mSel.VVl7Cx, BF(self.VV7tCq,source, mode, curBName, VVl7Cx, title), title="Adding Services ...")
      , "addToNew": BF(self.VVo8oI, source, mode, curBName, VVl7Cx, title)
      }
  else:
   VVwSHr.append(("Add to Bouquet (nothing selected)", ))
  mSel.VV5TZ4(VVwSHr, cbFncDict)
 def VV7tCq(self, source, mode, curBName, VVl7Cx, Title):
  chUrlLst = self.VVq4ph(source, mode, VVl7Cx)
  CCCBMo.VVnLWk(self, Title, curBName, "", chUrlLst)
 def VVo8oI(self, source, mode, curBName, VVl7Cx, Title):
  picker = CCCBMo(self, VVl7Cx, Title, BF(self.VVq4ph, source, mode, VVl7Cx), defBName=curBName)
 def VVq4ph(self, source, mode, VVl7Cx):
  totChange = 0
  isMulti = VVl7Cx.VVUCzo
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVl7Cx.VVBOVP()):
   if not isMulti or VVl7Cx.VVU8qn(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVY6sZ(mode, row)
     refCode, chUrl = self.VVhsnx(self.VVAWkd, self.VVsRGc, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VVurgs(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVEHNO(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
class CCG0qT(Screen):
 def __init__(self, session, VVl7Cx, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FFheJw(VV752q, 1870, 1030, 50, 10, 10, "#33000000", "#33000000", 50, topRightBtns=2)
  self.session   = session
  self.Title    = "Server Browser"
  FFqVmU(self, self.Title)
  self.VVl7Cx  = VVl7Cx
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.TOTAL_ROWS   = 2
  self.TOTAL_COLS   = 6
  self.PAGE_PICTURE  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.VVd40u    = []
  self.totPosterUrls  = 0
  self.totalChannels  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVhL6f, subPath)
  if not pathExists(self.pPath):
   os.system(FFlWZ0("mkdir -p '%s'" % (self.pPath)))
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  for i in range(4):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVmBrJ   ,
   "cancel"  : self.close   ,
   "menu"   : self.VVkFdX,
   "info"   : self.VVO42Z ,
   "up"   : self.VVRmh5    ,
   "down"   : self.VVThvL   ,
   "left"   : self.VVXUAo   ,
   "right"   : self.VVaQKG   ,
   "next"   : self.VVA4xu  ,
   "last"   : self.VVimMN
  }, -1)
  self.onShown.append(self.VVevf4)
  self.onClose.append(self.onExit)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  FFuN11(self)
  FFBmK5(self)
  self.VVGCwM()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVkFdX(self):
  VVwSHr = []
  VVwSHr.append(("Show Poster/PIcon"      , "VVgKXp"   ))
  VVwSHr.append(("Copy Poster/PIcon to Export-Directory" , "VVhUbM"  ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Cache details"       , "VVTLNT" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Change Poster/Picon Transparency Color" , "VVf9bj" ))
  FFKX6p(self, self.VVpYjj, title=self.Title, VVwSHr=VVwSHr)
 def VVpYjj(self, item=None):
  if item is not None:
   if   item == "VVhUbM"   : self.VVhUbM()
   elif item == "VVgKXp"   : self.VVgKXp()
   elif item == "VVTLNT"  : FFqXEj(self, self.VVTLNT, title="Calculating ...")
   elif item == "VVf9bj" : self.VVf9bj()
 def VVmBrJ(self):
  self.VVl7Cx.VVm16r(self.curIndex)
  self.VVl7Cx.VViOwa()
 def VVO42Z(self):
  self.VVl7Cx.VVm16r(self.curIndex)
  self.VVl7Cx.VVbfxA()
 def VVf9bj(self):
  fg = bg = CFG.transpColorPosters.getValue()
  self.session.openWithCallback(self.VVcSXf, CC6XYk, defFG=fg, defBG=bg, onlyBG=True)
 def VVcSXf(self, fg, bg):
  if bg:
   FFGxwH(CFG.transpColorPosters, bg)
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FFAMY6(self["myPosterRep%d%d" % (row, col)], bg)
 def VVGCwM(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
    self["myPosterLbl%d%d" % (row, col)].instance.setNoWrap(True)
  for colList in self.VVl7Cx.VVBOVP():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = os.path.basename(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VVd40u.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalChannels = len(self.VVd40u)
  self.totalPages  = int(self.totalChannels / self.PAGE_PICTURE) + (self.totalChannels % self.PAGE_PICTURE > 0)
  self.VVsllS(True)
  self.VVkiqT(self.VVl7Cx.VVf913())
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV5XNf)
  except:
   self.timer.callback.append(self.VV5XNf)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VVswCc)
  self.myThread.start()
 def VVswCc(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VVd40u):
    if not self.stopThread:
     if picUrl and not fName:
      fName = os.path.basename(picUrl)
      path, err = FF8zMR(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       os.system(FFlWZ0("mv -f '%s' '%s'" % (path, self.pPath + fName)))
       self.VVd40u[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VV5XNf(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VV0rNQ + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalChannels
  f1 = self.curPage * self.PAGE_PICTURE
  f2 = f1 + self.PAGE_PICTURE
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVd40u[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VVd40u[ndx] = (chName, subj, desc, fName, "")
     try:
      self.VVGe9T(self["myPosterPic%d%d" % (row, col)], path)
     except:
      pass
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVK0Ny(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
  last = self.totalChannels
  f1 = self.curPage * self.PAGE_PICTURE
  f2 = f1 + self.PAGE_PICTURE
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVd40u[ndx]
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.setText(chName)
   lbl.show()
   pic.show()
   path = ""
   if fName:
    path = self.pPath + fName
   if not fileExists(path):
    path = VVdSQY + "iptv.png"
   try:
    self.VVGe9T(pic, path)
    pic.show()
   except:
    pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVGe9T(self, pixObj, path):
  if path.endswith(".png"):
   pixObj.instance.setPixmapFromFile(path)
  else:
   png = LoadPixmap(path)
   pixObj.instance.setScale(1)
   pixObj.instance.setPixmap(png)
 def VVsllS(self, force=False):
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VV5jH7 = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VV5jH7: self.curPage = VV5jH7
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVK0Ny()
  if self.curPage == VV5jH7:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPosterPic%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICTURE + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVpBhv()
  chName, subj, desc, fName, picUrl = self.VVd40u[self.curIndex]
 def VVpBhv(self):
  chName, subj, desc, fName, picUrl = self.VVd40u[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalChannels))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVRmh5(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VViqaH()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVsllS()
 def VVThvL(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVx4GG()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVsllS()
 def VVXUAo(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VViqaH()
  else:
   self.curCol -= 1
   self.VVsllS()
 def VVaQKG(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVx4GG()
  else:
   self.curCol += 1
   self.VVsllS()
 def VVimMN(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVsllS(True)
 def VVA4xu(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVsllS(True)
 def VVx4GG(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVsllS(True)
 def VViqaH(self):
  self.curPage = self.totalPages - 1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVsllS(True)
 def VVkiqT(self, ndx):
  self.curPage = int(ndx / self.PAGE_PICTURE)
  ndx     -= self.curPage * self.PAGE_PICTURE
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VVsllS(True)
 def VVgKXp(self):
  chName, subj, desc, fName, picUrl = self.VVd40u[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CC1AR1.VVkxof(self, self.pPath + fName)
  else          : FFMYB5(self, "File not found", 1500)
 def VVhUbM(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VVd40u[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   res = os.system(FFlWZ0("cp -f '%s' '%s'" % (self.pPath + fName, dstF)))
   if res == 0 : FF6b7h(self, "File copied to:\n\n%s" % dstF, title=title)
   else  : FFAvZA(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FFAvZA(self, "No Poster/PIcon found", title=title)
 def VVTLNT(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVhL6f, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FFnz9X("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CCeH84.VVpYrc(size)
   txt += "%s\n    %s\n\n" % (FFNkac(path, VVXaO9), size)
  mainPath = "%sPosters" % VVhL6f
  totFiles = FFnz9X("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FFEOCn(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FFNkac("Total space used by Posters/PIcons%s:" % totFTxt, VVSqFX), CCeH84.VVpYrc(totSize))
  mountPath = CCeH84.VVDVh3(mainPath)
  if pathExists(mountPath):
   totSize  = CCeH84.VVIY6h(mountPath)
   freeSize = CCeH84.VVkvYz(mountPath)
   usedSize = CCeH84.VVpYrc(totSize - freeSize)
   totSize  = CCeH84.VVpYrc(totSize)
   freeSize = CCeH84.VVpYrc(freeSize)
   txt += "%s\n" % VVStMY
   txt += FFNkac("Media Space:\n", VVhTQL)
   txt += "    Media Path\t: %s\n" % FFNkac(mountPath, VVtjbM)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FFheEQ(self, txt, title="Cache Used Size", height=1000)
class CCY9K8(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFheJw(VVXQaf, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVVh2a  = 0
  self.VVsiPx = 1
  self.VVdKrR  = 2
  VVwSHr = []
  VVwSHr.append(("Find in All Service (from filter)" , "VV769y" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Find in All (Manual Entry)"   , "VVxDKf"    ))
  VVwSHr.append(("Find in TV"       , "VVuCFu"    ))
  VVwSHr.append(("Find in Radio"      , "VVsRMp"   ))
  if self.VVw4YR():
   VVwSHr.append(VVbzyo)
   VVwSHr.append(("Hide Channel: %s" % self.servName , "VVU2z5"   ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Zap History"       , "VVrcHQ"    ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("IPTV Tools"       , "iptv"      ))
  VVwSHr.append(("PIcons Tools"       , "PIconsTools"     ))
  VVwSHr.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FFqVmU(self, VVwSHr=VVwSHr, title=title)
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  FFpkQc(self["myMenu"])
  FFQGfp(self)
  if self.isFindMode:
   self.VVko5K(self.VV9rXU())
 def VVmBrJ(self):
  global VVLQSn
  VVLQSn = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVxDKf"    : self.VVxDKf()
   elif item == "VV769y" : self.VV769y()
   elif item == "VVuCFu"    : self.VVuCFu()
   elif item == "VVsRMp"   : self.VVsRMp()
   elif item == "VVU2z5"   : self.VVU2z5()
   elif item == "VVrcHQ"    : self.VVrcHQ()
   elif item == "iptv"       : self.session.open(CCaayN)
   elif item == "PIconsTools"     : self.session.open(CCVrfy)
   elif item == "ChannelsTools"    : self.session.open(CCKtc8)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVuCFu(self) : self.VVko5K(self.VVVh2a)
 def VVsRMp(self) : self.VVko5K(self.VVsiPx)
 def VVxDKf(self) : self.VVko5K(self.VVdKrR)
 def VVko5K(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFJC4A(self, BF(self.VVc8Pe, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VV769y(self):
  filterObj = CC6QfU(self)
  filterObj.VVefsy(self.VVyltj)
 def VVyltj(self, item):
  self.VVc8Pe(self.VVdKrR, item)
 def VVw4YR(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFNWS8(self.refCode)        : return False
  return True
 def VVc8Pe(self, mode, VVOnV4):
  FFqXEj(self, BF(self.VVK7IV, mode, VVOnV4), title="Searching ...")
 def VVK7IV(self, mode, VVOnV4):
  if VVOnV4:
   VVOnV4 = VVOnV4.strip()
  if VVOnV4:
   self.findTxt = VVOnV4
   CFG.lastFindContextFind.setValue(VVOnV4)
   if   mode == self.VVVh2a  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVsiPx : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVOnV4)
   if len(title) > 55:
    title = title[:55] + ".."
   VVmJ2p = self.VVpkXE(VVOnV4, servTypes)
   if self.isFindMode or mode == self.VVdKrR:
    VVmJ2p += self.VVtCs3(VVOnV4)
   if VVmJ2p:
    VVmJ2p.sort(key=lambda x: x[0].lower())
    VVPypB = self.VVPhCH
    VVVt3G  = ("Zap"   , self.VVBqLJ    , [])
    VVcZtS = ("Current Service", self.VVe9bG , [])
    VVq3zo = ("Options"  , self.VVPafw , [])
    VV0QzM = (""    , self.VVvrJu , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVe5VU  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFyLgY(self, None, title=title, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVVt3G=VVVt3G, VVPypB=VVPypB, VVcZtS=VVcZtS, VVq3zo=VVq3zo, VV0QzM=VV0QzM, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVko5K(self.VV9rXU())
    FF6b7h(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVpkXE(self, VVOnV4, servTypes):
  VVd40u = CCKtc8.VVsGi1(servTypes)
  VVmJ2p = []
  if VVd40u:
   VVwBvo, VV9WSF = FFXZbX()
   tp = CCpEt4()
   words, asPrefix = CC6QfU.VVfYn9(VVOnV4)
   colorYellow  = CC7nVY.VVnDoL(VVSqFX)
   colorWhite  = CC7nVY.VVnDoL(VV1R4z)
   for s in VVd40u:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFfCA9(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVwBvo:
        STYPE = VV9WSF[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVn847(refCode)
       if not "-S" in syst:
        sat = syst
       VVmJ2p.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVmJ2p
 def VVtCs3(self, VVOnV4):
  VVOnV4 = VVOnV4.lower()
  VVmJ2p = []
  colorYellow  = CC7nVY.VVnDoL(VVSqFX)
  colorWhite  = CC7nVY.VVnDoL(VV1R4z)
  for b in CCCBMo.VVC1BJ():
   VV10Wd  = b[0]
   VVF57Z  = b[1].toString()
   VVSMPM = eServiceReference(VVF57Z)
   VVfQIA = FFyIuW(VVSMPM)
   for service in VVfQIA:
    refCode  = service[0]
    if FFNWS8(refCode):
     servName = service[1]
     if VVOnV4 in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVOnV4), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVmJ2p.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVmJ2p
 def VV9rXU(self):
  VVreUe = InfoBar.instance
  if VVreUe:
   VVjitm = VVreUe.servicelist
   if VVjitm:
    return VVjitm.mode == 1
  return self.VVdKrR
 def VVPhCH(self, VVl7Cx):
  self.close()
  VVl7Cx.cancel()
 def VVBqLJ(self, VVl7Cx, title, txt, colList):
  FFf8Q6(VVl7Cx, colList[2], VVIqkw=False, checkParentalControl=True)
 def VVe9bG(self, VVl7Cx, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(VVl7Cx)
  if refCode:
   VVl7Cx.VVjNJH(2, FF2ErX(refCode, iptvRef, chName), True)
 def VVPafw(self, VVl7Cx, title, txt, colList):
  servName = colList[0]
  mSel = CCEd9P(self, VVl7Cx)
  VVwSHr, cbFncDict = CCKtc8.VV7R7I(self, VVl7Cx, servName, 2)
  mSel.VV5TZ4(VVwSHr, cbFncDict)
 def VVvrJu(self, VVl7Cx, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFQTAA(self, fncMode=CCnfxp.VV40Xm, refCode=refCode, chName=chName, text=txt)
 def VVU2z5(self):
  FFOjga(self, self.VVOnph, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVOnph(self):
  ret = FFxJPq(self.refCode, True)
  if ret:
   self.VVLeto()
   self.close()
  else:
   FFMYB5(self, "Cannot change state" , 1000)
 def VVLeto(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVjDBr()
  except:
   self.VV8WcC()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFft24(self, serviceRef)
 def VVjDBr(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVreUe = InfoBar.instance
   if VVreUe:
    VVjitm = VVreUe.servicelist
    if VVjitm:
     hList = VVjitm.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVjitm.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVjitm.history  = newList
       VVjitm.history_pos = pos
 def VV8WcC(self):
  VVreUe = InfoBar.instance
  if VVreUe:
   VVjitm = VVreUe.servicelist
   if VVjitm:
    VVjitm.history  = []
    VVjitm.history_pos = 0
 def VVrcHQ(self):
  VVreUe = InfoBar.instance
  VVmJ2p = []
  if VVreUe:
   VVjitm = VVreUe.servicelist
   if VVjitm:
    VVwBvo, VV9WSF = FFXZbX()
    for serv in VVjitm.history:
     refCode = serv[-1].toString()
     chName = FFHIlX(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FFNWS8(refCode)
     if   isIptv or isLocal : sat = "-"
     else     : sat = FFfCA9(refCode, True)
     if isIptv : STYPE = "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVwBvo:
       STYPE = VV9WSF[sTypeInt]
     VVmJ2p.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVmJ2p:
   VVVt3G  = ("Zap"   , self.VVnjOl   , [])
   VVq3zo = ("Clear History" , self.VV9oQ3   , [])
   VV0QzM = (""    , self.VV6cbW , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVe5VU  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFyLgY(self, None, title=title, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=28, VVVt3G=VVVt3G, VVq3zo=VVq3zo, VV0QzM=VV0QzM)
  else:
   FF6b7h(self, "Not found", title=title)
 def VVnjOl(self, VVl7Cx, title, txt, colList):
  FFf8Q6(VVl7Cx, colList[3], VVIqkw=False, checkParentalControl=True)
 def VV9oQ3(self, VVl7Cx, title, txt, colList):
  FFOjga(self, BF(self.VVo44j, VVl7Cx), "Clear Zap History ?")
 def VVo44j(self, VVl7Cx):
  self.VV8WcC()
  VVl7Cx.cancel()
 def VV6cbW(self, VVl7Cx, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFQTAA(self, fncMode=CCnfxp.VVHO2a, refCode=refCode, chName=chName, text=txt)
class CCVrfy(Screen):
 VVvHiO   = 0
 VVaKYs  = 1
 VV4XgY  = 2
 VV7Rpd  = 3
 VVfYtd  = 4
 VV6Aht  = 5
 VVgGxp  = 6
 VVSMHJ  = 7
 VVtD1u = 8
 VVGVoQ = 9
 VV3TeQ = 10
 VV0DEB = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFheJw(VV4xIc, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFqVmU(self, self.Title)
  FFTGpi(self["keyRed"] , "OK = Zap")
  FFTGpi(self["keyGreen"] , "Current Service")
  FFTGpi(self["keyYellow"], "Page Options")
  FFTGpi(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCVrfy.VVNV04()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVd40u    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVyjCn     ,
   "green"   : self.VVombX    ,
   "yellow"  : self.VVqbJM     ,
   "blue"   : self.VVMeQC     ,
   "menu"   : self.VV7bp9     ,
   "info"   : self.VVgtzi    ,
   "up"   : self.VVRmh5       ,
   "down"   : self.VVThvL      ,
   "left"   : self.VVXUAo      ,
   "right"   : self.VVaQKG      ,
   "pageUp"  : BF(self.VVoX8p, True) ,
   "chanUp"  : BF(self.VVoX8p, True) ,
   "pageDown"  : BF(self.VVoX8p, False) ,
   "chanDown"  : BF(self.VVoX8p, False) ,
   "next"   : self.VVA4xu     ,
   "last"   : self.VVimMN      ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  FFuN11(self)
  FFBmK5(self)
  FFAMY6(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
    self["myPosterLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFqXEj(self, BF(self.VVODOG, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VV7bp9(self):
  if not self.isBusy:
   VVwSHr = []
   VVwSHr.append(("Statistics"           , "VVOw8k"    ))
   VVwSHr.append(VVbzyo)
   VVwSHr.append(("Suggest PIcons for Current Channel"     , "VV5BiN"   ))
   VVwSHr.append(("Set to Current Channel (copy file)"     , "VV68g3_file"  ))
   VVwSHr.append(("Set to Current Channel (as SymLink)"     , "VV68g3_link"  ))
   VVwSHr.append(VVbzyo)
   VVwSHr.append(("Export Current File Names List"      , "VVCIOP" ))
   VVwSHr.append(CCVrfy.VVW9HU())
   VVwSHr.append(VVbzyo)
   movTxt = "Move Unused PIcons to a Directory"
   delTxt = "DELETE Unused PIcons"
   if self.filterTitle == "PIcons without Channels":
    c = VVmIAH
    VVwSHr.append((c + movTxt           , "VV2djj"  ))
    VVwSHr.append((c + delTxt           , "VV6vQc" ))
   else:
    disTxt = " (Filter >> Unused PIcons)"
    VVwSHr.append((movTxt + disTxt         ,       ))
    VVwSHr.append((delTxt + disTxt         ,       ))
   VVwSHr.append(VVbzyo)
   VVwSHr.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVHw44"  ))
   VVwSHr.append(VVbzyo)
   VVwSHr += CCVrfy.VV2gmI()
   VVwSHr.append(VVbzyo)
   VVwSHr.append(("Change Poster/Picon Transparency Color"    , "VVf9bj"  ))
   VVwSHr.append(("Keys Help"           , "VVNHlE"    ))
   FFKX6p(self, self.VVJ47T, width=1100, height=1050, title=self.Title, VVwSHr=VVwSHr)
 def VVJ47T(self, item=None):
  if item is not None:
   if   item == "VVOw8k"     : self.VVOw8k()
   elif item == "VV5BiN"    : self.VV5BiN()
   elif item == "VV68g3_file"   : self.VV68g3(0)
   elif item == "VV68g3_link"   : self.VV68g3(1)
   elif item == "VVCIOP"   : self.VVCIOP()
   elif item == "VVdLtF"   : CCVrfy.VVdLtF(self)
   elif item == "VV2djj"    : self.VV2djj()
   elif item == "VV6vQc"   : self.VV6vQc()
   elif item == "VVHw44"   : self.VVHw44()
   elif item == "VVbFW1"   : CCVrfy.VVbFW1(self)
   elif item == "findPiconBrokenSymLinks"  : CCVrfy.VVzqlw(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCVrfy.VVzqlw(self, False)
   elif item == "VVf9bj"   : self.VVf9bj()
   elif item == "VVNHlE"      : self.VVNHlE()
 def VVqbJM(self):
  if not self.isBusy:
   VVwSHr = []
   VVwSHr.append(("Go to First PIcon"  , "VVx4GG"  ))
   VVwSHr.append(("Go to Last PIcon"   , "VViqaH"  ))
   VVwSHr.append(VVbzyo)
   VVwSHr.append(("Sort by Channel Name"     , "sortByChan" ))
   VVwSHr.append(("Sort by File Name"  , "sortByFile" ))
   VVwSHr.append(VVbzyo)
   VVwSHr.append(("Find from File List .." , "VVmDBI" ))
   FFKX6p(self, self.VVoMJQ, title=self.Title, VVwSHr=VVwSHr)
 def VVoMJQ(self, item=None):
  if item is not None:
   if   item == "VVx4GG"   : self.VVx4GG()
   elif item == "VViqaH"   : self.VViqaH()
   elif item == "sortByChan"  : self.VVGQNY(2)
   elif item == "sortByFile"  : self.VVGQNY(0)
   elif item == "VVmDBI"  : self.VVmDBI()
 def VVf9bj(self):
  fg = bg = CFG.transpColorPicons.getValue()
  self.session.openWithCallback(self.VVcSXf, CC6XYk, defFG=fg, defBG=bg, onlyBG=True)
 def VVcSXf(self, fg, bg):
  if bg:
   FFGxwH(CFG.transpColorPicons, bg)
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FFAMY6(self["myPosterRep%d%d" % (row, col)], bg)
 def VVNHlE(self):
  FFK3qq(self, VVdSQY + "_help_picons", "PIcons Tools (Keys Help)")
 def VVRmh5(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VViqaH()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVWuBx()
 def VVThvL(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVx4GG()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVWuBx()
 def VVXUAo(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VViqaH()
  else:
   self.curCol -= 1
   self.VVWuBx()
 def VVaQKG(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVx4GG()
  else:
   self.curCol += 1
   self.VVWuBx()
 def VVimMN(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVWuBx(True)
 def VVA4xu(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVWuBx(True)
 def VVx4GG(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVWuBx(True)
 def VViqaH(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVWuBx(True)
 def VVmDBI(self):
  VVwSHr = []
  for item in self.VVd40u:
   VVwSHr.append((item[0], item[0]))
  FFKX6p(self, self.VVecMC, title='PIcons ".png" Files', VVwSHr=VVwSHr, VVto4D=True)
 def VVecMC(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VV6u9B(ndx)
 def VVyjCn(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVM3Kl()
   if refCode:
    FFf8Q6(self, refCode)
    self.VVe957()
    self.VVLkRv()
 def VVoX8p(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVe957()
   self.VVLkRv()
  except:
   pass
 def VVombX(self):
  if self["keyGreen"].getVisible():
   self.VV6u9B(self.curChanIndex)
 def VV6u9B(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVWuBx(True)
  else:
   FFMYB5(self, "Not found", 1000)
 def VVGQNY(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFqXEj(self, BF(self.VVODOG, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VV68g3(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVM3Kl()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVwSHr = []
     VVwSHr.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVwSHr.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFKX6p(self, BF(self.VVILbp, mode, curChF, selPiconF), VVwSHr=VVwSHr, title="Current Channel PIcon (already exists)")
    else:
     self.VVILbp(mode, curChF, selPiconF, "overwrite")
   else:
    FFAvZA(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFAvZA(self, "Could not read current channel info. !", title=title)
 def VVILbp(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFqXEj(self, BF(self.VVODOG, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VV2djj(self):
  defDir = FFThW1(CCVrfy.VVNV04() + "picons_backup")
  os.system(FFlWZ0("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(BF(self.VVF6lU, defDir), BF(CCeH84
         , mode=CCeH84.VVf4Wu, VVXtjq=CCVrfy.VVNV04()))
 def VVF6lU(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCVrfy.VVNV04():
    FFAvZA(self, "Cannot move to same directory !", title=title)
   else:
    if not FFThW1(path) == FFThW1(defDir):
     self.VVzOIJ(defDir)
    FFOjga(self, BF(FFqXEj, self, BF(self.VVLrJT, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVd40u), path), title=title)
  else:
   self.VVzOIJ(defDir)
 def VVLrJT(self, title, defDir, toPath):
  if not iMove:
   self.VVzOIJ(defDir)
   FFAvZA(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FFThW1(toPath)
  pPath = CCVrfy.VVNV04()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVd40u:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVd40u)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFheEQ(self, txt, title=title, VV9Ea0="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVP8UO("all")
 def VVzOIJ(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VV6vQc(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVd40u)
  FFOjga(self, BF(FFqXEj, self, BF(self.VV9zvz, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FFEOCn(tot)), title=title)
 def VV9zvz(self, title):
  pPath = CCVrfy.VVNV04()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVd40u:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVd40u)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFNkac(str(totErr), VVHKA4)
  FFheEQ(self, txt, title=title)
 def VVHw44(self):
  lines = FFIsyt("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FFOjga(self, BF(self.VVmuA2, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FFEOCn(tot)), VVA7RB=True)
  else:
   FF6b7h(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVmuA2(self, fList):
  os.system(FFlWZ0("find -L '%s' -type l -delete" % self.pPath))
  FF6b7h(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVgtzi(self):
  FFqXEj(self, self.VVFDZc)
 def VVFDZc(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVM3Kl()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFNkac("PIcon Directory:\n", VVHJRy)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FFN6Yw(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFN6Yw(path)
   txt += FFNkac("PIcon File:\n", VVHJRy)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FFNkac("Found %d SymLink%s to this file from:\n" % (tot, FFEOCn(tot)), VVHJRy)
     for fPath in slLst:
      txt += "  %s\n" % FFNkac(fPath, VVcK7G)
     txt += "\n"
   if chName:
    txt += FFNkac("Channel:\n", VVHJRy)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFNkac(chName, VV80BT)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FFNkac("Remarks:\n", VVHJRy)
    txt += "  %s\n" % FFNkac("Unused", VVHKA4)
  else:
   txt = "No info found"
  FFQTAA(self, fncMode=CCnfxp.VV7OJJ, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVM3Kl(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVd40u[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFJ0oY(sat)
  return fName, refCode, chName, sat, inDB
 def VVe957(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVd40u):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVLkRv(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVM3Kl()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFNkac("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVHJRy))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVM3Kl()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFNkac(self.curChanName, VVSqFX)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVOw8k(self):
  VVwBvo, VV9WSF = FFXZbX()
  sTypeNameDict = {}
  for key, val in VV9WSF.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVd40u:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VV9WSF: sTypeDict[VV9WSF[stNum]] = sTypeDict.get(VV9WSF[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFnz9X("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVmJ2p = []
  c = "#b#11003333#"
  VVmJ2p.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalPIcons, totUsedFiles + totUsedLinks)))
  VVmJ2p.append((c + "Files" , "%d\tUsed = %s" % (self.totalPIcons - totSymLinks, totUsedFiles)))
  VVmJ2p.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVmJ2p.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVmJ2p.append((c + "Not In Database (lamedb)" , str(self.totalPIcons - totInDB)))
  VVmJ2p.append((c + "Satellites"    , str(len(self.nsList))))
  VVmJ2p.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVmJ2p.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVmJ2p.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVmJ2p.extend(sTypeRows)
  FFyLgY(self, None, title=self.Title, VVd40u=VVmJ2p, VV2ql8=28, VVZozG="#00003333", VVsrIN="#00222222")
 def VVCIOP(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FFThW1(CFG.exportedTablesPath.getValue()), txt, FFLFgj())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVd40u:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FF6b7h(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVMeQC(self):
  if not self.isBusy:
   VVwSHr = []
   VVwSHr.append(("All"         , "all"   ))
   VVwSHr.append(VVbzyo)
   VVwSHr.append(("Used by Channels"      , "used"  ))
   VVwSHr.append(("Unused PIcons"      , "unused"  ))
   VVwSHr.append(("IPTV PIcons"       , "iptv"  ))
   VVwSHr.append(VVbzyo)
   VVwSHr.append(("PIcons Files"       , "pFiles"  ))
   VVwSHr.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVwSHr.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVwSHr.append(("By Files Date ..."     , "pDate"  ))
   VVwSHr.append(("By Service Type ..."     , "servType" ))
   if self.nsList:
    VVwSHr.append(FFDhQn("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFqpI8(val)
      VVwSHr.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CC6QfU(self)
   filterObj.VV7Ltt(VVwSHr, self.nsList, self.VVMmWq)
 def VVMmWq(self, item=None):
  if item is not None:
   self.VVP8UO(item)
 def VVP8UO(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVvHiO   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVaKYs   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VV4XgY  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVgGxp   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VV7Rpd  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVfYtd  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VV6Aht  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VV3TeQ , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VV0DEB , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVSMHJ   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVtD1u , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VV6Aht:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFIsyt("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFck77(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFMYB5(self, "Not found", 1000)
     return
   elif mode == self.VV3TeQ:
    self.VVPN59(mode)
    return
   elif mode == self.VV0DEB:
    self.VVdjYS(mode)
    return
   elif mode == self.VVGVoQ:
    return
   else:
    words, asPrefix = CC6QfU.VVfYn9(words)
   if not words and mode in (self.VVSMHJ, self.VVtD1u):
    FFMYB5(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFqXEj(self, BF(self.VVODOG, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVPN59(self, mode):
  VVwSHr = []
  VVwSHr.append(("Today"   , "today" ))
  VVwSHr.append(("Since Yesterday" , "yest" ))
  VVwSHr.append(("Since 7 days"  , "week" ))
  FFKX6p(self, BF(self.VVKn4T, mode), VVwSHr=VVwSHr, title="Filter by Added/Modified Date")
 def VVKn4T(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFpJ0E(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFpJ0E(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFpJ0E(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FFqXEj(self, BF(self.VVODOG, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVdjYS(self, mode):
  VVwBvo, VV9WSF = FFXZbX()
  lst = set()
  for key, val in VV9WSF.items():
   lst.add(val)
  VVwSHr = []
  for item in lst:
   VVwSHr.append((item, item))
  VVwSHr.sort(key=lambda x: x[0])
  FFKX6p(self, BF(self.VV4rHD, mode), VVwSHr=VVwSHr, title="Filter by Service Type")
 def VV4rHD(self, mode, item=None):
  if item:
   VVwBvo, VV9WSF = FFXZbX()
   sTypeList = []
   for key, val in VV9WSF.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FFqXEj(self, BF(self.VVODOG, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VV5BiN(self):
  self.session.open(CCfZJl, barTheme=CCfZJl.VVZDZW
      , titlePrefix = ""
      , fncToRun  = self.VVv5ik
      , VVUStE = self.VVQucK)
 def VVv5ik(self, VVvSz8):
  VVg870, err = CCKtc8.VVwRJt(self, CCKtc8.VVlGns, VVajqq=False, VVKx0m=False)
  files = []
  words = []
  if not VVvSz8 or VVvSz8.isCancelled:
   return
  VVvSz8.VVwBP2 = []
  VVvSz8.VVO1nT(len(VVg870))
  if VVg870:
   VVkxWB = CClSwG()
   curCh = VVkxWB.VVitvc(self.curChanName)
   for refCode in VVg870:
    if not VVvSz8 or VVvSz8.isCancelled:
     return
    VVvSz8.VVPK2y(1, True)
    chName, sat, inDB = VVg870.get(refCode, ("", "", 0))
    ratio = CCVrfy.VVry3E(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCVrfy.VVpc1c(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFck77(f)
       fil = f.replace(".png", "")
       if not fil in VVvSz8.VVwBP2:
        VVvSz8.VVwBP2.append(fil)
 def VVQucK(self, VVbt6k, VVwBP2, threadCounter, threadTotal, threadErr):
  if VVwBP2 : FFqXEj(self, BF(self.VVODOG, mode=self.VVGVoQ, words=VVwBP2), title="Loading ...")
  else   : FFMYB5(self, "Not found", 2000)
 def VVODOG(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VVjpFJ(isFirstTime):
   return
  self.isBusy = True
  VVKx0m = True if isFirstTime else False
  VVg870, err = CCKtc8.VVwRJt(self, CCKtc8.VVlGns, VVajqq=False, VVKx0m=VVKx0m)
  if err:
   self.close()
  iptvRefList = self.VVaWAU()
  tList = []
  for fName, fType in CCVrfy.VVrCgj(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVg870:
    if fName in VVg870:
     chName, sat, inDB = VVg870.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVvHiO:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVaKYs  and chName         : isAdd = True
   elif mode == self.VV4XgY and not chName        : isAdd = True
   elif mode == self.VV7Rpd  and fType == 0        : isAdd = True
   elif mode == self.VVfYtd  and fType == 1        : isAdd = True
   elif mode == self.VV6Aht  and fName in words       : isAdd = True
   elif mode == self.VVGVoQ and fName in words       : isAdd = True
   elif mode == self.VVgGxp  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVSMHJ  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVtD1u:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VV3TeQ:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VV0DEB:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVd40u   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FFMYB5(self)
  else:
   self.isBusy = False
   FFMYB5(self, "Not found", 1000)
   return
  self.VVd40u.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVe957()
  self.totalPIcons = len(self.VVd40u)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVWuBx(True)
 def VVjpFJ(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCVrfy.VVrCgj(self.pPath):
    if fName:
     return True
   if isFirstTime : FFAvZA(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFMYB5(self, "Not found", 1000)
  else:
   FFAvZA(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVaWAU(self):
  VVmJ2p = {}
  files  = CCaayN.VVHIur()
  if files:
   for path in files:
    txt = FFa594(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVmJ2p[refCode] = item[1]
  return VVmJ2p
 def VVWuBx(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VV5jH7 = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VV5jH7: self.curPage = VV5jH7
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVK0Ny()
  if self.curPage == VV5jH7:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPosterPic%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVLkRv()
  filName, refCode, chName, sat, inDB = self.VVM3Kl()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVK0Ny(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVd40u[ndx]
   fName = self.VVd40u[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFNkac(chName, VV80BT))
    else : lbl.setText("-")
   except:
    lbl.setText(FFNkac(chName, VVuRbD))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVry3E(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVW9HU():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVdLtF"   )
 @staticmethod
 def VV2gmI():
  VVwSHr = []
  VVwSHr.append(("Find SymLinks (to PIcon Directory)"   , "VVbFW1"   ))
  VVwSHr.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVwSHr.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVwSHr
 @staticmethod
 def VVdLtF(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(SELF)
  png, path = CCVrfy.VVDael(refCode)
  if path : CCVrfy.VVg41j(SELF, png, path)
  else : FFAvZA(SELF, "No PIcon found for current channel in:\n\n%s" % CCVrfy.VVNV04())
 @staticmethod
 def VVbFW1(SELF):
  if VVSqFX:
   sed1 = FFw6UZ("->", VVSqFX)
   sed2 = FFw6UZ("picon", VVHKA4)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVuRbD, VV1R4z)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FF7AMX(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFaJMY(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVzqlw(SELF, isPIcon):
  sed1 = FFw6UZ("->", VVuRbD)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFw6UZ("picon", VVHKA4)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FF7AMX(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFaJMY(), grep, sed1, sed2))
 @staticmethod
 def VVrCgj(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVNV04():
  path = CFG.PIconsPath.getValue()
  return FFThW1(path)
 @staticmethod
 def VVDael(refCode, chName=None):
  if FFNWS8(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFuK1e(refCode)
  allPath, fName, refCodeFile, pList = CCVrfy.VVpc1c(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVg41j(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFw6UZ("%s%s" % (dest, png), VV80BT))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFw6UZ(errTxt, VV0rNQ))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFGC8R(SELF, cmd)
 @staticmethod
 def VVpc1c(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCVrfy.VVNV04()
   pList = []
   lst = FFLuBK(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FFGlcE(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFck77(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCRN3G():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVLjxL  = None
  self.VVc1cA = ""
  self.VVwTdd  = noService
  self.VVtEO7 = 0
  self.VVDuGC  = noService
  self.VVatIe = 0
  self.VV4Mnb  = "-"
  self.VVPtvb = 0
  self.VV6MU3  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVrajB(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVLjxL = frontEndStatus
     self.VVo9F4()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVo9F4(self):
  if self.VVLjxL:
   val = self.VVLjxL.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVc1cA = "%3.02f dB" % (val / 100.0)
   else         : self.VVc1cA = ""
   val = self.VVLjxL.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVtEO7 = int(val)
   self.VVwTdd  = "%d%%" % val
   val = self.VVLjxL.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVatIe = int(val)
   self.VVDuGC  = "%d%%" % val
   val = self.VVLjxL.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VV4Mnb  = "%d" % val
   val = int(val * 100 / 500)
   self.VVPtvb = min(500, val)
   val = self.VVLjxL.get("tuner_locked", 0)
   if val == 1 : self.VV6MU3 = "Locked"
   else  : self.VV6MU3 = "Not locked"
 def VVYP0i(self)   : return self.VVc1cA
 def VVwrH1(self)   : return self.VVwTdd
 def VVyMSC(self)  : return self.VVtEO7
 def VVCc2L(self)   : return self.VVDuGC
 def VVcXp4(self)  : return self.VVatIe
 def VVs3lh(self)   : return self.VV4Mnb
 def VVjbti(self)  : return self.VVPtvb
 def VVcfGV(self)   : return self.VV6MU3
 def VVRziN(self) : return self.serviceName
class CCpEt4():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVhYcG(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFDZ6V(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVciYS(self.ORPOS  , mod=1   )
      self.sat2  = self.VVciYS(self.ORPOS  , mod=2   )
      self.freq  = self.VVciYS(self.FREQ  , mod=3   )
      self.sr   = self.VVciYS(self.SR   , mod=4   )
      self.inv  = self.VVciYS(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVciYS(self.POL  , self.D_POL )
      self.fec  = self.VVciYS(self.FEC  , self.D_FEC )
      self.syst  = self.VVciYS(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVciYS("modulation" , self.D_MOD )
       self.rolof = self.VVciYS("rolloff"  , self.D_ROLOF )
       self.pil = self.VVciYS("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVciYS("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVciYS("pls_code"  )
       self.iStId = self.VVciYS("is_id"   )
       self.t2PlId = self.VVciYS("t2mi_plp_id" )
       self.t2PId = self.VVciYS("t2mi_pid"  )
 def VVciYS(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFqpI8(val)
  elif mod == 2   : return FFeGzm(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VVqRJd(self, refCode):
  txt = ""
  self.VVhYcG(refCode)
  if self.data:
   def VVQesM(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVQesM("System"   , self.syst)
    txt += VVQesM("Satellite"  , self.sat2)
    txt += VVQesM("Frequency"  , self.freq)
    txt += VVQesM("Inversion"  , self.inv)
    txt += VVQesM("Symbol Rate"  , self.sr)
    txt += VVQesM("Polarization" , self.pol)
    txt += VVQesM("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVQesM("Modulation" , self.mod)
     txt += VVQesM("Roll-Off" , self.rolof)
     txt += VVQesM("Pilot"  , self.pil)
     txt += VVQesM("Input Stream", self.iStId)
     txt += VVQesM("T2MI PLP ID" , self.t2PlId)
     txt += VVQesM("T2MI PID" , self.t2PId)
     txt += VVQesM("PLS Mode" , self.plsMod)
     txt += VVQesM("PLS Code" , self.plsCod)
   else:
    txt += VVQesM("System"   , self.txMedia)
    txt += VVQesM("Frequency"  , self.freq)
  return txt, self.namespace
 def VV0xaW(self, refCode):
  txt = "Transpoder : ?"
  self.VVhYcG(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVn847(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFDZ6V(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVciYS(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVciYS(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVciYS(self.SYST, self.D_SYS_S)
     freq = self.VVciYS(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVciYS(self.POL , self.D_POL)
      fec = self.VVciYS(self.FEC , self.D_FEC)
      sr = self.VVciYS(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VV7yl9(self, refCode):
  self.data = None
  self.VVhYcG(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCRb0q():
 def __init__(self, VVYaCB, path, VVUStE=None, curRowNum=-1):
  self.VVYaCB  = VVYaCB
  self.origFile   = path
  self.Title    = "File Editor: " + FFck77(path)
  self.VVUStE  = VVUStE
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  response = os.system(FFlWZ0("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVQSND(curRowNum)
  else:
   FFAvZA(self.VVYaCB, "Error while preparing edit!")
 def VVQSND(self, curRowNum):
  VVmJ2p = self.VVuyks()
  VVcZtS = ("Save Changes" , self.VVGDFr   , [])
  VVVt3G  = ("Edit Line"  , self.VVuMoO    , [])
  VVq3zo = ("Go to Line Num" , self.VVYCLV   , [])
  VVrIQY = ("Line Options" , self.VVU7ff   , [])
  VV3zZz = (""    , self.VVEPgv , [])
  VVPypB = self.VVKXjS
  VVGssA  = self.VV2fu7
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVe5VU  = (CENTER  , LEFT  )
  VVl7Cx = FFyLgY(self.VVYaCB, None, title=self.Title, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVcZtS=VVcZtS, VVVt3G=VVVt3G, VVq3zo=VVq3zo, VVrIQY=VVrIQY, VVPypB=VVPypB, VVGssA=VVGssA, VV3zZz=VV3zZz, VV1YOp=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
    , VVCNiH   = "#11001111"
    , VVIhEb   = "#11001111"
    , VV9Ea0   = "#11001111"
    , VVZozG  = "#05333333"
    , VVsrIN  = "#00222222"
    , VVn0US  = "#11331133"
    )
  VVl7Cx.VVm16r(curRowNum)
 def VVYCLV(self, VVl7Cx, title, txt, colList):
  totRows = VVl7Cx.VVm6b9()
  lineNum = VVl7Cx.VVf913() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FFJC4A(self.VVYaCB, BF(self.VVosLD, VVl7Cx, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VVosLD(self, VVl7Cx, lineNum, totRows, VVg7w7):
  if VVg7w7:
   VVg7w7 = VVg7w7.strip()
   if VVg7w7.isdigit():
    num = FFrVTn(int(VVg7w7) - 1, 0, totRows)
    VVl7Cx.VVm16r(num)
    self.lastLineNum = num + 1
   else:
    FFMYB5(VVl7Cx, "Incorrect number", 1500)
 def VVU7ff(self, VVl7Cx, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVl7Cx.VV1Heh()
  VVwSHr = []
  VVwSHr.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVwSHr.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVIbcG"  ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVKliC:
   VVwSHr.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(  ("Delete Line"         , "deleteLine"   ))
  FFKX6p(self.VVYaCB, BF(self.VVLCFs, VVl7Cx, lineNum), VVwSHr=VVwSHr, title="Line Options")
 def VVLCFs(self, VVl7Cx, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVz3Kt("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVl7Cx)
   elif item == "VVIbcG"  : self.VVIbcG(VVl7Cx, lineNum)
   elif item == "copyToClipboard"  : self.VVZTcA(VVl7Cx, lineNum)
   elif item == "pasteFromClipboard" : self.VVvnVk(VVl7Cx, lineNum)
   elif item == "deleteLine"   : self.VVz3Kt("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVl7Cx)
 def VV2fu7(self, VVl7Cx):
  VVl7Cx.VVVZSG()
 def VVEPgv(self, VVl7Cx, title, txt, colList):
  if   self.insertMode == 1: VVl7Cx.VV8kC5()
  elif self.insertMode == 2: VVl7Cx.VVF53M()
  self.insertMode = 0
 def VVIbcG(self, VVl7Cx, lineNum):
  if lineNum == VVl7Cx.VV1Heh():
   self.insertMode = 1
   self.VVz3Kt("echo '' >> '%s'" % self.tmpFile, VVl7Cx)
  else:
   self.insertMode = 2
   self.VVz3Kt("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVl7Cx)
 def VVZTcA(self, VVl7Cx, lineNum):
  global VVKliC
  VVKliC = FFnz9X("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVl7Cx.VVguPD("Copied to clipboard")
 def VVGDFr(self, VVl7Cx, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFlWZ0("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFlWZ0("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVl7Cx.VVguPD("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVl7Cx.VVVZSG()
    else:
     FFAvZA(self.VVYaCB, "Cannot save file!")
   else:
    FFAvZA(self.VVYaCB, "Cannot create backup copy of original file!")
 def VVKXjS(self, VVl7Cx):
  if self.fileChanged:
   FFOjga(self.VVYaCB, BF(self.VVLGsz, VVl7Cx), "Cancel changes ?")
  else:
   finalOK = os.system(FFlWZ0("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVLGsz(VVl7Cx)
 def VVLGsz(self, VVl7Cx):
  VVl7Cx.cancel()
  FFblrr(self.tmpFile)
  if self.VVUStE:
   self.VVUStE(self.fileSaved)
 def VVuMoO(self, VVl7Cx, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VV1R4z + "ORIGINAL TEXT:\n" + VVcK7G + lineTxt
  FFJC4A(self.VVYaCB, BF(self.VVBKhE, lineNum, VVl7Cx), title="File Line", defaultText=lineTxt, message=message)
 def VVBKhE(self, lineNum, VVl7Cx, VVg7w7):
  if not VVg7w7 is None:
   if VVl7Cx.VV1Heh() <= 1:
    self.VVz3Kt("echo %s > '%s'" % (VVg7w7, self.tmpFile), VVl7Cx)
   else:
    self.VVFe65(VVl7Cx, lineNum, VVg7w7)
 def VVvnVk(self, VVl7Cx, lineNum):
  if lineNum == VVl7Cx.VV1Heh() and VVl7Cx.VV1Heh() == 1:
   self.VVz3Kt("echo %s >> '%s'" % (VVKliC, self.tmpFile), VVl7Cx)
  else:
   self.VVFe65(VVl7Cx, lineNum, VVKliC)
 def VVFe65(self, VVl7Cx, lineNum, newTxt):
  VVl7Cx.VV07Vz("Saving ...")
  lines = FF7up6(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVl7Cx.VVxWR8()
  VVmJ2p = self.VVuyks()
  VVl7Cx.VVfoGr(VVmJ2p)
 def VVz3Kt(self, cmd, VVl7Cx):
  tCons = CCPx0q()
  tCons.ePopen(cmd, BF(self.VVM7SQ, VVl7Cx))
  self.fileChanged = True
  VVl7Cx.VVxWR8()
 def VVM7SQ(self, VVl7Cx, result, retval):
  VVmJ2p = self.VVuyks()
  VVl7Cx.VVfoGr(VVmJ2p)
 def VVuyks(self):
  if fileExists(self.tmpFile):
   lines = FF7up6(self.tmpFile)
   VVmJ2p = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVmJ2p.append((str(ndx), line.strip()))
   if not VVmJ2p:
    VVmJ2p.append((str(1), ""))
   return VVmJ2p
  else:
   FFXl6w(self.VVYaCB, self.tmpFile)
class CC6QfU():
 def __init__(self, callingSELF, VVCNiH="#22003344", VVIhEb="#22002233"):
  self.callingSELF = callingSELF
  self.VVwSHr  = []
  self.satList  = []
  self.VVCNiH  = VVCNiH
  self.VVIhEb   = VVIhEb
 def VVefsy(self, VVUStE):
  self.VVwSHr = []
  VVwSHr, VVOVHj = CC6QfU.VVJ2BL(self.callingSELF, False, True)
  if VVwSHr:
   self.VVwSHr += VVwSHr
   self.VVzePl(VVUStE, VVOVHj)
 def VVPWEf(self, mode, VVl7Cx, satCol, VVUStE, inFilterFnc=None):
  VVl7Cx.VV07Vz("Loading Filters ...")
  self.VVwSHr = []
  self.VVwSHr.append(("All Services" , "all"))
  if mode == 1:
   self.VVwSHr.append(VVbzyo)
   self.VVwSHr.append(("Parental Control", "parentalControl"))
   self.VVwSHr.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVwSHr.append(VVbzyo)
   self.VVwSHr.append(("Selected Transponder"   , "selectedTP" ))
   self.VVwSHr.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VV9fZj(VVl7Cx, satCol)
  VVwSHr, VVOVHj = CC6QfU.VVJ2BL(self.callingSELF, True, False)
  if VVwSHr:
   VVwSHr.insert(0, FFDhQn("Custom Words"))
   self.VVwSHr += VVwSHr
  VVl7Cx.VVTKmx()
  self.VVzePl(VVUStE, VVOVHj, inFilterFnc)
 def VV7Ltt(self, VVwSHr, sats, VVUStE, inFilterFnc=None):
  self.VVwSHr = VVwSHr
  VVwSHr, VVOVHj = CC6QfU.VVJ2BL(self.callingSELF, True, False)
  if VVwSHr:
   self.VVwSHr.append(FFDhQn("Custom Words"))
   self.VVwSHr += VVwSHr
  self.VVzePl(VVUStE, VVOVHj, inFilterFnc)
 def VVzePl(self, VVUStE, VVOVHj, inFilterFnc=None):
  VV7qf7  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVoZDD = ("Edit Filter"  , BF(self.VVVK76, VVOVHj))
  VVWYuC  = ("Filter Help"  , BF(self.VVDxDc, VVOVHj))
  FFKX6p(self.callingSELF, BF(self.VVsL17, VVUStE), VVwSHr=self.VVwSHr, title="Select Filter", VV7qf7=VV7qf7, VVoZDD=VVoZDD, VVWYuC=VVWYuC, VVL5Ba=True, VVCNiH=self.VVCNiH, VVIhEb=self.VVIhEb)
 def VVsL17(self, VVUStE, item):
  if item:
   VVUStE(item)
 def VVVK76(self, VVOVHj, VVZPLhObj, sel):
  if fileExists(VVOVHj) : CCRb0q(self.callingSELF, VVOVHj, VVUStE=None)
  else       : FFXl6w(self.callingSELF, VVOVHj)
  VVZPLhObj.cancel()
 def VVDxDc(self, VVOVHj, VVZPLhObj, sel):
  FFK3qq(self.callingSELF, VVdSQY + "_help_service_filter", "Service Filter")
 def VV9fZj(self, VVl7Cx, satColNum):
  if not self.satList:
   satList = VVl7Cx.VVy7J4(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFJ0oY(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FFDhQn("Satellites"))
  if self.VVwSHr:
   self.VVwSHr += self.satList
 @staticmethod
 def VVJ2BL(SELF, addTag, VViqYq):
  FFtAvw()
  fileName  = "ajpanel_services_filter"
  VVOVHj = VVhL6f + fileName
  VVwSHr  = []
  if not fileExists(VVOVHj):
   os.system(FFlWZ0("cp -f '%s' '%s'" % (VVdSQY + fileName, VVOVHj)))
  fileFound = False
  if fileExists(VVOVHj):
   fileFound = True
   lines = FF7up6(VVOVHj)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVwSHr.append((line, "__w__" + line))
       else  : VVwSHr.append((line, line))
  if VViqYq:
   if   not fileFound : FFXl6w(SELF, VVOVHj)
   elif not VVwSHr : FF8QNX(SELF, VVOVHj)
  return VVwSHr, VVOVHj
 @staticmethod
 def VVfYn9(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CCEd9P():
 def __init__(self, callingSELF, VVl7Cx, addSep=True):
  self.callingSELF = callingSELF
  self.VVl7Cx = VVl7Cx
  self.VVwSHr = []
  iMulSel = self.VVl7Cx.VV9IV0()
  if iMulSel : self.VVwSHr.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVwSHr.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVl7Cx.VVmvz4()
  self.VVwSHr.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVwSHr.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVwSHr.append(VVbzyo)
 def VV5TZ4(self, extraMenu, cbFncDict):
  if extraMenu:
   self.VVwSHr.extend(extraMenu)
  FFKX6p(self.callingSELF, BF(self.VVfGyl, cbFncDict), title="Options", VVwSHr=self.VVwSHr)
 def VVfGyl(self, cbFncDict, item=None):
  if item:
   if   item == "multSelEnab" : self.VVl7Cx.VVDfQL(True)
   elif item == "MultSelDisab" : self.VVl7Cx.VVDfQL(False)
   elif item == "selectAll" : self.VVl7Cx.VV2zD3()
   elif item == "unselectAll" : self.VVl7Cx.VVZCNW()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
class CCHCTj(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFheJw(VVkJ1U, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFqVmU(self)
  FFTGpi(self["keyRed"]  , "Exit")
  FFTGpi(self["keyGreen"]  , "Save")
  FFTGpi(self["keyYellow"] , "Refresh")
  FFTGpi(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVduu9  ,
   "green"   : self.VVLR0S ,
   "yellow"  : self.VVtANY  ,
   "blue"   : self.VV3WIX   ,
   "up"   : self.VVRmh5    ,
   "down"   : self.VVThvL   ,
   "left"   : self.VVXUAo   ,
   "right"   : self.VVaQKG   ,
   "cancel"  : self.VVduu9
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VVevf4)
  self.onClose.append(self.onExit)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  self.VVtANY()
  self.VVMT8K()
  FFBmK5(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVw6dX)
  except:
   self.timer.callback.append(self.VVw6dX)
  self.timer.start(1000, False)
  self.VVw6dX()
 def onExit(self):
  self.timer.stop()
 def VVduu9(self) : self.close(True)
 def VV8553(self) : self.close(False)
 def VV3WIX(self):
  self.session.openWithCallback(self.VVmZNN, BF(CCcfob))
 def VVmZNN(self, closeAll):
  if closeAll:
   self.close()
 def VVw6dX(self):
  self["curTime"].setText(str(FFLaSW(iTime())))
 def VVRmh5(self):
  self.VV77QT(1)
 def VVThvL(self):
  self.VV77QT(-1)
 def VVXUAo(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVMT8K()
 def VVaQKG(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVMT8K()
 def VV77QT(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VV97MA(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VV97MA(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VV97MA(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVvjsV(year)):
   days += 1
  return days
 def VVvjsV(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVMT8K(self):
  for obj in self.list:
   FFAMY6(obj, "#11404040")
  FFAMY6(self.list[self.index], "#11ff8000")
 def VVtANY(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVLR0S(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCPx0q()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVr1p1)
 def VVr1p1(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FF6b7h(self, "Nothing returned from the system!")
  else:
   FF6b7h(self, str(result))
class CCcfob(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFheJw(VVn6dg, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFqVmU(self, addLabel=True)
  FFTGpi(self["keyRed"]  , "Exit")
  FFTGpi(self["keyGreen"]  , "Sync")
  FFTGpi(self["keyYellow"] , "Refresh")
  FFTGpi(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVduu9   ,
   "green"   : self.VVMcTX  ,
   "yellow"  : self.VVfY2t ,
   "blue"   : self.VVoMYj  ,
   "cancel"  : self.VVduu9
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVVlYi()
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  FFBmK5(self)
  FFuqQK(self.refresh)
 def refresh(self):
  self.VVDxrj()
  self.VVtScc(False)
 def VVduu9(self)  : self.close(True)
 def VVoMYj(self) : self.close(False)
 def VVVlYi(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVDxrj(self):
  self.VVHdPA()
  self.VViUrb()
  self.VVrn18()
  self.VVUhpr()
 def VVfY2t(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVVlYi()
   self.VVDxrj()
   FFuqQK(self.refresh)
 def VVMcTX(self):
  if len(self["keyGreen"].getText()) > 0:
   FFOjga(self, self.VVw4SM, "Synchronize with Internet Date/Time ?")
 def VVw4SM(self):
  self.VVDxrj()
  FFuqQK(BF(self.VVtScc, True))
 def VVHdPA(self)  : self["keyRed"].show()
 def VVZ2oR(self)  : self["keyGreen"].show()
 def VVEEwD(self) : self["keyYellow"].show()
 def VV34oF(self)  : self["keyBlue"].show()
 def VViUrb(self)  : self["keyGreen"].hide()
 def VVrn18(self) : self["keyYellow"].hide()
 def VVUhpr(self)  : self["keyBlue"].hide()
 def VVtScc(self, sync):
  localTime = FFbS0L()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VV7ats(server)
   if epoch_time is not None:
    ntpTime = FFLaSW(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCPx0q()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VVr1p1, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVEEwD()
  self.VV34oF()
  if ok:
   self.VVZ2oR()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVr1p1(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVtScc(False)
  except:
   pass
 def VV7ats(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FF9q7B():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCsbwx(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFheJw(VVEXzS, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FFqVmU(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  FFuqQK(self.VV4Xnr)
 def VV4Xnr(self):
  if FF9q7B(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFAMY6(self["myBody"], color)
   FFAMY6(self["myLabel"], color)
  except:
   pass
class CCTDYj(Screen):
 VVgpqK = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFEFsT()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFheJw(VV3Iw8, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCYnxY(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCYnxY(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCYnxY(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCRN3G()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFqVmU(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close      ,
   "up"  : self.VVRmh5       ,
   "down"  : self.VVThvL      ,
   "left"  : self.VVXUAo      ,
   "right"  : self.VVaQKG      ,
   "info"  : self.VVXEta     ,
   "epg"  : self.VVXEta     ,
   "menu"  : self.VVNHlE      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVIvik, -1)  ,
   "next"  : BF(self.VVIvik, 1)  ,
   "pageUp" : BF(self.VV7hTR, True) ,
   "chanUp" : BF(self.VV7hTR, True) ,
   "pageDown" : BF(self.VV7hTR, False) ,
   "chanDown" : BF(self.VV7hTR, False) ,
   "0"   : BF(self.VVIvik, 0)  ,
   "1"   : BF(self.VVwlZ1, pos=1) ,
   "2"   : BF(self.VVwlZ1, pos=2) ,
   "3"   : BF(self.VVwlZ1, pos=3) ,
   "4"   : BF(self.VVwlZ1, pos=4) ,
   "5"   : BF(self.VVwlZ1, pos=5) ,
   "6"   : BF(self.VVwlZ1, pos=6) ,
   "7"   : BF(self.VVwlZ1, pos=7) ,
   "8"   : BF(self.VVwlZ1, pos=8) ,
   "9"   : BF(self.VVwlZ1, pos=9) ,
  }, -1)
  self.onShown.append(self.VVevf4)
  self.onClose.append(self.onExit)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  if not CCTDYj.VVgpqK:
   CCTDYj.VVgpqK = self
  self.sliderSNR.VVXcdk()
  self.sliderAGC.VVXcdk()
  self.sliderBER.VVXcdk(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVwlZ1()
  self.VVWFkf()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVkrWY)
  except:
   self.timer.callback.append(self.VVkrWY)
  self.timer.start(500, False)
 def VVWFkf(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVrajB(service)
  serviceName = self.tunerInfo.VVRziN()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self)
  tp = CCpEt4()
  tpTxt, satTxt = tp.VV0xaW(refCode)
  if tpTxt == "?" :
   tpTxt = FFNkac("NO SIGNAL", VVmIAH)
  self["myTPInfo"].setText(tpTxt + "  " + FFNkac(satTxt, VVXaO9))
 def VVkrWY(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVrajB(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVYP0i())
   self["mySNR"].setText(self.tunerInfo.VVwrH1())
   self["myAGC"].setText(self.tunerInfo.VVCc2L())
   self["myBER"].setText(self.tunerInfo.VVs3lh())
   self.sliderSNR.VVNeWE(self.tunerInfo.VVyMSC())
   self.sliderAGC.VVNeWE(self.tunerInfo.VVcXp4())
   self.sliderBER.VVNeWE(self.tunerInfo.VVjbti())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVNeWE(0)
   self.sliderAGC.VVNeWE(0)
   self.sliderBER.VVNeWE(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self)
    if state and not state == "Tuned":
     FFMYB5(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVXEta(self):
  FFQTAA(self, fncMode=CCnfxp.VVwxyw)
 def VVNHlE(self):
  FFK3qq(self, VVdSQY + "_help_signal", "Signal Monitor (Keys)")
 def VVRmh5(self)  : self.VVwlZ1(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVThvL(self) : self.VVwlZ1(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVXUAo(self) : self.VVwlZ1(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVaQKG(self) : self.VVwlZ1(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVwlZ1(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FFGxwH(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVIvik(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFrVTn(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FFGxwH(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CCTDYj.VVgpqK = None
 def VV7hTR(self, isUp):
  FFMYB5(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVWFkf()
  except:
   pass
class CCYnxY(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVXcdk(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFAMY6(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVdSQY +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFAMY6(self.covObj, self.covColor)
   else:
    FFAMY6(self.covObj, "#00006688")
    self.isColormode = True
  self.VVNeWE(0)
 def VVNeWE(self, val):
  val  = FFrVTn(val, self.minN, self.maxN)
  width = int(FFzS0X(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFrVTn(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCfZJl(Screen):
 VVZDZW    = 0
 VVBjE0 = 1
 VVOK6Z = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVUStE=None, barTheme=VVZDZW):
  ratio = self.VV808T(barTheme)
  self.skin, self.skinParam = FFheJw(VVZeE3, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVUStE = VVUStE
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVwBP2 = None
  self.timer   = eTimer()
  self.myThread  = None
  FFqVmU(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVevf4)
  self.onClose.append(self.onExit)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  self.VVefGV()
  self["myProgBarVal"].setText("0%")
  FFAMY6(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VV9daA()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV9daA)
  except:
   self.timer.callback.append(self.VV9daA)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVO1nT(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVBSm7(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVwBP2), self.counter, self.maxValue, catName)
 def VVE03S(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVVXid(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VVofeK(self, title):
  self.newTitle = title
  try:
   self.VV9daA()
  except:
   pass
 def VV6VDY(self, txt):
  self.newTitle = txt
 def VVPK2y(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVwBP2), self.counter, self.maxValue)
  except:
   pass
 def VVcjuK(self, val):
  try:
   self.counter = val
  except:
   pass
 def VV0QgR(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVKIGf(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFMYB5(self, "Cancelling ...")
  self.isCancelled = True
  self.VVBDIb(False)
 def VVBDIb(self, isDone):
  if self.VVUStE:
   self.VVUStE(isDone, self.VVwBP2, self.counter, self.maxValue, self.isError)
  self.close()
 def VV9daA(self):
  val = FFrVTn(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFzS0X(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VVBDIb(True)
 def VVefGV(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVBjE0, self.VVOK6Z):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VV808T(self, barTheme):
  if   barTheme == self.VVBjE0 : return 0.7
  if   barTheme == self.VVOK6Z : return 0.5
  else             : return 1
class CCPx0q(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVUStE = {}
  self.commandRunning = False
  self.VVM65w  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVUStE, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVUStE[name] = VVUStE
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVM65w:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVC8cm, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VV5eVH , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVC8cm, name))
    self.appContainers[name].appClosed.append(BF(self.VV5eVH , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VV5eVH(name, retval)
  return True
 def VVC8cm(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FFNkac("[UN-DECODED STRING]", VVmIAH))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VV5eVH(self, name, retval):
  if not self.VVM65w:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVUStE[name]:
   self.VVUStE[name](self.appResults[name], retval)
  del self.VVUStE[name]
 def VVjraF(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CClcu8(Screen):
 def __init__(self, session, title="", VVwcGi=None, VV4lzZ=False, VVKWR3=False, VViYG9=False, VV5YO7=False, VVIDCC=False, VV8ntC=False, VVDaM8=VVZIpo, VVFApn=None, VVaD1B=False, VVHvPK=None, VVRXt6="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFheJw(VVQhck, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFqVmU(self, addScrollLabel=True)
  if not VVRXt6:
   VVRXt6 = "Processing ..."
  self["myLabel"].setText("   %s" % VVRXt6)
  self.VV4lzZ   = VV4lzZ
  self.VVKWR3   = VVKWR3
  self.VViYG9   = VViYG9
  self.VV5YO7  = VV5YO7
  self.VVIDCC = VVIDCC
  self.VV8ntC = VV8ntC
  self.VVDaM8   = VVDaM8
  self.VVFApn = VVFApn
  self.VVaD1B  = VVaD1B
  self.VVHvPK  = VVHvPK
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCPx0q()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFNk49()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVwcGi, str):
   self.VVwcGi = [VVwcGi]
  else:
   self.VVwcGi = VVwcGi
  if self.VViYG9 or self.VV5YO7:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVStMY, VVStMY)
   self.VVwcGi.append("echo -e '\n%s\n' %s" % (restartNote, FFw6UZ(restartNote, VVSqFX)))
   if self.VViYG9:
    self.VVwcGi.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVwcGi.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVIDCC:
   FFMYB5(self, "Processing ...")
  self.onLayoutFinish.append(self.VVASxa)
  self.onClose.append(self.VVNPfk)
 def VVASxa(self):
  self["myLabel"].VV3oQu(outputFileToSave="console" if self.enableSaveRes else "")
  if self.VV4lzZ:
   self["myLabel"].VVy5sP()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVMb4G()
  else:
   self.VVVmh6()
 def VVMb4G(self):
  if FF9q7B():
   self["myLabel"].setText("Processing ...")
   self.VVVmh6()
  else:
   self["myLabel"].setText(FFNkac("\n   No connection to internet!", VVHKA4))
 def VVVmh6(self):
  allOK = self.container.ePopen(self.VVwcGi[0], self.VVkkXo, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVkkXo("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VV8ntC or self.VViYG9 or self.VV5YO7:
    self["myLabel"].setText(FFYH2Y("STARTED", VVSqFX) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVHvPK:
   colorWhite = CC7nVY.VVnDoL(VV1R4z)
   color  = CC7nVY.VVnDoL(self.VVHvPK[0])
   words  = self.VVHvPK[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVDaM8=self.VVDaM8)
 def VVkkXo(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVwcGi):
   allOK = self.container.ePopen(self.VVwcGi[self.cmdNum], self.VVkkXo, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVkkXo("Cannot connect to Console!", -1)
  else:
   if self.VVIDCC and FFRJ8Y(self):
    FFMYB5(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VV8ntC:
    self["myLabel"].appendText("\n" + FFYH2Y("FINISHED", VVSqFX), self.VVDaM8)
   if self.VV4lzZ or self.VVKWR3:
    self["myLabel"].VVy5sP()
   if self.VVFApn is not None:
    self.VVFApn()
   if not retval and self.VVaD1B:
    self.VVNPfk()
 def VVNPfk(self):
  if self.container.VVjraF():
   self.container.killAll()
class CCGmAs(Screen):
 def __init__(self, session, VVwcGi=None, VVIDCC=False):
  self.skin, self.skinParam = FFheJw(VVQhck, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVhL6f + "ajpanel_terminal.history"
  self.customCommandsFile = VVhL6f + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFnz9X("pwd") or "/home/root"
  self.container   = CCPx0q()
  FFqVmU(self, addScrollLabel=True)
  FFTGpi(self["keyRed"] , "Exit = Stop Command")
  FFTGpi(self["keyGreen"] , "OK = History")
  FFTGpi(self["keyYellow"], "Menu = Custom Cmds")
  FFTGpi(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVk0xY ,
   "cancel" : self.VVOivl  ,
   "menu"  : self.VVLvdU ,
   "last"  : self.VVgaik  ,
   "next"  : self.VVgaik  ,
   "1"   : self.VVgaik  ,
   "2"   : self.VVgaik  ,
   "3"   : self.VVgaik  ,
   "4"   : self.VVgaik  ,
   "5"   : self.VVgaik  ,
   "6"   : self.VVgaik  ,
   "7"   : self.VVgaik  ,
   "8"   : self.VVgaik  ,
   "9"   : self.VVgaik  ,
   "0"   : self.VVgaik
  })
  self.onLayoutFinish.append(self.VVevf4)
  self.onClose.append(self.VVT8Oc)
 def VVevf4(self):
  self["myLabel"].VV3oQu(isResizable=False, outputFileToSave="terminal")
  FFilsZ(self["keyRed"]  , "#00ff8000")
  FFAMY6(self["keyRed"]  , self.skinParam["titleColor"])
  FFAMY6(self["keyGreen"]  , self.skinParam["titleColor"])
  FFAMY6(self["keyYellow"] , self.skinParam["titleColor"])
  FFAMY6(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVSlkh(FFnz9X("date"), 5)
  result = FFnz9X("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVV3Pu()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVdSQY + "LinuxCommands.lst"
   newTemplate = VVdSQY + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFlWZ0("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFlWZ0("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVT8Oc(self):
  if self.container.VVjraF():
   self.container.killAll()
   self.VVSlkh("Process killed\n", 4)
   self.VVV3Pu()
 def VVOivl(self):
  if self.container.VVjraF():
   self.VVT8Oc()
  else:
   FFOjga(self, self.close, "Exit ?", VV8V8a=False)
 def VVV3Pu(self):
  self.VVSlkh(self.prompt, 1)
  self["keyRed"].hide()
 def VVSlkh(self, txt, mode):
  if   mode == 1 : color = VVSqFX
  elif mode == 2 : color = VVHJRy
  elif mode == 3 : color = VV1R4z
  elif mode == 4 : color = VVHKA4
  elif mode == 5 : color = VVcK7G
  elif mode == 6 : color = VVNUkq
  else   : color = VV1R4z
  try:
   self["myLabel"].appendText(FFNkac(txt, color))
  except:
   pass
 def VVItul(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVSlkh(cmd, 2)
   self.VVSlkh("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVSlkh(ch, 0)
   self.VVSlkh("\nor\n", 4)
   self.VVSlkh("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVV3Pu()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFNkac(parts[0].strip(), VVHJRy)
    right = FFNkac("#" + parts[1].strip(), VVNUkq)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVSlkh(txt, 2)
   lastLine = self.VVbxwq()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVIS3b(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVkkXo, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFAvZA(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVSlkh(data, 3)
 def VVkkXo(self, data, retval):
  if not retval == 0:
   self.VVSlkh("Exit Code : %d\n" % retval, 4)
  self.VVV3Pu()
 def VVk0xY(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVbxwq() == "":
   self.VVIS3b("cd /tmp")
   self.VVIS3b("ls")
  VVmJ2p = []
  if fileExists(self.commandHistoryFile):
   lines  = FF7up6(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVmJ2p.append((str(c), line, str(lNum)))
   self.VVUfiG(VVmJ2p, title, self.commandHistoryFile, isHistory=True)
  else:
   FFXl6w(self, self.commandHistoryFile, title=title)
 def VVbxwq(self):
  lastLine = FFnz9X("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVIS3b(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVLvdU(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FF7up6(self.customCommandsFile)
   lastLineIsSep = False
   VVmJ2p = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVmJ2p.append((str(c), line, str(lNum)))
   self.VVUfiG(VVmJ2p, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFXl6w(self, self.customCommandsFile, title=title)
 def VVUfiG(self, VVmJ2p, title, filePath=None, isHistory=False):
  if VVmJ2p:
   VVZozG = "#05333333"
   if isHistory: VVCNiH = VVIhEb = VV9Ea0 = "#11000020"
   else  : VVCNiH = VVIhEb = VV9Ea0 = "#06002020"
   VVVt3G   = ("Send"   , BF(self.VVTCoC, isHistory) , [])
   VVcZtS  = ("Modify & Send" , self.VVwYxJ     , [])
   if isHistory:
    VVq3zo = ("Clear History" , self.VVtYUx     , [])
    VVrIQY = None
   elif filePath:
    VVq3zo = None
    VVrIQY = ("Edit File"  , BF(self.VV0QLT, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVe5VU     = (CENTER  , LEFT   , CENTER )
   VVl7Cx = FFyLgY(self, None, title=title, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVVt3G=VVVt3G, VVcZtS=VVcZtS, VVq3zo=VVq3zo, VVrIQY=VVrIQY, lastFindConfigObj=CFG.lastFindTerminal, VV1YOp=True, searchCol=1
     , VVCNiH   = VVCNiH
     , VVIhEb   = VVIhEb
     , VV9Ea0   = VV9Ea0
     , VV0HYK  = "#05ffff00"
     , VVZozG  = VVZozG
    )
   if not isHistory:
    VVl7Cx.VVm16r(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FF8QNX(self, filePath, title=title)
 def VVTCoC(self, isHistory, VVl7Cx, title, txt, colList):
  if not isHistory:
   FFGxwH(CFG.lastTerminalCustCmdLineNum, VVl7Cx.VVf913())
  cmd = colList[1].strip()
  VVl7Cx.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVSlkh("\n%s\n" % cmd, 6)
   self.VVSlkh(self.prompt, 1)
  else:
   self.VVItul(cmd)
 def VVwYxJ(self, VVl7Cx, title, txt, colList):
  cmd = colList[1]
  self.VVVVak(VVl7Cx, cmd)
 def VVtYUx(self, VVl7Cx, title, txt, colList):
  FFOjga(self, BF(self.VV7CX9, VVl7Cx), "Reset History File ?", title="Command History")
 def VV7CX9(self, VVl7Cx):
  os.system(FFlWZ0("echo '' > %s" % self.commandHistoryFile))
  VVl7Cx.cancel()
 def VV0QLT(self, filePath, VVl7Cx, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCRb0q(self, filePath, VVUStE=BF(self.VVO54b, VVl7Cx), curRowNum=rowNum)
  else     : FFXl6w(self, filePath)
 def VVO54b(self, VVl7Cx, fileChanged):
  if fileChanged:
   VVl7Cx.cancel()
   FFuqQK(self.VVLvdU)
 def VVgaik(self):
  self.VVVVak(None, self.lastCommand)
 def VVVVak(self, VVl7Cx, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFJC4A(self, BF(self.VVfxf2, VVl7Cx), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVfxf2(self, VVl7Cx, cmd):
  if cmd and len(cmd) > 0:
   self.VVItul(cmd)
   if VVl7Cx:
    VVl7Cx.cancel()
class CC7it8(Screen):
 def __init__(self, session, title="", message="", VVDaM8=VVZIpo, width=1400, height=800, VVHoVk=False, VV9Ea0=None, VV2ql8=30, outputFileToSave=""):
  self.skin, self.skinParam = FFheJw(VVQhck, width, height, 50, 30, 20, "#22002020", "#22001122", VV2ql8)
  self.session   = session
  FFqVmU(self, title, addScrollLabel=True)
  self.VVDaM8   = VVDaM8
  self.VVHoVk   = VVHoVk
  self.VV9Ea0   = VV9Ea0
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  self["myLabel"].VV3oQu(VVHoVk=self.VVHoVk, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVDaM8)
  if self.VV9Ea0:
   FFAMY6(self["myBody"], self.VV9Ea0)
   FFAMY6(self["myLabel"], self.VV9Ea0)
   FFSeS9(self["myLabel"], self.VV9Ea0)
  self["myLabel"].VVy5sP()
class CCc6iq(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFheJw(VVL14D, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFqVmU(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  FFpx0D(self["errPic"], "err")
class CCs2ey(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFheJw(VV6Nc5, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFqVmU(self, " ", addCloser=True)
class CCpCNj():
 def __init__(self, session, txt, timeout=1500):
  self.win = session.instantiateDialog(CCs2ey, txt, 24)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  FFJvZs(self.win["myWinTitle"], "#440000", 2)
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVZ99m)
  except:
   self.timer.callback.append(self.VVZ99m)
  self.timer.start(timeout, True)
 def VVZ99m(self):
  self.session.deleteDialog(self.win)
class CCEgwO():
 VV2bBz    = 0
 VVqh3l  = 1
 VVpliX   = ""
 VV9Tcp    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVl7Cx   = None
  self.timer     = eTimer()
  self.VV4nDf   = 0
  self.VV604e  = 1
  self.VVUBJr  = 2
  self.VVw1WV   = 3
  self.VV5zW8   = 4
  VVmJ2p = self.VVWW7n()
  if VVmJ2p:
   self.VVl7Cx = self.VVmq9s(VVmJ2p)
  if not VVmJ2p and mode == self.VV2bBz:
   self.VVWyxg("Download list is empty !")
   self.cancel()
  if mode == self.VVqh3l:
   FFqXEj(self.VVl7Cx or self.SELF, BF(self.VVdMvz, startDnld, decodedUrl), title="Checking Server ...")
  self.VVG3fI(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVG3fI)
  except:
   self.timer.callback.append(self.VVG3fI)
  self.timer.start(1000, False)
 def VVmq9s(self, VVmJ2p):
  VVmJ2p.sort(key=lambda x: int(x[0]))
  VVPypB = self.VVyBwL
  VVVt3G  = ("Play"  , self.VVYWcO , [])
  VV0QzM = (""   , self.VVAyY4  , [])
  VVlNkE = ("Stop"  , self.VVR9fx  , [])
  VVcZtS = ("Resume"  , self.VV9fDC , [])
  VVq3zo = ("Options" , self.VV7bp9  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVe5VU  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFyLgY(self.SELF, None, title=self.Title, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVVt3G=VVVt3G, VV0QzM=VV0QzM, VVPypB=VVPypB, VVlNkE=VVlNkE, VVcZtS=VVcZtS, VVq3zo=VVq3zo, lastFindConfigObj=CFG.lastFindIptv, VVCNiH="#11220022", VVIhEb="#11110011", VV9Ea0="#11110011", VV0HYK="#00ffff00", VVZozG="#00223025", VVsrIN="#0a333333", VVn0US="#0a400040", VV1YOp=True, searchCol=1)
 def VVWW7n(self):
  lines = CCEgwO.VV3dVR()
  VVmJ2p = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVKc5N(decodedUrl)
      if fName:
       if   FFQf5u(decodedUrl) : sType = "Movie"
       elif FFz5m2(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVOV6X(decodedUrl, fName)
       if size > -1: sizeTxt = CCeH84.VVpYrc(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVmJ2p.append((str(len(VVmJ2p) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVmJ2p
 def VVOy0n(self):
  VVmJ2p = self.VVWW7n()
  if VVmJ2p:
   if self.VVl7Cx : self.VVl7Cx.VVfoGr(VVmJ2p, VVVlYiMsg=False)
   else     : self.VVl7Cx = self.VVmq9s(VVmJ2p)
  else:
   self.cancel()
 def VVG3fI(self, force=False):
  if self.VVl7Cx:
   thrListUrls = self.VVw17N()
   VVmJ2p = []
   changed = False
   for ndx, row in enumerate(self.VVl7Cx.VVBOVP()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VV4nDf
    if m3u8Log:
     percent = CCEgwO.VVn2f1(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVw1WV , "%.2f %%" % percent
      else   : flag, progr = self.VV5zW8 , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFtd04(mPath)
     if curSize > -1:
      fSize = CCeH84.VVpYrc(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCeH84.VVpYrc(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFtd04(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVw1WV , "%.2f %%" % percent
       else   : flag, progr = self.VV5zW8 , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCeH84.VVpYrc(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VVUBJr
     if m3u8Log :
      if not speed and not force : flag = self.VV604e
      elif curSize == -1   : self.VV8DWp(False)
    elif flag == self.VV4nDf  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VV4nDf  : color2 = "#f#00555555#"
    elif flag == self.VV604e : color2 = "#f#0000FFFF#"
    elif flag == self.VVUBJr : color2 = "#f#0000FFFF#"
    elif flag == self.VVw1WV  : color2 = "#f#00FF8000#"
    elif flag == self.VV5zW8  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVRckj(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVmJ2p.append(row)
   if changed or force:
    self.VVl7Cx.VVfoGr(VVmJ2p, VVVlYiMsg=False)
 def VVRckj(self, flag):
  tDict = self.VVeEGD()
  return tDict.get(flag, "?")
 def VV63iB(self, state):
  for flag, txt in self.VVeEGD().items():
   if txt == state:
    return flag
  return -1
 def VVeEGD(self):
  return { self.VV4nDf: "Not started", self.VV604e: "Connecting", self.VVUBJr: "Downloading", self.VVw1WV: "Stopped", self.VV5zW8: "Completed" }
 def VVA5pv(self, title):
  colList = self.VVl7Cx.VVRTTA()
  path = colList[6]
  url  = colList[8]
  if self.VVbkmj() : self.VVWyxg("Cannot delete !\n\nFile is downloading.")
  else      : FFOjga(self.SELF, BF(self.VV9fgx, path, url), "Delete ?\n\n%s" % path, title=title)
 def VV9fgx(self, path, url):
  m3u8Log = self.VVl7Cx.VVRTTA()[12]
  if m3u8Log : os.system(FFlWZ0("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFlWZ0("rm -r '%s'" % path))
  self.VVgoWn(False)
  self.VVOy0n()
 def VVgoWn(self, VViqYq=True):
  if self.VVbkmj():
   FFMYB5(self.VVl7Cx, self.VVRckj(self.VVUBJr), 500)
  else:
   colList  = self.VVl7Cx.VVRTTA()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VV63iB(state) in (self.VV4nDf, self.VV5zW8, self.VVw1WV):
    lines = CCEgwO.VV3dVR()
    newLines = []
    found = False
    for line in lines:
     if CCEgwO.VVs9zZ(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VV0FX1(newLines)
     self.VVOy0n()
     FFMYB5(self.VVl7Cx, "Removed.", 1000)
    else:
     FFMYB5(self.VVl7Cx, "Not found.", 1000)
   elif VViqYq:
    self.VVWyxg("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVtAQb(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFOjga(self.SELF, BF(self.VV7xDG, flag), ques, title=title)
 def VV7xDG(self, flag):
  list = []
  for ndx, row in enumerate(self.VVl7Cx.VVBOVP()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VV63iB(state)
   if   flag == flagVal == self.VV5zW8: list.append(decodedUrl)
   elif flag == flagVal == self.VV4nDf : list.append(decodedUrl)
  lines = CCEgwO.VV3dVR()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VV0FX1(newLines)
   self.VVOy0n()
   FFMYB5(self.VVl7Cx, "%d removed." % totRem, 1000)
  else:
   FFMYB5(self.VVl7Cx, "Not found.", 1000)
 def VVk442(self):
  colList  = self.VVl7Cx.VVRTTA()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFMYB5(self.VVl7Cx, "Poster exists", 1500)
  else    : FFqXEj(self.VVl7Cx, BF(self.VVDhk0, decodedUrl, path, png), title="Checking Server ...")
 def VVDhk0(self, decodedUrl, path, png):
  err = self.VVV7HR(decodedUrl, path, png)
  if err:
   FFAvZA(self.SELF, err, title="Poster Download")
 def VVV7HR(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCcf6M.VVOmqb(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCaayN.VVBGRU(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCaayN.VVokhy(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCaayN.VV6hiq(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FF8zMR(pUrl, "ajpanel_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   os.system(FFlWZ0("mv -f '%s' '%s'" % (tPath, png)))
   CC1AR1.VVkxof(self.SELF, VV9GFC=png, showGrnMsg="Downloaded")
   return ""
 def VVAyY4(self, VVl7Cx, title, txt, colList):
  def VV6J2i(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVQesM(key, val) : return "\n%s:\n%s\n" % (FFNkac(key, VVXaO9), val.strip())
  heads  = self.VVl7Cx.VVEoLZ()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VV6J2i(heads[i]  , CCeH84.VVpYrc(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VV6J2i("Downloaded" , CCeH84.VVpYrc(int(curSize), mode=0))
   else:
    txt += VV6J2i(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVQesM(heads[i], colList[i])
  FFheEQ(self.SELF, txt, title=title)
 def VVYWcO(self, VVl7Cx, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCeH84.VVpZNA(self.SELF, path)
  else    : FFMYB5(self.VVl7Cx, "File not found", 1000)
 def VVyBwL(self, VVl7Cx):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVl7Cx:
   self.VVl7Cx.cancel()
  del self
 def VV7bp9(self, VVl7Cx, title, txt, colList):
  c1, c2, c3 = VVhTQL, VVHKA4, VVXaO9
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVwSHr = []
  VVwSHr.append((c1 + "Remove current row"       , "VVgoWn" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVwSHr.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append((c2 + "Delete the file (and remove from list)"  , "VVA5pv"))
  VVwSHr.append(VVbzyo)
  VVwSHr.append((resumeTxt + " Auto Resume"       , "VVKWdN" ))
  VVwSHr.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVwSHr.append(VVbzyo)
  t = "Download Movie Poster "
  if FFQf5u(decodedUrl): VVwSHr.append((c3 + "%s(from server)" % t , "VVk442"  ))
  else      : VVwSHr.append(("%s... Movies only" % t ,      ))
  if fileExists(path) : VVwSHr.append((c3 + "Open in File Manager" , "inFileMan,%s" % path ))
  else    : VVwSHr.append(("Open in File Manager"  ,      ))
  FFKX6p(self.SELF, BF(self.VVygVu, VVl7Cx), VVwSHr=VVwSHr, title=self.Title, VVto4D=True, width=800, VVL5Ba=True, VVCNiH="#1a001122", VVIhEb="#1a001122")
 def VVygVu(self, VVl7Cx, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVgoWn"  : self.VVgoWn()
   elif ref == "remFinished"   : self.VVtAQb(self.VV5zW8, txt)
   elif ref == "remPending"   : self.VVtAQb(self.VV4nDf, txt)
   elif ref == "VVA5pv" : self.VVA5pv(txt)
   elif ref == "VVk442"  : self.VVk442()
   elif ref == "VVKWdN"  : FFGxwH(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FFGxwH(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CCeH84, mode=CCeH84.VVcWEv, jumpToFile=path)
    else    : FFMYB5(VVl7Cx, "Path not found !", 1500)
 def VVdMvz(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCcf6M.VVOmqb(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVWyxg("Could not get download link !\n\nTry again later.")
     return
  for line in CCEgwO.VV3dVR():
   if CCEgwO.VVs9zZ(decodedUrl, line):
    if self.VVl7Cx:
     self.VVfK3A(decodedUrl)
     FFuqQK(BF(FFMYB5, self.VVl7Cx, "Already listed !", 2000))
    break
  else:
   params = self.VVfiv8(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVWyxg(params[0])
   elif len(params) == 2:
    FFOjga(self.SELF, BF(self.VVuHbj, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCeH84.VVpYrc(fSize)
    FFOjga(self.SELF, BF(self.VV7HxV, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VV7HxV(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCEgwO.VVFBwV(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVOy0n()
  if self.VVl7Cx:
   self.VVl7Cx.VVF53M()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCEgwO.VV9Tcp, path, decodedUrl)
   self.VVT4wi(threadName, url, decodedUrl, path, resp)
 def VVfK3A(self, decodedUrl):
  if self.VVl7Cx:
   for ndx, row in enumerate(self.VVl7Cx.VVBOVP()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVl7Cx:
     self.VVl7Cx.VVm16r(ndx)
     break
 def VVfiv8(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVKc5N(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVOV6X(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCcf6M.VVOmqb(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCcf6M.VVReea()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCEgwO.VVdDAR(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCEgwO.VVTTqW(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVuHbj(self, resp, decodedUrl):
  if not os.system(FFlWZ0("which ffmpeg")) == 0:
   FFOjga(self.SELF, BF(CCaayN.VVz8nj, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVKc5N(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVYhIN(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFOjga(self.SELF, BF(self.VVOv6g, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVOv6g(rTxt, rUrl)
  else:
   self.VVWyxg("Cannot process m3u8 file !")
 def VVYhIN(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVwSHr = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCaayN.VV2pD7(rUrl, fPath)
   VVwSHr.append((resol, fullUrl))
  if VVwSHr:
   FFKX6p(self.SELF, self.VVrzJo, VVwSHr=VVwSHr, title="Resolution", VVto4D=True, VVL5Ba=True)
  else:
   self.VVWyxg("Cannot get Resolutions list from server !")
 def VVrzJo(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFOjga(self.SELF, BF(FFuqQK, BF(self.VV8hyf, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFuqQK(BF(self.VV8hyf, resolUrl))
 def VV8hyf(self, resolUrl):
  txt, err = CCcf6M.VV6nkC(resolUrl)
  if err : self.VVWyxg(err)
  else : self.VVOv6g(txt, resolUrl)
 def VVMynd(self, logF, decodedUrl):
  found = False
  lines = CCEgwO.VV3dVR()
  with open(CCEgwO.VVFBwV(), "w") as f:
   for line in lines:
    if CCEgwO.VVs9zZ(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCEgwO.VVFBwV(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVOy0n()
  if self.VVl7Cx:
   self.VVl7Cx.VVF53M()
 def VVOv6g(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCaayN.VV2pD7(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVWyxg("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVMynd(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFlWZ0("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCEgwO.VV9Tcp, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVn2f1(dnldLog):
  if fileExists(dnldLog):
   dur = CCEgwO.VVtoDA(dnldLog)
   if dur > -1:
    tim = CCEgwO.VVHSNL(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVtoDA(dnldLog):
  lines = FFIsyt("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVHSNL(dnldLog):
  lines = FFIsyt("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVOV6X(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFz5m2(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFlWZ0("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVT4wi(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVl7Cx.VVRTTA()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VV3qC3, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VV3qC3(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVpliX == path:
       break
     else:
      break
  except:
   return
  if CCEgwO.VVpliX:
   CCEgwO.VVpliX = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFtd04(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVfiv8(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VV3qC3(url, decodedUrl, path, resp, totFileSize, True)
 def VVR9fx(self, VVl7Cx, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VV864m() : FFMYB5(self.VVl7Cx, self.VVRckj(self.VV5zW8), 500)
  elif not self.VVbkmj() : FFMYB5(self.VVl7Cx, self.VVRckj(self.VVw1WV), 500)
  elif m3u8Log      : FFOjga(self.SELF, self.VV8DWp, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVw17N():
    CCEgwO.VVpliX = colList[6]
    FFMYB5(self.VVl7Cx, "Stopping ...", 1000)
   else:
    FFMYB5(self.VVl7Cx, "Stopped", 500)
 def VV8DWp(self, withMsg=True):
  if withMsg:
   FFMYB5(self.VVl7Cx, "Stopping ...", 1000)
  os.system(FFlWZ0("killall -INT ffmpeg"))
 def VV9fDC(self, *args):
  if   self.VV864m() : FFMYB5(self.VVl7Cx, self.VVRckj(self.VV5zW8) , 500)
  elif self.VVbkmj() : FFMYB5(self.VVl7Cx, self.VVRckj(self.VVUBJr), 500)
  else:
   resume = False
   m3u8Log = self.VVl7Cx.VVRTTA()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFOjga(self.SELF, BF(self.VVfefk, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVhDop():
    resume = True
   if resume: FFqXEj(self.VVl7Cx, BF(self.VVE4KE), title="Checking Server ...")
   else  : FFMYB5(self.VVl7Cx, "Cannot resume !", 500)
 def VVfefk(self, m3u8Log):
  os.system(FFlWZ0("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFqXEj(self.VVl7Cx, BF(self.VVE4KE), title="Checking Server ...")
 def VVE4KE(self):
  colList  = self.VVl7Cx.VVRTTA()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCcf6M.VVOmqb(decodedUrl)
   if url:
    decodedUrl = self.VVDvDn(decodedUrl, url)
   else:
    self.VVWyxg("Could not get download link !\n\nTry again later.")
    return
  curSize = FFtd04(path)
  params = self.VVfiv8(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVWyxg(params[0])
   return
  elif len(params) == 2:
   self.VVuHbj(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVDvDn(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCEgwO.VV9Tcp, path, decodedUrl)
  if resumable: self.VVT4wi(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVWyxg("Cannot resume from server !")
 def VVKc5N(self, decodedUrl):
  fileExt = CCaayN.VVmuAb(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FF3iML(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVWyxg(self, txt):
  FFAvZA(self.SELF, txt, title=self.Title)
 def VVw17N(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCEgwO.VV9Tcp, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVbkmj(self):
  decodedUrl = self.VVl7Cx.VVRTTA()[9]
  return decodedUrl in self.VVw17N()
 def VV864m(self):
  colList = self.VVl7Cx.VVRTTA()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFtd04(path)) == size
 def VVhDop(self):
  colList = self.VVl7Cx.VVRTTA()
  path = colList[6]
  size = int(colList[7])
  curSize = FFtd04(path)
  if curSize > -1:
   size -= curSize
  err = CCEgwO.VVTTqW(size)
  if err:
   FFAvZA(self.SELF, err, title=self.Title)
   return False
  return True
 def VV0FX1(self, list):
  with open(CCEgwO.VVFBwV(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVDvDn(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCEgwO.VV3dVR()
  url = decodedUrl
  with open(CCEgwO.VVFBwV(), "w") as f:
   for line in lines:
    if CCEgwO.VVs9zZ(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVOy0n()
  return url
 @staticmethod
 def VV3dVR():
  list = []
  if fileExists(CCEgwO.VVFBwV()):
   for line in FF7up6(CCEgwO.VVFBwV()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVs9zZ(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVTTqW(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCeH84.VVkvYz(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCeH84.VVpYrc(size), CCeH84.VVpYrc(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVsSBf(SELF):
  tot = CCEgwO.VVwzmj()
  if tot:
   FFAvZA(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVwzmj():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCEgwO.VV9Tcp):
    c += 1
  return c
 @staticmethod
 def VVbJ3i():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCEgwO.VV9Tcp, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VV84hj():
  return len(CCEgwO.VV3dVR()) == 0
 @staticmethod
 def VVJRVo():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVycOt():
  mPoints = CCEgwO.VVJRVo()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFlWZ0("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVFBwV():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVloZW(SELF):
  CCEgwO.VV64Ir(SELF, CCEgwO.VV2bBz)
 @staticmethod
 def VVJUop(SELF):
  CCEgwO.VV64Ir(SELF, CCEgwO.VVqh3l, startDnld=True)
 @staticmethod
 def VV3DSl(SELF, url):
  CCEgwO.VV64Ir(SELF, CCEgwO.VVqh3l, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVZ4oI(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(SELF)
  added, skipped = CCEgwO.VVe5Q6([decodedUrl])
  FFMYB5(SELF, "Added", 1000)
 @staticmethod
 def VVe5Q6(list):
  added = skipped = 0
  for line in CCEgwO.VV3dVR():
   for ndx, url in enumerate(list):
    if url and CCEgwO.VVs9zZ(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCEgwO.VVFBwV(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VV64Ir(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCXk4n.VV9Kgc(SELF):
   return
  if mode == CCEgwO.VV2bBz and CCEgwO.VV84hj():
   FFAvZA(SELF, "Download list is empty !", title=title)
  else:
   inst = CCEgwO(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVdDAR(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCcojD(Screen, CC3oLs):
 VVkJzO = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, isFromExternal=False, enableDownloadMenu=True, enableOpenInFMan=True):
  self.skin, self.skinParam = FFheJw(VVFcCy, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CC3oLs.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.enableOpenInFMan  = enableOpenInFMan
  self.iptvTableParams  = iptvTableParams
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FFqVmU(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVsFBY())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVmBrJ       ,
   "info"  : self.VVXEta      ,
   "epg"  : self.VVXEta      ,
   "menu"  : self.VV2xAT     ,
   "cancel" : self.cancel       ,
   "red"  : self.VVNDFL   ,
   "green"  : self.VVEPnk  ,
   "blue"  : self.VVHThV      ,
   "yellow" : self.VV3tB6 ,
   "left"  : BF(self.VVkuFM, -1)    ,
   "right"  : BF(self.VVkuFM,  1)    ,
   "play"  : self.VVJPQm      ,
   "pause"  : self.VVJPQm      ,
   "playPause" : self.VVJPQm      ,
   "stop"  : self.VVJPQm      ,
   "rewind" : self.VVoCPI      ,
   "forward" : self.VVasLL      ,
   "rewindDm" : self.VVoCPI      ,
   "forwardDm" : self.VVasLL      ,
   "last"  : self.VVRbIj      ,
   "next"  : self.VVQMaX      ,
   "pageUp" : BF(self.VVIVIv, True)  ,
   "pageDown" : BF(self.VVIVIv, False)  ,
   "chanUp" : BF(self.VVIVIv, True)  ,
   "chanDown" : BF(self.VVIVIv, False)  ,
   "up"  : BF(self.VVIVIv, True)  ,
   "down"  : BF(self.VVIVIv, False)  ,
   "audio"  : BF(self.VV6kyK, True)  ,
   "subtitle" : BF(self.VV6kyK, False)  ,
   "text"  : self.VVysLP  ,
   "0"   : BF(self.VVVVrc , 10)   ,
   "1"   : BF(self.VVVVrc , 1)   ,
   "2"   : BF(self.VVVVrc , 2)   ,
   "3"   : BF(self.VVVVrc , 3)   ,
   "4"   : BF(self.VVVVrc , 4)   ,
   "5"   : BF(self.VVVVrc , 5)   ,
   "6"   : BF(self.VVVVrc , 6)   ,
   "7"   : BF(self.VVVVrc , 7)   ,
   "8"   : BF(self.VVVVrc , 8)   ,
   "9"   : BF(self.VVVVrc , 9)
  }, -1)
  self.onShown.append(self.VVevf4)
  self.onClose.append(self.onExit)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  FFuN11(self)
  if not CCcojD.VVkJzO:
   CCcojD.VVkJzO = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFpx0D(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFpx0D(self["myPlayRpt"], "rpt")
  self.VVt4hn()
  self.instance.move(ePoint(40, 40))
  self.VVew6b(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVkXpe)
  except:
   self.timer.callback.append(self.VVkXpe)
  self.timer.start(250, False)
  self.VVkXpe("Checking ...")
  self.VV2BeA()
 def VVEPnk(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self)
  self.lastSubtitle = CC9Rlw.VVeZL2()
  if "chCode" in iptvRef:
   if CCXk4n.VV9Kgc(self):
    self.VV2BeA(True)
  else:
   self.VVkXpe("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVt4hn(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVf9pe()
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VVmIAH + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FFAMY6(self["myTitle"], tColor)
  FFAMY6(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFAMY6(self["myPlay%s" % item], tColor)
  picFile = CCnfxp.VV36by(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CCnfxp.VVGHgl(self)
  cl = CCZBdY.VVLSHJ(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VVkXpe(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCEgwO.VVwzmj()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVf9pe()
  if evName:
   evName = "    %s    " % FFNkac(evName, VVcK7G)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVoTsP():
   FFilsZ(self["myPlayBlu"], "#00FFFFFF")
   FFAMY6(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFilsZ(self["myPlayBlu"], "#00FFFF88")
   FFAMY6(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FFAMY6(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FFrVTn(percVal, 0, 100)
   width = int(FFzS0X(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FFAMY6(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFilsZ(self["myPlayMsg"], "#0000ffff")
   else  : FFilsZ(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFilsZ(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFilsZ(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VV92Sq()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VVtE1K(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CC9Rlw.VVbJwk(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVRbIj()
  state = self.VVJqqR()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFilsZ(self["myPlayMsg"], "#0000ff00")
  else     : FFilsZ(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVf9pe(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFbgUV(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCcojD.VV1JQT(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCnfxp.VVgF5Q(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CCpEt4()
   tpTxt, satTxt = tp.VV0xaW(refCode)
   self.satInfo_TP = tpTxt + "  " + FFNkac(satTxt, VVtjbM)
  evName = evNameNext = ""
  evLst = CCnfxp.VVqonL(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFCNz5(info, iServiceInformation.sVideoWidth) or -1
   h = FFCNz5(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFCNz5(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CCnfxp.VVEyP4(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VV1JQT(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFQjGS(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFQjGS(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFQjGS(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VV2xAT(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVf9pe()
  FFQf5uSeries = FF3iML(decodedUrl)
  VVwSHr = []
  if self.isFromExternal:
   VVwSHr.append((VVtjbM + "IPTV Menu"   , "iptv" ))
   VVwSHr.append(VVbzyo)
  if isIptv and not "&end=" in decodedUrl and not FFQf5uSeries:
   uType, uHost, uUser, uPass, uId, uChName = CCaayN.VVBGRU(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVwSHr.append((VVtjbM + "Catchup Programs", "catchup" ))
    VVwSHr.append(VVbzyo)
  if refCode:
   c = VVmIAH
   VVwSHr.append((c + "Stop Current Service"  , "stop"  ))
   VVwSHr.append((c + "Restart Current Service" , "restart"  ))
   VVwSHr.append(VVbzyo)
  if FFQf5uSeries:
   VVwSHr.append((VVtjbM + "File Size (on server)", "fileSize" ))
   VVwSHr.append(VVbzyo)
  if self.enableDownloadMenu:
   c = VVtjbM
   addSep = False
   if isIptv and FFQf5uSeries:
    VVwSHr.append((c + "Start Download"   , "dload_cur" ))
    VVwSHr.append((c + "Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCEgwO.VV84hj():
    VVwSHr.append((VVtjbM + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVwSHr.append(VVbzyo)
  fPath, fDir, fName = CCeH84.VVYryR(self)
  if fPath:
   c = VV4YPU
   if self.enableOpenInFMan and not CCeH84.VVpEEa:
    VVwSHr.append((c + "Open path in File Manager", "VVA6KH"))
   VVwSHr.append((c + "Add to Bouquet"             , "VVVEd0" ))
   VVwSHr.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVb1Ze"  ))
   VVwSHr.append(VVbzyo)
  if isDvb:
   VVwSHr.append((VVtjbM + "Signal Monitor", "sigMon"   ))
  if posTxt and durTxt:
   VVwSHr.append((VVXaO9 + "Start Subtitle", "VVlyml"))
   VVwSHr.append(VVbzyo)
  if CFG.playerPos.getValue() : VVwSHr.append(("Move Bar to Bottom"  , "botm"    ))
  else      : VVwSHr.append(("Move Bar to Top"  , "top"     ))
  VVwSHr.append(("Help"             , "help"    ))
  FFKX6p(self, self.VVcH9V, VVwSHr=VVwSHr, width=600, title="Options")
 def VVcH9V(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VV3tB6()
   elif item == "stop"     : self.VVzv24(0)
   elif item == "restart"    : self.VVzv24(1)
   elif item == "fileSize"    : FFqXEj(self, BF(CCnfxp.VVg8Nl, self), title="Checking Server")
   elif item == "dload_cur"   : CCEgwO.VVJUop(self)
   elif item == "addToDload"   : CCEgwO.VVZ4oI(self)
   elif item == "dload_stat"   : CCEgwO.VVloZW(self)
   elif item == "VVA6KH" : self.close("close_openInFileMan")
   elif item == "VVVEd0" : self.VVVEd0()
   elif item == "VVlyml"  : self.VVx8Nu()
   elif item == "VVb1Ze"  : self.VVb1Ze()
   elif item == "botm"     : self.VVew6b(0)
   elif item == "top"     : self.VVew6b(1)
   elif item == "sigMon"    : self.VVNDFL()
   elif item == "help"     : FFK3qq(self, VVdSQY + "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCcojD.VVkJzO = None
 def VVzv24(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVt4hn()
   elif typ == 1:
    self.VVkXpe("Restarting Service ...")
    FFuqQK(BF(self.VVcflW, serv))
 def VVcflW(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self)
  if "&end=" in decodedUrl: BF(self.VV2BeA, True)
  else     : self.session.nav.playService(serv)
 def VVVEd0(self):
  fPath, fDir, fName = CCeH84.VVYryR(self)
  if fPath: picker = CCCBMo(self, self, "Add Current Movie to a Bouquet", BF(self.VVOYsC, [fPath]))
  else : FFMYB5(self, "Path not found !", 1500)
 def VVOYsC(self, pathLst):
  return CCCBMo.VVtG1f(pathLst)
 def VVb1Ze(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCcojD.VV1JQT(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVkXpe(txt, highlight=ok)
 def VVew6b(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FFGxwH(CFG.playerPos, pos)
 def VVNDFL(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCnfxp.VVgF5Q(serv)
   if isDvb: self.close("close_sig")
   else : self.VVkXpe("No Signal for Current Service")
 def VVx8Nu(self):
  self.session.openWithCallback(self.VVSmOi, BF(CC9Rlw))
 def VVysLP(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVf9pe()
   if posTxt and durTxt: self.VVx8Nu()
   else    : self.VVkXpe("No duration Info. !")
 def VVSmOi(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VVIVIv(True)
  elif reason == "subtZapDn" : self.VVIVIv(False)
  elif reason == "pause"  : self.VVJPQm()
  elif reason == "audio"  : self.VV6kyK(True)
  elif reason == "subtitle" : self.VV6kyK(False)
  elif reason == "rewind"     : self.VVoCPI()
  elif reason == "forward" : self.VVasLL()
  elif reason == "rewindDm" : self.VVoCPI()
  elif reason == "forwardDm" : self.VVasLL()
  else      : txt = reason
  if txt:
   FFMYB5(self, txt, 2000)
 def VVmBrJ(self):
  if self.isManualSeek:
   self.VVrUiT()
   self.VVtE1K(self.manualSeekPts)
  elif self.shown:
   if CC9Rlw.VV0aKm(self): self.VVx8Nu()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVrUiT()
  else    : self.close()
 def VVXEta(self):
  FFQTAA(self, fncMode=CCnfxp.VVnHwO)
 def VVJPQm(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVkXpe("Toggling Play/Pause ...")
 def VVrUiT(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVkuFM(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCcojD.VV1JQT(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVW80c()
   else:
    self.manualSeekSec += direc * self.VVW80c()
    self.manualSeekSec = FFrVTn(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFzS0X(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFQjGS(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVVVrc(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVsFBY())
   FFGxwH(CFG.playerJumpMin, self.jumpMinutes)
  self.VVkXpe("Changed Seek Time to : %d%s" % (val, self.VVI0tq()))
 def VVsFBY(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVI0tq())
 def VVI0tq(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVkP8E(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVW80c(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VV92Sq(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVHThV(self):
  cList = self.VVoTsP()
  if cList:
   VVwSHr = []
   for pts, what in cList:
    txt = FFQjGS(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVwSHr.append((txt, pts))
   FFKX6p(self, self.VVZSXz, VVwSHr=VVwSHr, title="Cut List")
  else:
   self.VVkXpe("No Cut-List for this channel !")
 def VVZSXz(self, item=None):
  if item:
   self.VVtE1K(item)
 def VVoTsP(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVasLL(self) : self.VVRESL(1)
 def VVoCPI(self) : self.VVRESL(-1)
 def VVRESL(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCcojD.VV1JQT(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVW80c() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVkP8E())
    self.VVkXpe(txt)
  except:
   self.VVkXpe("Cannot jump")
 def VVtE1K(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVkXpe("Changing Time ...")
 def VVRbIj(self):
  self.VVzv24(1)
  self.VVkXpe("Replaying ...")
  self.VVrUiT()
 def VVQMaX(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCcojD.VV1JQT(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVkXpe("Jumping to end ...")
  except:
   pass
 def VVJqqR(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVIVIv(self, isUp):
  if self.enableZapping:
   self.VVkXpe("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVrUiT()
   if self.iptvTableParams:
    FFuqQK(BF(self.VVBvvf, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self)
    if "/timeshift/" in decodedUrl:
     self.VVkXpe("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVTglz()
  else:
   self.VVkXpe("Zap Disabled !")
 def VVTglz(self):
  self.lastPlayPos = 0
  self.VVt4hn()
  self.VV2BeA()
 def VVBvvf(self, isUp):
  CCaayN_inatance, VVl7Cx, mode = self.iptvTableParams
  if isUp : VVl7Cx.VVlSGS()
  else : VVl7Cx.VVo4gD()
  colList = VVl7Cx.VVRTTA()
  if mode == "localIptv":
   chName, chUrl = CCaayN_inatance.VVCu06(VVl7Cx, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCaayN_inatance.VVpi7F(VVl7Cx, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCaayN_inatance.VVQWoA(mode, VVl7Cx, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCaayN_inatance.VVI1hv(mode, VVl7Cx, colList)
  else:
   self.VVkXpe("Cannot Zap")
   return
  FFf8Q6(self, chUrl, VVIqkw=False)
  self.VVTglz()
 def VV2BeA(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCcojD.VV1JQT(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self)
   if not self.VVGbY9(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVkXpe("Refreshing Portal")
   FFuqQK(self.VV1ORL)
  except:
   pass
 def VV1ORL(self):
  self.restoreLastPlayPos = self.VVw0dy()
 def VV3tB6(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self)
  if not decodedUrl or FF3iML(decodedUrl):
   self.VVkXpe("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCaayN.VVBGRU(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVkXpe("Reading Program List ...")
   ok_fnc = BF(self.VVE6s2, refCode, chName, streamId, uHost, uUser, uPass)
   FFuqQK(BF(CCaayN.VVT4Ch, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVkXpe("Cannot process this channel")
 def VVE6s2(self, refCode, chName, streamId, uHost, uUser, uPass, VVl7Cx, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVl7Cx.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVkXpe("Changing Program ...")
   FFuqQK(BF(self.VVnmA5, chUrl))
  else:
   self.VVkXpe("Incorrect Timestamp !")
 def VVnmA5(self, chUrl):
  FFf8Q6(self, chUrl, VVIqkw=False)
  self.lastPlayPos = 0
  self.VVt4hn()
 def VV6kyK(self, isAudio):
  try:
   VVreUe = InfoBar.instance
   if VVreUe:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVreUe)
    else  : self.session.open(SubtitleSelection, VVreUe)
  except:
   pass
 @staticmethod
 def VVGxJ9(session, mode=None):
  if   mode == "close_sig"   : FF3UUy(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CCaayN)
  elif mode == "close_openInFileMan" : session.open(CCeH84, gotoMovie=True)
 @staticmethod
 def VVEI1u(session, isFromExternal=False, **kwargs):
  session.openWithCallback(BF(CCcojD.VVGxJ9, session), CCcojD, isFromExternal=isFromExternal, **kwargs)
class CCbt2B(Screen):
 def __init__(self, session, title="", VVByb6="Continue?", VV8V8a=True, VVA7RB=False):
  self.skin, self.skinParam = FFheJw(VVW7yA, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVByb6 = VVByb6
  self.VVA7RB = VVA7RB
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VV8V8a : VVwSHr = [no , yes]
  else   : VVwSHr = [yes, no ]
  FFqVmU(self, title, VVwSHr=VVwSHr, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVmBrJ ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVByb6)
  if self.VVA7RB:
   self["myLabel"].instance.setHAlign(0)
  self.VVXIna()
  FFpkQc(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFJGGi(self["myMenu"])
  FFqDWf(self, self["myMenu"])
 def VVmBrJ(self):
  item = FFulUr(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVXIna(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCK3F9(Screen):
 def __init__(self, session, title="", VVwSHr=None, width=1000, height=0, VV2ql8=30, barText="", minRows=1, OKBtnFnc=None, VVMcss=None, VV7qf7=None, VVoZDD=None, VVWYuC=None, VVto4D=False, VVL5Ba=False, VVCNiH="#22003344", VVIhEb="#22002233"):
  if height == 0: height = 850
  self.skin, self.skinParam = FFheJw(VVXQaf, width, height, 50, 40, 30, VVCNiH, VVIhEb, VV2ql8, barHeight=40)
  self.session   = session
  self.VVwSHr   = VVwSHr
  self.barText   = barText
  self.minRows   = minRows
  self.OKBtnFnc   = OKBtnFnc
  self.VVMcss   = VVMcss
  self.VV7qf7  = VV7qf7
  self.VVoZDD  = VVoZDD
  self.VVWYuC   = VVWYuC
  self.VVto4D  = VVto4D
  self.VVL5Ba  = VVL5Ba
  FFqVmU(self, title, VVwSHr=VVwSHr)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVmBrJ          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVD72P         ,
   "green"  : self.VVBwiZ         ,
   "yellow" : self.VVYGkG         ,
   "blue"  : self.VVFls6         ,
   "pageUp" : self.VVW9rN       ,
   "chanUp" : self.VVW9rN       ,
   "pageDown" : self.VVNIk3        ,
   "chanDown" : self.VVNIk3
  }, -1)
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  FFpkQc(self["myMenu"])
  FFQGfp(self, minRows=self.minRows)
  self.VVX99e(self["keyRed"]  , self.VVMcss )
  self.VVX99e(self["keyGreen"] , self.VV7qf7 )
  self.VVX99e(self["keyYellow"] , self.VVoZDD )
  self.VVX99e(self["keyBlue"]  , self.VVWYuC )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFBmK5(self)
 def VVX99e(self, btnObj, btnFnc):
  if btnFnc:
   FFTGpi(btnObj, btnFnc[0])
 def VVX49t(self, fnc=None):
  self.VV7qf7 = fnc
  if fnc : self.VVX99e(self["keyGreen"], self.VV7qf7)
  else : self["keyGreen"].hide()
 def VVmBrJ(self):
  item = FFulUr(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVto4D: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVD72P(self)  : self.VViIob(self.VVMcss)
 def VVBwiZ(self) : self.VViIob(self.VV7qf7)
 def VVYGkG(self) : self.VViIob(self.VVoZDD)
 def VVFls6(self) : self.VViIob(self.VVWYuC)
 def VViIob(self, btnFnc):
  if btnFnc:
   item = FFulUr(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVL5Ba:
    self.cancel()
 def VVEPkY(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VVPjeT(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVwSHr = self["myMenu"].list
  VVwSHr.pop(ndx)
  if len(VVwSHr) > 0: self["myMenu"].setList(VVwSHr)
  else    : self.close()
 def VVTD7t(self, VVwSHr):
  if len(VVwSHr) > 0:
   newList = []
   for item in VVwSHr:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFQGfp(self, minRows=self.minRows)
  else:
   self.close("")
 def VV0FMl(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FFQGfp(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVqSiW(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVW9rN(self):
  self["myMenu"].moveToIndex(0)
 def VVNIk3(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCTHnd(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VVd40u=None, VVe5VU=None, VVLpvM=None, VV2ql8=26, VV1YOp=False, VVkbOA=0, VVVt3G=None, VV0QzM=None, VVlNkE=None, VVcZtS=None, VVq3zo=None, VVrIQY=None, VVGssA=None, VV3zZz=None, VVPypB=None, VVBEEG=-1, VVtvxl=False, searchCol=0, lastFindConfigObj=None, VVCNiH=None, VVIhEb=None, VVQpxk="#00dddddd", VV9Ea0="#11002233", VV0HYK="#00ff8833", VVZozG="#11111111", VVsrIN="#0a555555", VVeJ4R="#0affffff", VVn0US="#11552200", VV0k8r="#0055ff55"):
  self.skin, self.skinParam = FFheJw(VVXRSp, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFqVmU(self, title)
  self.Title     = title
  self.header     = header
  self.VVd40u     = VVd40u
  self.totalCols    = len(VVd40u[0])
  self.VVkbOA   = VVkbOA
  self.lastSortModeIsReverese = False
  self.VV1YOp   = VV1YOp
  self.VVDPe5   = 0.01
  self.VVs9oW   = 0.02
  self.VVvVbv = 0.03
  self.VVLdf5  = 1
  self.VVLpvM = VVLpvM
  self.colWidthPixels   = []
  self.VVVt3G   = VVVt3G
  self.OKButtonObj   = None
  self.VV0QzM   = VV0QzM
  self.VVlNkE   = VVlNkE
  self.VVcZtS   = VVcZtS
  self.VVq3zo  = VVq3zo
  self.VVrIQY   = VVrIQY
  self.VVGssA    = VVGssA
  self.VV3zZz   = VV3zZz
  self.tableRefreshCB   = None
  self.VVPypB  = VVPypB
  self.VVBEEG    = VVBEEG
  self.VVtvxl   = VVtvxl
  self.searchCol    = searchCol
  self.VVe5VU    = VVe5VU
  self.keyPressed    = -1
  self.VV2ql8    = FFfwAy(VV2ql8)
  self.VVSYmq    = FFCOh0(self.VV2ql8, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVCNiH    = VVCNiH
  self.VVIhEb      = VVIhEb
  self.VVQpxk    = FFUCM9(VVQpxk)
  self.VV9Ea0    = FFUCM9(VV9Ea0)
  self.VV0HYK    = FFUCM9(VV0HYK)
  self.VVZozG    = FFUCM9(VVZozG)
  self.VVsrIN   = FFUCM9(VVsrIN)
  self.VVeJ4R    = FFUCM9(VVeJ4R)
  self.VVn0US    = FFUCM9(VVn0US)
  self.VV0k8r   = FFUCM9(VV0k8r)
  self.VVUCzo  = False
  self.selectedItems   = 0
  self.VVD1eF   = FFUCM9("#01fefe01")
  self.VV7XoG   = FFUCM9("#11400040")
  self.VVMRk6  = self.VVD1eF
  self.VVZ4ng  = self.VVZozG
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVtvxl:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VViOwa  ,
   "red"   : self.VV4IBW  ,
   "green"   : self.VVm3TC ,
   "yellow"  : self.VVAuZb ,
   "blue"   : self.VVmqKD  ,
   "menu"   : self.VVN3e2 ,
   "info"   : self.VVbfxA  ,
   "cancel"  : self.VVa4kU  ,
   "up"   : self.VVo4gD    ,
   "down"   : self.VVlSGS  ,
   "left"   : self.VVimMN   ,
   "right"   : self.VVA4xu  ,
   "next"   : self.VVG6aZ  ,
   "last"   : self.VVqVhf  ,
   "home"   : self.VVnzYl  ,
   "pageUp"  : self.VVnzYl  ,
   "chanUp"  : self.VVnzYl  ,
   "end"   : self.VVF53M  ,
   "pageDown"  : self.VVF53M  ,
   "chanDown"  : self.VVF53M
  }, -1)
  FFnqTm(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  FFuN11(self)
  try:
   self.VVCCDS()
  except Exception as e:
   FFAvZA(self, str(e), title=self.Title)
   self.close(None)
 def VVCCDS(self):
  FFBmK5(self)
  if self.VVCNiH:
   FFAMY6(self["myTitle"], self.VVCNiH)
  if self.VVIhEb:
   FFAMY6(self["myBody"] , self.VVIhEb)
   FFAMY6(self["myTableH"] , self.VVIhEb)
   FFAMY6(self["myTable"] , self.VVIhEb)
   FFAMY6(self["myBar"]  , self.VVIhEb)
  self.VVX99e(self.VVlNkE  , self["keyRed"])
  self.VVX99e(self.VVcZtS  , self["keyGreen"])
  self.VVX99e(self.VVq3zo , self["keyYellow"])
  self.VVX99e(self.VVrIQY  , self["keyBlue"])
  if self.VVVt3G:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVVt3G[0])
    FFAMY6(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVSYmq)
  self["myTableH"].l.setFont(0, gFont(VVOCsc, self.VV2ql8))
  self["myTable"].l.setItemHeight(self.VVSYmq)
  self["myTable"].l.setFont(0, gFont(VVOCsc, self.VV2ql8))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVSYmq)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVSYmq))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVSYmq)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVSYmq
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVSYmq * len(self.VVd40u) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVLpvM:
   self.VVLpvM = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVLpvM)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVe5VU:
   self.VVe5VU = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVe5VU
   self.VVe5VU = []
   for item in tmpList:
    self.VVe5VU.append(item | RT_VALIGN_CENTER)
  self.VVAHnE()
  if self.VVGssA:
   self.VVGssA(self)
 def VVX99e(self, btnFnc, btn):
  if btnFnc : FFTGpi(btn, btnFnc[0])
  else  : FFTGpi(btn, "")
 def VVEXaO(self, waitTxt):
  FFqXEj(self, self.VVAHnE, title=waitTxt)
 def VVAHnE(self, onlyHeader=False):
  try:
   if self.header:
    self["myTableH"].setList([self.VVYje1(0, self.header, self.VVeJ4R, self.VVn0US, self.VVeJ4R, self.VVn0US, self.VV0k8r)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVd40u):
    self["myTable"].list.append(self.VVYje1(c, row, self.VVQpxk, self.VV9Ea0, self.VV0HYK, self.VVZozG, None))
   self.VVd40u = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVBEEG > -1:
    self["myTable"].moveToIndex(self.VVBEEG )
   self.VVolUD()
   if self.VVtvxl:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVSYmq * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VV3zZz:
    self.VViIob(self.VV3zZz, None)
   if self.tableRefreshCB:
    self.VViIob(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FFAvZA(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VVYje1(self, keyIndex, columns, VVQpxk, VV9Ea0, VV0HYK, VVZozG, VV0k8r):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VV0k8r and ndx == self.VVkbOA : textColor = VV0k8r
   else           : textColor = VVQpxk
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFUCM9(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VV9Ea0 = c
    entry = span.group(3)
   if self.VVe5VU[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVSYmq)
           , font   = 0
           , flags   = self.VVe5VU[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VV9Ea0
           , color_sel  = VV0HYK
           , backcolor_sel = VVZozG
           , border_width = 1
           , border_color = self.VVsrIN
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVbfxA(self):
  rowData = self.VVkOkW()
  if rowData:
   title, txt, colList = rowData
   if self.VV0QzM:
    fnc  = self.VV0QzM[1]
    params = self.VV0QzM[2]
    fnc(self, title, txt, colList)
   else:
    FFheEQ(self, txt, title)
 def VViOwa(self):
  if   self.VVUCzo : self.VVT6C2(self.VVf913(), mode=2)
  elif self.VVVt3G  : self.VViIob(self.VVVt3G, None)
  else      : self.VVbfxA()
 def VV4IBW(self) : self.VViIob(self.VVlNkE , self["keyRed"])
 def VVm3TC(self) : self.VViIob(self.VVcZtS , self["keyGreen"])
 def VVAuZb(self): self.VViIob(self.VVq3zo , self["keyYellow"])
 def VVmqKD(self) : self.VViIob(self.VVrIQY , self["keyBlue"])
 def VViIob(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFMYB5(self, buttonFnc[3])
    FFuqQK(BF(self.VV7iBz, buttonFnc))
   else:
    self.VV7iBz(buttonFnc)
 def VV7iBz(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVkOkW()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVT6C2(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][9] == self.VVD1eF
   newRow = self.VVRTTA()
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVYje1(ndx, newRow, self.VVQpxk, self.VV9Ea0, self.VV0HYK, self.VVZozG, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVYje1(ndx, newRow, self.VVD1eF, self.VV7XoG, self.VVMRk6, self.VVZ4ng, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   if self.VVf913() < len(self["myTable"].list) - 1:
    self.VVlSGS()
   else:
    self.VVolUD()
 def VV2zD3(self)  : FFqXEj(self, BF(self.VV8a6M, True ), title="Selecting all ..."  )
 def VVZCNW(self) : FFqXEj(self, BF(self.VV8a6M, False), title="Unselecting all ...")
 def VV8a6M(self, isSel=True):
  if isSel:
   fg, bg = self.VVD1eF, self.VV7XoG
   self.selectedItems = len(self["myTable"].list)
   self.VVDfQL(True)
  else:
   fg, bg = self.VVQpxk, self.VV9Ea0
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][9] == self.VVD1eF
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     param = list(self["myTable"].list[ndx][col])
     param[8]  = fg
     param[9]  = fg
     param[10] = bg
     self["myTable"].list[ndx][col] = tuple(param)
  self["myTable"].l.invalidate()
 def VVkOkW(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVLpvM[i] > 1 or self.VVLpvM[i] == self.VVDPe5 or self.VVLpvM[i] == self.VVvVbv:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VVa4kU(self):
  if self.VVPypB : self.VVPypB(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VVWhqJ(self):
  return self["myTitle"].getText().strip()
 def VVEoLZ(self):
  return self.header
 def VVWtBD(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVd4ks(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFilsZ(self["myBar"], color)
 def VV07Vz(self, txt):
  FFMYB5(self, txt)
 def VVguPD(self, txt, Time=1000):
  FFMYB5(self, txt, Time)
 def VVxWR8(self): self["keyGreen"].show()
 def VVVZSG(self): self["keyGreen"].hide()
 def VVTKmx(self):
  FFMYB5(self)
 def VVlWG2(self, fnc):
  self["myTable"].onSelectionChanged.append(fnc)
 def VV1Heh(self):
  return len(self["myTable"].list)
 def VVf913(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVm6b9(self):
  return len(self["myTable"].list)
 def VVDfQL(self, isOn):
  self.VVUCzo = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VVrIQY: self["keyBlue"].hide()
   if self.VVVt3G and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVrIQY: self["keyBlue"].show()
   if self.VVVt3G and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVVt3G[0])
   self.VVZCNW()
  FFAMY6(self["myTitle"], color)
  FFAMY6(self["myBar"]  , color)
 def VV9IV0(self):
  return self.VVUCzo
 def VVmvz4(self):
  return self.selectedItems
 def VV8kC5(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVolUD()
 def VVOkvD(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVc2EZ(self):
  txt  = "Total Rows\t: %d\n\n" % self.VV1Heh()
  txt += FFYH2Y("Total Unique Items", VVHKA4)
  for i in range(self.totalCols):
   if self.VVLpvM[i - 1] > 1 or self.VVLpvM[i - 1] == self.VVDPe5 or self.VVLpvM[i - 1] == self.VVvVbv:
    name, tot = self.VVOkvD(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFheEQ(self, txt)
 def VVboCB(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVRTTA(self):
  return self.VVx7ND(self["myTable"].l.getCurrentSelectionIndex())
 def VVx7ND(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVfoGr(self, newList, newTitle="", VVVlYiMsg=True, tableRefreshCB=None):
  if newTitle:
   self.VVWtBD(newTitle)
  if newList:
   self.VVd40u = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VV1YOp and self.VVkbOA == 0:
    isNum = True
   else:
    for cols in self.VVd40u:
     if not FFQBdn(cols[self.VVkbOA]): break
    else:
     isNum = True
   if isNum: self.VVd40u.sort(key=lambda x: int(x[self.VVkbOA])  , reverse=self.lastSortModeIsReverese)
   else : self.VVd40u.sort(key=lambda x: x[self.VVkbOA].lower() , reverse=self.lastSortModeIsReverese)
   if VVVlYiMsg : self.VVEXaO("Refreshing ...")
   else   : self.VVAHnE()
  else:
   FFAvZA(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VVSGdt(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VVYje1(self.VVm6b9(), row, self.VVQpxk, self.VV9Ea0, self.VV0HYK, self.VVZozG, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VVF53M()
 def VVu68F(self):
  self["myTable"].list.pop(self.VVf913())
  self["myTable"].l.setList(self["myTable"].list)
 def VV3N4D(self, data):
  ndx = self.VVf913()
  newRow = self.VVYje1(ndx, data, self.VVQpxk, self.VV9Ea0, self.VV0HYK, self.VVZozG, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVolUD()
   return True
  else:
   return False
 def VVCunO(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VVYje1(ndx, data, self.VVQpxk, self.VV9Ea0, self.VV0HYK, self.VVZozG, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVPAYz()
 def VVPAYz(self):
  self["myTable"].l.setList(self["myTable"].list)
 def VVu8Ft(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VVjNJH(self, colNum, textToFind, VViqYq=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVolUD()
    break
  else:
   if VViqYq:
    FFMYB5(self, "Not found", 1000)
 def VVzboj(self, colDict, VViqYq=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVolUD()
    return
  if VViqYq:
   FFMYB5(self, "Not found", 1000)
 def VVy7J4(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVODyh(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFQBdn(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVwG2k(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVD1eF:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVQwmL(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVD1eF:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VVU8qn(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VVD1eF: return True
  else        : return False
 def VVBOVP(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVN3e2(self):
  if not self["keyMenu"].getVisible() or self.VVtvxl:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVf913()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVwSHr1, VVOVHj = CC6QfU.VVJ2BL(self, False, False)
  VVwSHr = []
  VVwSHr.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVwSHr.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVwSHr.append(("Find ...\t\t%s" % (FFNkac(txt, VVHJRy) if txt else ""), "findNew"   ))
  VVwSHr.append(itemOf(bool(VVwSHr1)    , "Find (from Filter) ..."   , "filter"   ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Table Statistcis"             , "tableStat"  ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append((FFNkac("Export Table to .html"     , VVHKA4) , "VVNTFx" ))
  VVwSHr.append((FFNkac("Export Table to .csv"     , VVHKA4) , "VVGsN4" ))
  VVwSHr.append((FFNkac("Export Table to .txt (Tab Separated)", VVHKA4) , "VVakvI" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVLpvM[i] > 1 or self.VVLpvM[i] == self.VVs9oW:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVwSHr.append(VVbzyo)
   if tot == 1 : VVwSHr.append(("Sort", sList[0][1]))
   else  : VVwSHr += sList
  VVWYuC = ("Keys Help", self.FFyLgYHelp)
  FFKX6p(self, self.VVDNvQ, VVwSHr=VVwSHr, title=self.VVWhqJ(), VVWYuC=VVWYuC)
 def VVDNvQ(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVIaRn()
   elif item == "findPrev"  : self.VVIaRn(isPrev=True)
   elif item == "findNew"  : self.VVEmAV()
   elif item == "filter"  : self.VVRs5m()
   elif item == "tableStat" : self.VVc2EZ()
   elif item == "VVNTFx": FFqXEj(self, self.VVNTFx, title=title)
   elif item == "VVGsN4" : FFqXEj(self, self.VVGsN4 , title=title)
   elif item == "VVakvI" : FFqXEj(self, self.VVakvI , title=title)
   else:
    self.lastSortModeIsReverese = False
    if self.VVkbOA == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVkbOA = item
    if self.VV1YOp and self.VVkbOA == 0 or self.VVODyh(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVAHnE(onlyHeader=True)
 def FFyLgYHelp(self, menuInstance, path):
  FFK3qq(self, VVdSQY + "_help_table", "Table (Keys Help)")
 def VVo4gD(self):
  self["myTable"].up()
  self.VVolUD()
 def VVlSGS(self):
  self["myTable"].down()
  self.VVolUD()
 def VVimMN(self):
  self["myTable"].pageUp()
  self.VVolUD()
 def VVA4xu(self):
  self["myTable"].pageDown()
  self.VVolUD()
 def VVnzYl(self):
  self["myTable"].moveToIndex(0)
  self.VVolUD()
 def VVF53M(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVolUD()
 def VVm16r(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVolUD()
 def VVG6aZ(self):
  if self.lastFindConfigObj.getValue():
   if self.VVf913() == len(self["myTable"].list) - 1 : FFMYB5(self, "End reached", 1000)
   else              : self.VVIaRn()
  else:
   FFMYB5(self, 'Set "Find" in Menu', 1500)
 def VVqVhf(self):
  if self.lastFindConfigObj.getValue():
   if self.VVf913() == 0 : FFMYB5(self, "Top reached", 1000)
   else       : self.VVIaRn(isPrev=True)
  else:
   FFMYB5(self, 'Set "Find" in Menu', 1500)
 def VVekpw(self, txt):
  FFGxwH(self.lastFindConfigObj, txt)
 def VVEmAV(self):
  FFJC4A(self, self.VVBM8j, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VVBM8j(self, VVg7w7):
  if not VVg7w7 is None:
   txt = VVg7w7.strip()
   self.VVekpw(txt)
   if VVg7w7: self.VVIaRn(reset=True)
   else  : FFMYB5(self, "Nothing to find !", 1500)
 def VVRs5m(self):
  VVwSHr, VVOVHj = CC6QfU.VVJ2BL(self, False, False)
  VVoZDD = ("Edit Filter", BF(self.VV8vAw, VVOVHj))
  if VVwSHr : FFKX6p(self, self.VVfsK9, VVwSHr=VVwSHr, VVoZDD=VVoZDD, title="Find from Filter")
  else  : FFMYB5(self, "Filter Error !", 1500)
 def VVfsK9(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VVekpw(txt)
    self.VVIaRn(reset=True)
   else:
    FFMYB5(self, "No entry !", 1500)
 def VV8vAw(self, VVOVHj, VVZPLhObj, sel):
  if fileExists(VVOVHj) : CCRb0q(self, VVOVHj, VVUStE=None)
  else       : FFXl6w(self, VVOVHj)
  VVZPLhObj.cancel()
 def VVIaRn(self, reset=False, isPrev=False):
  curRow = self.VVf913()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CC6QfU.VVfYn9(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VVm16r(i)
      break
    elif any(x in line for x in tupl):
     self.VVm16r(i)
     break
   else:
    FFMYB5(self, "Not found", 1000)
  else:
   FFMYB5(self, "Check your query", 1500)
 def VVakvI(self):
  expFile = self.VV89kO() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VV0Suv()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVx7ND(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVLpvM[ndx] > self.VVLdf5 or self.VVLpvM[ndx] == self.VVvVbv:
      col = self.VVgGNg(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVtYMh(expFile)
 def VVGsN4(self):
  expFile = self.VV89kO() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VV0Suv()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVx7ND(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVLpvM[ndx] > self.VVLdf5 or self.VVLpvM[ndx] == self.VVvVbv:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VVgGNg(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVtYMh(expFile)
 def VVNTFx(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVWhqJ(), PLUGIN_NAME, VV191S)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVWhqJ()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VV0Suv()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVLpvM:
   colgroup += '   <colgroup>'
   for w in self.VVLpvM:
    if w > self.VVLdf5 or w == self.VVvVbv:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VV89kO() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVx7ND(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVLpvM[ndx] > self.VVLdf5 or self.VVLpvM[ndx] == self.VVvVbv:
      col = self.VVgGNg(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVtYMh(expFile)
 def VV0Suv(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVLpvM[ndx] > self.VVLdf5 or self.VVLpvM[ndx] == self.VVvVbv:
     newRow.append(col.strip())
  return newRow
 def VVgGNg(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFGlcE(col)
 def VV89kO(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVWhqJ())
  fileName = fileName.replace("__", "_")
  path  = FFThW1(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFLFgj()
  return expFile
 def VVtYMh(self, expFile):
  FF6b7h(self, "File exported to:\n\n%s" % expFile, title=self.VVWhqJ())
 def VVolUD(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCZBdY():
 def __init__(self, pixmapObj, picPath, VV9Ea0=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VV9Ea0  = VV9Ea0 or "#2200002a"
 def VV0XWT(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VV199l)
    except:
     self.picLoad.PictureData.get().append(self.VV199l)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VV9Ea0])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VV199l(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VV3ETZ(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVLSHJ(pixmapObj, path, VV9Ea0=None):
  cl = CCZBdY(pixmapObj, path, VV9Ea0)
  ok = cl.VV0XWT()
  if ok: return cl
  else : return None
class CC1AR1(Screen):
 def __init__(self, session, title="", VV9GFC=None, showGrnMsg=""):
  self.skin, self.skinParam = FFheJw(VV0RYQ, 1600, 1000, 30, 40, 20, "#22000060", "#2200002a", 30)
  if not title:
   title = os.path.basename(VV9GFC),
  self.session = session
  FFqVmU(self, title, addCloser=True)
  self["myPic"]  = Pixmap()
  self.VV9GFC = VV9GFC
  self.showGrnMsg  = showGrnMsg
  self.picViewer  = None
  self.onShown.append(self.VVevf4)
  self.onClose.append(self.onExit)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  self.picViewer = CCZBdY.VVLSHJ(self["myPic"], self.VV9GFC)
  if self.picViewer:
   if self.showGrnMsg:
    FFMYB5(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFAvZA(self, "Cannot view picture file:\n\n%s" % self.VV9GFC)
   self.close()
 def onExit(self):
  if self.picViewer:
   self.picViewer.VV3ETZ()
 @staticmethod
 def VVkxof(SELF, VV9GFC, title="", showGrnMsg=""):
  SELF.session.open(BF(CC1AR1, title=title, VV9GFC=VV9GFC, showGrnMsg=showGrnMsg))
class CCTLk6(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FFheJw(VVYzBB, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FFqVmU(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VVevf4)
  self.onClose.append(self.onExit)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  res = os.system(FFlWZ0("showiframe %s" % self.mviFile))
  if not res == 0:
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VVuBMJ(SELF, mviFile):
  SELF.session.openWithCallback(BF(CCTLk6.VVlm47, SELF), CCTLk6, mviFile)
 @staticmethod
 def VVlm47(SELF, reason=None):
  if reason == -1: FFAvZA(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CCKVDO(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFheJw(VVHcRy, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFqVmU(self, title=self.Title)
  FFTGpi(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("File Manage Exit-Button Action"        , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Signal & Player Cotroller Hotkey"       , CFG.hotkey_signal    ))
  if VVhP34:
   lst.append(getConfigListEntry("EPG Translation Language"        , CFG.epgLanguage    ))
  lst.append(getConfigListEntry(VVStMY *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type"         , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Movie/Series Download Path"         , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VVStMY *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VVStMY *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons"            , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVm0Od()
  self.onShown.append(self.VVevf4)
 def VVm0Od(self):
  kList = {
    "ok"  : self.VVmBrJ    ,
    "green"  : self.VVXfvZ  ,
    "menu"  : self.VVjgp2  ,
    "cancel" : self.VV2f42  ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVrCIe, 0)
     kList["chanDown"] = BF(self["config"].VVrCIe, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  FFuN11(self)
  FFpkQc(self["config"])
  FFQGfp(self, self["config"])
  FFBmK5(self)
 def VVmBrJ(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsMode   : self.VVxRNT()
   elif item == CFG.MovieDownloadPath   : self.VV0tKC(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VVQA1a(item)
   elif item == CFG.backupPath    : self.VVQA1a(item)
   elif item == CFG.packageOutputPath  : self.VVQA1a(item)
   elif item == CFG.downloadedPackagesPath : self.VVQA1a(item)
   elif item == CFG.exportedTablesPath  : self.VVQA1a(item)
   elif item == CFG.exportedPIconsPath  : self.VVQA1a(item)
 def VV0tKC(self, item, title):
  tot = CCEgwO.VVwzmj()
  if tot : FFAvZA(self, "Cannot change while downloading.", title=title)
  else : self.VVQA1a(item)
 def VVxRNT(self):
  VVwSHr = []
  VVwSHr.append(("Auto Find" , "auto"))
  VVwSHr.append(("Custom Path" , "cust"))
  FFKX6p(self, self.VVeP2F, VVwSHr=VVwSHr, title="IPTV Hosts Files Path")
 def VVeP2F(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVk7lM)
   elif item == "cust":
    VVmJ2p = self.VVbZYP()
    if VVmJ2p : self.VVJauB(VVmJ2p)
    else  : self.session.openWithCallback(self.VVYHgF, BF(CCeH84, mode=CCeH84.VVf4Wu, VVXtjq="/"))
 def VVJauB(self, VVmJ2p):
  VVPypB = self.VVgBko
  VVlNkE = ("Remove"  , self.VVueBJ , [])
  VVq3zo = ("Add "  , self.VVM447, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VVe5VU  = (LEFT   , LEFT  )
  FFyLgY(self, None, title="IPTV Hosts Search Paths", header=header, VVd40u=VVmJ2p, width=1200, height=700, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=26, VVPypB=VVPypB, VVlNkE=VVlNkE, VVq3zo=VVq3zo
    , VVCNiH="#11220000", VVIhEb="#11110000", VV9Ea0="#11110011", VV0HYK="#00ffff00", VVZozG="#00223025", VVsrIN="#0a333333", VVn0US="#0a400040")
 def VVgBko(self, VVl7Cx):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVqdlh)
  VVl7Cx.cancel()
 def VVYHgF(self, path):
  if path:
   FFGxwH(CFG.iptvHostsDirs, FFThW1(path.strip()))
   VVmJ2p = self.VVbZYP()
   if VVmJ2p : self.VVJauB(VVmJ2p)
   else  : FFMYB5(self, "Cannot add dir", 1500)
 def VVJ0CT(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVk7lM:
   return []
  return lst
 def VVbZYP(self):
  lst = self.VVJ0CT()
  if lst:
   VVmJ2p = []
   for Dir in lst:
    VVmJ2p.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVmJ2p.sort(key=lambda x: x[0].lower())
   return VVmJ2p
  else:
   return []
 def VVM447(self, VVl7Cx, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VVMfxY, VVl7Cx)
         , BF(CCeH84, mode=CCeH84.VVf4Wu, VVXtjq=sDir))
 def VVMfxY(self, VVl7Cx, path):
  if path:
   path = FFThW1(path.strip())
   if self.VV3DdO(VVl7Cx, path):
    FFMYB5(VVl7Cx, "Already added", 1500)
   else:
    lst = self.VVJ0CT()
    lst.append(path)
    FFGxwH(CFG.iptvHostsDirs, ",".join(lst))
    VVmJ2p = self.VVbZYP()
    VVl7Cx.VVfoGr(VVmJ2p, tableRefreshCB=BF(self.VVcKlJ, path))
 def VVcKlJ(self, path, VVl7Cx, title, txt, colList):
  self.VV3DdO(VVl7Cx, path)
 def VV3DdO(self, VVl7Cx, path):
  for ndx, row in enumerate(VVl7Cx.VVBOVP()):
   if row[0].strip() == path.strip():
    VVl7Cx.VVm16r(ndx)
    return True
  return False
 def VVueBJ(self, VVl7Cx, title, txt, colList):
  path = colList[0]
  FFOjga(self, BF(self.VVNOl1, VVl7Cx), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVNOl1(self, VVl7Cx):
  row = VVl7Cx.VVRTTA()
  path, rem = row[0], row[1]
  VVmJ2p = []
  lst = []
  for ndx, row in enumerate(VVl7Cx.VVBOVP()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVmJ2p.append((tPath, tRem))
  if len(VVmJ2p) > 0:
   FFGxwH(CFG.iptvHostsDirs, ",".join(lst))
   VVl7Cx.VVfoGr(VVmJ2p)
   FFMYB5(VVl7Cx, "Deleted", 1500)
  else:
   FFGxwH(CFG.iptvHostsMode, VVk7lM)
   FFGxwH(CFG.iptvHostsDirs, "")
   VVl7Cx.cancel()
   FFuqQK(BF(FFMYB5, self, "Changed to Auto-Find", 1500))
 def VVQA1a(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VVszSe, configObj)
         , BF(CCeH84, mode=CCeH84.VVf4Wu, VVXtjq=sDir))
 def VVszSe(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VV2f42(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFOjga(self, self.VVXfvZ, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVXfvZ(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVdNnE()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVjgp2(self):
  VVwSHr = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVwSHr.append((txt    , "VVm4gY"   ))
  else        : VVwSHr.append((txt    ,       ))
  VVwSHr.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Reset %s Settings" % PLUGIN_NAME      , "VVgbPC"   ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Backup %s Settings" % PLUGIN_NAME      , "VVqohM"  ))
  VVwSHr.append(("Restore %s Settings" % PLUGIN_NAME     , "VVF0a6"  ))
  if fileExists(VVhL6f + VVf5ke):
   VVwSHr.append(VVbzyo)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVwSHr.append(('%s Checking for Update' % txt1     , txt2     ))
   VVwSHr.append(("Reinstall %s" % PLUGIN_NAME      , "VVSYTo"  ))
   VVwSHr.append(("Update %s" % PLUGIN_NAME      , "VV4yvS"   ))
  FFKX6p(self, self.VV6qDY, VVwSHr=VVwSHr, title="Config. Options")
 def VV6qDY(self, item=None):
  if item:
   if   item == "VVm4gY"  : FFOjga(self, self.VVm4gY , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CC7nVY)
   elif item == "VVgbPC"  : FFOjga(self, self.VVgbPC, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VVqohM" : self.VVqohM()
   elif item == "VVF0a6" : FFqXEj(self, self.VVF0a6, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FFGxwH(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FFGxwH(CFG.checkForUpdateAtStartup, False)
   elif item == "VVSYTo" : FFqXEj(self, self.VVSYTo , "Checking Server ...")
   elif item == "VV4yvS"  : FFqXEj(self, self.VV4yvS  , "Checking Server ...")
 def VVqohM(self):
  path = "%sajpanel_settings_%s" % (VVhL6f, FFLFgj())
  os.system("grep .%s. %ssettings > %s" % (PLUGIN_NAME, VVslLY, path))
  FF6b7h(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVF0a6(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFIsyt("find / %s -iname '%s*' | grep %s" % (FFaJMY(1), name, name))
  if lines:
   lines.sort()
   VVwSHr = []
   for line in lines:
    VVwSHr.append((line, line))
   FFKX6p(self, BF(self.VVzhaM, title), title=title, VVwSHr=VVwSHr, width=1200)
  else:
   FFAvZA(self, "No settings files found !", title=title)
 def VVzhaM(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FF7up6(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVdNnE()
    FFtAvw()
   else:
    FFXl6w(SELF, path, title=title)
 def VVm4gY(self):
  newPath = FFThW1(VVhL6f)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVdNnE()
 @staticmethod
 def VV5ZNp():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVgbPC(self):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVdNnE()
  self.close()
 def VVdNnE(self):
  configfile.save()
  global VVhL6f
  VVhL6f = CFG.backupPath.getValue()
  FF9YTV()
 def VV4yvS(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVrpbt(title)
  if webVer:
   FFOjga(self, BF(FFqXEj, self, BF(self.VVIfKv, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVSYTo(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVrpbt(title, True)
  if webVer:
   FFOjga(self, BF(FFqXEj, self, BF(self.VVIfKv, webVer, title, True)), "Install and Restart ?", title=title)
 def VVIfKv(self, webVer, title, isReinst=False):
  url = self.VVjAP0(self, title)
  if url:
   VVM65w = FFGwKB() == "dpkg"
   if VVM65w == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVM65w else "ipk")
   path, err = FF8zMR(url + fName, fName, timeout=2)
   if path:
    if isReinst : cmd = FFtNvi(VVUj18, path)
    else  : cmd = FFtNvi(VV2M4Y, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFCHwU(self, cmd)
    else:
     FF0QO3(self, title=title)
   else:
    FFAvZA(self, err, title=title)
 def VVrpbt(self, title, anyVer=False):
  url = self.VVjAP0(self, title)
  if not url:
   return ""
  path, err = FF8zMR(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFAvZA(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFa594(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFAvZA(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VV191S.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFIsyt(cmd)
   if list and curVer == list[0]:
    return webVer
  FF6b7h(self, FFNkac("No update required.", VV80BT) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVjAP0(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVhL6f + VVf5ke
  if fileExists(path):
   span = iSearch(r"(http.+)", FFa594(path), IGNORECASE)
   if span : url = FFThW1(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFAvZA(SELF, err, title)
  return url
 @staticmethod
 def VVNuqZ(url):
  path, err = FF8zMR(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFa594(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VV191S.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFIsyt(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CC7nVY(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFheJw(VVarsQ, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = COLOR_SCHEME_NUM
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFqVmU(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VV5RJV("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VV5RJV("\c00888888", i) + sp + "GREY\n"
   txt += self.VV5RJV("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VV5RJV("\c00FF0000", i) + sp + "RED\n"
   txt += self.VV5RJV("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VV5RJV("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VV5RJV("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VV5RJV("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VV5RJV("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VV5RJV("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VV5RJV("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VV5RJV("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVmBrJ ,
   "green"   : self.VVmBrJ ,
   "left"   : self.VVXUAo ,
   "right"   : self.VVaQKG ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  self.VVGYFr()
 def VVmBrJ(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFOjga(self, self.VVaqVW, "Change to : %s" % txt, title=self.Title)
 def VVaqVW(self):
  FFGxwH(CFG.mixedColorScheme, self.cursorPos)
  global COLOR_SCHEME_NUM
  COLOR_SCHEME_NUM = self.cursorPos
  self.VVjxR1()
  self.close()
 def VVXUAo(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVGYFr()
 def VVaQKG(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVGYFr()
 def VVGYFr(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VV5RJV(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVnDoL(color):
  if VVSqFX: return "\\" + color
  else    : return ""
 @staticmethod
 def VVjxR1():
  global VVNUkq, VVcK7G, VV0rNQ, VVmIAH, VVHKA4, VVhTQL, VVlWiV, VV7q9v, VV80BT, VV4YPU, VVSqFX, VVXaO9, VVHJRy, VVtjbM, VVuRbD, VV1R4z
  VV1R4z   = CC7nVY.VV5RJV("\c00FFFFFF", COLOR_SCHEME_NUM)
  VVcK7G    = CC7nVY.VV5RJV("\c00888888", COLOR_SCHEME_NUM)
  VVNUkq  = CC7nVY.VV5RJV("\c005A5A5A", COLOR_SCHEME_NUM)
  VV7q9v    = CC7nVY.VV5RJV("\c00FF0000", COLOR_SCHEME_NUM)
  VV0rNQ   = CC7nVY.VV5RJV("\c00FF5000", COLOR_SCHEME_NUM)
  VVmIAH   = CC7nVY.VV5RJV("\c00FFBB66", COLOR_SCHEME_NUM)
  VVSqFX   = CC7nVY.VV5RJV("\c00FFFF00", COLOR_SCHEME_NUM)
  VVXaO9 = CC7nVY.VV5RJV("\c00FFFFAA", COLOR_SCHEME_NUM)
  VV80BT   = CC7nVY.VV5RJV("\c0000FF00", COLOR_SCHEME_NUM)
  VV4YPU  = CC7nVY.VV5RJV("\c00AAFFAA", COLOR_SCHEME_NUM)
  VVlWiV    = CC7nVY.VV5RJV("\c000066FF", COLOR_SCHEME_NUM)
  VVHJRy    = CC7nVY.VV5RJV("\c0000FFFF", COLOR_SCHEME_NUM)
  VVtjbM  = CC7nVY.VV5RJV("\c00AAFFFF", COLOR_SCHEME_NUM)  #
  VVuRbD   = CC7nVY.VV5RJV("\c00FA55E7", COLOR_SCHEME_NUM)
  VVHKA4    = CC7nVY.VV5RJV("\c00FF8F5F", COLOR_SCHEME_NUM)
  VVhTQL  = CC7nVY.VV5RJV("\c00FFC0C0", COLOR_SCHEME_NUM)
CC7nVY.VVjxR1()
class CCjcS8(Screen):
 def __init__(self, session, path, VVM65w):
  self.skin, self.skinParam = FFheJw(VVn6dg, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVS9Hn   = path
  self.VVLHMt   = ""
  self.VV6uFH   = ""
  self.VVM65w    = VVM65w
  self.VVREwO    = ""
  self.VVvS3G  = ""
  self.VVRN1o    = False
  self.VVcvqJ  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VVcxCM  = "enigma2-plugin-extensions-"
  self.VVYBOZ  = "enigma2-plugin-systemplugins-"
  self.VV3hM6 = "enigma2-"
  self.VVLqzL  = 0
  self.VVdwv4  = 1
  self.VV0Ywe  = 2
  if pathExists(self.Path + "DEBIAN") : self.VV5a1M = "DEBIAN"
  else        : self.VV5a1M = "CONTROL"
  self.controlPath = self.Path + self.VV5a1M
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVM65w:
   self.packageExt  = ".deb"
   self.VV9Ea0  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VV9Ea0  = "#11001020"
  FFqVmU(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFTGpi(self["keyRed"] , "Create")
  FFTGpi(self["keyGreen"] , "Post Install")
  FFTGpi(self["keyYellow"], "Installation Path")
  FFTGpi(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVRJ9g  ,
   "green"   : self.VVKlEV ,
   "yellow"  : self.VVHUUh  ,
   "blue"   : self.VVc3Ka  ,
   "cancel"  : self.VVduu9
  }, -1)
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  FFBmK5(self)
  if self.VV9Ea0:
   FFAMY6(self["myBody"], self.VV9Ea0)
   FFAMY6(self["myLabel"], self.VV9Ea0)
  self.VViztg(True)
  self.VVx5JV(True)
 def VVx5JV(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVDQw6()
  if isFirstTime:
   if   package.startswith(self.VVcxCM) : self.VVS9Hn = VVKPve + self.VVREwO + "/"
   elif package.startswith(self.VVYBOZ) : self.VVS9Hn = VVGc43 + self.VVREwO + "/"
   else            : self.VVS9Hn = self.Path
  if self.VVRN1o : myColor = VVHKA4
  else    : myColor = VV1R4z
  txt  = ""
  txt += "Source Path\t: %s\n" % FFNkac(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFNkac(self.VVS9Hn, VVSqFX)
  if self.VV6uFH : txt += "Package File\t: %s\n" % FFNkac(self.VV6uFH, VVcK7G)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFNkac("Check Control File fields : %s" % errTxt, VV0rNQ)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFNkac("Restart GUI", VVHKA4)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFNkac("Reboot Device", VVHKA4)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FFNkac("Post Install", VV80BT), act)
  if not errTxt and VV0rNQ in controlInfo:
   txt += "Warning\t: %s\n" % FFNkac("Errors in control file may affect the result package.", VV0rNQ)
  txt += "\nControl File\t: %s\n" % FFNkac(self.controlFile, VVcK7G)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVKlEV(self):
  if self["keyGreen"].getVisible():
   VVwSHr = []
   VVwSHr.append(("No Action"    , "noAction"  ))
   VVwSHr.append(("Restart GUI"    , "VViYG9"  ))
   VVwSHr.append(("Reboot Device"   , "rebootDev"  ))
   FFKX6p(self, self.VVtZqm, title="Package Installation Option (after completing installation)", VVwSHr=VVwSHr)
 def VVtZqm(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VViYG9"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VViztg(False)
   self.VVx5JV()
 def VVHUUh(self):
  rootPath = FFNkac("/%s/" % self.VVREwO, VVXaO9)
  VVwSHr = []
  VVwSHr.append(("Current Path"        , "toCurrent"  ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Extension Path"       , "toExtensions" ))
  VVwSHr.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVwSHr.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFKX6p(self, self.VVJfsX, title="Installation Path", VVwSHr=VVwSHr)
 def VVJfsX(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVDBeE(FFFUBh(self.Path, True))
   elif item == "toExtensions"  : self.VVDBeE(VVKPve)
   elif item == "toSystemPlugins" : self.VVDBeE(VVGc43)
   elif item == "toRootPath"  : self.VVDBeE("/")
   elif item == "toRoot"   : self.VVDBeE("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVLpYG, BF(CCeH84, mode=CCeH84.VVf4Wu, VVXtjq=VVhL6f))
 def VVLpYG(self, path):
  if len(path) > 0:
   self.VVDBeE(path)
 def VVDBeE(self, parent, withPackageName=True):
  if withPackageName : self.VVS9Hn = parent + self.VVREwO + "/"
  else    : self.VVS9Hn = "/"
  mode = self.VVbkpj()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VV5ZDa(mode), self.controlFile))
  self.VVx5JV()
 def VVc3Ka(self):
  if fileExists(self.controlFile):
   lines = FF7up6(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFJC4A(self, self.VV1Jer, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFAvZA(self, "Version not found or incorrectly set !")
  else:
   FFXl6w(self, self.controlFile)
 def VV1Jer(self, VVg7w7):
  if VVg7w7:
   version, color = self.VVlhHL(VVg7w7, False)
   if color == VVHJRy:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVg7w7, self.controlFile))
    self.VVx5JV()
   else:
    FFAvZA(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVduu9(self):
  if self.newControlPath:
   if self.VVRN1o:
    self.VV35Cc()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFNkac(self.newControlPath, VVcK7G)
    txt += FFNkac("Do you want to keep these files ?", VVSqFX)
    FFOjga(self, self.close, txt, callBack_No=self.VV35Cc, title="Create Package", VVA7RB=True)
  else:
   self.close()
 def VV35Cc(self):
  os.system(FFlWZ0("rm -r '%s'" % self.newControlPath))
  self.close()
 def VV5ZDa(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VVvS3G
  if package.startswith(self.VV3hM6):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VV3hM6, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VVdwv4 : prefix = self.VVcxCM
  elif mode == self.VV0Ywe : prefix = self.VVYBOZ
  return (prefix + name).lower()
 def VVbkpj(self):
  if   self.VVS9Hn.startswith(VVKPve) : return self.VVdwv4
  elif self.VVS9Hn.startswith(VVGc43) : return self.VV0Ywe
  else            : return self.VVLqzL
 def VViztg(self, isFirstTime):
  self.VVREwO   = FFck77(self.Path)
  self.VVREwO   = "_".join(self.VVREwO.split())
  self.VVvS3G = self.VVREwO.lower()
  self.VVRN1o = self.VVvS3G == VVmVo9.lower()
  if self.VVRN1o and self.VVvS3G.endswith("ajpan"):
   self.VVvS3G += "el"
  if self.VVRN1o : self.VVLHMt = VVhL6f
  else    : self.VVLHMt = CFG.packageOutputPath.getValue()
  self.VVLHMt = FFThW1(self.VVLHMt)
  if not pathExists(self.controlPath):
   os.system(FFlWZ0("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VVbkpj()
  if fileExists(self.controlFile):
   lines = FF7up6(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VVRN1o : version, descripton, maintainer = VV191S , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVREwO , self.VVREwO
   txt = ""
   txt += "Package: %s\n"  % self.VV5ZDa(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VVRN1o : t = PLUGIN_NAME
  else    : t = self.VVREwO
  self.VVM4Lu(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVM4Lu(self.postrmFile, "echo 'Package removed.'\n")
  if self.VVRN1o : self.VVM4Lu(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VV191S))
  else    : self.VVM4Lu(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVREwO)
  if isFirstTime and not mode == self.VVLqzL:
   self.postInstAcion = 1
  txt = self.VVJZkl(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFa594(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VVJZkl(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  os.system(FFlWZ0("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
 def VVM4Lu(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VVJZkl(self, action):
  sep  = "echo '%s'\n" % VVStMY
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VVDQw6(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FF7up6(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFNkac(line, VV0rNQ)
     elif not line.startswith(" ")    : line = FFNkac(line, VV0rNQ)
     else          : line = FFNkac(line, VVHJRy)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVHJRy
   else   : color = VV0rNQ
   descr = FFNkac(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VV0rNQ
     elif line.startswith((" ", "\t")) : color = VV0rNQ
     elif line.startswith("#")   : color = VVcK7G
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVlhHL(val, True)
      elif key == "Version"  : version, color = self.VVlhHL(val, False)
      elif key == "Maintainer" : maint  , color = val, VVHJRy
      elif key == "Architecture" : arch  , color = val, VVHJRy
      else:
       color = VVHJRy
      if not key == "OE" and not key.istitle():
       color = VV0rNQ
     else:
      color = VVHKA4
     txt += FFNkac(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VV6uFH = self.VVLHMt + packageName
   self.VVcvqJ = True
   errTxt = ""
  else:
   self.VV6uFH  = ""
   self.VVcvqJ = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVlhHL(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVHJRy
  else          : return val, VV0rNQ
 def VVRJ9g(self):
  if not self.VVcvqJ:
   FFAvZA(self, "Please fix Control File errors first.")
   return
  if self.VVM65w: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFFUBh(self.VVS9Hn, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVREwO
  symlinkTo  = FFTAAa(self.Path)
  dataDir   = self.VVS9Hn.rstrip("/")
  removePorjDir = FFlWZ0("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFlWZ0("rm -f '%s'" % self.VV6uFH) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFlS4l()
  if self.VVM65w:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFNMcU("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVRN1o:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVS9Hn == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VV5a1M)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VV6uFH, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VV6uFH
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VV6uFH, FFw6UZ(result  , VV80BT))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVS9Hn, FFw6UZ(instPath, VVHJRy))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFw6UZ(failed, VV0rNQ))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFCHwU(self, cmd)
class CCCBMo():
 VVNOWv  = "666"
 VV3gaV   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.menuInstance   = None
  self.VV3Vb3()
 def VV3Vb3(self):
  VVwSHr = CCCBMo.VV1eYH()
  if VVwSHr:
   VVoZDD = ("Create New", self.VVVVQj)
   self.menuInstance = FFKX6p(self.SELF, self.VVHdFg, VVwSHr=VVwSHr, title=self.Title, VVoZDD=VVoZDD, VVto4D=True, VVCNiH="#22222233", VVIhEb="#22222233")
  else:
   self.VVVVQj()
 def VVHdFg(self, item):
  if item:
   bName, bRef, ndx = item
   self.VV5Ywf(bName, bRef)
  else:
   CCCBMo.VVlRWN(self)
 def VVVVQj(self, VVZPLhObj=None, item=None):
  FFJC4A(self.SELF, BF(self.VVlflI), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVlflI(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.menuInstance:
     self.menuInstance.cancel()
    self.VV5Ywf(bName, "")
   else:
    FFMYB5(self.menuInstance, "Incorrect Bouquet Name !", 2000)
    CCCBMo.VVlRWN(self)
 def VV5Ywf(self, bName, bRef):
  FFqXEj(self.waitMsgSELF, BF(self.VVMxfB, bName, bRef), title="Adding Services ...")
 def VVMxfB(self, bName, bRef):
  CCCBMo.VVnLWk(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVlRWN(classObj):
  del classObj
 @staticmethod
 def VVnLWk(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FFAvZA(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVslLY + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFXl6w(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CCCBMo.VVEbUz(bRef)
   bPath = VVslLY + bFile
  else:
   fName = CCaayN.VV4PiN(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVslLY + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVslLY + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  CCCBMo.VVsHDO(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   CCCBMo.VVsHDO(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CCVrfy.VVNV04()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       os.system(FFlWZ0("cp -f '%s' '%s'" % (poster, picon)))
       os.system(CCnfxp.VVxhyv(picon))
       break
  FFjpsW()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FFheEQ(SELF, txt, title=title)
 @staticmethod
 def VV1eYH(mode=2, showTitle=True, prefix=""):
  VVwSHr = []
  if mode in (0, 2): VVwSHr.extend(CCCBMo.VVDznQ(0, showTitle, prefix))
  if mode in (1, 2): VVwSHr.extend(CCCBMo.VVDznQ(1, showTitle, prefix))
  return VVwSHr
 @staticmethod
 def VVDznQ(mode, showTitle, prefix):
  VVwSHr = []
  lst = CCCBMo.VVFHcF(mode)
  if lst:
   if showTitle:
    VVwSHr.append(FFDhQn("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVwSHr.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVwSHr.append((item[0], item[1].toString()))
  return VVwSHr
 @staticmethod
 def VVC1BJ():
  bLise = CCCBMo.VVFHcF(0)
  bLise.extend(CCCBMo.VVFHcF(1))
  return bLise
 @staticmethod
 def VVFHcF(mode=0):
  bList = []
  VVreUe = InfoBar.instance
  VVjitm = VVreUe and VVreUe.servicelist
  if VVjitm:
   curMode = VVjitm.mode
   CCCBMo.VVHoyT(VVjitm, mode)
   bList.extend(VVjitm.getBouquetList() or [])
   CCCBMo.VVHoyT(VVjitm, curMode)
  return bList
 @staticmethod
 def VVHoyT(VVjitm, mode):
  if not mode == VVjitm.mode:
   if   mode == 0: VVjitm.setModeTv()
   elif mode == 1: VVjitm.setModeRadio()
 @staticmethod
 def VVsHDO(fPath):
  with open(fPath, "rb+") as f:
   try:
    f.seek(-1, 2)
    if ord(f.read(1)) not in (10, 13):
     f.write(b"\n")
   except:
    pass
 @staticmethod
 def VVEbUz(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : ""
 @staticmethod
 def VV5Mvc():
  try:
   fName = CCCBMo.VVEbUz(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVslLY, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VVTC7K():
  path = CCCBMo.VV5Mvc()
  if path:
   txt = FFa594(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VV1MWD():
  return FFyIuW(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VVK4Z1():
  lst = []
  for b in CCCBMo.VVC1BJ():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVslLY + CCCBMo.VVEbUz(bRef)
   if fileExists(path):
    lines = FF7up6(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VV3RAZ(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VVdheu(SID="", stripRType=False):
  if SID : patt = CCCBMo.VV3RAZ(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CCCBMo.VVC1BJ():
   for service in FFyIuW(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVxivD():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CCCBMo.VVC1BJ():
   for service in FFyIuW(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVqdPj(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VVtG1f(pathLst):
  refLst = CCCBMo.VVdheu(CCCBMo.VVNOWv, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CCCBMo.VVqdPj(rType, CCCBMo.VVNOWv, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CCeH84(Screen):
 VVcWEv   = 0
 VVvR6q  = 1
 VVf4Wu  = 2
 VVCcW3  = 3
 VVATAq    = 20
 VVpEEa  = None
 def __init__(self, session, VVXtjq="/", mode=VVcWEv, VVclLa="Select", height=920, VV2ql8=30, gotoMovie=False, jumpToFile=""):
  self.skin, self.skinParam = FFheJw(VVXQaf, 1400, height, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFqVmU(self)
  FFTGpi(self["keyRed"] , "Exit" if mode == self.VVcWEv else "Cancel")
  FFTGpi(self["keyYellow"], "More Options")
  FFTGpi(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVclLa = VVclLa
  self.jumpToFile   = jumpToFile
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = "#06003333"
  CCeH84.VVpEEa = self
  if   self.jumpToFile       : VVOpkz, self.VVXtjq = True , FFFUBh(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VVOpkz, self.VVXtjq = True , CCeH84.VVYryR(self)[1] or "/"
  elif self.mode == self.VVcWEv  : VVOpkz, self.VVXtjq = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVf4Wu : VVOpkz, self.VVXtjq = False, VVXtjq
  elif self.mode == self.VVCcW3 : VVOpkz, self.VVXtjq = True , VVXtjq
  else           : VVOpkz, self.VVXtjq = True , VVXtjq
  self.VVXtjq = FFThW1(self.VVXtjq)
  VVEUah = None
  if self.mode == self.VVCcW3:
   VVEUah = "^.*\.srt"
  self["myMenu"] = CCOLsm(  directory   = None
         , VVEUah = VVEUah
         , VVOpkz   = VVOpkz
         , VVg2xy = True
         , VVz7PC = True
         , VVGjni   = self.skinParam["width"]
         , VV2ql8   = self.skinParam["bodyFontSize"]
         , VVSYmq  = self.skinParam["bodyLineH"]
         , VVVWYu  = self.skinParam["bodyColor"]
         , pngBGColorSelStr = self.cursorBG)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVmBrJ    ,
   "red"  : self.VV4mwC   ,
   "green"  : self.VVNwyQ,
   "yellow" : self.VVh9Rs  ,
   "blue"  : self.VV9UC2 ,
   "menu"  : self.VVpUWN  ,
   "info"  : self.VVEKrJ  ,
   "cancel" : self.VVnJPi    ,
   "pageUp" : self.VVMliL   ,
   "chanUp" : self.VVMliL
  }, -1)
  FFnqTm(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVMT8K)
 def onExit(self):
  CCeH84.VVpEEa = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVMT8K)
  FFuN11(self)
  FFpkQc(self["myMenu"], bg=self.cursorBG)
  FFBmK5(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVf4Wu, self.VVCcW3):
   FFTGpi(self["keyGreen"], self.VVclLa)
   color = "#22000022"
   FFAMY6(self["myBody"], color)
   FFAMY6(self["myMenu"], color)
   color = "#22220000"
   FFAMY6(self["myTitle"], color)
   FFAMY6(self["myBar"], color)
  self.VVMT8K()
  if self.VV0alI(self.VVXtjq) > self.bigDirSize: FFqXEj(self, self.VVvpyr, title="Changing directory...")
  else              : self.VVvpyr()
 def VVvpyr(self):
  if self.jumpToFile : self.VVCvYX(self.jumpToFile)
  elif self.gotoMovie : self.VV6V6r(chDir=False)
  else    : self["myMenu"].VVCdPn(self.VVXtjq)
 def VVm16r(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVAKTc(self):
  self["myMenu"].refresh()
  FFI36Q()
 def VV0alI(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VVmBrJ(self):
  if self["myMenu"].VVZkoH() : self.VVK4LS()
  else       : self.VVKJwp()
 def VVMliL(self):
  self["myMenu"].moveToIndex(0)
  if self["myMenu"].VVhNd6():
   self.VVK4LS()
 def VVK4LS(self, isDirUp=False):
  if self["myMenu"].VVZkoH():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVOO24(self.VVZPLh())
   if self.VV0alI(path) > self.bigDirSize : FFqXEj(self, self.VVPRXZ, title="Changing directory...")
   else           : self.VVPRXZ()
 def VVPRXZ(self):
  self["myMenu"].descent()
  self.VVMT8K()
 def VVnJPi(self):
  if CFG.FileManagerExit.getValue() == "e": self.VV4mwC()
  else         : self.VVMliL()
 def VV4mwC(self):
  if not FFRJ8Y(self):
   self.close("")
 def VVNwyQ(self):
  path = self.VVOO24(self.VVZPLh())
  if self.mode == self.VVf4Wu:
   self.close(path)
  elif self.mode == self.VVCcW3:
   if os.path.isfile(path) : self.close(path)
   else     : FFMYB5(self, "Only .srt files", 1000)
 def VVEKrJ(self):
  if not self.mode == self.VVCcW3:
   FFqXEj(self, self.VVcLwT, title="Calculating size ...")
 def VVcLwT(self):
  path = self.VVOO24(self.VVZPLh())
  param = self.VVXdwz(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFnz9X("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCeH84.VVIY6h(path)
     freeSize = CCeH84.VVkvYz(path)
     size = totSize - freeSize
     totSize  = CCeH84.VVpYrc(totSize)
     freeSize = CCeH84.VVpYrc(freeSize)
    else:
     size = FFnz9X("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CCeH84.VVpYrc(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFNkac(pathTxt, VVHKA4) + "\n"
   if slBroken : fileTime = self.VV0NUT(path)
   else  : fileTime = self.VVlRtV(path)
   def VV6J2i(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VV6J2i("Path"    , pathTxt)
   txt += VV6J2i("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VV6J2i("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VV6J2i("Total Size"   , "%s" % totSize)
    txt += VV6J2i("Used Size"   , "%s" % usedSize)
    txt += VV6J2i("Free Size"   , "%s" % freeSize)
   else:
    txt += VV6J2i("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VV6J2i("Owner"    , owner)
   txt += VV6J2i("Group"    , group)
   txt += VV6J2i("Perm. (User)"  , permUser)
   txt += VV6J2i("Perm. (Group)"  , permGroup)
   txt += VV6J2i("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VV6J2i("Perm. (Ext.)" , permExtra)
   txt += VV6J2i("iNode"    , iNode)
   txt += VV6J2i("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVStMY, VVStMY)
    txt += hLinkedFiles
   txt += self.VVpqMA(path)
  else:
   FFAvZA(self, "Cannot access information !")
  if len(txt) > 0:
   FFheEQ(self, txt)
 def VVXdwz(self, path):
  path = path.strip()
  path = FFTAAa(path)
  result = FFnz9X("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVurTs(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVurTs(perm, 1, 4)
   permGroup = VVurTs(perm, 4, 7)
   permOther = VVurTs(perm, 7, 10)
   permExtra = VVurTs(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFnUjX("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVpqMA(self, path):
  txt  = ""
  res  = FFnz9X("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFNkac("File Attributes:", VVuRbD), txt)
  return txt
 def VVlRtV(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFLaSW(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFLaSW(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFLaSW(os.path.getctime(path))
  return txt
 def VV0NUT(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFnz9X("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFnz9X("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFnz9X("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVOO24(self, currentSel):
  currentDir  = self["myMenu"].VVQNWz()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVZkoH():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVZPLh(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VVMT8K(self):
  path = self.VVOO24(self.VVZPLh())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVRbts()
  if self.mode == self.VVcWEv and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
  if self.mode == self.VVCcW3 and len(path) > 0 : self["keyInfo"].hide()
  else               : self["keyInfo"].show()
  if self.mode == self.VVCcW3:
   path = self.VVOO24(self.VVZPLh())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVRbts(self):
  if self.VVO6RF() : self["keyBlue"].show()
  else      : self["keyBlue"].hide()
 def VVpUWN(self):
  if self.mode == self.VVcWEv:
   color1  = VVhTQL
   color2  = VVXaO9
   path  = self.VVOO24(self.VVZPLh())
   VVwSHr = []
   VVwSHr.append(("Properties", "properties"))
   if os.path.isdir(path):
    if not self.VVG4B2(path):
     VVwSHr.append(VVbzyo)
     VVwSHr.append((color1 + "Archiving / Packaging", "VVTeSJ_dir"))
   elif os.path.isfile(path):
    selFile = self.VVZPLh()
    isArch = selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar"))
    if not isArch:
     VVwSHr.append((color1 + "Archive ...", "VVTeSJ_file"))
    isText = False
    txt = ""
    if   isArch            : VVwSHr.extend(self.VV3R1d(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith(".m3u")       : VVwSHr.extend(self.VVgmQ8(True))
    elif selFile.endswith(".sh"):
     VVwSHr.extend(self.VV0FJi(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CCeH84.VVtdsg(path):
     VVwSHr.append(VVbzyo)
     VVwSHr.append((color2 + "View"     , "textView_def"))
     VVwSHr.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVwSHr.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVZ6Yt(path) == "pic":
     if selFile.lower().endswith((".jpg", ".png")) and FF0CKG("ffmpeg"):
      VVwSHr.append(VVbzyo)
      VVwSHr.append((color2 + "Convert to MVI (1280 x 720 )", "VV7IbzHd"))
      VVwSHr.append((color2 + "Convert to MVI (1920 x 1080)", "VV7IbzFhd"))
    elif selFile.endswith(CCeH84.VV74My()):
     if selFile.endswith(".mvi"):
      if FF0CKG("showiframe"):
       VVwSHr.append(VVbzyo)
       VVwSHr.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVwSHr.append(VVbzyo)
      VVwSHr.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVwSHr.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
    if isText:
     VVwSHr.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVwSHr.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVwSHr.append((color1 + "Convert Line-Breaks to Unix Format..." , "VV7zlA" ))
    if len(txt) > 0:
     VVwSHr.append(VVbzyo)
     VVwSHr.append((color1 + txt, "VVKJwp"))
   VVwSHr.append(VVbzyo)
   VVwSHr.append(("Create SymLink", "VVuprR"))
   if not self.VVG4B2(path):
    VVwSHr.append(("Rename"      , "VVU7jp" ))
    VVwSHr.append(("Copy"       , "copyFileOrDir" ))
    VVwSHr.append(("Move"       , "moveFileOrDir" ))
    VVwSHr.append((VV0rNQ + "DELETE" , "VVhHHM" ))
    if fileExists(path):
     VVwSHr.append(VVbzyo)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVwSHr.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVwSHr.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVwSHr.append((chmodTxt + "777)", "chmod777"))
   c = VVtjbM
   VVwSHr.append(VVbzyo)
   VVwSHr.append((c + "Create New File (in current directory)"  , "createNewFile" ))
   VVwSHr.append((c + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCeH84.VVYryR(self)
   if fPath:
    VVwSHr.append(VVbzyo)
    VVwSHr.append((color2 + "Go to Current Movie Dir", "VV6V6r"))
   FFKX6p(self, self.VVhDAs, height=1050, title="Options", VVwSHr=VVwSHr, VVCNiH="#00101020", VVIhEb="#00101A2A")
 def VVhDAs(self, item=None):
  if self.mode == self.VVcWEv:
   if item is not None:
    path = self.VVOO24(self.VVZPLh())
    selFile = self.VVZPLh()
    if   item == "properties"    : self.VVEKrJ()
    elif item == "VVTeSJ_dir" : self.VVTeSJ(path, True)
    elif item == "VVTeSJ_file" : self.VVTeSJ(path, False)
    elif item == "VVHjal"  : self.VVHjal(path)
    elif item == "VVigal"  : self.VVigal(path)
    elif item.startswith("extract_")  : self.VVQbSu(path, selFile, item)
    elif item.startswith("script_")   : self.VVH36d(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVuwXx(path, selFile, item)
    elif item.startswith("textView_def") : FFsBYR(self, path)
    elif item.startswith("textView_enc") : self.VVHq8i(path)
    elif item.startswith("text_Edit")  : FFqXEj(self, BF(CCRb0q, self, path), title="Opening File ...")
    elif item.startswith("textSave_encUtf8"): self.VVHyMh(path, "Save as UTF-8"   , True)
    elif item.startswith("textSave_encOthr"): self.VVHyMh(path, "Save as Other Encoding", False)
    elif item.startswith("VV7zlA") : self.VV7zlA(path)
    elif item == "viewAsBootlogo"   : self.VVAhd8(path, True)
    elif item == "addMovieToBouquet"  : self.VVw8Vw(path, False)
    elif item == "addAllMoviesToBouquet" : self.VVw8Vw(path, True)
    elif item == "VV7IbzHd"   : FFqXEj(self, BF(self.VV7Ibz, path, False))
    elif item == "VV7IbzFhd"   : FFqXEj(self, BF(self.VV7Ibz, path, True))
    elif item == "VVuprR"   : self.VVuprR(path, selFile)
    elif item == "VVU7jp"   : self.VVU7jp(path, selFile)
    elif item == "copyFileOrDir"   : self.VVw8me(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVw8me(path, selFile, True)
    elif item == "VVhHHM"   : self.VVhHHM(path, selFile)
    elif item == "chmod644"     : self.VVVKu3(path, selFile, "644")
    elif item == "chmod755"     : self.VVVKu3(path, selFile, "755")
    elif item == "chmod777"     : self.VVVKu3(path, selFile, "777")
    elif item == "createNewFile"   : self.VVJZ3b(path, True)
    elif item == "createNewDir"    : self.VVJZ3b(path, False)
    elif item == "VV6V6r"   : self.VV6V6r()
    elif item == "VVKJwp"    : self.VVKJwp()
 def VVKJwp(self):
  if self.mode == self.VVCcW3:
   return
  selFile = self.VVZPLh()
  path  = self.VVOO24(selFile)
  if os.path.isfile(path):
   VVwcGi  = []
   category = self["myMenu"].VVZ6Yt(path)
   if   category == "pic"      : CC1AR1.VVkxof(self, path)
   elif category == "txt"      : FFsBYR(self, path)
   elif category in ("tar", "zip", "rar")  : self.VVFzMz(path, selFile)
   elif category == "scr"      : self.VVVHaX(path, selFile)
   elif category == "m3u"      : self.VVqSQE(path, selFile)
   elif category in ("ipk", "deb")    : self.VV1jTz(path, selFile)
   elif category in ("mov", "mus")    : self.VVAhd8(path)
   elif not CCeH84.VVtdsg(path) : FFsBYR(self, path)
 def VVAhd8(self, path, asLogo=False):
  if asLogo : CCTLk6.VVuBMJ(self, path)
  else  : FFqXEj(self, BF(self.VVpZNA,self, path), title="Playing Media ...")
 def VV9UC2(self):
  if self["keyBlue"].getVisible():
   VVd40u = self.VVO6RF()
   if VVd40u:
    path = self.VVOO24(self.VVZPLh())
    enableGreenBtn = False if path in self.VVO6RF() else True
    newList = []
    for line in VVd40u:
     newList.append((line, line))
    VVMcss  = ("Delete"    , self.VVnZTB    )
    VV7qf7  = ("Add Current Dir"   , BF(self.VVpkbV, path) ) if enableGreenBtn else None
    VVoZDD = ("Move Up"     , self.VVhE0d    )
    VVWYuC  = ("Move Down"   , self.VVxnK6    )
    self.bookmarkMenu = FFKX6p(self, self.VVyUhi, width=1200, title="Bookmarks", VVwSHr=newList, minRows=10 ,VVMcss=VVMcss, VV7qf7=VV7qf7, VVoZDD=VVoZDD, VVWYuC=VVWYuC, VVCNiH="#00000022", VVIhEb="#00000022")
 def VVnZTB(self, menuInstance=None, path=None):
  VVd40u = self.VVO6RF()
  if VVd40u:
   while path in VVd40u:
    VVd40u.remove(path)
   self.VVUfvj(VVd40u)
  if self.bookmarkMenu:
   self.bookmarkMenu.VVTD7t(VVd40u)
   self.bookmarkMenu.VVX49t(("Add Current Dir", BF(self.VVpkbV, path)))
  else:
   FFMYB5(self, "Removed", 800)
  self.VVRbts()
 def VVpkbV(self, path, menuInstance=None, item=None):
  VVd40u = self.VVO6RF()
  if len(VVd40u) >= self.VVATAq:
   FFAvZA(SELF, "Max bookmarks reached (max=%d)." % self.VVATAq)
  elif not path in VVd40u:
   newList = [path] + VVd40u
   self.VVUfvj(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VVTD7t(newList)
    self.bookmarkMenu.VVX49t()
   else:
    FFMYB5(self, "Added", 800)
  self.VVRbts()
 def VVhE0d(self, VVZPLhObj, path):
  if self.bookmarkMenu:
   VVd40u = self.bookmarkMenu.VVqSiW(True)
   if VVd40u:
    self.VVUfvj(VVd40u)
 def VVxnK6(self, VVZPLhObj, path):
  if self.bookmarkMenu:
   VVd40u = self.bookmarkMenu.VVqSiW(False)
   if VVd40u:
    self.VVUfvj(VVd40u)
 def VVyUhi(self, folder=None):
  if folder:
   folder = FFThW1(folder)
   self["myMenu"].VVCdPn(folder)
   self["myMenu"].moveToIndex(0)
  self.VVMT8K()
 def VVO6RF(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VV9QRy(self):
  return True if VVO6RF() else False
 def VVUfvj(self, VVd40u):
  line = ",".join(VVd40u)
  FFGxwH(CFG.browserBookmarks, line)
 def VVCvYX(self, path):
  if fileExists(path):
   fDir  = FFThW1(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVCdPn(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFMYB5(self, "Not found", 1000)
 def VV6V6r(self, chDir=True):
  fPath, fDir, fName = CCeH84.VVYryR(self)
  self.VVCvYX(fPath)
 def VVh9Rs(self):
  path = self.VVOO24(self.VVZPLh())
  isAdd = False if path in self.VVO6RF() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  VVwSHr = []
  VVwSHr.append(   ("Find Files ..."      , "find" ))
  VVwSHr.append(   ("Sort ..."        , "sort" ))
  VVwSHr.append(VVbzyo)
  if isAdd: VVwSHr.append( ("Add %s Dir to Bookmarks" % dirTxt  , "addBM" ))
  else : VVwSHr.append( ("Remove %s Dir from Bookmarks" % dirTxt, "remBM" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(   ('Set %s Dir as "Startup Dir"' % dirTxt , "start" ))
  FFKX6p(self, BF(self.VV1NXw, path), width=750, title="More Options", VVwSHr=VVwSHr, VVCNiH="#00221111", VVIhEb="#00221111")
 def VV1NXw(self, path, item):
  if item:
   if   item == "find" : self.VVrkCA(path)
   elif item == "sort" : self.VVaVnA()
   elif item == "addBM": self.VVpkbV(path)
   elif item == "remBM": self.VVnZTB(None, path)
   elif item == "start": self.VVWFv9(path)
 def VVrkCA(self, path):
  VVwSHr = []
  VVwSHr.append(("Find in Current Directory"    , "findCur"  ))
  VVwSHr.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVwSHr.append(("Find in all Storage Systems"    , "findAll"  ))
  FFKX6p(self, BF(self.VVnXlC, path), width=700, title="Find File/Pattern", VVwSHr=VVwSHr, VVto4D=True, VVL5Ba=True, VVCNiH="#00221111", VVIhEb="#00221111")
 def VVnXlC(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VVwL0m(0, path, title)
   elif item == "findCurR" : self.VVwL0m(1, path, title)
   elif item == "findAll" : self.VVwL0m(2, path, title)
 def VVwL0m(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FFJC4A(self, BF(self.VVMhnq, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVMhnq(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FFGxwH(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FFMYB5(self, "No entery", 1500)
   elif badLst  : FFMYB5(self, "Too many file !", 1500)
   else   : FFqXEj(self, BF(self.VVJKFN, mode, path, title, filePatt), title="Searching ...", clearMsg=False)
 def VVJKFN(self, mode, path, title, filePatt):
  FFMYB5(self)
  lst = FFIsyt(FFpeT0("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   if len(lst) == 1 and lst[0] == VVQZPP:
    FFAvZA(self, VVQZPP)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VV0QzM = (""     , self.VV52lu , [])
    VVcZtS = ("Go to File Location", self.VV4Jy4  , [])
    FFyLgY(self, None, title="%s : %s" % (title, filePatt), header=header, VVd40u=lst, VVLpvM=widths, VV2ql8=26, VV0QzM=VV0QzM, VVcZtS=VVcZtS)
  else:
   FFMYB5(self, "Not found !", 2000)
 def VV4Jy4(self, VVl7Cx, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVl7Cx.cancel()
   self.VVCvYX(path)
  else:
   FFMYB5(VVl7Cx, "Path not found !", 1000)
 def VV52lu(self, VVl7Cx, title, txt, colList):
  txt = "%s\n%s\n\n" % (FFNkac("File:"  , VVXaO9), colList[0])
  txt += "%s\n%s"  % (FFNkac("Directory:", VVXaO9), FFThW1(colList[1]))
  FFheEQ(VVl7Cx, txt, title=title)
 def VVaVnA(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVAsjh()
  VVwSHr = []
  VVwSHr.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVwSHr.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVwSHr.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVwSHr.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVWYuC = ("Mix", BF(self.VV1Z6Q, True))
  FFKX6p(self, BF(self.VVrFC0, False), barText=txt, width=650, title="Sort Options", VVwSHr=VVwSHr, VVWYuC=VVWYuC, VVL5Ba=True, VVCNiH="#00221111", VVIhEb="#00221111")
 def VV1Z6Q(self, isMix, menuInstance, item):
  self.VVrFC0(True, item)
 def VVrFC0(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVAsjh()
   title = "Sorting ... "
   if   item == "nameAlp": FFqXEj(self, BF(self["myMenu"].VVjQRG, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FFqXEj(self, BF(self["myMenu"].VVjQRG, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FFqXEj(self, BF(self["myMenu"].VVjQRG, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FFqXEj(self, BF(self["myMenu"].VVjQRG, typeMode , isMix, False), title=title)
 def VVWFv9(self, path):
  if not os.path.isdir(path):
   path = FFFUBh(path, True)
  FFGxwH(CFG.browserStartPath, path)
  FFMYB5(self, "Done", 500)
 def VVp3Sh(self, selFile, VVByb6, command):
  FFOjga(self, BF(FFCHwU, self, command, VVFApn=self.VVAKTc), "%s\n\n%s" % (VVByb6, selFile))
 def VV3R1d(self, path, calledFromMenu):
  destPath = self.VVkSu9(path)
  lastPart = FFck77(destPath)
  VVwSHr = []
  if calledFromMenu:
   VVwSHr.append(VVbzyo)
   color = VVXaO9
  else:
   color = ""
  VVwSHr.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVwSHr.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVwSHr.append((color + "Extract Here"            , "extract_here"  ))
  if iTar and iZip:
   if path.endswith(".zip"):
    if not calledFromMenu: VVwSHr.append(VVbzyo)
    VVwSHr.append((color + "Convert .zip to .tar.gz"       , "VVHjal" ))
   elif path.endswith(".tar.gz"):
    if not calledFromMenu: VVwSHr.append(VVbzyo)
    VVwSHr.append((color + "Convert .tar.gz to .zip"       , "VVigal" ))
  return VVwSHr
 def VVFzMz(self, path, selFile):
  FFKX6p(self, BF(self.VVQbSu, path, selFile), title="Compressed File Options", VVwSHr=self.VV3R1d(path, False))
 def VVQbSu(self, path, selFile, item=None):
  if item is not None:
   parent  = FFFUBh(path, False)
   destPath = self.VVkSu9(path)
   lastPart = FFck77(destPath)
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVStMY
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFNMcU("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFNMcU("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVStMY, VVStMY)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FF7AMX(self, cmd)
   elif path.endswith(".zip"):
    if item == "VVHjal" : self.VVHjal(path)
    else       : self.VV9tsH(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "VVigal" and path.endswith(".tar.gz"):
    self.VVigal(path)
   elif path.endswith(".rar"):
    self.VVbBYl(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFlWZ0("mkdir '%s'"   % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVp3Sh(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVp3Sh(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FFFUBh(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVp3Sh(selFile, "Extract Here ?"      , cmd)
 def VVkSu9(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VV9tsH(self, item, path, parent, destPath, VVByb6):
  FFOjga(self, BF(self.VVfh0i, item, path, parent, destPath), VVByb6)
 def VVfh0i(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVStMY
  cmd  = FFNMcU("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFw6UZ(destPath, VV80BT))
  cmd +=   sep
  cmd += "fi;"
  FFSiFd(self, cmd, VVFApn=self.VVAKTc)
 def VVbBYl(self, item, path, parent, destPath, VVByb6):
  FFOjga(self, BF(self.VV6jFK, item, path, parent, destPath), VVByb6)
 def VV6jFK(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFThW1(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVStMY
  cmd  = FFNMcU("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFw6UZ(destPath, VV80BT))
  cmd +=   sep
  cmd += "fi;"
  FFSiFd(self, cmd, VVFApn=self.VVAKTc)
 def VV0FJi(self, addSep=False):
  VVwSHr = []
  if addSep:
   VVwSHr.append(VVbzyo)
  VVwSHr.append((VVXaO9 + "View Script File"  , "script_View"  ))
  VVwSHr.append((VVXaO9 + "Execute Script File" , "script_Execute" ))
  VVwSHr.append((VVXaO9 + "Edit"     , "script_Edit" ))
  return VVwSHr
 def VVVHaX(self, path, selFile):
  FFKX6p(self, BF(self.VVH36d, path, selFile), title="Script File Options", VVwSHr=self.VV0FJi())
 def VVH36d(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFsBYR(self, path)
   elif item == "script_Execute" : self.VVp3Sh(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCRb0q(self, path)
 def VVgmQ8(self, addSep=False):
  VVwSHr = []
  if addSep:
   VVwSHr.append(VVbzyo)
  VVwSHr.append((VVXaO9 + "Browse IPTV Channels"  , "m3u_Browse" ))
  VVwSHr.append((VVXaO9 + "Edit"      , "m3u_Edit" ))
  VVwSHr.append((VVXaO9 + "View"      , "m3u_View" ))
  return VVwSHr
 def VVqSQE(self, path, selFile):
  FFKX6p(self, BF(self.VVuwXx, path, selFile), title="M3U/M3U8 File Options", VVwSHr=self.VVgmQ8())
 def VVuwXx(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFqXEj(self, BF(self.session.open, CCaayN, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCRb0q(self, path)
   elif item == "m3u_View"  : FFsBYR(self, path)
 def VVHq8i(self, path):
  if fileExists(path) : FFqXEj(self, BF(CCor0x.VVNdUZ, self, path, BF(self.VVnKN1, path)), title="Loading Codecs ...", clearMsg=False)
  else    : FFXl6w(self, path)
 def VVnKN1(self, path, item=None):
  if item:
   FFsBYR(self, path, encLst=item)
 def VVHyMh(self, path, title, asUtf8):
  if fileExists(path) : FFqXEj(self, BF(CCor0x.VVNdUZ, self, path, BF(self.VVYfsW, path, title, asUtf8), title="Original Encoding"), clearMsg=False, title="Loading Codecs ...")
  else    : FFXl6w(self, path)
 def VVYfsW(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8 : self.VVBMod(path, title, fromEnc, "UTF-8")
   else  : CCor0x.VVNdUZ(self, path,  BF(self.VVBMod, path, title, fromEnc), onlyWorkingEnc=False, title="Convert to Encoding")
 def VVBMod(self, path, title, fromEnc, toEnc):
  if toEnc:
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FFNkac("Successful\n\n", VV80BT)
      txt += FFNkac("From Encoding (%s):\n" % fromEnc, VVSqFX)
      txt += "%s\n\n" % path
      txt += FFNkac("To Encoding (%s):\n" % toEnc, VVSqFX)
      txt += "%s\n\n" % outFile
      FFheEQ(self, txt, title=title)
    except:
     FFAvZA(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FFMYB5(self, "Cannot open file", 2000)
  self.VVAKTc()
 def VV7zlA(self, path):
  title = "File Line-Break Conversion"
  FFOjga(self, BF(self.VVT3Ur, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVT3Ur(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FFNkac("File converted:", VV80BT), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FF6b7h(self, txt, title=title)
  else:
   FFXl6w(self, path, title=title)
 def VVVKu3(self, path, selFile, newChmod):
  FFOjga(self, BF(self.VV7xLD, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VV7xLD(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVp7GH)
  result = FFnz9X(cmd)
  if result == "Successful" : FF6b7h(self, result)
  else      : FFAvZA(self, result)
 def VVuprR(self, path, selFile):
  parent = FFFUBh(path, False)
  self.session.openWithCallback(self.VVwe12, BF(CCeH84, mode=CCeH84.VVf4Wu, VVXtjq=parent, VVclLa="Create Symlink here"))
 def VVwe12(self, newPath):
  if len(newPath) > 0:
   target = self.VVOO24(self.VVZPLh())
   target = FFTAAa(target)
   linkName = FFck77(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFThW1(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFAvZA(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFOjga(self, BF(self.VVJopQ, target, link), "Create Soft Link ?\n\n%s" % txt, VVA7RB=True)
 def VVJopQ(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVp7GH)
  result = FFnz9X(cmd)
  if result == "Successful" : FF6b7h(self, result)
  else      : FFAvZA(self, result)
 def VVU7jp(self, path, selFile):
  lastPart = FFck77(path)
  FFJC4A(self, BF(self.VVem7E, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVem7E(self, path, selFile, VVg7w7):
  if VVg7w7:
   parent = FFFUBh(path, True)
   if os.path.isdir(path):
    path = FFTAAa(path)
   newName = parent + VVg7w7
   cmd = "mv '%s' '%s' %s" % (path, newName, VVp7GH)
   if VVg7w7:
    if selFile != VVg7w7:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFOjga(self, BF(self.VV2Zp2, cmd), message, title="Rename file?")
    else:
     FFAvZA(self, "Cannot use same name!", title="Rename")
 def VV2Zp2(self, cmd):
  result = FFnz9X(cmd)
  if "Fail" in result:
   FFAvZA(self, result)
  self.VVAKTc()
 def VVw8me(self, path, selFile, isMove):
  if isMove : VVclLa = "Move to here"
  else  : VVclLa = "Paste here"
  parent = FFFUBh(path, False)
  self.session.openWithCallback(BF(self.VVJnof, isMove, path, selFile)
         , BF(CCeH84, mode=CCeH84.VVf4Wu, VVXtjq=parent, VVclLa=VVclLa))
 def VVJnof(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = FFck77(path)
   if os.path.isdir(path):
    path = FFTAAa(path)
   newPath = FFThW1(newPath)
   dest = newPath + lastPart
   if os.path.isdir(path) and os.path.isdir(dest):
    if isMove:
     FFAvZA(self, 'Same directory already exists:\n\n%s\n\n( Try to copy then delete the source )' % dest)
     return
    else:
     dest = newPath
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFOjga(self, BF(FFGC8R, self, cmd, VVFApn=self.VVAKTc), txt, VVA7RB=True)
   else:
    FFAvZA(self, "Cannot %s to same directory !" % action.lower())
 def VVhHHM(self, path, fileName):
  path = FFTAAa(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFOjga(self, BF(self.VVajQD, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVajQD(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VVAKTc()
 def VVG4B2(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVpo5P and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVJZ3b(self, path, isFile):
  dirName = FFThW1(os.path.dirname(path))
  if isFile : objName, VVg7w7 = "File"  , self.edited_newFile
  else  : objName, VVg7w7 = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFJC4A(self, BF(self.VVJD8s, dirName, isFile, title), title=title, defaultText=VVg7w7, message="Enter %s Name:" % objName)
 def VVJD8s(self, dirName, isFile, title, VVg7w7):
  if VVg7w7:
   if isFile : self.edited_newFile = VVg7w7
   else  : self.edited_newDir  = VVg7w7
   path = dirName + VVg7w7
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVp7GH)
    else  : cmd = "mkdir '%s' %s" % (path, VVp7GH)
    result = FFnz9X(cmd)
    if "Fail" in result:
     FFAvZA(self, result)
    self.VVAKTc()
   else:
    FFAvZA(self, "Name already exists !\n\n%s" % path, title)
 def VV1jTz(self, path, selFile):
  c1, c2, c3 = VV4YPU, VVXaO9, VVhTQL
  VVwSHr = []
  VVwSHr.append((c1 + "List Package Files"         , "VVINMA"     ))
  VVwSHr.append((c1 + "Package Information"         , "VVzh3P"     ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append((c2 + "Install Package"          , "VVk4L8_CheckVersion" ))
  VVwSHr.append((c2 + "Install Package (force reinstall)"     , "VVk4L8_ForceReinstall" ))
  VVwSHr.append((c2 + "Install Package (force overwrite)"     , "VVk4L8_ForceOverwrite" ))
  VVwSHr.append((c2 + "Install Package (force downgrade)"     , "VVk4L8_ForceDowngrade" ))
  VVwSHr.append((c2 + "Install Package (ignore failed dependencies)"  , "VVk4L8_IgnoreDepends" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append((c3 + "Remove Related Package"        , "VV4yVd_ExistingPackage" ))
  VVwSHr.append((c3 + "Remove Related Package (force remove)"    , "VV4yVd_ForceRemove"  ))
  VVwSHr.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VV4yVd_IgnoreDepends" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Extract Files"           , "VVOw9u"     ))
  VVwSHr.append(("Unbuild Package"           , "VVw6kJ"     ))
  FFKX6p(self, BF(self.VVzxbl, path, selFile), VVwSHr=VVwSHr)
 def VVzxbl(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVINMA"      : self.VVINMA(path, selFile)
   elif item == "VVzh3P"      : self.VVzh3P(path)
   elif item == "VVk4L8_CheckVersion"  : self.VVk4L8(path, selFile, VVJBI8     )
   elif item == "VVk4L8_ForceReinstall" : self.VVk4L8(path, selFile, VVUj18 )
   elif item == "VVk4L8_ForceOverwrite" : self.VVk4L8(path, selFile, VV2M4Y )
   elif item == "VVk4L8_ForceDowngrade" : self.VVk4L8(path, selFile, VVFbVd )
   elif item == "VVk4L8_IgnoreDepends" : self.VVk4L8(path, selFile, VVhG5k )
   elif item == "VV4yVd_ExistingPackage" : self.VV4yVd(path, selFile, VVhiem     )
   elif item == "VV4yVd_ForceRemove"  : self.VV4yVd(path, selFile, VVbRax  )
   elif item == "VV4yVd_IgnoreDepends"  : self.VV4yVd(path, selFile, VVFY8T )
   elif item == "VVOw9u"     : self.VVOw9u(path, selFile)
   elif item == "VVw6kJ"     : self.VVw6kJ(path, selFile)
   else           : self.close()
 def VVINMA(self, path, selFile):
  if FF0CKG("ar") : cmd = "allOK='1';"
  else    : cmd  = FFlS4l()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVStMY, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVStMY, VVStMY)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFr3ln(self, cmd, VVFApn=self.VVAKTc)
 def VVOw9u(self, path, selFile):
  lastPart = FFck77(path)
  dest  = FFFUBh(path, True) + selFile[:-4]
  cmd  =  FFlS4l()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFlWZ0("mkdir '%s'" % dest) + ";"
  cmd +=    FFlWZ0("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFw6UZ(dest, VV80BT))
  cmd += "fi;"
  FFCHwU(self, cmd, VVFApn=self.VVAKTc)
 def VVw6kJ(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVBorG = os.path.splitext(path)[0]
  else        : VVBorG = path + "_"
  if path.endswith(".deb")   : VV5a1M = "DEBIAN"
  else        : VV5a1M = "CONTROL"
  cmd  = FFlS4l()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVBorG, FFuSel())
  cmd += "  mkdir '%s';"    % VVBorG
  cmd += "  CONTPATH='%s/%s';"  % (VVBorG, VV5a1M)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVBorG
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVBorG, VVBorG)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVBorG
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVBorG, VVBorG)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVBorG
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVBorG
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVBorG, FFw6UZ(VVBorG, VV80BT))
  cmd += "fi;"
  FFCHwU(self, cmd, VVFApn=self.VVAKTc)
 def VVzh3P(self, path):
  listCmd  = FFeJzm(VVT5Tj, "")
  infoCmd  = FFtNvi(VVfQeQ , "")
  filesCmd = FFtNvi(VVcV6O, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFoIr5(VVSqFX)
   notInst = "Package not installed."
   cmd  = FFN8GC("File Info", VVSqFX)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFN8GC("System Info", VVSqFX)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFw6UZ(notInst, VVHKA4))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFN8GC("Related Files", VVSqFX)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FF7AMX(self, cmd)
  else:
   FF0QO3(self)
 def VVk4L8(self, path, selFile, cmdOpt):
  cmd = FFtNvi(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFOjga(self, BF(FFCHwU, self, cmd, VVFApn=FFI36Q), "Install Package ?\n\n%s" % selFile)
  else:
   FF0QO3(self)
 def VV4yVd(self, path, selFile, cmdOpt):
  listCmd  = FFeJzm(VVT5Tj, "")
  infoCmd  = FFtNvi(VVfQeQ, "")
  instRemCmd = FFtNvi(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFw6UZ(errTxt, VVHKA4))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFw6UZ(cannotTxt, VVHKA4))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFw6UZ(tryTxt, VVHKA4))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFOjga(self, BF(FFCHwU, self, cmd, VVFApn=FFI36Q), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FF0QO3(self)
 def VVDbba(self, path):
  hostName = FFnz9X("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVTeSJ(self, path, isDir):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVwSHr = []
  VVwSHr.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVwSHr.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVwSHr.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVwSHr.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVwSHr.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVwSHr.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVwSHr.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVwSHr.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVwSHr.append(("%s.zip"  % Path   , "archPath_zip"  ))
  if isDir:
   VVwSHr.append(VVbzyo)
   VVwSHr.append(('Convert to ".ipk" Package' , "convertDirToIpk" ))
   VVwSHr.append(('Convert to ".deb" Package' , "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFKX6p(self, BF(self.VVX1ND, path, isDir, title), VVwSHr=VVwSHr, title=title, VVCNiH=c1, VVIhEb=c2)
 def VVX1ND(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVMLAq(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz"   : self.VVMLAq(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVMLAq(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVMLAq(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"    : self.VVMLAq(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"    : self.VVMLAq(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz"   : self.VVMLAq(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVMLAq(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVMLAq(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"    : self.VVMLAq(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk"   : self.VVSYy4(path, False)
   elif item == "convertDirToDeb"   : self.VVSYy4(path, True)
   else         : self.close()
 def VVSYy4(self, path, VVM65w):
  self.session.openWithCallback(self.VVAKTc, BF(CCjcS8, path=path, VVM65w=VVM65w))
 def VVMLAq(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FFFUBh(path, True)
  lastPart = FFck77(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFNMcU("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFNMcU("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFNMcU("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVStMY
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFlWZ0("rm -f '%s'" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFw6UZ(failed, VVmIAH))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFw6UZ(srcTxt, VVHJRy))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFw6UZ("Output", VV80BT))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFw6UZ(failed, VV0rNQ))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFr3ln(self, cmd, VVFApn=self.VVAKTc, title=title)
 def VVw8Vw(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CCeH84.VVJWza(FFFUBh(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CCCBMo(self, self, title, BF(self.VVOYsC, pathLst))
 def VVOYsC(self, pathLst):
  return CCCBMo.VVtG1f(pathLst)
 def VVHjal(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VVRL8F, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFOjga(self, BF(FFqXEj, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFqXEj(self, fnc, title=txt)
  else:
   FFAvZA(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VVRL8F(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, 'w:gz') as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFheEQ(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VVAKTc()
  else:
   FFblrr(tarPath)
   FFAvZA(self, "Error while converting.", title=title)
 def VVigal(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVBJt1, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFOjga(self, BF(FFqXEj, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFqXEj(self, fnc, title=txt)
  else:
   FFAvZA(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVBJt1(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFheEQ(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VVAKTc()
  else:
   FFblrr(zipPath)
   FFAvZA(self, "Error while converting.", title=title)
 def VV7Ibz(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FFThW1(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  os.system(FFlWZ0("rm -f '%s' '%s'" % (m1v, mvi)))
  res = os.system(FFlWZ0("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)))
  if res == 0 and fileExists(m1v):
   res = os.system(FFlWZ0("mv -f '%s' '%s'" % (m1v, mvi)))
   self.VVAKTc()
   FF6b7h(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FFAvZA(self, "Cannot convert this file !", title=title)
 @staticmethod
 def VVpZNA(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCcojD.VVEI1u(SELF.session, enableZapping= False, enableDownloadMenu=False, enableOpenInFMan=False)
  except:
   pass
 @staticmethod
 def VVYryR(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFThW1(fDir), fName
  return "", "", ""
 @staticmethod
 def VVIY6h(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVkvYz(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVpYrc(size, mode=0):
  txt = CCeH84.VVUiXj(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVUiXj(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VVtdsg(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VVnVuy(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FFAvZA(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VV74My():
  tDict = CCOLsm.VVWj5y()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVJWza(path):
  lst = []
  for ext in CCeH84.VV74My():
   lst.extend(FFLuBK(path, "*.%s" % ext))
  return sorted(lst, key=FFucwL(FF8kED))
 @staticmethod
 def VVIB0Q(path):
  res = os.system("tar -tzf '%s' >/dev/null" % path)
  return res == 0
 @staticmethod
 def VVDVh3(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
class CCOLsm(MenuList):
 VVj6Vj  = 0
 VVaxPR  = 1
 VVxEx8  = 2
 VVM1tl  = 3
 VVdcfh  = 4
 VVZoaQ  = 5
 VVYyyZ  = 6
 VVMyo6  = 7
 VV7vTP  = "<List of Storage Devices>"
 VVGBaQ = "<Parent Directory>"
 def __init__(self, VVz7PC=False, directory="/", VV5NsQ=True, VVOpkz=True, VVg2xy=True, VVEUah=None, VVjy8Z=False, VVeRaf=False, VVEhYY=False, isTop=False, VVVrki=None, VVGjni=1000, VV2ql8=30, VVSYmq=30, VVVWYu="#00000000", pngBGColorSelStr="#06003333"):
  MenuList.__init__(self, list, VVz7PC, eListboxPythonMultiContent)
  self.VV5NsQ  = VV5NsQ
  self.VVOpkz    = VVOpkz
  self.VVg2xy  = VVg2xy
  self.VVEUah  = VVEUah
  self.VVjy8Z   = VVjy8Z
  self.VVeRaf   = VVeRaf or []
  self.VVEhYY   = VVEhYY or []
  self.isTop     = isTop
  self.additional_extensions = VVVrki
  self.VVGjni    = VVGjni
  self.VV2ql8    = VV2ql8
  self.VVSYmq    = VVSYmq
  self.pngBGColor    = FFUCM9(VVVWYu)
  self.pngBGColorSel   = FFUCM9(pngBGColorSelStr)
  self.EXTENSIONS    = CCOLsm.VVWj5y()
  self.VVFnSu   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.l.setFont(0, gFont(VVOCsc, self.VV2ql8))
  self.l.setItemHeight(self.VVSYmq)
  self.png_mem   = self.VVusbz("mem")
  self.png_usb   = self.VVusbz("usb")
  self.png_fil   = self.VVusbz("fil")
  self.png_dir   = self.VVusbz("dir")
  self.png_dirup   = self.VVusbz("dirup")
  self.png_srv   = self.VVusbz("srv")
  self.png_slwfil   = self.VVusbz("slwfil")
  self.png_slbfil   = self.VVusbz("slbfil")
  self.png_slwdir   = self.VVusbz("slwdir")
  self.VVjMvA()
  self.VVCdPn(directory)
 def VVusbz(self, category):
  return LoadPixmap("%s%s.png" % (VVdSQY, category), getDesktop(0))
 @staticmethod
 def VVWj5y():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVIxLn(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFTAAa(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFNkac(" -> " , VVSqFX) + FFNkac(os.readlink(path), VV80BT)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVSYmq + 10, 0, self.VVGjni, self.VVSYmq, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVFJgt: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVSYmq-4, self.VVSYmq-4, png, self.pngBGColor, self.pngBGColorSel, VVFJgt))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVSYmq-4, self.VVSYmq-4, png, self.pngBGColor, self.pngBGColorSel))
  return tableRow
 def VVZ6Yt(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVjMvA(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VVpuf7(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVkL5B(self, file):
  if os.path.realpath(file) == file:
   return self.VVpuf7(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVpuf7(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVpuf7(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVol47(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVFnSu.info(l[0][0]).getEvent(l[0][0])
 def VVT7L2(self):
  return self.list
 def VVt8Db(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVCdPn(self, directory, select = None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VVg2xy:
    self.current_mountpoint = self.VVkL5B(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VVg2xy:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVEhYY and not self.VVt8Db(path, self.VVeRaf):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVIxLn(name=p.description, absolute=path, isDir=True, png=png))
    path = "/"
    if path not in self.VVEhYY and not self.VVt8Db(path, self.VVeRaf):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVIxLn(name="INTERNAL FLASH", absolute="/", isDir=True, png=self.png_mem))
  elif self.VVjy8Z:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVFnSu = eServiceCenter.getInstance()
   list = VVFnSu.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VV5NsQ and not self.isTop:
   if directory == self.current_mountpoint and self.VVg2xy:
    self.list.append(self.VVIxLn(name=self.VV7vTP, absolute=None, isDir=True, png=self.png_dirup))
   elif (directory != "/") and not (self.VVEhYY and self.VVpuf7(directory) in self.VVEhYY):
    self.list.append(self.VVIxLn(name=self.VVGBaQ, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, png=self.png_dirup))
  if self.VV5NsQ:
   for x in directories:
    if not (self.VVEhYY and self.VVpuf7(x) in self.VVEhYY) and not self.VVt8Db(x, self.VVeRaf):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVIxLn(name=name, absolute=x, isDir=True, png=png))
  if self.VVOpkz:
   for x in files:
    if self.VVjy8Z:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFNkac(" -> " , VVSqFX) + FFNkac(target, VV80BT)
       else:
        png = self.png_slbfil
        name += FFNkac(" -> " , VVSqFX) + FFNkac(target, VV0rNQ)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVZ6Yt(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVdSQY, category))
    if (self.VVEUah is None) or iCompile(self.VVEUah).search(path):
     self.list.append(self.VVIxLn(name=name, absolute=x , isDir=False, png=png))
  if self.VVg2xy and len(self.list) == 0:
   self.list.append(self.VVIxLn(name=FFNkac("No USB connected", VVcK7G), absolute=None, isDir=False, png=self.png_usb))
  self.l.setList(self.list)
  self.VVjQRG()
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVQNWz(self):
  return self.current_directory
 def VVZkoH(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VVhNd6(self):
  return self.VVqWQM() and self.VVQNWz()
 def VVqWQM(self):
  return self.list[0][1][7] in (self.VV7vTP, self.VVGBaQ)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVCdPn(self.getSelection()[0], select = self.current_directory)
 def VVASTQ(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVEcuI(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVpmrI)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVpmrI)
 def refresh(self):
  self.VVCdPn(self.current_directory, self.VVASTQ())
 def VVpmrI(self, action, device):
  self.VVjMvA()
  if self.current_directory is None:
   self.refresh()
 def VVAsjh(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVj6Vj : nameAlpMode, nameAlpTxt = self.VVaxPR, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVj6Vj, sAZ
  if mode == self.VVxEx8 : nameNumMode, nameNumTxt = self.VVM1tl, s90
  else       : nameNumMode, nameNumTxt = self.VVxEx8, s09
  if mode == self.VVdcfh : dateMode, dateTxt = self.VVZoaQ, sON
  else       : dateMode, dateTxt = self.VVdcfh, sNO
  if mode == self.VVYyyZ : typeMode, typeTxt = self.VVMyo6, sZA
  else       : typeMode, typeTxt = self.VVYyyZ, sAZ
  if   mode in (self.VVj6Vj, self.VVaxPR): txt = "Name (%s)" % (sAZ if mode == self.VVj6Vj else sZA)
  elif mode in (self.VVxEx8, self.VVM1tl): txt = "Name (%s)" % (s09 if mode == self.VVj6Vj else s90)
  elif mode in (self.VVdcfh, self.VVZoaQ): txt = "Date (%s)" % (sNO if mode == self.VVdcfh else sON)
  elif mode in (self.VVYyyZ, self.VVMyo6): txt = "Type (%s)" % (sAZ if mode == self.VVYyyZ else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VVjQRG(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FFGxwH(CFG.browserSortMode, mode)
   FFGxwH(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVqWQM() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVj6Vj, self.VVaxPR):
    rev = True if mode == self.VVaxPR else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVxEx8, self.VVM1tl):
    rev = True if mode == self.VVM1tl else False
    self.list = sorted(self.list[item0:], key=FFucwL(BF(self.VVkm6m, isMix, rev)), reverse=rev)
   elif mode in (self.VVdcfh, self.VVZoaQ):
    rev = True if mode == self.VVZoaQ else False
    self.list = sorted(self.list[item0:], key=FFucwL(BF(self.VVcm2O, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VVMyo6 else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VVkm6m(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FF8kED(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FFdA1L(dir2, dir1) or FF8kED(name1, name2)
 def VVcm2O(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FFdA1L(stat2.st_ctime, stat1.st_ctime)
    else : return FFdA1L(dir2, dir1) or FFdA1L(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CC6XYk(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FFheJw(VVXIC2, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVd40u   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVbJip(defFG, "#00FFFFFF")
  self.defBG   = self.VVbJip(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFqVmU(self, self.Title)
  self["keyRed"].show()
  FFTGpi(self["keyGreen"] , "< > Transp.")
  FFTGpi(self["keyYellow"], "Foreground")
  FFTGpi(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV4sks     ,
   "green"   : self.VV4sks     ,
   "yellow"  : BF(self.VVOtqE, False)  ,
   "blue"   : BF(self.VVOtqE, True)  ,
   "up"   : self.VVRmh5       ,
   "down"   : self.VVThvL      ,
   "left"   : self.VVXUAo      ,
   "right"   : self.VVaQKG      ,
   "last"   : BF(self.VVs988, -5) ,
   "next"   : BF(self.VVs988, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVevf4)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFAMY6(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFAMY6(self["keyRed"] , c)
  FFAMY6(self["keyGreen"] , c)
  self.VV1cUV()
  self.VVEEr5()
  FFilsZ(self["myColorTst"], self.defFG)
  FFAMY6(self["myColorTst"], self.defBG)
 def VVbJip(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVEEr5(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVVM9C(0, 0)
     return
 def VV4sks(self):
  self.close(self.defFG, self.defBG)
 def VVRmh5(self): self.VVVM9C(-1, 0)
 def VVThvL(self): self.VVVM9C(1, 0)
 def VVXUAo(self): self.VVVM9C(0, -1)
 def VVaQKG(self): self.VVVM9C(0, 1)
 def VVVM9C(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVquPt()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVCPiQ()
 def VV1cUV(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVCPiQ(self):
  color = self.VVquPt()
  if self.isBgMode: FFAMY6(self["myColorTst"], color)
  else   : FFilsZ(self["myColorTst"], color)
 def VVOtqE(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VV1cUV()
   self.VVEEr5()
 def VVs988(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVVM9C(0, 0)
 def VVpBci(self):
  return hex(self.transp)[2:].zfill(2)
 def VVquPt(self):
  return ("#%s%s" % (self.VVpBci(), self.colors[self.curRow][self.curCol])).upper()
class CC9Rlw(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFheJw(VVdmEc, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FFqVmU(self, title="%s%s%s" % (self.Title, " " * 10, FFNkac("Change values with Up , Down, < , 0 , >", VVcK7G)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVmBrJ      ,
   "cancel" : self.VVYiBq      ,
   "info"  : self.VVjcrw    ,
   "red"  : self.VVvWCD  ,
   "green"  : self.VVxQfQ   ,
   "yellow" : BF(self.VVUHUb, 0)  ,
   "blue"  : self.VV3MLf    ,
   "menu"  : self.VVPF0J      ,
   "left"  : self.VVXUAo      ,
   "right"  : self.VVaQKG      ,
   "last"  : self.VVM20s     ,
   "next"  : self.VVLKgy     ,
   "0"   : self.VVVpQ9    ,
   "up"  : self.VVRmh5       ,
   "down"  : self.VVThvL      ,
   "pageUp" : BF(self.VVzu8c, True) ,
   "pageDown" : BF(self.VVzu8c, False) ,
   "chanUp" : BF(self.VVzu8c, True) ,
   "chanDown" : BF(self.VVzu8c, False) ,
   "play"  : BF(self.VV4iLI, "pause")  ,
   "pause"  : BF(self.VV4iLI, "pause")  ,
   "playPause" : BF(self.VV4iLI, "pause")  ,
   "stop"  : BF(self.VV4iLI, "pause")  ,
   "audio"  : BF(self.VV4iLI, "audio")  ,
   "subtitle" : BF(self.VV4iLI, "subtitle") ,
   "rewind" : BF(self.VV4iLI, "rewind" ) ,
   "forward" : BF(self.VV4iLI, "forward" ) ,
   "rewindDm" : BF(self.VV4iLI, "rewindDm") ,
   "forwardDm" : BF(self.VV4iLI, "forwardDm")
  }, -1)
  self.VViObJ()
  self.onShown.append(self.VVevf4)
  self.onClose.append(self.VVWjxb)
 def VViObJ(self):
  lst = []
  for fil in FFLuBK(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VVw7NR:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VVevf4(self):
  self.onShown.remove(self.VVevf4)
  FFBmK5(self)
  FFuN11(self)
  for i in range(3):
   self["mySubt%d" % i].instance.setNoWrap(True)
   self["mySubt%d" % i].hide()
  self.VVwzbs()
  self.VVmH4u()
  self.VVlyml()
 def VVWjxb(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VVJv6k(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FFAMY6(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VVF8Z6()
 def VVwzbs(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FFAMY6(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VVmBrJ(self):
  if self.settingShown:
   confItem = self.VVRBC7()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVwSHr = []
   if isinstance(lst[0], tuple):
    for item in lst: VVwSHr.append((item[1], item[0]))
   else:
    for item in lst: VVwSHr.append((item, item))
   menuInstance = FFKX6p(self, self.VVhZZv, VVwSHr=VVwSHr, width=700, title=title, VVCNiH="#33221111", VVIhEb="#33110011")
   menuInstance.VVEPkY(confItem.getIndex())
  else:
   self.close("subtExit")
 def VVhZZv(self, item=None):
  if item:
   self.VVRBC7()[self.CursorPos].setValue(item)
   self.VVF8Z6()
   self.VVmH4u()
   self.VVanvF(True)
 def VVYiBq(self):
  for confItem in self.VVRBC7():
   if confItem.isChanged():
    FFOjga(self, self.VVRO5O, "Save Changes ?", callBack_No=self.VVTekJ, title=self.Title)
    break
  else:
   if self.settingShown: self.VVwzbs()
   else    : self.close("subtExit")
 def VVPF0J(self):
  if self.settingShown: self.VVqdvP()
  else    : self.VVJv6k()
 def VVXUAo(self): self.VVrMCg(-1)
 def VVaQKG(self): self.VVrMCg(1)
 def VVrMCg(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VVWNEP()
   if pos == -1: ndx = self.VVoXzq(posVal)
   else  : ndx = self.VVFJuF(posVal)
   if   ndx < 0      : FFMYB5(self, "Not found" , 500)
   elif ndx == 0      : FFMYB5(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FFMYB5(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVzdye(frmSec)
    if allow:
     self.VVUHUb(delay, True)
     self.VVanvF(force=True)
    else:
     FFMYB5(self, "Delay out of range", 800)
 def VVzu8c(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VV4iLI(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVM20s(self) : self.VVrmqR(5)
 def VVLKgy(self) : self.VVrmqR(6)
 def VVVpQ9(self) : self.VVrmqR(-1)
 def VVRmh5(self):
  if self.settingShown: self.VVrmqR(1)
  else    : self.VVzu8c(True)
 def VVThvL(self):
  if self.settingShown: self.VVrmqR(0)
  else    : self.VVzu8c(False)
 def VVrmqR(self, direction):
  if self.settingShown:
   confItem = self.VVRBC7()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VVF8Z6()
   self.VVmH4u()
   self.VVanvF(True)
 def VVRBC7(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VVTekJ(self):
  for confItem in self.VVRBC7(): confItem.cancel()
  self.VVF8Z6()
  self.VVmH4u()
  self.VVwzbs()
 def VVvWCD(self):
  if self.settingShown:
   FFOjga(self, self.VVWmR9, "Reset Subtitle Settings to default ?", title=self.Title)
 def VVWmR9(self):
  for confItem in self.VVRBC7(): confItem.setValue(confItem.default)
  self.VVRO5O()
  self.VVF8Z6()
  self.VVmH4u()
 def VVUHUb(self, delay, force=False):
  if self.settingShown or force:
   FFGxwH(CFG.subtDelaySec, delay)
   self.VVLxWH()
   self.VVF8Z6()
   self.VVmH4u()
   if self.settingShown:
    FFMYB5(self, 'Reset to "0"', 800, isGrn=True)
 def VVxQfQ(self):
  if self.settingShown:
   self.VVRO5O()
   self.VVwzbs()
 def VVRO5O(self):
  for confItem in self.VVRBC7(): confItem.save()
  configfile.save()
  self.VVLxWH()
  FFMYB5(self, "Saved", 1000, isGrn=True)
 def VVF8Z6(self):
  cfgLst = self.VVRBC7()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VVmH4u(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   addFont(path, fnt, 100, 1)
  else:
   fnt = VVOCsc
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFzS0X(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFilsZ(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FFAMY6(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    inst.setNoWrap(True)
    lineH = FFCOh0(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFzS0X(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFEFsT()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  boxFSize = self["myInfoFrame"].instance.size()
  boxSize  = self["myInfoBody"].instance.size()
  self["myInfoFrame"].instance.move(ePoint(int((winW - boxFSize.width()) // 2), int((winH - boxFSize.height()) // 2)))
  self["myInfoBody"].instance.move(ePoint(int((winW - boxSize.width()) // 2) , int((winH - boxSize.height()) // 2)))
 def VVjcrw(self):
  sp = "    "
  txt  = "%s\n"   % FFNkac("Subtitle File:", VVXaO9)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FFNkac("Subtitle Settings:", VVXaO9)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VVWNEP()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FFQjGS(frmSec1)
   time2 = FFQjGS(toSec2)
   txt += "\n"
   txt += "%s\n"       % FFNkac("Timing:", VVXaO9)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FFQjGS(durVal)
   txt += sp + "Progress\t: %s\n" % FFQjGS(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FFNkac("Subtitle end reached.", VVmIAH)
  FFheEQ(self, txt, title="Current Subtitle")
 def VVlyml(self, path="", delay=0, enc=""):
  FFqXEj(self, BF(self.VVLmIB, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VVLmIB(self, path="", delay=0, enc=""):
  FFMYB5(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVirLW(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VVF8Z6()
     self.VVviNI()
   else:
    path, delay, enc = CC9Rlw.VVhvlu(self)
    if path:
     self.VVlyml(path=path, delay=delay, enc=enc)
    else:
     self.VVqdvP()
  except:
   pass
 def VVviNI(self):
  posVal, durVal = self.VVWNEP()
  if self.VVao1v(posVal):
   return
  CC9Rlw.VVbJwk(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVanvF)
  except:
   self.timerUpdate.callback.append(self.VVanvF)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVNRFl)
  except:
   self.timerEndText.callback.append(self.VVNRFl)
  FFMYB5(self, "Subtitle started", 700, isGrn=True)
 def VVao1v(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CC9Rlw.VVNjz8(self)
   FFblrr(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VVqdvP(self):
  c1, c2, c3, c4, c5 = "", VVXaO9, VVtjbM, VVhTQL, VVmIAH
  VVwSHr = []
  VVwSHr.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVwSHr.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVwSHr.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVwSHr.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVwSHr.append(VVbzyo)
   VVwSHr.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVwSHr.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVwSHr.append(VVbzyo)
   VVwSHr.append(("Help (Keys)"        , "help"  ))
  FFKX6p(self, self.VV0oZf, VVwSHr=VVwSHr, width=700, title='Find Subtitle ".srt" File', VVCNiH="#33221111", VVIhEb="#33110011")
 def VV0oZf(self, item=None):
  if item:
   if   item == "allSrt"   : self.VVANIq(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VVANIq(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    dir1 = CFG.lastFileManFindSrt.getValue()
    dir2 = CFG.MovieDownloadPath.getValue()
    sDir = "/"
    for path in (dir1, dir2, "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VVsCHT, BF(CCeH84, mode=CCeH84.VVCcW3, VVXtjq=sDir))
   elif item.startswith("sugSrt") : self.VVANIq(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FFqXEj(self, BF(CCor0x.VVNdUZ, self, self.lastSubtFile, self.VVy4Yq, defEnc=self.lastSubtEnc), title="Loading Codecs ...", clearMsg=False)
    else             : FFMYB5(self, "SRT File error", 1000)
   elif item == "disab":
    FFblrr(CC9Rlw.VVNjz8(self))
    self.close("subtExit")
   elif item == "help"    : FFK3qq(self, VVdSQY + "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VVy4Yq(self, item=None):
  if item:
   FFqXEj(self, BF(self.VVlyml, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VVsCHT(self, path):
  if path:
   FFGxwH(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VVlyml(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VVANIq(self, defSrt="", mode=0, coeff=0.25):
  FFqXEj(self, BF(self.VVUFIp, defSrt, mode=mode, coeff=coeff), title="Searching for srt files", clearMsg=False)
 def VVUFIp(self, defSrt="", mode=0, coeff=0.25):
  FFMYB5(self)
  if mode == 1:
   srtList = CC9Rlw.VVnRFT(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FFIsyt('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFaJMY(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVHti6(srtList, coeff)
     if err:
      if self.settingShown: FFMYB5(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVmJ2p = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FFThW1(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVmJ2p.append((fName, Dir))
   VVVt3G  = ("Select"    , self.VVTbh7     , [])
   VVPypB = self.VV7yit
   VV0QzM = (""     , self.VVBkfW       , [])
   VV3zZz = (""     , BF(self.VVqw7u, defSrt, False) , [])
   VVcZtS = ("Find Current File" , BF(self.VVqw7u, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FFyLgY(self, None, title=title, header=header, VVd40u=VVmJ2p, VVLpvM=widths, VV2ql8=28, VVVt3G=VVVt3G, VVPypB=VVPypB, VV0QzM=VV0QzM, VV3zZz=VV3zZz, VVcZtS=VVcZtS, lastFindConfigObj=CFG.lastFindSubtitle
     , VVCNiH="#11002222", VVIhEb="#33001111", VV9Ea0="#33001111", VV0HYK="#11ffff00", VVZozG="#11445544", VVsrIN="#22222222", VVn0US="#11002233")
  elif self.settingShown : FFMYB5(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VV7yit(self, VVl7Cx):
  VVl7Cx.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VVBkfW(self, VVl7Cx, title, txt, colList):
  fName, Dir = colList
  FFheEQ(VVl7Cx, "%s\n\n%s%s" % (FFNkac("Path:", VVXaO9), Dir, fName), title=title)
 def VVqw7u(self, path, VViqYq, VVl7Cx, title, txt, colList):
  for ndx, row in enumerate(VVl7Cx.VVBOVP()):
   if path == row[1].strip() + row[0].strip():
    VVl7Cx.VVm16r(ndx)
    break
  else:
   if VViqYq:
    FFMYB5(VVl7Cx, "Not in list !", 1000)
 def VVTbh7(self, VVl7Cx, title, txt, colList):
  VVl7Cx.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VVlyml(path=path)
 def VVHti6(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCnfxp.VV20OD(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName and not CFG.epgLanguage.getValue() == "off":
   evName = CCnfxp.VVEGxt(evName)
  if evName:
   lst, err = CC9Rlw.VVYkdq(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVirLW(self, path, enc=None):
  if not fileExists(path):
   return [], "File not found"
  if (FFtd04(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FF7up6(path, encLst=enc if enc else None)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVXLa7(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VVBDxW(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVLxWH()
  return subtList, ""
 def VVBDxW(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VVXLa7(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVLxWH(self):
  path = CC9Rlw.VVNjz8(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVanvF(self, force=False):
  posVal, durVal = self.VVWNEP()
  if self.VVao1v(posVal):
   return
  curIndex = self.VVgd2C(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVNRFl()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFilsZ(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VVWNEP(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCcojD.VV1JQT(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCnfxp.VV20OD(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VVgd2C(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VVoXzq(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VVFJuF(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVNRFl(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFilsZ(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VV3MLf(self):
  FFqXEj(self, self.VVorCv, title="Loading Lines ...", clearMsg=False)
 def VVorCv(self):
  FFMYB5(self)
  VVmJ2p = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVmJ2p.append((cap, FFQjGS(frm), str(frm), firstLine))
  if VVmJ2p:
   title = "Select Current Subtitle Line"
   VVGssA  = self.VVlXli
   VVPypB = self.VV9B0B
   VVVt3G  = ("Select"   , self.VVh6Ru , [title])
   VVcZtS = ("Current Line" , self.VVdxqZ , [True])
   VVq3zo = ("Reset Delay" , self.VV3Xof , [])
   VVrIQY = ("New Delay"  , self.VVj9RX   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VVe5VU  = (CENTER , CENTER, CENTER , LEFT    )
   VVl7Cx = FFyLgY(self, None, title=title, header=header, VVd40u=VVmJ2p, VVe5VU=VVe5VU, VVLpvM=widths, VV2ql8=28, VVGssA=VVGssA, VVPypB=VVPypB, VVVt3G=VVVt3G, VVcZtS=VVcZtS, VVq3zo=VVq3zo, VVrIQY=VVrIQY
          , VVCNiH="#33002222", VVIhEb="#33001111", VV9Ea0="#33110011", VV0HYK="#11ffff00", VVZozG="#0a334455", VVsrIN="#22222222", VVn0US="#33002233")
  else:
   FFMYB5(self, "Cannot read lines !", 2000)
 def VVlXli(self, VVl7Cx):
  self.subtLinesTable = VVl7Cx
  if CFG.subtDelaySec.getValue():
   VVl7Cx["keyYellow"].show()
   VVl7Cx["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVl7Cx["keyYellow"].hide()
  VVl7Cx["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FFAMY6(VVl7Cx["keyBlue"], "#22222222")
  VVl7Cx.VVlWG2(BF(self.VV7U4T, VVl7Cx))
  self.VVdxqZ(VVl7Cx, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVhAWU)
  except:
   self.timerSubtLines.callback.append(self.VVhAWU)
  self.timerSubtLines.start(1000, False)
 def VV9B0B(self, VVl7Cx):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVl7Cx.cancel()
 def VVhAWU(self):
  if self.subtLinesTable:
   VVl7Cx = self.subtLinesTable
   posVal, durVal = self.VVWNEP()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVgd2C(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVl7Cx.VVx7ND(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVl7Cx.VVCunO(self.subtLinesTableNdx, row)
     row = VVl7Cx.VVx7ND(curIndex)
     row[0] = color + row[0]
     VVl7Cx.VVCunO(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VVh6Ru(self, VVl7Cx, Title):
  delay, color, allow = self.VVXOwG(VVl7Cx)
  if allow:
   self.VV9B0B(VVl7Cx)
   self.VVUHUb(delay, True)
  else:
   FFMYB5(VVl7Cx, "Delay out of range", 1500)
 def VVdxqZ(self, VVl7Cx, VViqYq, onlyColor=False):
  if VVl7Cx:
   posVal, durVal = self.VVWNEP()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVgd2C(posVal)
    if curIndex > -1:
     VVl7Cx.VVm16r(curIndex)
    else:
     ndx = self.VVoXzq(posVal)
     if ndx > -1:
      VVl7Cx.VVm16r(ndx)
 def VV3Xof(self, VVl7Cx, title, txt, colList):
  if VVl7Cx["keyYellow"].getVisible():
   self.VVUHUb(0, True)
   VVl7Cx["keyYellow"].hide()
   self.VVdxqZ(VVl7Cx, False)
 def VV7U4T(self, VVl7Cx):
  delay, color, allow = self.VVXOwG(VVl7Cx)
  VVl7Cx["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VVXOwG(self, VVl7Cx):
  lineTime = float(VVl7Cx.VVRTTA()[2].strip())
  return self.VVzdye(lineTime)
 def VVzdye(self, lineTime):
  posVal, durVal = self.VVWNEP()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VV4YPU
   else     : allow, color = False, VVmIAH
   delay = FFrVTn(val, -600, 600)
  return delay, color, allow
 def VVj9RX(self, VVl7Cx, title, txt, colList):
  pass
 @staticmethod
 def VV0aKm(SELF):
  path, delay, enc = CC9Rlw.VVhvlu(SELF)
  return True if path else False
 @staticmethod
 def VVhvlu(SELF):
  path, delay, enc = CC9Rlw.VVvFOM(SELF)
  if not path:
   path = CC9Rlw.VVAWbf(SELF)
  return path, delay, enc
 @staticmethod
 def VVvFOM(SELF):
  srtCfgPath = CC9Rlw.VVNjz8(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FF7up6(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVNjz8(SELF):
  fPath, fDir, fName = CCeH84.VVYryR(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCnfxp.VV20OD(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFbgUV(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VVAWbf(SELF):
  bestRatio = 0
  fPath, fDir, fName = CCeH84.VVYryR(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CC9Rlw.VVnRFT(SELF)
    bLst, err = CC9Rlw.VVYkdq(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVnRFT(SELF):
  fPath, fDir, fName = CCeH84.VVYryR(SELF)
  if pathExists(fDir):
   files = FFLuBK(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VVYkdq(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVeZL2():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVbJwk(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CC9Rlw.VVBUfO()
 @staticmethod
 def VVBUfO():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CChIHC(ScrollLabel):
 def __init__(self, parentSELF, text="", VVishT=True):
  ScrollLabel.__init__(self, text)
  self.VVishT   = VVishT
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VVQbgz  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VV2ql8    = None
  self.parentW    = None
  self.parentH    = None
  self.firstTime    = True
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VVR0bf ,
   "green"   : self.VVKoty ,
   "yellow"  : self.VVIRS8 ,
   "blue"   : self.VVJOqm ,
   "up"   : self.pageUp   ,
   "down"   : self.pageDown   ,
   "left"   : self.pageUp   ,
   "right"   : self.pageDown   ,
   "last"   : BF(self.VVK9Jy, 0) ,
   "0"    : BF(self.VVK9Jy, 1) ,
   "next"   : BF(self.VVK9Jy, 2) ,
   "pageUp"  : self.VVYMXa   ,
   "chanUp"  : self.VVYMXa   ,
   "pageDown"  : self.VV5jH7   ,
   "chanDown"  : self.VV5jH7
  }, -1)
 def VV3oQu(self, isResizable=True, VVHoVk=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFilsZ(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFAMY6(self.parentSELF["keyRedTop"], "#113A5365")
  FFBmK5(self.parentSELF, True)
  self.isResizable = isResizable
  if VVHoVk:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VV2ql8  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFAMY6(self, color)
 def VVK2CA(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  lineheight  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  lines   = int(self.long_text.size().height() / lineheight)
  margin   = int(lineheight / 6)
  self.pageHeight = int(lines * lineheight)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  self.setText(self.message)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVQbgz - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVzcJv()
 def pageUp(self):
  if self.VVQbgz > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVQbgz > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVYMXa(self):
  self.setPos(0)
 def VV5jH7(self):
  self.setPos(self.VVQbgz-self.pageHeight)
 def VV4GRJ(self):
  return self.VVQbgz <= self.pageHeight or self.curPos == self.VVQbgz - self.pageHeight
 def getText(self):
  return self.message
 def VVzcJv(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVQbgz, 3))
   start = int((100 - vis) * self.curPos / (self.VVQbgz - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVDaM8=VVZIpo):
  old_VV4GRJ = self.VV4GRJ()
  self.message = str(text)
  if self.pageHeight:
   self.long_text.setText(self.message)
   self.VVQbgz = self.long_text.calculateSize().height()
   if self.VVishT and self.VVQbgz > self.pageHeight:
    self.scrollbar.show()
    self.VVzcJv()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVQbgz))
   if   VVDaM8 == VVM50Z: self.setPos(0)
   elif VVDaM8 == VVGmpm : self.VV5jH7()
   elif old_VV4GRJ    : self.VV5jH7()
   if self.firstTime and len(self.message) > 0:
    self.firstTime = False
    self.setText(self.message, VVDaM8=VVDaM8)
 def appendText(self, text, VVDaM8=VVGmpm):
  self.setText(self.message + str(text), VVDaM8=VVDaM8)
 def VVIRS8(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VV5ype(size)
 def VVJOqm(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VV5ype(size)
 def VVKoty(self):
  self.VV5ype(self.VV2ql8)
 def VV5ype(self, VV2ql8):
  self.long_text.setFont(gFont(self.fontFamily, VV2ql8))
  self.setText(self.message, VVDaM8=VVZIpo)
  self.VVy5sP(calledFromFontSizer=True)
 def VVK9Jy(self, align):
  self.long_text.setHAlign(align)
 def VVR0bf(self):
  VVwSHr = []
  VVwSHr.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Align Left"  , "left" ))
  VVwSHr.append(("Align Center"  , "center" ))
  VVwSHr.append(("Align Right"  , "right" ))
  if self.outputFileToSave:
   VVwSHr.append(VVbzyo)
   VVwSHr.append((FFNkac("Save to File", VVXaO9), "save" ))
  VVwSHr.append(VVbzyo)
  VVwSHr.append(("Keys (Shortcuts)" , "help" ))
  FFKX6p(self.parentSELF, self.VVd54S, VVwSHr=VVwSHr, title="Text Option", width=500)
 def VVd54S(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VVK9Jy(0)
   elif item == "center" : self.VVK9Jy(1)
   elif item == "right" : self.VVK9Jy(2)
   elif item == "save"  : self.VVtTpD()
   elif item == "help"  : FFK3qq(self.parentSELF, VVdSQY + "_help_txt", "Text Viewer (Keys)")
 def VVtTpD(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FFThW1(expPath), self.outputFileToSave, FFLFgj())
   with open(outF, "w") as f:
    f.write(FFGlcE(self.message))
   FF6b7h(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFAvZA(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVy5sP(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVQbgz > 0 and self.pageHeight > 0:
   if self.VVQbgz < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVQbgz
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
