import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVdDje   = "v5.1.0"
VVUrQZ    = "01-05-2022"
EASY_MODE    = 0
VVLddi   = 0
VV0xHB   = 0
VVkxqr  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVngBg  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVe6OI    = "/media/usb/"
VVk5g8    = "/usr/share/enigma2/picon/"
VV2Mmb = "/etc/enigma2/blacklist"
VVgmxK   = "/etc/enigma2/"
VVdGEY  = "ajpanel_update_url"
VV4zs3   = "AJPan"
VVRRQu    = "AUTO FIND"
VVJgJQ    = ""
VVIbI9    = "Regular"
VVFkPZ      = "-" * 80
VVB35E    = ("-" * 100, )
VVWyR9    = ""
VV6iqe   = " && echo 'Successful' || echo 'Failed!'"
VVQsBX    = []
VVxcbV  = "Cannot continue (No Enough Memory) !"
VVj3zx  = False
VVioJp  = False
VVsWxe = False
VVDXvw     = 0
VVxZpK    = 1
VV2ztI    = 2
VV19tE   = 3
VVyofO    = 4
VVOhNa    = 5
VVCTjl = 6
VV9U6R = 7
VVcrrg  = 8
VVYI3s   = 9
VVIrXs   = 10
VVsdkx   = 11
VV9gk8  = 12
VV9biv  = 13
VV1aAd    = 14
VVpRAs   = 15
VVLvRB   = 16
VVLluH    = 17
WINDOW_SUBTITLE    = 18
VVx4P1  = 19
VVNiTo   = 0
VVDQDA   = 1
VVlNJ6   = 2
def FFMsxt():
 fList = None
 try:
  from enigma import getFontFaces
  return set(getFontFaces())
 except:
  try:
   from skin import getFontFaces
   return set(getFontFaces())
  except:
   pass
 return [VVIbI9]
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices=[ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.forceUtf8Encoding   = ConfigYesNo(default=True)
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsPath    = ConfigDirectory(default=VVRRQu, visible_width=51)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=51)
CFG.PIconsPath     = ConfigDirectory(default=VVk5g8, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVe6OI, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
tmp = [("srt", "From SRT File"), ("#FFFFFF", "White"), ("#C0C0C0", "Silver"), ("#808080", "Gray"), ("#000000", "Black"), ("#FF0000", "Red"), ("#800000", "Maroon"), ("#FFFF00", "Yellow"), ("#808000", "Olive"), ("#00FF00", "Lime"), ("#008000", "Green"), ("#00FFFF", "Aqua"), ("#008080", "Teal"), ("#0000FF", "Blue"), ("#000080", "Navy"), ("#FF00FF", "Fuchsia"), ("#800080", "Purple")]
CFG.subtDelay     = ConfigSelection(default="0.0", choices=[ (str(x/10.0),  str(x/10.0)) for x in range(-600, 600, 5) ])
CFG.subtTextFg     = ConfigSelection(default="srt", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVIbI9, choices=[ (x,  x) for x in FFMsxt() ])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=80, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[ ("0", "Left"), ("1", "Center"), ("2", "Right") ])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=0, stepwidth=10, min=-140, max=140, wraparound=False)
del tmp
def FFazY0():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVS929  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVFLRy = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVS929  : return 0
  elif VVFLRy : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVcrwi = FFazY0()
VVM75e = VVBPJz = VVe3tS = VVValh = VVcBCb = VVKDsv = VVAexn = VVgcU9 = COLOR_CONS_BRIGHT_YELLOW = VVzqsa = VVwcoZ = VVeyOS = VVXaUF = ""
def FFycFf()  : return FFsyrs()
def FFiqB1(*args) : FFmLCz(True , True , *args)
def FFACBV(*args): FFmLCz(False, True , *args)
def FFjFx6(*args): FFmLCz(True, False, *args)
def FFmLCz(addSep=True, oneLine=True, *args):
 if VVLddi:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if oneLine:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  else:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item:
      txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFeuGP(txt, isAppend=True, ignoreErr=False):
 if VVLddi:
  tm = FFD3g6()
  err = ""
  if not ignoreErr:
   err = FFsyrs()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFiqB1(err)
  FFiqB1("Output Log File : %s" % fileName)
def FFsyrs():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFD3g6()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except Exception as e:
  return "Cannot Trace !"
def FFUHpW():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVQsBX = []
def FF5ZRH(win):
 global VVQsBX
 if not win in VVQsBX:
  VVQsBX.append(win)
def FFOWIb(*args):
 global VVQsBX
 for win in VVQsBX:
  try:
   win.close()
  except:
   pass
 VVQsBX = []
def FFYIgW():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VV0l6A = FFYIgW()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FF0g4k()     : return PluginDescriptor(fnc=FFswSw, where=[PluginDescriptor.WHERE_SESSIONSTART] , needsRestart=True   , description="AJPanel Startup")
def FFkU8v()      : return getDescriptor(FFp3gD   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FF64VM()       : return getDescriptor(FFUu9q  , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFiMCm()   : return getDescriptor(FFZVxZ , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFvb4h(): return getDescriptor(FF4UXD , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player"  , descr="Signal Monitor / Player")
def FFaroL()  : return getDescriptor(FFIfXP  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV"     , descr="IPTV Menu")
def FFHJCB()     : return getDescriptor(FF48ew , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info."    , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFkU8v() , FF64VM() , FF0g4k() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFiMCm())
  result.append(FFvb4h())
  result.append(FFaroL())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFHJCB())
 return result
def FFswSw(reason, **kwargs):
 if reason == 0:
  FFD1L5()
  if "session" in kwargs:
   session = kwargs["session"]
   FFSrRJ(session)
   CCIt4k(session)
  CCAv2L.VVELBh()
def FFUu9q(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFp3gD, PLUGIN_NAME, 45)]
 else:
  return []
def FFp3gD(session, **kwargs):
 session.open(Main_Menu)
def FFZVxZ(session, **kwargs):
 session.open(CCN0r2)
def FF4UXD(session, **kwargs):
 FFTT8H(session, isFromSession=True)
def FFIfXP(session, **kwargs):
 session.open(CCNFtw)
def FF48ew(session, **kwargs):
 session.open(CCc6Hf, fncMode=CCc6Hf.VVbvPB)
def FFKjVi():
 FFcmhu(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFiMCm(), FFvb4h(), FFaroL() ])
 FFcmhu(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFHJCB() ])
def FFcmhu(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VV404Z = None
def FFD1L5():
 try:
  global VV404Z
  if VV404Z is None:
   VV404Z    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFeFUc
  ChannelContextMenu.FFe7Qq = FFe7Qq
 except:
  pass
def FFeFUc(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VV404Z(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFe7Qq, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFe7Qq, title1, csel, isFind=True))))
def FFe7Qq(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFrAs1(refCode)
 except:
  pass
 self.session.open(boundFunction(CCEOaz, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFSrRJ(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FF4Jnw, session, "lok")
 hk.actions['longCancel'] = boundFunction(FF4Jnw, session, "lesc")
 hk.actions['longRed']  = boundFunction(FF4Jnw, session, "lred")
def FF4Jnw(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFTT8H(session, isFromSession=True)
def FFFgql(SELF, title="", addLabel=False, addScrollLabel=False, VV64WM=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFkYLf()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCydIb(SELF)
 if VV64WM:
  SELF["myMenu"] = MenuList(VV64WM)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVhHBt        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFG8YJ(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FFqctt, SELF, "0") ,
  "1"    : boundFunction(FFqctt, SELF, "1") ,
  "2"    : boundFunction(FFqctt, SELF, "2") ,
  "3"    : boundFunction(FFqctt, SELF, "3") ,
  "4"    : boundFunction(FFqctt, SELF, "4") ,
  "5"    : boundFunction(FFqctt, SELF, "5") ,
  "6"    : boundFunction(FFqctt, SELF, "6") ,
  "7"    : boundFunction(FFqctt, SELF, "7") ,
  "8"    : boundFunction(FFqctt, SELF, "8") ,
  "9"    : boundFunction(FFqctt, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FF6Zc4, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFqctt(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVXaUF:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVXaUF + SELF.keyPressed + VVBPJz)
    txt = VVBPJz + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFmoBc(SELF, txt)
def FF6Zc4(SELF, tableObj, colNum):
 FFmoBc(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VVIAsB(i)
     break
 except:
  pass
def FFZqNe(SELF, setMenuAction=True):
 if setMenuAction:
  global VVWyR9
  VVWyR9 = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFkYLf():
 return ("  %s" % VVWyR9)
def FF9CgN(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFWesU(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FF03Jc(color):
 return parseColor(color).argb()
def FFaMdN(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFrlPO(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFFLw5(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FF8OuG(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVXaUF)
 else:
  return ""
def FF2l60(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVFkPZ, word, VVFkPZ, VVXaUF)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVFkPZ, word, VVFkPZ)
def FFtsFe(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVXaUF
def FFBpeU(color):
 if color: return "echo -e '%s' %s;" % (VVFkPZ, FF8OuG(VVFkPZ, VVgcU9))
 else : return "echo -e '%s';" % VVFkPZ
def FF82X1(title, color):
 title = "%s\n%s\n%s\n" % (VVFkPZ, title, VVFkPZ)
 return FFtsFe(title, color)
def FFH9Ay(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFUyOi(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFSYWA(callBackFunction):
 tCons = CCmDe5()
 tCons.ePopen("echo", boundFunction(FF4hCg, callBackFunction))
def FF4hCg(callBackFunction, result, retval):
 callBackFunction()
def FFb4DW(SELF, fnc, title="Processing ...", clearMsg=True):
 FFmoBc(SELF, title)
 tCons = CCmDe5()
 tCons.ePopen("echo", boundFunction(FFA88k, SELF, fnc, clearMsg))
def FFA88k(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFmoBc(SELF)
def FFlAoD(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVxcbV
  else       : return ""
def FFo68R(cmd):
 txt = FFlAoD(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFhOpk(cmd):
 lines = FFo68R(cmd)
 if lines: return lines[0]
 else : return ""
def FF2WA2(SELF, cmd):
 lines = FFo68R(cmd)
 VV3CuM = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VV3CuM.append((key, val))
  elif line:
   VV3CuM.append((line, ""))
 if VV3CuM:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFynj9(SELF, None, header=header, VVATVO=VV3CuM, VVeJNW=widths, VV4RrQ=28)
 else:
  FFcaNF(SELF, cmd)
def FFcaNF(    SELF, cmd, **kwargs): SELF.session.open(CCGGXr, VVV9xk=cmd, VVXJUc=True, VVsIwt=VVDQDA, **kwargs)
def FFLeXJ(  SELF, cmd, **kwargs): SELF.session.open(CCGGXr, VVV9xk=cmd, **kwargs)
def FFLfrr(   SELF, cmd, **kwargs): SELF.session.open(CCGGXr, VVV9xk=cmd, VVOEgC=True, VVWC9a=True, VVsIwt=VVDQDA, **kwargs)
def FFMB4s(  SELF, cmd, **kwargs): SELF.session.open(CCGGXr, VVV9xk=cmd, VVOEgC=True, VVWC9a=True, VVsIwt=VVlNJ6, **kwargs)
def FFSA5Q(  SELF, cmd, **kwargs): SELF.session.open(CCGGXr, VVV9xk=cmd, VVgFWw=True , **kwargs)
def FFamVv( SELF, cmd, **kwargs): SELF.session.open(CCGGXr, VVV9xk=cmd, VVVlNn=True   , **kwargs)
def FFnFy8( SELF, cmd, **kwargs): SELF.session.open(CCGGXr, VVV9xk=cmd, VVdzpq=True  , **kwargs)
def FFUJYt(cmd):
 return cmd + " > /dev/null 2>&1"
def FFTvuI():
 return " > /dev/null 2>&1"
def FFQiCi(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFN326(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FF4LBH():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFhOpk(cmd)
VVzrCb     = 0
VViyYs      = 1
VVHiEG   = 2
VVe7Ha      = 3
VVcOCF      = 4
VViIll     = 5
VVMxji     = 6
VVIxA6 = 7
VVeAw5 = 8
VVc2aH = 9
VVD21Q  = 10
VV402z     = 11
VVjBJk  = 12
VVrSTd  = 13
def FF5FY1(parmNum, grepTxt):
 if   parmNum == VVzrCb  : param = ["update"   , "dpkg update" ]
 elif parmNum == VViyYs   : param = ["list"   , "apt list" ]
 elif parmNum == VVHiEG: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FF4LBH()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFU7ig(parmNum, package):
 if   parmNum == VVe7Ha      : param = ["info"      , "apt show"         ]
 elif parmNum == VVcOCF      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VViIll     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVMxji     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVIxA6 : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVeAw5 : param = ["install --force-overwrite" , "dpkg -i --force-overwrite -y"    ]
 elif parmNum == VVc2aH : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVD21Q  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VV402z     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVjBJk  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVrSTd  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FF4LBH()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FF0OmY():
 result = FFhOpk("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFU7ig(VVMxji , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFUJYt("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFUJYt("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FF8OuG(failed1, VVgcU9))
   cmd += "  echo -e '%s' %s;"  % (failed2, FF8OuG(failed2, VVgcU9))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FF8OuG(failed3, VVe3tS))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FF13Wm(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFU7ig(VVMxji , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFUJYt("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FF8OuG(failed1, VVgcU9))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FF8OuG(failed2, VVe3tS))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FF9SAM(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFUJYt('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFUJYt("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFP7TV(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCAv2L.VVMxJo()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFK66c(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFP7TV(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFyCNw(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFmOde(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFP7TV(path, maxSize=maxSize, encLst=encLst)
  if lines: FFR6iW(SELF, lines, title=title, VVsIwt=VVDQDA)
  else : FF16em(SELF, path, title=title)
 else:
  FFTvTY(SELF, path, title)
def FFkCkL(SELF, path, title):
 if fileExists(path):
  txt = FFP7TV(path)
  txt = txt.replace("#W#", VVXaUF)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVBPJz)
  txt = txt.replace("#C#", VVzqsa)
  txt = txt.replace("#P#", VVValh)
  FFR6iW(SELF, txt, title=title)
 else:
  FFTvTY(SELF, path, title)
def FFCbgi(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFu1mf(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFADc6(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFMXkM(parent)
 else    : return FFhTBt(parent)
def FFmOde(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFMXkM(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFhTBt(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFZADQ():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVkxqr)
 paths.append(VVkxqr.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFu1mf(ba)
 for p in list:
  p = ba + p + VVkxqr
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VV4zs3, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVkxqr, VV4zs3 , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVopWG, VVe57v = FFZADQ()
def FFfN32():
 def VVottP(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 iPath = CFG.iptvHostsPath.getValue()
 if not iPath == VVRRQu and not pathExists(iPath):
  CFG.iptvHostsPath.setValue(VVRRQu)
  CFG.iptvHostsPath.save()
  oldIptvHostsPath = VVRRQu
 else:
  oldIptvHostsPath = ""
 oldMovieDownloadPath = VVottP(CFG.MovieDownloadPath, CCL4WW.VVfLiz())
 VVonyQ   = VVottP(CFG.backupPath, CCs4Ff.VVLcn8())
 VVgFgs   = VVottP(CFG.downloadedPackagesPath, t)
 VVFaNI  = VVottP(CFG.exportedTablesPath, t)
 VV4CmM  = VVottP(CFG.exportedPIconsPath, t)
 VVJl8L   = VVottP(CFG.packageOutputPath, t)
 global VVe6OI
 VVe6OI = FFMXkM(CFG.backupPath.getValue())
 if VVonyQ or VVJl8L or VVgFgs or VVFaNI or VV4CmM or oldIptvHostsPath or oldMovieDownloadPath:
  configfile.save()
 return VVonyQ, VVJl8L, VVgFgs, VVFaNI, VV4CmM, oldIptvHostsPath, oldMovieDownloadPath
def FFf1ps(path):
 path = FFhTBt(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFI6cr(SELF, pathList, tarFileName, addTimeStamp=True):
 VVATVO = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVATVO.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVATVO.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVATVO.append(path)
 if not VVATVO:
  FF3wnI(SELF, "Files not found!")
 elif not pathExists(VVe6OI):
  FF3wnI(SELF, "Path not found!\n\n%s" % VVe6OI)
 else:
  VVrszS = FFMXkM(VVe6OI)
  tarFileName = "%s%s" % (VVrszS, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFpkvp())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVATVO:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVFkPZ
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FF8OuG(tarFileName, VVAexn))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FF8OuG(failed, VVAexn))
  cmd += "fi;"
  cmd +=  sep
  FFLeXJ(SELF, cmd)
def FFb93v(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FF5IjG(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FF5IjG(SELF["keyInfo"], "info")
def FF5IjG(barObj, fName):
 path = "%s%s%s" % (VVe57v, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFIOvl(SELF, title, VVXmFj, showGrnMsg=""):
 SELF.session.open(boundFunction(CCcSGB, title=title, VVXmFj=VVXmFj, showGrnMsg=showGrnMsg))
def FFHLbC(labelObj, VVXmFj):
 if VVXmFj and fileExists(VVXmFj):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VV1TS8(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VV1TS8)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VVXmFj)
   return True
  except:
   pass
 return False
def FFhwVp(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFoAsb(satNum)
  return satName
def FFoAsb(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFfrDO(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFhwVp(val)
  else  : sat = FFoAsb(val)
 return sat
def FFhYTe(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFhwVp(num)
 except:
  pass
 return sat
def FFtGZT(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFsLKB(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFdS3Z(info, iServiceInformation.sServiceref)
   prov = FFdS3Z(info, iServiceInformation.sProvider)
   state = str(FFdS3Z(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FF6XlH(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FF0J40(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFdS3Z(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFYZPy(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFrAs1(refCode):
 info = FFZzEv(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FF4HUl(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFqcmy(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFZzEv(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VV8O7b = eServiceCenter.getInstance()
  if VV8O7b:
   info = VV8O7b.info(service)
 return info
def FFtcar(SELF, refCode, VVdsme=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  FFzyZu(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVdsme:
   FFTT8H(SELF, isFromSession)
 try:
  VVMZAe = InfoBar.instance
  if VVMZAe:
   VVXEzV = VVMZAe.servicelist
   if VVXEzV:
    servRef = eServiceReference(refCode)
    VVXEzV.saveChannel(servRef)
 except:
  pass
def FFzyZu(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCQOiM()
    if pr.VVFU1o(refCode, chName, decodedUrl, iptvRef):
     pr.VVg09H(SELF, isFromSession)
def FF6XlH(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFqt04(url): return any(x in url for x in ("/movie/", "/series/", "mode=vod", "mode=series"))
def FFMgGK(url)  : return any(x in url for x in ("/movie/", "mode=vod"))
def FFRiSY(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FF0J40(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFqMjA(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FF5Fv9(userBfile):
 txt = ""
 bFile = VVgmxK + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVgmxK + userBfile):
  fTxt = FFP7TV(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFhOpk('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
def FFqMjA(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FFNJUt(url):
 if iQuote : return iQuote(url)
 else  : return url
def FFwkTL(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FF27My(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFUFAB(txt):
 try:
  return FFwkTL(FF27My(txt)) == txt
 except:
  return False
def FFTT8H(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCkjHt, isFromExternal=isFromSession)
 else      : FF06Rj(session, reopen=True, isFromExternal=isFromSession)
def FF06Rj(session, reopen=False, isFromExternal=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FF06Rj, session, isFromExternal=isFromExternal), boundFunction(CCHLrq, isFromExternal=isFromExternal))
  except:
   try:
    FFWkkk(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFl5lx(refCode):
 tp = CCkhMr()
 if tp.VVK3df(refCode) : return True
 else        : return False
def FF2FUE(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFNMxM():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FFtsF4():
 VVMZAe = InfoBar.instance
 if VVMZAe:
  VVXEzV = VVMZAe.servicelist
  if VVXEzV:
   return VVXEzV.getBouquetList()
 return None
def FFovpB():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFOHyc():
 path = FFovpB()
 if path:
  txt = FFP7TV(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFD5dU():
 return FFMx0N(InfoBar.instance.servicelist.getRoot())
def FFMx0N(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VV8O7b = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VV8O7b.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FFgerI():
 VVL7qP = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVwz6m = list(VVL7qP)
 return VVwz6m, VVL7qP
def FFgSiE():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFTBVm(session, VVtt0Q):
 VVER8j, VVFO7w, VVimoL, camCommand = FFfRQz()
 if VVFO7w:
  runLog = False
  if   VVtt0Q == CCJ8Pw.VVrgUX : runLog = True
  elif VVtt0Q == CCJ8Pw.VVOwlb : runLog = True
  elif not VVimoL          : FFWkkk(session, message="SoftCam not started yet!")
  elif fileExists(VVimoL)        : runLog = True
  else             : FFWkkk(session, message="File not found !\n\n%s" % VVimoL)
  if runLog:
   session.open(boundFunction(CCJ8Pw, VVER8j=VVER8j, VVFO7w=VVFO7w, VVimoL=VVimoL, VVtt0Q=VVtt0Q))
 else:
  FFWkkk(session, message="No active OSCam/NCam found !", title="Live Log")
def FFfRQz():
 VVER8j = "/etc/tuxbox/config/"
 VVFO7w = None
 VVimoL  = None
 camCommand = FFhOpk("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVFO7w = "oscam"
 elif "ncam"  in camCommand : VVFO7w = "ncam"
 if VVFO7w:
  path = FFhOpk(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFMXkM(path)
  if pathExists(path):
   VVER8j = path
  tFile = VVER8j + VVFO7w + ".conf"
  tFile = FFhOpk("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVimoL = tFile
 return VVER8j, VVFO7w, VVimoL, camCommand
def FFlXfZ(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFNZmc():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFpkvp():
 return FFNZmc().replace(" ", "_").replace("-", "").replace(":", "")
def FFZEiA(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFD3g6():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFd8ee(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCNFtw.VVH2YO(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCNFtw.VVEkpK_forBouquet(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFUJYt("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFwMj8(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFQbFg(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
VV29Jx = 0
def FFNYRG():
 global VV29Jx
 VV29Jx = iTime()
def FFXXUT():
 FFiqB1(">>>>>> Elapsed\t: {:.6f} seconds".format(iTime() - VV29Jx).rstrip("0").rstrip("."))
def FFi9RU(SELF, message, title=""):
 SELF.session.open(boundFunction(CCeZgx, title=title, message=message, VVqTIr=True))
def FFR6iW(SELF, message, title="", VVsIwt=VVDQDA, **kwargs):
 SELF.session.open(boundFunction(CCeZgx, title=title, message=message, VVsIwt=VVsIwt, **kwargs))
def FF3wnI(SELF, message, title="")  : FFWkkk(SELF.session, message, title)
def FFTvTY(SELF, path, title="") : FFWkkk(SELF.session, "File not found !\n\n%s" % path, title)
def FF16em(SELF, path, title="") : FFWkkk(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFdiGu(SELF, title="")  : FFWkkk(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFWkkk(session, message, title="") : session.open(boundFunction(CCWr24, title=title, message=message))
def FFaNVN(SELF, VVtktQ, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVtktQ, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVtktQ, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVtktQ, boundFunction(CC7aa4, title=title, message=message, VVtkVj=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FF3wnI(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFysO2(SELF, callBack_Yes, VVLGGV, callBack_No=None, title="", VVESi4=False, VVZRHB=True):
 SELF.session.openWithCallback(boundFunction(FFvysc, callBack_Yes, callBack_No)
        , boundFunction(CCz9tz, title=title, VVLGGV=VVLGGV, VVZRHB=VVZRHB, VVESi4=VVESi4))
def FFvysc(callBack_Yes, callBack_No, FFysO2ed):
 if FFysO2ed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFmoBc(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFrlPO(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FF2i8Y(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFytTf(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VV1LIR = eTimer()
def FF2i8Y(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFzcGK, SELF))
 fnc = boundFunction(FFzcGK, SELF)
 try:
  t = VV1LIR.timeout.connect(fnc)
 except:
  VV1LIR.callback.append(fnc)
 VV1LIR.start(milliSeconds, 1)
def FFzcGK(SELF):
 VV1LIR.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFynj9(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCOxzY, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCOxzY, **kwargs))
  FF5ZRH(win)
  return win
 except:
  return None
def FFUdxd(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCbIsi, **kwargs))
 FF5ZRH(win)
 return win
def FFt65h(SELF, **kwargs):
 SELF.session.open(CCc6Hf, **kwargs)
def FF1rm3(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFZHDY(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVIbI9, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFq9fK(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFZHDY(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFGpXP():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFrcge(VV4RrQ):
 screenSize  = FFGpXP()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VV4RrQ)
 return bodyFontSize
def FFtdej(VV4RrQ, extraSpace):
 font = gFont(VVIbI9, VV4RrQ)
 VVAa0V = fontRenderClass.getInstance().getLineHeight(font) or (VV4RrQ * 1.25)
 return int(VVAa0V + VVAa0V * extraSpace)
def FFhdcK(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFGpXP()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVIbI9, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFtdej(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVIbI9, titleFontSize, alignLeftCenter)
 if winType == VVDXvw or winType == VVxZpK:
  if winType == VVxZpK : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVx4P1:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == WINDOW_SUBTITLE:
  lineH = int((height - 8) / 3.0)
  top = 2
  tmp += '<widget name="mySubtFr" position="0,0" size="%d,%d" zPosition="10" backgroundColor="#00FFFF00" />' % (width, height)
  for i in range(3):
   tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="11" foregroundColor="#ffffff" shadowColor="#555555" shadowOffset="-2,-2" backgroundColor="#ff000000" %s %s />' % (i, top + 2, width - 2, lineH - 2, bodyFontStr, alignCenter)
   top += lineH
 elif winType == VV1aAd:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FFi9RUL = b2Left2 + timeW + marginLeft
  FFi9RUW = b2Left3 - marginLeft - FFi9RUL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FFi9RUL  , b2Top, FFi9RUW , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
 elif winType == VVpRAs:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVyofO:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VV2ztI:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VV19tE:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVIbI9, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVIbI9, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVIrXs:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFi9RUH = int(bodyH * 0.5)
  inpTop = bodyTop + FFi9RUH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFi9RUH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVIbI9, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVIbI9, mapF, alignCenter)
 elif winType == VVsdkx:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VV9gk8:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVIbI9, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVLvRB:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVIbI9, fontH, alignCenter)
 elif winType == VV9biv:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVIbI9, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVIbI9, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVIbI9, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVLluH:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 else:
  if   winType == VV9U6R : align = alignLeftCenter
  elif winType == VVCTjl : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVYI3s:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VVOhNa:
   moreParams = ""
  else:
   fontName = VVIbI9
   if usefixedFont and winType == VVCTjl:
    fnt = "Fixed"
    if fnt in FFMsxt():
     fontName = "Fixed"
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VV4RrQ = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVIbI9, VV4RrQ, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVLubA = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVIbI9, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVLubA[i], VVIbI9, barFont, alignCenter)
   left += btnW + gap
 if winType == VVCTjl:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVLubA = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVLubA[i], VVIbI9, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhdcK(VVDXvw, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.VVh1OL = ""
  self.themsList  = []
  VV64WM = []
  if VV0xHB:
   VV64WM.append(("-- MY TEST --"    , "myTest"   ))
  VV64WM.append(("  File Manager"     , "FileManager"  ))
  VV64WM.append(VVB35E)
  VV64WM.append(("  Services/Channels"    , "ChannelsTools" ))
  VV64WM.append(("  IPTV"       , "IptvTools"  ))
  VV64WM.append(("  PIcons"       , "PIconsTools"  ))
  VV64WM.append(("  SoftCam"      , "SoftCam"   ))
  VV64WM.append(VVB35E)
  VV64WM.append(("  Plugins"      , "PluginsTools" ))
  VV64WM.append(("  Terminal"      , "Terminal"  ))
  VV64WM.append(("  Backup & Restore"    , "BackupRestore" ))
  VV64WM.append(VVB35E)
  VV64WM.append(("  Date/Time"      , "Date_Time"  ))
  VV64WM.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VV64WM)
  FFFgql(self, VV64WM=VV64WM)
  FF9CgN(self["keyRed"] , "Exit")
  FF9CgN(self["keyGreen"] , "Settings")
  FF9CgN(self["keyYellow"], "Dev. Info.")
  FF9CgN(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVCV9o       ,
   "yellow"  : self.VV8JMJ       ,
   "blue"   : self.VVdwHL       ,
   "info"   : self.VVdwHL       ,
   "next"   : self.VVCwqP       ,
   "menu"   : self.VVmqWC     ,
   "text"   : self.VVH4dH      ,
   "0"    : boundFunction(self.VVm4UK, 0) ,
   "1"    : boundFunction(self.VVxfNt, 1)   ,
   "2"    : boundFunction(self.VVxfNt, 2)   ,
   "3"    : boundFunction(self.VVxfNt, 3)   ,
   "4"    : boundFunction(self.VVxfNt, 4)   ,
   "5"    : boundFunction(self.VVxfNt, 5)   ,
   "6"    : boundFunction(self.VVxfNt, 6)   ,
   "7"    : boundFunction(self.VVxfNt, 7)   ,
   "8"    : boundFunction(self.VVxfNt, 8)   ,
   "9"    : boundFunction(self.VVxfNt, 9)
  })
  self.onShown.append(self.VV82q3)
  self.onClose.append(self.onExit)
  global VVj3zx, VVioJp, VVsWxe
  VVj3zx = VVioJp = VVsWxe = False
 def VVhHBt(self):
  item = FFZqNe(self)
  self.VVxfNt(item)
 def VVxfNt(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVKfWa()
   elif item in ("FileManager"  , 1) : self.session.open(CCN0r2)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCs1x9)
   elif item in ("IptvTools"  , 3) : self.session.open(CCNFtw)
   elif item in ("PIconsTools"  , 4) : self.VVfDyo()
   elif item in ("SoftCam"   , 5) : self.session.open(CC8RLw)
   elif item in ("PluginsTools" , 6) : self.session.open(CCJYXQ)
   elif item in ("Terminal"  , 7) : self.session.open(CC1Gfu)
   elif item in ("BackupRestore" , 8) : self.session.open(CCON82)
   elif item in ("Date_Time"  , 9) : self.session.open(CCcGBJ)
   elif item in ("CheckInternet" , 10) : self.session.open(CCgaZk)
   else         : self.close()
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FFH9Ay(self["myMenu"])
  FFq9fK(self)
  FF1rm3(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVdDje)
  self["myTitle"].setText(title)
  VVonyQ, VVJl8L, VVgFgs, VVFaNI, VV4CmM, oldIptvHostsPath, oldMovieDownloadPath = FFfN32()
  self.VVjqVD()
  if VVonyQ or VVJl8L or VVgFgs or VVFaNI or VV4CmM or oldIptvHostsPath or oldMovieDownloadPath:
   VVABtc = lambda path, subj: "%s:\n%s\n\n" % (subj, FFtsFe(path, VVe3tS)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVABtc(oldIptvHostsPath  , "IPTV Hosts Files Path"   )
   txt += VVABtc(VVonyQ   , "Backup/Restore Path"    )
   txt += VVABtc(VVJl8L  , "Created Package Files (IPK/DEB)" )
   txt += VVABtc(VVgFgs  , "Download Packages (from feeds)" )
   txt += VVABtc(VVFaNI , "Exported Tables"     )
   txt += VVABtc(VV4CmM , "Exported PIcons"     )
   txt += VVABtc(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFR6iW(self, txt, title="Settings Paths")
  if (EASY_MODE or VVLddi or VV0xHB):
   FFrlPO(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFmoBc(self, "Welcome", 300)
  FFSYWA(boundFunction(self.VVbTjL, title))
 def VVbTjL(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCs4Ff.VVEVdZ()
   if url:
    newWebVer = CCs4Ff.VVkW7Y(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFUJYt("rm /tmp/ajpanel*"))
  global VVj3zx, VVioJp, VVsWxe
  VVj3zx = VVioJp = VVsWxe = False
 def VVm4UK(self, digit):
  self.VVh1OL += str(digit)
  ln = len(self.VVh1OL)
  global VVj3zx, VVsWxe
  if ln == 4:
   if self.VVh1OL == "0" * ln:
    VVj3zx = True
    FFrlPO(self["myTitle"], "#800080")
   else:
    self.VVh1OL = "x"
  elif self.VVh1OL == "0" * 8:
   VVsWxe = True
 def VVCwqP(self):
  self.VVh1OL += ">"
  if self.VVh1OL == "0" * 4 + ">" * 2:
   global VVioJp
   VVioJp = True
   FFrlPO(self["myTitle"], "#dd5588")
 def VVH4dH(self):
  if self.VVh1OL == "0" * 4:
   ok = False
   fnt = "ae_AlMateen.ttf"
   fontFile = "/usr/share/fonts/%s" % fnt
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    try:
     addFont(fontFile, fontName, 100, True)
     ok = True
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      ok = True
     except:
      pass
   if ok: txt = 'Added Font: "%s"' % fnt
   else : txt = '"%s" Not Found' % fnt
   FFmoBc(self, txt, 2000, isGrn=ok)
 def VVfDyo(self):
  found = False
  pPath = CC7Ld1.VVeUbw()
  if pathExists(pPath):
   for fName, fType in CC7Ld1.VVbvMz(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CC7Ld1)
  else:
   VV64WM = []
   VV64WM.append(("PIcons Manager" , "CC7Ld1" ))
   VV64WM.append(VVB35E)
   VV64WM.append(CC7Ld1.VVutpE())
   VV64WM.append(VVB35E)
   VV64WM += CC7Ld1.VVOngF()
   FFUdxd(self, self.VVrECc, VV64WM=VV64WM)
 def VVrECc(self, item=None):
  if item:
   if   item == "CC7Ld1"   : self.session.open(CC7Ld1)
   elif item == "VVeQps"  : CC7Ld1.VVeQps(self)
   elif item == "VVgU1I"  : CC7Ld1.VVgU1I(self)
   elif item == "findPiconBrokenSymLinks" : CC7Ld1.VVuT6G(self, True)
   elif item == "FindAllBrokenSymLinks" : CC7Ld1.VVuT6G(self, False)
 def VVCV9o(self):
  self.session.open(CCs4Ff)
 def VV8JMJ(self):
  self.session.open(CC2u4W)
 def VVdwHL(self):
  changeLogFile = VVe57v + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FFK66c(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFtsFe("\n%s\n%s\n%s" % (VVFkPZ, line, VVFkPZ), VVValh, VVXaUF)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FFtsFe(line, VVBPJz, VVXaUF)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFR6iW(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVdDje), VV4RrQ=26)
 def VVmqWC(self):
  VV64WM = []
  VV64WM.append(("Title Colors"   , "title" ))
  VV64WM.append(("Menu Area Colors"  , "body" ))
  VV64WM.append(("Menu Pointer Colors" , "cursor" ))
  VV64WM.append(("Bottom Bar Colors" , "bar"  ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Reset Colors"   , "reset" ))
  title = "Main Menu Colors"
  FFUdxd(self, boundFunction(self.VV8a5E, title), VV64WM=VV64WM, width=500, title=title)
 def VV8a5E(self, title, item=None):
  if item:
   if item == "reset":
    FFysO2(self, self.VVKrlQ, "Reset to default colors ?", title=title)
   else:
    tDict = self.VVEubC()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VVYCDe, tDict, item), CC429m, defFG=fg, defBG=bg)
 def VVPqvc(self):
  return VVe6OI + "ajpanel_colors"
 def VVEubC(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVPqvc()
  if fileExists(p):
   txt = FFP7TV(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVYCDe(self, tDict, item, fg, bg):
  if fg:
   self.VVhVlJ(item, fg)
   self.VV44Au(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVWaWv(tDict)
 def VVWaWv(self, tDict):
   p = self.VVPqvc()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVhVlJ(self, item, fg):
  if   item == "title" : FFaMdN(self["myTitle"], fg)
  elif item == "body"  :
   FFaMdN(self["myMenu"], fg)
   FFaMdN(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFrlPO(self["myBar"], fg)
   FFaMdN(self["keyRed"], fg)
   FFaMdN(self["keyGreen"], fg)
   FFaMdN(self["keyYellow"], fg)
   FFaMdN(self["keyBlue"], fg)
 def VV44Au(self, item, bg):
  if   item == "title" : FFrlPO(self["myTitle"], bg)
  elif item == "body"  :
   FFrlPO(self["myMenu"], bg)
   FFrlPO(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFrlPO(self["myBar"], bg)
 def VVKrlQ(self):
  os.system(FFUJYt("rm %s" % self.VVPqvc()))
  self.close()
 def VVjqVD(self):
  tDict = self.VVEubC()
  self.VVnTTg(tDict, "title")
  self.VVnTTg(tDict, "body")
  self.VVnTTg(tDict, "cursor")
  self.VVnTTg(tDict, "bar")
 def VVnTTg(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVhVlJ(name, fg)
  if bg: self.VV44Au(name, bg)
 def VVKfWa(self):
  FFTT8H(self)
class CCAv2L():
 @staticmethod
 def VVMxJo():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVELBh(isApply=False):
  global VVSeco, VVrM79
  VVSeco  = True
  VVrM79 = CCAv2L.VVDOM0()
  CCAv2L.VVHLM5()
 @staticmethod
 def VVHLM5():
  if VVrM79:
   global VVSeco
   if CFG.forceUtf8Encoding.getValue():
    if CCAv2L.VVnlJU() : VVSeco = True
    else        : VVSeco = False
   else:
    CCAv2L.VVP6t4()
    VVSeco = False
 @staticmethod
 def VVDOM0(isApply=False):
  from sys import version_info
  if version_info[0] >= 3 and version_info[1] >= 10:
   path = "/etc/issue"
   if fileExists(path):
    path = "/etc/issue"
    if fileExists(path):
     txt = FFP7TV(path)
     span = iSearch(r"open.?vision", txt, IGNORECASE)
     if span:
      return True
  return False
 @staticmethod
 def VVnlJU():
  import locale
  enc = locale.getdefaultlocale()[1]
  span = iSearch(r"UTF.?8", enc, IGNORECASE)
  if not span:
   try:
    import locale
    return locale.setlocale(locale.LC_ALL, "en_GB.UTF-8")
   except:
    pass
  return None
 @staticmethod
 def VVP6t4():
  try:
   import locale
   return locale.setlocale(locale.LC_ALL, "")
  except:
   return None
 @staticmethod
 def VVk4R4(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFynj9(SELF, None, VVATVO=lst, VV4RrQ=30, VVQvC9=True)
 @staticmethod
 def VVpb9U(path, SELF=None):
  for enc in CCAv2L.VVMxJo():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FF3wnI(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VV6idB(SELF, path, cbFnc, defEnc="", pos=0):
  FFmoBc(SELF)
  lst = CCAv2L.VVp3Zn(path)
  if lst:
   VV64WM = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if defEnc == enc:
     txt = FFtsFe(txt, VVAexn)
    VV64WM.append((txt, enc))
   win = FFUdxd(SELF, cbFnc, title="Select Encoding", VV64WM=VV64WM, width=900, height=500 if pos == 1 else 0)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FFmoBc(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVp3Zn(path):
  encLst = []
  cPath = VVe57v + "codecs"
  if fileExists(cPath):
   lines = FFK66c(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCAv2L.VVMxJo())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    try:
     with ioOpen(path, "r", encoding=enc) as f:
      for line in f:
       pass
     lst.append((item[0], enc))
    except:
     pass
  return lst
class CC2u4W(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhdcK(VVDXvw, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VV64WM = []
  VV64WM.append(("Settings File"        , "SettingsFile"   ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Box Info"          , "VVrtuZ"    ))
  VV64WM.append(("Tuners Info"         , "VVTjDi"   ))
  VV64WM.append(("Python Version"        , "VVt1Cu"   ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Screen Size"         , "ScreenSize"    ))
  VV64WM.append(("Language/Locale"        , "Locale"     ))
  VV64WM.append(("Processor"         , "Processor"    ))
  VV64WM.append(("Operating System"        , "OperatingSystem"   ))
  VV64WM.append(("Drivers"          , "drivers"     ))
  VV64WM.append(VVB35E)
  VV64WM.append(("System Users"         , "SystemUsers"    ))
  VV64WM.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VV64WM.append(("Uptime"          , "Uptime"     ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Host Name"         , "HostName"    ))
  VV64WM.append(("MAC Address"         , "MACAddress"    ))
  VV64WM.append(("Network Configuration"      , "NetworkConfiguration" ))
  VV64WM.append(("Network Status"        , "NetworkStatus"   ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Disk Usage"         , "VVtukW"    ))
  VV64WM.append(("Mount Points"         , "MountPoints"    ))
  VV64WM.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VV64WM.append(("USB Devices"         , "USB_Devices"    ))
  VV64WM.append(("List Block-Devices"       , "listBlockDevices"  ))
  VV64WM.append(("Directory Size"        , "DirectorySize"   ))
  VV64WM.append(("Memory"          , "Memory"     ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VV64WM.append(("Running Processes"       , "RunningProcesses"  ))
  VV64WM.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFFgql(self, VV64WM=VV64WM, title="Device Information")
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FFH9Ay(self["myMenu"])
  FFq9fK(self)
 def VVhHBt(self):
  global VVWyR9
  VVWyR9 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCGzUN)
   elif item == "VVrtuZ"    : self.VVrtuZ()
   elif item == "VVTjDi"   : self.VVTjDi()
   elif item == "VVt1Cu"   : self.VVt1Cu()
   elif item == "ScreenSize"    : FFR6iW(self, "Width\t: %s\nHeight\t: %s" % (FFGpXP()[0], FFGpXP()[1]))
   elif item == "Locale"     : CCAv2L.VVk4R4(self)
   elif item == "Processor"    : self.VVxS11()
   elif item == "OperatingSystem"   : FFcaNF(self, "uname -a"        )
   elif item == "drivers"     : self.VVcDhL()
   elif item == "SystemUsers"    : FFcaNF(self, "id"          )
   elif item == "LoggedInUsers"   : FFcaNF(self, "who -a"         )
   elif item == "Uptime"     : FFcaNF(self, "uptime"         )
   elif item == "HostName"     : FFcaNF(self, "hostname"        )
   elif item == "MACAddress"    : self.VVpV9u()
   elif item == "NetworkConfiguration"  : FFcaNF(self, "ifconfig %s %s" % (FF8OuG("HWaddr", VVeyOS), FF8OuG("addr:", VVgcU9)))
   elif item == "NetworkStatus"   : FFcaNF(self, "netstat -tulpn"       )
   elif item == "VVtukW"    : self.VVtukW()
   elif item == "MountPoints"    : FFcaNF(self, "mount %s" % (FF8OuG(" on ", VVgcU9)))
   elif item == "FileSystemTable"   : FFcaNF(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFcaNF(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFcaNF(self, "blkid"         )
   elif item == "DirectorySize"   : FFcaNF(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVWn0a="Reading size ...")
   elif item == "Memory"     : FFcaNF(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVMq2N()
   elif item == "RunningProcesses"   : FFcaNF(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFcaNF(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVNolH()
   else         : self.close()
 def VVpV9u(self):
  res = FFlAoD("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFR6iW(self, txt)
  else:
   FFcaNF(self, "ip link")
 def VVQHrP(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFo68R(cmd)
  return lines
 def VVJmBw(self, lines, headerRepl, widths, VVnesb):
  VV3CuM = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VV3CuM.append(parts)
  if VV3CuM and len(header) == len(widths):
   VV3CuM.sort(key=lambda x: x[0].lower())
   FFynj9(self, None, header=header, VVATVO=VV3CuM, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=28, VVQvC9=True)
   return True
  else:
   return False
 def VVtukW(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VVQHrP(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVnesb = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVJmBw(lines, headerRepl, widths, VVnesb)
  if not allOK:
   lines = FFo68R(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFhTBt(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVAexn:
     note = "\n%s" % FFtsFe("Green = Mounted Partitions", VVAexn)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVgcU9
     elif line.endswith(mountList) : color = VVAexn
     else       : color = VVBPJz
     txt += FFtsFe(line, color) + "\n"
    FFR6iW(self, txt + note)
   else:
    FF3wnI(self, "Not data from system !")
 def VVMq2N(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVQHrP(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVnesb = (LEFT , CENTER, LEFT )
  allOK = self.VVJmBw(lines, headerRepl, widths, VVnesb)
  if not allOK:
   FFcaNF(self, cmd)
 def VVcDhL(self):
  cmd = FF5FY1(VVHiEG, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFcaNF(self, cmd)
  else : FFdiGu(self)
 def VVxS11(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFcaNF(self, cmd)
 def VVNolH(self):
  cmd = FF5FY1(VViyYs, "| grep secondstage")
  if cmd : FFcaNF(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFdiGu(self)
 def VVrtuZ(self):
  c = VVAexn
  VVATVO = []
  VVATVO.append((FFtsFe("Box Type"  , c), FFtsFe(self.VVwF2A("boxtype").upper(), c)))
  VVATVO.append((FFtsFe("Board Version", c), FFtsFe(self.VVwF2A("board_revision") , c)))
  VVATVO.append((FFtsFe("Chipset"  , c), FFtsFe(self.VVwF2A("chipset")  , c)))
  VVATVO.append((FFtsFe("S/N"   , c), FFtsFe(self.VVwF2A("sn")    , c)))
  VVATVO.append((FFtsFe("Version"  , c), FFtsFe(self.VVwF2A("version")  , c)))
  VVJLC0   = []
  VVFMKP = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVFMKP = SystemInfo[key]
     else:
      VVJLC0.append((FFtsFe(str(key), VVzqsa), FFtsFe(str(SystemInfo[key]), VVzqsa)))
  except:
   pass
  if VVFMKP:
   VVn8db = self.VV7AS1(VVFMKP)
   if VVn8db:
    VVn8db.sort(key=lambda x: x[0].lower())
    VVATVO += VVn8db
  if VVJLC0:
   VVJLC0.sort(key=lambda x: x[0].lower())
   VVATVO += VVJLC0
  if VVATVO:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFynj9(self, None, header=header, VVATVO=VVATVO, VVeJNW=widths, VV4RrQ=28, VVQvC9=True)
  else:
   FFR6iW(self, "Could not read info!")
 def VVwF2A(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFK66c(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VV7AS1(self, mbDict):
  try:
   mbList = list(mbDict)
   VVATVO = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVATVO.append((FFtsFe(subject, VVgcU9), FFtsFe(value, VVgcU9)))
  except:
   pass
  return VVATVO
 def VVTjDi(self):
  txt = self.VV5BPM("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VV5BPM("/proc/bus/nim_sockets")
  if not txt: txt = self.VVBui9()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFR6iW(self, txt)
 def VVBui9(self):
  txt = ""
  VVABtc = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVABtc("Slot Name" , slot.getSlotName())
     txt += FFtsFe(slotName, VVgcU9)
     txt += VVABtc("Description"  , slot.getFullDescription())
     txt += VVABtc("Frontend ID"  , slot.frontend_id)
     txt += VVABtc("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VV5BPM(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFK66c(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFtsFe(line, VVgcU9)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVt1Cu(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFR6iW(self, txt)
class CCGzUN(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhdcK(VVDXvw, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VV64WM = []
  VV64WM.append(("Settings (All)"   , "Settings_All"   ))
  VV64WM.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  if VVioJp:
   VV64WM.append(("Settings (FHDG-17)" , "Settings_FHDG_17"  ))
  VV64WM.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VV64WM.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VV64WM.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VV64WM.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VV64WM.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFFgql(self, VV64WM=VV64WM)
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FFH9Ay(self["myMenu"])
  FFq9fK(self)
 def VVhHBt(self):
  global VVWyR9
  VVWyR9 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFcaNF(self, cmd                )
   elif item == "Settings_HotKeys"   : FFcaNF(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFcaNF(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFcaNF(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFcaNF(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFcaNF(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFcaNF(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFcaNF(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CC8RLw(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhdcK(VVDXvw, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVER8j, VVFO7w, VVimoL, camCommand = FFfRQz()
  self.VVFO7w = VVFO7w
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VV64WM = []
  VV64WM.append(("OSCam Files"        , "OSCamFiles"  ))
  VV64WM.append(("NCam Files"        , "NCamFiles"  ))
  VV64WM.append(("CCcam Files"        , "CCcamFiles"  ))
  VV64WM.append(VVB35E)
  VV64WM.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VV64WM.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VV64WM.append(VVB35E)
  if VVFO7w:
   if   "oscam" in VVFO7w : camName = "OSCam"
   elif "ncam"  in VVFO7w : camName = "NCam"
   VV64WM.append((camName + " Info."      , "camInfo"   ))
   VV64WM.append((camName + " Live Status"    , "camLiveStatus" ))
   VV64WM.append((camName + " Live Readers"    , "camLiveReaders" ))
   VV64WM.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VV64WM.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFFgql(self, VV64WM=VV64WM)
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FFH9Ay(self["myMenu"])
  FFq9fK(self)
 def VVhHBt(self):
  global VVWyR9
  VVWyR9 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCiGD7, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCiGD7, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCiGD7, "cccam"))
   elif item == "OSCamReaders"  : self.VV1oVk("os")
   elif item == "NSCamReaders"  : self.VV1oVk("n")
   elif item == "camInfo"   : FF2WA2(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFTBVm(self.session, CCJ8Pw.VVrgUX)
   elif item == "camLiveReaders" : FFTBVm(self.session, CCJ8Pw.VVOwlb)
   elif item == "camLiveLog"  : FFTBVm(self.session, CCJ8Pw.VV8CnV)
   else       : self.close()
 def VV1oVk(self, camPrefix):
  VV3CuM = self.VVHHrl(camPrefix)
  if VV3CuM:
   VV3CuM.sort(key=lambda x: int(x[0]))
   if self.VVFO7w and self.VVFO7w.startswith(camPrefix):
    VVVDdh = ("Toggle State", self.VVfXTi, [camPrefix], "Changing State ...")
   else:
    VVVDdh = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVnesb  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFynj9(self, None, header=header, VVATVO=VV3CuM, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=26, VVVDdh=VVVDdh, VVzmtH=True)
 def VVHHrl(self, camPrefix):
  readersFile = self.VVER8j + camPrefix + "cam.server"
  VV3CuM = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFK66c(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VV3CuM.append((str(len(VV3CuM) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VV3CuM:
    FF3wnI(self, "No readers found !")
  else:
   FFTvTY(self, readersFile)
  return VV3CuM
 def VVfXTi(self, VVMB3d, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVER8j, camPrefix)
  readerState  = VVMB3d.VVits3(1)
  readerLabel  = VVMB3d.VVits3(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CC8RLw.VVcBOa(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVMB3d.VVIZWg()
    FF3wnI(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VV3CuM = self.VVHHrl(camPrefix)
   if VV3CuM:
    VVMB3d.VVr5NB(VV3CuM)
 @staticmethod
 def VVcBOa(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFK66c(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FF3wnI(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FF3wnI(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFTvTY(SELF, confFile)
   return None
  if not iRequest:
   FF3wnI(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FF3wnI(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FF3wnI(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCiGD7(Screen):
 def __init__(self, VV3g2s, session, args=0):
  self.skin, self.skinParam = FFhdcK(VVDXvw, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVER8j, VVFO7w, VVimoL, camCommand = FFfRQz()
  if   VV3g2s == "ncam" : self.prefix = "n"
  elif VV3g2s == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VV64WM = []
  if self.prefix == "":
   VV64WM.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VV64WM.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VV64WM.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VV64WM.append(("constant.cw"         , "x_constant_cw" ))
   VV64WM.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VV64WM.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VV64WM.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VV64WM.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VV64WM.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VV64WM.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VV64WM.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VV64WM.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VV64WM.append(VVB35E)
   VV64WM.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VV64WM.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VV64WM.append(VVB35E)
   VV64WM.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VV64WM.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VV64WM.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFFgql(self, VV64WM=VV64WM)
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FFH9Ay(self["myMenu"])
  FFq9fK(self)
 def VVhHBt(self):
  global VVWyR9
  VVWyR9 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFyCNw(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFyCNw(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFyCNw(self, self.VVER8j + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFyCNw(self, self.VVER8j + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVh4ts("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVh4ts("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVh4ts("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVh4ts("cam.provid"        )
   elif item == "x_cam_server"  : self.VVh4ts("cam.server"        )
   elif item == "x_cam_services" : self.VVh4ts("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVh4ts("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVh4ts("cam.user"        )
   elif item == "x_VVFkPZ"   : pass
   elif item == "x_SoftCam_Key" : self.VV4OgH()
   elif item == "x_CCcam_cfg"  : FFyCNw(self, self.VVER8j + "CCcam.cfg"    )
   elif item == "x_VVFkPZ"   : pass
   elif item == "x_cam_log"  : FFyCNw(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFyCNw(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFyCNw(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVh4ts(self, fileName):
  FFyCNw(self, self.VVER8j + self.prefix + fileName)
 def VV4OgH(self):
  path = self.VVER8j + "SoftCam.Key"
  if fileExists(path) : FFyCNw(self, path)
  else    : FFyCNw(self, path.replace(".Key", ".key"))
class CCJ8Pw(Screen):
 VVrgUX  = 0
 VVOwlb = 1
 VV8CnV = 2
 def __init__(self, session, VVER8j="", VVFO7w="", VVimoL="", VVtt0Q=VVrgUX):
  self.skin, self.skinParam = FFhdcK(VVCTjl, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVimoL   = VVimoL
  self.VVtt0Q  = VVtt0Q
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVER8j + VVFO7w + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVFO7w : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVER8j, self.camPrefix)
  if self.VVtt0Q == self.VVrgUX:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVtt0Q == self.VVOwlb:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFFgql(self, self.Title, addScrollLabel=True)
  FF9CgN(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVVQIz
  self.onShown.append(self.VV82q3)
  self.onClose.append(self.onExit)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  self["myLabel"].VVdsWe(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FF1rm3(self)
  self.VVVQIz()
 def onExit(self):
  self.timer.stop()
 def VVDss5(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVxSEY)
  except:
   self.timer.callback.append(self.VVxSEY)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFmoBc(self, "Started", 1000)
 def VVVfvF(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVxSEY)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFmoBc(self, "Stopped", 1000)
 def VVVQIz(self):
  if self.timerRunning:
   self.VVVfvF()
  else:
   self.VVDss5()
   if self.VVtt0Q == self.VVrgUX or self.VVtt0Q == self.VVOwlb:
    if self.VVtt0Q == self.VVrgUX : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CC8RLw.VVcBOa(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFSYWA(self.VVlmAN)
    else:
     self.close()
   else:
    self.VVHEWX()
 def VVxSEY(self):
  if self.timerRunning:
   if   self.VVtt0Q == self.VVrgUX : self.VVGWL4()
   elif self.VVtt0Q == self.VVOwlb : self.VVGWL4()
   else            : self.VVHEWX()
 def VVHEWX(self):
  if fileExists(self.VVimoL):
   fTime = FFlXfZ(os.path.getmtime(self.VVimoL))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VV2SP3(), VVsIwt=VVlNJ6)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVimoL)
 def VVlmAN(self):
  self.VVGWL4()
 def VVGWL4(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFtsFe("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVValh))
   self.camWebIfErrorFound = True
   self.VVVfvF()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVtt0Q == self.VVrgUX : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFtsFe("Error while parsing data elements !\n\nError = %s" % str(e), VVe3tS)
   self.camWebIfErrorFound = True
   self.VVVfvF()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVIFfS(root)
  self["myLabel"].setText(txt, VVsIwt=VVlNJ6)
  self["myBar"].setText("Last Update : %s" % FFNZmc())
 def VVIFfS(self, rootElement):
  def VVABtc(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVtt0Q == self.VVrgUX:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFtsFe(status, VVAexn)
    else          : status = FFtsFe(status, VVe3tS)
    txt += VVFkPZ + "\n"
    txt += VVABtc("Name"  , name)
    txt += VVABtc("Description" , desc)
    txt += VVABtc("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVABtc("Protocol" , protocol)
    txt += VVABtc("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFtsFe("Yes", VVAexn)
    else    : enabTxt = FFtsFe("No", VVe3tS)
    txt += VVFkPZ + "\n"
    txt += VVABtc("Label"  , label)
    txt += VVABtc("Protocol" , protocol)
    txt += VVABtc("Enabled" , enabTxt)
  return txt
 def VV2SP3(self):
  wordsDict = self.VVSjd3()
  color = [ VVgcU9, VVeyOS, VVAexn, VVe3tS, VVzqsa, VVcBCb]
  lines = FFo68R("tail -n %d %s" % (100, self.VVimoL))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVValh + line[:19] + VVBPJz + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVXaUF + line[ndx + 3:] + VVBPJz
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVgcU9 + line[ndx + 8 : ndx1 + 4] + VVBPJz + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVBPJz)
   elif line.startswith("----") or ">>" in line:
    line = FFtsFe(line, VVgcU9)
   txt += line + "\n"
  return txt
 def VVSjd3(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFK66c(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCON82(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhdcK(VVDXvw, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VV64WM = []
  VV64WM.append(("Backup Channels"    , "VVdNge"   ))
  VV64WM.append(("Restore Channels"    , "Restore_Channels"  ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Backup SoftCAM Files"   , "VVI79Z" ))
  VV64WM.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VV64WM.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VV64WM.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Backup Network Settings"  , "VVCy5X"   ))
  VV64WM.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVioJp:
   VV64WM.append(VVB35E)
   VV64WM.append((VVValh + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VV7WRS"   ))
   VV64WM.append((VVAexn + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVUrQZ) , "createMyIpk"   ))
   VV64WM.append((VVAexn + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVUrQZ) , "createMyDeb"   ))
   VV64WM.append((VVzqsa + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VV64WM.append((VVzqsa + "Decode %s Crash Report"   % PLUGIN_NAME     , "VV56XY" ))
  FFFgql(self, VV64WM=VV64WM)
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FFH9Ay(self["myMenu"])
  FFq9fK(self)
 def VVhHBt(self):
  global VVWyR9
  VVWyR9 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVdNge"    : self.VVdNge()
   elif item == "Restore_Channels"    : self.VVrgCY("channels_backup*.tar.gz", self.VV1Shk)
   elif item == "VVI79Z"   : self.VVI79Z()
   elif item == "Restore_SoftCAM_Files"  : self.VVrgCY("softcam_backup*.tar.gz", self.VVoAM1)
   elif item == "Backup_TunerDiSEqC"   : self.VVYFTg("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVrgCY("tuner_backup*.backup", boundFunction(self.VVNvEl, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVYFTg("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVrgCY("hotkey_*backup*.backup", boundFunction(self.VVNvEl, "misc"))
   elif item == "VVCy5X"    : self.VVCy5X()
   elif item == "Restore_Network"    : self.VVrgCY("network_backup*.tar.gz", self.VVqbGB)
   elif item == "VV7WRS"     : FFysO2(self, boundFunction(FFb4DW, self, boundFunction(CCON82.VV7WRS, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVMExU(False)
   elif item == "createMyDeb"     : self.VVMExU(True)
   elif item == "createMyTar"     : self.VVH2Sj()
   elif item == "VV56XY"   : self.VV56XY()
 @staticmethod
 def VV7WRS(SELF):
  OBF_Path = VVopWG + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVopWG, VVdDje, VVUrQZ)
   if err : FF3wnI(SELF, err)
   else : FFR6iW(SELF, txt)
  else:
   FFTvTY(SELF, OBF_Path)
 def VVMExU(self, VVPOOn):
  OBF_Path = VVopWG + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FF3wnI(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVopWG)
  os.system("mv -f %s %s" % (VVopWG + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVopWG + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVopWG + "plugin.py"))
  self.session.openWithCallback(self.VVMExU1, boundFunction(CC78zY, path=VVopWG, VVPOOn=VVPOOn))
 def VVMExU1(self):
  os.system("mv -f %s %s" % (VVopWG + "OBF/main.py"  , VVopWG))
  os.system("mv -f %s %s" % (VVopWG + "OBF/plugin.py" , VVopWG))
 def VV56XY(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FF3wnI(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FF3wnI(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVJkG4("%s*.list" % path)
  if err:
   FFTvTY(self, path + "*.list")
   return
  srcF, err = self.VVJkG4("%s*main_final.py" % path)
  if err:
   FFTvTY(self, path + "*.final.py")
   return
  VVATVO = []
  for f in files:
   f = os.path.basename(f)
   VVATVO.append((f, f))
  FFUdxd(self, boundFunction(self.VVMyMO, path, codF, srcF), VV64WM=VVATVO)
 def VVMyMO(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFTvTY(self, logF)
   else     : FFb4DW(self, boundFunction(self.VVA9EB, logF, codF, srcF))
 def VVA9EB(self, logF, codF, srcF):
  lst  = []
  lines = FFK66c(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FF3wnI(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVvQ4A(lst, logF, newLogF)
  totSrc  = self.VVvQ4A(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFR6iW(self, txt)
 def VVJkG4(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVvQ4A(self, lst, f1, f2):
  txt = FFP7TV(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVH2Sj(self):
  VVATVO = []
  VVATVO.append("%s%s" % (VVopWG, "*.py"))
  VVATVO.append("%s%s" % (VVopWG, "*.png"))
  VVATVO.append("%s%s" % (VVopWG, "*.xml"))
  VVATVO.append("%s"  % (VVe57v))
  FFI6cr(self, VVATVO, "%s_%s" % (PLUGIN_NAME, VVdDje), addTimeStamp=False)
 def VVdNge(self):
  path1 = VVgmxK
  path2 = "/etc/tuxbox/"
  VVATVO = []
  VVATVO.append("%s%s" % (path1, "*.tv"))
  VVATVO.append("%s%s" % (path1, "*.radio"))
  VVATVO.append("%s%s" % (path1, "*list"))
  VVATVO.append("%s%s" % (path1, "lamedb*"))
  VVATVO.append("%s%s" % (path2, "*.xml"))
  FFI6cr(self, VVATVO, "channels_backup", addTimeStamp=True)
 def VVI79Z(self):
  VVATVO = []
  VVATVO.append("/etc/tuxbox/config/")
  VVATVO.append("/usr/keys/")
  VVATVO.append("/usr/scam/")
  VVATVO.append("/etc/CCcam.cfg")
  FFI6cr(self, VVATVO, "softcam_backup", addTimeStamp=True)
 def VVCy5X(self):
  VVATVO = []
  VVATVO.append("/etc/hostname")
  VVATVO.append("/etc/default_gw")
  VVATVO.append("/etc/resolv.conf")
  VVATVO.append("/etc/wpa_supplicant*.conf")
  VVATVO.append("/etc/network/interfaces")
  VVATVO.append("/etc/enigma2/nameserversdns.conf")
  FFI6cr(self, VVATVO, "network_backup", addTimeStamp=True)
 def VV1Shk(self, fileName=None):
  if fileName:
   FFysO2(self, boundFunction(self.VVBsuu, fileName), "Overwrite current channels ?")
 def VVBsuu(self, fileName):
  path = "%s%s" % (VVe6OI, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCs1x9.VVzPB4()
   lamedb5File, diabled5File = CCs1x9.VVgHkw()
   cmd = ""
   cmd += FFUJYt("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFUJYt("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFNMxM()
   if res == 0 : FFi9RU(self, "Channels Restored.")
   else  : FF3wnI(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFTvTY(self, path)
 def VVoAM1(self, fileName=None):
  if fileName:
   FFysO2(self, boundFunction(self.VVsbNM, fileName), "Overwrite SoftCAM files ?")
 def VVsbNM(self, fileName):
  fileName = "%s%s" % (VVe6OI, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVFkPZ
   note = "You may need to restart your SoftCAM."
   FFMB4s(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FF8OuG(note, VVgcU9), sep))
  else:
   FFTvTY(self, fileName)
 def VVqbGB(self, fileName=None):
  if fileName:
   FFysO2(self, boundFunction(self.VVd74c, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVd74c(self, fileName):
  fileName = "%s%s" % (VVe6OI, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFSA5Q(self,  cmd)
  else:
   FFTvTY(self, fileName)
 def VVrgCY(self, pattern, callBackFunction, isTuner=False):
  title = FFkYLf()
  if pathExists(VVe6OI):
   myFiles = iGlob("%s%s" % (VVe6OI, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVATVO = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVATVO.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVJA2t = ("Sat. List", self.VVcMvi)
    else  : VVJA2t = None
    VV78RH = ("Delete File", self.VVLMoj)
    FFUdxd(self, callBackFunction, title=title, VV64WM=VVATVO, VVJA2t=VVJA2t, VV78RH=VV78RH)
   else:
    FF3wnI(self, "No files found in:\n\n%s" % VVe6OI, title)
  else:
   FF3wnI(self, "Path not found:\n\n%s" % VVe6OI, title)
 def VVLMoj(self, VVd1c8Obj, path):
  FFysO2(self, boundFunction(self.VVRUwk, VVd1c8Obj, path), "Delete this file ?\n\n%s" % path)
 def VVRUwk(self, VVd1c8Obj, path):
  path = VVe6OI + path
  os.system(FFUJYt("rm -f '%s'" % path))
  if fileExists(path) : FFmoBc(VVd1c8Obj, "Not deleted", 1000)
  else    : VVd1c8Obj.VVlcxr()
 def VVYFTg(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCmDe5()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVGEty, filePrefix))
 def VVGEty(self, filePrefix, result, retval):
  title = FFkYLf()
  if pathExists(VVe6OI):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FF3wnI(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVe6OI, filePrefix, FFpkvp())
    try:
     VVATVO = str(result.strip()).split()
     if VVATVO:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVATVO:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVFkPZ, FFtsFe(fName, VVgcU9), VVFkPZ)
       FFR6iW(self, txt, title=title, VVsIwt=VVlNJ6)
      else:
       FF3wnI(self, "File creation failed!", title)
     else:
      FF3wnI(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFUJYt("rm %s" % fName))
     FF3wnI(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFUJYt("rm %s" % fName))
     FF3wnI(self, "Error while writing file.")
  else:
   FF3wnI(self, "Path not found:\n\n%s" % VVe6OI, title)
 def VVNvEl(self, mode, path=None):
  if path:
   path = "%s%s" % (VVe6OI, path)
   if fileExists(path):
    lines = FFK66c(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFysO2(self, boundFunction(self.VVyXvG, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FF16em(self, path, title=FFkYLf())
   else:
    FFTvTY(self, path)
 def VVyXvG(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVV9xk = []
  VVV9xk.append("echo -e 'Reading current settings ...'")
  VVV9xk.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVV9xk.append("echo -e 'Preparing new settings ...'")
  VVV9xk.append(settingsLines)
  VVV9xk.append("echo -e 'Applying new settings ...'")
  VVV9xk.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFnFy8(self, VVV9xk)
 def VVcMvi(self, VVd1c8Obj, path):
  if not path:
   return
  path = VVe6OI + path
  if not fileExists(path):
   FFTvTY(self, path)
   return
  txt = FFP7TV(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVATVO  = []
   for item in satList:
    VVATVO.append("%s\t%s" % (item[0], FFhwVp(item[1])))
   FFR6iW(self, VVATVO, title="  Satellites List")
  else:
   FF3wnI(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCJYXQ(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhdcK(VVDXvw, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VV64WM = []
  VV64WM.append(("Plugins Browser List"       , "VV9e3H"   ))
  VV64WM.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VV64WM.append(("Startup Plugins"        , "pluginsStartup"    ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VV64WM.append(("Remove Packages (show all)"     , "VVKctLsAll"   ))
  VV64WM.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Update List of Available Packages"   , "VV4tQE"   ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Packaging Tool"        , "VV2GqB"    ))
  VV64WM.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFFgql(self, VV64WM=VV64WM)
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FFH9Ay(self["myMenu"])
  FFq9fK(self)
 def VVhHBt(self):
  global VVWyR9
  VVWyR9 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV9e3H"   : self.VV9e3H()
   elif item == "pluginsMenus"     : self.VVCPgk(0)
   elif item == "pluginsStartup"    : self.VVCPgk(1)
   elif item == "pluginsDirList"    : self.VV2tby()
   elif item == "downloadInstallPackages"  : FFb4DW(self, boundFunction(self.VVI5CK, 0, ""))
   elif item == "VVKctLsAll"   : FFb4DW(self, boundFunction(self.VVI5CK, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFb4DW(self, boundFunction(self.VVI5CK, 2, "| grep -e skin -e enigma2-"))
   elif item == "VV4tQE"   : self.VV4tQE()
   elif item == "VV2GqB"    : self.VV2GqB()
   elif item == "packagesFeeds"    : self.VVDG9U()
   else          : self.close()
 def VV2tby(self):
  extDirs  = FFu1mf(VVkxqr)
  sysDirs  = FFu1mf(VVngBg)
  VVATVO  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVATVO.append((item, VVkxqr + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVATVO.append((item, VVngBg + item))
  if VVATVO:
   VVATVO = sorted(VVATVO, key=lambda x: x[0].lower())
   VVHxLO = ("Package Info.", self.VVFSgs, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFynj9(self, None, header=header, VVATVO=VVATVO, VVeJNW=widths, VV4RrQ=28, VVHxLO=VVHxLO)
  else:
   FF3wnI(self, "Nothing found!")
 def VVFSgs(self, VVMB3d, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVkxqr) : loc = "extensions"
  elif path.startswith(VVngBg) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVO201(package)
  else:
   FF3wnI(self, "No info!")
 def VVDG9U(self):
  pkg = FF4LBH()
  if pkg : FFcaNF(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFdiGu(self)
 def VV9e3H(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVABtc(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVFkPZ + "\n"
    txt += VVABtc("Number"   , str(c))
    txt += VVABtc("Name"   , FFtsFe(str(p.name), VVgcU9))
    txt += VVABtc("Path"  , p.path  )
    txt += VVABtc("Description" , p.description )
    txt += VVABtc("Icon"  , p.iconstr  )
    txt += VVABtc("Wakeup Fnc" , p.wakeupfnc )
    txt += VVABtc("NeedsRestart", p.needsRestart)
    txt += VVABtc("Internal" , p.internal )
    txt += VVABtc("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFR6iW(self, txt)
 def VVCPgk(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVATVO = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVATVO.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVATVO:
   VVATVO.sort(key=lambda x: x[0].lower())
   header  = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths  = (19  , 25 , 20  , 27   , 9  )
   FFynj9(self, None, title=title, header=header, VVATVO=VVATVO, VVeJNW=widths, VV4RrQ=26)
  else:
   FF3wnI(self, "Nothing Found", title=title)
 def VV4tQE(self):
  cmd = FF5FY1(VVzrCb, "")
  if cmd : FFSA5Q(self, cmd, checkNetAccess=True)
  else : FFdiGu(self)
 def VV2GqB(self):
  pkg = FF4LBH()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFi9RU(self, txt)
 def VVI5CK(self, mode, grep, VVMB3d=None, title=""):
  if   mode == 0: cmd = FF5FY1(VViyYs    , grep)
  elif mode == 1: cmd = FF5FY1(VVHiEG , grep)
  elif mode == 2: cmd = FF5FY1(VVHiEG , grep)
  if not cmd:
   FFdiGu(self)
   return
  VV3CuM = FFo68R(cmd)
  if not VV3CuM:
   if VVMB3d: VVMB3d.VVIZWg()
   FF3wnI(self, "No packages found!")
   return
  elif len(VV3CuM) == 1 and VV3CuM[0] == VVxcbV:
   FF3wnI(self, VVxcbV)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVATVO  = []
  for item in VV3CuM:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVATVO.append((name, package, version))
  if mode > 0:
   extensions = FFo68R("ls %s -l | grep '^d' | awk '{print $9}'" % VVkxqr)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVATVO:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVATVO.append((name, VVkxqr + item, "-"))
   systemPlugins = FFo68R("ls %s -l | grep '^d' | awk '{print $9}'" % VVngBg)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVATVO:
      if item.lower() == row[0].lower():
       break
     else:
      VVATVO.append((item, VVngBg + item, "-"))
  if not VVATVO:
   FF3wnI(self, "No packages found!")
   return
  if VVMB3d:
   VVATVO.sort(key=lambda x: x[0].lower())
   VVMB3d.VVr5NB(VVATVO, title)
  else:
   widths = (20, 50, 30)
   VVVDdh = None
   VVDrmo = None
   if mode == 0:
    VVFile = ("Install" , self.VVLFRp   , [])
    VVVDdh = ("Download" , self.VVH7Yd   , [])
    VVDrmo = ("Filter"  , self.VVguSW , [])
   elif mode == 1:
    VVFile = ("Uninstall", self.VVKctL, [])
   elif mode == 2:
    VVFile = ("Uninstall", self.VVKctL, [])
    widths= (18, 57, 25)
   VVATVO = sorted(VVATVO, key=lambda x: x[0].lower())
   VVHxLO = ("Package Info.", self.VV7cFK, [])
   header   = ("Name" ,"Package" , "Version" )
   FFynj9(self, None, header=header, VVATVO=VVATVO, VVeJNW=widths, VV4RrQ=28, VVFile=VVFile, VVVDdh=VVVDdh, VVHxLO=VVHxLO, VVDrmo=VVDrmo, VV7PFT=self.lastSelectedRow
     , VVPUaR="#22110011", VV1PI5="#22191111", VVLubA="#22191111", VVrJH1="#00003030", VVndWP="#00333333")
 def VV7cFK(self, VVMB3d, title, txt, colList):
  package = colList[1]
  self.VVO201(package)
 def VVguSW(self, VVMB3d, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VV64WM = []
  VV64WM.append(("All Packages", "all"))
  VV64WM.append(VVB35E)
  VV64WM.append(("Plugin/SoftCAM/Skin", "plugins"))
  VV64WM.append(VVB35E)
  for word in words:
   VV64WM.append((word, word))
  FFUdxd(self, boundFunction(self.VVxVei, VVMB3d), VV64WM=VV64WM, title="Select Filter")
 def VVxVei(self, VVMB3d, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFb4DW(VVMB3d, boundFunction(self.VVI5CK, 0, grep, VVMB3d, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVKctL(self, VVMB3d, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVkxqr, VVngBg)):
   FFysO2(self, boundFunction(self.VVxoeO, VVMB3d, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VV64WM = []
   VV64WM.append(("Remove Package"         , "remove_ExistingPackage" ))
   VV64WM.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VV64WM.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFUdxd(self, boundFunction(self.VVQC6E, VVMB3d, package), VV64WM=VV64WM)
 def VVxoeO(self, VVMB3d, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VV6iqe)
  FFSA5Q(self, cmd, VVc6vh=boundFunction(self.VVLTQ6, VVMB3d))
 def VVQC6E(self, VVMB3d, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VV402z
   elif item == "remove_ForceRemove"  : cmdOpt = VVjBJk
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVrSTd
   FFysO2(self, boundFunction(self.VVVz74, VVMB3d, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVVz74(self, VVMB3d, package, cmdOpt):
  self.lastSelectedRow = VVMB3d.VVdrH0()
  cmd = FFU7ig(cmdOpt, package)
  if cmd : FFSA5Q(self, cmd, VVc6vh=boundFunction(self.VVLTQ6, VVMB3d))
  else : FFdiGu(self)
 def VVLTQ6(self, VVMB3d):
  VVMB3d.cancel()
  FFgSiE()
 def VVLFRp(self, VVMB3d, title, txt, colList):
  package  = colList[1]
  VV64WM = []
  VV64WM.append(("Install Package"         , "install_CheckVersion" ))
  VV64WM.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VV64WM.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VV64WM.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VV64WM.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFUdxd(self, boundFunction(self.VVDhCL, package), VV64WM=VV64WM)
 def VVDhCL(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVMxji
   elif item == "install_ForceReinstall" : cmdOpt = VVIxA6
   elif item == "install_ForceOverwrite" : cmdOpt = VVeAw5
   elif item == "install_ForceDowngrade" : cmdOpt = VVc2aH
   elif item == "install_IgnoreDepends" : cmdOpt = VVD21Q
   FFysO2(self, boundFunction(self.VV3Oao, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VV3Oao(self, package, cmdOpt):
  cmd = FFU7ig(cmdOpt, package)
  if cmd : FFSA5Q(self, cmd, VVc6vh=FFgSiE, checkNetAccess=True)
  else : FFdiGu(self)
 def VVH7Yd(self, VVMB3d, title, txt, colList):
  package  = colList[1]
  FFysO2(self, boundFunction(self.VVQjIK, package), "Download Package ?\n\n%s" % package)
 def VVQjIK(self, package):
  if FF9SAM():
   cmd = FFU7ig(VViIll, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FF8OuG(success, VVAexn))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FF8OuG(fail, VVe3tS))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFSA5Q(self, cmd, VVp5se=[VVe3tS, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFdiGu(self)
  else:
   FF3wnI(self, "No internet connection !")
 def VVO201(self, package):
  infoCmd  = FFU7ig(VVe7Ha, package)
  filesCmd = FFU7ig(VVcOCF, package)
  listInstCmd = FF5FY1(VVHiEG, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFBpeU(VVgcU9)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FF8OuG(notInst, VVValh))
   cmd += "else "
   cmd +=   FF2l60("System Info", VVgcU9)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FF2l60("Related Files", VVgcU9)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFLfrr(self, cmd)
  else:
   FFdiGu(self)
class CCs1x9(Screen):
 VVGXYk  = 0
 VVsaBJ = 1
 VVUi72  = 2
 VV2esi  = 3
 VVnsGP = 4
 VV0Oz5 = 5
 VVwIG3 = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFhdcK(VVDXvw, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVlU7c = None
  self.lastfilterUsed  = None
  VV64WM = self.VVxieH()
  FFFgql(self, VV64WM=VV64WM, title="Services/Channels")
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self["myMenu"].setList(self.VVxieH())
  FFH9Ay(self["myMenu"])
  FFq9fK(self)
 def VVxieH(self):
  VV64WM = []
  VV64WM.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VV64WM.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Services (Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VV64WM.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VV64WM.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VV64WM.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VV64WM.append(("Services with PIcons for the System"  , "VVPhEE"     ))
  VV64WM.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VV64WM.append(VVB35E)
  lamedbFile, disabledFile = CCs1x9.VVzPB4()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VV64WM.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VV64WM.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VV64WM.append(("Reset Parental Control Settings"   , "VVEMp3"    ))
  VV64WM.append(("Delete Channels with no names"   , "VVCThx"    ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Reload Channels and Bouquets"    , "VVWdvr"      ))
  return VV64WM
 def VVhHBt(self):
  global VVWyR9
  VVWyR9 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFTT8H(self)
   elif item == "currentServiceInfo"     : FFt65h(self, fncMode=CCc6Hf.VVbvPB)
   elif item == "TranspondersStats"     : FFb4DW(self, self.VVnauW     )
   elif item == "lameDB_allChannels_with_refCode"  : FFb4DW(self, self.VViTBf )
   elif item == "lameDB_allChannels_with_tranaponder" : FFb4DW(self, self.VVWZwJ)
   elif item == "lameDB_allChannels_with_details"  : FFb4DW(self, self.VVmyI8 )
   elif item == "parentalControlChannels"    : FFb4DW(self, self.VVD4nw   )
   elif item == "showHiddenChannels"     : FFb4DW(self, self.VVzTwC     )
   elif item == "VVPhEE"     : FFb4DW(self, self.VVY2IA     )
   elif item == "servicesWithMissingPIcons"   : FFb4DW(self, self.VVQh92   )
   elif item == "enableHiddenChannels"     : self.VVGROk(True)
   elif item == "disableHiddenChannels"    : self.VVGROk(False)
   elif item == "VVEMp3"    : FFysO2(self, self.VVEMp3, "Reset and Restart ?" )
   elif item == "VVCThx"    : FFb4DW(self, self.VVCThx)
   elif item == "VVWdvr"      : FFb4DW(self, boundFunction(CCs1x9.VVWdvr, self))
   else            : self.close()
 @staticmethod
 def VVWdvr(SELF):
  FFNMxM()
  FFi9RU(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VViTBf(self):
  self.VVlU7c = None
  self.lastfilterUsed  = None
  self.filterObj   = CCbhk5(self)
  VV3CuM = CCs1x9.VVNwh8(self, self.VVGXYk)
  if VV3CuM:
   VV3CuM.sort(key=lambda x: x[0].lower())
   VVyMeP  = ("Zap"   , self.VVUMKc     , [])
   VV4SDx = (""    , self.VVNStT   , [])
   VVHxLO = ("Options"  , self.VVbpuV , [])
   VVVDdh = ("Current Service", self.VV1FRA , [])
   VVDrmo = ("Filter"   , self.VVzggD  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVnesb  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFynj9(self, None, header=header, VVATVO=VV3CuM, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=26, VVyMeP=VVyMeP, VV4SDx=VV4SDx, VVVDdh=VVVDdh, VVHxLO=VVHxLO, VVDrmo=VVDrmo)
 def VVWZwJ(self):
  self.VVlU7c = None
  self.lastfilterUsed  = None
  self.filterObj   = CCbhk5(self)
  VV3CuM = CCs1x9.VVNwh8(self, self.VVsaBJ)
  if VV3CuM:
   VV3CuM.sort(key=lambda x: x[0].lower())
   VVyMeP  = ("Zap"   , self.VVUMKc      , [])
   VV4SDx = (""    , self.VVNStT    , [])
   VVVDdh = ("Current Service", self.VV1FRA  , [])
   VVHxLO = ("Options"  , self.VVwujI , [])
   VVDrmo = ("Filter"   , self.VVKqIX  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVnesb  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFynj9(self, None, header=header, VVATVO=VV3CuM, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=26, VVyMeP=VVyMeP, VV4SDx=VV4SDx, VVVDdh=VVVDdh, VVHxLO=VVHxLO, VVDrmo=VVDrmo)
 def VVbpuV(self, VVMB3d, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel  = CCYdZD(self, VVMB3d, 3)
  mSel.VV9azb(servName, refCode, pcState, hidState)
 def VVwujI(self, VVMB3d, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CCYdZD(self, VVMB3d, 3)
  mSel.VV8gP8(servName, refCode)
 def VVlgNJ(self, VVMB3d, refCode, isAddToBlackList):
  VVMB3d.VVVdyU("Processing ...")
  FFSYWA(boundFunction(self.VVKDgR, VVMB3d, [refCode], isAddToBlackList))
 def VVM9iW(self, VVMB3d, isAddToBlackList):
  refCodeList = VVMB3d.VV8QuG(3)
  if not refCodeList:
   FF3wnI(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVMB3d.VVVdyU("Processing ...")
  FFSYWA(boundFunction(self.VVKDgR, VVMB3d, refCodeList, isAddToBlackList))
 def VVKDgR(self, VVMB3d, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VV2Mmb, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VV2Mmb):
   lines = FFK66c(VV2Mmb)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VV2Mmb, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVMB3d.VVoduh
   if isMulti:
    self.VVscIJ(VVMB3d, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVe8uw(VVMB3d, refCode)
    VVMB3d.VVIZWg()
  else:
   VVMB3d.VVettN("No changes")
 def VVJBXi(self, VVMB3d, refCode, isHide):
  title = "Change Hidden State"
  if FFl5lx(refCode):
   VVMB3d.VVVdyU("Processing ...")
   ret = FF2FUE(refCode, isHide)
   if ret : FFb4DW(self, boundFunction(self.VVe8uw, VVMB3d, refCode))
   else : FF3wnI(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FF3wnI(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVe8uw(self, VVMB3d, refCode):
  VV3CuM = CCs1x9.VVNwh8(self, self.VVGXYk, VVos0d=[3, [refCode], False])
  done = False
  if VV3CuM:
   data = VV3CuM[0]
   if data[3] == refCode:
    done = VVMB3d.VVqFcn(data)
  if not done:
   self.VVAC7A(VVMB3d, VVMB3d.VVIwKq(), self.VVGXYk)
  VVMB3d.VVIZWg()
 def VVscIJ(self, VVMB3d, totRefCodes):
  VV3CuM = CCs1x9.VVNwh8(self, self.VVGXYk, VVos0d=self.VVlU7c)
  VVMB3d.VVr5NB(VV3CuM)
  VVMB3d.VVMC9a(False)
  VVMB3d.VVettN("%d Processed" % totRefCodes)
 def VV3hO0(self, VVMB3d, isHide):
  refCodeList = VVMB3d.VV8QuG(3)
  if not refCodeList:
   FF3wnI(self, "Nothing selected", title="Change Hidden State")
   return
  VVMB3d.VVVdyU("Processing ...")
  FFSYWA(boundFunction(self.VV8whc, VVMB3d, refCodeList, isHide))
 def VV8whc(self, VVMB3d, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FF2FUE(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   db = eDVBDB.getInstance()
   if db:
    db.saveServicelist()
    db.reloadServicelist()
    db.reloadBouquets()
   self.VVscIJ(VVMB3d, len(refCodeList))
  else:
   VVMB3d.VVettN("No changes")
 def VVzggD(self, VVMB3d, title, txt, colList):
  self.filterObj.VVsOrb(1, VVMB3d, 2, boundFunction(self.VVLZWm, VVMB3d))
 def VVLZWm(self, VVMB3d, item):
  self.VVs0Tt(VVMB3d, item, 2, self.VVGXYk)
 def VVKqIX(self, VVMB3d, title, txt, colList):
  self.filterObj.VVsOrb(2, VVMB3d, 4, boundFunction(self.VV1NBP, VVMB3d))
 def VV1NBP(self, VVMB3d, item):
  self.VVs0Tt(VVMB3d, item, 4, self.VVsaBJ)
 def VVwV3q(self, VVMB3d, title, txt, colList):
  self.filterObj.VVsOrb(0, VVMB3d, 4, boundFunction(self.VVeDB8, VVMB3d))
 def VVeDB8(self, VVMB3d, item):
  self.VVs0Tt(VVMB3d, item, 4, self.VVUi72)
 def VVs0Tt(self, VVMB3d, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVMB3d.VVits3(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVlU7c = None
  else:
   words, asPrefix = CCbhk5.VVQhDw(words)
   self.VVlU7c = [col, words, asPrefix]
  if words: FFb4DW(self, boundFunction(self.VVAC7A, VVMB3d, title, mode), title="Reading Services ...")
  else : FFmoBc(VVMB3d, "Incorrect filter", 2000)
 def VVAC7A(self, VVMB3d, title, mode):
  VV3CuM = CCs1x9.VVNwh8(self, mode, VVos0d=self.VVlU7c, VVD9mD=False)
  if VV3CuM:
   VV3CuM.sort(key=lambda x: x[0].lower())
   VVMB3d.VVr5NB(VV3CuM, title)
  else:
   VVMB3d.VVIZWg()
   FFmoBc(VVMB3d, "Not found!", 1500)
 def VVEirG(self, VVATVO, VVyMeP=None, VV4SDx=None, VVFile=None, VVVDdh=None, VVHxLO=None, VVDrmo=None):
  VVVDdh = ("Current Service", self.VV1FRA, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVnesb = (LEFT  , LEFT  , CENTER, LEFT    )
  FFynj9(self, None, header=header, VVATVO=VVATVO, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=26, VVyMeP=VVyMeP, VV4SDx=VV4SDx, VVFile=VVFile, VVVDdh=VVVDdh, VVHxLO=VVHxLO, VVDrmo=VVDrmo)
 def VV1FRA(self, VVMB3d, title, txt, colList):
  self.VVOGjl(VVMB3d)
 def VVPjDN(self, VVMB3d, title, txt, colList):
  self.VVOGjl(VVMB3d, True)
 def VVOGjl(self, VVMB3d, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVMB3d.VV8QRM(colDict, VVuaY6=True)
   else:
    VVMB3d.VVV98r(3, refCode, True)
   return
  FF3wnI(self, "Colud not read current Reference Code !")
 def VVmyI8(self):
  self.VVlU7c = None
  self.lastfilterUsed  = None
  self.filterObj   = CCbhk5(self)
  VV3CuM = CCs1x9.VVNwh8(self, self.VVUi72)
  if VV3CuM:
   VV3CuM.sort(key=lambda x: x[0].lower())
   VV4SDx = (""    , self.VV3es5 , []      )
   VVVDdh = ("Current Service", self.VVPjDN  , []      )
   VVDrmo = ("Filter"   , self.VVwV3q   , [], "Loading Filters ..." )
   VVyMeP  = ("Zap"   , self.VVnhXV      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVnesb  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFynj9(self, None, header=header, VVATVO=VV3CuM, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=26, VVyMeP=VVyMeP, VV4SDx=VV4SDx, VVVDdh=VVVDdh, VVDrmo=VVDrmo)
 def VV3es5(self, VVMB3d, title, txt, colList):
  refCode  = self.VVBnqn(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFt65h(self, fncMode=CCc6Hf.VVJyYl, refCode=refCode, chName=chName, text=txt)
 def VVnhXV(self, VVMB3d, title, txt, colList):
  refCode = self.VVBnqn(colList)
  FFtcar(self, refCode)
 def VVUMKc(self, VVMB3d, title, txt, colList):
  FFtcar(self, colList[3])
 def VVBnqn(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVNwh8(SELF, mode, VVos0d=None, VVD9mD=True, VVxxba=True):
  lamedbFile, disabledFile = CCs1x9.VVzPB4()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVos0d:
    filterCol = VVos0d[0]
    filterWords = VVos0d[1]
    asPrefix = VVos0d[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCs1x9.VVGXYk:
    blackList = None
    if fileExists(VV2Mmb):
     blackList = FFK66c(VV2Mmb)
     if blackList:
      blackList = set(blackList)
   elif mode == CCs1x9.VVsaBJ:
    tp = CCkhMr()
   VVwz6m, VVL7qP = FFgerI()
   tagFound  = False
   if mode in (CCs1x9.VV0Oz5, CCs1x9.VVwIG3):
    VV3CuM = {}
   else:
    VV3CuM = []
   with ioOpen(lamedbFile, "r", encoding="utf-8") as f:
    lines = []
    for line in f:
     line = str(line).strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFoAsb(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CCs1x9.VVUi72:
        if sTypeInt in VVwz6m:
         STYPE = VVL7qP[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VV3CuM.append(tRow)
         elif any(x in tmp for x in filterWords)    : VV3CuM.append(tRow)
        else:
         VV3CuM.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCs1x9.VV0Oz5:
         VV3CuM[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCs1x9.VVwIG3:
         VV3CuM[chName] = refCode
        elif mode == CCs1x9.VVGXYk:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VV3CuM.append(tRow)
          elif any(x in tmp for x in filterWords)    : VV3CuM.append(tRow)
         else:
          VV3CuM.append(tRow)
        elif mode == CCs1x9.VVsaBJ:
         if sTypeInt in VVwz6m:
          STYPE = VVL7qP[sTypeInt]
         freq, pol, fec, sr, syst = tp.VV34cG(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VV3CuM.append(tRow)
          elif any(x in tmp for x in filterWords)    : VV3CuM.append(tRow)
         else:
          VV3CuM.append(tRow)
        elif mode == CCs1x9.VV2esi:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VV3CuM.append((chName, chProv, sat, refCode))
        elif mode == CCs1x9.VVnsGP:
         VV3CuM.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VV3CuM and VVD9mD:
    FF3wnI(SELF, "No services found!")
   return VV3CuM
  else:
   if VVxxba:
    FFTvTY(SELF, lamedbFile)
   return None
 def VVD4nw(self):
  if fileExists(VV2Mmb):
   lines = FFK66c(VV2Mmb)
   if lines:
    newRows  = []
    VV3CuM = CCs1x9.VVNwh8(self, self.VVnsGP)
    if VV3CuM:
     lines = set(lines)
     for item in VV3CuM:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VV3CuM = newRows
      VV3CuM.sort(key=lambda x: x[0].lower())
      VV4SDx = ("", self.VVNStT, [])
      VVyMeP = ("Zap", self.VVUMKc, [])
      self.VVEirG(VVATVO=VV3CuM, VVyMeP=VVyMeP, VV4SDx=VV4SDx)
     else:
      FFR6iW(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VV3CuM)))
   else:
    FFi9RU(self, "No active Parental Control services.", FFkYLf())
  else:
   FFTvTY(self, VV2Mmb)
 def VVzTwC(self):
  VV3CuM = CCs1x9.VVNwh8(self, self.VV2esi)
  if VV3CuM:
   VV3CuM.sort(key=lambda x: x[0].lower())
   VV4SDx = ("" , self.VVNStT, [])
   VVyMeP  = ("Zap", self.VVUMKc, [])
   self.VVEirG(VVATVO=VV3CuM, VVyMeP=VVyMeP, VV4SDx=VV4SDx)
  else:
   FFi9RU(self, "No hidden services.", FFkYLf())
 def VVnauW(self):
  totT, totC, totA, totS, totS2, satList = self.VVjb4m()
  txt = FFtsFe("Total Transponders:\n\n", VVzqsa)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFtsFe("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVzqsa)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFtGZT(item), satList.count(item))
  FFR6iW(self, txt)
 def VVjb4m(self):
  lamedbFile, disabledFile = CCs1x9.VVzPB4()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with ioOpen(lamedbFile, "r", encoding="utf-8") as f:
    lines = []
    for line in f:
     line = str(line).strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFTvTY(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VVY2IA(self)   : self.VVPhEE(True)
 def VVQh92(self) : self.VVPhEE(False)
 def VVPhEE(self, isWithPIcons):
  piconsPath = CC7Ld1.VVeUbw()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CC7Ld1.VVbvMz(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VV3CuM = CCs1x9.VVNwh8(self, self.VVnsGP)
    if VV3CuM:
     channels = []
     for (chName, chProv, sat, refCode) in VV3CuM:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFqcmy(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VV3CuM)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVABtc(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVABtc("PIcons Path"  , piconsPath)
     txt += VVABtc("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVABtc("Total services" , totalServices)
     txt += VVABtc("With PIcons"  , totalWithPIcons)
     txt += VVABtc("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFR6iW(self, txt)
     else:
      VV4SDx     = (""      , self.VVNStT , [])
      if isWithPIcons : VVDrmo = ("Export Current PIcon", self.VVTQ2A  , [])
      else   : VVDrmo = None
      VVHxLO     = ("Statistics", FFR6iW, [txt])
      VVyMeP      = ("Zap", self.VVUMKc, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVEirG(VVATVO=channels, VVyMeP=VVyMeP, VV4SDx=VV4SDx, VVHxLO=VVHxLO, VVDrmo=VVDrmo)
   else:
    FF3wnI(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FF3wnI(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVNStT(self, VVMB3d, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFt65h(self, fncMode=CCc6Hf.VVJyYl, refCode=refCode, chName=chName, text=txt)
 def VVTQ2A(self, VVMB3d, title, txt, colList):
  png, path = CC7Ld1.VVOrYS(colList[3], colList[0])
  if path:
   CC7Ld1.VVALFi(self, png, path)
 @staticmethod
 def VVzPB4():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVgHkw():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVGROk(self, isEnable):
  lamedbFile, disabledFile = CCs1x9.VVzPB4()
  if isEnable and not fileExists(disabledFile):
   FFi9RU(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FF3wnI(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFysO2(self, boundFunction(self.VVZlkK, isEnable), "%s Hidden Channels ?" % word)
 def VVZlkK(self, isEnable):
  lamedbFile , disabledFile = CCs1x9.VVzPB4()
  lamedb5File, diabled5File = CCs1x9.VVgHkw()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFNMxM()
  if res == 0 : FFi9RU(self, "Hidden List %s" % word)
  else  : FF3wnI(self, "Error while restoring:\n\n%s" % fileName)
 def VVEMp3(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFnFy8(self, cmd)
 def VVCThx(self):
  lamedbFile, disabledFile = CCs1x9.VVzPB4()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFUJYt("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFK66c(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFUJYt("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFNMxM()
   FFR6iW(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFTvTY(self, lamedbFile)
class CCc6Hf(Screen):
 VVbvPB  = 0
 VVlsAz   = 1
 VVaFX5   = 2
 VVJyYl    = 3
 VVZpzG    = 4
 VVufz1   = 5
 VVeRha   = 6
 VV07WG    = 7
 VVmnnf   = 8
 VVSSwx   = 9
 VVRvdl   = 10
 VVsgkw   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFhdcK(VVCTjl, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVbvPB)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFtsFe("%s\n", VVM75e) % VVFkPZ
  FFFgql(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVC4vC })
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  self["myLabel"].VVdsWe(textOutFile="chann_info")
  if   self.fncMode == self.VVbvPB : fnc = self.VVaXZO_VVbvPB
  elif self.fncMode == self.VVlsAz  : fnc = self.VVaXZO_VVbvPB
  elif self.fncMode == self.VVaFX5  : fnc = self.VVaXZO_VVbvPB
  elif self.fncMode == self.VVJyYl  : fnc = self.VVaXZO_VVJyYl
  elif self.fncMode == self.VVZpzG  : fnc = self.VVaXZO_VVZpzG
  elif self.fncMode == self.VVufz1  : fnc = self.VVaXZO_VVufz1
  elif self.fncMode == self.VVeRha  : fnc = self.VVaXZO_VVeRha
  elif self.fncMode == self.VV07WG  : fnc = self.VVaXZO_VV07WG
  elif self.fncMode == self.VVmnnf  : fnc = self.VVaXZO_VVmnnf
  elif self.fncMode == self.VVSSwx : fnc = self.VVaXZO_VVSSwx
  elif self.fncMode == self.VVRvdl  : fnc = self.VVaXZO_VVRvdl
  elif self.fncMode == self.VVsgkw : fnc = self.VVaXZO_VVsgkw
  self["myLabel"].setText("\n   Reading Info ...")
  FFSYWA(fnc)
 def VVt3i0(self, err):
  self["myLabel"].setText(err)
  FFrlPO(self["myTitle"], "#22200000")
  FFrlPO(self["myBody"], "#22200000")
  self["myLabel"].FFrlPOColor("#22200000")
  self["myLabel"].VVxD83()
 def VVaXZO_VVbvPB(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self)
  self.refCode = refCode
  self.VVirWN(chName)
 def VVaXZO_VVJyYl(self):
  self.VVirWN(self.chName)
 def VVaXZO_VVZpzG(self):
  self.VVirWN(self.chName)
 def VVaXZO_VVufz1(self):
  self.VVirWN(self.chName)
 def VVaXZO_VVeRha(self):
  self.VVirWN("Picon Info")
 def VVaXZO_VV07WG(self):
  self.VVirWN(self.chName)
 def VVaXZO_VVmnnf(self):
  self.VVirWN(self.chName)
 def VVaXZO_VVSSwx(self):
  self.VVirWN(self.chName)
 def VVaXZO_VVRvdl(self):
  self.chUrl = self.refCode + self.callingSELF.VVaI7c(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVirWN(self.chName)
 def VVaXZO_VVsgkw(self):
  self.VVirWN(self.chName)
 def VVirWN(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFsLKB(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVjFyu(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFtsFe(self.VViLgh(tUrl), VVBPJz)
  if not self.epg:
   epg = self.VVdPz4(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVdv6v(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CC7Ld1.VVOrYS(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVdv6v(path)
  self.VVavDQ()
  self.VVfwWk()
  self["myLabel"].setText(self.text, VVsIwt=VVDQDA)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVxD83(minHeight=minH)
 def VVfwWk(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FF6XlH(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVOZYS(FFqMjA(url))
  if epg:
   self.text += "\n" + FF82X1("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVavDQ()
 def VVavDQ(self):
  if not self.piconShown and self.picUrl:
   path, err = FFd8ee(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVdv6v(path)
    if self.piconShown and self.refCode:
     self.VVJXIY(path, self.refCode)
 def VVJXIY(self, path, refCode):
  if path and fileExists(path) and os.system(FFUJYt("which ffmpeg")) == 0:
   pPath = CC7Ld1.VVeUbw()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
    cmd += FFUJYt("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVdv6v(self, path):
  if path and fileExists(path):
   err, w, h = self.VVip7q(path)
   if not err:
    if h > w:
     self.VVvAY9(self["myPicF"], w, h, True)
     self.VVvAY9(self["myPic"] , w, h, False)
   allOK = FFHLbC(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVvAY9(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVip7q(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFhOpk(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVjFyu(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFtsFe(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVABtc(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFtsFe(state, VVValh)
   txt += "State\t: %s\n" % state
  w = FFdS3Z(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFdS3Z(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVJ1iG(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVABtc(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVABtc(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVABtc(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVCqzW()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVTAge()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCc6Hf.VVVu1t(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFtsFe("IPTV", VVzqsa)
   txt += self.VVBvRZ(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVPath(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCkhMr()
    tpTxt, namespace = tp.VViyhr(refCode)
    del tp
    if tpTxt:
     txt += FFtsFe("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFtsFe("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVABtc(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVABtc(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVABtc(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVABtc(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVABtc(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVABtc(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVABtc(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVABtc(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVABtc(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVJ1iG(info):
  if info:
   aspect = FFdS3Z(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVABtc(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFdS3Z(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVevDb(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVevDb(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVCqzW(self):
  try:
   service = self.session.nav.getCurrentService()
   audio = service and service.audioTracks()
   return audio and audio.getNumberOfTracks() or 0
  except:
   pass
  return -1
 def VVTAge(self):
  try:
   service   = self.session.nav.getCurrentService()
   subtitle  = service and service.subtitle()
   subtitlelist = subtitle and subtitle.getSubtitleList()
   return len(subtitlelist)
  except:
   pass
  return -1
 def VVPath(self, refCode, iptvRef, chName):
  refCode = FFYZPy(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFP7TV(VVgmxK + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFP7TV(VVgmxK + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVATVO = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVgmxK + item
   if fileExists(path):
    txt = FFP7TV(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVATVO.append(bName)
  txt = self.Sep
  if VVATVO:
   if len(VVATVO) == 1:
    txt += "%s\t: %s\n" % (FFtsFe("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VVATVO[0])
   else:
    txt += FFtsFe("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VVATVO):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVdPz4(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVnmG1(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVnmG1(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVnmG1(event, 0)
     except:
      pass
  return epg
 def VVnmG1(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName().strip()    or ""
   evTime = event.getBeginTime()      or ""
   evDur = event.getDuration()      or ""
   evShort = event.getShortDescription() .strip() or ""
   evDesc = event.getExtendedDescription().strip() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = self.VVaq2z(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FFtsFe(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FFtsFe(evNameTransl, COLOR_CONS_BRIGHT_YELLOW))
    if evTime           : txt += "Start Time\t: %s\n" % FFlXfZ(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFlXfZ(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFZEiA(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFZEiA(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFZEiA(evTime - now)
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFtsFe(evShort, VVwcoZ)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFtsFe(evDesc , VVwcoZ)
    if txt:
     txt = FFtsFe("\n%s\n%s Event:\n%s\n" % (VVFkPZ, ("Current", "Next")[evNum], VVFkPZ), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVBvRZ(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FF0J40(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCpWxg()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVKzrD(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFtsFe("URL:", VVzqsa) + "\n%s\n" % self.VViLgh(decodedUrl)
  else:
   txt = "\n"
   txt += FFtsFe("Reference:", VVzqsa) + "\n%s\n" % refCode
  return txt
 def VViLgh(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVioJp:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VVOZYS(self, decodedUrl):
  if not FF9SAM():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCNFtw.VVH2YO(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCNFtw.VVfEog(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVB0iR(tDict)
   elif uType == "movie" : epg, picUrl = self.VVRdTV(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVB0iR(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCNFtw.VVmQRI(item, "title"    , is_base64=True )
     lang    = CCNFtw.VVmQRI(item, "lang"         ).upper()
     description   = CCNFtw.VVmQRI(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCNFtw.VVmQRI(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCNFtw.VVmQRI(item, "start_timestamp"      )
     stop_timestamp  = CCNFtw.VVmQRI(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCNFtw.VVmQRI(item, "stop_timestamp"       )
     now_playing   = CCNFtw.VVmQRI(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVXaUF, ""
      else     : color, txt = VVValh , "    (CURRENT EVENT)"
      epg += FFtsFe("_" * 32 + "\n", VVM75e)
      epg += FFtsFe("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFtsFe(description, VVBPJz)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVx4Tm(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVRdTV(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCNFtw.VVmQRI(item, "movie_image" )
    genre  = CCNFtw.VVmQRI(item, "genre"   ) or "-"
    plot  = CCNFtw.VVmQRI(item, "plot"   ) or "-"
    cast  = CCNFtw.VVmQRI(item, "cast"   ) or "-"
    rating  = CCNFtw.VVmQRI(item, "rating"   ) or "-"
    director = CCNFtw.VVmQRI(item, "director"  ) or "-"
    releasedate = CCNFtw.VVmQRI(item, "releasedate" ) or "-"
    duration = CCNFtw.VVmQRI(item, "duration"  ) or "-"
    try:
     lang = CCNFtw.VVmQRI(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFtsFe(cast, VVBPJz)
    epg += "Plot:\n%s"    % FFtsFe(self.VVaq2z(plot), VVBPJz)
   except:
    pass
  return epg, movie_image
 def VVaq2z(self, evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = self.VVozYb(evTxt, lang)
   return CCc6Hf.VVGOEi(txt).strip() or evTxt
 @staticmethod
 def VVGOEi(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VVozYb(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFNJUt(txt))
   txt, err = CCNFtw.VVfEog(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFqMjA(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVx4Tm(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VVlgR3(SELF):
  if not CCZnqB.VVEsd4(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(SELF)
  err = url =  fSize = resumable = ""
  if FFqt04(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCpWxg.VVSNrE(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCpWxg.VVg7EPHeader(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FF3wnI(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCN0r2.VVAajP(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFtsFe(" (M3U/M3U8 File)", VVBPJz)
    else:
     fSize = "No info. from server. Try again later."
    hResume = resp.headers.get("Accept-Ranges" , "")
    if hResume:
     if not hResume == "none": resumable = "Yes"
     else     : resumable = "No"
   except requests.Timeout as e     : err = "Connection Timeout"
   except Exception as e       : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVLucE(subj, val):
   return "%s\n%s\n\n" % (FFtsFe("%s:" % subj, COLOR_CONS_BRIGHT_YELLOW), val)
  title = "File Size"
  txt  = VVLucE(title , fSize or "?")
  txt += VVLucE("Name" , chName)
  txt += VVLucE("URL" , url)
  if resumable: txt += VVLucE("Supports Download-Resume", resumable)
  if err  : txt += FFtsFe("Error:\n", VVValh) + err
  FFR6iW(SELF, txt, title=title)
 @staticmethod
 def VVVu1t(SELF):
  fPath, fDir, fName = CCN0r2.VVyaVF(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg", "mvi"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 def VVC4vC(self):
  if VVioJp:
   def VVABtc(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVABtc(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCpWxg()
    valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVKzrD(decodedUrl)
    n = ("valid", "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVABtc(n[i], v[i])
   with open("/tmp/ajp_channel_details", "a") as f:
    f.write("%s\n%s\n" % (VVFkPZ, txt))
   FFmoBc(self, "Saved to:", 1000)
class CCpWxg():
 def __init__(self):
  self.VVqiSe   = ""
  self.VVjS4W    = ""
  self.VV5toC   = ""
  self.portal_moreAuthRand = ""
  self.portal_moreAuthMsg  = ""
  self.portal_moreAuthType = 0
  self.colored_user   = "#f#11ffffaa#User"
  self.colored_server   = "#f#11aaffff#Server"
 def VVB1qz(self, url, mac, VVuaY6=True):
  self.VVqiSe   = ""
  self.VVjS4W    = ""
  self.VV5toC   = ""
  self.portal_moreAuthRand = ""
  self.portal_moreAuthMsg  = ""
  self.portal_moreAuthType = 0
  host = self.VVdmaJ(url)
  if not host:
   if VVuaY6:
    self.VVuaY6or("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVLrZ0(mac)
  if not host:
   if VVuaY6:
    self.VVuaY6or("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVqiSe = host
  self.VVjS4W  = mac
  return True
 def VVdmaJ(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVLrZ0(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVWMDe(self):
  res, err = self.VV83MV(self.VVMFxe())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VVqiSe:
   self.VVqiSe = self.VVqiSe.replace(urlPath, "")
   res, err = self.VV83MV(self.VVMFxe())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCNFtw.VVmQRI(tDict["js"], "token")
    rand  = CCNFtw.VVmQRI(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVcrCo(self, VVuaY6=True):
  err = blkMsg = FFi9RUTxt = ""
  try:
   token, rand, err = self.VVWMDe()
   if token:
    self.VV5toC = token
    self.portal_moreAuthRand = rand
    if rand:
     self.portal_moreAuthType = 2
    prof, retTxt = self.VVeqYc(True)
    if prof:
     self.portal_moreAuthMsg = retTxt
     if "device_id mismatch" in retTxt:
      self.portal_moreAuthType = 3
      prof, retTxt = self.VVeqYc(False)
      if retTxt:
       self.portal_moreAuthMsg = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFi9RUTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFi9RUTxt: tErr += "\n%s" % FFi9RUTxt
  if VVuaY6:
   self.VVuaY6or(tErr)
  return "", "", tErr
 def VVeqYc(self, capMac):
  res, err = self.VV83MV(self.VV8pBw(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCNFtw.VVmQRI(tDict["js"], "block_%s" % word)
    FFi9RUTxt = CCNFtw.VVmQRI(tDict["js"], word)
    return tDict, FFi9RUTxt.strip() or blkMsg.strip()
   except Exception as e:
    pass
  return "", ""
 def VV8pBw(self, capMac):
  if self.portal_moreAuthMsg or self.portal_moreAuthRand:
   import hashlib
   if capMac: mac = self.VVjS4W.upper()
   else  : mac = self.VVjS4W.lower()
   macUtf8 = mac.encode('utf-8')
   sn = hashlib.md5(macUtf8).hexdigest().upper()[:13]
   Id = hashlib.sha256(macUtf8).hexdigest().upper()
   sig = hashlib.sha256((sn + mac).encode('utf-8')).hexdigest().upper()
   param  = ""
   param += "&sn=%s"   % sn
   param += "&device_id=%s" % Id
   param += "&device_id2=%s" % Id
   param += "&signature=%s" % sig
   param += '&auth_second_step=1'
   param += '&hw_version=2.17-IB-00&hw_version_2=62'
   param += '&metrics={"mac":"%s","sn":"%s","type":"STB","model":"MAG250","random":"%s"}' % (self.VVjS4W, sn, self.portal_moreAuthRand)
  else:
   param = ""
  return self.VVi15b() + "type=stb&action=get_profile" + param
 def VVIRlK(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVA4hJ()
  if len(rows) < 10:
   rows = self.VVCzvF()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVqiSe ))
   rows.append(("MAC (from URL)" , self.VVjS4W ))
   rows.append(("Token"   , self.VV5toC ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VVjS4W ))
   rows.append(("2", self.colored_server, "Host" , self.VVqiSe ))
   rows.append(("2", self.colored_server, "Token" , self.VV5toC ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVAFK0(self, isPhp=True, VVuaY6=False):
  token, profile, tErr = self.VVcrCo(VVuaY6)
  if not token:
   return "", tErr
  m3u_Url = ""
  url = self.VVvvkg()
  res, err = self.VV83MV(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCNFtw.VVmQRI(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFNJUt(span.group(2))
     pass1 = FFNJUt(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, err
 def VVA4hJ(self):
  m3u_Url, err = self.VVAFK0()
  rows = []
  if m3u_Url:
   res, err = self.VV83MV(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFlXfZ(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFlXfZ(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVCzvF(self):
  token, profile, tErr = self.VVcrCo()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFUFAB(val): val = FF27My(val.decode("UTF-8"))
     else     : val = self.VVjS4W
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFlXfZ(int(parts[1]))
      if parts[2] : ends = FFlXfZ(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFlXfZ(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVaI7c(self, mode, chCm, epNum, epId):
  crLinkUrl = self.VVQWE9(mode, chCm, epNum, epId)
  token, profile, tErr = self.VVcrCo(VVuaY6=False)
  if not token:
   return ""
  res, err = self.VV83MV(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCNFtw.VVmQRI(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVi15b(self):
  return self.VVqiSe + "/server/load.php?"
 def VVMFxe(self):
  return self.VVi15b() + "type=stb&action=handshake&token=&mac=%s" % self.VVjS4W
 def VVqg0F(self, mode):
  url = self.VVi15b() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVKLNw(self, catID):
  return self.VVi15b() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVtPsF(self, mode, catID, page):
  url = self.VVi15b() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "series" : url += "category=%s" % catID
  else    : url += "genre=%s&force_ch_link_check=" % catID
  return url
 def VVvNxu(self, mode, searchName, page):
  return self.VVi15b() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VVwYeH(self, mode, catID):
  return self.VVi15b() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVQWE9(self, mode, chCm, serCode, serId):
  url = self.VVi15b() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVvvkg(self):
  return self.VVi15b() + "type=itv&action=create_link"
 def VVNbg1(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVDd7X(catID, stID, chNum)
  query = self.VVZoKf(mode, FFwkTL(host), FFwkTL(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVZoKf(self, mode, host, mac, serCode, serId, chCm):
  query = "mode=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVKzrD(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVZoKf(mode, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FF27My(host)
  mac   = FF27My(mac)
  valid = False
  if self.VVdmaJ(playHost) and self.VVdmaJ(host) and self.VVdmaJ(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, playHost, mode, host, mac, epNum, epId, chCm, query
 def VV83MV(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCpWxg.VVg7EPHeader()
   if self.VV5toC:
    headers["Authorization"] = "Bearer %s" % self.VV5toC
   if useCookies : cookies = {"mac": self.VVjS4W, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok : return res, ""
   else  : err = "Err-%d : %s" % (res.status_code, res.reason or "Unknown")
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVgMVZ(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCpWxg.VVg7EPHeader(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVg7EPHeader():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVYJaU(host, mac, tType, action, keysList=[]):
  myPortal = CCpWxg()
  ok = myPortal.VVB1qz(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVcrCo(VVuaY6=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VV83MV(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVHYHi(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVHYHi(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVuaY6or(self, err, title="Portal Browser"):
  FF3wnI(self, str(err), title=title)
 def VVsSOA(self, mode):
  if   mode in ("itv"  , CCNFtw.VVtemc , CCNFtw.VVOCls)  : return "Live"
  elif mode in ("vod"  , CCNFtw.VVACIN , CCNFtw.VVbMHV)  : return "VOD"
  elif mode in ("series" , CCNFtw.VVgqDe , CCNFtw.VVpiYc) : return "Series"
  else                          : return "IPTV"
 def VV7h9k(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVsSOA(mode), searchName)
 def VVkLJq(self, catchup=False):
  VV64WM = []
  VV64WM.append(("Live"    , "live"  ))
  VV64WM.append(("VOD"    , "vod"   ))
  VV64WM.append(("Series"   , "series"  ))
  if catchup:
   VV64WM.append(VVB35E)
   VV64WM.append(("Catchup TV" , "catchup"  ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Account Info." , "accountInfo" ))
  return VV64WM
 @staticmethod
 def VV1tPI(decodedUrl):
  m3u_Url = ""
  p = CCpWxg()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVKzrD(decodedUrl)
  if valid:
   ok = p.VVB1qz(host, mac, VVuaY6=False)
   if ok:
    m3u_Url, err = p.VVAFK0(isPhp=False, VVuaY6=False)
    span = iSearch(r".+ch\/(.+)_", decodedUrl, IGNORECASE)
    if span:
     m3u_Url += span.group(1)
  return m3u_Url
 @staticmethod
 def VVSNrE(decodedUrl):
  p = CCpWxg()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVKzrD(decodedUrl)
  if valid:
   ok = p.VVB1qz(host, mac, VVuaY6=False)
   if ok:
    try:
     chUrl = p.VVaI7c(mode, chCm, epNum, epId)
     return FFqMjA(chUrl)
    except Exception as e:
     pass
  return ""
class CCQOiM(CCpWxg):
 def __init__(self):
  CCpWxg.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVFU1o(self, refCode, chName, decodedUrl, iptvRef):
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVKzrD(decodedUrl)
  if valid:
   if self.VVB1qz(host, mac, VVuaY6=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVg09H(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVaI7c(self.mode, self.chCm, self.epNum, self.epId)
  except:
   pass
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = self.refCode + chUrl.strip() + ":" + self.chName
  newIptvRef = self.VVUGKc(chUrl)
  if newIptvRef:
   success = self.VV80YZ(self.iptvRef, newIptvRef)
   if passedSELF:
    FFtcar(passedSELF, newIptvRef, VVdsme=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFtcar(self, newIptvRef, VVdsme=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVUGKc(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VV80YZ(self, oldCode, newCode):
  bPath = FFovpB()
  if bPath:
   txt = FFP7TV(bPath)
   if oldCode in txt:
    txt = txt.replace(oldCode, newCode)
    with open(bPath, "w") as f:
     f.write(txt)
    FFNMxM()
    return True
  return False
class CCIt4k(CCQOiM):
 def __init__(self, passedSession):
  CCQOiM.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.starttime  = iTime()
  self.timer1   = eTimer()
  self.isFromEOF  = False
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVgOSF, iPlayableService.evEOF: self.VVy1Tc, iPlayableService.evEnd: self.VVSoO4})
  except:
   pass
 def VVgOSF(self):
  self.starttime = iTime()
 def VVy1Tc(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.starttime) > 2:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self.passedSession, isFromSession=True)
    if iptvRef and not FFqt04(decodedUrl):
     span = iSearch(r"(mode=itv.+end=)", decodedUrl, IGNORECASE)
     if span:
      self.isFromEOF = True
     CCus7a(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
 def VVSoO4(self):
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVS47l)
  except:
   self.timer1.callback.append(self.VVS47l)
  self.timer1.start(100, True)
 def VVS47l(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self.passedSession, isFromSession=True)
  valid = False
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVFU1o(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCkjHt.VVBIqe:
       self.isFromEOF = False
       self.VVg09H(self.passedSession, isFromSession=True)
class CCVre4():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.nameTagPatt = r"\s*[\[(|:].*[\])|:](.+)|\s*(?:[^a-z]+:)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.missingUtf8 = VVrM79 and not VVSeco
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "xxi", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.adultWords2 = ("\u042d\u0440\u043e\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0435", "dla doros\u0142ych")
 def VVLT3a(self, name,  censored=""):
  if self.missingUtf8:
   name = str(name.encode('ascii', 'replace').decode('utf-8'))
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCNFtw.VV4uvE(name):
   return CCNFtw.VVDFKy(name)
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    name = span.group(1) or span.group(2)
  return name.strip() or name
 def VVunOm(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  span = iSearch(self.nameTagPatt, name)
  if span:
   name = span.group(1) or span.group(2)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVZ9wa(self, name):
  if self.hideAdult:
   if any(x in name.lower() for x in self.adultWords):
    return ""
   elif any(x in name.encode('ascii', 'backslashreplace').decode('utf-8').lower() for x in self.adultWords2):
    return ""
  return name.strip()
 def VVmOWk(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVIqMS(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCZnqB(CCpWxg):
 def __init__(self):
  CCpWxg.__init__(self)
 def VV8WjW(self):
  if CCZnqB.VVEsd4(self):
   FFb4DW(self, self.VVAsPX, title="Searching ...")
 def VVqvP4(self, winSession, url, mac):
  if CCZnqB.VVEsd4(self):
   if self.VVB1qz(url, mac):
    FFb4DW(winSession, self.VVaVFi, title="Checking Server ...")
   else:
    FF3wnI(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVAsPX(self):
  path = CCNFtw.VVuKzP()
  lines = FFo68R('find %s %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % (path, FFN326(1)))
  if lines:
   lines.sort()
   VV64WM = []
   for line in lines:
    VV64WM.append((line, line))
   OKBtnFnc  = self.VVHl1T
   VV78RH = ("Delete File", self.VV4DEq)
   FFUdxd(self, None, title="Select Portals File", VV64WM=VV64WM, width=1200, OKBtnFnc=OKBtnFnc, VV78RH=VV78RH)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FF3wnI(self, 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt)
 def VV4DEq(self, VVd1c8Obj, path):
  FFysO2(self, boundFunction(self.VVBnwo, VVd1c8Obj, path), "Delete this file ?\n\n%s" % path)
 def VVBnwo(self, VVd1c8Obj, path):
  os.system(FFUJYt("rm -f '%s'" % path))
  if fileExists(path) : FFmoBc(VVd1c8Obj, "Not deleted", 1000)
  else    : VVd1c8Obj.VVlcxr()
 def VVHl1T(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CCAv2L.VVpb9U(path, self)
   if enc == -1:
    return
   self.session.open(CCbVFf, barTheme=CCbVFf.VVkoHr
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVRrtZ, path, enc)
       , VVtktQ = boundFunction(self.VVm1xj, menuInstance, path))
 def VVRrtZ(self, path, enc, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  progBarObj.VVTUhX(totLines)
  progBarObj.VVoIwV = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VV7qoF(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVdmaJ(url)
     mac  = self.VVLrZ0(mac)
     if host and mac and progBarObj:
      progBarObj.VVoIwV.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVdmaJ(url)
      mac  = self.VVLrZ0(mac)
      if host and mac and not mac.startswith("AC") and progBarObj:
       progBarObj.VVoIwV.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVm1xj(self, menuInstance, path, VVJ8JJ, VVoIwV, threadCounter, threadTotal, threadErr):
  title = "Portals List File"
  if VVoIwV:
   VVFile  = ("Home Menu", FFOWIb, [])
   VVDrmo  = None #("Check & Filter" , boundFunction(self.filterPortalAuthorizedServers, path), [])
   VVHxLO = ("Edit File" , boundFunction(self.VVGo9r, path) , [])
   VVVDdh = ("Open as M3U", self.VVkXHN     , [])
   VVyMeP  = ("Select"  , self.VVqvP4_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVnesb  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVMB3d = FFynj9(self, None, title=title, header=header, VVATVO=VVoIwV, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=26, VVyMeP=VVyMeP, VVFile=VVFile, VVVDdh=VVVDdh, VVHxLO=VVHxLO, VVDrmo=VVDrmo, VVPUaR="#0a001122", VV1PI5="#0a001122", VVLubA="#0a001122", VVrJH1="#00004455", VVndWP="#0a333333", VVleo7="#11331100", VVzmtH=True, searchCol=1)
   if not VVJ8JJ:
    FFmoBc(VVMB3d, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVJ8JJ:
    FF3wnI(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVkXHN(self, VVMB3d, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  FFb4DW(VVMB3d, boundFunction(self.VVu2wp, VVMB3d, host, mac), title="Checking Server ...")
 def VVu2wp(self, VVMB3d, host, mac):
  p = CCpWxg()
  m3u_Url = ""
  ok = p.VVB1qz(host, mac, VVuaY6=False)
  err = ""
  if ok:
   m3u_Url, err = p.VVAFK0(VVuaY6=False)
  title = "Browsing M3U Server from Portal Data"
  if m3u_Url:
   self.VVENEF(title, m3u_Url)
  else:
   FF3wnI(self, err or "No response from Server !", title=title)
 def VVqvP4_fromMacFiles(self, VVMB3d, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVqvP4(VVMB3d, url, mac)
 def VVGo9r(self, path, VVMB3d, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCfUC2(self, path, VVtktQ=boundFunction(self.VVedl7, VVMB3d), curRowNum=rowNum)
  else    : FFTvTY(self, path)
 def VVBY30(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FF27My(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVaVFi(self):
  token, profile, tErr = self.VVcrCo()
  if token:
   dots = "." * self.portal_moreAuthType
   VV64WM  = self.VVkLJq()
   OKBtnFnc = self.VVNfJ1
   VVZg0c = ("Home Menu", FFOWIb)
   VVY0ds = ("Bookmark Server", boundFunction(CCNFtw.VVh1gi, self, True, self.VVqiSe + "\t" + self.VVjS4W))
   FFUdxd(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVjS4W, dots), VV64WM=VV64WM, OKBtnFnc=OKBtnFnc, VVZg0c=VVZg0c, VVY0ds=VVY0ds)
 def VVNfJ1(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFb4DW(menuInstance, boundFunction(self.VVH13p, mode), title="Reading Categories ...")
   else : FFb4DW(menuInstance, boundFunction(self.VVX8xT, menuInstance, title), title="Reading Account ...")
 def VVX8xT(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVIRlK(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVjS4W)
  VVFile  = ("Home Menu" , FFOWIb            , [])
  VVVDdh  = None
  if VVj3zx:
   VVVDdh = ("Get JS"  , boundFunction(self.VVELla, self.VVqiSe) , [])
  if totCols == 2:
   VVDrmo = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVDrmo = ("More Info.", boundFunction(self.VVPlNw, menuInstance) , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFynj9(self, None, title=title, width=1200, header=header, VVATVO=rows, VVeJNW=widths, VV4RrQ=26, VVFile=VVFile, VVVDdh=VVVDdh, VVDrmo=VVDrmo, VVPUaR="#0a00292B", VV1PI5="#0a002126", VVLubA="#0a002126", VVrJH1="#00000000", searchCol=searchCol)
 def VVELla(self, url, VVMB3d, title, txt, colList):
  FFb4DW(VVMB3d, boundFunction(self.VVT3bh, url), title="Getting JS ...")
 def VVT3bh(self, url):
  txt = "// Host\t: %s\n" % url
  res, err = self.VV83MV("%s/c/version.js" % url)
  if not err: ver = res.text
  else   : ver = "Error: %s" % err
  txt += "// Version\t: %s\n" % ver
  res, err = self.VV83MV("%s/c/xpcom.common.js" % url)
  if not err: js = res.text
  else   : js = "Error: %s" % err
  txt += "\n%s" % js
  FFR6iW(self, txt, title="JS Info", canSaveToFile="Server_xpcom.common.js")
 def VVPlNw(self, menuInstance, VVMB3d, title, txt, colList):
  VVMB3d.cancel()
  FFb4DW(menuInstance, boundFunction(self.VVX8xT, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVH13p(self, mode):
  token, profile, tErr = self.VVcrCo()
  if not token:
   return
  res, err = self.VV83MV(self.VVqg0F(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CCVre4()
     chList = tDict["js"]
     for item in chList:
      Id   = CCNFtw.VVmQRI(item, "id"       )
      Title  = CCNFtw.VVmQRI(item, "title"      )
      censored = CCNFtw.VVmQRI(item, "censored"     )
      Title = processChanName.VVZ9wa(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVj3zx:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVsSOA(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVPUaR, VV1PI5, VVLubA, VVrJH1 = self.VVUR6Q(mode)
   mName = self.VVsSOA(mode)
   VVyMeP   = ("Show List"   , boundFunction(self.VVYJZu, mode) , [])
   VVFile  = ("Home Menu"   , FFOWIb         , [])
   if mode in ("vod", "series"):
    VVHxLO = ("Find in %s" % mName , boundFunction(self.VVy1wr, mode), [])
   else:
    VVHxLO = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFynj9(self, None, title=title, width=1200, header=header, VVATVO=list, VVeJNW=widths, VV4RrQ=30, VVFile=VVFile, VVHxLO=VVHxLO, VVyMeP=VVyMeP, VVPUaR=VVPUaR, VV1PI5=VV1PI5, VVLubA=VVLubA, VVrJH1=VVrJH1)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.portal_moreAuthMsg:
     txt += "\n\n( %s )" % self.portal_moreAuthMsg
   else:
    txt = "Could not get Categories from server!"
   FF3wnI(self, txt, title=title)
 def VVmzJW(self, mode, VVMB3d, title, txt, colList):
  FFb4DW(VVMB3d, boundFunction(self.VVTXRS, mode, VVMB3d, title, txt, colList), title="Downloading ...")
 def VVTXRS(self, mode, VVMB3d, title, txt, colList):
  token, profile, tErr = self.VVcrCo()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VV83MV(self.VVKLNw(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCNFtw.VVmQRI(item, "id"    )
      actors   = CCNFtw.VVmQRI(item, "actors"   )
      added   = CCNFtw.VVmQRI(item, "added"   )
      age    = CCNFtw.VVmQRI(item, "age"   )
      category_id  = CCNFtw.VVmQRI(item, "category_id" )
      description  = CCNFtw.VVmQRI(item, "description" )
      director  = CCNFtw.VVmQRI(item, "director"  )
      genres_str  = CCNFtw.VVmQRI(item, "genres_str"  )
      name   = CCNFtw.VVmQRI(item, "name"   )
      path   = CCNFtw.VVmQRI(item, "path"   )
      screenshot_uri = CCNFtw.VVmQRI(item, "screenshot_uri" )
      series   = CCNFtw.VVmQRI(item, "series"   )
      cmd    = CCNFtw.VVmQRI(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VVyMeP  = ("Play"    , boundFunction(self.VVwuG8, mode)       , [])
   VV4SDx = (""     , boundFunction(self.VVT3aP, mode)     , [])
   VVFile = ("Home Menu"   , FFOWIb               , [])
   VVVDdh = ("Download Options" , boundFunction(self.VVvZzA, mode, "sp", seriesName) , [])
   VVHxLO = ("Options" , boundFunction(self.VVgJ8Y, 0, "pEp", mode, seriesName)  , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVnesb  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFynj9(self, None, title=seriesName, width=1200, header=header, VVATVO=list, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=26, VVFile=VVFile, VVVDdh=VVVDdh, VVHxLO=VVHxLO, VVyMeP=VVyMeP, VV4SDx=VV4SDx, VVPUaR="#0a00292B", VV1PI5="#0a002126", VVLubA="#0a002126", VVrJH1="#00000000")
  else:
   FF3wnI(self, "Could not get Episodes from server!", title=seriesName)
 def VVy1wr(self, mode, VVMB3d, title, txt, colList):
  VV64WM = []
  VV64WM.append(("Keyboard"  , "manualEntry"))
  VV64WM.append(("From Filter" , "fromFilter"))
  FFUdxd(self, boundFunction(self.VVAi5H, VVMB3d, mode), title="Input Type", VV64WM=VV64WM, width=400)
 def VVAi5H(self, VVMB3d, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFaNVN(self, boundFunction(self.VVTsfO, VVMB3d, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCbhk5(self)
    filterObj.VVghZC(boundFunction(self.VVTsfO, VVMB3d, mode))
 def VVTsfO(self, VVMB3d, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VV7h9k(mode, searchName)
   if len(searchName) < 3:
    FF3wnI(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CCVre4()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVmOWk([searchName]):
     FF3wnI(self, processChanName.VVIqMS(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVtuXo(mode, searchName, "", searchName)
 def VVYJZu(self, mode, VVMB3d, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVtuXo(mode, bName, catID, "")
 def VVtuXo(self, mode, bName, catID, searchName):
  self.session.open(CCbVFf, barTheme=CCbVFf.VVkoHr
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVtYU5, mode, bName, catID, searchName)
      , VVtktQ = boundFunction(self.VVXdNq, mode, bName, catID, searchName))
 def VVXdNq(self, mode, bName, catID, searchName, VVJ8JJ, VVoIwV, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VV7h9k(mode, searchName)
  else   : title = "%s : %s" % (self.VVsSOA(mode), bName)
  if VVoIwV:
   VVVDdh = None
   VVHxLO = None
   if mode == "series":
    VVPUaR, VV1PI5, VVLubA, VVrJH1 = self.VVUR6Q("series2")
    VVyMeP  = ("Episodes", boundFunction(self.VVmzJW, mode) , [])
   else:
    VVPUaR, VV1PI5, VVLubA, VVrJH1 = self.VVUR6Q("")
    VVyMeP  = ("Play"    , boundFunction(self.VVwuG8, mode)           , [])
    VVVDdh = ("Download Options" , boundFunction(self.VVvZzA, mode, "vp" if mode == "vod" else "", "") , [])
    VVHxLO = ("Options"   , boundFunction(self.VVgJ8Y, 1, "pCh", mode, bName)      , [])
   VV4SDx = (""      , boundFunction(self.VVxckE, mode)          , [])
   VVFile = ("Home Menu"    , FFOWIb                   , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVnesb  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT )
   VVMB3d = FFynj9(self, None, title=title, header=header, VVATVO=VVoIwV, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=26, VVFile=VVFile, VVVDdh=VVVDdh, VVHxLO=VVHxLO, VVyMeP=VVyMeP, VV4SDx=VV4SDx, VVPUaR=VVPUaR, VV1PI5=VV1PI5, VVLubA=VVLubA, VVrJH1=VVrJH1, VVzmtH=True, searchCol=1)
   if not VVJ8JJ:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVMB3d.VVsmoP(VVMB3d.VVIwKq() + tot)
    if threadErr: FFmoBc(VVMB3d, "Error while reading !", 2000)
    else  : FFmoBc(VVMB3d, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FF3wnI(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FF3wnI(self, "Could not get list from server !", title=title)
 def VVxckE(self, mode, VVMB3d, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFt65h(self, fncMode=CCc6Hf.VVsgkw, portalHost=self.VVqiSe, portalMac=self.VVjS4W, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVpJbz(mode, VVMB3d, title, txt, colList)
 def VVT3aP(self, mode, VVMB3d, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFtsFe(colList[10], VVBPJz)
  txt += "Description:\n%s" % FFtsFe(colList[11], VVBPJz)
  self.VVpJbz(mode, VVMB3d, title, txt, colList)
 def VVpJbz(self, mode, VVMB3d, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVlB9l(mode, colList)
  refCode, chUrl = self.VVNbg1(self.VVqiSe, self.VVjS4W, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFt65h(self, fncMode=CCc6Hf.VVRvdl, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVtYU5(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile, tErr = self.VVcrCo()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVoIwV, total_items, max_page_items, err = self.VVxC41(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVoIwV and total_items > -1 and max_page_items > -1:
    progBarObj.VVTUhX(total_items)
    progBarObj.VV7qoF(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVxC41(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VV4YWC()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVoIwV += list
      progBarObj.VV7qoF(len(list), True)
  except:
   pass
 def VVxC41(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVvNxu(mode, searchName, page)
  else   : url = self.VVtPsF(mode, catID, page)
  res, err = self.VV83MV(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVTdo0(CCNFtw.VVmQRI(item, "total_items" ))
     max_page_items = self.VVTdo0(CCNFtw.VVmQRI(item, "max_page_items" ))
     processChanName = CCVre4()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCNFtw.VVmQRI(item, "id"    )
      name   = CCNFtw.VVmQRI(item, "name"   )
      tv_genre_id  = CCNFtw.VVmQRI(item, "tv_genre_id" )
      number   = CCNFtw.VVmQRI(item, "number"   ) or str(counter)
      logo   = CCNFtw.VVmQRI(item, "logo"   )
      screenshot_uri = CCNFtw.VVmQRI(item, "screenshot_uri" )
      cmd    = CCNFtw.VVmQRI(item, "cmd"   )
      censored  = CCNFtw.VVmQRI(item, "censored"  )
      cmd = cmd.replace("ffmpeg ", "")
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8"):
       span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
      cmd = cmd.replace("auto ", "")
      picon = logo or screenshot_uri
      counter += 1
      name = processChanName.VVLT3a(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVbtUy(self, mode, bName, VVMB3d, title, txt, colList):
  bNameFile = CCNFtw.VVEkpK_forBouquet(bName)
  num  = 0
  path = VVgmxK + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVgmxK + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   isMulti = VVMB3d.VVoduh
   for ndx, row in enumerate(VVMB3d.VVsLdG()):
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVlB9l(mode, row)
    refCode, chUrl = self.VVNbg1(self.VVqiSe, self.VVjS4W, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    if not isMulti or VVMB3d.VVlaxk(ndx):
     f.write("#SERVICE %s\n"  % chUrl)
     f.write("#DESCRIPTION %s\n" % chName)
     totChange += 1
  FF5Fv9(os.path.basename(path))
  self.VVl970(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVTdo0(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVwuG8(self, mode, VVMB3d, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVlB9l(mode, colList)
  refCode, chUrl = self.VVNbg1(self.VVqiSe, self.VVjS4W, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VV4uvE(chName):
   FFmoBc(VVMB3d, "This is a marker!", 300)
  else:
   FFb4DW(VVMB3d, boundFunction(self.VVSLLb, mode, VVMB3d, chUrl), title="Playing ...")
 def VVSLLb(self, mode, VVMB3d, chUrl):
  FFtcar(self, chUrl, VVdsme=False)
  self.session.open(CCkjHt, portalTableParam=(self, VVMB3d, mode))
 def VVuV0f(self, mode, VVMB3d, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVlB9l(mode, colList)
  refCode, chUrl = self.VVNbg1(self.VVqiSe, self.VVjS4W, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVlB9l(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVEsd4(SELF):
  try:
   import requests
   return True
  except:
   FFysO2(SELF, boundFunction(CCZnqB.VVbBz4, SELF), 'This requires the library "Requests".\n\nInstall it now ?')
   return False
 @staticmethod
 def VVbBz4(SELF):
  from sys import version_info
  cmdUpd = FF5FY1(VVzrCb, "")
  if cmdUpd:
   cmdInst = FFU7ig(VVMxji, "python-requests")
   if version_info[0] >= 3:
    cmdInst = cmdInst.replace("python-", "python3-")
   cmd = cmdUpd + " && " + cmdInst
   FFSA5Q(SELF, cmd, checkNetAccess=True, title="Installing Requests Library")
  else:
   FFdiGu(SELF)
class CCNFtw(Screen, CCZnqB):
 VV3CeI    = 0
 VVxuNP    = 1
 VV0dPO    = 2
 VVwE48    = 3
 VVifgL     = 4
 VV5CI8     = 5
 VVAssr     = 6
 VV6oyi     = 7
 VVxf7w      = 8
 VVDUE2     = 9
 VVyUt5     = 10
 VVb9BY     = 11
 VVdke6     = 12
 VVoyy0      = 13
 VVaMyB      = 14
 VVzAC0      = 15
 VVlv91      = 16
 VVm0rM      = 17
 VVaVXF    = 0
 VVtemc   = 1
 VVACIN   = 2
 VVgqDe   = 3
 VVMeRe  = 4
 VVydBq  = 5
 VVOCls   = 6
 VVbMHV   = 7
 VVpiYc  = 8
 VVgt49  = 9
 VVJ65D  = 10
 VVcm3f = 0
 VVdqMQ = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFhdcK(VVDXvw, 1000, 1000, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.m3uOrM3u8File  = m3uOrM3u8File
  self.m3uOrM3u8BName  = ""
  self.VVMB3d  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVBcpRData  = {}
  self.lastFindIptvName = ""
  CCZnqB.__init__(self)
  VV64WM= self.VV4uJJ()
  FFFgql(self, title="IPTV", VV64WM=VV64WM)
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FFH9Ay(self["myMenu"])
  FFq9fK(self)
  FF5ZRH(self)
  if self.m3uOrM3u8File:
   self.VVZEoN(self.m3uOrM3u8File)
 def VV4uJJ(self):
  files = self.VVrPLz()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"        , "VVBcpR_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal List)"        , "VVBcpR_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)"    , "VVBcpR_fromM3u"  ))
  qUrl, iptvRef = self.VVJgs0()
  if qUrl or "chCode" in iptvRef:
   tList.append(("IPTV Server Browser (from Current Channel)"      , "VVBcpR_fromCurrChan" ))
  VV64WM = []
  if files:
   if self.VVMB3d:
    VV64WM.append(("Add Current List to a New Bouquet"      , "VVzGO7"  ))
    VV64WM.append(VVB35E)
    VV64WM.append(("Change Current List References to Unique Codes"   , "VVp1vu"))
    VV64WM.append(("Change Current List References to Identical Codes"  , "VVfPOX_rows" ))
    VV64WM.append(VVB35E)
    VV64WM.append(("Share Reference with Satellite/C/T Service (manual entry)", "VVKJkN"   ))
    VV64WM.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VVtdkE"   ))
   else:
    VV64WM += tList
    VV64WM.append(VVB35E)
    VV64WM.append(("M3U/M3U8 Channels Browser"        , "VVErDs"   ))
    VV64WM.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    if qUrl:
     VV64WM.append(VVB35E)
     VV64WM.append(("Update Current Bouquet EPG (from IPTV Server)"  , "refreshIptvEPG"   ))
    VV64WM.append(VVB35E)
    VV64WM.append(("Count Available IPTV Channels"       , "VV2Yn0"    ))
    VV64WM.append(("Check Reference Codes Format"        , "VVWjNs"   ))
    VV64WM.append(("Check System Acceptable Reference Types"     , "VVwU4K"   ))
    VV64WM.append(VVB35E)
    VV64WM.append(("Share Reference with Sat./C/T (Only Matching Names)"  , "VVdMrZ" ))
    VV64WM.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVdp33"  ))
    VV64WM.append(("Change ALL References to Unique Codes"     , "VVt3oi" ))
    VV64WM.append(("Change ALL References to Identical Codes"     , "VVfPOX_all" ))
  if not self.VVMB3d:
   if not files:
    VV64WM += tList
   if not CCL4WW.VVTjd7():
    VV64WM.append(VVB35E)
    VV64WM.append(("Download Manager"           , "dload_stat"    ))
  return VV64WM
 def VVxfNt(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVzGO7"   : FFaNVN(self, self.VVzGO7, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVp1vu" : FFysO2(self, boundFunction(FFb4DW, self.VVMB3d, self.VVp1vu ), "Change Current List References to Unique Codes ?")
   elif item == "VVfPOX_rows" : FFysO2(self, boundFunction(FFb4DW, self.VVMB3d, self.VVfPOX   ), "Change Current List References to Identical Codes ?")
   elif item == "VVKJkN"   : self.VVKJkN(tTitle)
   elif item == "VVtdkE"   : self.VVtdkE(tTitle)
   elif item == "VVBcpR_fromPlayList" : FFb4DW(self, self.VVK71N, title=title)
   elif item == "VVBcpR_fromM3u"  : FFb4DW(self, boundFunction(self.VVw5Sv, 0), title=title)
   elif item == "VVBcpR_fromMac"  : self.VV8WjW()
   elif item == "VVBcpR_fromCurrChan" : self.VVqvP4_fromCurrChan()
   elif item == "VVErDs"   : self.VVErDs()
   elif item == "iptvTable_live"   : FFb4DW(self, boundFunction(self.VVQTds, self.VV6oyi ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFb4DW(self, boundFunction(self.VVQTds, self.VV3CeI) , title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VV7kJg()
   elif item == "VV2Yn0"    : FFb4DW(self, self.VV2Yn0)
   elif item == "VVWjNs"    : FFb4DW(self, self.VVWjNs)
   elif item == "VVwU4K"   : FFb4DW(self, self.VVwU4K)
   elif item == "VVdMrZ"  : FFysO2(self, boundFunction(FFb4DW, self, self.VVdMrZ ), "Continue ?")
   elif item == "VVdp33"  : self.VVdp33()
   elif item == "VVt3oi" : FFysO2(self, boundFunction(FFb4DW, self, self.VVt3oi ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVfPOX_all" : FFysO2(self, boundFunction(FFb4DW, self, self.VVfPOX  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "dload_stat"    : CCL4WW.VVp5QA(self)
   elif item == "VVWdvr"   : FFb4DW(self, boundFunction(CCs1x9.VVWdvr, self))
 def VVErDs(self):
  if CCZnqB.VVEsd4(self):
   FFb4DW(self, boundFunction(self.VVw5Sv, 1), title="Searching ...")
 def VVhHBt(self):
  global VVWyR9
  VVWyR9 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVxfNt(item)
 def VVQTds(self, mode):
  VV3CuM = self.VVp7H0(mode)
  if VV3CuM:
   VVVDdh = ("Current Service", self.VVdBl9  , [])
   VVHxLO = ("Options"  , self.VVgnQ3    , [])
   VVDrmo = ("Filter"   , self.VVefig    , [])
   VVyMeP  = ("Play"   , boundFunction(self.VVCb5u) , [])
   VV4SDx = (""    , self.VVOBWD     , [])
   VVz2py = (""    , self.VV8Hrw      , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVnesb  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFynj9(self, None, header=header, VVATVO=VV3CuM, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=26
     , VVyMeP=VVyMeP, VVVDdh=VVVDdh, VVHxLO=VVHxLO, VVDrmo=VVDrmo, VV4SDx=VV4SDx, VVz2py=VVz2py
     , VVPUaR="#0a00292B", VV1PI5="#0a002126", VVLubA="#0a002126", VVrJH1="#00000000", VVzmtH=True, searchCol=1)
  else:
   if mode == self.VV6oyi: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FF3wnI(self, err)
 def VV8Hrw(self, VVMB3d, title, txt, colList):
  self.VVMB3d = VVMB3d
 def VVgnQ3(self, VVMB3d, title, txt, colList):
  VV64WM= self.VV4uJJ()
  FFUdxd(self, self.VVxfNt, title="IPTV Tools", VV64WM=VV64WM)
 def VVefig(self, VVMB3d, title, txt, colList):
  VV64WM = []
  VV64WM.append(("All"         , "all"   ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Prefix of Selected Channel"   , "sameName" ))
  VV64WM.append(("Suggest Words from Selected Channel" , "partName" ))
  VV64WM.append(("Names with Non-English Characters" , "nonEnglish" ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Live TV"        , "live"  ))
  VV64WM.append(("VOD"         , "vod"   ))
  VV64WM.append(("Series"        , "series"  ))
  VV64WM.append(("Uncategorised"      , "uncat"  ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Video"        , "video"  ))
  VV64WM.append(("Audio"        , "audio"  ))
  VV64WM.append(VVB35E)
  VV64WM.append(("MKV"         , "MKV"   ))
  VV64WM.append(("MP4"         , "MP4"   ))
  VV64WM.append(("MP3"         , "MP3"   ))
  VV64WM.append(("AVI"         , "AVI"   ))
  VV64WM.append(("FLV"         , "FLV"   ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVwFCw()
  if bNames:
   bNames.sort()
   VV64WM.append(VVB35E)
   for item in bNames:
    VV64WM.append((item, "__b__" + item))
  filterObj = CCbhk5(self)
  filterObj.VVUzgW(VV64WM, VV64WM, boundFunction(self.VVtkom, VVMB3d))
 def VVtkom(self, VVMB3d, item=None):
  prefix = VVMB3d.VVits3(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VV3CeI, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVxuNP , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VV0dPO , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVwE48 , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VV6oyi  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVxf7w   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVDUE2  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVyUt5  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVb9BY  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVdke6  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVoyy0   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVaMyB   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVzAC0   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVlv91   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVm0rM   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVAssr  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVifgL  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VV5CI8  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VV0dPO:
   VV64WM = []
   chName = VVMB3d.VVits3(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VV64WM.append((item, item))
    if not VV64WM and chName:
     VV64WM.append((chName, chName))
    FFUdxd(self, boundFunction(self.VVKl18_partOfName, title), title="Words from Current Selection", VV64WM=VV64WM)
   else:
    VVMB3d.VVettN("Invalid Channel Name")
  else:
   words, asPrefix = CCbhk5.VVQhDw(words)
   if not words and mode in (self.VVifgL, self.VV5CI8):
    FFmoBc(self.VVMB3d, "Incorrect filter", 2000)
   else:
    FFb4DW(self.VVMB3d, boundFunction(self.VVwOeA, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVKl18_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFb4DW(self.VVMB3d, boundFunction(self.VVwOeA, self.VV0dPO, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVDFKy(txt):
  return "#f#11ffff00#" + txt
 def VVwOeA(self, mode, words, asPrefix, title):
  VV3CuM = self.VVp7H0(mode=mode, words=words, asPrefix=asPrefix)
  if VV3CuM : self.VVMB3d.VVr5NB(VV3CuM, title)
  else  : self.VVMB3d.VVettN("Not found")
 def VVp7H0(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VV3CuM = []
  files  = self.VVrPLz()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFP7TV(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVZnFN = span.group(1)
    else : VVZnFN = ""
    VVZnFN_lCase = VVZnFN.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VV4uvE(chName): chNameMod = self.VVDFKy(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVZnFN, chType, refCode, url)
     ok = False
     tUrl = FFqMjA(url).lower()
     if mode == self.VV3CeI       : ok = True
     elif mode == self.VVAssr       : ok = True
     elif mode == self.VVb9BY:
      if CCNFtw.VVH2YO(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVdke6:
      if CCNFtw.VVH2YO(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VV6oyi:
      if CCNFtw.VVH2YO(tUrl, compareType="live")  : ok = True
     elif mode == self.VVxf7w:
      if CCNFtw.VVH2YO(tUrl, compareType="movie") : ok = True
     elif mode == self.VVDUE2:
      if CCNFtw.VVH2YO(tUrl, compareType="series") : ok = True
     elif mode == self.VVyUt5:
      if CCNFtw.VVH2YO(tUrl, compareType="")   : ok = True
     elif mode == self.VVoyy0:
      if CCNFtw.VVH2YO(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVaMyB:
      if CCNFtw.VVH2YO(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVzAC0:
      if CCNFtw.VVH2YO(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVlv91:
      if CCNFtw.VVH2YO(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVm0rM:
      if CCNFtw.VVH2YO(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVxuNP:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VV0dPO:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVwE48:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVifgL:
      if words[0] == VVZnFN_lCase:
       ok = True
     elif mode == self.VV5CI8:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VV3CuM.append(row)
      chNum += 1
  if VV3CuM and mode == self.VVAssr:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VV3CuM)
   for item in VV3CuM:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VV3CuM = newRows
  return VV3CuM
 def VVzGO7(self, bName):
  if bName:
   FFb4DW(self.VVMB3d, boundFunction(self.VV3v7r, bName), title="Adding Channels ...")
 def VV3v7r(self, bName):
  num = 0
  path = VVgmxK + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVgmxK + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVMB3d.VVsLdG():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFWesU(row[1]))
    totChange += 1
  FF5Fv9(os.path.basename(path))
  self.VVl970(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVdp33(self):
  txt = "Stream Type "
  VV64WM = []
  VV64WM.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VV64WM.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VV64WM.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VV64WM.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VV64WM.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VV64WM.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFUdxd(self, self.VV7U7d, title="Change Reference Types to:", VV64WM=VV64WM)
 def VV7U7d(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVdDdF("1"   )
   elif item == "RT_4097" : self.VVdDdF("4097")
   elif item == "RT_5001" : self.VVdDdF("5001")
   elif item == "RT_5002" : self.VVdDdF("5002")
   elif item == "RT_8192" : self.VVdDdF("8192")
   elif item == "RT_8193" : self.VVdDdF("8193")
 def VVdDdF(self, rType):
  FFysO2(self, boundFunction(FFb4DW, self, boundFunction(self.VVOus7, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVOus7(self, refType):
  totChange = 0
  files  = self.VVrPLz()
  if files:
   for path in files:
    txt = FFP7TV(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FF5Fv9(os.path.basename(path))
  self.VVl970(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VV2Yn0(self):
  totFiles = 0
  files  = self.VVrPLz()
  if files:
   totFiles = len(files)
  totChans = 0
  VV3CuM = self.VVp7H0()
  if VV3CuM:
   totChans = len(VV3CuM)
  FFR6iW(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVWjNs(self):
  files  = self.VVrPLz()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFP7TV(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVAexn
   else    : color = VVValh
   totInvalid = FFtsFe(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFtsFe("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFR6iW(self, txt, title="Check IPTV References")
 def VVwU4K(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVgmxK + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FF5Fv9(os.path.basename(path))
  FFNMxM()
  acceptedList = []
  VVa1Lj = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVa1Lj:
   VVUckK = FFMx0N(VVa1Lj)
   if VVUckK:
    for service in VVUckK:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVgmxK + userBName
  bFile = VVgmxK + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFUJYt("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFUJYt("rm -f '%s'" % path)
  os.system(cmd)
  FFNMxM()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVAexn
    else     : res, color = "No" , VVValh
    txt += "    %s\t: %s\n" % (item, FFtsFe(res, color))
   FFR6iW(self, txt, title=title)
  else:
   txt = FF3wnI(self, "Could not complete the test on your system!", title=title)
 def VVdMrZ(self):
  lameDbChans = CCs1x9.VVNwh8(self, CCs1x9.VVwIG3)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVrPLz():
    toSave = False
    txt = FFP7TV(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVl970(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FF3wnI(self, 'No channels in "lamedb" !')
 def VVt3oi(self):
  files  = self.VVrPLz()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFK66c(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVvGpJ(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVl970(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVp1vu(self):
  iptvRefList = []
  files  = self.VVrPLz()
  if files:
   for path in files:
    txt = FFP7TV(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVMB3d.VVsBri(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVvGpJ(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVrPLz()
  if files:
   for path in files:
    lines = FFK66c(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVl970(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVvGpJ(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVfPOX(self):
  list = None
  if self.VVMB3d:
   list = []
   for row in self.VVMB3d.VVsLdG():
    list.append(row[4] + row[5])
  files  = self.VVrPLz()
  totChange = 0
  if files:
   for path in files:
    lines = FFK66c(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVl970(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVl970(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFNMxM()
   if refreshTable and self.VVMB3d:
    VV3CuM = self.VVp7H0()
    if VV3CuM and self.VVMB3d:
     self.VVMB3d.VVr5NB(VV3CuM, self.tableTitle)
     self.VVMB3d.VVettN(txt)
   FFR6iW(self, txt, title=title)
  else:
   FFi9RU(self, "No changes.")
 def VVwFCw(self):
  files = self.VVrPLz()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with ioOpen(path, "r", encoding="utf-8") as f:
     span = iSearch(r"#NAME\s+(.*)", str(f.readline()), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VV9JnC = FFtsF4()
    if VV9JnC:
     for b in VV9JnC:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVrPLz(self):
  return CCNFtw.VVWx7c(self)
 @staticmethod
 def VVWx7c(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVgmxK + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFP7TV(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVOBWD(self, VVMB3d, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFqMjA(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFt65h(self, fncMode=CCc6Hf.VV07WG, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVm4i5(self, VVMB3d, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVCb5u(self, VVMB3d, title, txt, colList):
  chName, chUrl = self.VVm4i5(VVMB3d, colList)
  self.VVaJE1(VVMB3d, chName, chUrl, "localIptv")
 def VVIbHh(self, mode, VVMB3d, colList):
  chName, chUrl, picUrl, refCode = self.VVytmW(mode, colList)
  return chName, chUrl
 def VV62qV(self, mode, VVMB3d, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVytmW(mode, colList)
  self.VVaJE1(VVMB3d, chName, chUrl, mode)
 def VVaJE1(self, VVMB3d, chName, chUrl, playerFlag):
  chName = FFWesU(chName)
  if self.VV4uvE(chName):
   FFmoBc(VVMB3d, "This is a marker!", 300)
  else:
   FFb4DW(VVMB3d, boundFunction(self.VVJWHJ, VVMB3d, chUrl, playerFlag), title="Playing ...")
 def VVJWHJ(self, VVMB3d, chUrl, playerFlag):
  FFtcar(self, chUrl, VVdsme=False)
  self.session.open(CCkjHt, portalTableParam=(self, VVMB3d, playerFlag))
 @staticmethod
 def VV4uvE(chName):
  mark = ("--", "__", "==", "##", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVdBl9(self, VVMB3d, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self)
  if refCode:
   bName = FFOHyc()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFYZPy(refCode, origUrl, chName) }
   VVMB3d.VV8QRM_partial(colDict, VVuaY6=True)
 def VVw5Sv(self, m3uMode):
  path = CCNFtw.VVuKzP()
  lines = FFo68R("find %s %s -iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'" % (path, FFN326(1)))
  if lines:
   lines.sort()
   VV64WM = []
   for line in lines:
    VV64WM.append((line, line))
   if m3uMode == self.VVcm3f:
    title = "Browse Server from M3U URLs"
    VVY0ds = ("All to Playlist", self.VVP8hp)
   else:
    title = "M3U/M3U8 Channels Browser"
    VVY0ds = None
   OKBtnFnc = boundFunction(self.VVrycu, m3uMode, title)
   VVJA2t  = ("Show Full Path", self.VVpVsn)
   VV78RH = ("Delete File", self.VV4DEq)
   FFUdxd(self, None, title=title, VV64WM=VV64WM, width=1200, OKBtnFnc=OKBtnFnc, VVJA2t=VVJA2t, VV78RH=VV78RH, VVY0ds=VVY0ds)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n\n%s" % path
   FF3wnI(self, 'No ".m3u" files found %s' % txt)
 def VVpVsn(self, VVd1c8Obj, url):
  FFR6iW(self, url, title="Full Path")
 def VVrycu(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == self.VVcm3f:
    FFb4DW(menuInstance, boundFunction(self.VVI2eR, title, path))
   else:
    FFb4DW(menuInstance, boundFunction(self.VVZEoN, path))
 def VVZEoN(self, srcPath):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFP7TV(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  processChanName = CCVre4()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVgWlv(propLine, "group-title") or "-"
   if not group == "-" and processChanName.VVLT3a(group):
    groups.add(group)
  VV3CuM = []
  if len(groups) > 0:
   title = "Groups"
   for group in groups:
    VV3CuM.append((group, group))
   VV3CuM.append(("ALL", ""))
   VV3CuM.sort(key=lambda x: x[0].lower())
   VVUKxL = self.VVBYsk
   VVyMeP  = ("Select" , boundFunction(self.VV3Zkj, srcPath), [])
   widths   = (100  , 0)
   VVnesb  = (LEFT  , LEFT)
   FFynj9(self, None, title=title, width= 800, header=None, VVATVO=VV3CuM, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=30, VVyMeP=VVyMeP, VVUKxL=VVUKxL
     , VVPUaR="#11110022", VV1PI5="#11110022", VVLubA="#11110022", VVrJH1="#00444400")
  else:
   txt = FFP7TV(srcPath)
   self.VVM2i9(txt, filterGroup="")
 def VV3Zkj(self, srcPath, VVMB3d, title, txt, colList):
  group = colList[1]
  txt = FFP7TV(srcPath)
  self.VVM2i9(txt, filterGroup=group)
 def VVM2i9(self, txt, filterGroup=""):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = "Group : %s" % (filterGroup or "ALL")
  if lst:
   self.session.open(CCbVFf, barTheme=CCbVFf.VVkoHr
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VVDEDb, lst, filterGroup)
       , VVtktQ = boundFunction(self.VVmi2q, title, bName))
  else:
   self.VVBLOC("No valid lines found !", title)
 def VVDEDb(self, lst, filterGroup, progBarObj):
  progBarObj.VVoIwV = []
  progBarObj.VVTUhX(len(lst))
  processChanName = CCVre4()
  num = 0
  for cols in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VV7qoF(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVgWlv(propLine, "tvg-logo")
   group = self.VVgWlv(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if group and not processChanName.VVLT3a(group) : skip = True
    if chName and not processChanName.VVLT3a(chName): skip = True
    if not skip and progBarObj:
     num += 1
     progBarObj.VVoIwV.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if progBarObj:
   progBarObj.VV5fDs_forcedUpdate("Loading %d Channels" % len(progBarObj.VVoIwV))
 def VVmi2q(self, title, bName, VVJ8JJ, VVoIwV, threadCounter, threadTotal, threadErr):
  if VVoIwV:
   VVUKxL = self.VVBYsk
   VVyMeP  = ("Select"    , boundFunction(self.VVtGV4, title) , [])
   VV4SDx = (""     , self.VVlaFz         , [])
   VVVDdh = ("Download PIcons" , self.VVfvOm        , [])
   VVHxLO = ("Options" , boundFunction(self.VVgJ8Y, 1, "m3Ch", "", bName)  , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVnesb  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFynj9(self, None, title=title, header=header, VVATVO=VVoIwV, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=28, VVyMeP=VVyMeP, VVUKxL=VVUKxL, VV4SDx=VV4SDx, VVVDdh=VVVDdh, VVHxLO=VVHxLO, VVzmtH=True, searchCol=1
     , VVPUaR="#0a00192B", VV1PI5="#0a00192B", VVLubA="#0a00192B", VVrJH1="#00000000")
  else:
   self.VVBLOC("No valid lines found !", title)
 def VVfvOm(self, VVMB3d, title, txt, colList):
  self.VVUzOa(VVMB3d, "m3u/m3u8")
 def VV1h7j(self, mode, bName, VVMB3d, title, txt, colList):
  bNameFile = CCNFtw.VVEkpK_forBouquet(bName)
  num  = 0
  path = VVgmxK + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVgmxK + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   catID = "33"
   rowNum = 0
   isMulti = VVMB3d.VVoduh
   for ndx, row in enumerate(VVMB3d.VVsLdG()):
    chName = row[1].strip()
    url  = row[3].strip()
    chUrl = self.VVTf5M(rowNum, url, chName)
    rowNum += 1
    if not isMulti or VVMB3d.VVlaxk(ndx):
     f.write("#SERVICE %s\n"  % chUrl)
     f.write("#DESCRIPTION %s\n" % chName)
     totChange += 1
  FF5Fv9(os.path.basename(path))
  self.VVl970(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVTf5M(self, rowNum, url, chName):
  refCode = self.VVsffd(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFNJUt(url), chName)
  return chUrl
 def VVsffd(self, rowNum, url, chName):
  span = iSearch(r"\/(\d{2,})", url, IGNORECASE)
  if span : stID = span.group(1)
  else : stID = "444"
  catID = "333"
  chNum = str(rowNum + 1)
  refCode = self.VVDd7X(catID, stID, chNum)
  return refCode
 def VVgWlv(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVtGV4(self, Title, VVMB3d, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFb4DW(VVMB3d, boundFunction(self.VVx3BL, Title, VVMB3d, colList), title="Checking Server ...")
  else:
   self.VVKvDq(VVMB3d, url, chName)
 def VVx3BL(self, title, VVMB3d, colList):
  if not CCZnqB.VVEsd4(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCpWxg.VVgMVZ(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VV64WM = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCNFtw.VVqTaq(url, fPath)
     VV64WM.append((resol, fullUrl))
    if VV64WM:
     if len(VV64WM) > 1:
      FFUdxd(self, boundFunction(self.VVVlsm, VVMB3d, chName), VV64WM=VV64WM, title="Resolution", VVecAt=True, VVMYH9=True)
     else:
      self.VVKvDq(VVMB3d, VV64WM[0][1], chName)
    else:
     self.VVuaY6or("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVM2i9(txt, filterGroup="")
      return
    self.VVKvDq(VVMB3d, url, chName)
   else:
    self.VVBLOC("Cannot process this channel !", title)
  else:
   self.VVBLOC(err, title)
 def VVVlsm(self, VVMB3d, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVKvDq(VVMB3d, resolUrl, chName)
 def VVKvDq(self, VVMB3d, url, chName):
  FFb4DW(VVMB3d, boundFunction(self.VVq3pg, VVMB3d, url, chName), title="Playing ...")
 def VVq3pg(self, VVMB3d, url, chName):
  chUrl = self.VVTf5M(VVMB3d.VVdrH0(), url, chName)
  FFtcar(self, chUrl, VVdsme=False)
  self.session.open(CCkjHt, portalTableParam=(self, VVMB3d, "m3u/m3u8"))
 def VVZkgj(self, VVMB3d, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVTf5M(VVMB3d.VVdrH0(), url, chName)
  return chName, chUrl
 def VVlaFz(self, VVMB3d, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFt65h(self, fncMode=CCc6Hf.VV07WG, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVBLOC(self, err, title):
  FF3wnI(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVBYsk(self, VVMB3d):
  if self.m3uOrM3u8File:
   self.close()
  VVMB3d.cancel()
 def VVP8hp(self, VVd1c8Obj, item=None):
  FFb4DW(VVd1c8Obj, boundFunction(self.VVpV47, VVd1c8Obj, item))
 def VVpV47(self, VVd1c8Obj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVd1c8Obj.VV64WM):
    path = item[1]
    if fileExists(path):
     enc = CCAv2L.VVpb9U(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VVWEst(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCNFtw.VVuKzP(orExportPath=True)
    pListF = "%sPlaylist_%s.txt" % (path, FFpkvp())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVd1c8Obj.VV64WM)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFR6iW(self, txt, title=title)
   else:
    FF3wnI(self, "Could not obtain URLs from this file list !", title=title)
 def VVK71N(self):
  path = CCNFtw.VVuKzP()
  lines = FFo68R('find %s %s -iname "*playlist*" | grep -i ".txt"' % (path, FFN326(1)))
  if lines:
   lines.sort()
   VV64WM = []
   for line in lines:
    VV64WM.append((line, line))
   OKBtnFnc  = self.VVCoD4
   VV78RH = ("Delete File", self.VV4DEq)
   FFUdxd(self, None, title="Select Playlist File", VV64WM=VV64WM, width=1200, OKBtnFnc=OKBtnFnc, VV78RH=VV78RH)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FF3wnI(self, 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt)
 def VVCoD4(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFb4DW(menuInstance, boundFunction(self.VVPyDZ, menuInstance, path), title="Processing File ...")
 def VVPyDZ(self, fileMenuInstance, path):
  enc = CCAv2L.VVpb9U(path, self)
  if enc == -1:
   return
  VV3CuM = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0]
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFMXkM(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCNFtw.VV4Hcw(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VV3CuM:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(filter(None, [item[5], item[0]]))
     num += 1
     VV3CuM.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VV3CuM:
   title = "Playlist File"
   VVyMeP  = ("Start"    , boundFunction(self.VVQ84c, title)  , [])
   VVFile = ("Home Menu"   , FFOWIb         , [])
   VVVDdh = ("Download M3U File" , self.VV3Cra     , [])
   VVHxLO = ("Edit File"   , boundFunction(self.VVItS3, path) , [])
   VVDrmo = ("Check & Filter"  , boundFunction(self.VVGkUG, fileMenuInstance, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVnesb  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFynj9(self, None, title=title, header=header, VVATVO=VV3CuM, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=26, VVyMeP=VVyMeP, VVFile=VVFile, VVDrmo=VVDrmo, VVVDdh=VVVDdh, VVHxLO=VVHxLO, VVPUaR="#11001116", VV1PI5="#11001116", VVLubA="#11001116", VVrJH1="#00003635", VVndWP="#0a333333", VVleo7="#11331100", VVzmtH=True)
  else:
   FF3wnI(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VV3Cra(self, VVMB3d, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFysO2(self, boundFunction(FFb4DW, VVMB3d, boundFunction(self.VVs3jw, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVs3jw(self, title, url):
  path, err = FFd8ee(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FF3wnI(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFP7TV(path)
   if '{"user_info":{"auth":0}}' in txt:
    os.system(FFUJYt("rm -f '%s'" % path))
    FF3wnI(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    os.system(FFUJYt("rm -f '%s'" % path))
    FF3wnI(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCNFtw.VVuKzP(orExportPath=True) + fName
    os.system(FFUJYt("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FFi9RU(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FF3wnI(self, "Could not download the M3U file!", title=errTitle)
 def VVQ84c(self, Title, VVMB3d, title, txt, colList):
  url = colList[6]
  FFb4DW(VVMB3d, boundFunction(self.VVENEF, Title, url), title="Checking Server ...")
 def VVItS3(self, path, VVMB3d, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCfUC2(self, path, VVtktQ=boundFunction(self.VVedl7, VVMB3d), curRowNum=rowNum)
  else    : FFTvTY(self, path)
 def VVedl7(self, VVMB3d, fileChanged):
  if fileChanged:
   VVMB3d.cancel()
 def VVKJkN(self, title):
  curChName = self.VVMB3d.VVits3(1)
  FFaNVN(self, boundFunction(self.VVS8wE, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVS8wE(self, title, name):
  if name:
   lameDbChans = CCs1x9.VVNwh8(self, CCs1x9.VVnsGP, VVD9mD=False, VVxxba=False)
   list = []
   if lameDbChans:
    processChanName = CCVre4()
    name = processChanName.VVunOm(name)
    ratio = "1"
    for item in lameDbChans:
     if name in item[0].lower():
      list.append((item[0], FFhYTe(item[2]), item[3], ratio))
   if list : self.VVASbY(list, title)
   else : FF3wnI(self, "Not found:\n\n%s" % name, title=title)
 def VVtdkE(self, title):
  curChName = self.VVMB3d.VVits3(1)
  self.session.open(CCbVFf, barTheme=CCbVFf.VVkoHr
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVxNkJ
      , VVtktQ = boundFunction(self.VVw9F5, title, curChName))
 def VVxNkJ(self, progBarObj):
  curChName = self.VVMB3d.VVits3(1)
  lameDbChans = CCs1x9.VVNwh8(self, CCs1x9.VV0Oz5, VVD9mD=False, VVxxba=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVoIwV = []
  progBarObj.VVTUhX(len(lameDbChans))
  processChanName = CCVre4()
  curCh = processChanName.VVunOm(curChName)
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CC7Ld1.VVuULS(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VV7qoF(1, True)
   if progBarObj and ratio > 50:
    progBarObj.VVoIwV.append((chName, FFhYTe(sat), refCode.replace("_", ":"), str(ratio)))
 def VVw9F5(self, title, curChName, VVJ8JJ, VVoIwV, threadCounter, threadTotal, threadErr):
  if VVoIwV: self.VVASbY(VVoIwV, title)
  elif VVJ8JJ: FF3wnI(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVASbY(self, VV3CuM, title):
  curChName = self.VVMB3d.VVits3(1)
  curRefCode = self.VVMB3d.VVits3(4)
  curUrl  = self.VVMB3d.VVits3(5)
  VV3CuM = sorted(VV3CuM, key=lambda x: (100-int(x[3]), x[0].lower()))
  VVyMeP  = ("Share Sat/C/T Ref.", boundFunction(self.VVqWwA, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFynj9(self, None, title=title, header=header, VVATVO=VV3CuM, VVeJNW=widths, VV4RrQ=26, VVyMeP=VVyMeP, VVPUaR="#0a00112B", VV1PI5="#0a001126", VVLubA="#0a001126", VVrJH1="#00000000")
 def VVqWwA(self, newtitle, curChName, curRefCode, curUrl, VVMB3d, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFysO2(self.VVMB3d, boundFunction(FFb4DW, self.VVMB3d, boundFunction(self.VVBKfW, VVMB3d, data)), ques, title=newtitle, VVESi4=True)
 def VVBKfW(self, VVMB3d, data):
  VVMB3d.cancel()
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVrPLz():
    txt = FFP7TV(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFNMxM()
    newRow = []
    for i in range(6):
     newRow.append(self.VVMB3d.VVits3(i))
    newRow[4] = newRefCode
    done = self.VVMB3d.VVqFcn(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFSYWA(boundFunction(FFi9RU , self, resTxt, title=title))
  elif resErr: FFSYWA(boundFunction(FF3wnI , self, resErr, title=title))
 def VVGkUG(self, fileMenuInstance, path, VVMB3d, title, txt, colList):
  self.session.open(CCbVFf, barTheme=CCbVFf.VVkoHr
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVIrIz, VVMB3d)
      , VVtktQ = boundFunction(self.VV3Zrr, fileMenuInstance, path, VVMB3d))
 def VVIrIz(self, VVMB3d, progBarObj):
  progBarObj.VVTUhX(VVMB3d.VVgz0D())
  progBarObj.VVoIwV = []
  for row in VVMB3d.VVsLdG():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VV7qoF(1, True)
   qUrl = self.VVKDM6(self.VVaVXF, row[6])
   txt, err = self.VVfEog(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVmQRI(item, "auth") == "0":
       progBarObj.VVoIwV.append(qUrl)
    except:
     pass
 def VV3Zrr(self, fileMenuInstance, path, VVMB3d, VVJ8JJ, VVoIwV, threadCounter, threadTotal, threadErr):
  if VVJ8JJ:
   list = VVoIwV
   title = "Authorized Servers"
   if list:
    totChk = VVMB3d.VVgz0D()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFpkvp()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVK71N()
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFtsFe(str(totAuth), VVAexn)
     txt += "%s\n\n%s"    %  (FFtsFe("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFR6iW(self, txt, title=title)
     VVMB3d.close()
     fileMenuInstance.close()
    else:
     FFi9RU(self, "All URLs are authorized.", title=title)
   else:
    FF3wnI(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVfEog(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   cont = res.headers.get("Content-Type")
   if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
    return "", "Unexpected server data type ( %s )" % cont
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VV4Hcw(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVH2YO(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVKDM6(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VV4Hcw(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVaVXF   : return "%s"            % url
  elif mode == self.VVtemc   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVACIN   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVgqDe  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVMeRe  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVydBq : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVOCls   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVbMHV    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVpiYc  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVJ65D : return "%s&action=get_live_streams"      % url
  elif mode == self.VVgt49  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVmQRI(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFlXfZ(int(val))
    elif is_base64 : val = FF27My(val)
    elif isToHHMMSS : val = FFZEiA(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVI2eR(self, title, path):
  if fileExists(path):
   enc = CCAv2L.VVpb9U(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VVWEst(line)
     if qUrl:
      break
   if qUrl : self.VVENEF(title, qUrl)
   else : FF3wnI(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FF3wnI(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVqvP4_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVJgs0()
  if qUrl or "chCode" in iptvRef:
   p = CCpWxg()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVKzrD(iptvRef)
   if valid:
    self.VVqvP4(self, host, mac)
    return
   elif qUrl:
    FFb4DW(self, boundFunction(self.VVENEF, title, qUrl), title="Checking Server ...")
    return
  FF3wnI(self, "Error in current channel URL !", title=title)
 def VVJgs0(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self)
  qUrl = self.VVWEst(decodedUrl)
  return qUrl, iptvRef
 def VVWEst(self, url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVENEF(self, title, url):
  self.VVBcpRData = {}
  qUrl = self.VVKDM6(self.VVaVXF, url)
  txt, err = self.VVfEog(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVBcpRData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVBcpRData["username"    ] = self.VVmQRI(item, "username"        )
    self.VVBcpRData["password"    ] = self.VVmQRI(item, "password"        )
    self.VVBcpRData["message"    ] = self.VVmQRI(item, "message"        )
    self.VVBcpRData["auth"     ] = self.VVmQRI(item, "auth"         )
    self.VVBcpRData["status"    ] = self.VVmQRI(item, "status"        )
    self.VVBcpRData["exp_date"    ] = self.VVmQRI(item, "exp_date"    , isDate=True )
    self.VVBcpRData["is_trial"    ] = self.VVmQRI(item, "is_trial"        )
    self.VVBcpRData["active_cons"   ] = self.VVmQRI(item, "active_cons"       )
    self.VVBcpRData["created_at"   ] = self.VVmQRI(item, "created_at"   , isDate=True )
    self.VVBcpRData["max_connections"  ] = self.VVmQRI(item, "max_connections"      )
    self.VVBcpRData["allowed_output_formats"] = self.VVmQRI(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVBcpRData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVBcpRData["url"    ] = self.VVmQRI(item, "url"        )
    self.VVBcpRData["port"    ] = self.VVmQRI(item, "port"        )
    self.VVBcpRData["https_port"  ] = self.VVmQRI(item, "https_port"      )
    self.VVBcpRData["server_protocol" ] = self.VVmQRI(item, "server_protocol"     )
    self.VVBcpRData["rtmp_port"   ] = self.VVmQRI(item, "rtmp_port"       )
    self.VVBcpRData["timezone"   ] = self.VVmQRI(item, "timezone"       )
    self.VVBcpRData["timestamp_now"  ] = self.VVmQRI(item, "timestamp_now"  , isDate=True )
    self.VVBcpRData["time_now"   ] = self.VVmQRI(item, "time_now"       )
    VV64WM  = self.VVkLJq(True)
    OKBtnFnc = self.VVBcpROptions
    VVZg0c = ("Home Menu", FFOWIb)
    VVY0ds = ("Bookmark Server", boundFunction(CCNFtw.VVh1gi, self, False, self.VVBcpRData["playListURL"]))
    FFUdxd(self, None, title="IPTV Server Resources", VV64WM=VV64WM, OKBtnFnc=OKBtnFnc, VVZg0c=VVZg0c, VVY0ds=VVY0ds)
   else:
    err = "Could not get data from server !"
  if err:
   FF3wnI(self, err, title=title)
  FFmoBc(self)
 def VVBcpROptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFb4DW(menuInstance, boundFunction(self.VVVT3U, self.VVtemc  , title=title), title=wTxt)
   elif ref == "vod"   : FFb4DW(menuInstance, boundFunction(self.VVVT3U, self.VVACIN  , title=title), title=wTxt)
   elif ref == "series"  : FFb4DW(menuInstance, boundFunction(self.VVVT3U, self.VVgqDe , title=title), title=wTxt)
   elif ref == "catchup"  : FFb4DW(menuInstance, boundFunction(self.VVVT3U, self.VVMeRe , title=title), title=wTxt)
   elif ref == "accountInfo" : FFb4DW(menuInstance, boundFunction(self.VVKPhA           , title=title), title=wTxt)
 def VVKPhA(self, title):
  rows = []
  for key, val in self.VVBcpRData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VVFile  = ("Home Menu", FFOWIb, [])
  VVVDdh  = None
  if VVj3zx:
   VVVDdh = ("Get JS" , boundFunction(self.VVELla, "/".join(self.VVBcpRData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFynj9(self, None, title=title, width=1200, header=header, VVATVO=rows, VVeJNW=widths, VV4RrQ=26, VVFile=VVFile, VVVDdh=VVVDdh, VVPUaR="#0a00292B", VV1PI5="#0a002126", VVLubA="#0a002126", VVrJH1="#00000000", searchCol=2)
 def VVKx8y(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CCVre4()
    if mode in (self.VVOCls, self.VVgt49):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVmQRI(item, "num"         )
      name     = self.VVmQRI(item, "name"        )
      stream_id    = self.VVmQRI(item, "stream_id"       )
      stream_icon    = self.VVmQRI(item, "stream_icon"       )
      epg_channel_id   = self.VVmQRI(item, "epg_channel_id"      )
      added     = self.VVmQRI(item, "added"    , isDate=True )
      is_adult    = self.VVmQRI(item, "is_adult"       )
      category_id    = self.VVmQRI(item, "category_id"       )
      tv_archive    = self.VVmQRI(item, "tv_archive"       )
      name = processChanName.VVLT3a(name)
      if name:
       if mode == self.VVOCls or mode == self.VVgt49 and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVbMHV:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVmQRI(item, "num"         )
      name    = self.VVmQRI(item, "name"        )
      stream_id   = self.VVmQRI(item, "stream_id"       )
      stream_icon   = self.VVmQRI(item, "stream_icon"       )
      added    = self.VVmQRI(item, "added"    , isDate=True )
      is_adult   = self.VVmQRI(item, "is_adult"       )
      category_id   = self.VVmQRI(item, "category_id"       )
      container_extension = self.VVmQRI(item, "container_extension"     ) or "mp4"
      name = processChanName.VVLT3a(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVpiYc:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVmQRI(item, "num"        )
      name    = self.VVmQRI(item, "name"       )
      series_id   = self.VVmQRI(item, "series_id"      )
      cover    = self.VVmQRI(item, "cover"       )
      genre    = self.VVmQRI(item, "genre"       )
      episode_run_time = self.VVmQRI(item, "episode_run_time"    )
      category_id   = self.VVmQRI(item, "category_id"      )
      container_extension = self.VVmQRI(item, "container_extension"    ) or "mp4"
      name = processChanName.VVLT3a(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVVT3U(self, mode, title):
  cList, err = self.VVxViT(mode)
  if cList and mode == self.VVMeRe:
   cList = self.VV2TqE(cList)
  if err:
   FF3wnI(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVPUaR, VV1PI5, VVLubA, VVrJH1 = self.VVUR6Q(mode)
   mName = self.VVsSOA(mode)
   if   mode == self.VVtemc  : fMode = self.VVOCls
   elif mode == self.VVACIN  : fMode = self.VVbMHV
   elif mode == self.VVgqDe : fMode = self.VVpiYc
   elif mode == self.VVMeRe : fMode = self.VVgt49
   if mode == self.VVMeRe:
    VVHxLO = None
   else:
    VVHxLO = ("Find in %s" % mName , boundFunction(self.VVygSK, fMode) , [])
   VVyMeP   = ("Show List"   , boundFunction(self.VVIAAd, mode) , [])
   VVFile  = ("Home Menu"   , FFOWIb          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFynj9(self, None, title=title, width=1200, header=header, VVATVO=cList, VVeJNW=widths, VV4RrQ=30, VVFile=VVFile, VVHxLO=VVHxLO, VVyMeP=VVyMeP, VVPUaR=VVPUaR, VV1PI5=VV1PI5, VVLubA=VVLubA, VVrJH1=VVrJH1)
  else:
   FF3wnI(self, "No list from server !", title=title)
  FFmoBc(self)
 def VVxViT(self, mode):
  qUrl  = self.VVKDM6(mode, self.VVBcpRData["playListURL"])
  txt, err = self.VVfEog(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    processChanName = CCVre4()
    for item in tDict:
     category_id  = self.VVmQRI(item, "category_id"  )
     category_name = self.VVmQRI(item, "category_name" )
     parent_id  = self.VVmQRI(item, "parent_id"  )
     category_name = processChanName.VVZ9wa(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VV2TqE(self, catList):
  mode  = self.VVgt49
  qUrl  = self.VVKDM6(mode, self.VVBcpRData["playListURL"])
  txt, err = self.VVfEog(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVKx8y(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVIAAd(self, mode, VVMB3d, title, txt, colList):
  title = colList[1]
  FFb4DW(VVMB3d, boundFunction(self.VVZTnn, mode, VVMB3d, title, txt, colList), title="Downloading ...")
 def VVZTnn(self, mode, VVMB3d, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVsSOA(mode) + " : "+ bName
  if   mode == self.VVtemc  : mode = self.VVOCls
  elif mode == self.VVACIN  : mode = self.VVbMHV
  elif mode == self.VVgqDe : mode = self.VVpiYc
  elif mode == self.VVMeRe : mode = self.VVgt49
  qUrl  = self.VVKDM6(mode, self.VVBcpRData["playListURL"], catID)
  txt, err = self.VVfEog(qUrl)
  list  = []
  if not err and mode in (self.VVOCls, self.VVbMHV, self.VVpiYc, self.VVgt49):
   list, err = self.VVKx8y(mode, txt)
  if err:
   FF3wnI(self, err, title=title)
  elif list:
   VVFile  = ("Home Menu"   , FFOWIb             , [])
   if mode in (self.VVOCls, self.VVgt49):
    VVPUaR, VV1PI5, VVLubA, VVrJH1 = self.VVUR6Q(mode)
    VV4SDx = (""     , boundFunction(self.VVHxz5, mode)     , [])
    VVVDdh = ("Download Options" , boundFunction(self.VVvZzA, mode, "", "")  , [])
    VVHxLO = ("Options" , boundFunction(self.VVgJ8Y, 1, "lv", mode, bName)  , [])
    if mode == self.VVOCls:
     VVyMeP = ("Play"    , boundFunction(self.VV62qV, mode)     , [])
    elif mode == self.VVgt49:
     VVyMeP  = ("Programs", boundFunction(self.VVVSzA_fromIptvTable, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVnesb  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVbMHV:
    VVPUaR, VV1PI5, VVLubA, VVrJH1 = self.VVUR6Q(mode)
    VVyMeP  = ("Play"    , boundFunction(self.VV62qV, mode)    , [])
    VV4SDx = (""     , boundFunction(self.VVHxz5, mode)    , [])
    VVVDdh = ("Download Options" , boundFunction(self.VVvZzA, mode, "v", ""), [])
    VVHxLO = ("Options" , boundFunction(self.VVgJ8Y, 1, "v", mode, bName)  , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVnesb  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVpiYc:
    VVPUaR, VV1PI5, VVLubA, VVrJH1 = self.VVUR6Q("series2")
    VVyMeP  = ("Show Seasons", boundFunction(self.VVGcxc, mode) , [])
    VV4SDx = ("", boundFunction(self.VVKS6I, mode)  , [])
    VVVDdh = None
    VVHxLO = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVnesb  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFynj9(self, None, title=title, header=header, VVATVO=list, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=26, VVyMeP=VVyMeP, VVFile=VVFile, VVVDdh=VVVDdh, VVHxLO=VVHxLO, VV4SDx=VV4SDx, VVPUaR=VVPUaR, VV1PI5=VV1PI5, VVLubA=VVLubA, VVrJH1=VVrJH1, VVzmtH=True, searchCol=1)
  else:
   FF3wnI(self, "No Channels found !", title=title)
  FFmoBc(self)
 def VVVSzA_fromIptvTable(self, mode, bName, VVMB3d, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVBcpRData["playListURL"]
  ok_fnc  = boundFunction(self.VVJROo, hostUrl, chName, catId, streamId)
  FFb4DW(VVMB3d, boundFunction(CCNFtw.VVVSzA, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVJROo(self, chUrl, chName, catId, streamId, VVMB3d, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCNFtw.VV4Hcw(chUrl)
   chNum = "333"
   refCode = CCNFtw.VVDd7X(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFtcar(self, chUrl, VVdsme=False)
   self.session.open(CCkjHt)
  else:
   FF3wnI(self, "Incorrect Timestamp", pTitle)
 def VVGcxc(self, mode, VVMB3d, title, txt, colList):
  title = colList[1]
  FFb4DW(VVMB3d, boundFunction(self.VV29Vq, mode, VVMB3d, title, txt, colList), title="Downloading ...")
 def VV29Vq(self, mode, VVMB3d, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVKDM6(self.VVydBq, self.VVBcpRData["playListURL"], series_id)
  txt, err = self.VVfEog(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVmQRI(tDict["info"], "name"   )
      category_id = self.VVmQRI(tDict["info"], "category_id" )
      icon  = self.VVmQRI(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVmQRI(EP, "id"     )
        episode_num   = self.VVmQRI(EP, "episode_num"   )
        epTitle    = self.VVmQRI(EP, "title"     )
        container_extension = self.VVmQRI(EP, "container_extension" )
        seasonNum   = self.VVmQRI(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FF3wnI(self, err, title=title)
  elif list:
   VVFile = ("Home Menu"   , FFOWIb             , [])
   VVVDdh = ("Download Options" , boundFunction(self.VVvZzA, mode, "s", title) , [])
   VVHxLO = ("Options" , boundFunction(self.VVgJ8Y, 0, "s", mode, title)  , [])
   VV4SDx = (""     , boundFunction(self.VVHxz5, mode)     , [])
   VVyMeP  = ("Play"    , boundFunction(self.VV62qV, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVnesb  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFynj9(self, None, title=title, header=header, VVATVO=list, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=26, VVFile=VVFile, VVVDdh=VVVDdh, VVyMeP=VVyMeP, VV4SDx=VV4SDx, VVHxLO=VVHxLO, VVPUaR="#0a00292B", VV1PI5="#0a002126", VVLubA="#0a002126", VVrJH1="#00000000")
  else:
   FF3wnI(self, "No Channels found !", title=title)
  FFmoBc(self)
 def VVygSK(self, mode, VVMB3d, title, txt, colList):
  VV64WM = []
  VV64WM.append(("Keyboard"  , "manualEntry"))
  VV64WM.append(("From Filter" , "fromFilter"))
  FFUdxd(self, boundFunction(self.VVrFOK, VVMB3d, mode), title="Input Type", VV64WM=VV64WM, width=400)
 def VVrFOK(self, VVMB3d, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFaNVN(self, boundFunction(self.VVgZgm, VVMB3d, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCbhk5(self)
    filterObj.VVghZC(boundFunction(self.VVgZgm, VVMB3d, mode))
 def VVgZgm(self, VVMB3d, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CCVre4()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVmOWk(words):
     FF3wnI(self, processChanName.VVIqMS(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CCbVFf, barTheme=CCbVFf.VVkoHr
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VVaWrM, VVMB3d, mode, title, words, toFind, asPrefix, processChanName)
         , VVtktQ = boundFunction(self.VVpmoq, mode, toFind, title))
   else:
    FF3wnI(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVaWrM(self, VVMB3d, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVTUhX(VVMB3d.VVW3je())
  progBarObj.VVoIwV = []
  for row in VVMB3d.VVsLdG():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VV7qoF(1)
   progBarObj.VV5fDs_fromIptvFind(catName)
   qUrl  = self.VVKDM6(mode, self.VVBcpRData["playListURL"], catID)
   txt, err = self.VVfEog(qUrl)
   if not err:
    tList, err = self.VVKx8y(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VVLT3a(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVOCls:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VVoIwV.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVbMHV:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VVoIwV.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVpiYc:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VVoIwV.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVpmoq(self, mode, toFind, title, VVJ8JJ, VVoIwV, threadCounter, threadTotal, threadErr):
  if VVoIwV:
   title = self.VV7h9k(mode, toFind)
   if mode == self.VVOCls or mode == self.VVbMHV:
    if mode == self.VVbMHV : typ = "v"
    else          : typ = ""
    bName   = CCNFtw.VVEkpK_forBouquet(toFind)
    VVyMeP  = ("Play"     , boundFunction(self.VV62qV, mode)    , [])
    VVVDdh = ("Download Options" , boundFunction(self.VVvZzA, mode, typ, ""), [])
    VVHxLO = ("Options" , boundFunction(self.VVgJ8Y, 1, "fnd", mode, bName)  , [])
   elif mode == self.VVpiYc:
    VVyMeP  = ("Show Seasons"  , boundFunction(self.VVGcxc, mode)    , [])
    VVHxLO = None
    VVVDdh = None
   VV4SDx  = (""     , boundFunction(self.VVHxz5, mode)    , [])
   VVFile  = ("Home Menu"   , FFOWIb            , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVnesb  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVMB3d = FFynj9(self, None, title=title, header=header, VVATVO=VVoIwV, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=26, VVyMeP=VVyMeP, VVFile=VVFile, VVVDdh=VVVDdh, VVHxLO=VVHxLO, VV4SDx=VV4SDx, VVPUaR="#0a00292B", VV1PI5="#0a002126", VVLubA="#0a002126", VVrJH1="#00000000", VVzmtH=True, searchCol=1)
   if not VVJ8JJ:
    FFmoBc(VVMB3d, "Stopped" , 1000)
  else:
   if VVJ8JJ:
    FF3wnI(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVytmW(self, mode, colList):
  if mode in (self.VVOCls, self.VVgt49):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVbMHV:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFWesU(chName)
  url = self.VVBcpRData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VV4Hcw(url)
  refCode = self.VVDd7X(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVHxz5(self, mode, VVMB3d, title, txt, colList):
  FFb4DW(VVMB3d, boundFunction(self.VVfl4V, mode, VVMB3d, title, txt, colList))
 def VVfl4V(self, mode, VVMB3d, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVytmW(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFt65h(self, fncMode=CCc6Hf.VVmnnf, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVKS6I(self, mode, VVMB3d, title, txt, colList):
  FFb4DW(VVMB3d, boundFunction(self.VVJiJC, mode, VVMB3d, title, txt, colList))
 def VVJiJC(self, mode, VVMB3d, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFt65h(self, fncMode=CCc6Hf.VVSSwx, chName=name, text=txt, picUrl=Cover)
 def VVRDTi(self, mode, bName, VVMB3d, title, txt, colList):
  url = self.VVBcpRData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VV4Hcw(url)
  bNameFile = CCNFtw.VVEkpK_forBouquet(bName)
  num  = 0
  path = VVgmxK + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVgmxK + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   isMulti = VVMB3d.VVoduh
   for ndx, row in enumerate(VVMB3d.VVsLdG()):
    chName, chUrl, picUrl, refCode = self.VVytmW(mode, row)
    if not isMulti or VVMB3d.VVlaxk(ndx):
     f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
     f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
     totChange += 1
  FF5Fv9(os.path.basename(path))
  self.VVl970(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVvZzA(self, mode, typ, seriesName, VVMB3d, title, txt, colList):
  VV64WM = []
  isMulti = VVMB3d.VVoduh
  tot  = VVMB3d.VVZiZc()
  if isMulti:
   if tot < 1:
    FFmoBc(VVMB3d, "Select rows first.", 1000)
    return
   else:
    s = "s" if tot > 1 else ""
    name = "%d Selected" % tot
  else:
   s = "s"
   name = "ALL"
  VV64WM.append(("Download %s PIcon%s" % (name, s), "dnldPicons" ))
  if typ:
   VV64WM.append(VVB35E)
   tName = "Movie" if typ.startswith("v") else "Series"
   VV64WM.append(("Download Current %s" % tName    , "dnldSel"  ))
   VV64WM.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VV64WM.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCL4WW.VVTjd7():
    VV64WM.append(VVB35E)
    VV64WM.append(("Download Manager"      , "dload_stat" ))
  FFUdxd(self, boundFunction(self.VVxfNt_VVTsAs, VVMB3d, mode, typ, seriesName, colList), title="Download Options", VV64WM=VV64WM)
 def VVxfNt_VVTsAs(self, VVMB3d, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVUzOa(VVMB3d, mode)
   elif item == "dnldSel"  : self.VVeOFu(VVMB3d, mode, typ, colList, True)
   elif item == "addSel"  : self.VVeOFu(VVMB3d, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVDgmj(VVMB3d, mode, typ, seriesName)
   elif item == "dload_stat" : CCL4WW.VVp5QA(self)
 def VVeOFu(self, VVMB3d, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVsD0G(mode, typ, colList)
  if startDnld:
   CCL4WW.VVd21N_url(self, decodedUrl)
  else:
   self.VVTsAs_FFysO2(VVMB3d, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVDgmj(self, VVMB3d, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVMB3d.VVsLdG():
   chName, decodedUrl = self.VVsD0G(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVTsAs_FFysO2(VVMB3d, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVTsAs_FFysO2(self, VVMB3d, title, chName, decodedUrl_list, startDnld):
  FFysO2(self, boundFunction(self.VV4E1v, VVMB3d, decodedUrl_list, startDnld), chName, title=title)
 def VV4E1v(self, VVMB3d, decodedUrl_list, startDnld):
  added, skipped = CCL4WW.VVLrnjList(decodedUrl_list)
  FFmoBc(VVMB3d, "Added", 1000)
 def VVsD0G(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVytmW(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVlB9l(mode, colList)
   refCode, chUrl = self.VVNbg1(self.VVqiSe, self.VVjS4W, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FF0J40(chUrl)
  return chName, decodedUrl
 def VVUzOa(self, VVMB3d, mode):
  if os.system(FFUJYt("which ffmpeg")) == 0:
   self.session.open(CCbVFf, barTheme=CCbVFf.VVES7x
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VV5twy, VVMB3d, mode)
       , VVtktQ = self.VVsMuE)
  else:
   FFysO2(self, boundFunction(CCNFtw.VVwhAT, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVsMuE(self, VVJ8JJ, VVoIwV, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVoIwV["proces"], VVoIwV["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVoIwV["ok"], VVoIwV["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVoIwV["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVoIwV["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVoIwV["badURL"]
  txt += "Download Failure\t: %d\n"   % VVoIwV["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVoIwV["path"]
  if not VVJ8JJ  : color = "#11402000"
  elif VVoIwV["err"]: color = "#11201000"
  else     : color = None
  if VVoIwV["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVoIwV["err"], txt)
  title = "PIcons Download Result"
  if not VVJ8JJ:
   title += "  (cancelled)"
  FFR6iW(self, txt, title=title, VVLubA=color)
 def VV5twy(self, VVMB3d, mode, progBarObj):
  isMulti = VVMB3d.VVoduh
  if isMulti : totRows = VVMB3d.VVZiZc()
  else  : totRows = VVMB3d.VVW3je()
  progBarObj.VVTUhX(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CC7Ld1.VVeUbw()
  progBarObj.VVoIwV = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for rowNum, row in enumerate(VVMB3d.VVsLdG()):
    if progBarObj.isCancelled:
     break
    if not isMulti or VVMB3d.VVlaxk(rowNum):
     progBarObj.VVoIwV["proces"] += 1
     progBarObj.VV7qoF(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVlB9l(mode, row)
      refCode = CCNFtw.VVDd7X(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVsffd(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVytmW(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       progBarObj.VVoIwV["attempt"] += 1
       path, err = FFd8ee(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        progBarObj.VVoIwV["ok"] += 1
        if FFmOde(path) > 0:
         cmd = ""
         if not mode == CCNFtw.VVOCls:
          cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
         cmd += FFUJYt("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         progBarObj.VVoIwV["size0"] += 1
         os.system(FFUJYt("rm -f '%s'" % path))
       elif err:
        progBarObj.VVoIwV["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         progBarObj.VVoIwV["err"] = err.title()
         break
      else:
       progBarObj.VVoIwV["exist"] += 1
     else:
      progBarObj.VVoIwV["badURL"] += 1
  except:
   pass
 @staticmethod
 def VVwhAT(SELF):
  cmd = FFU7ig(VVMxji, "ffmpeg")
  if cmd : FFSA5Q(SELF, cmd, title="Installing FFmpeg")
  else : FFdiGu(SELF)
 def VV7kJg(self):
  self.session.open(CCbVFf, barTheme=CCbVFf.VVES7x
      , titlePrefix = ""
      , fncToRun  = self.VV7fx8
      , VVtktQ = self.VVRyMP)
 def VV7fx8(self, progBarObj):
  bName = FFOHyc()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  progBarObj.VVoIwV = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = FFD5dU()
  if not progBarObj or progBarObj.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   progBarObj.VVTUhX(totCh)
   for serv in services:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VV7qoF(1)
    progBarObj.VV5fDs_fromImportEPG(totEpgOK, uChName)
    fullRef  = serv[0]
    if FF6XlH(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FF0J40(fullRef)
     span = iSearch(r"(mode=.+end=)", fullRef, IGNORECASE)
     if span:
      m3u_Url = CCpWxg.VV1tPI(fullRef)
      uType, uHost, uUser, uPass, uId, uChName  = CCNFtw.VVH2YO(fullRef)
      uType, uHost, uUser, uPass, uId, uChName1 = CCNFtw.VVH2YO(m3u_Url)
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCNFtw.VVH2YO(m3u_Url)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCNFtw.VVqbMa(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCc6Hf.VVx4Tm(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
      else:
       pass
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if progBarObj:
     progBarObj.VVoIwV = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   progBarObj.VVoIwV = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VVRyMP(self, VVJ8JJ, VVoIwV, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVoIwV
  title = "IPTV EPG Import"
  if err:
   FF3wnI(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFtsFe(str(totNotIptv), VVValh)
    if totServErr : txt += "Server Errors\t: %s\n" % FFtsFe(str(totServErr) + t1, VVValh)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFtsFe(str(totInv), VVValh)
   if not VVJ8JJ:
    title += "  (stopped)"
   FFR6iW(self, txt, title=title)
 @staticmethod
 def VVqbMa(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCNFtw.VV4Hcw(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCNFtw.VVfEog(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCNFtw.VVmQRI(item, "description" , is_base64=True ).replace("\n", " .. ")
    has_archive   = CCNFtw.VVmQRI(item, "has_archive"      )
    lang    = CCNFtw.VVmQRI(item, "lang"        ).upper()
    now_playing   = CCNFtw.VVmQRI(item, "now_playing"      )
    start    = CCNFtw.VVmQRI(item, "start"        )
    start_timestamp  = CCNFtw.VVmQRI(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCNFtw.VVmQRI(item, "start_timestamp"     )
    stop_timestamp  = CCNFtw.VVmQRI(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCNFtw.VVmQRI(item, "stop_timestamp"      )
    tTitle    = CCNFtw.VVmQRI(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVDd7X(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCNFtw.VVy05K(catID, MAX_4b)
  TSID = CCNFtw.VVy05K(chNum, MAX_4b)
  ONID = CCNFtw.VVy05K(chNum, MAX_4b)
  NS  = CCNFtw.VVy05K(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVy05K(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVEkpK_forBouquet(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVUR6Q(mode):
  if   mode in ("itv"  , CCNFtw.VVtemc)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCNFtw.VVACIN)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCNFtw.VVgqDe) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCNFtw.VVMeRe) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCNFtw.VVgt49    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 @staticmethod
 def VVuKzP(orExportPath=False):
  path = CFG.iptvHostsPath.getValue()
  if not pathExists(path) or path == VVRRQu:
   if orExportPath : path = CFG.exportedTablesPath.getValue()
   else   : path ="/"
  return FFMXkM(path)
 @staticmethod
 def VVVSzA(SELF, hostUrl, chName, streamId, ok_fnc):
  title = "Catchup TV Programs"
  pList, err = CCNFtw.VVqbMa(hostUrl, streamId, True)
  if err:
   FF3wnI(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVPUaR, VV1PI5, VVLubA, VVrJH1 = CCNFtw.VVUR6Q("")
   VVFile = ("Home Menu" , FFOWIb, [])
   VVyMeP  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVnesb  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFynj9(SELF, None, title="Programs for : " + chName, header=header, VVATVO=pList, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=24, VVyMeP=VVyMeP, VVFile=VVFile, VVPUaR=VVPUaR, VV1PI5=VV1PI5, VVLubA=VVLubA, VVrJH1=VVrJH1)
  else:
   FF3wnI(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVqTaq(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 @staticmethod
 def VVh1gi(SELF, isPortal, line, VVd1c8Obj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCNFtw.VVuKzP(orExportPath=True)
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FF3wnI(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFi9RU(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FF3wnI(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVgJ8Y(self, nameCol, source, mode, bName, VVMB3d, title, txt, colList):
  isMulti = VVMB3d.VVoduh
  mSel = CCYdZD(self, VVMB3d, nameCol, addSep=False)
  title = ""
  if isMulti:
   tot = VVMB3d.VVZiZc()
   if tot > 0:
    s = "s" if tot > 1 else ""
    title = "Add %d Service%s to Bouquet" % (tot, s)
  else:
   title = "Add ALL to Bouquet"
  if title:
   mSel.VV64WM.append(VVB35E)
   mSel.VV64WM.append((title        , "addToBoquet"))
  FFUdxd(self, boundFunction(self.VV12tv, mSel, source, mode, bName, VVMB3d, title, txt, colList), title="Options", VV64WM=mSel.VV64WM)
 def VV12tv(self, mSelObj, source, mode, bName, VVMB3d, title, txt, colList, item):
  if item:
   if   item == "multSelEnab"     : mSelObj.VVMB3d.VVMC9a(True)
   elif item == "MultSelDisab"     : mSelObj.VVMB3d.VVMC9a(False)
   elif item == "selectAll"     : mSelObj.VVMB3d.VVb2VJ()
   elif item == "unselectAll"     : mSelObj.VVMB3d.VVNdD3()
   elif item == "addToBoquet"     :
    if   source == "pEp" : fnc = self.VVbtUy
    elif source == "pCh" : fnc = self.VVbtUy
    elif source == "m3Ch" : fnc = self.VV1h7j
    elif source == "lv"  : fnc = self.VVRDTi
    elif source == "v"  : fnc = self.VVRDTi
    elif source == "s"  : fnc = self.VVRDTi
    elif source == "fnd" : fnc = self.VVRDTi
    else     : return
    FFb4DW(VVMB3d, boundFunction(fnc, mode, bName, VVMB3d, title, txt, colList), title="Adding Channels ...")
class CCEOaz(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFhdcK(VVDXvw, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVzcOZ  = 0
  self.VVgGUE = 1
  self.VVIJs5  = 2
  VV64WM = []
  VV64WM.append(("Find in All Service (from filter)" , "VV0ruQ" ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Find in All (Manual Entry)"   , "VVSCSn"    ))
  VV64WM.append(("Find in TV"       , "VVj0RI"    ))
  VV64WM.append(("Find in Radio"      , "VVZmb9"   ))
  if self.VVtweh():
   VV64WM.append(VVB35E)
   VV64WM.append(("Hide Channel: %s" % self.servName , "VVd5IJ"   ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Zap History"       , "VVhRme"    ))
  VV64WM.append(VVB35E)
  VV64WM.append(("IPTV Tools"       , "iptv"      ))
  VV64WM.append(("PIcons Tools"       , "PIconsTools"     ))
  VV64WM.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FFFgql(self, VV64WM=VV64WM, title=title)
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FFH9Ay(self["myMenu"])
  FFq9fK(self)
  if self.isFindMode:
   self.VV4P6X(self.VVtW6I())
 def VVhHBt(self):
  global VVWyR9
  VVWyR9 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVSCSn"    : self.VVSCSn()
   elif item == "VV0ruQ" : self.VV0ruQ()
   elif item == "VVj0RI"    : self.VVj0RI()
   elif item == "VVZmb9"   : self.VVZmb9()
   elif item == "VVd5IJ"   : self.VVd5IJ()
   elif item == "VVhRme"    : self.VVhRme()
   elif item == "iptv"       : self.session.open(CCNFtw)
   elif item == "PIconsTools"     : self.session.open(CC7Ld1)
   elif item == "ChannelsTools"    : self.session.open(CCs1x9)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVj0RI(self) : self.VV4P6X(self.VVzcOZ)
 def VVZmb9(self) : self.VV4P6X(self.VVgGUE)
 def VVSCSn(self) : self.VV4P6X(self.VVIJs5)
 def VV4P6X(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFaNVN(self, boundFunction(self.VVnJgE, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VV0ruQ(self):
  filterObj = CCbhk5(self)
  filterObj.VVghZC(self.VVxzLm)
 def VVxzLm(self, item):
  self.VVnJgE(self.VVIJs5, item)
 def VVtweh(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FF6XlH(self.refCode)        : return False
  return True
 def VVnJgE(self, mode, VV3jRI):
  FFb4DW(self, boundFunction(self.VVbI96, mode, VV3jRI), title="Searching ...")
 def VVbI96(self, mode, VV3jRI):
  if VV3jRI:
   self.findTxt = VV3jRI
   if   mode == self.VVzcOZ  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVgGUE : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VV3jRI)
   if len(title) > 55:
    title = title[:55] + ".."
   VV3CuM = self.VV8RjS(VV3jRI, servTypes)
   if self.isFindMode or mode == self.VVIJs5:
    VV3CuM += self.VVo9K5(VV3jRI)
   if VV3CuM:
    VV3CuM.sort(key=lambda x: x[0].lower())
    VVUKxL = self.VVAj6Q
    VVyMeP  = ("Zap"   , self.VVowpo    , [])
    VVVDdh = ("Current Service", self.VVpcNX , [])
    VVHxLO = ("Options"  , self.VVuSvw , [])
    VV4SDx = (""    , self.VVFvsk , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVnesb  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFynj9(self, None, title=title, header=header, VVATVO=VV3CuM, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=26, VVyMeP=VVyMeP, VVUKxL=VVUKxL, VVVDdh=VVVDdh, VVHxLO=VVHxLO, VV4SDx=VV4SDx)
   else:
    self.VV4P6X(self.VVtW6I())
    FFi9RU(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VV8RjS(self, VV3jRI, servTypes):
  VV8O7b  = eServiceCenter.getInstance()
  VVdUNj   = '%s ORDER BY name' % servTypes
  VVXr0j   = eServiceReference(VVdUNj)
  VVsqGm = VV8O7b.list(VVXr0j)
  if VVsqGm: VVATVO = VVsqGm.getContent("CN", False)
  else     : VVATVO = None
  VV3CuM = []
  if VVATVO:
   VVwz6m, VVL7qP = FFgerI()
   tp   = CCkhMr()
   words, asPrefix = CCbhk5.VVQhDw(VV3jRI)
   colorYellow  = CCpI1P.VVkC9W(VVgcU9)
   colorWhite  = CCpI1P.VVkC9W(VVXaUF)
   for s in VVATVO:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFfrDO(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVwz6m:
        STYPE = VVL7qP[sTypeInt]
       freq, pol, fec, sr, syst = tp.VV34cG(refCode)
       if not "-S" in syst:
        sat = syst
       VV3CuM.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VV3CuM
 def VVo9K5(self, VV3jRI):
  VV3jRI = VV3jRI.lower()
  VV9JnC = FFtsF4()
  VV3CuM = []
  colorYellow  = CCpI1P.VVkC9W(VVgcU9)
  colorWhite  = CCpI1P.VVkC9W(VVXaUF)
  if VV9JnC:
   for b in VV9JnC:
    VVZnFN  = b[0]
    VVRvdT  = b[1].toString()
    VVa1Lj = eServiceReference(VVRvdT)
    VVUckK = FFMx0N(VVa1Lj)
    for service in VVUckK:
     refCode  = service[0]
     if FF6XlH(refCode):
      servName = service[1]
      if VV3jRI in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VV3jRI), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VV3CuM.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VV3CuM
 def VVtW6I(self):
  VVMZAe = InfoBar.instance
  if VVMZAe:
   VVXEzV = VVMZAe.servicelist
   if VVXEzV:
    return VVXEzV.mode == 1
  return self.VVIJs5
 def VVAj6Q(self, VVMB3d):
  self.close()
  VVMB3d.cancel()
 def VVowpo(self, VVMB3d, title, txt, colList):
  FFtcar(VVMB3d, colList[2], VVdsme=False, checkParentalControl=True)
 def VVpcNX(self, VVMB3d, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(VVMB3d)
  if refCode:
   VVMB3d.VVV98r(2, FFYZPy(refCode, iptvRef, chName), True)
 def VVuSvw(self, VVMB3d, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CCYdZD(self, VVMB3d, 2)
  mSel.VV8gP8(servName, refCode)
 def VVFvsk(self, VVMB3d, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFt65h(self, fncMode=CCc6Hf.VVZpzG, refCode=refCode, chName=chName, text=txt)
 def VVd5IJ(self):
  FFysO2(self, self.VV4itk, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VV4itk(self):
  ret = FF2FUE(self.refCode, True)
  if ret:
   self.VVhQPf()
   self.close()
  else:
   FFmoBc(self, "Cannot change state" , 1000)
 def VVhQPf(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VV5N0u()
  except:
   self.VVYddB()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFzyZu(self, serviceRef)
 def VVKOc0(self):
  VVMZAe = InfoBar.instance
  if VVMZAe:
   VVXEzV = VVMZAe.servicelist
   if VVXEzV:
    VVXEzV.setMode()
 def VV5N0u(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVMZAe = InfoBar.instance
   if VVMZAe:
    VVXEzV = VVMZAe.servicelist
    if VVXEzV:
     hList = VVXEzV.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVXEzV.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVXEzV.history  = newList
       VVXEzV.history_pos = pos
 def VVYddB(self):
  VVMZAe = InfoBar.instance
  if VVMZAe:
   VVXEzV = VVMZAe.servicelist
   if VVXEzV:
    VVXEzV.history  = []
    VVXEzV.history_pos = 0
 def VVhRme(self):
  VVMZAe = InfoBar.instance
  VV3CuM = []
  if VVMZAe:
   VVXEzV = VVMZAe.servicelist
   if VVXEzV:
    VVwz6m, VVL7qP = FFgerI()
    for chParams in VVXEzV.history:
     refCode = chParams[-1].toString()
     chName = FFrAs1(refCode)
     isIptv = FF6XlH(refCode)
     if isIptv: sat = "-"
     else  : sat = FFfrDO(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVwz6m:
       STYPE = VVL7qP[sTypeInt]
     VV3CuM.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VV3CuM:
   VVyMeP  = ("Zap"   , self.VVWvpP   , [])
   VVHxLO = ("Clear History" , self.VVcxhv   , [])
   VV4SDx = (""    , self.VVaXZOFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVnesb  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFynj9(self, None, title=title, header=header, VVATVO=VV3CuM, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=28, VVyMeP=VVyMeP, VVHxLO=VVHxLO, VV4SDx=VV4SDx)
  else:
   FFi9RU(self, "Not found", title=title)
 def VVWvpP(self, VVMB3d, title, txt, colList):
  FFtcar(VVMB3d, colList[3], VVdsme=False, checkParentalControl=True)
 def VVcxhv(self, VVMB3d, title, txt, colList):
  FFysO2(self, boundFunction(self.VV4hYg, VVMB3d), "Clear Zap History ?")
 def VV4hYg(self, VVMB3d):
  self.VVYddB()
  VVMB3d.cancel()
 def VVaXZOFromZapHistory(self, VVMB3d, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFt65h(self, fncMode=CCc6Hf.VVufz1, refCode=refCode, chName=chName, text=txt)
class CC7Ld1(Screen):
 VVfWet   = 0
 VVx4c3  = 1
 VVMuPe  = 2
 VVdUHu  = 3
 VVy4SA  = 4
 VVUCHb  = 5
 VVwOec  = 6
 VVWMKE  = 7
 VVD36P = 8
 VViR2O = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFhdcK(VV9biv, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFFgql(self, self.Title)
  FF9CgN(self["keyRed"] , "OK = Zap")
  FF9CgN(self["keyGreen"] , "Current Service")
  FF9CgN(self["keyYellow"], "Page Options")
  FF9CgN(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CC7Ld1.VVeUbw()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVATVO    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV8wSV        ,
   "green"   : self.VV1AX1       ,
   "yellow"  : self.VVXYQc        ,
   "blue"   : self.VVb4mX        ,
   "menu"   : self.VVPhSf        ,
   "info"   : self.VVaXZO         ,
   "up"   : self.VVmeLf          ,
   "down"   : self.VVJgQv         ,
   "left"   : self.VVrCAA         ,
   "right"   : self.VVxaGR         ,
   "pageUp"  : boundFunction(self.VVYea8, True) ,
   "chanUp"  : boundFunction(self.VVYea8, True) ,
   "pageDown"  : boundFunction(self.VVYea8, False) ,
   "chanDown"  : boundFunction(self.VVYea8, False) ,
   "next"   : self.VV821G        ,
   "last"   : self.VV1aDH         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FFb93v(self)
  FF1rm3(self)
  FFrlPO(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFb4DW(self, boundFunction(self.VVXcvV, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVPhSf(self):
  if not self.isBusy:
   VV64WM = []
   VV64WM.append(("Statistics"           , "VVnDdq"    ))
   VV64WM.append(VVB35E)
   VV64WM.append(("Suggest PIcons for Current Channel"     , "VVT3kG"   ))
   VV64WM.append(("Set to Current Channel (copy file)"     , "VVBY5C_file"  ))
   VV64WM.append(("Set to Current Channel (as SymLink)"     , "VVBY5C_link"  ))
   VV64WM.append(VVB35E)
   VV64WM.append(CC7Ld1.VVutpE())
   VV64WM.append(VVB35E)
   if self.filterTitle == "PIcons without Channels":
    c = VVValh
    VV64WM.append((FFtsFe("Move Unused PIcons to a Directory", c) , "VVnEH3"  ))
    VV64WM.append((FFtsFe("DELETE Unused PIcons", c)    , "VVskhr" ))
    VV64WM.append(VVB35E)
   VV64WM.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVYGRQ"  ))
   VV64WM.append(VVB35E)
   VV64WM += CC7Ld1.VVOngF()
   VV64WM.append(VVB35E)
   VV64WM.append(("RCU Keys Help"          , "VVGdCL"    ))
   FFUdxd(self, self.VVxfNt, title=self.Title, VV64WM=VV64WM)
 def VVxfNt(self, item=None):
  if item is not None:
   if   item == "VVnDdq"     : self.VVnDdq()
   elif item == "VVT3kG"    : self.VVT3kG()
   elif item == "VVBY5C_file"   : self.VVBY5C(0)
   elif item == "VVBY5C_link"   : self.VVBY5C(1)
   elif item == "VVLv0n_file"  : self.VVLv0n(0)
   elif item == "VVLv0n_link"  : self.VVLv0n(1)
   elif item == "VVPNKT"   : self.VVPNKT()
   elif item == "VVx6if"  : self.VVx6if()
   elif item == "VVnEH3"    : self.VVnEH3()
   elif item == "VVskhr"   : self.VVskhr()
   elif item == "VVYGRQ"   : self.VVYGRQ()
   elif item == "VVeQps"   : CC7Ld1.VVeQps(self)
   elif item == "VVgU1I"   : CC7Ld1.VVgU1I(self)
   elif item == "findPiconBrokenSymLinks"  : CC7Ld1.VVuT6G(self, True)
   elif item == "FindAllBrokenSymLinks"  : CC7Ld1.VVuT6G(self, False)
   elif item == "VVGdCL"      : self.VVGdCL()
 def VVXYQc(self):
  if not self.isBusy:
   VV64WM = []
   VV64WM.append(("Go to First PIcon"  , "VVom2H"  ))
   VV64WM.append(("Go to Last PIcon"   , "VV0pNf"  ))
   VV64WM.append(VVB35E)
   VV64WM.append(("Sort by Channel Name"     , "sortByChan" ))
   VV64WM.append(("Sort by File Name"  , "sortByFile" ))
   VV64WM.append(VVB35E)
   VV64WM.append(("Find from File List .." , "VVKLM9" ))
   FFUdxd(self, self.VVf94h, title=self.Title, VV64WM=VV64WM)
 def VVf94h(self, item=None):
  if item is not None:
   if   item == "VVom2H"   : self.VVom2H()
   elif item == "VV0pNf"   : self.VV0pNf()
   elif item == "sortByChan"  : self.VV9Mch(2)
   elif item == "sortByFile"  : self.VV9Mch(0)
   elif item == "VVKLM9"  : self.VVKLM9()
 def VVGdCL(self):
  FFkCkL(self, VVe57v + "_help_picons", "PIcons Manager (Keys Help)")
 def VVmeLf(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VV0pNf()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVdZSC()
 def VVJgQv(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVom2H()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVdZSC()
 def VVrCAA(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VV0pNf()
  else:
   self.curCol -= 1
   self.VVdZSC()
 def VVxaGR(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVom2H()
  else:
   self.curCol += 1
   self.VVdZSC()
 def VV1aDH(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVdZSC(True)
 def VV821G(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVdZSC(True)
 def VVom2H(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVdZSC(True)
 def VV0pNf(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVdZSC(True)
 def VVKLM9(self):
  VV64WM = []
  for item in self.VVATVO:
   VV64WM.append((item[0], item[0]))
  FFUdxd(self, self.VVTeeb, title='PIcons ".png" Files', VV64WM=VV64WM, VVecAt=True)
 def VVTeeb(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VV2Ck9(ndx)
 def VV8wSV(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVP00o()
   if refCode:
    FFtcar(self, refCode)
    self.VVWUuN()
    self.VVzlJ3()
 def VVYea8(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVWUuN()
   self.VVzlJ3()
  except:
   pass
 def VV1AX1(self):
  if self["keyGreen"].getVisible():
   self.VV2Ck9(self.curChanIndex)
 def VV2Ck9(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVdZSC(True)
  else:
   FFmoBc(self, "Not found", 1000)
 def VV9Mch(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFb4DW(self, boundFunction(self.VVXcvV, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVBY5C(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVP00o()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VV64WM = []
     VV64WM.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VV64WM.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFUdxd(self, boundFunction(self.VVKHBz, mode, curChF, selPiconF), VV64WM=VV64WM, title="Current Channel PIcon (already exists)")
    else:
     self.VVKHBz(mode, curChF, selPiconF, "overwrite")
   else:
    FF3wnI(self, "Cannot change PIcon to itself !", title=title)
  else:
   FF3wnI(self, "Could not read current channel info. !", title=title)
 def VVKHBz(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFb4DW(self, boundFunction(self.VVXcvV, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVLv0n(self, mode):
  pass
 def VVPNKT(self):
  pass
 def VVx6if(self):
  pass
 def VVnEH3(self):
  defDir = FFMXkM(CC7Ld1.VVeUbw() + "picons_backup")
  os.system(FFUJYt("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(boundFunction(self.VV3L11, defDir), boundFunction(CCN0r2
         , mode=CCN0r2.VVBjC9, VV8UhH=CC7Ld1.VVeUbw()))
 def VV3L11(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CC7Ld1.VVeUbw():
    FF3wnI(self, "Cannot move to same directory !", title=title)
   else:
    if not FFMXkM(path) == FFMXkM(defDir):
     self.VV941U(defDir)
    FFysO2(self, boundFunction(FFb4DW, self, boundFunction(self.VVBh6O, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVATVO), path), title=title)
  else:
   self.VV941U(defDir)
 def VVBh6O(self, title, defDir, toPath):
  try:
   from shutil import move as iMove
  except:
   self.VV941U(defDir)
   FF3wnI(self, 'Could not load "shutil" module !', title=title)
   return
  toPath = FFMXkM(toPath)
  pPath = CC7Ld1.VVeUbw()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVATVO:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVATVO)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFR6iW(self, txt, title=title, VVLubA="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVKl18("all")
 def VV941U(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVskhr(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVATVO)
  s = "s" if tot > 1 else ""
  FFysO2(self, boundFunction(FFb4DW, self, boundFunction(self.VVruZk, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, s), title=title)
 def VVruZk(self, title):
  pPath = CC7Ld1.VVeUbw()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVATVO:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVATVO)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFtsFe(str(totErr), VVValh)
  FFR6iW(self, txt, title=title)
 def VVYGRQ(self):
  lines = FFo68R("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFysO2(self, boundFunction(self.VVfkvk, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVESi4=True)
  else:
   FFi9RU(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVfkvk(self, fList):
  os.system(FFUJYt("find -L '%s' -type l -delete" % self.pPath))
  FFi9RU(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVaXZO(self):
  FFb4DW(self, self.VVy3d7)
 def VVy3d7(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVP00o()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFtsFe("PIcon Directory:\n", VVzqsa)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFf1ps(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFf1ps(path)
   txt += FFtsFe("PIcon File:\n", VVzqsa)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFo68R(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFtsFe("Found %d SymLink%s to this file from:\n" % (tot, s), VVzqsa)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFrAs1(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFtsFe(tChName, VVAexn)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFtsFe(line, VVBPJz), tChName)
    txt += "\n"
   if chName:
    txt += FFtsFe("Channel:\n", VVzqsa)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFtsFe(chName, VVAexn)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFtsFe("Remarks:\n", VVzqsa)
    txt += "  %s\n" % FFtsFe("Unused", VVValh)
  else:
   txt = "No info found"
  FFt65h(self, fncMode=CCc6Hf.VVeRha, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVP00o(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVATVO[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFhYTe(sat)
  return fName, refCode, chName, sat, inDB
 def VVWUuN(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVATVO):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVzlJ3(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVP00o()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFtsFe("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVzqsa))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVP00o()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFtsFe(self.curChanName, VVgcU9)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVnDdq(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VVATVO:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFhOpk("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFR6iW(self, txt, title=self.Title)
 def VVb4mX(self):
  if not self.isBusy:
   VV64WM = []
   VV64WM.append(("All"         , "all"   ))
   VV64WM.append(VVB35E)
   VV64WM.append(("Used by Channels"      , "used"  ))
   VV64WM.append(("Unused PIcons"      , "unused"  ))
   VV64WM.append(VVB35E)
   VV64WM.append(("PIcons Files"       , "pFiles"  ))
   VV64WM.append(("SymLinks to PIcons"     , "pLinks"  ))
   VV64WM.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VV64WM.append(VVB35E)
   VV64WM.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VV64WM.append(VVB35E)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFoAsb(val)
      VV64WM.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCbhk5(self)
   filterObj.VVUzgW(VV64WM, self.nsList, self.VVDqL8)
 def VVDqL8(self, item=None):
  if item is not None:
   self.VVKl18(item)
 def VVKl18(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVfWet   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVx4c3   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVMuPe  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVdUHu  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVy4SA  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVUCHb  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVwOec   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVWMKE   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVD36P , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVUCHb:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFo68R("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFmoBc(self, "Not found", 1000)
     return
   elif mode == self.VViR2O:
    return
   else:
    words, asPrefix = CCbhk5.VVQhDw(words)
   if not words and mode in (self.VVWMKE, self.VVD36P):
    FFmoBc(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFb4DW(self, boundFunction(self.VVXcvV, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVT3kG(self):
  self.session.open(CCbVFf, barTheme=CCbVFf.VVkoHr
      , titlePrefix = ""
      , fncToRun  = self.VVfSjQ
      , VVtktQ = self.VVNko5)
 def VVfSjQ(self, progBarObj):
  lameDbChans = CCs1x9.VVNwh8(self, CCs1x9.VV0Oz5, VVD9mD=False, VVxxba=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVoIwV = []
  progBarObj.VVTUhX(len(lameDbChans))
  if lameDbChans:
   processChanName = CCVre4()
   curCh = processChanName.VVunOm(self.curChanName)
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VV7qoF(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CC7Ld1.VVuULS(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CC7Ld1.VVtwS8(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VVoIwV.append(f.replace(".png", ""))
 def VVNko5(self, VVJ8JJ, VVoIwV, threadCounter, threadTotal, threadErr):
  if VVoIwV:
   self.timer = eTimer()
   fnc = boundFunction(FFb4DW, self, boundFunction(self.VVXcvV, mode=self.VViR2O, words=VVoIwV), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FFmoBc(self, "Not found", 2000)
 def VVXcvV(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVMSzA(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCs1x9.VVNwh8(self, CCs1x9.VV0Oz5, VVD9mD=False, VVxxba=False)
  iptvRefList = self.VVTGho()
  tList = []
  for fName, fType in CC7Ld1.VVbvMz(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVfWet:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVx4c3  and chName         : isAdd = True
   elif mode == self.VVMuPe and not chName        : isAdd = True
   elif mode == self.VVdUHu  and fType == 0        : isAdd = True
   elif mode == self.VVy4SA  and fType == 1        : isAdd = True
   elif mode == self.VVUCHb  and fName in words       : isAdd = True
   elif mode == self.VViR2O and fName in words       : isAdd = True
   elif mode == self.VVwOec  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVWMKE  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVD36P:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVATVO   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFmoBc(self)
  else:
   self.isBusy = False
   FFmoBc(self, "Not found", 1000)
   return
  self.VVATVO.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVWUuN()
  self.totalPIcons = len(self.VVATVO)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVdZSC(True)
 def VVMSzA(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CC7Ld1.VVbvMz(self.pPath):
    if fName:
     return True
   if isFirstTime : FF3wnI(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFmoBc(self, "Not found", 1000)
  else:
   FF3wnI(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVTGho(self):
  VV3CuM = {}
  files  = CCNFtw.VVWx7c(self)
  if files:
   for path in files:
    txt = FFP7TV(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VV3CuM[refCode] = item[1]
  return VV3CuM
 def VVdZSC(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVt7LZ = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVt7LZ: self.curPage = VVt7LZ
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VV0n28()
  if self.curPage == VVt7LZ:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVzlJ3()
  filName, refCode, chName, sat, inDB = self.VVP00o()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VV0n28(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVATVO[ndx]
   fName = self.VVATVO[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFtsFe(chName, VVAexn))
    else : lbl.setText("-")
   except:
    lbl.setText(FFtsFe(chName, VVeyOS))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVuULS(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVutpE():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVeQps"   )
 @staticmethod
 def VVOngF():
  VV64WM = []
  VV64WM.append(("Find SymLinks (to PIcon Directory)"   , "VVgU1I"   ))
  VV64WM.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VV64WM.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VV64WM
 @staticmethod
 def VVeQps(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(SELF)
  png, path = CC7Ld1.VVOrYS(refCode)
  if path : CC7Ld1.VVALFi(SELF, png, path)
  else : FF3wnI(SELF, "No PIcon found for current channel in:\n\n%s" % CC7Ld1.VVeUbw())
 @staticmethod
 def VVgU1I(SELF):
  if VVgcU9:
   sed1 = FF8OuG("->", VVgcU9)
   sed2 = FF8OuG("picon", VVValh)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVeyOS, VVXaUF)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFLfrr(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFN326(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVuT6G(SELF, isPIcon):
  sed1 = FF8OuG("->", VVeyOS)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FF8OuG("picon", VVValh)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFLfrr(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFN326(), grep, sed1, sed2))
 @staticmethod
 def VVbvMz(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVeUbw():
  path = CFG.PIconsPath.getValue()
  return FFMXkM(path)
 @staticmethod
 def VVOrYS(refCode, chName=None):
  if FF6XlH(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FF0J40(refCode)
  allPath, fName, refCodeFile, pList = CC7Ld1.VVtwS8(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVALFi(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FF8OuG("%s%s" % (dest, png), VVAexn))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FF8OuG(errTxt, VVe3tS))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFcaNF(SELF, cmd)
 @staticmethod
 def VVtwS8(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CC7Ld1.VVeUbw()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFWesU(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCb4du():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VV0psT  = None
  self.VVb1uM = ""
  self.VV9Srr  = noService
  self.VVNwmi = 0
  self.VVjJYW  = noService
  self.VVc9CY = 0
  self.VVcx9v  = "-"
  self.VV8RbO = 0
  self.VVeMzW  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVqUMR(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VV0psT = frontEndStatus
     self.VViwiO()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VViwiO(self):
  if self.VV0psT:
   val = self.VV0psT.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVb1uM = "%3.02f dB" % (val / 100.0)
   else         : self.VVb1uM = ""
   val = self.VV0psT.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVNwmi = int(val)
   self.VV9Srr  = "%d%%" % val
   val = self.VV0psT.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVc9CY = int(val)
   self.VVjJYW  = "%d%%" % val
   val = self.VV0psT.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVcx9v  = "%d" % val
   val = int(val * 100 / 500)
   self.VV8RbO = min(500, val)
   val = self.VV0psT.get("tuner_locked", 0)
   if val == 1 : self.VVeMzW = "Locked"
   else  : self.VVeMzW = "Not locked"
 def VVRDzJ(self)   : return self.VVb1uM
 def VVrGL2(self)   : return self.VV9Srr
 def VVpqWU(self)  : return self.VVNwmi
 def VVmNUR(self)   : return self.VVjJYW
 def VVCxj6(self)  : return self.VVc9CY
 def VVKMSK(self)   : return self.VVcx9v
 def VV2Nma(self)  : return self.VV8RbO
 def VV4B8u(self)   : return self.VVeMzW
 def VVHNop(self) : return self.serviceName
class CCkhMr():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVRCEF(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FF4HUl(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVA47V(self.ORPOS  , mod=1   )
      self.sat2  = self.VVA47V(self.ORPOS  , mod=2   )
      self.freq  = self.VVA47V(self.FREQ  , mod=3   )
      self.sr   = self.VVA47V(self.SR   , mod=4   )
      self.inv  = self.VVA47V(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVA47V(self.POL  , self.D_POL )
      self.fec  = self.VVA47V(self.FEC  , self.D_FEC )
      self.syst  = self.VVA47V(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVA47V("modulation" , self.D_MOD )
       self.rolof = self.VVA47V("rolloff"  , self.D_ROLOF )
       self.pil = self.VVA47V("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVA47V("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVA47V("pls_code"  )
       self.iStId = self.VVA47V("is_id"   )
       self.t2PlId = self.VVA47V("t2mi_plp_id" )
       self.t2PId = self.VVA47V("t2mi_pid"  )
 def VVA47V(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFoAsb(val)
  elif mod == 2   : return FFhwVp(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VViyhr(self, refCode):
  txt = ""
  self.VVRCEF(refCode)
  if self.data:
   def VVABtc(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVABtc("System"   , self.syst)
    txt += VVABtc("Satellite"  , self.sat2)
    txt += VVABtc("Frequency"  , self.freq)
    txt += VVABtc("Inversion"  , self.inv)
    txt += VVABtc("Symbol Rate"  , self.sr)
    txt += VVABtc("Polarization" , self.pol)
    txt += VVABtc("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVABtc("Modulation" , self.mod)
     txt += VVABtc("Roll-Off" , self.rolof)
     txt += VVABtc("Pilot"  , self.pil)
     txt += VVABtc("Input Stream", self.iStId)
     txt += VVABtc("T2MI PLP ID" , self.t2PlId)
     txt += VVABtc("T2MI PID" , self.t2PId)
     txt += VVABtc("PLS Mode" , self.plsMod)
     txt += VVABtc("PLS Code" , self.plsCod)
   else:
    txt += VVABtc("System"   , self.txMedia)
    txt += VVABtc("Frequency"  , self.freq)
  return txt, self.namespace
 def VVoIVz(self, refCode):
  txt = "Transpoder : ?"
  self.VVRCEF(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVzqsa + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VV34cG(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FF4HUl(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVA47V(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVA47V(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVA47V(self.SYST, self.D_SYS_S)
     freq = self.VVA47V(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVA47V(self.POL , self.D_POL)
      fec = self.VVA47V(self.FEC , self.D_FEC)
      sr = self.VVA47V(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVK3df(self, refCode):
  self.data = None
  self.VVRCEF(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCfUC2():
 def __init__(self, VVnt2W, path, VVtktQ=None, curRowNum=-1):
  self.VVnt2W  = VVnt2W
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVtktQ  = VVtktQ
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFUJYt("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVNeNV(curRowNum)
  else:
   FF3wnI(self.VVnt2W, "Error while preparing edit!")
 def VVNeNV(self, curRowNum):
  VV3CuM = self.VVJpJ9()
  VVFile = None #("Delete Line" , self.deleteLine  , [])
  VVVDdh = ("Save Changes" , self.VVHdQt   , [])
  VVyMeP  = ("Edit Line"  , self.VVlE7V    , [])
  VVDrmo = ("Line Options" , self.VVS2ew   , [])
  VVz2py = (""    , self.VV3tXx , [])
  VVUKxL = self.VVoQub
  VVScQs  = self.VVRkit
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVnesb  = (CENTER  , LEFT  )
  VVMB3d = FFynj9(self.VVnt2W, None, title=self.Title, header=header, VVATVO=VV3CuM, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=26, VVFile=VVFile, VVVDdh=VVVDdh, VVyMeP=VVyMeP, VVDrmo=VVDrmo, VVUKxL=VVUKxL, VVScQs=VVScQs, VVz2py=VVz2py, VVzmtH=True
    , VVPUaR   = "#11001111"
    , VV1PI5   = "#11001111"
    , VVLubA   = "#11001111"
    , VVrJH1  = "#05333333"
    , VVndWP  = "#00222222"
    , VVleo7  = "#11331133"
    )
  VVMB3d.VVC1AB(curRowNum)
 def VVS2ew(self, VVMB3d, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVMB3d.VVgz0D()
  VV64WM = []
  VV64WM.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VV64WM.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVgHho"  ))
  VV64WM.append(VVB35E)
  VV64WM.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVJgJQ:
   VV64WM.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VV64WM.append(VVB35E)
  VV64WM.append(  ("Delete Line"         , "deleteLine"   ))
  FFUdxd(self.VVnt2W, boundFunction(self.VVOqc1, VVMB3d, lineNum), VV64WM=VV64WM, title="Line Options")
 def VVOqc1(self, VVMB3d, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVzLbH("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVMB3d)
   elif item == "VVgHho"  : self.VVgHho(VVMB3d, lineNum)
   elif item == "copyToClipboard"  : self.VV8Yv8(VVMB3d, lineNum)
   elif item == "pasteFromClipboard" : self.VVL2cy(VVMB3d, lineNum)
   elif item == "deleteLine"   : self.VVzLbH("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVMB3d)
 def VVRkit(self, VVMB3d):
  VVMB3d.VVrNVt()
 def VV3tXx(self, VVMB3d, title, txt, colList):
  if   self.insertMode == 1: VVMB3d.VVBH29()
  elif self.insertMode == 2: VVMB3d.VV5H2s()
  self.insertMode = 0
 def VVgHho(self, VVMB3d, lineNum):
  if lineNum == VVMB3d.VVgz0D():
   self.insertMode = 1
   self.VVzLbH("echo '' >> '%s'" % self.tmpFile, VVMB3d)
  else:
   self.insertMode = 2
   self.VVzLbH("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVMB3d)
 def VV8Yv8(self, VVMB3d, lineNum):
  global VVJgJQ
  VVJgJQ = FFhOpk("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVMB3d.VVettN("Copied to clipboard")
 def VVHdQt(self, VVMB3d, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFUJYt("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFUJYt("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVMB3d.VVettN("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVMB3d.VVrNVt()
    else:
     FF3wnI(self.VVnt2W, "Cannot save file!")
   else:
    FF3wnI(self.VVnt2W, "Cannot create backup copy of original file!")
 def VVoQub(self, VVMB3d):
  if self.fileChanged:
   FFysO2(self.VVnt2W, boundFunction(self.VVUY7e, VVMB3d), "Cancel changes ?")
  else:
   finalOK = os.system(FFUJYt("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVUY7e(VVMB3d)
 def VVUY7e(self, VVMB3d):
  VVMB3d.cancel()
  os.system(FFUJYt("rm -f '%s'" % self.tmpFile))
  if self.VVtktQ:
   self.VVtktQ(self.fileSaved)
 def VVlE7V(self, VVMB3d, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVXaUF + "ORIGINAL TEXT:\n" + VVBPJz + lineTxt
  FFaNVN(self.VVnt2W, boundFunction(self.VVR8dE, lineNum, VVMB3d), title="File Line", defaultText=lineTxt, message=message)
 def VVR8dE(self, lineNum, VVMB3d, VVtkVj):
  if not VVtkVj is None:
   if VVMB3d.VVgz0D() <= 1:
    self.VVzLbH("echo %s > '%s'" % (VVtkVj, self.tmpFile), VVMB3d)
   else:
    self.VVWuAW(VVMB3d, lineNum, VVtkVj)
 def VVL2cy(self, VVMB3d, lineNum):
  if lineNum == VVMB3d.VVgz0D() and VVMB3d.VVgz0D() == 1:
   self.VVzLbH("echo %s >> '%s'" % (VVJgJQ, self.tmpFile), VVMB3d)
  else:
   self.VVWuAW(VVMB3d, lineNum, VVJgJQ)
 def VVWuAW(self, VVMB3d, lineNum, newTxt):
  VVMB3d.VVVdyU("Saving ...")
  lines = FFK66c(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVMB3d.VVSa4L()
  VV3CuM = self.VVJpJ9()
  VVMB3d.VVr5NB(VV3CuM)
 def VVzLbH(self, cmd, VVMB3d):
  tCons = CCmDe5()
  tCons.ePopen(cmd, boundFunction(self.VVLLoE, VVMB3d))
  self.fileChanged = True
  VVMB3d.VVSa4L()
 def VVLLoE(self, VVMB3d, result, retval):
  VV3CuM = self.VVJpJ9()
  VVMB3d.VVr5NB(VV3CuM)
 def VVJpJ9(self):
  if fileExists(self.tmpFile):
   lines = FFK66c(self.tmpFile)
   VV3CuM = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VV3CuM.append((str(ndx), line.strip()))
   if not VV3CuM:
    VV3CuM.append((str(1), ""))
   return VV3CuM
  else:
   FFTvTY(self.VVnt2W, self.tmpFile)
class CCbhk5():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VV64WM   = []
  self.satList   = []
 def VVghZC(self, VVtktQ):
  self.VV64WM = []
  VV64WM, VVTZK2 = self.VVWMgF(False, True)
  if VV64WM:
   self.VV64WM += VV64WM
   self.VVKUGV(VVtktQ, VVTZK2)
 def VVsOrb(self, mode, VVMB3d, satCol, VVtktQ):
  VVMB3d.VVVdyU("Loading Filters ...")
  self.VV64WM = []
  self.VV64WM.append(("All Services" , "all"))
  if mode == 1:
   self.VV64WM.append(VVB35E)
   self.VV64WM.append(("Parental Control", "parentalControl"))
   self.VV64WM.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VV64WM.append(VVB35E)
   self.VV64WM.append(("Selected Transponder"   , "selectedTP" ))
   self.VV64WM.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVjKyz(VVMB3d, satCol)
  VV64WM, VVTZK2 = self.VVWMgF(True, False)
  if VV64WM:
   VV64WM.insert(0, VVB35E)
   self.VV64WM += VV64WM
  VVMB3d.VVIZWg()
  self.VVKUGV(VVtktQ, VVTZK2)
 def VVUzgW(self, VV64WM, sats, VVtktQ):
  self.VV64WM = VV64WM
  VV64WM, VVTZK2 = self.VVWMgF(True, False)
  if VV64WM:
   self.VV64WM.append(VVB35E)
   self.VV64WM += VV64WM
  self.VVKUGV(VVtktQ, VVTZK2)
 def VVKUGV(self, VVtktQ, VVTZK2):
  VV78RH = ("Edit Filter", boundFunction(self.VV1SLB, VVTZK2))
  VVY0ds  = ("Filter Help", boundFunction(self.VVK0UZ, VVTZK2))
  FFUdxd(self.callingSELF, boundFunction(self.VV9MnI, VVtktQ), VV64WM=self.VV64WM, title="Select Filter", VV78RH=VV78RH, VVY0ds=VVY0ds)
 def VV9MnI(self, VVtktQ, item):
  if item:
   VVtktQ(item)
 def VV1SLB(self, VVTZK2, VVd1c8Obj, sel):
  if fileExists(VVTZK2) : CCfUC2(self.callingSELF, VVTZK2, VVtktQ=None)
  else       : FFTvTY(self.callingSELF, VVTZK2)
  VVd1c8Obj.cancel()
 def VVK0UZ(self, VVTZK2, VVd1c8Obj, sel):
  FFkCkL(self.callingSELF, VVe57v + "_help_service_filter", "Service Filter")
 def VVjKyz(self, VVMB3d, satColNum):
  if not self.satList:
   satList = VVMB3d.VVsBri(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFhYTe(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVB35E)
  if self.VV64WM:
   self.VV64WM += self.satList
 def VVWMgF(self, addTag, VVuaY6):
  FFfN32()
  fileName  = "ajpanel_services_filter"
  VVTZK2 = VVe6OI + fileName
  VV64WM  = []
  if not fileExists(VVTZK2):
   os.system(FFUJYt("cp -f '%s' '%s'" % (VVe57v + fileName, VVTZK2)))
  fileFound = False
  if fileExists(VVTZK2):
   fileFound = True
   lines = FFK66c(VVTZK2)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VV64WM.append((line, "__w__" + line))
       else  : VV64WM.append((line, line))
  if VVuaY6:
   if   not fileFound : FFTvTY(self.callingSELF , VVTZK2)
   elif not VV64WM : FF16em(self.callingSELF , VVTZK2)
  return VV64WM, VVTZK2
 @staticmethod
 def VVQhDw(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CCYdZD():
 def __init__(self, callingSELF, VVMB3d, refCodeColNum, addSep=True):
  self.callingSELF = callingSELF
  self.VVMB3d = VVMB3d
  self.refCodeColNum = refCodeColNum
  self.VV64WM = []
  iMulSel = self.VVMB3d.VVrNsh()
  if iMulSel : self.VV64WM.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VV64WM.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVMB3d.VVZiZc()
  self.VV64WM.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VV64WM.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VV64WM.append(VVB35E)
 def VVzsVM(self, servName):
  tot = self.VVMB3d.VVZiZc()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VV64WM.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVGdak_multi" ))
  else    : self.VV64WM.append( ("Add to Bouquet : %s"      % servName , "VVGdak_one" ))
 def VV8gP8(self, servName, refCode):
  self.VVzsVM(servName)
  self.VVhlUi(servName, refCode)
 def VV9azb(self, servName, refCode, pcState, hidState):
  isMulti = self.VVMB3d.VVoduh
  if isMulti:
   refCodeList = self.VVMB3d.VV8QuG(3)
   if refCodeList:
    self.VV64WM.append(("Add Selection to Parental Control"    , "parentalControl_sel_add"  ))
    self.VV64WM.append(("Remove Selection from Parental Control"   , "parentalControl_sel_remove" ))
    self.VV64WM.append(VVB35E)
    self.VV64WM.append(("Add Selection to Hidden Services"    , "hiddenServices_sel_add"  ))
    self.VV64WM.append(("Remove Selection from Hidden Services"   , "hiddenServices_sel_remove" ))
   else:
    self.VV64WM.pop(len(self.VV64WM) - 1)
  else:
   if pcState == "No" : self.VV64WM.append(("Add to Parental Control"  , "parentalControl_add"   ))
   else    : self.VV64WM.append(("Remove from Parental Control" , "parentalControl_remove"  ))
   self.VV64WM.append(VVB35E)
   if hidState == "No" : self.VV64WM.append(("Add to Hidden Services"  , "hiddenServices_add"   ))
   else    : self.VV64WM.append(("Remove from Hidden Services" , "hiddenServices_remove"  ))
  self.VV64WM.append(VVB35E)
  self.VVzsVM(servName)
  self.VVhlUi(servName, refCode)
 def VVhlUi(self, servName, refCode):
  FFUdxd(self.callingSELF, boundFunction(self.VVEyqk, servName, refCode), title="Options", VV64WM=self.VV64WM)
 def VVEyqk(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"     : self.VVMB3d.VVMC9a(True)
   elif item == "MultSelDisab"     : self.VVMB3d.VVMC9a(False)
   elif item == "selectAll"     : self.VVMB3d.VVb2VJ()
   elif item == "unselectAll"     : self.VVMB3d.VVNdD3()
   elif item == "parentalControl_add"   : self.callingSELF.VVlgNJ(self.VVMB3d, refCode, True)
   elif item == "parentalControl_remove"  : self.callingSELF.VVlgNJ(self.VVMB3d, refCode, False)
   elif item == "hiddenServices_add"   : self.callingSELF.VVJBXi(self.VVMB3d, refCode, True)
   elif item == "hiddenServices_remove"  : self.callingSELF.VVJBXi(self.VVMB3d, refCode, False)
   elif item == "parentalControl_sel_add"  : self.callingSELF.VVM9iW(self.VVMB3d, True)
   elif item == "parentalControl_sel_remove" : self.callingSELF.VVM9iW(self.VVMB3d, False)
   elif item == "hiddenServices_sel_add"  : self.callingSELF.VV3hO0(self.VVMB3d, True)
   elif item == "hiddenServices_sel_remove" : self.callingSELF.VV3hO0(self.VVMB3d, False)
   elif item == "VVGdak_multi"  : self.VVGdak(refCode, True)
   elif item == "VVGdak_one"  : self.VVGdak(refCode, False)
 def VVhdoH(self, VVMB3d):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  mSel   = CCYdZD(self, VVMB3d, 3)
  mSel.VV8gP8(servName, refCode)
 def VVGdak(self, refCode, isMulti):
  bouquets = FFtsF4()
  if bouquets:
   VV64WM = []
   for item in bouquets:
    VV64WM.append((item[0], item[1].toString()))
   VV78RH = ("Create New", boundFunction(self.VVrHIL, refCode, isMulti))
   FFUdxd(self.callingSELF, boundFunction(self.VVxAux, refCode, isMulti), VV64WM=VV64WM, title="Add to Bouquet", VV78RH=VV78RH, VVecAt=True, VVMYH9=True)
  else:
   FFysO2(self.callingSELF, boundFunction(self.VV2DCw, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVxAux(self, refCode, isMulti, bName=None):
  if bName:
   FFb4DW(self.VVMB3d, boundFunction(self.VVuv61, refCode, isMulti, bName), title="Adding Channels ...")
 def VVuv61(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVSkZp(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVMZAe = InfoBar.instance
    if VVMZAe:
     VVXEzV = VVMZAe.servicelist
     if VVXEzV:
      mutableList = VVXEzV.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVMB3d.VVIZWg()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFi9RU(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FF3wnI(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVSkZp(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVMB3d.VV8QuG(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVrHIL(self, refCode, isMulti, VVd1c8Obj, path):
  self.VV2DCw(refCode, isMulti)
 def VV2DCw(self, refCode, isMulti):
  FFaNVN(self.callingSELF, boundFunction(self.VV53eg, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VV53eg(self, refCode, isMulti, name):
  if name:
   FFb4DW(self.VVMB3d, boundFunction(self.VVyCDk, refCode, isMulti, name), title="Adding Channels ...")
 def VVyCDk(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVSkZp(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVMZAe = InfoBar.instance
    if VVMZAe:
     VVXEzV = VVMZAe.servicelist
     if VVXEzV:
      try:
       VVXEzV.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVXEzV.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVMB3d.VVIZWg()
   title = "Add to Bouquet"
   if allOK: FFi9RU(self.callingSELF, "Added to : %s" % name, title=title)
   else : FF3wnI(self.callingSELF, "Nothing added!", title=title)
class CCcGBJ(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhdcK(VV19tE, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFFgql(self)
  FF9CgN(self["keyRed"]  , "Exit")
  FF9CgN(self["keyGreen"]  , "Save")
  FF9CgN(self["keyYellow"] , "Refresh")
  FF9CgN(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVE1AF  ,
   "green"   : self.VVeetG ,
   "yellow"  : self.VVpERR  ,
   "blue"   : self.VVKHVt   ,
   "up"   : self.VVmeLf    ,
   "down"   : self.VVJgQv   ,
   "left"   : self.VVrCAA   ,
   "right"   : self.VVxaGR   ,
   "cancel"  : self.VVE1AF
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVpERR()
  self.VVrNO5()
  FF1rm3(self)
 def VVE1AF(self) : self.close(True)
 def VVhA0P(self) : self.close(False)
 def VVKHVt(self):
  self.session.openWithCallback(self.VVNmB5, boundFunction(CCRvYU))
 def VVNmB5(self, closeAll):
  if closeAll:
   self.close()
 def VVmeLf(self):
  self.VVChf5(1)
 def VVJgQv(self):
  self.VVChf5(-1)
 def VVrCAA(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVrNO5()
 def VVxaGR(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVrNO5()
 def VVChf5(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVk5Mn(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVk5Mn(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVk5Mn(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVcATe(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVcATe(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVrNO5(self):
  for obj in self.list:
   FFrlPO(obj, "#11404040")
  FFrlPO(self.list[self.index], "#11ff8000")
 def VVpERR(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVeetG(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCmDe5()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVQW0M)
 def VVQW0M(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFi9RU(self, "Nothing returned from the system!")
  else:
   FFi9RU(self, str(result))
class CCRvYU(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhdcK(VV9U6R, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFFgql(self, addLabel=True)
  FF9CgN(self["keyRed"]  , "Exit")
  FF9CgN(self["keyGreen"]  , "Sync")
  FF9CgN(self["keyYellow"] , "Refresh")
  FF9CgN(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVE1AF   ,
   "green"   : self.VVXvY6  ,
   "yellow"  : self.VVFeL1 ,
   "blue"   : self.VV4UZV  ,
   "cancel"  : self.VVE1AF
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVki5C()
  self.onShow.append(self.start)
 def start(self):
  FFSYWA(self.refresh)
  FF1rm3(self)
 def refresh(self):
  self.VVysQp()
  self.VVD3bA(False)
 def VVE1AF(self)  : self.close(True)
 def VV4UZV(self) : self.close(False)
 def VVki5C(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVysQp(self):
  self.VVkHco()
  self.VVO86e()
  self.VVuw7k()
  self.VVBq9r()
 def VVFeL1(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVki5C()
   self.VVysQp()
   FFSYWA(self.refresh)
 def VVXvY6(self):
  if len(self["keyGreen"].getText()) > 0:
   FFysO2(self, self.VVUEty, "Synchronize with Internet Date/Time ?")
 def VVUEty(self):
  self.VVysQp()
  FFSYWA(boundFunction(self.VVD3bA, True))
 def VVkHco(self)  : self["keyRed"].show()
 def VVuwZM(self)  : self["keyGreen"].show()
 def VVDCYZ(self) : self["keyYellow"].show()
 def VVsgku(self)  : self["keyBlue"].show()
 def VVO86e(self)  : self["keyGreen"].hide()
 def VVuw7k(self) : self["keyYellow"].hide()
 def VVBq9r(self)  : self["keyBlue"].hide()
 def VVD3bA(self, sync):
  localTime = FFNZmc()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VV9xd1(server)
   if epoch_time is not None:
    ntpTime = FFlXfZ(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCmDe5()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVQW0M, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVDCYZ()
  self.VVsgku()
  if ok:
   self.VVuwZM()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVQW0M(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVD3bA(False)
  except:
   pass
 def VV9xd1(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FF9SAM():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCgaZk(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFhdcK(VVcrrg, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFFgql(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FFSYWA(self.VVzzuZ)
 def VVzzuZ(self):
  if FF9SAM(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFrlPO(self["myBody"], color)
   FFrlPO(self["myLabel"], color)
  except:
   pass
class CCHLrq(Screen):
 def __init__(self, session, isFromExternal=False):
  size = CFG.signalSize.getValue()
  screenW = FFGpXP()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFhdcK(VV9gk8, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self.isFromExternal  = isFromExternal
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCGKSl(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCGKSl(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCGKSl(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCb4du()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFFgql(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVmeLf          ,
   "down"  : self.VVJgQv         ,
   "left"  : self.VVrCAA         ,
   "right"  : self.VVxaGR         ,
   "info"  : self.VVYbHQ        ,
   "epg"  : self.VVYbHQ        ,
   "menu"  : self.VVGdCL         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "blue"  : self.VVR9dW       ,
   "last"  : boundFunction(self.VV14h1, -1)  ,
   "next"  : boundFunction(self.VV14h1, 1)  ,
   "pageUp" : boundFunction(self.VVQTpi, True) ,
   "chanUp" : boundFunction(self.VVQTpi, True) ,
   "pageDown" : boundFunction(self.VVQTpi, False) ,
   "chanDown" : boundFunction(self.VVQTpi, False) ,
   "0"   : boundFunction(self.VV14h1, 0)  ,
   "1"   : boundFunction(self.VVy8sA, pos=1) ,
   "2"   : boundFunction(self.VVy8sA, pos=2) ,
   "3"   : boundFunction(self.VVy8sA, pos=3) ,
   "4"   : boundFunction(self.VVy8sA, pos=4) ,
   "5"   : boundFunction(self.VVy8sA, pos=5) ,
   "6"   : boundFunction(self.VVy8sA, pos=6) ,
   "7"   : boundFunction(self.VVy8sA, pos=7) ,
   "8"   : boundFunction(self.VVy8sA, pos=8) ,
   "9"   : boundFunction(self.VVy8sA, pos=9) ,
  }, -1)
  self.onShown.append(self.VV82q3)
  self.onClose.append(self.onExit)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  self.sliderSNR.VVE1CX()
  self.sliderAGC.VVE1CX()
  self.sliderBER.VVE1CX(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVy8sA()
  self.VVZS5MInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVZS5M)
  except:
   self.timer.callback.append(self.VVZS5M)
  self.timer.start(500, False)
 def VVZS5MInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVqUMR(service)
  serviceName = self.tunerInfo.VVHNop()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self)
  tp = CCkhMr()
  txt = tp.VVoIVz(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVZS5M(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVqUMR(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVRDzJ())
   self["mySNR"].setText(self.tunerInfo.VVrGL2())
   self["myAGC"].setText(self.tunerInfo.VVmNUR())
   self["myBER"].setText(self.tunerInfo.VVKMSK())
   self.sliderSNR.VVgUH8(self.tunerInfo.VVpqWU())
   self.sliderAGC.VVgUH8(self.tunerInfo.VVCxj6())
   self.sliderBER.VVgUH8(self.tunerInfo.VV2Nma())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVgUH8(0)
   self.sliderAGC.VVgUH8(0)
   self.sliderBER.VVgUH8(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self)
    if state and not state == "Tuned":
     FFmoBc(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVYbHQ(self):
  FFt65h(self, fncMode=CCc6Hf.VVlsAz)
 def VVGdCL(self):
  FFkCkL(self, VVe57v + "_help_signal", "Signal Monitor (Keys)")
 def VVR9dW(self):
  self.session.open(CCkjHt, isFromExternal=self.isFromExternal)
  self.close()
 def VVmeLf(self)  : self.VVy8sA(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVJgQv(self) : self.VVy8sA(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVrCAA(self) : self.VVy8sA(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVxaGR(self) : self.VVy8sA(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVy8sA(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VV14h1(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFwMj8(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVQTpi(self, isUp):
  FFmoBc(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVZS5MInfo()
  except:
   pass
class CCGKSl(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVE1CX(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFrlPO(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVe57v +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFrlPO(self.covObj, self.covColor)
   else:
    FFrlPO(self.covObj, "#00006688")
    self.isColormode = True
  self.VVgUH8(0)
 def VVgUH8(self, val):
  val  = FFwMj8(val, self.minN, self.maxN)
  width = int(FFQbFg(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFwMj8(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCbVFf(Screen):
 VVkoHr    = 0
 VVES7x = 1
 VVQAOc = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVtktQ=None, barTheme=VVkoHr):
  ratio = self.VVqUJU(barTheme)
  self.skin, self.skinParam = FFhdcK(VVLvRB, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVtktQ = VVtktQ
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVoIwV = None
  self.timer   = eTimer()
  self.myThread  = None
  FFFgql(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VV82q3)
  self.onClose.append(self.onExit)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  self.VV4pU7()
  self["myProgBarVal"].setText("0%")
  FFrlPO(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVT4Tq()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVT4Tq)
  except:
   self.timer.callback.append(self.VVT4Tq)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def VVTUhX(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VV5fDs_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVoIwV), self.counter, self.maxValue, catName)
 def VV5fDs_fromImportEPG(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VV5fDs_forcedUpdate(self, title):
  self.newTitle = title
  try:
   self.VVT4Tq()
  except:
   pass
 def VV7qoF(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VVoIwV), self.counter, self.maxValue)
  except:
   pass
 def VVSrBO(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVX19z(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VV4YWC(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFmoBc(self, "Cancelling ...")
  self.isCancelled = True
  self.VVs6tI(False)
 def VVs6tI(self, isDone):
  if self.VVtktQ:
   self.VVtktQ(isDone, self.VVoIwV, self.counter, self.maxValue, self.isError)
  self.close()
 def VVT4Tq(self):
  val = FFwMj8(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFQbFg(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VVs6tI(True)
 def VV4pU7(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVES7x, self.VVQAOc):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVqUJU(self, barTheme):
  if   barTheme == self.VVES7x : return 0.7
  if   barTheme == self.VVQAOc : return 0.5
  else             : return 1
class CCmDe5(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVtktQ = {}
  self.commandRunning = False
  self.VVPOOn  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVtktQ, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVtktQ[name] = VVtktQ
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVPOOn:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVI0hI, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVXNaC , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVI0hI, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVXNaC , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVXNaC(name, retval)
  return True
 def VVI0hI(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVXNaC(self, name, retval):
  if not self.VVPOOn:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVtktQ[name]:
   self.VVtktQ[name](self.appResults[name], retval)
  del self.VVtktQ[name]
 def VVoVJ2(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCGGXr(Screen):
 def __init__(self, session, title="", VVV9xk=None, VVXJUc=False, VVWC9a=False, VVVlNn=False, VVdzpq=False, VVOEgC=False, VVgFWw=False, VVsIwt=VVNiTo, VVc6vh=None, VVVBSD=False, VVp5se=None, VVWn0a="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFhdcK(VVCTjl, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFFgql(self, addScrollLabel=True)
  if not VVWn0a:
   VVWn0a = "Processing ..."
  self["myLabel"].setText("   %s" % VVWn0a)
  self.VVXJUc   = VVXJUc
  self.VVWC9a   = VVWC9a
  self.VVVlNn   = VVVlNn
  self.VVdzpq  = VVdzpq
  self.VVOEgC = VVOEgC
  self.VVgFWw = VVgFWw
  self.VVsIwt   = VVsIwt
  self.VVc6vh = VVc6vh
  self.VVVBSD  = VVVBSD
  self.VVp5se  = VVp5se
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCmDe5()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFkYLf()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVV9xk, str):
   self.VVV9xk = [VVV9xk]
  else:
   self.VVV9xk = VVV9xk
  if self.VVVlNn or self.VVdzpq:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVFkPZ, VVFkPZ)
   self.VVV9xk.append("echo -e '\n%s\n' %s" % (restartNote, FF8OuG(restartNote, VVgcU9)))
   if self.VVVlNn:
    self.VVV9xk.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVV9xk.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVOEgC:
   FFmoBc(self, "Processing ...")
  self.onLayoutFinish.append(self.VVxEN4)
  self.onClose.append(self.VVqfv6)
 def VVxEN4(self):
  self["myLabel"].VVdsWe(textOutFile="console" if self.enableSaveRes else "")
  if self.VVXJUc:
   self["myLabel"].VVxD83()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVgCKQ()
  else:
   self.VV7XGu()
 def VVgCKQ(self):
  if FF9SAM():
   self["myLabel"].setText("Processing ...")
   self.VV7XGu()
  else:
   self["myLabel"].setText(FFtsFe("\n   No connection to internet!", VVValh))
 def VV7XGu(self):
  allOK = self.container.ePopen(self.VVV9xk[0], self.VVh3R7, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVh3R7("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVgFWw or self.VVVlNn or self.VVdzpq:
    self["myLabel"].setText(FF82X1("STARTED", VVgcU9) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVp5se:
   colorWhite = CCpI1P.VVkC9W(VVXaUF)
   color  = CCpI1P.VVkC9W(self.VVp5se[0])
   words  = self.VVp5se[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVsIwt=self.VVsIwt)
 def VVh3R7(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVV9xk):
   allOK = self.container.ePopen(self.VVV9xk[self.cmdNum], self.VVh3R7, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVh3R7("Cannot connect to Console!", -1)
  else:
   if self.VVOEgC and FFytTf(self):
    FFmoBc(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVgFWw:
    self["myLabel"].appendText("\n" + FF82X1("FINISHED", VVgcU9), self.VVsIwt)
   if self.VVXJUc or self.VVWC9a:
    self["myLabel"].VVxD83()
   if self.VVc6vh is not None:
    self.VVc6vh()
   if not retval and self.VVVBSD:
    self.VVqfv6()
 def VVqfv6(self):
  if self.container.VVoVJ2():
   self.container.killAll()
class CC1Gfu(Screen):
 def __init__(self, session, VVV9xk=None, VVOEgC=False):
  self.skin, self.skinParam = FFhdcK(VVCTjl, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVe6OI + "ajpanel_terminal.history"
  self.customCommandsFile = VVe6OI + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFhOpk("pwd") or "/home/root"
  self.container   = CCmDe5()
  FFFgql(self, addScrollLabel=True)
  FF9CgN(self["keyRed"] , "Exit = Stop Command")
  FF9CgN(self["keyGreen"] , "OK = History")
  FF9CgN(self["keyYellow"], "Menu = Custom Cmds")
  FF9CgN(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVMdTP ,
   "cancel" : self.VVS34J  ,
   "menu"  : self.VVzRyQ ,
   "last"  : self.VV2Gr3  ,
   "next"  : self.VV2Gr3  ,
   "1"   : self.VV2Gr3  ,
   "2"   : self.VV2Gr3  ,
   "3"   : self.VV2Gr3  ,
   "4"   : self.VV2Gr3  ,
   "5"   : self.VV2Gr3  ,
   "6"   : self.VV2Gr3  ,
   "7"   : self.VV2Gr3  ,
   "8"   : self.VV2Gr3  ,
   "9"   : self.VV2Gr3  ,
   "0"   : self.VV2Gr3
  })
  self.onLayoutFinish.append(self.VV82q3)
  self.onClose.append(self.VV4bp3)
 def VV82q3(self):
  self["myLabel"].VVdsWe(isResizable=False, textOutFile="terminal")
  FFaMdN(self["keyRed"]  , "#00ff8000")
  FFrlPO(self["keyRed"]  , self.skinParam["titleColor"])
  FFrlPO(self["keyGreen"]  , self.skinParam["titleColor"])
  FFrlPO(self["keyYellow"] , self.skinParam["titleColor"])
  FFrlPO(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVKR45(FFhOpk("date"), 5)
  result = FFhOpk("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVvink()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVe57v + "LinuxCommands.lst"
   newTemplate = VVe57v + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFUJYt("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFUJYt("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VV4bp3(self):
  if self.container.VVoVJ2():
   self.container.killAll()
   self.VVKR45("Process killed\n", 4)
   self.VVvink()
 def VVS34J(self):
  if self.container.VVoVJ2():
   self.VV4bp3()
  else:
   FFysO2(self, self.close, "Exit ?", VVZRHB=False)
 def VVvink(self):
  self.VVKR45(self.prompt, 1)
  self["keyRed"].hide()
 def VVKR45(self, txt, mode):
  if   mode == 1 : color = VVgcU9
  elif mode == 2 : color = VVzqsa
  elif mode == 3 : color = VVXaUF
  elif mode == 4 : color = VVValh
  elif mode == 5 : color = VVBPJz
  elif mode == 6 : color = VVM75e
  else   : color = VVXaUF
  try:
   self["myLabel"].appendText(FFtsFe(txt, color))
  except:
   pass
 def VVGIyp(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVKR45(cmd, 2)
   self.VVKR45("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVKR45(ch, 0)
   self.VVKR45("\nor\n", 4)
   self.VVKR45("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVvink()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFtsFe(parts[0].strip(), VVzqsa)
    right = FFtsFe("#" + parts[1].strip(), VVM75e)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVKR45(txt, 2)
   lastLine = self.VVlcYT()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VV8vwv(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVh3R7, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FF3wnI(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVKR45(data, 3)
 def VVh3R7(self, data, retval):
  if not retval == 0:
   self.VVKR45("Exit Code : %d\n" % retval, 4)
  self.VVvink()
 def VVMdTP(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVlcYT() == "":
   self.VV8vwv("cd /tmp")
   self.VV8vwv("ls")
  VV3CuM = []
  if fileExists(self.commandHistoryFile):
   lines  = FFK66c(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VV3CuM.append((str(c), line, str(lNum)))
   self.VVuwiY(VV3CuM, title, self.commandHistoryFile, isHistory=True)
  else:
   FFTvTY(self, self.commandHistoryFile, title=title)
 def VVlcYT(self):
  lastLine = FFhOpk("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VV8vwv(self, cmd):
  os.system("echo '%s' >> %s" % (str(cmd.encode("UTF-8")), str(self.commandHistoryFile)))
 def VVzRyQ(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFK66c(self.customCommandsFile)
   lastLineIsSep = False
   VV3CuM = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VV3CuM.append((str(c), line, str(lNum)))
   self.VVuwiY(VV3CuM, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFTvTY(self, self.customCommandsFile, title=title)
 def VVuwiY(self, VV3CuM, title, filePath=None, isHistory=False):
  if VV3CuM:
   VVrJH1 = "#05333333"
   if isHistory: VVPUaR = VV1PI5 = VVLubA = "#11000020"
   else  : VVPUaR = VV1PI5 = VVLubA = "#06002020"
   VVHxLO = VVDrmo = None
   VVyMeP   = ("Send"   , self.VVpLxX        , [])
   VVVDdh  = ("Modify & Send" , self.VVrwmI        , [])
   if isHistory:
    VVHxLO = ("Clear History" , self.VVLfBV        , [])
   elif filePath:
    VVDrmo = ("Edit File"  , boundFunction(self.VVM0jE, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVnesb     = (CENTER  , LEFT   , CENTER )
   FFynj9(self, None, title=title, header=header, VVATVO=VV3CuM, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=26, VVyMeP=VVyMeP, VVVDdh=VVVDdh, VVHxLO=VVHxLO, VVDrmo=VVDrmo, VVzmtH=True
     , VVPUaR   = VVPUaR
     , VV1PI5   = VV1PI5
     , VVLubA   = VVLubA
     , VV7cLV  = "#05ffff00"
     , VVrJH1  = VVrJH1
    )
  else:
   FF16em(self, filePath, title=title)
 def VVpLxX(self, VVMB3d, title, txt, colList):
  cmd = colList[1].strip()
  VVMB3d.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVKR45("\n%s\n" % cmd, 6)
   self.VVKR45(self.prompt, 1)
  else:
   self.VVGIyp(cmd)
 def VVrwmI(self, VVMB3d, title, txt, colList):
  cmd = colList[1]
  self.VV0KUX(VVMB3d, cmd)
 def VVLfBV(self, VVMB3d, title, txt, colList):
  FFysO2(self, boundFunction(self.VViAGG, VVMB3d), "Reset History File ?", title="Command History")
 def VViAGG(self, VVMB3d):
  os.system(FFUJYt("echo '' > %s" % self.commandHistoryFile))
  VVMB3d.cancel()
 def VVM0jE(self, filePath, VVMB3d, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCfUC2(self, filePath, VVtktQ=boundFunction(self.VVFH7s, VVMB3d), curRowNum=rowNum)
  else     : FFTvTY(self, filePath)
 def VVFH7s(self, VVMB3d, fileChanged):
  if fileChanged:
   VVMB3d.cancel()
   FFSYWA(self.VVzRyQ)
 def VV2Gr3(self):
  self.VV0KUX(None, self.lastCommand)
 def VV0KUX(self, VVMB3d, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFaNVN(self, boundFunction(self.VVUMCb, VVMB3d), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVUMCb(self, VVMB3d, cmd):
  if cmd and len(cmd) > 0:
   self.VVGIyp(cmd)
   if VVMB3d:
    VVMB3d.cancel()
class CC7aa4(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVtkVj="", VVSe1N=False, VVLoeV=False, isTrimEnds=True):
  self.skin, self.skinParam = FFhdcK(VVIrXs, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFFgql(self, title, addLabel=True)
  FF9CgN(self["keyRed"] , "Up/Down = Change")
  FF9CgN(self["keyGreen"] , "Overwrite")
  FF9CgN(self["keyYellow"], "Pick Key Map")
  FF9CgN(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVLoeV   = VVLoeV
  self.VVSe1N  = VVSe1N
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVtkVj, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVsqjn      ,
   "green"    : self.VVVrcn    ,
   "yellow"   : self.VVjt8L      ,
   "blue"    : self.VVqtIh     ,
   "menu"    : self.VVc7Zy     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVe3CF, True) ,
   "down"    : boundFunction(self.VVe3CF, False) ,
   "left"    : self.VVVE9f       ,
   "right"    : self.VVat1x       ,
   "home"    : self.VVr9MU       ,
   "end"    : self.VVeQiY       ,
   "next"    : self.VVoKsX      ,
   "last"    : self.VV5bIZ      ,
   "deleteForward"  : self.VVoKsX      ,
   "deleteBackward" : self.VV5bIZ      ,
   "tab"    : self.VVyClY       ,
   "toggleOverwrite" : self.VVVrcn    ,
   "0"     : self.VVHgA9     ,
   "1"     : self.VVHgA9     ,
   "2"     : self.VVHgA9     ,
   "3"     : self.VVHgA9     ,
   "4"     : self.VVHgA9     ,
   "5"     : self.VVHgA9     ,
   "6"     : self.VVHgA9     ,
   "7"     : self.VVHgA9     ,
   "8"     : self.VVHgA9     ,
   "9"     : self.VVHgA9
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VV4op9()
  self.onShown.append(self.VV82q3)
  self.onClose.append(self.onExit)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FFb93v(self)
  self["myLabel"].setText(self.message)
  self.VVR9Ue()
  if self.VVSe1N : self.VVVrcn()
  else    : self.VV2u0d()
  FF1rm3(self)
  FFrlPO(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV5gGQ)
  except:
   self.timer.callback.append(self.VV5gGQ)
 def onExit(self):
  self.timer.stop()
 def VVsqjn(self):
  self.VVkMkT()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVkMkT()
  self.close(None)
 def VVc7Zy(self):
  VV64WM = []
  VV64WM.append(("Home"         , "home"    ))
  VV64WM.append(("End"         , "end"     ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Clear All"       , "clearAll"   ))
  VV64WM.append(("Clear To Home"      , "clearToHome"   ))
  VV64WM.append(("Clear To End"       , "clearToEnd"   ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVJgJQ:
   VV64WM.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VV64WM.append(VVB35E)
  VV64WM.append(("To Capital Letters"     , "toCapital"   ))
  VV64WM.append(("To Small Letters"      , "toSmall"    ))
  FFUdxd(self, self.VVkcCl, title="Edit Options", VV64WM=VV64WM)
 def VVkcCl(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVr9MU()
   elif item == "end"     : self.VVeQiY()
   elif item == "clearAll"    : self.VVzmko()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVr9MU()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVJgJQ
    VVJgJQ = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVJgJQ)
    self.VVr9MU()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VV5gGQ(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVVrcn(self):
  self["myInput"].toggleOverwrite()
  self.VV2u0d()
 def VVjt8L(self):
  self.session.openWithCallback(self.VVmXhz, boundFunction(CCbHt5, mode=self.charMode, VVLoeV=self.VVLoeV))
 def VVmXhz(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVR9Ue()
 def VV2u0d(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VV4op9(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVkMkT(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVIvDI(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVVE9f(self)     : self.VVJNUY(self["myInput"].left)
 def VVat1x(self)     : self.VVJNUY(self["myInput"].right)
 def VVoKsX(self)     : self.VVJNUY(self["myInput"].delete)
 def VVr9MU(self)     : self.VVJNUY(self["myInput"].home)
 def VVeQiY(self)     : self.VVJNUY(self["myInput"].end)
 def VV5bIZ(self)    : self.VVJNUY(self["myInput"].deleteBackward)
 def VVyClY(self)     : self.VVJNUY(self["myInput"].tab)
 def VVzmko(self)     : self["myInput"].setText("")
 def VVJNUY(self, fnc):
  fnc()
  self.VV5gGQ()
 def VVHgA9(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVIvDI(newChar, overwrite)
   self.VVNIUP(newChar, self["myInput"].mapping[number])
 def VVe3CF(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCbHt5.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCbHt5.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVIvDI(newChar, True)
   for group in groups:
    if newChar in group:
     self.VVNIUP(newChar, group)
     break
 def VVNIUP(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVXaUF:
    group = VVBPJz + group.replace(newChar, FFtsFe(newChar, VVXaUF, VVBPJz))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVqtIh(self):
  if self.VVLoeV : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVR9Ue()
 def VVR9Ue(self):
  self["myInput"].mapping = CCbHt5.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCbHt5.RCU_MAP_TITLES[self.charMode])
class CCbHt5(Screen):
 VVzGX9  = 0
 VVQrBq  = 1
 VVLOqU  = 2
 VVkvO8  = 3
 VVCGen = 4
 VVDPfJ = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols , arabic_nums1, arabic1)
       , ( symbols , arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A", u"\u0628")
       , (u"\u0647", u"\u062A")
       )
 def __init__(self, session, mode=VVzGX9, VVLoeV=False):
  self.skin, self.skinParam = FFhdcK(VVsdkx, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVLoeV  = VVLoeV
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFFgql(self, title=self.Title)
  FF9CgN(self["keyRed"] ,"OK = Select")
  FF9CgN(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVtsDf     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVolit, -1) ,
   "next"  : boundFunction(self.VVolit, +1) ,
   "left"  : boundFunction(self.VVolit, -1) ,
   "right"  : boundFunction(self.VVolit, +1) ,
  }, -1)
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FFrlPO(self["keyRed"], "#11222222")
  FFrlPO(self["keyGreen"], "#11222222")
  self.VVGIbJ()
 def VVGIbJ(self):
  self.VVmpBI()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVmpBI(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVolit(self, direction):
  if self.VVLoeV : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVGIbJ()
 def VVtsDf(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCeZgx(Screen):
 def __init__(self, session, title="", message="", VVsIwt=VVNiTo, VVqTIr=False, VVLubA=None, VV4RrQ=30, canSaveToFile=""):
  self.skin, self.skinParam = FFhdcK(VVCTjl, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VV4RrQ)
  self.session   = session
  FFFgql(self, title, addScrollLabel=True)
  self.VVsIwt   = VVsIwt
  self.VVqTIr   = VVqTIr
  self.VVLubA   = VVLubA
  self.canSaveToFile  = canSaveToFile
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  self["myLabel"].VVdsWe(VVqTIr=self.VVqTIr, textOutFile=self.canSaveToFile)
  self["myLabel"].setText(self.message, self.VVsIwt)
  if self.VVLubA:
   FFrlPO(self["myBody"], self.VVLubA)
   FFrlPO(self["myLabel"], self.VVLubA)
   FFFLw5(self["myLabel"], self.VVLubA)
  self["myLabel"].VVxD83()
class CCWr24(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFhdcK(VVYI3s, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFFgql(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FF5IjG(self["errPic"], "err")
class CChe4r(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FFhdcK(VVx4P1, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", 20)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFFgql(self, " ", addCloser=True)
class CCus7a():
 def __init__(self, session, txt):
  self.win = session.instantiateDialog(CChe4r, txt)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV0Khc)
  except:
   self.timer.callback.append(self.VV0Khc)
  self.timer.start(1500, True)
 def VV0Khc(self):
  self.session.deleteDialog(self.win)
class CCL4WW():
 VV0prE    = 0
 VVBnoc  = 1
 VVyj7V   = ""
 VV9Oi3    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVMB3d   = None
  self.timer     = eTimer()
  self.VVKny8   = 0
  self.VVsWRu  = 1
  self.VVYloO  = 2
  self.VVmNWE   = 3
  self.VVi5L5   = 4
  VV3CuM = self.VVzcVm()
  if VV3CuM:
   self.VVMB3d = self.VVvQpG(VV3CuM)
  if not VV3CuM and mode == self.VV0prE:
   self.VVuaY6or("Download list is empty !")
   self.cancel()
  if mode == self.VVBnoc:
   FFb4DW(self.VVMB3d or self.SELF, boundFunction(self.VVStYC, startDnld, decodedUrl), title="Checking Server ...")
  self.VVk4L9(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVk4L9)
  except:
   self.timer.callback.append(self.VVk4L9)
  self.timer.start(1000, False)
 def VVvQpG(self, VV3CuM):
  VV3CuM.sort(key=lambda x: int(x[0]))
  VVUKxL = self.VVPvko
  VVyMeP  = ("Play"  , self.VVZWRf , [])
  VV4SDx = (""   , self.VVF91b  , [])
  VVFile = ("Stop"  , self.VV2YZJ  , [])
  VVVDdh = ("Resume"  , self.VVt5Pi , [])
  VVHxLO = ("Options" , self.VVPhSf  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVnesb  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFynj9(self.SELF, None, title=self.Title, header=header, VVATVO=VV3CuM, VVnesb=VVnesb, VVeJNW=widths, VV4RrQ=26, VVyMeP=VVyMeP, VV4SDx=VV4SDx, VVUKxL=VVUKxL, VVFile=VVFile, VVVDdh=VVVDdh, VVHxLO=VVHxLO, VV1PI5="#11110011", VVPUaR="#11220022", VVLubA="#11110011", VV7cLV="#00ffff00", VVrJH1="#00223025", VVndWP="#0a333333", VVleo7="#0a400040", VVzmtH=True, searchCol=1)
 def VVzcVm(self):
  lines = CCL4WW.VVyXDY()
  VV3CuM = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",")
     left  = parts[0].strip()
     decodedUrl = ",".join(parts[1:]).strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVCWdL(decodedUrl)
      if fName:
       if   FFMgGK(decodedUrl) : sType = "Movie"
       elif FFRiSY(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVzrT4(decodedUrl, fName)
       if size > -1: sizeTxt = CCN0r2.VVAajP(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VV3CuM.append((str(len(VV3CuM) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VV3CuM
 def VVZUjT(self):
  VV3CuM = self.VVzcVm()
  if VV3CuM:
   if self.VVMB3d : self.VVMB3d.VVr5NB(VV3CuM, VVki5CMsg=False)
   else     : self.VVMB3d = self.VVvQpG(VV3CuM)
  else:
   self.cancel()
 def VVk4L9(self, force=False):
  if self.VVMB3d:
   thrList = self.VVZtua()
   VV3CuM = []
   changed = False
   for ndx, row in enumerate(self.VVMB3d.VVsLdG()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVKny8
    if m3u8Log:
     percent = self.VVDFWE(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVmNWE , "%.2f %%" % percent
      else   : flag, progr = self.VVi5L5 , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFmOde(mPath)
     if curSize > -1:
      fSize = CCN0r2.VVAajP(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCN0r2.VVAajP(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFmOde(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVmNWE , "%.2f %%" % percent
       else   : flag, progr = self.VVi5L5 , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCN0r2.VVAajP(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrList:
     flag = self.VVYloO
     if m3u8Log :
      if not speed and not force : flag = self.VVsWRu
      elif curSize == -1   : self.VVFRFQ(False)
    elif flag == self.VVKny8  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVKny8  : color2 = "#f#00555555#"
    elif flag == self.VVsWRu : color2 = "#f#0000FFFF#"
    elif flag == self.VVYloO : color2 = "#f#0000FFFF#"
    elif flag == self.VVmNWE  : color2 = "#f#00FF8000#"
    elif flag == self.VVi5L5  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVjwqX(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VV3CuM.append(row)
   if changed or force:
    self.VVMB3d.VVr5NB(VV3CuM, VVki5CMsg=False)
 def VVjwqX(self, flag):
  tDict = self.VVsdTf()
  return tDict.get(flag, "?")
 def VVSqy1(self, state):
  for flag, txt in self.VVsdTf().items():
   if txt == state:
    return flag
  return -1
 def VVsdTf(self):
  return { self.VVKny8: "Not started", self.VVsWRu: "Connecting", self.VVYloO: "Downloading", self.VVmNWE: "Stopped", self.VVi5L5: "Completed" }
 def VVTOAU(self, title):
  colList = self.VVMB3d.VVQnoN()
  path = colList[6]
  url  = colList[8]
  if self.VVUX39() : self.VVuaY6or("Cannot delete !\n\nFile is downloading.")
  else      : FFysO2(self.SELF, boundFunction(self.VVMRVS, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVMRVS(self, path, url):
  m3u8Log = self.VVMB3d.VVQnoN()[12].strip()
  if m3u8Log : os.system(FFUJYt("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFUJYt("rm -r '%s'" % path))
  self.VVozoM()
  self.VVZUjT()
 def VVozoM(self):
  if self.VVUX39():
   FFmoBc(self.VVMB3d, self.VVjwqX(self.VVYloO), 500)
  else:
   colList  = self.VVMB3d.VVQnoN()
   state  = colList[4].strip()
   decodedUrl = colList[9].strip()
   if self.VVSqy1(state) in (self.VVKny8, self.VVi5L5):
    lines = CCL4WW.VVyXDY()
    newLines = []
    found = False
    for line in lines:
     if CCL4WW.VVEf4W(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VV4epu(newLines)
     self.VVZUjT()
     FFmoBc(self.VVMB3d, "Removed.", 1000)
    else:
     FFmoBc(self.VVMB3d, "Not found.", 1000)
   else:
    self.VVuaY6or("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VV9r16(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFysO2(self.SELF, boundFunction(self.VVYoM9, flag), ques, title=title)
 def VVYoM9(self, flag):
  list = []
  for ndx, row in enumerate(self.VVMB3d.VVsLdG()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVSqy1(state)
   if   flag == flagVal == self.VVi5L5: list.append(decodedUrl)
   elif flag == flagVal == self.VVKny8 : list.append(decodedUrl)
  lines = CCL4WW.VVyXDY()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VV4epu(newLines)
   self.VVZUjT()
   FFmoBc(self.VVMB3d, "%d removed." % totRem, 1000)
  else:
   FFmoBc(self.VVMB3d, "Not found.", 1000)
 def VVSXsw(self):
  colList  = self.VVMB3d.VVQnoN()
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFmoBc(self.VVMB3d, "Poster exists", 1500)
  else    : FFb4DW(self.VVMB3d, boundFunction(self.VVE3Oa, decodedUrl, path, png), title="Checking Server ...")
 def VVE3Oa(self, decodedUrl, path, png):
  err = self.VVjujs(decodedUrl, path, png)
  if err:
   FF3wnI(self.SELF, err, title="Poster Download")
 def VVjujs(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCpWxg.VVSNrE(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCNFtw.VVH2YO(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCNFtw.VVfEog(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCNFtw.VVmQRI(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if pUrl:
   ext = os.path.splitext(pUrl)[1] or ".png"
   tPath, err = FFd8ee(pUrl, "ajpanel_tmp%s", timeout=2, mustBeImage=True)
   if err:
    return "Cannot download poster !\n\n%s" % err
   else:
    png = "%s%s" % (os.path.splitext(path)[0], ext)
    os.system(FFUJYt("mv -f '%s' '%s'" % (tPath, png)))
    FFIOvl(self.SELF, title=os.path.basename(png), VVXmFj=png, showGrnMsg="Downloaded")
  else:
   return "Cannot get Poster URL !\n\n%s" % err
  return ""
 def VVF91b(self, VVMB3d, title, txt, colList):
  def VVLucE(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVABtc(key, val) : return "\n%s:\n%s\n" % (FFtsFe(key, COLOR_CONS_BRIGHT_YELLOW), val.strip())
  heads  = self.VVMB3d.VVkr43()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVLucE(heads[i]  , CCN0r2.VVAajP(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVLucE("Downloaded" , CCN0r2.VVAajP(int(curSize), mode=0))
   else:
    txt += VVLucE(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVABtc(heads[i], colList[i])
  FFR6iW(self.SELF, txt, title=title)
 def VVZWRf(self, VVMB3d, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCN0r2.VVlK5w(self.SELF, path)
  else    : FFmoBc(self.VVMB3d, "File not found", 1000)
 def VVPvko(self, VVMB3d):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVMB3d:
   self.VVMB3d.cancel()
  del self
 def VVPhSf(self, VVMB3d, title, txt, colList):
  decodedUrl = colList[9].strip()
  if CFG.downloadAutoResume.getValue(): resumeTxt = "Disable"
  else        : resumeTxt = "Enable"
  VV64WM = []
  VV64WM.append(("Remove current row"      , "VVozoM"  ))
  VV64WM.append(VVB35E)
  VV64WM.append(('Remove all "Completed"'     , "remFinished"    ))
  VV64WM.append(('Remove all "Not started"'     , "remPending"    ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Delete the file (and remove from list)" , "VVTOAU" ))
  if FFMgGK(decodedUrl):
   VV64WM.append(VVB35E)
   VV64WM.append(("Download Movie Poster (from server)" , "VVSXsw"   ))
  VV64WM.append(VVB35E)
  VV64WM.append((resumeTxt + " Auto Resume"     , "VVPhKp"  ))
  FFUdxd(self.SELF, self.VVqdqn, VV64WM=VV64WM, title=self.Title, VVecAt=True, VVMYH9=True)
 def VVqdqn(self, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVozoM"  : self.VVozoM()
   elif ref == "remFinished"   : self.VV9r16(self.VVi5L5, txt)
   elif ref == "remPending"   : self.VV9r16(self.VVKny8, txt)
   elif ref == "VVTOAU" : self.VVTOAU(txt)
   elif ref == "VVSXsw"  : self.VVSXsw()
   elif ref == "VVPhKp"  : self.VVPhKp()
 def VVStYC(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCpWxg.VVSNrE(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVuaY6or("Could not get download link !\n\nTry again later.")
     return
  for line in CCL4WW.VVyXDY():
   if CCL4WW.VVEf4W(decodedUrl, line):
    self.VVw6GP(decodedUrl)
    FFSYWA(boundFunction(FFmoBc, self.VVMB3d, "Already listed !", 2000))
    break
  else:
   params = self.VV3eJI(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVuaY6or(params[0])
   elif len(params) == 2:
    self.VVTIAv(params[0], decodedUrl)
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCN0r2.VVAajP(fSize)
    FFysO2(self.SELF, boundFunction(self.VVIl9F, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVIl9F(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCL4WW.VVcEr0(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVZUjT()
  if self.VVMB3d:
   self.VVMB3d.VV5H2s()
  if startDnld:
   threadName = self.VV9Oi3 + decodedUrl
   self.VVASTF(threadName, url, decodedUrl, path, resp)
 def VVw6GP(self, decodedUrl):
  for ndx, row in enumerate(self.VVMB3d.VVsLdG()):
   decodedUrl2 = row[9].strip()
   if decodedUrl == decodedUrl2 and self.VVMB3d:
    self.VVMB3d.VVIAsB(ndx)
    break
 def VV3eJI(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVCWdL(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVzrT4(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCpWxg.VVSNrE(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCpWxg.VVg7EPHeader()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head["Content-Length"]
   cType = head["Content-Type"]
   if not "video" in cType:
    if resp.url.endswith(".m3u8"):
     return [resp, 1]
    else:
     return ["Cannot download this video !\n\nNot allowed by server."]
   if "Accept-Ranges" in head:
    resume = head["Accept-Ranges"]
    if not resume == "none":
     resumable = True
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  err = CCL4WW.VVhJJK(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVTIAv(self, resp, decodedUrl):
  if not os.system(FFUJYt("which ffmpeg")) == 0:
   FFysO2(self.SELF, boundFunction(CCNFtw.VVwhAT, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVCWdL(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVGpDi(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFysO2(self.SELF, boundFunction(self.VVeMFN, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVeMFN(rTxt, rUrl)
  else:
   self.VVuaY6or("Cannot process m3u8 file !")
 def VVGpDi(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VV64WM = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCNFtw.VVqTaq(rUrl, fPath)
   VV64WM.append((resol, fullUrl))
  if VV64WM:
   FFUdxd(self.SELF, self.VV41vh, VV64WM=VV64WM, title="Resolution", VVecAt=True, VVMYH9=True)
  else:
   self.VVuaY6or("Cannot get Resolutions list from server !")
 def VV41vh(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFysO2(self.SELF, boundFunction(FFSYWA, boundFunction(self.VVSjzA, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFSYWA(boundFunction(self.VVSjzA, resolUrl))
 def VVSjzA(self, resolUrl):
  txt, err = CCpWxg.VVgMVZ(resolUrl)
  if err : self.VVuaY6or(err)
  else : self.VVeMFN(txt, resolUrl)
 def VVJwFt(self, logF, decodedUrl):
  found = False
  lines = CCL4WW.VVyXDY()
  with open(CCL4WW.VVcEr0(), "w") as f:
   for line in lines:
    if CCL4WW.VVEf4W(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCL4WW.VVcEr0(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVZUjT()
 def VVeMFN(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCNFtw.VVqTaq(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVuaY6or("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVJwFt(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFUJYt("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = self.VV9Oi3 + decodedUrl
  myThread = iThread(name=threadName, target=boundFunction(os.system, cmd))
  myThread.start()
 def VVDFWE(self, dnldLog):
  if fileExists(dnldLog):
   dur = self.VVzDbf(dnldLog)
   if dur > -1:
    tim = self.VV2giQ(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 def VVzDbf(self, dnldLog):
  lines = FFo68R("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VV2giQ(self, dnldLog):
  lines = FFo68R("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVzrT4(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFRiSY(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFUJYt("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVASTF(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVMB3d.VVQnoN()[7].strip())
  myThread = iThread(name=threadName, target=boundFunction(self.VVlv81, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVlv81(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if CCL4WW.VVyj7V == path:
       break
     else:
      break
  except:
   return
  if CCL4WW.VVyj7V:
   CCL4WW.VVyj7V = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFmOde(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VV3eJI(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVlv81(url, decodedUrl, path, resp, totFileSize, True)
 def VV2YZJ(self, VVMB3d, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVb4GI() : FFmoBc(self.VVMB3d, self.VVjwqX(self.VVi5L5), 500)
  elif not self.VVUX39() : FFmoBc(self.VVMB3d, self.VVjwqX(self.VVmNWE), 500)
  elif m3u8Log      : FFysO2(self.SELF, self.VVFRFQ, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVZtua():
    CCL4WW.VVyj7V = colList[6]
    FFmoBc(self.VVMB3d, "Stopping ...", 1000)
   else:
    FFmoBc(self.VVMB3d, "Stopped", 500)
 def VVFRFQ(self, withMsg=True):
  if withMsg:
   FFmoBc(self.VVMB3d, "Stopping ...", 1000)
  os.system(FFUJYt("killall -INT ffmpeg"))
 def VVPhKp(self):
  CFG.downloadAutoResume.setValue(not CFG.downloadAutoResume.getValue())
  CFG.downloadAutoResume.save()
  configfile.save()
 def VVt5Pi(self, *args):
  if   self.VVb4GI() : FFmoBc(self.VVMB3d, self.VVjwqX(self.VVi5L5) , 500)
  elif self.VVUX39() : FFmoBc(self.VVMB3d, self.VVjwqX(self.VVYloO), 500)
  else:
   resume = False
   m3u8Log = self.VVMB3d.VVQnoN()[12].strip()
   if m3u8Log:
    if fileExists(m3u8Log) : FFysO2(self.SELF, boundFunction(self.VVi3R9, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVTYlx():
    resume = True
   if resume: FFb4DW(self.VVMB3d, boundFunction(self.VVXhZB), title="Checking Server ...")
   else  : FFmoBc(self.VVMB3d, "Cannot resume !", 500)
 def VVi3R9(self, m3u8Log):
  os.system(FFUJYt("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFb4DW(self.VVMB3d, boundFunction(self.VVXhZB), title="Checking Server ...")
 def VVXhZB(self):
  colList  = self.VVMB3d.VVQnoN()
  path  = colList[6].strip()
  size  = colList[7].strip()
  decodedUrl = colList[9].strip()
  if "j.php" in decodedUrl:
   url = CCpWxg.VVSNrE(decodedUrl)
   if url:
    decodedUrl = self.VVTb00(decodedUrl, url)
   else:
    self.VVuaY6or("Could not get download link !\n\nTry again later.")
    return
  curSize = FFmOde(path)
  params = self.VV3eJI(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVuaY6or(params[0])
   return
  elif len(params) == 2:
   self.VVTIAv(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVTb00(decodedUrl, url, fSize)
  threadName = self.VV9Oi3 + decodedUrl
  if resumable: self.VVASTF(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVuaY6or("Cannot resume from server !")
 def VVCWdL(self, decodedUrl):
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(http:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   x = decodedUrl.find("&mode")
   if x > -1: url = decodedUrl[:x]
   fName = ".mp4"
   x = decodedUrl.find("&end=")
   if x > -1: chName = decodedUrl[x+5:]
  if url and fName and chName:
   mix  = fName + chName
   fName =  mix.split(":")[0]
   chName = ":".join(mix.split(":")[1:])
   fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
   url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVuaY6or(self, txt):
  FF3wnI(self.SELF, txt, title=self.Title)
 def VVZtua(self):
  thrList = []
  for thr in iEnumerate():
   if self.VV9Oi3 in thr.name:
    thrList.append(thr.name.replace(self.VV9Oi3, ""))
  return thrList
 def VVUX39(self):
  decodedUrl = self.VVMB3d.VVQnoN()[9].strip()
  return decodedUrl in self.VVZtua()
 def VVb4GI(self):
  colList = self.VVMB3d.VVQnoN()
  path = colList[6].strip()
  size = colList[7].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFmOde(path)) == size
 def VVTYlx(self):
  colList = self.VVMB3d.VVQnoN()
  path = colList[6].strip()
  size = int(colList[7].strip())
  curSize = FFmOde(path)
  if curSize > -1:
   size -= curSize
  err = CCL4WW.VVhJJK(size)
  if err:
   FF3wnI(self.SELF, err, title=self.Title)
   return False
  return True
 def VV4epu(self, list):
  with open(CCL4WW.VVcEr0(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVTb00(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCL4WW.VVyXDY()
  url = decodedUrl
  with open(CCL4WW.VVcEr0(), "w") as f:
   for line in lines:
    if CCL4WW.VVEf4W(decodedUrl, line):
     parts = line.split(",")
     oldUrl = ",".join(parts[1:]).strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVZUjT()
  return url
 @staticmethod
 def VVyXDY():
  list = []
  if fileExists(CCL4WW.VVcEr0()):
   for line in FFK66c(CCL4WW.VVcEr0()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVEf4W(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVhJJK(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCN0r2.VVTwnf(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCN0r2.VVAajP(size), CCN0r2.VVAajP(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVQ894(SELF):
  tot = CCL4WW.VVGumv()
  if tot:
   FF3wnI(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVGumv():
  c = 0
  for thread in iEnumerate():
   if thread.name.startswith(CCL4WW.VV9Oi3):
    c += 1
  return c
 @staticmethod
 def VVTjd7():
  return len(CCL4WW.VVyXDY()) == 0
 @staticmethod
 def VVT7pQ():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVfLiz():
  mPoints = CCL4WW.VVT7pQ()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFUJYt("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVcEr0():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVp5QA(SELF):
  CCL4WW.VVFpYA(SELF, CCL4WW.VV0prE)
 @staticmethod
 def VVd21N_cur(SELF):
  CCL4WW.VVFpYA(SELF, CCL4WW.VVBnoc, startDnld=True)
 @staticmethod
 def VVd21N_url(SELF, url):
  CCL4WW.VVFpYA(SELF, CCL4WW.VVBnoc, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVLrnjCurrent(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(SELF)
  added, skipped = CCL4WW.VVLrnjList([decodedUrl])
  FFmoBc(SELF, "Added", 1000)
 @staticmethod
 def VVLrnjList(list):
  added = skipped = 0
  for line in CCL4WW.VVyXDY():
   for ndx, url in enumerate(list):
    if url and CCL4WW.VVEf4W(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCL4WW.VVcEr0(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVFpYA(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCZnqB.VVEsd4(SELF):
   return
  if mode == CCL4WW.VV0prE and CCL4WW.VVTjd7():
   FF3wnI(SELF, "Download list is empty !", title=title)
  else:
   inst = CCL4WW(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
class CCkjHt(Screen, CCQOiM):
 VVBIqe = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False, enableDownloadMenu=True):
  self.skin, self.skinParam = FFhdcK(VV1aAd, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCQOiM.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  self.SubtWin    = None
  FFFgql(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVQTPo())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVhHBt         ,
   "info"  : self.VVYbHQ        ,
   "epg"  : self.VVYbHQ        ,
   "menu"  : self.VV1mY4       ,
   "cancel" : self.cancel         ,
   "blue"  : self.VVGJ39        ,
   "green"  : self.VVJf4P    ,
   "yellow" : self.VVI3Tt   ,
   "left"  : boundFunction(self.VV8gOp, -1)   ,
   "right"  : boundFunction(self.VV8gOp,  1)   ,
   "play"  : self.VVlli1        ,
   "pause"  : self.VVlli1        ,
   "playPause" : self.VVlli1        ,
   "stop"  : self.VVlli1        ,
   "rewind" : self.VVSCgH        ,
   "forward" : self.VVt2Gm        ,
   "rewindDm" : self.VVSCgH        ,
   "forwardDm" : self.VVt2Gm        ,
   "last"  : self.VV5WLZ        ,
   "next"  : self.VVDEmz        ,
   "pageUp" : boundFunction(self.VV1R6h, True) ,
   "pageDown" : boundFunction(self.VV1R6h, False) ,
   "chanUp" : boundFunction(self.VV1R6h, True) ,
   "chanDown" : boundFunction(self.VV1R6h, False) ,
   "up"  : boundFunction(self.VV1R6h, True) ,
   "down"  : boundFunction(self.VV1R6h, False) ,
   "audio"  : boundFunction(self.VVQsZB, True) ,
   "subtitle" : boundFunction(self.VVQsZB, False) ,
   "0"   : boundFunction(self.VVpotc , 10)  ,
   "1"   : boundFunction(self.VVpotc , 1)  ,
   "2"   : boundFunction(self.VVpotc , 2)  ,
   "3"   : boundFunction(self.VVpotc , 3)  ,
   "4"   : boundFunction(self.VVpotc , 4)  ,
   "5"   : boundFunction(self.VVpotc , 5)  ,
   "6"   : boundFunction(self.VVpotc , 6)  ,
   "7"   : boundFunction(self.VVpotc , 7)  ,
   "8"   : boundFunction(self.VVpotc , 8)  ,
   "9"   : boundFunction(self.VVpotc , 9)
  }, -1)
  self.onShown.append(self.VV82q3)
  self.onClose.append(self.onExit)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FFb93v(self)
  if not CCkjHt.VVBIqe:
   CCkjHt.VVBIqe = self
  else:
   self.close()
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FF5IjG(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FF5IjG(self["myPlayRpt"], "rpt")
  self.VVZAP3()
  self.instance.move(ePoint(40, 40))
  self.VV8vOz(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVu5MB)
  except:
   self.timer.callback.append(self.VVu5MB)
  self.timer.start(250, False)
  self.VVu5MB("Checking ...")
  self.VVJU3h()
 def VVJf4P(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self)
  if "chCode" in iptvRef:
   if CCZnqB.VVEsd4(self):
    self.VVJU3h(True)
 def VVZAP3(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FFrlPO(self["myTitle"], color)
 def VV1mY4(self):
  if self.SubtWin:
   self.SubtWin.VVmbuI()
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self)
  VV64WM = []
  if self.isFromExternal:
   VV64WM.append(("IPTV Menu"     , "iptv"  ))
   VV64WM.append(VVB35E)
  if FF6XlH(iptvRef) and not "&end=" in decodedUrl and not FFqt04(decodedUrl):
   uType, uHost, uUser, uPass, uId, uChName = CCNFtw.VVH2YO(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VV64WM.append(("Catchup Programs"   , "catchup"  ))
    VV64WM.append(VVB35E)
  VV64WM.append(("Stop Current Service"    , "stop"  ))
  VV64WM.append(("Restart Current Service"   , "restart"  ))
  VV64WM.append(VVB35E)
  FFMgGKSeries = FFqt04(decodedUrl)
  if FFMgGKSeries:
   VV64WM.append(("File Size"     , "fileSize" ))
   VV64WM.append(VVB35E)
  if self.enableDownloadMenu:
   addSep = False
   if FF6XlH(iptvRef) and FFMgGKSeries:
    VV64WM.append(("Start Download"   , "dload_cur" ))
    VV64WM.append(("Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCL4WW.VVTjd7():
    VV64WM.append(("Download Manager"   , "dload_stat" ))
    addSep = True
   if addSep:
    VV64WM.append(VVB35E)
  addSep = False
  fPath, fDir, fName = CCN0r2.VVyaVF(self)
  if fPath:
   if not CCN0r2.VVWHpP:
    VV64WM.append((VVgcU9 + "Open path in File Manager" , "VV5lnw" ))
    addSep = True
   if fPath:
    VV64WM.append((VVgcU9 + 'Add to "My Movies" Bouquet' , "VViy6M" ))
    VV64WM.append((VVgcU9 + "Start Subtitle"    , "VVv1Yi"  ))
    addSep = True
   if addSep:
    VV64WM.append(VVB35E)
   VV64WM.append(("%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VV9tD1" ))
   VV64WM.append(VVB35E)
  if CFG.playerPos.getValue() : VV64WM.append(("Move Bar to Bottom"  , "botm"  ))
  else      : VV64WM.append(("Move Bar to Top"  , "top"   ))
  VV64WM.append(("Help"             , "help"  ))
  FFUdxd(self, self.VVzaK8, VV64WM=VV64WM, width=550, title="Options")
 def VVzaK8(self, item=None):
  if item:
   if item == "iptv"     : self.VV4T5T()
   elif item == "catchup"    : self.VVI3Tt()
   elif item == "stop"     : self.VVncMV(0)
   elif item == "restart"    : self.VVncMV(1)
   elif item == "fileSize"    : FFb4DW(self, boundFunction(CCc6Hf.VVlgR3, self), title="Checking Server")
   elif item == "dload_cur"   : CCL4WW.VVd21N_cur(self)
   elif item == "addToDload"   : CCL4WW.VVLrnjCurrent(self)
   elif item == "dload_stat"   : CCL4WW.VVp5QA(self)
   elif item == "VV5lnw" : self.VV5lnw()
   elif item == "VViy6M" : FFb4DW(self, self.VViy6M)
   elif item == "VVv1Yi"  : self.VVv1Yi(CCVhHd.VVTpx3)
   elif item == "VV9tD1"  : self.VV9tD1()
   elif item == "botm"     : self.VV8vOz(0)
   elif item == "top"     : self.VV8vOz(1)
   elif item == "help"     : FFkCkL(self, VVe57v + "_help_player", "Player Controller (Keys)")
 def onExit(self):
  self.timer.stop()
  CCkjHt.VVBIqe = None
  self.VVP4ZR()
 def VVTsb7(self):
  if CCkjHt.VVBIqe:
   self.session.open(CCkjHt, enableZapping= False, enableDownloadMenu=False)
  self.close()
 def VV5lnw(self):
  self.session.open(CCN0r2, gotoMovie=True)
  self.VVTsb7()
 def VV4T5T(self):
  self.session.open(CCNFtw)
  self.VVTsb7()
 def VVncMV(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.close()
   elif typ == 1:
    self.VVu5MB("Restarting Service ...")
    FFSYWA(boundFunction(self.VVDqbd, serv))
 def VVDqbd(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self)
  if "&end=" in decodedUrl: boundFunction(self.VVJU3h, True)
  else     : self.session.nav.playService(serv)
 def VViy6M(self):
  title = "Add Movie to Bouquet"
  bName = "My Movies"
  path  = VVgmxK + "userbouquet.my_local_movies.tv"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self)
  fPath, fDir, fName = CCN0r2.VVyaVF(self)
  if not fPath or not chName:
   FF3wnI(self, "Cannot read Path or Channel Name", title=title)
   return
  isNew = False
  if not fileExists(path):
   isNew = True
   with open(path, "w") as f:
    f.write("#NAME %s\n" % bName)
  catID, stID, chNum = "1638", "6", "6"
  refCode = CCNFtw.VVDd7X(catID, stID, chNum)
  if not isNew:
   fTxt = FFP7TV(path)
   chUrl_noRef = "%s:%s" % (fPath, chName)
   if chUrl_noRef in fTxt:
    FF3wnI(self, "Already added to bouquet:\n\n%s" % bName, title=title)
    return
   for ns in range(1, 65535 - 1):
    catID, stID, chNum = "1638", str(ns), "6"
    refCode = CCNFtw.VVDd7X(catID, stID, chNum)
    if not refCode in fTxt:
     break
   else:
    FF3wnI(self, "Cannot create a unique Reference Code", title=title)
    return
  if refCode and fPath and chName:
   chUrl = "%s%s:%s" % (refCode, fPath, chName)
   with open(path, "a") as f:
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
   piconOk = self.VV069K(refCode)
   FF5Fv9(os.path.basename(path))
   FFNMxM()
   FFi9RU(self, "Added to bouquet:\n\n%s" % bName, title=title + (" (with PIcon)" if piconOk else ""))
  else:
   FF3wnI(self, "Cannot create a unique Reference Code", title=title)
   return
 def VV9tD1(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCkjHt.VVeT0D(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVu5MB(txt, highlight=ok)
 def VVv1Yi(self, mode, useSubtFile=""):
  self.hide()
  self.SubtWin = self.session.instantiateDialog(CCVhHd, mode=mode, endCallback=self.VVwt9E)
  self.SubtWin.show()
  self.SubtWin.VVzrwN(useSubtFile)
 def VVwt9E(self, err):
  if err:
   if err == "noResume": self.VVP4ZR(False)
   else    : self.VVP4ZR(True)
   if   err == "noResume" : return
   if   err == "noErr"  : return
   elif err == "noAutoSrt" : CCVhHd.VV7RO9(self, self.VVlNre)
   else      : FFmoBc(self, err, 2000)
 def VVlNre(self, path):
  if path:
   self.VVv1Yi(CCVhHd.VVTpx3, useSubtFile=path)
 def VV069K(self, refCode):
  fPath, fDir, fName, picFile = CCc6Hf.VVVu1t(self)
  pPath = CC7Ld1.VVeUbw()
  if fileExists(pPath) and pathExists(picFile):
   pFile = refCode.replace(":", "_").strip("_") + ".png"
   dest = os.path.join(pPath, pFile)
   os.system(FFUJYt("cp -f '%s' '%s'" % (picFile, dest)))
   os.system(FFUJYt("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (dest, dest)))
   return True
  return False
 def VV8vOz(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VVhHBt(self):
  if self.isManualSeek:
   self.VVVpmu()
   self.VVSmXT(self.manualSeekPts)
  else:
   if self.shown:
    self.hide()
    self.VVv1Yi(CCVhHd.VVjClK)
   else:
    self.VVP4ZR()
 def VVP4ZR(self, showBar=True):
  if self.SubtWin:
   self.session.deleteDialog(self.SubtWin)
   self.SubtWin = None
  if showBar:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVVpmu()
  elif self.SubtWin : self.VVP4ZR()
  else    : self.close()
 def VVYbHQ(self):
  if self.SubtWin:
   self.SubtWin.VVpF9w("noErr")
  FFt65h(self, fncMode=CCc6Hf.VVaFX5)
 def VVlli1(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except Exception as e:
   pass
  self.VVu5MB("Toggling Play/Pause ...")
 def VVVpmu(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VV8gOp(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCkjHt.VVeT0D(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVsgFA()
   else:
    self.manualSeekSec += direc * self.VVsgFA()
    self.manualSeekSec = FFwMj8(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFQbFg(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFZEiA(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVpotc(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVQTPo())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVu5MB("Changed Seek Time to : %d%s" % (val, self.VVSM9Z()))
 def VVQTPo(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVSM9Z())
 def VVSM9Z(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVy4fb(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVsgFA(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVu5MB(self, stateTxt="", highlight=False):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFsLKB(self, addInfoObj=True)
  fr = res = ""
  if info:
   w = FFdS3Z(info, iServiceInformation.sVideoWidth) or -1
   h = FFdS3Z(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFdS3Z(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CCc6Hf.VVJ1iG(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCkjHt.VVeT0D(self)
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FFwMj8(percVal, 0, 100)
    width = int(FFQbFg(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not posTxt: self["myPlayPos"].setText("")
  if not remTxt: self["myPlayRem"].setText("")
  if not durTxt:
   if   prov : txt = prov
   elif posTxt : txt = ">>>>"
   else  : txt = "...."
   self["myPlayVal"].setText(txt)
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText("")
   FFrlPO(self["myPlayBarBG"], "#1100202a")
   self["myPlayBarF"].hide()
  else:
   FFrlPO(self["myPlayBarBG"], "#11000000")
   self["myPlayBarF"].show()
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VVyCi6() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   if highlight: FFaMdN(self["myPlayMsg"], "#0000ffff")
   else  : FFaMdN(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   self["myPlayMsg"].setText("-" if decodedUrl else FFfrDO(refCode, True))
   FFaMdN(self["myPlayMsg"], "#00ff8066")
  tot = CCL4WW.VVGumv()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVEzID()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VVSmXT(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VV5WLZ()
  state = self.VVz9Op()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFaMdN(self["myPlayMsg"], "#0000ff00")
  else     : FFaMdN(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 @staticmethod
 def VVeT0D(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFZEiA(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFZEiA(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFZEiA(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVEzID(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVGJ39(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVyCi6()
   if cList:
    VV64WM = []
    for pts, what in cList:
     txt = FFZEiA(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VV64WM.append((txt, pts))
    FFUdxd(self, self.VVjd2E, VV64WM=VV64WM, title="Cut List")
   else:
    self.VVu5MB("No Cut-List for this channel !")
 def VVjd2E(self, item=None):
  if item:
   self.VVSmXT(item)
 def VVyCi6(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVt2Gm(self) : self.VVCKj9(1)
 def VVSCgH(self) : self.VVCKj9(-1)
 def VVCKj9(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCkjHt.VVeT0D(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVsgFA() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVy4fb())
    self.VVu5MB(txt)
  except:
   self.VVu5MB("Cannot jump")
 def VVSmXT(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVu5MB("Changing Time ...")
 def VV5WLZ(self):
  self.VVncMV(1)
  self.VVu5MB("Replaying ...")
  self.VVVpmu()
 def VVDEmz(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCkjHt.VVeT0D(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVu5MB("Jumping to end ...")
  except:
   pass
 def VVz9Op(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VV1R6h(self, isUp):
  if self.enableZapping:
   self.VVu5MB("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVVpmu()
   if self.portalTableParam:
    FFSYWA(boundFunction(self.VVl8t8, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self)
    if "/timeshift/" in decodedUrl:
     self.VVu5MB("Cannot Zap Catcup TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVjOyC()
 def VVjOyC(self):
  self.lastPlayPos = 0
  self.VVZAP3()
  self.VVJU3h()
 def VVl8t8(self, isUp):
  CCNFtw_inatance, VVMB3d, mode = self.portalTableParam
  if isUp : VVMB3d.VV7sYU()
  else : VVMB3d.VVRVq9()
  colList = VVMB3d.VVQnoN()
  if mode == "localIptv":
   chName, chUrl = CCNFtw_inatance.VVm4i5(VVMB3d, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCNFtw_inatance.VVZkgj(VVMB3d, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCNFtw_inatance.VVIbHh(mode, VVMB3d, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCNFtw_inatance.VVuV0f(mode, VVMB3d, colList)
  else:
   self.VVu5MB("Cannot Zap")
   return
  FFtcar(self, chUrl, VVdsme=False)
  self.VVjOyC()
 def VVJU3h(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCkjHt.VVeT0D(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self)
   if not self.VVFU1o(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVu5MB("Refreshing Portal")
   FFSYWA(self.VVQCPZ)
  except:
   pass
 def VVQCPZ(self):
  self.restoreLastPlayPos = self.VVg09H()
 def VVI3Tt(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFsLKB(self)
  if not decodedUrl or FFqt04(decodedUrl):
   self.VVu5MB("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCNFtw.VVH2YO(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVu5MB("Reading Program List ...")
   ok_fnc = boundFunction(self.VV2GCd, refCode, chName, streamId, uHost, uUser, uPass)
   FFSYWA(boundFunction(CCNFtw.VVVSzA, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVu5MB("Cannot process this channel")
 def VV2GCd(self, refCode, chName, streamId, uHost, uUser, uPass, VVMB3d, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVMB3d.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVu5MB("Changing Program ...")
   FFSYWA(boundFunction(self.VVtx4g, chUrl))
  else:
   self.VVu5MB("Incorrect Timestamp !")
 def VVtx4g(self, chUrl):
   FFtcar(self, chUrl, VVdsme=False)
   self.lastPlayPos = 0
   self.VVZAP3()
 def VVQsZB(self, isAudio):
  try:
   VVMZAe = InfoBar.instance
   if VVMZAe:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVMZAe)
    else  : self.session.open(SubtitleSelection, VVMZAe)
  except:
   pass
class CCz9tz(Screen):
 def __init__(self, session, title="", VVLGGV="Continue?", VVZRHB=True, VVESi4=False):
  self.skin, self.skinParam = FFhdcK(VVyofO, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVLGGV = VVLGGV
  self.VVESi4 = VVESi4
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVZRHB : VV64WM = [no , yes]
  else   : VV64WM = [yes, no ]
  FFFgql(self, title, VV64WM=VV64WM, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVhHBt ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVLGGV)
  if self.VVESi4:
   self["myLabel"].instance.setHAlign(0)
  self.VV2vIq()
  FFH9Ay(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFUyOi(self["myMenu"])
  FFZHDY(self, self["myMenu"])
 def VVhHBt(self):
  item = FFZqNe(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VV2vIq(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCbIsi(Screen):
 def __init__(self, session, title="", VV64WM=None, width=1000, height=0, OKBtnFnc=None, VVZg0c=None, VVJA2t=None, VV78RH=None, VVY0ds=None, VVecAt=False, VVMYH9=False):
  if height == 0: height = 850
  self.skin, self.skinParam = FFhdcK(VVDXvw, width, height, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VV64WM   = VV64WM
  self.OKBtnFnc   = OKBtnFnc
  self.VVZg0c   = VVZg0c
  self.VVJA2t  = VVJA2t
  self.VV78RH  = VV78RH
  self.VVY0ds   = VVY0ds
  self.VVecAt  = VVecAt
  self.VVMYH9  = VVMYH9
  FFFgql(self, title, VV64WM=VV64WM)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVhHBt          ,
   "cancel" : self.cancel          ,
   "red"  : self.VV70jH         ,
   "green"  : self.VVpzIB         ,
   "yellow" : self.VVJJnf         ,
   "blue"  : self.VV98bb         ,
   "pageUp" : self.VVywRR       ,
   "chanUp" : self.VVywRR       ,
   "pageDown" : self.VVAAlv        ,
   "chanDown" : self.VVAAlv
  }, -1)
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FFH9Ay(self["myMenu"])
  FFq9fK(self)
  self.VVzL10(self["keyRed"]  , self.VVZg0c )
  self.VVzL10(self["keyGreen"] , self.VVJA2t )
  self.VVzL10(self["keyYellow"] , self.VV78RH )
  self.VVzL10(self["keyBlue"]  , self.VVY0ds )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FF1rm3(self)
 def VVzL10(self, btnObj, btnFnc):
  if btnFnc:
   FF9CgN(btnObj, btnFnc[0])
 def VVhHBt(self):
  item = FFZqNe(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVecAt: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VV70jH(self)  : self.VVJNUY(self.VVZg0c)
 def VVpzIB(self) : self.VVJNUY(self.VVJA2t)
 def VVJJnf(self) : self.VVJNUY(self.VV78RH)
 def VV98bb(self) : self.VVJNUY(self.VVY0ds)
 def VVJNUY(self, btnFnc):
  if btnFnc:
   item = FFZqNe(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVMYH9:
    self.cancel()
 def VVlcxr(self):
  ndx = self["myMenu"].getSelectedIndex()
  VV64WM = self["myMenu"].list
  VV64WM.pop(ndx)
  if len(VV64WM) > 0: self["myMenu"].setList(VV64WM)
  else    : self.close()
 def VVM8HY(self, VV64WM):
  if len(VV64WM) > 0:
   newList = []
   for item in VV64WM:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVL4YU(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVywRR(self):
  self["myMenu"].moveToIndex(0)
 def VVAAlv(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCOxzY(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VVATVO=None, VVnesb=None, VVeJNW=None, VV4RrQ=26, VVzmtH=False, VVyMeP=None, VV4SDx=None, VVFile=None, VVVDdh=None, VVHxLO=None, VVDrmo=None, VVScQs=None, VVz2py=None, VVUKxL=None, VV7PFT=-1, VVQvC9=False, searchCol=0, VVPUaR=None, VV1PI5=None, VVdHDz="#00dddddd", VVLubA="#11002233", VV7cLV="#00ff8833", VVrJH1="#11111111", VVndWP="#0a555555", VVnH0Y="#0affffff", VVleo7="#11552200", VVMEm9="#0055ff55"):
  self.skin, self.skinParam = FFhdcK(VV2ztI, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFFgql(self, title)
  self.header     = header
  self.VVATVO     = VVATVO
  self.totalCols    = len(VVATVO[0])
  self.VVPIq4   = 0
  self.lastSortModeIsReverese = False
  self.VVzmtH   = VVzmtH
  self.VVGUfe   = 0.01
  self.VVSn1j   = 0.02
  self.VV60iK = 0.03
  self.VV2Ze8  = 1
  self.VVeJNW = VVeJNW
  self.colWidthPixels   = []
  self.VVyMeP   = VVyMeP
  self.OKButtonObj   = None
  self.VV4SDx   = VV4SDx
  self.VVFile   = VVFile
  self.VVVDdh   = VVVDdh
  self.VVHxLO  = VVHxLO
  self.VVDrmo   = VVDrmo
  self.VVScQs    = VVScQs
  self.VVz2py   = VVz2py
  self.VVUKxL  = VVUKxL
  self.VV7PFT    = VV7PFT
  self.VVQvC9   = VVQvC9
  self.searchCol    = searchCol
  self.VVnesb    = VVnesb
  self.keyPressed    = -1
  self.VV4RrQ    = FFrcge(VV4RrQ)
  self.VVAa0V    = FFtdej(self.VV4RrQ, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVPUaR    = VVPUaR
  self.VV1PI5      = VV1PI5
  self.VVdHDz    = FF03Jc(VVdHDz)
  self.VVLubA    = FF03Jc(VVLubA)
  self.VV7cLV    = FF03Jc(VV7cLV)
  self.VVrJH1    = FF03Jc(VVrJH1)
  self.VVndWP   = FF03Jc(VVndWP)
  self.VVnH0Y    = FF03Jc(VVnH0Y)
  self.VVleo7    = FF03Jc(VVleo7)
  self.VVMEm9   = FF03Jc(VVMEm9)
  self.VVoduh  = False
  self.selectedItems   = 0
  self.VVNDSv   = FF03Jc("#01fefe01")
  self.VV8WiD   = FF03Jc("#11400040")
  self.VV1ifv  = self.VVNDSv
  self.VVyo0u  = self.VVrJH1
  if self.VVQvC9:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVahCU  ,
   "red"   : self.VV4NF7  ,
   "green"   : self.VV3Koz ,
   "yellow"  : self.VV7i3a ,
   "blue"   : self.VVzw6R  ,
   "menu"   : self.VVA2ua ,
   "info"   : self.VVFIwr  ,
   "cancel"  : self.VV5u9z  ,
   "up"   : self.VVRVq9    ,
   "down"   : self.VV7sYU  ,
   "left"   : self.VV1aDH   ,
   "right"   : self.VV821G  ,
   "pageUp"  : self.VVl8rt  ,
   "chanUp"  : self.VVl8rt  ,
   "pageDown"  : self.VV5H2s  ,
   "chanDown"  : self.VV5H2s
  }, -1)
  FFG8YJ(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FFb93v(self)
  try:
   self.VVzYGm()
  except Exception as err:
   FF3wnI(self, str(err))
   self.close(None)
 def VVzYGm(self):
  FF1rm3(self)
  if self.VVPUaR:
   FFrlPO(self["myTitle"], self.VVPUaR)
  if self.VV1PI5:
   FFrlPO(self["myBody"] , self.VV1PI5)
   FFrlPO(self["myTableH"] , self.VV1PI5)
   FFrlPO(self["myTable"] , self.VV1PI5)
   FFrlPO(self["myBar"]  , self.VV1PI5)
  self.VVzL10(self.VVFile  , self["keyRed"])
  self.VVzL10(self.VVVDdh  , self["keyGreen"])
  self.VVzL10(self.VVHxLO , self["keyYellow"])
  self.VVzL10(self.VVDrmo  , self["keyBlue"])
  if self.VVyMeP:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVyMeP[0])
    FFrlPO(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVAa0V)
  self["myTableH"].l.setFont(0, gFont(VVIbI9, self.VV4RrQ))
  self["myTable"].l.setItemHeight(self.VVAa0V)
  self["myTable"].l.setFont(0, gFont(VVIbI9, self.VV4RrQ))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVAa0V)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVAa0V))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVAa0V)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVAa0V
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVAa0V * len(self.VVATVO) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVeJNW:
   self.VVeJNW = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVeJNW)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVnesb:
   self.VVnesb = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVnesb
   self.VVnesb = []
   for item in tmpList:
    self.VVnesb.append(item | RT_VALIGN_CENTER)
  self.VV9WOY()
  if self.VVScQs:
   self.VVScQs(self)
 def VVzL10(self, btnFnc, btn):
  if btnFnc : FF9CgN(btn, btnFnc[0])
  else  : FF9CgN(btn, "")
 def VVHp7f(self, waitTxt):
  FFb4DW(self, self.VV9WOY, title=waitTxt)
 def VV9WOY(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VV4AT4(0, self.header, self.VVnH0Y, self.VVleo7, self.VVnH0Y, self.VVleo7, self.VVMEm9)])
   rows = []
   for c, row in enumerate(self.VVATVO):
    rows.append(self.VV4AT4(c, row, self.VVdHDz, self.VVLubA, self.VV7cLV, self.VVrJH1, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VV7PFT > -1:
    self["myTable"].moveToIndex(self.VV7PFT )
   self.VVijZq()
   if self.VVQvC9:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVAa0V * len(self.VVATVO)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVz2py:
    self.VVJNUY(self.VVz2py, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FF3wnI(self, str(err))
    self.close()
   except:
    pass
 def VV4AT4(self, keyIndex, columns, VVdHDz, VVLubA, VV7cLV, VVrJH1, VVMEm9):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVMEm9 and ndx == self.VVPIq4 : textColor = VVMEm9
   else           : textColor = VVdHDz
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FF03Jc(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVLubA = c
    entry = span.group(3)
   if self.VVnesb[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVAa0V)
           , font   = 0
           , flags   = self.VVnesb[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVLubA
           , color_sel  = VV7cLV
           , backcolor_sel = VVrJH1
           , border_width = 1
           , border_color = self.VVndWP
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVFIwr(self):
  rowData = self.VVTMyN()
  if rowData:
   title, txt, colList = rowData
   if self.VV4SDx:
    fnc  = self.VV4SDx[1]
    params = self.VV4SDx[2]
    fnc(self, title, txt, colList)
   else:
    FFR6iW(self, txt, title)
 def VVahCU(self):
  if   self.VVoduh : self.VVzbKI(self.VVdrH0(), mode=2)
  elif self.VVyMeP  : self.VVJNUY(self.VVyMeP, None)
  else      : self.VVFIwr()
 def VV4NF7(self) : self.VVJNUY(self.VVFile , self["keyRed"])
 def VV3Koz(self) : self.VVJNUY(self.VVVDdh , self["keyGreen"])
 def VV7i3a(self): self.VVJNUY(self.VVHxLO , self["keyYellow"])
 def VVzw6R(self) : self.VVJNUY(self.VVDrmo , self["keyBlue"])
 def VVJNUY(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFmoBc(self, buttonFnc[3])
    FFSYWA(boundFunction(self.VVUAcH, buttonFnc))
   else:
    self.VVUAcH(buttonFnc)
 def VVUAcH(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVTMyN()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVzbKI(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VVATVO[ndx]
   isSelected = row[1][9] == self.VVNDSv
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VV4AT4(ndx, item, self.VVdHDz, self.VVLubA, self.VV7cLV, self.VVrJH1, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VV4AT4(ndx, item, self.VVNDSv, self.VV8WiD, self.VV1ifv, self.VVyo0u, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVijZq()
 def VVb2VJ(self):
  FFb4DW(self, self.VVhuKV, title="Selecting all ...")
 def VVhuKV(self):
  self.VVMC9a(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVNDSv
   if not isSelected:
    item = self.VVATVO[ndx]
    newRow = self.VV4AT4(ndx, item, self.VVNDSv, self.VV8WiD, self.VV1ifv, self.VVyo0u, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVijZq()
  self.VVAwc2()
 def VVNdD3(self):
  FFb4DW(self, self.VV5UbM, title="Unselecting all ...")
 def VV5UbM(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVNDSv:
    item = self.VVATVO[ndx]
    newRow = self.VV4AT4(ndx, item, self.VVdHDz, self.VVLubA, self.VV7cLV, self.VVrJH1, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVijZq()
  self.VVAwc2()
 def VVAwc2(self):
  self.hide()
  self.show()
 def VVTMyN(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVeJNW[i] > 1 or self.VVeJNW[i] == self.VVGUfe or self.VVeJNW[i] == self.VV60iK:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VVATVO))
   return rowNum, txt, colList
  else:
   return None
 def VV5u9z(self):
  if self.VVUKxL : self.VVUKxL(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVIwKq(self):
  return self["myTitle"].getText().strip()
 def VVkr43(self):
  return self.header
 def VVsmoP(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVVdyU(self, txt):
  FFmoBc(self, txt)
 def VVettN(self, txt):
  FFmoBc(self, txt, 1000)
 def VVIZWg(self):
  FFmoBc(self)
 def VVgz0D(self):
  return len(self.VVATVO)
 def VVSa4L(self): self["keyGreen"].show()
 def VVrNVt(self): self["keyGreen"].hide()
 def VVdrH0(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVW3je(self):
  return len(self["myTable"].list)
 def VVMC9a(self, isOn):
  self.VVoduh = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu"].hide()
   if self.VVDrmo: self["keyBlue"].hide()
   if self.VVyMeP and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVDrmo: self["keyBlue"].show()
   if self.VVyMeP and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVyMeP[0])
   self.VVNdD3()
  FFrlPO(self["myTitle"], color)
  FFrlPO(self["myBar"]  , color)
 def VVrNsh(self):
  return self.VVoduh
 def VVZiZc(self):
  return self.selectedItems
 def VVC1AB(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVijZq()
 def VVBH29(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVijZq()
 def VVyNP8(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VVATVO:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVvSBD(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVgz0D()
  txt += FF82X1("Total Unique Items", VVValh)
  for i in range(self.totalCols):
   if self.VVeJNW[i - 1] > 1 or self.VVeJNW[i - 1] == self.VVGUfe or self.VVeJNW[i - 1] == self.VV60iK:
    name, tot = self.VVyNP8(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFR6iW(self, txt)
 def VVits3(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVQnoN(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVr5NB(self, newList, newTitle="", VVki5CMsg=True):
  if newList:
   self.VVATVO = newList
   if self.VVzmtH and self.VVPIq4 == 0:
    self.VVATVO = sorted(self.VVATVO, key=lambda x: int(x[self.VVPIq4])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VVATVO = sorted(self.VVATVO, key=lambda x: x[self.VVPIq4].lower(), reverse=self.lastSortModeIsReverese)
   if VVki5CMsg : self.VVHp7f("Refreshing ...")
   else   : self.VV9WOY()
   if newTitle:
    self.VVsmoP(newTitle)
  else:
   FF3wnI(self, "Cannot refresh list")
   self.cancel()
 def VVqFcn(self, data):
  ndx = self.VVdrH0()
  newRow = self.VV4AT4(ndx, data, self.VVdHDz, self.VVLubA, self.VV7cLV, self.VVrJH1, None)
  if newRow:
   self.VVATVO[ndx] = data
   self["myTable"].list[ndx] = newRow
   self.VVijZq()
   return True
  else:
   return False
 def VVV98r(self, colNum, textToFind, VVuaY6=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVijZq()
    break
  else:
   if VVuaY6:
    FFmoBc(self, "Not found", 1000)
 def VV8QRM(self, colDict, VVuaY6=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVijZq()
    return
  if VVuaY6:
   FFmoBc(self, "Not found", 1000)
 def VV8QRM_partial(self, colDict, VVuaY6=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVijZq()
    return
  if VVuaY6:
   FFmoBc(self, "Not found", 1000)
 def VVsBri(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VV8QuG(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVNDSv:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVlaxk(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VVNDSv: return True
  else        : return False
 def VVsLdG(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVA2ua(self):
  if not self["keyMenu"].getVisible() or self.VVQvC9:
   return
  VV64WM = []
  VV64WM.append(("Table Statistcis"             , "tableStat"  ))
  VV64WM.append(VVB35E)
  VV64WM.append((FFtsFe("Export Table to .html"     , VVValh) , "VVMHth" ))
  VV64WM.append((FFtsFe("Export Table to .csv"     , VVValh) , "VVpkyi" ))
  VV64WM.append((FFtsFe("Export Table to .txt (Tab Separated)", VVValh) , "VVxkkV" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVeJNW[i] > 1 or self.VVeJNW[i] == self.VVSn1j:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VV64WM.append(VVB35E)
   if tot == 1 : VV64WM.append(("Sort", sList[0][1]))
   else  : VV64WM += sList
  FFUdxd(self, self.VVHbjA, VV64WM=VV64WM, title=self.VVIwKq())
 def VVHbjA(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVvSBD()
   elif item == "VVMHth": FFb4DW(self, self.VVMHth, title=title)
   elif item == "VVpkyi" : FFb4DW(self, self.VVpkyi , title=title)
   elif item == "VVxkkV" : FFb4DW(self, self.VVxkkV , title=title)
   else:
    isReversed = False
    if self.VVPIq4 == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVzmtH and item == 0:
     self.VVATVO = sorted(self.VVATVO, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VVATVO = sorted(self.VVATVO, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVPIq4 = item
    self.VVHp7f("Sorting ...")
 def VVRVq9(self):
  self["myTable"].up()
  self.VVijZq()
 def VV7sYU(self):
  self["myTable"].down()
  self.VVijZq()
 def VV1aDH(self):
  self["myTable"].pageUp()
  self.VVijZq()
 def VV821G(self):
  self["myTable"].pageDown()
  self.VVijZq()
 def VVl8rt(self):
  self["myTable"].moveToIndex(0)
  self.VVijZq()
 def VV5H2s(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVijZq()
 def VVIAsB(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVijZq()
 def VVxkkV(self):
  expFile = self.VVTaCO() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVPKWH()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VVATVO:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVeJNW[ndx] > self.VV2Ze8 or self.VVeJNW[ndx] == self.VV60iK:
      col = self.VVNJBf(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVV8tA(expFile)
 def VVpkyi(self):
  expFile = self.VVTaCO() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVPKWH()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VVATVO:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVeJNW[ndx] > self.VV2Ze8 or self.VVeJNW[ndx] == self.VV60iK:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVNJBf(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVV8tA(expFile)
 def VVMHth(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVIwKq(), PLUGIN_NAME, VVdDje)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVIwKq()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVPKWH()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVeJNW:
   colgroup += '   <colgroup>'
   for w in self.VVeJNW:
    if w > self.VV2Ze8 or w == self.VV60iK:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVTaCO() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VVATVO:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVeJNW[ndx] > self.VV2Ze8 or self.VVeJNW[ndx] == self.VV60iK:
      col = self.VVNJBf(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVV8tA(expFile)
 def VVPKWH(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVeJNW[ndx] > self.VV2Ze8 or self.VVeJNW[ndx] == self.VV60iK:
     newRow.append(col.strip())
  return newRow
 def VVNJBf(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFWesU(col)
 def VVTaCO(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVIwKq())
  fileName = fileName.replace("__", "_")
  path  = FFMXkM(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFpkvp()
  return expFile
 def VVV8tA(self, expFile):
  FFi9RU(self, "File exported to:\n\n%s" % expFile, title=self.VVIwKq())
 def VVijZq(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCcSGB(Screen):
 def __init__(self, session, title="", VVXmFj=None, showGrnMsg=""):
  self.skin, self.skinParam = FFhdcK(VVOhNa, 1400, 800, 30, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FFFgql(self, title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VVXmFj = VVXmFj
  self.showGrnMsg  = showGrnMsg
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  allOK = FFHLbC(self["myLabel"], self.VVXmFj)
  if allOK:
   if self.showGrnMsg:
    FFmoBc(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FF3wnI(self, "Cannot view picture file:\n\n%s" % self.VVXmFj)
   self.close()
class CCs4Ff(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFhdcK(VVxZpK, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFFgql(self, title=self.Title)
  FF9CgN(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Signal & Player Cotroller Hotkey"       , CFG.hotkey_signal    ))
  if VVsWxe:
   lst.append(getConfigListEntry("EPG Translation Language"        , CFG.epgLanguage    ))
  if VVrM79:
   lst.append(getConfigListEntry("Force UTF-8 Encoding (only OpenVision Python-3.10.2+)" , CFG.forceUtf8Encoding   ))
  lst.append(getConfigListEntry(VVFkPZ *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type"         , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsPath    ))
  lst.append(getConfigListEntry("Movie/Series Download Path"         , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VVFkPZ *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VVFkPZ *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons"            , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVyk6M()
  self.onShown.append(self.VV82q3)
 def VVyk6M(self):
  kList = {
    "ok"  : self.VVhHBt    ,
    "green"  : self.VVxk8v   ,
    "menu"  : self.VVqp3p  ,
    "cancel" : self.VVX6tp  ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"]  = boundFunction(self["config"].handleKey, kLeft)
   kList["right"]  = boundFunction(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = boundFunction(self["config"].VVNQRK, 0)
     kList["chanDown"] = boundFunction(self["config"].VVNQRK, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FFb93v(self)
  FFH9Ay(self["config"])
  FFq9fK(self, self["config"])
  FF1rm3(self)
 def VVhHBt(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsPath   : self.VVwQXY()
   elif item == CFG.MovieDownloadPath   : self.VVXsac(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VV4Hvp(item)
   elif item == CFG.backupPath    : self.VV4Hvp(item)
   elif item == CFG.packageOutputPath  : self.VV4Hvp(item)
   elif item == CFG.downloadedPackagesPath : self.VV4Hvp(item)
   elif item == CFG.exportedTablesPath  : self.VV4Hvp(item)
   elif item == CFG.exportedPIconsPath  : self.VV4Hvp(item)
 def VVXsac(self, item, title):
  tot = CCL4WW.VVGumv()
  if tot : FF3wnI(self, "Cannot change while downloading.", title=title)
  else : self.VV4Hvp(item)
 def VVwQXY(self):
  VV64WM = []
  VV64WM.append(("Auto Find" , "auto"))
  VV64WM.append(("Custom Path" , "path"))
  FFUdxd(self, self.VViITE, VV64WM=VV64WM, title="IPTV Hosts Files Path")
 def VViITE(self, item=None):
  if item:
   if   item == "auto": CFG.iptvHostsPath.setValue(VVRRQu)
   elif item == "path": self.VV4Hvp(CFG.iptvHostsPath)
 def VV4Hvp(self, configObj):
  sDir = configObj.getValue()
  if sDir == VVRRQu:
   sDir = "/"
  self.session.openWithCallback(boundFunction(self.VVZibt, configObj)
         , boundFunction(CCN0r2, mode=CCN0r2.VVBjC9, VV8UhH=sDir))
 def VVZibt(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVX6tp(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFysO2(self, self.VVxk8v, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVxk8v(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVKLHz()
  self.VVjza5()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVjza5(self):
  CCAv2L.VVHLM5()
 def VVqp3p(self):
  VV64WM = []
  VV64WM.append(("Use Backup directory in all other paths"      , "VVseZO"   ))
  VV64WM.append(("Reset all to default (including File Manager bookmarks)"  , "VVqlyY"   ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Backup %s Settings" % PLUGIN_NAME        , "VVahvx"  ))
  VV64WM.append(("Restore %s Settings" % PLUGIN_NAME       , "VVVcHO"  ))
  if fileExists(VVe6OI + VVdGEY):
   VV64WM.append(VVB35E)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VV64WM.append(('%s Checking for Update' % txt1       , txt2     ))
   VV64WM.append(("Reinstall %s" % PLUGIN_NAME        , "VVqmVg"  ))
   VV64WM.append(("Update %s" % PLUGIN_NAME        , "VVpJs9"   ))
  FFUdxd(self, self.VVz17z, VV64WM=VV64WM, title="Config. Options")
 def VVz17z(self, item=None):
  if item:
   if   item == "VVseZO"  : FFysO2(self, self.VVseZO , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVqlyY"  : FFysO2(self, self.VVqlyY, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCpI1P)
   elif item == "VVahvx" : self.VVahvx()
   elif item == "VVVcHO" : FFb4DW(self, self.VVVcHO, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVqrpq(True)
   elif item == "disableChkUpdate" : self.VVqrpq(False)
   elif item == "VVqmVg" : FFb4DW(self, self.VVqmVg , "Checking Server ...")
   elif item == "VVpJs9"  : FFb4DW(self, self.VVpJs9  , "Checking Server ...")
 def VVahvx(self):
  path = "%sajpanel_settings_%s" % (VVe6OI, FFpkvp())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFi9RU(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVVcHO(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFo68R("find / %s -iname '%s*' | grep %s" % (FFN326(1), name, name))
  if lines:
   lines.sort()
   VV64WM = []
   for line in lines:
    VV64WM.append((line, line))
   FFUdxd(self, boundFunction(self.VVeTIa, title), title=title, VV64WM=VV64WM, width=1200)
  else:
   FF3wnI(self, "No settings files found !", title=title)
 def VVeTIa(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFK66c(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVKLHz()
    FFfN32()
   else:
    FFTvTY(SELF, path, title=title)
 def VVqrpq(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVseZO(self):
  newPath = FFMXkM(VVe6OI)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVKLHz()
 @staticmethod
 def VVLcn8():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVqlyY(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.EventsInfoMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.epgLanguage.setValue("off")
  CFG.forceUtf8Encoding.setValue(True)
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.autoResetFrozenIptvChan.setValue(True)
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.iptvHostsPath.setValue(VVRRQu)
  CFG.MovieDownloadPath.setValue(CCL4WW.VVfLiz())
  CFG.PIconsPath.setValue(VVk5g8)
  CFG.backupPath.setValue(CCs4Ff.VVLcn8())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVKLHz()
  self.close()
 def VVKLHz(self):
  configfile.save()
  global VVe6OI
  VVe6OI = CFG.backupPath.getValue()
  FFKjVi()
 def VVpJs9(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVRP1w(title)
  if webVer:
   FFysO2(self, boundFunction(FFb4DW, self, boundFunction(self.VVkgUs, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVqmVg(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVRP1w(title, True)
  if webVer:
   FFysO2(self, boundFunction(FFb4DW, self, boundFunction(self.VVkgUs, webVer, title, True)), "Install and Restart ?", title=title)
 def VVkgUs(self, webVer, title, isReinst=False):
  url = self.VVEVdZ(self, title)
  if url:
   VVPOOn = FF4LBH() == "dpkg"
   if VVPOOn == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVPOOn else "ipk")
   path, err = FFd8ee(url + fName, fName, timeout=2)
   if path:
    if isReinst : cmd = FFU7ig(VVIxA6, path)
    else  : cmd = FFU7ig(VVeAw5, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFSA5Q(self, cmd)
    else:
     FFdiGu(self, title=title)
   else:
    FF3wnI(self, err, title=title)
 def VVRP1w(self, title, anyVer=False):
  url = self.VVEVdZ(self, title)
  if not url:
   return ""
  path, err = FFd8ee(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FF3wnI(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFP7TV(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FF3wnI(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVdDje.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFo68R(cmd)
   if list and curVer == list[0]:
    return webVer
  FFi9RU(self, FFtsFe("No update required.", VVAexn) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVEVdZ(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVe6OI + VVdGEY
  if fileExists(path):
   span = iSearch(r"(http.+)", FFP7TV(path), IGNORECASE)
   if span : url = FFMXkM(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FF3wnI(SELF, err, title)
  return url
 @staticmethod
 def VVkW7Y(url):
  path, err = FFd8ee(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFP7TV(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVdDje.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFo68R(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCpI1P(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFhdcK(VVpRAs, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVcrwi
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFFgql(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVK4sO("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVK4sO("\c00888888", i) + sp + "GREY\n"
   txt += self.VVK4sO("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVK4sO("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVK4sO("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVK4sO("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVK4sO("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVK4sO("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVK4sO("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVK4sO("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVK4sO("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVK4sO("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVhHBt ,
   "green"   : self.VVhHBt ,
   "left"   : self.VVrCAA ,
   "right"   : self.VVxaGR ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  self.VVEerL()
 def VVhHBt(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFysO2(self, self.VV9GfC, "Change to : %s" % txt, title=self.Title)
 def VV9GfC(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVcrwi
  VVcrwi = self.cursorPos
  self.VVfopa()
  self.close()
 def VVrCAA(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVEerL()
 def VVxaGR(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVEerL()
 def VVEerL(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVK4sO(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVkC9W(color):
  if VVgcU9: return "\\" + color
  else    : return ""
 @staticmethod
 def VVfopa():
  global VVM75e, VVBPJz, VVe3tS, VVValh, VVcBCb, VVKDsv, VVAexn, VVgcU9, COLOR_CONS_BRIGHT_YELLOW, VVzqsa, VVwcoZ, VVeyOS, VVXaUF
  VVXaUF   = CCpI1P.VVK4sO("\c00FFFFFF", VVcrwi)
  VVBPJz    = CCpI1P.VVK4sO("\c00888888", VVcrwi)
  VVM75e  = CCpI1P.VVK4sO("\c005A5A5A", VVcrwi)
  VVKDsv    = CCpI1P.VVK4sO("\c00FF0000", VVcrwi)
  VVe3tS   = CCpI1P.VVK4sO("\c00FF5000", VVcrwi)
  VVgcU9   = CCpI1P.VVK4sO("\c00FFFF00", VVcrwi)
  COLOR_CONS_BRIGHT_YELLOW = CCpI1P.VVK4sO("\c00FFFFAA", VVcrwi)
  VVAexn   = CCpI1P.VVK4sO("\c0000FF00", VVcrwi)
  VVcBCb    = CCpI1P.VVK4sO("\c000066FF", VVcrwi)
  VVzqsa    = CCpI1P.VVK4sO("\c0000FFFF", VVcrwi)
  VVwcoZ  = CCpI1P.VVK4sO("\c00DSFFFF", VVcrwi)  #
  VVeyOS   = CCpI1P.VVK4sO("\c00FA55E7", VVcrwi)
  VVValh    = CCpI1P.VVK4sO("\c00FF8F5F", VVcrwi)
CCpI1P.VVfopa()
class CC78zY(Screen):
 def __init__(self, session, path, VVPOOn):
  self.skin, self.skinParam = FFhdcK(VV9U6R, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVqfL2   = path
  self.VVEUtc   = ""
  self.VVbnMI   = ""
  self.VVPOOn    = VVPOOn
  self.VVzqwX    = ""
  self.VVDj5b  = ""
  self.VVu7bw    = False
  self.VV0j8Y  = False
  self.postInstAcion   = 0
  self.VVLlrp  = "enigma2-plugin-extensions"
  self.VVv52V  = "enigma2-plugin-systemplugins"
  self.VVNQgB = "enigma2"
  self.VVYvmt  = 0
  self.VVVnbD  = 1
  self.VVa00U  = 2
  if pathExists(self.Path + "DEBIAN") : self.VV5lKD = "DEBIAN"
  else        : self.VV5lKD = "CONTROL"
  self.controlPath = self.Path + self.VV5lKD
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVPOOn:
   self.packageExt  = ".deb"
   self.VVLubA  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVLubA  = "#11001020"
  FFFgql(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FF9CgN(self["keyRed"] , "Create")
  FF9CgN(self["keyGreen"] , "Post Install")
  FF9CgN(self["keyYellow"], "Installation Path")
  FF9CgN(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVUVJP  ,
   "green"   : self.VV4UIo ,
   "yellow"  : self.VVHvU0  ,
   "blue"   : self.VVpEqx  ,
   "cancel"  : self.VVE1AF
  }, -1)
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FF1rm3(self)
  if self.VVLubA:
   FFrlPO(self["myBody"], self.VVLubA)
   FFrlPO(self["myLabel"], self.VVLubA)
  self.VVxMWC(True)
  self.VVaXZO(True)
 def VVaXZO(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVkrAW()
  if isFirstTime:
   if   package.startswith(self.VVLlrp) : self.VVqfL2 = VVkxqr + self.VVzqwX + "/"
   elif package.startswith(self.VVv52V) : self.VVqfL2 = VVngBg + self.VVzqwX + "/"
   else            : self.VVqfL2 = self.Path
  if self.VVu7bw : myColor = VVValh
  else    : myColor = VVXaUF
  txt  = ""
  txt += "Source Path\t: %s\n" % FFtsFe(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFtsFe(self.VVqfL2, VVgcU9)
  if self.VVbnMI : txt += "Package File\t: %s\n" % FFtsFe(self.VVbnMI, VVBPJz)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFtsFe("Check Control File fields : %s" % errTxt, VVe3tS)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFtsFe("Restart GUI", VVValh)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFtsFe("Reboot Device", VVValh)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFtsFe("Post Install", VVAexn), act)
  if not errTxt and VVe3tS in controlInfo:
   txt += "Warning\t: %s\n" % FFtsFe("Errors in control file may affect the result package.", VVe3tS)
  txt += "\nControl File\t: %s\n" % FFtsFe(self.controlFile, VVBPJz)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VV4UIo(self):
  VV64WM = []
  VV64WM.append(("No Action"    , "noAction"  ))
  VV64WM.append(("Restart GUI"    , "VVVlNn"  ))
  VV64WM.append(("Reboot Device"   , "rebootDev"  ))
  FFUdxd(self, self.VV8Iqd, title="Package Installation Option (after completing installation)", VV64WM=VV64WM)
 def VV8Iqd(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVVlNn"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVxMWC(False)
   self.VVaXZO()
 def VVHvU0(self):
  rootPath = FFtsFe("/%s/" % self.VVzqwX, VVM75e)
  VV64WM = []
  VV64WM.append(("Current Path"        , "toCurrent"  ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Extension Path"       , "toExtensions" ))
  VV64WM.append(("System Plugins Path"      , "toSystemPlugins" ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VV64WM.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFUdxd(self, self.VVcGd6, title="Installation Path", VV64WM=VV64WM)
 def VVcGd6(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVwxoe(FFADc6(self.Path, True))
   elif item == "toExtensions"  : self.VVwxoe(VVkxqr)
   elif item == "toSystemPlugins" : self.VVwxoe(VVngBg)
   elif item == "toRootPath"  : self.VVwxoe("/")
   elif item == "toRoot"   : self.VVwxoe("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVOpB9, boundFunction(CCN0r2, mode=CCN0r2.VVBjC9, VV8UhH=VVe6OI))
 def VVOpB9(self, path):
  if len(path) > 0:
   self.VVwxoe(path)
 def VVwxoe(self, parent, withPackageName=True):
  if withPackageName : self.VVqfL2 = parent + self.VVzqwX + "/"
  else    : self.VVqfL2 = "/"
  mode = self.VVsPPB()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVQFn2(mode), self.controlFile))
  self.VVaXZO()
 def VVpEqx(self):
  if fileExists(self.controlFile):
   lines = FFK66c(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFaNVN(self, self.VVxdLd, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FF3wnI(self, "Version not found or incorrectly set !")
  else:
   FFTvTY(self, self.controlFile)
 def VVxdLd(self, VVtkVj):
  if VVtkVj:
   version, color = self.VVetHj(VVtkVj, False)
   if color == VVzqsa:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVtkVj, self.controlFile))
    self.VVaXZO()
   else:
    FF3wnI(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVE1AF(self):
  if self.newControlPath:
   if self.VVu7bw:
    self.VVnqFX()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFtsFe(self.newControlPath, VVBPJz)
    txt += FFtsFe("Do you want to keep these files ?", VVgcU9)
    FFysO2(self, self.close, txt, callBack_No=self.VVnqFX, title="Create Package", VVESi4=True)
  else:
   self.close()
 def VVnqFX(self):
  os.system(FFUJYt("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVQFn2(self, mode):
  if   mode == self.VVVnbD : prefix = self.VVLlrp
  elif mode == self.VVa00U : prefix = self.VVv52V
  else        : prefix = self.VVNQgB
  return prefix + "-" + self.VVDj5b
 def VVsPPB(self):
  if   self.VVqfL2.startswith(VVkxqr) : return self.VVVnbD
  elif self.VVqfL2.startswith(VVngBg) : return self.VVa00U
  else            : return self.VVYvmt
 def VVxMWC(self, isFirstTime):
  self.VVzqwX   = os.path.basename(os.path.normpath(self.Path))
  self.VVzqwX   = "_".join(self.VVzqwX.split())
  self.VVDj5b = self.VVzqwX.lower()
  self.VVu7bw = self.VVDj5b == VV4zs3.lower()
  if self.VVu7bw and self.VVDj5b.endswith("ajpan"):
   self.VVDj5b += "el"
  if self.VVu7bw : self.VVEUtc = VVe6OI
  else    : self.VVEUtc = CFG.packageOutputPath.getValue()
  self.VVEUtc = FFMXkM(self.VVEUtc)
  if not pathExists(self.controlPath):
   os.system(FFUJYt("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVu7bw : t = PLUGIN_NAME
  else    : t = self.VVzqwX
  self.VVer97(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVopWG.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVu7bw : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVer97(self.postrmFile, txt)
  if self.VVu7bw:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVdDje)
   self.VVer97(self.preinstFile, txt)
  else:
   self.VVer97(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVzqwX)
  mode = self.VVsPPB()
  if isFirstTime and not mode == self.VVYvmt:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVFkPZ
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVer97(self.postinstFile, txt, VVSe1N=True)
  os.system(FFUJYt("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVu7bw : version, descripton, maintainer = VVdDje , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVzqwX , self.VVzqwX
   txt = ""
   txt += "Package: %s\n"  % self.VVQFn2(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVer97(self, path, lines, VVSe1N=False):
  if not fileExists(path) or VVSe1N:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVkrAW(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFK66c(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFtsFe(line, VVe3tS)
     elif not line.startswith(" ")    : line = FFtsFe(line, VVe3tS)
     else          : line = FFtsFe(line, VVzqsa)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVzqsa
   else   : color = VVe3tS
   descr = FFtsFe(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVe3tS
     elif line.startswith((" ", "\t")) : color = VVe3tS
     elif line.startswith("#")   : color = VVBPJz
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVetHj(val, True)
      elif key == "Version"  : version, color = self.VVetHj(val, False)
      elif key == "Maintainer" : maint  , color = val, VVzqsa
      elif key == "Architecture" : arch  , color = val, VVzqsa
      else:
       color = VVzqsa
      if not key == "OE" and not key.istitle():
       color = VVe3tS
     else:
      color = VVValh
     txt += FFtsFe(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVbnMI = self.VVEUtc + packageName
   self.VV0j8Y = True
   errTxt = ""
  else:
   self.VVbnMI  = ""
   self.VV0j8Y = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVetHj(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVzqsa
  else          : return val, VVe3tS
 def VVUVJP(self):
  if not self.VV0j8Y:
   FF3wnI(self, "Please fix Control File errors first.")
   return
  if self.VVPOOn: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFADc6(self.VVqfL2, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVzqwX
  symlinkTo  = FFhTBt(self.Path)
  dataDir   = self.VVqfL2.rstrip("/")
  removePorjDir = FFUJYt("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFUJYt("rm -f '%s'" % self.VVbnMI) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FF0OmY()
  if self.VVPOOn:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FF13Wm("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVu7bw:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVqfL2 == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VV5lKD)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVbnMI, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVbnMI
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVbnMI, FF8OuG(result  , VVAexn))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVqfL2, FF8OuG(instPath, VVzqsa))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FF8OuG(failed, VVe3tS))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFSA5Q(self, cmd)
class CCN0r2(Screen):
 VVxqD9   = 0
 VVBjC9  = 1
 VV7B4K = 20
 VVWHpP  = None
 def __init__(self, session, VV8UhH="/", mode=VVxqD9, VVHn5t="Select", VV4RrQ=30, gotoMovie=False):
  self.skin, self.skinParam = FFhdcK(VVDXvw, 1400, 920, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFFgql(self)
  FF9CgN(self["keyRed"] , "Exit")
  FF9CgN(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVHn5t = VVHn5t
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  CCN0r2.VVWHpP = self
  if   self.gotoMovie        : VVcVAc, self.VV8UhH = True , CCN0r2.VVyaVF(self)[1] or "/"
  elif self.mode == self.VVxqD9  : VVcVAc, self.VV8UhH = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVBjC9 : VVcVAc, self.VV8UhH = False, VV8UhH
  else           : VVcVAc, self.VV8UhH = True , VV8UhH
  self.VV8UhH = FFMXkM(self.VV8UhH)
  self["myMenu"] = CCtyMq(  directory   = "/"
         , VVcVAc   = VVcVAc
         , VVVXyA = True
         , VVkyKm   = self.skinParam["width"]
         , VV4RrQ   = self.skinParam["bodyFontSize"]
         , VVAa0V  = self.skinParam["bodyLineH"]
         , VV0Jgs  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVhHBt      ,
   "red"    : self.VVAKeQ     ,
   "green"    : self.VV8lIC    ,
   "yellow"   : self.VVtTJz   ,
   "blue"    : self.VVfrqD   ,
   "menu"    : self.VVJyJY    ,
   "info"    : self.VV3ja1    ,
   "cancel"   : self.VVLgvx     ,
   "pageUp"   : self.VVLgvx     ,
   "chanUp"   : self.VVLgvx
  }, -1)
  FFG8YJ(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVrNO5)
 def onExit(self):
  CCN0r2.VVWHpP = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVrNO5)
  FFb93v(self)
  FFH9Ay(self["myMenu"], bg="#06003333")
  FF1rm3(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode == self.VVBjC9:
   FF9CgN(self["keyGreen"], self.VVHn5t)
   color = "#22000022"
   FFrlPO(self["myBody"], color)
   FFrlPO(self["myMenu"], color)
   color = "#22220000"
   FFrlPO(self["myTitle"], color)
   FFrlPO(self["myBar"], color)
  self.VVrNO5()
  if self.VVrv0A(self.VV8UhH) > self.bigDirSize:
   FFmoBc(self, "Changing directory...")
   FFSYWA(self.VVQgXK)
  else:
   self.VVQgXK()
 def VVQgXK(self):
  self["myMenu"].VVm3lk(self.VV8UhH)
  if self.gotoMovie:
   self.VVMdhg(chDir=False)
 def VVIAsB(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVt1UZ(self):
  self["myMenu"].refresh()
  FFgSiE()
 def VVrv0A(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VVhHBt(self):
  if self["myMenu"].VVuKUH():
   path = self.VVs5qQ(self.VVd1c8())
   if self.VVrv0A(path) > self.bigDirSize:
    FFmoBc(self, "Changing directory...")
    FFSYWA(self.VViSsw)
   else:
    self.VViSsw()
  else:
   self.VVZJfr()
 def VViSsw(self):
  self["myMenu"].descent()
  self.VVrNO5()
 def VVLgvx(self):
  if self["myMenu"].VVT2hn():
   self["myMenu"].moveToIndex(0)
   self.VViSsw()
 def VVAKeQ(self):
  if not FFytTf(self):
   self.close("")
 def VV8lIC(self):
  if self.mode == self.VVBjC9:
   path = self.VVs5qQ(self.VVd1c8())
   self.close(path)
 def VV3ja1(self):
  FFb4DW(self, self.VVzm9Y, title="Calculating size ...")
 def VVzm9Y(self):
  path = self.VVs5qQ(self.VVd1c8())
  param = self.VVW2mW(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFhOpk("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCN0r2.VVXBdy(path)
     freeSize = CCN0r2.VVTwnf(path)
     size = totSize - freeSize
     totSize  = CCN0r2.VVAajP(totSize)
     freeSize = CCN0r2.VVAajP(freeSize)
    else:
     size = FFhOpk("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CCN0r2.VVAajP(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFtsFe(pathTxt, VVValh) + "\n"
   if slBroken : fileTime = self.VVPQa9(path)
   else  : fileTime = self.VVCNG3(path)
   def VVLucE(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVLucE("Path"    , pathTxt)
   txt += VVLucE("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVLucE("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVLucE("Total Size"   , "%s" % totSize)
    txt += VVLucE("Used Size"   , "%s" % usedSize)
    txt += VVLucE("Free Size"   , "%s" % freeSize)
   else:
    txt += VVLucE("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVLucE("Owner"    , owner)
   txt += VVLucE("Group"    , group)
   txt += VVLucE("Perm. (User)"  , permUser)
   txt += VVLucE("Perm. (Group)"  , permGroup)
   txt += VVLucE("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVLucE("Perm. (Ext.)" , permExtra)
   txt += VVLucE("iNode"    , iNode)
   txt += VVLucE("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVFkPZ, VVFkPZ)
    txt += hLinkedFiles
   txt += self.VVk3l3(path)
  else:
   FF3wnI(self, "Cannot access information !")
  if len(txt) > 0:
   FFR6iW(self, txt)
 def VVW2mW(self, path):
  path = path.strip()
  path = FFhTBt(path)
  result = FFhOpk("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVqzu9(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVqzu9(perm, 1, 4)
   permGroup = VVqzu9(perm, 4, 7)
   permOther = VVqzu9(perm, 7, 10)
   permExtra = VVqzu9(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFlAoD("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVk3l3(self, path):
  txt  = ""
  res  = FFhOpk("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFtsFe("File Attributes:", VVeyOS), txt)
  return txt
 def VVCNG3(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFlXfZ(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFlXfZ(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFlXfZ(os.path.getctime(path))
  return txt
 def VVPQa9(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFhOpk("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFhOpk("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFhOpk("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVs5qQ(self, currentSel):
  currentDir  = self["myMenu"].VVT2hn()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVuKUH():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVd1c8(self):
  return self["myMenu"].getSelection()[0]
 def VVrNO5(self):
  FFmoBc(self)
  path = self.VVs5qQ(self.VVd1c8())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VVATVO = self.VVcrcf()
  if VVATVO and len(VVATVO) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VVbT3Z(path)
  if self.mode == self.VVxqD9 and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
 def VVbT3Z(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVhIlr(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVJyJY(self):
  if self.mode == self.VVxqD9:
   path  = self.VVs5qQ(self.VVd1c8())
   isDir  = os.path.isdir(path)
   VV64WM = []
   VV64WM.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VV038n(path):
     sepShown = True
     VV64WM.append(VVB35E)
     VV64WM.append( (VVValh + "Archiving / Packaging"      , "VV5Pvp"  ))
    if self.VVn3Y2(path):
     if not sepShown:
      VV64WM.append(VVB35E)
     VV64WM.append( (VVValh + "Read Backup information"     , "VVx2G6"  ))
     VV64WM.append( (VVValh + "Compress Octagon Image (to zip File)"  , "VVpPO8" ))
   elif os.path.isfile(path):
    selFile = self.VVd1c8()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar")) : VV64WM.extend(self.VVyURa(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VV64WM.extend(self.VVqvBU(True))
    elif selFile.endswith(".m3u")              : VV64WM.extend(self.VVsavL(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FFCbgi(path):
     VV64WM.append(VVB35E)
     VV64WM.append((VVValh + "View"     , "textView_def" ))
     VV64WM.append((VVValh + "View (Select Encoder)" , "textView_enc" ))
     VV64WM.append((VVValh + "Edit"     , "text_Edit"  ))
    if len(txt) > 0:
     VV64WM.append(VVB35E)
     VV64WM.append(   (VVValh + txt      , "VVZJfr"  ))
   VV64WM.append(VVB35E)
   VV64WM.append(     ("Create SymLink"       , "VV1L9A" ))
   if not self.VV038n(path):
    VV64WM.append(   ("Rename"          , "VV0eeU" ))
    VV64WM.append(   ("Copy"           , "copyFileOrDir" ))
    VV64WM.append(   ("Move"           , "moveFileOrDir" ))
    VV64WM.append(   ("DELETE"          , "VVSxHG" ))
    if fileExists(path):
     VV64WM.append(VVB35E)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VV64WM.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VV64WM.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VV64WM.append( (chmodTxt + "777)"       , "chmod777"  ))
   VV64WM.append(VVB35E)
   VV64WM.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VV64WM.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCN0r2.VVyaVF(self)
   if fPath:
    VV64WM.append(VVB35E)
    VV64WM.append(   (VVgcU9 + "Go to current movie"  , "VVMdhg"))
   VV64WM.append(VVB35E)
   VV64WM.append(    ("Set current directory as \"Startup Path\"" , "VVGVHJ" ))
   FFUdxd(self, self.VVAljz, title="Options", VV64WM=VV64WM)
 def VVAljz(self, item=None):
  if self.mode == self.VVxqD9:
   if item is not None:
    path = self.VVs5qQ(self.VVd1c8())
    selFile = self.VVd1c8()
    if   item == "properties"    : self.VV3ja1()
    elif item == "VV5Pvp"  : self.VV5Pvp(path)
    elif item == "VVx2G6"  : self.VVx2G6(path)
    elif item == "VVpPO8" : self.VVpPO8(path)
    elif item.startswith("extract_")  : self.VVSQyW(path, selFile, item)
    elif item.startswith("script_")   : self.VVmIyW(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVxfNtItem_m3u(path, selFile, item)
    elif item.startswith("textView_def") : FFyCNw(self, path)
    elif item.startswith("textView_enc") : self.VVChnD(path)
    elif item.startswith("text_Edit")  : CCfUC2(self, path)
    elif item == "chmod644"     : self.VVDeOV(path, selFile, "644")
    elif item == "chmod755"     : self.VVDeOV(path, selFile, "755")
    elif item == "chmod777"     : self.VVDeOV(path, selFile, "777")
    elif item == "VV1L9A"   : self.VV1L9A(path, selFile)
    elif item == "VV0eeU"   : self.VV0eeU(path, selFile)
    elif item == "copyFileOrDir"   : self.VVHCXE(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVHCXE(path, selFile, True)
    elif item == "VVSxHG"   : self.VVSxHG(path, selFile)
    elif item == "createNewFile"   : self.VV3abT(path, True)
    elif item == "createNewDir"    : self.VV3abT(path, False)
    elif item == "VVMdhg"   : self.VVMdhg()
    elif item == "VVGVHJ"   : self.VVGVHJ(path)
    elif item == "VVZJfr"    : self.VVZJfr()
    else         : self.close()
 def VVZJfr(self):
  selFile = self.VVd1c8()
  path  = self.VVs5qQ(selFile)
  if os.path.isfile(path):
   VVV9xk = []
   category = self["myMenu"].VVZqVr(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVFleu(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FFIOvl(self, selFile, path)
   elif category == "txt"         : FFyCNw(self, path)
   elif category in ("tar", "zip", "rar")     : self.VV7jxS(path, selFile)
   elif category == "scr"         : self.VVZHhu(path, selFile)
   elif category == "m3u"         : self.VVFhxE(path, selFile)
   elif category in ("ipk", "deb")       : self.VVkFsV(path, selFile)
   elif category == "mus"         : self.VVlK5w(self, path)
   elif category == "mov"         : self.VVlK5w(self, path)
   elif not FFCbgi(path)        : FFyCNw(self, path)
 def VVtTJz(self):
  path = self.VVs5qQ(self.VVd1c8())
  action = self.VVbT3Z(path)
  if action == 1:
   self.VVQfHr(path)
   FFmoBc(self, "Added", 500)
  elif action == -1:
   self.VV5Wrt(path)
   FFmoBc(self, "Removed", 500)
  self.VVbT3Z(path)
 def VVQfHr(self, path):
  VVATVO = self.VVcrcf()
  if not VVATVO:
   VVATVO = []
  if len(VVATVO) >= self.VV7B4K:
   FF3wnI(SELF, "Max bookmarks reached (max=%d)." % self.VV7B4K)
  elif not path in VVATVO:
   VVATVO = [path] + VVATVO
   self.VVblCE(VVATVO)
 def VVfrqD(self):
  VVATVO = self.VVcrcf()
  if VVATVO:
   newList = []
   for line in VVATVO:
    newList.append((line, line))
   VVZg0c  = ("Delete"  , self.VVd8sE )
   VV78RH = ("Move Up"   , self.VVApUm )
   VVY0ds  = ("Move Down" , self.VVhhpz )
   self.bookmarkMenu = FFUdxd(self, self.VVSFhv, title="Bookmarks", VV64WM=newList, VVZg0c=VVZg0c, VV78RH=VV78RH, VVY0ds=VVY0ds)
 def VVd8sE(self, VVd1c8Obj, path):
  if self.bookmarkMenu:
   VVATVO = self.VV5Wrt(path)
   self.bookmarkMenu.VVM8HY(VVATVO)
 def VVApUm(self, VVd1c8Obj, path):
  if self.bookmarkMenu:
   VVATVO = self.bookmarkMenu.VVL4YU(True)
   if VVATVO:
    self.VVblCE(VVATVO)
 def VVhhpz(self, VVd1c8Obj, path):
  if self.bookmarkMenu:
   VVATVO = self.bookmarkMenu.VVL4YU(False)
   if VVATVO:
    self.VVblCE(VVATVO)
 def VVSFhv(self, folder=None):
  if folder:
   folder = FFMXkM(folder)
   self["myMenu"].VVm3lk(folder)
   self["myMenu"].moveToIndex(0)
  self.VVrNO5()
 def VVcrcf(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVhIlr(self, path):
  VVATVO = self.VVcrcf()
  if VVATVO and path in VVATVO:
   return True
  else:
   return False
 def VVfgM6(self):
  if VVcrcf():
   return True
  else:
   return False
 def VVblCE(self, VVATVO):
  line = ",".join(VVATVO)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VV5Wrt(self, path):
  VVATVO = self.VVcrcf()
  if VVATVO:
   while path in VVATVO:
    VVATVO.remove(path)
   self.VVblCE(VVATVO)
   return VVATVO
 def VVMdhg(self, chDir=True):
  fPath, fDir, fName = CCN0r2.VVyaVF(self)
  if fPath:
   if chDir:
    self["myMenu"].VVm3lk(fDir)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFmoBc(self, "Not found", 1000)
 def VVGVHJ(self, path):
  if not os.path.isdir(path):
   path = FFADc6(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVFleu(self, selFile, VVLGGV, command):
  FFysO2(self, boundFunction(FFSA5Q, self, command, VVc6vh=self.VVt1UZ), "%s\n\n%s" % (VVLGGV, selFile))
 def VVyURa(self, path, calledFromMenu):
  destPath = self.VVuDks(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VV64WM = []
  if calledFromMenu:
   VV64WM.append(VVB35E)
   color = VVValh
  else:
   color = ""
  VV64WM.append((color + "List Archived Files"          , "extract_listFiles" ))
  VV64WM.append(VVB35E)
  VV64WM.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VV64WM.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VV64WM.append((color + "Extract Here"            , "extract_here"  ))
  if VVioJp and path.endswith(".tar.gz"):
   VV64WM.append(VVB35E)
   VV64WM.append((color + 'Convert to ".ipk" Package' , "VV90UD"  ))
   VV64WM.append((color + 'Convert to ".deb" Package' , "VVsduq"  ))
  return VV64WM
 def VV7jxS(self, path, selFile):
  FFUdxd(self, boundFunction(self.VVSQyW, path, selFile), title="Compressed File Options", VV64WM=self.VVyURa(path, False))
 def VVSQyW(self, path, selFile, item=None):
  if item is not None:
   parent  = FFADc6(path, False)
   destPath = self.VVuDks(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVFkPZ
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FF13Wm("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FF13Wm("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVFkPZ, VVFkPZ)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFLfrr(self, cmd)
   elif path.endswith(".zip"):
    self.VVthqa(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif path.endswith(".rar"):
    self.VVPkPj(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFUJYt("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVFleu(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVFleu(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFADc6(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVFleu(selFile, "Extract Here ?"      , cmd)
   elif item == "VV90UD" : self.VV90UD(path)
   elif item == "VVsduq" : self.VVsduq(path)
 def VVuDks(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVthqa(self, item, path, parent, destPath, VVLGGV):
  FFysO2(self, boundFunction(self.VVKO4g, item, path, parent, destPath), VVLGGV)
 def VVKO4g(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVFkPZ
  cmd  = FF13Wm("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FF8OuG(destPath, VVAexn))
  cmd +=   sep
  cmd += "fi;"
  FFMB4s(self, cmd, VVc6vh=self.VVt1UZ)
 def VVPkPj(self, item, path, parent, destPath, VVLGGV):
  FFysO2(self, boundFunction(self.VVCGG9, item, path, parent, destPath), VVLGGV)
 def VVCGG9(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFMXkM(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVFkPZ
  cmd  = FF13Wm("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FF8OuG(destPath, VVAexn))
  cmd +=   sep
  cmd += "fi;"
  FFMB4s(self, cmd, VVc6vh=self.VVt1UZ)
 def VVqvBU(self, addSep=False):
  VV64WM = []
  if addSep:
   VV64WM.append(VVB35E)
  VV64WM.append((VVValh + "View Script File"  , "script_View"  ))
  VV64WM.append((VVValh + "Execute Script File" , "script_Execute" ))
  VV64WM.append((VVValh + "Edit"     , "script_Edit" ))
  return VV64WM
 def VVZHhu(self, path, selFile):
  FFUdxd(self, boundFunction(self.VVmIyW, path, selFile), title="Script File Options", VV64WM=self.VVqvBU())
 def VVmIyW(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFyCNw(self, path)
   elif item == "script_Execute" : self.VVFleu(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCfUC2(self, path)
 def VVsavL(self, addSep=False):
  VV64WM = []
  if addSep:
   VV64WM.append(VVB35E)
  VV64WM.append((VVValh + "Browse IPTV Channels"  , "m3u_Browse" ))
  VV64WM.append((VVValh + "Edit"      , "m3u_Edit" ))
  VV64WM.append((VVValh + "View"      , "m3u_View" ))
  return VV64WM
 def VVFhxE(self, path, selFile):
  FFUdxd(self, boundFunction(self.VVxfNtItem_m3u, path, selFile), title="M3U/M3U8 File Options", VV64WM=self.VVsavL())
 def VVxfNtItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFb4DW(self, boundFunction(self.session.open, CCNFtw, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCfUC2(self, path)
   elif item == "m3u_View"  : FFyCNw(self, path)
 def VVChnD(self, path):
  if fileExists(path) : FFb4DW(self, boundFunction(CCAv2L.VV6idB, self, path, boundFunction(self.VVC18b, path), defEnc=None), title="Loading Codecs ...", clearMsg=False)
  else    : FFTvTY(self, path)
 def VVC18b(self, path, item=None):
  if item:
   FFyCNw(self, path, encLst=item)
 def VVDeOV(self, path, selFile, newChmod):
  FFysO2(self, boundFunction(self.VVLEgF, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVLEgF(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VV6iqe)
  result = FFhOpk(cmd)
  if result == "Successful" : FFi9RU(self, result)
  else      : FF3wnI(self, result)
 def VV1L9A(self, path, selFile):
  parent = FFADc6(path, False)
  self.session.openWithCallback(self.VVoz9i, boundFunction(CCN0r2, mode=CCN0r2.VVBjC9, VV8UhH=parent, VVHn5t="Create Symlink here"))
 def VVoz9i(self, newPath):
  if len(newPath) > 0:
   target = self.VVs5qQ(self.VVd1c8())
   target = FFhTBt(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFMXkM(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FF3wnI(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFysO2(self, boundFunction(self.VVg6LO, target, link), "Create Soft Link ?\n\n%s" % txt, VVESi4=True)
 def VVg6LO(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VV6iqe)
  result = FFhOpk(cmd)
  if result == "Successful" : FFi9RU(self, result)
  else      : FF3wnI(self, result)
 def VV0eeU(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFaNVN(self, boundFunction(self.VVEekj, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVEekj(self, path, selFile, VVtkVj):
  if VVtkVj:
   parent = FFADc6(path, True)
   if os.path.isdir(path):
    path = FFhTBt(path)
   newName = parent + VVtkVj
   cmd = "mv '%s' '%s' %s" % (path, newName, VV6iqe)
   if VVtkVj:
    if selFile != VVtkVj:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFysO2(self, boundFunction(self.VV1dz6, cmd), message, title="Rename file?")
    else:
     FF3wnI(self, "Cannot use same name!", title="Rename")
 def VV1dz6(self, cmd):
  result = FFhOpk(cmd)
  if "Fail" in result:
   FF3wnI(self, result)
  self.VVt1UZ()
 def VVHCXE(self, path, selFile, isMove):
  if isMove : VVHn5t = "Move to here"
  else  : VVHn5t = "Copy to here"
  parent = FFADc6(path, False)
  self.session.openWithCallback(boundFunction(self.VVWDgO, isMove, path, selFile)
         , boundFunction(CCN0r2, mode=CCN0r2.VVBjC9, VV8UhH=parent, VVHn5t=VVHn5t))
 def VVWDgO(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFhTBt(path)
   newPath = FFMXkM(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFysO2(self, boundFunction(FFcaNF, self, cmd, VVc6vh=self.VVt1UZ), txt, VVESi4=True)
   else:
    FF3wnI(self, "Cannot %s to same directory !" % action.lower())
 def VVSxHG(self, path, fileName):
  path = FFhTBt(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFysO2(self, boundFunction(self.VVKzHW, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVKzHW(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VVt1UZ()
 def VV038n(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVj3zx and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VV3abT(self, path, isFile):
  dirName = FFMXkM(os.path.dirname(path))
  if isFile : objName, VVtkVj = "File"  , self.edited_newFile
  else  : objName, VVtkVj = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFaNVN(self, boundFunction(self.VVcHVQ, dirName, isFile, title), title=title, defaultText=VVtkVj, message="Enter %s Name:" % objName)
 def VVcHVQ(self, dirName, isFile, title, VVtkVj):
  if VVtkVj:
   if isFile : self.edited_newFile = VVtkVj
   else  : self.edited_newDir  = VVtkVj
   path = dirName + VVtkVj
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VV6iqe)
    else  : cmd = "mkdir '%s' %s" % (path, VV6iqe)
    result = FFhOpk(cmd)
    if "Fail" in result:
     FF3wnI(self, result)
    self.VVt1UZ()
   else:
    FF3wnI(self, "Name already exists !\n\n%s" % path, title)
 def VVkFsV(self, path, selFile):
  VV64WM = []
  VV64WM.append(("List Package Files"          , "VVBjLX"     ))
  VV64WM.append(("Package Information"          , "VVpgrN"     ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Install Package"           , "VVFphn_CheckVersion" ))
  VV64WM.append(("Install Package (force reinstall)"      , "VVFphn_ForceReinstall" ))
  VV64WM.append(("Install Package (force overwrite)"      , "VVFphn_ForceOverwrite" ))
  VV64WM.append(("Install Package (force downgrade)"      , "VVFphn_ForceDowngrade" ))
  VV64WM.append(("Install Package (ignore failed dependencies)"    , "VVFphn_IgnoreDepends" ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Remove Related Package"         , "VVU541_ExistingPackage" ))
  VV64WM.append(("Remove Related Package (force remove)"     , "VVU541_ForceRemove"  ))
  VV64WM.append(("Remove Related Package (ignore failed dependencies)"  , "VVU541_IgnoreDepends" ))
  VV64WM.append(VVB35E)
  VV64WM.append(("Extract Files"           , "VVMDPS"     ))
  VV64WM.append(("Unbuild Package"           , "VVCNW4"     ))
  FFUdxd(self, boundFunction(self.VV1lm1, path, selFile), VV64WM=VV64WM)
 def VV1lm1(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVBjLX"      : self.VVBjLX(path, selFile)
   elif item == "VVpgrN"      : self.VVpgrN(path)
   elif item == "VVFphn_CheckVersion"  : self.VVFphn(path, selFile, VVMxji     )
   elif item == "VVFphn_ForceReinstall" : self.VVFphn(path, selFile, VVIxA6 )
   elif item == "VVFphn_ForceOverwrite" : self.VVFphn(path, selFile, VVeAw5 )
   elif item == "VVFphn_ForceDowngrade" : self.VVFphn(path, selFile, VVc2aH )
   elif item == "VVFphn_IgnoreDepends" : self.VVFphn(path, selFile, VVD21Q )
   elif item == "VVU541_ExistingPackage" : self.VVU541(path, selFile, VV402z     )
   elif item == "VVU541_ForceRemove"  : self.VVU541(path, selFile, VVjBJk  )
   elif item == "VVU541_IgnoreDepends"  : self.VVU541(path, selFile, VVrSTd )
   elif item == "VVMDPS"     : self.VVMDPS(path, selFile)
   elif item == "VVCNW4"     : self.VVCNW4(path, selFile)
   else           : self.close()
 def VVBjLX(self, path, selFile):
  if FFQiCi("ar") : cmd = "allOK='1';"
  else    : cmd  = FF0OmY()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVFkPZ, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVFkPZ, VVFkPZ)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFLeXJ(self, cmd, VVc6vh=self.VVt1UZ)
 def VVMDPS(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFADc6(path, True) + selFile[:-4]
  cmd  =  FF0OmY()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFUJYt("mkdir '%s'" % dest) + ";"
  cmd +=    FFUJYt("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FF8OuG(dest, VVAexn))
  cmd += "fi;"
  FFSA5Q(self, cmd, VVc6vh=self.VVt1UZ)
 def VVCNW4(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVrszS = os.path.splitext(path)[0]
  else        : VVrszS = path + "_"
  if path.endswith(".deb")   : VV5lKD = "DEBIAN"
  else        : VV5lKD = "CONTROL"
  cmd  = FF0OmY()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVrszS, FFTvuI())
  cmd += "  mkdir '%s';"    % VVrszS
  cmd += "  CONTPATH='%s/%s';"  % (VVrszS, VV5lKD)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVrszS
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVrszS, VVrszS)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVrszS
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVrszS, VVrszS)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVrszS
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVrszS
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVrszS, FF8OuG(VVrszS, VVAexn))
  cmd += "fi;"
  FFSA5Q(self, cmd, VVc6vh=self.VVt1UZ)
 def VVpgrN(self, path):
  listCmd  = FF5FY1(VVHiEG, "")
  infoCmd  = FFU7ig(VVe7Ha , "")
  filesCmd = FFU7ig(VVcOCF, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFBpeU(VVgcU9)
   notInst = "Package not installed."
   cmd  = FF2l60("File Info", VVgcU9)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FF2l60("System Info", VVgcU9)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FF8OuG(notInst, VVValh))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FF2l60("Related Files", VVgcU9)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFLfrr(self, cmd)
  else:
   FFdiGu(self)
 def VVFphn(self, path, selFile, cmdOpt):
  cmd = FFU7ig(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFysO2(self, boundFunction(FFSA5Q, self, cmd, VVc6vh=FFgSiE), "Install Package ?\n\n%s" % selFile)
  else:
   FFdiGu(self)
 def VVU541(self, path, selFile, cmdOpt):
  listCmd  = FF5FY1(VVHiEG, "")
  infoCmd  = FFU7ig(VVe7Ha, "")
  instRemCmd = FFU7ig(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FF8OuG(errTxt, VVValh))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FF8OuG(cannotTxt, VVValh))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FF8OuG(tryTxt, VVValh))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFysO2(self, boundFunction(FFSA5Q, self, cmd, VVc6vh=FFgSiE), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFdiGu(self)
 def VVe4Sv(self, path):
  hostName = FFhOpk("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVn3Y2(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVe4Sv(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VV5Pvp(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VV64WM = []
  VV64WM.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VV64WM.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VV64WM.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VV64WM.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VV64WM.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VV64WM.append(VVB35E)
  VV64WM.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VV64WM.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VV64WM.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VV64WM.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VV64WM.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VV64WM.append(VVB35E)
  VV64WM.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VV64WM.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFUdxd(self, boundFunction(self.VVHB8Y, path), VV64WM=VV64WM)
 def VVHB8Y(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVHKge(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVHKge(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVHKge(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVHKge(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVHKge(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVHKge(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVHKge(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVHKge(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVHKge(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVHKge(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVS6rh(path, False)
   elif item == "convertDirToDeb"   : self.VVS6rh(path, True)
   else         : self.close()
 def VVS6rh(self, path, VVPOOn):
  self.session.openWithCallback(self.VVt1UZ, boundFunction(CC78zY, path=path, VVPOOn=VVPOOn))
 def VVHKge(self, path, fileExt, preserveDirStruct):
  parent  = FFADc6(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FF13Wm("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FF13Wm("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FF13Wm("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVFkPZ
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFUJYt("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FF8OuG(resultFile, VVAexn))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FF8OuG(failed, VVe3tS))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFLeXJ(self, cmd, VVc6vh=self.VVt1UZ)
 def VVx2G6(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFyCNw(self, versionFile)
 def VVpPO8(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVe4Sv(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FF3wnI(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFK66c(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFADc6(path, False)
  VVrszS = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FF8OuG(errCmd, VVe3tS))
  installCmd = FFU7ig(VVMxji , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVrszS, VVrszS)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVrszS
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVrszS
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVrszS, VVrszS)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFSA5Q(self, cmd, VVc6vh=self.VVt1UZ)
 def VV90UD(self, path):
  FF3wnI(self, "Under Construction.")
 def VVsduq(self, path):
  FF3wnI(self, "Under Construction.")
 @staticmethod
 def VVlK5w(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   SELF.session.open(CCkjHt, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVyaVF(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFMXkM(fDir), fName
  return "", "", ""
 @staticmethod
 def VVXBdy(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVTwnf(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVAajP(size, mode=0):
  txt = CCN0r2.VVa4Kt(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVa4Kt(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
class CCtyMq(MenuList):
 def __init__(self, VVVXyA=False, directory="/", VVGzxX=True, VVcVAc=True, VVEmUy=True, VV2g6V=None, VVZqRC=False, VVcQn5=False, VVY5Bp=False, isTop=False, VVR3gh=None, VVkyKm=1000, VV4RrQ=30, VVAa0V=30, VV0Jgs="#00000000"):
  MenuList.__init__(self, list, VVVXyA, eListboxPythonMultiContent)
  self.VVGzxX  = VVGzxX
  self.VVcVAc    = VVcVAc
  self.VVEmUy  = VVEmUy
  self.VV2g6V  = VV2g6V
  self.VVZqRC   = VVZqRC
  self.VVcQn5   = VVcQn5 or []
  self.VVY5Bp   = VVY5Bp or []
  self.isTop     = isTop
  self.additional_extensions = VVR3gh
  self.VVkyKm    = VVkyKm
  self.VV4RrQ    = VV4RrQ
  self.VVAa0V    = VVAa0V
  self.pngBGColor    = FF03Jc(VV0Jgs)
  self.EXTENSIONS    = self.VVgOVK()
  self.VV8O7b   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVIbI9, self.VV4RrQ))
  self.l.setItemHeight(self.VVAa0V)
  self.png_mem   = self.VVwrT6("mem")
  self.png_usb   = self.VVwrT6("usb")
  self.png_fil   = self.VVwrT6("fil")
  self.png_dir   = self.VVwrT6("dir")
  self.png_dirup   = self.VVwrT6("dirup")
  self.png_srv   = self.VVwrT6("srv")
  self.png_slwfil   = self.VVwrT6("slwfil")
  self.png_slbfil   = self.VVwrT6("slbfil")
  self.png_slwdir   = self.VVwrT6("slwdir")
  self.VVTLqi()
  self.VVm3lk(directory)
 def VVwrT6(self, category):
  return LoadPixmap("%s%s.png" % (VVe57v, category), getDesktop(0))
 def VVgOVK(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "rar" : "rar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u" ,
   "m3u8" : "m3u"
  }
 def VVIijY(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFhTBt(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFtsFe(" -> " , VVgcU9) + FFtsFe(os.readlink(path), VVAexn)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVAa0V + 10, 0, self.VVkyKm, self.VVAa0V, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VV0l6A: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVAa0V-4, self.VVAa0V-4, png, self.pngBGColor, self.pngBGColor, VV0l6A))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVAa0V-4, self.VVAa0V-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVZqVr(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVTLqi(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VV5inq(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVSAn3(self, file):
  if os.path.realpath(file) == file:
   return self.VV5inq(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VV5inq(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VV5inq(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVhM8x(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VV8O7b.info(l[0][0]).getEvent(l[0][0])
 def VVzMjj(self):
  return self.list
 def VVWmUm(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVm3lk(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVEmUy:
    self.current_mountpoint = self.VVSAn3(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVEmUy:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVY5Bp and not self.VVWmUm(path, self.VVcQn5):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVIijY(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVZqRC:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VV8O7b = eServiceCenter.getInstance()
   list = VV8O7b.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVGzxX and not self.isTop:
   if directory == self.current_mountpoint and self.VVEmUy:
    self.list.append(self.VVIijY(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVY5Bp and self.VV5inq(directory) in self.VVY5Bp):
    self.list.append(self.VVIijY(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVGzxX:
   for x in directories:
    if not (self.VVY5Bp and self.VV5inq(x) in self.VVY5Bp) and not self.VVWmUm(x, self.VVcQn5):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVIijY(name = name, absolute = x, isDir = True, png = png))
  if self.VVcVAc:
   for x in files:
    if self.VVZqRC:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFtsFe(" -> " , VVgcU9) + FFtsFe(target, VVAexn)
       else:
        png = self.png_slbfil
        name += FFtsFe(" -> " , VVgcU9) + FFtsFe(target, VVe3tS)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVZqVr(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVe57v, category))
    if (self.VV2g6V is None) or iCompile(self.VV2g6V).search(path):
     self.list.append(self.VVIijY(name = name, absolute = x , isDir = False, png = png))
  if self.VVEmUy and len(self.list) == 0:
   self.list.append(self.VVIijY(name = FFtsFe("No USB connected", VVBPJz), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVT2hn(self):
  return self.current_directory
 def VVuKUH(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVm3lk(self.getSelection()[0], select = self.current_directory)
 def VVzsHm(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVTaUa(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVujIo)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVujIo)
 def refresh(self):
  self.VVm3lk(self.current_directory, self.VVzsHm())
 def VVujIo(self, action, device):
  self.VVTLqi()
  if self.current_directory is None:
   self.refresh()
class CC429m(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFhdcK(VVLluH, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVATVO   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVixdi(defFG, "#00FFFFFF")
  self.defBG   = self.VVixdi(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFFgql(self, self.Title)
  self["keyRed"].show()
  FF9CgN(self["keyGreen"] , "< > Transp.")
  FF9CgN(self["keyYellow"], "Foreground")
  FF9CgN(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVplie        ,
   "yellow"   : boundFunction(self.VVSZic, False)  ,
   "blue"   : boundFunction(self.VVSZic, True)  ,
   "up"   : self.VVmeLf          ,
   "down"   : self.VVJgQv         ,
   "left"   : self.VVrCAA         ,
   "right"   : self.VVxaGR         ,
   "last"   : boundFunction(self.VVvUkZ, -5) ,
   "next"   : boundFunction(self.VVvUkZ, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFrlPO(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFrlPO(self["keyRed"] , c)
  FFrlPO(self["keyGreen"] , c)
  self.VV51UG()
  self.VVU68q()
  FFaMdN(self["myColorTst"], self.defFG)
  FFrlPO(self["myColorTst"], self.defBG)
 def VVixdi(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVU68q(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVcwqg(0, 0)
     return
 def VVplie(self):
  self.close(self.defFG, self.defBG)
 def VVmeLf(self): self.VVcwqg(-1, 0)
 def VVJgQv(self): self.VVcwqg(1, 0)
 def VVrCAA(self): self.VVcwqg(0, -1)
 def VVxaGR(self): self.VVcwqg(0, 1)
 def VVcwqg(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVwF1I()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVxa8s()
 def VV51UG(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVxa8s(self):
  color = self.VVwF1I()
  if self.isBgMode: FFrlPO(self["myColorTst"], color)
  else   : FFaMdN(self["myColorTst"], color)
 def VVSZic(self, isBg):
  self.isBgMode = isBg
  self.VV51UG()
  self.VVU68q()
 def VVvUkZ(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVcwqg(0, 0)
 def VVU1ih(self):
  return hex(self.transp)[2:].zfill(2)
 def VVwF1I(self):
  return ("#%s%s" % (self.VVU1ih(), self.colors[self.curRow][self.curCol])).upper()
class CCVhHd(Screen):
 VVTpx3  = 0
 VVjClK = 1
 def __init__(self, session, mode, endCallback):
  self.session  = session
  margin    = 50
  screenSize   = FFGpXP()
  w     = int(screenSize[0] - margin)
  h     = int(screenSize[1] / 2.0)
  self.skin, self.skinParam = FFhdcK(WINDOW_SUBTITLE, w, h, 35, 20, 30, "#ff000000", "#ff000000", 60)
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.currentIndex  = -1
  self.subtitleMode  = mode
  self.defaultY   = 0
  self.endCallback  = endCallback
  FFFgql(self)
  self["myTitle"].hide()
  self["mySubtFr"] = Label()
  self["mySubtFr"].hide()
  for i in range(3):
   self["mySubt%d" % i] = Label()
  self.onClose.append(self.VVpF9w)
 def VVzrwN(self, path=""):
  if path :
   self.VVLTpH()
   FFb4DW(self, boundFunction(self.VVb0vf, path), title="Checking file ...", clearMsg=False)
  else:
   self.VVb0vf()
 def VVb0vf(self, path=""):
  if path:
   subtList, err = self.VVclVa(path)
   if err    : self.VVpF9w(err)
   elif not subtList : self.VVpF9w("Invalid srt file")
   else    :
    self.subtList = subtList
    self.VVsPV1()
  else:
   if self.VVj5Kn():
    self.VVsPV1()
   elif self.subtitleMode == CCVhHd.VVjClK:
    self.VVpF9w("noResume")
   else:
    if self.VVJev1(): self.VVsPV1()
    else         : self.VVpF9w("noAutoSrt")
 def VVsPV1(self):
  try:
   InfoBar.instance.enableSubtitle(None)
  except:
   try:
    InfoBar.instance.setSubtitlesEnable(False)
   except:
    pass
  FFmoBc(self, "Subtitle started", 1000, isGrn=True)
  self.VVLTpH()
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVZhgx)
  except:
   self.timerUpdate.callback.append(self.VVZhgx)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVRcv7)
  except:
   self.timerEndText.callback.append(self.VVRcv7)
  self.VVbdKm(True)
 def VVpF9w(self, res=""):
  self.timerUpdate.stop()
  self.timerEndText.stop()
  self.VVbdKm(False)
  self.endCallback(res)
 def VVbdKm(self, isAdd):
  lst = [CFG.subtDelay, CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextSize, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtShadowSize, CFG.subtVerticalPos]
  notifier = self.VVLTpH
  for item in lst:
   if isAdd:
    item.addNotifier(notifier, initial_call=False)
   else:
    try:
     item.removeNotifier(notifier)
    except:
     try:
      notifier in item.notifiers and item.notifiers.remove(notifier)
      notifier in item.notifiers_final and item.notifiers_final.remove(notifier)
     except Exception as e:
      pass
 def VVj5Kn(self):
  fPath, fDir, fName = CCN0r2.VVyaVF(self)
  if fPath:
   path = fPath + ".ajp"
   if fileExists(path):
    lines = FFK66c(path)
    srt = delay = enc = ""
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : srtPath = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay   = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc   = line.split("=")[1].strip()
    if srtPath and fileExists(srtPath):
     subtList, err = self.VVclVa(srtPath, enc)
     if subtList:
      self.lastSubtEnc = enc
      self.subtList = subtList
      try:
       CFG.subtDelay.setValue("%.1f" % float(delay))
      except:
       pass
      return True
  return False
 def VVJev1(self):
  bestSrt, bestRatio = CCVhHd.VVsXcz(self)
  if bestSrt and bestRatio > 40:
   subtList, err = self.VVclVa(bestSrt)
   if subtList:
    self.subtList = subtList
    return True
  return False
 def VVmbuI(self):
  VV64WM = []
  if self.lastSubtFile:
   VV64WM.append(("Settings"      , "set"  ))
   VV64WM.append(("Change Encoding"    , "enc"  ))
   VV64WM.append(("Disable Current Subtitle"  , "disab" ))
   VV64WM.append(VVB35E)
  VV64WM.append(("Find all srt file"    , "findSrt" ))
  lst = CCVhHd.VVMTMF(self)
  if lst:
   VV64WM.append(VVB35E)
   for item in lst:
    fName = os.path.basename(item)
    if self.lastSubtFile == item:
     fName = FFtsFe(fName, VVAexn)
    VV64WM.append((fName, item))
  win = FFUdxd(self, self.VVaalz, VV64WM=VV64WM, width=1200, title="Subtitle Options")
  win.instance.move(ePoint(40, 40))
 def VVaalz(self, item=None):
  if item:
   if item == "set":
    self["mySubtFr"].show()
    for i in range(3):
     FFrlPO(self["mySubt%d" % i], "#55000000")
    self.session.openWithCallback(self.VVjQth, CCDFEq)
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile):
     FFb4DW(self, boundFunction(CCAv2L.VV6idB, self, self.lastSubtFile, self.VV6Qbh, defEnc=self.lastSubtEnc, pos=1), title="Loading Codecs ...", clearMsg=False)
    else:
     FFmoBc(self, "SRT File error", 1000)
   elif item == "disab":
    fPath, fDir, fName = CCN0r2.VVyaVF(self)
    os.system(FFUJYt("rm -f '%s'" % fPath + ".ajp"))
    self.VVpF9w("noErr")
   elif item == "findSrt":
    CCVhHd.VV7RO9(self, self.VVCffa, defSrt=self.lastSubtFile, pos=1)
   else:
    self.VVCffa(item)
 def VVjQth(self, res):
  self["mySubtFr"].hide()
  for i in range(3):
   FFrlPO(self["mySubt%d" % i], "#FF000000")
  if res:
   self.VVAoMz()
   self.VVLTpH()
 def VVLTpH(self, configElement=None):
  fnt = CFG.subtTextFont.getValue()
  if not fnt in FFMsxt():
   fnt = VVIbI9
  lineH = 0
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFaMdN(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    inst.setHAlign(int(CFG.subtTextAlign.getValue()))
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    inst.setNoWrap(True)
    lineH = FFtdej(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    inst.move(ePoint(int(inst.position().x()), int(lineH * i + 1)))
  except:
   pass
  try:
   height = lineH * 3 + 2
   if not self.defaultY:
    self.defaultY = int(getDesktop(0).size().height() - height - self.skinParam["marginTop"])
   if lineH:
    self.instance.resize(eSize(*(int(self.instance.size().width()), height)))
   y = int(self.defaultY + CFG.subtVerticalPos.getValue())
   y = min(y, getDesktop(0).size().height() - height - 5)
   self.instance.move(ePoint(int(self.instance.position().x()), int(y)))
   inst = self["myInfoFrame"].instance
   inst.move(ePoint(int(inst.position().x()), 2))
   inst = self["myInfoBody"].instance
   inst.move(ePoint(int(inst.position().x()), 4))
  except:
   pass
 def VVCffa(self, path, enc=None):
  self.timerUpdate.stop()
  subtList, err = self.VVclVa(path, enc)
  if err    : FFmoBc(self, err, 2000)
  elif not subtList : FFmoBc(self, "Invalid SRT file", 2000)
  else    :
   self.subtList  = subtList
   self.lastSubtInfo = ""
   self.lastSubtEnc = ""
   self.currentIndex = 0
   CFG.subtDelay.setValue("0.0")
   for i in range(3):
    FFaMdN(self["mySubt%d" % i], "#ffffff")
    self["mySubt%d" % i].setText("")
   FFmoBc(self, "Subtitle started", 1000, isGrn=True)
  self.timerUpdate.start(500, False)
 def VV6Qbh(self, item=None):
  if item:
   self.VVCffa(self.lastSubtFile, item)
 @staticmethod
 def VVMTMF(SELF):
  fPath, fDir, fName = CCN0r2.VVyaVF(SELF)
  if pathExists(fDir):
   files = iGlob("%s*.srt" % fDir)
   if files:
    return files
  return []
 @staticmethod
 def VVsXcz(SELF):
  bestSrt = ""
  bestRatio = 0
  fPath, fDir, fName = CCN0r2.VVyaVF(SELF)
  if fName:
   movName = os.path.splitext(fName)[0].lower()
   files = CCVhHd.VVMTMF(SELF)
   for path in files:
    fName = os.path.basename(path)
    fName = os.path.splitext(fName)[0]
    ratio = CC7Ld1.VVuULS(movName.lower(), fName.lower())
    if ratio > bestRatio:
     bestRatio = ratio
     bestSrt = path
  return bestSrt, bestRatio
 def VVDu0H(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVclVa(self, path, enc=None):
  if not fileExists(path):
   return [], "File not found"
  if (FFmOde(path) > 1024 * 700):
   return [], "File too big"
  capNum = frmSec = toSec = bold = italic = under = 0
  color  = ""
  subtLines = []
  subtList = []
  capFound = False
  lines  = FFK66c(path, encLst=enc if enc else None)
  for line in lines:
   line = line.strip()
   if line:
    if not capFound and line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVDu0H(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      subtLines.append((line.strip(), color, bold, italic, under))
   else:
    if (toSec - frmSec) > 0:
     subtList.append((capNum, frmSec, toSec, subtLines))
    capFound = False
    subtLines = []
    color = ""
    capNum = frmSec = toSec = bold = italic = under = 0
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVAoMz()
  return subtList, ""
 def VVAoMz(self):
  fPath, fDir, fName = CCN0r2.VVyaVF(self)
  if fPath and pathExists(fDir):
   with open(fPath + ".ajp", "w") as f:
    f.write("srt=%s\n" % self.lastSubtFile)
    f.write("delay=%s\n" % CFG.subtDelay.getValue())
    if self.lastSubtEnc:
     f.write("enc=%s\n" % self.lastSubtEnc)
 def VVZhgx(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCkjHt.VVeT0D(self)
  txtDur = 0
  lines = []
  self.VVia3h(posVal)
  if self.currentIndex == -2:
   return
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[self.currentIndex]
   if not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    for i in range(3):
     FFaMdN(self["mySubt%d" % i], "#ffffff")
     self["mySubt%d" % i].setText("")
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
     txtDur = int(toSec * 1000 - frmSec * 1000)
     if txtDur > 0:
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        line = line.replace(u"\u202A", "")
        line = line.replace(u"\u202B", "")
        line = line.replace(u"\u202C", "")
        line = str(line)
        if newColor:
         FFaMdN(self["mySubt%d" % ndx], newColor)
        self["mySubt%d" % ndx].setText(line)
      self.timerEndText.start(txtDur, True)
 def VVia3h(self, posVal):
  if posVal > 0:
   delay = float(CFG.subtDelay.getValue())
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     self.currentIndex = ndx
     return
  self.currentIndex = -2
 def VVRcv7(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
 @staticmethod
 def VV7RO9(SELF, cbFnc, defSrt="", pos=0):
  FFb4DW(SELF, boundFunction(CCVhHd.VVS9Rd, SELF, cbFnc, defSrt, pos), title="Searching for srt files", clearMsg=False)
 @staticmethod
 def VVS9Rd(SELF, cbFnc, defSrt="", pos=0):
  FFmoBc(SELF)
  lines = FFo68R('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFN326(1)))
  if lines:
   lines.sort()
   VV64WM = []
   for item in lines:
    VV64WM.append(((VVAexn if defSrt == item else "") + item, item))
   VVJA2t = ("Show Full Path", CCVhHd.VVpVsn)
   win = FFUdxd(SELF, boundFunction(CCVhHd.VVCxcc, cbFnc), title="Subtitle Files", VV64WM=VV64WM, width=1200, height=500 if pos == 1 else 900, VVJA2t=VVJA2t)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FFmoBc(SELF, "No srt files found !", 2000)
 @staticmethod
 def VVpVsn(VVd1c8Obj, path):
  FFR6iW(VVd1c8Obj, path, title="Full Path")
 @staticmethod
 def VVCxcc(cbFnc, item):
  if item:
   cbFnc(item)
 @staticmethod
 def VV5R52():
  c = s = m = h = 0
  with open(VVe6OI + "AJPanel_test.srt", "w") as f:
   for i in range(1, 5401):
    s += 2
    if s >= 60:
     s = 0
     m += 1
     if m >= 60:
      m = 0
      h += 1
    if i < 6:
     txt  = '<font color="#ffff00">Created by AJPanel</font>\n'
     txt += '<font color="#00ffff">Testing Subtitle Files</font>\n'
     txt += '<font color="#00ff00">Line - %d</font>\n\n' % i
    else:
     txt = '<font color="#ffffbb">Subtitle Line - %d</font>\n\n' % i
    f.write("%d\n" % i)
    f.write("%02d:%02d:%02d,001 --> %02d:%02d:%02d,001\n" % (h, m, s, h, m, s+1))
    f.write(txt)
class CCDFEq(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFhdcK(VVxZpK, 600, 600, 40, 30, 10, "#11331010", "#11442020", 30, barHeight=40)
  self.session  = session
  self.Title   = "Subtitle Settings"
  FFFgql(self, title=self.Title)
  FF9CgN(self["keyRed"] , "Exit")
  FF9CgN(self["keyGreen"] , "Save")
  FF9CgN(self["keyYellow"], "Reset")
  self.confList = []
  self.confList.append(getConfigListEntry("Delay (current movie)" , CFG.subtDelay   ))
  self.confList.append(getConfigListEntry(VVFkPZ *2     ,       ))
  self.confList.append(getConfigListEntry("Text Color"   , CFG.subtTextFg  ))
  self.confList.append(getConfigListEntry("Text Font"    , CFG.subtTextFont  ))
  self.confList.append(getConfigListEntry("Text Size"    , CFG.subtTextSize  ))
  self.confList.append(getConfigListEntry("Alignment"    , CFG.subtTextAlign  ))
  self.confList.append(getConfigListEntry("Shadow Color"   , CFG.subtShadowColor ))
  self.confList.append(getConfigListEntry("Shadow Size"   , CFG.subtShadowSize ))
  self.confList.append(getConfigListEntry(VVFkPZ *2     ,       ))
  self.confList.append(getConfigListEntry("Vertical Pos"   , CFG.subtVerticalPos ))
  ConfigListScreen.__init__(self, self.confList, session)
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVX6tp  ,
   "green"   : self.VVxk8v   ,
   "yellow"  : boundFunction(FFysO2, self, self.VVqlyY, "Reset Subtitle Settings to default ?", title="Subtitle Settings"),
   "cancel"  : self.VVX6tp
  }, -1)
  self.onShown.append(self.VV82q3)
 def VV82q3(self):
  self.onShown.remove(self.VV82q3)
  FFH9Ay(self["config"])
  FFq9fK(self, self["config"])
  FF1rm3(self)
  self.instance.move(ePoint(40, 40))
 def VVX6tp(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFysO2(self, self.VVxk8v, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVxk8v(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  configfile.save()
  self.close(True)
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close(False)
 def VVqlyY(self):
  CFG.subtDelay.setValue("0.0")
  CFG.subtTextFg.setValue("srt")
  CFG.subtTextFont.setValue(VVIbI9)
  CFG.subtTextSize.setValue(50)
  CFG.subtTextAlign.setValue("1")
  CFG.subtShadowColor.setValue("#000080")
  CFG.subtShadowSize.setValue(5)
  CFG.subtVerticalPos.setValue(0)
  self.VVxk8v()
class CCydIb(ScrollLabel):
 def __init__(self, parentSELF, text="", VVynJV=True):
  ScrollLabel.__init__(self, text)
  self.VVynJV=VVynJV
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVMRmP  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VV4RrQ    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close     ,
   "cancel"  : parentSELF.close     ,
   "red"   : self.VVjdKa     ,
   "green"   : self.VVPyTD    ,
   "yellow"  : self.VVtYqT    ,
   "blue"   : self.VVoLLG    ,
   "up"   : self.pageUp      ,
   "down"   : self.pageDown      ,
   "left"   : self.pageUp      ,
   "right"   : self.pageDown      ,
   "last"   : boundFunction(self.VV3IFl, 0) ,
   "next"   : boundFunction(self.VV3IFl, 2) ,
   "0"    : boundFunction(self.VV3IFl, 1) ,
   "pageUp"  : self.VVPnzz      ,
   "chanUp"  : self.VVPnzz      ,
   "pageDown"  : self.VVt7LZ      ,
   "chanDown"  : self.VVt7LZ
  }, -1)
 def VVdsWe(self, isResizable=True, VVqTIr=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FF1rm3(self.parentSELF, True)
  self.isResizable = isResizable
  if VVqTIr:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VV4RrQ  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFrlPO(self, color)
 def FFrlPOColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVMRmP - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVcxon()
 def pageUp(self):
  if self.VVMRmP > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVMRmP > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVPnzz(self):
  self.setPos(0)
 def VVt7LZ(self):
  self.setPos(self.VVMRmP-self.pageHeight)
 def VVWeLb(self):
  return self.VVMRmP <= self.pageHeight or self.curPos == self.VVMRmP - self.pageHeight
 def VVcxon(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVMRmP, 3))
   start = int((100 - vis) * self.curPos / (self.VVMRmP - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVsIwt=VVNiTo):
  old_VVWeLb = self.VVWeLb()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VVMRmP = self.long_text.calculateSize().height()
   if self.VVynJV and self.VVMRmP > self.pageHeight:
    self.scrollbar.show()
    self.VVcxon()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVMRmP))
   if   VVsIwt == VVDQDA: self.setPos(0)
   elif VVsIwt == VVlNJ6 : self.VVt7LZ()
   elif old_VVWeLb    : self.VVt7LZ()
 def appendText(self, text, VVsIwt=VVlNJ6):
  self.setText(self.message + str(text), VVsIwt)
 def VVtYqT(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVLxHp(size)
 def VVoLLG(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVLxHp(size)
 def VVPyTD(self):
  self.VVLxHp(self.VV4RrQ)
 def VVLxHp(self, VV4RrQ):
  self.long_text.setFont(gFont(self.fontFamily, VV4RrQ))
  self.setText(self.message, VVsIwt=VVNiTo)
  self.VVxD83(calledFromFontSizer=True)
 def VV3IFl(self, align):
  self.long_text.setHAlign(align)
 def VVjdKa(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FFMXkM(expPath), self.textOutFile, FFpkvp())
    with open(outF, "w") as f:
     f.write(FFWesU(self.message))
    FFi9RU(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FF3wnI(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVxD83(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVMRmP > 0 and self.pageHeight > 0:
   if self.VVMRmP < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVMRmP
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
