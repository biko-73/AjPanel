import os
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import ceil as iCeil
from time      import localtime, mktime, strftime
from time      import time as iTime
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVOn61   = "v3.0.0"
VV0rqe    = "15-10-2021"
VVIYOM  = "AJ File Manager"
VVamcm   = "AJ Live Log (OSCam/NCam)"
EASY_MODE    = 0
VVZKa6   = 0
VV1wSt   = 0
VVgvyL  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVkvs5  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVhuan    = "/media/usb/"
VVLTqb    = "/usr/share/enigma2/picon/"
VVGnNm   = "/etc/enigma2/"
VVEMg1  = "ajpanel_update_url"
VVTGQU   = "AJPan"
VVrcHB    = ""
VVUC67    = "Regular"
VV8ben      = "-" * 80;
VVhJ3E    = (VV8ben, )
VV8CgR    = ""
VVmw9Y   = " && echo 'Successful' || echo 'Failed!'"
VVlbJ0    = []
VVOgvu     = 0
VVIoC5    = ""
VVU5KH  = False
VVyEf8  = False
VVseVH     = 0
VVal8u    = 1
VVem0w    = 2
VVjRal   = 3
VVfGZx    = 4
VVkuU0    = 5
VVCHm0 = 6
VVrlPa = 7
VV3Am4  = 8
VVuUrL   = 9
VVZpeg   = 10
VVs0oG   = 11
VVo7vq  = 12
VVOcdu  = 13
VVt2o7    = 14
VVEV4h   = 15
VVv5BW   = 16
VVXU1D  = 15
VVXhsS   = 0
VVAqA7   = 1
VVwXIf   = 2
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices = [ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices = [ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices = [ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.PIconsPath     = ConfigDirectory(default=VVLTqb, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVhuan, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
def FFlVG0():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVRhCg  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VV9VQA = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVRhCg  : return 0
  elif VV9VQA : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVKrK3 = FFlVG0()
VVZD1o = VVLIgE = VVP3bf = VVEiu9 = VVju96 = VVRZG6 = VVbnJx = VVApsx = COLOR_CONS_BRIGHT_YELLOW = VVbHZ1 = VV5Hmu = VVI8UI = ""
def FFnGpC(FFnGpCText="", addSep=True):
 if VVZKa6:
  txt = VV8ben + "\n" if addSep else ""
  txt += ">>>> %s >>  %s" % (PLUGIN_NAME, str(FFnGpCText))
  os.system('echo -e "%s"' % txt)
def FFR7Uc(txt, isAppend=True, ignoreErr=False):
 if VVZKa6:
  tm   = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
  err = ""
  if not ignoreErr:
   try:
    from traceback import format_exc, format_stack
    trace = format_exc()
    if trace and len(trace) > 5:
     stack = format_stack()[:-1]
     sep = "*" * 70
     err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
     err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   except:
    pass
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFnGpC(err)
  FFnGpC("Output Log File : %s" % fileName)
VVlbJ0 = []
def FFnMch(win):
 global VVlbJ0
 if not win in VVlbJ0:
  VVlbJ0.append(win)
def FFW3h5(*args):
 global VVlbJ0
 for win in VVlbJ0:
  try:
   win.close()
  except:
   pass
 VVlbJ0 = []
def FFxIGw():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVulDh = FFxIGw()
def getDescriptor(fnc, where, name=PLUGIN_NAME):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=True, name=name, description=PLUGIN_DESCRIPTION, icon=icon)
def FF2x3g()     : return getDescriptor(FFwkhA   , [ PluginDescriptor.WHERE_PLUGINMENU  ] )
def FFs9bw()  : return getDescriptor(FFwkhA   , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] )
def FFGFb9()  : return getDescriptor(FFCcQh , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , VVIYOM)
def FFRjw3() : return getDescriptor(FFyR8O , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , VVamcm)
def FFifWe()    : return getDescriptor(FFUME5  , [ PluginDescriptor.WHERE_SESSIONSTART  ] )
def FFnmHM()      : return getDescriptor(FFb1SZ  , [ PluginDescriptor.WHERE_MENU    ] )
def Plugins(**kwargs):
 result = [ FF2x3g() , FFnmHM() , FFifWe() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFs9bw())
  result.append(FFGFb9())
  result.append(FFRjw3())
 return result
def FFUME5(reason, **kwargs):
 if reason == 0:
  FFxyDn()
  session = kwargs["session"]
  if session:
   FFjWpH(session)
def FFb1SZ(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFwkhA, PLUGIN_NAME, 45)]
 else:
  return []
def FFwkhA(session, **kwargs):
 session.open(Main_Menu)
def FFCcQh(session, **kwargs):
 session.open(CCyaF0)
def FFyR8O(session, **kwargs):
 FFfbem(session, CCObh2.VVdMa1)
def FF5DqA():
 pluginList  = iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU)
 descrPanel  = FFs9bw()
 descrFileMan = FFGFb9()
 descrCamLog  = FFRjw3()
 try:
  if CFG.showInExtensionMenu.getValue():
   if not descrPanel    in pluginList : iPlugins.addPlugin(descrPanel)
   if not descrFileMan  in pluginList : iPlugins.addPlugin(descrFileMan)
   if not descrCamLog in pluginList : iPlugins.addPlugin(descrCamLog)
  else:
   if descrPanel   in pluginList  : iPlugins.removePlugin(descrPanel)
   if descrFileMan in pluginList  : iPlugins.removePlugin(descrFileMan)
   if descrCamLog  in pluginList  : iPlugins.removePlugin(descrCamLog)
 except:
  pass
VVelB1 = None
def FFxyDn():
 try:
  global VVelB1
  if VVelB1 is None:
   VVelB1    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFKvo1
  ChannelContextMenu.FFzKJr = FFzKJr
 except:
  pass
def FFKvo1(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVelB1(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFzKJr, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFzKJr, title1, csel, isFind=True))))
def FFzKJr(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFoZoJ(refCode)
 except:
  pass
 self.session.open(boundFunction(CCNuRU, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFjWpH(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFCEHy, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFCEHy, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFCEHy, session, "lred")
def FFCEHy(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFJZPp(session, isFromSession=True)
def FFyw62(SELF, title="", addLabel=False, addScrollLabel=False, VVei97=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFIP5j()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 if SELF.skinParam["topRightBtns"] > 0:
  SELF["keyMenu2F"]  = Label()
  SELF["keyMenu2"]  = Label("Menu")
  if SELF.skinParam["topRightBtns"] > 1:
   SELF["keyMenu1F"] = Label()
   SELF["keyMenu1"] = Label("Info")
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CC0QxB(SELF)
 if VVei97:
  SELF["myMenu"] = MenuList(VVei97)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVnr3G        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFSIMa(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FFOMpL, SELF, "0") ,
  "1"    : boundFunction(FFOMpL, SELF, "1") ,
  "2"    : boundFunction(FFOMpL, SELF, "2") ,
  "3"    : boundFunction(FFOMpL, SELF, "3") ,
  "4"    : boundFunction(FFOMpL, SELF, "4") ,
  "5"    : boundFunction(FFOMpL, SELF, "5") ,
  "6"    : boundFunction(FFOMpL, SELF, "6") ,
  "7"    : boundFunction(FFOMpL, SELF, "7") ,
  "8"    : boundFunction(FFOMpL, SELF, "8") ,
  "9"    : boundFunction(FFOMpL, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFrgFD, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFOMpL(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVI8UI:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVI8UI + SELF.keyPressed + VVLIgE)
    txt = VVLIgE + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFyMZt(SELF, txt)
def FFrgFD(SELF, tableObj, colNum):
 FFyMZt(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     tableObj.moveToIndex(i)
     SELF.VVHCva()
     break
 except:
  pass
def FFKfA8(SELF, setMenuAction=True):
 if setMenuAction:
  global VV8CgR
  VV8CgR = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFIP5j():
 return ("  %s" % VV8CgR)
def FF3p62(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFfEyW(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFB7IS(color):
 return parseColor(color).argb()
def FFkgl3(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFrhNb(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFInme(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFPqb8(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVI8UI)
 else:
  return ""
def FFA58W(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VV8ben, word, VV8ben, VVI8UI)
 else : return "echo -e '%s\n--- %s\n%s';" % (VV8ben, word, VV8ben)
def FFUIPk(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVI8UI
def FFZAZA(color):
 if color: return "echo -e '%s' %s;" % (VV8ben, FFPqb8(VV8ben, VVApsx))
 else : return "echo -e '%s';" % VV8ben
def FFlZwH(title, color):
 title = "%s\n%s\n%s\n" % (VV8ben, title, VV8ben)
 return FFUIPk(title, color)
def FFgNUr(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFUtq8(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FF5Ov8(callBackFunction):
 tCons = CCZ10W()
 tCons.ePopen("echo", boundFunction(FF1vaC, callBackFunction))
def FF1vaC(callBackFunction, result, retval):
 callBackFunction()
def FFpgNe(SELF, fnc, title="Processing ...", clearMsg=True):
 FFyMZt(SELF, title)
 tCons = CCZ10W()
 tCons.ePopen("echo", boundFunction(FFU9DT, SELF, fnc, clearMsg))
def FFU9DT(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFyMZt(SELF)
def FFiQod(cmd):
 from subprocess import Popen, PIPE
 process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
 stdout, stderr = process.communicate()
 stdout = stdout.strip()
 stderr = stderr.strip()
 if stderr : return stderr
 else  : return stdout
def FFofdg(cmd):
 txt = FFiQod(cmd)
 if txt:
  txt.strip()
  if "\n" in txt:
   txt = txt.splitlines()
   return list(map(str.strip, txt))
  else:
   return [txt]
 else:
  return []
def FFLHG0(cmd):
 lines = FFofdg(cmd)
 if lines: return lines[0]
 else : return ""
def FFhU60(SELF, cmd):
 lines = FFofdg(cmd)
 VVbelk = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVbelk.append((key, val))
  elif line:
   VVbelk.append((line, ""))
 if VVbelk:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFed34(SELF, None, header=header, VVpuR3=VVbelk, VVEFlP=widths, VVQ020=22)
 else:
  FF5DF6(SELF, cmd)
def FF5DF6(    SELF, cmd, **kwargs): SELF.session.open(CCGImd, VVlqxJ=cmd, VV8HGF=True, VVfs8s=VVAqA7, **kwargs)
def FFtFVx(  SELF, cmd, **kwargs): SELF.session.open(CCGImd, VVlqxJ=cmd, **kwargs)
def FFX0Ip(   SELF, cmd, **kwargs): SELF.session.open(CCGImd, VVlqxJ=cmd, VVqQmI=True, VVjlzY=True, VVfs8s=VVAqA7, **kwargs)
def FFLPvq(  SELF, cmd, **kwargs): SELF.session.open(CCGImd, VVlqxJ=cmd, VVqQmI=True, VVjlzY=True, VVfs8s=VVwXIf, **kwargs)
def FF8mHD(  SELF, cmd, **kwargs): SELF.session.open(CCGImd, VVlqxJ=cmd, VVglDm=True , **kwargs)
def FFeJmo( SELF, cmd, **kwargs): SELF.session.open(CCGImd, VVlqxJ=cmd, VV3rwq=True   , **kwargs)
def FFw6rd( SELF, cmd, **kwargs): SELF.session.open(CCGImd, VVlqxJ=cmd, VV4mTt=True  , **kwargs)
def FFgzF5(cmd):
 return cmd + " > /dev/null 2>&1"
def FF8JsR():
 return " > /dev/null 2>&1"
def FFLUR1(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFRwKj(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "/bin"
    , "/boot"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/picon"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFeW8z():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFLHG0(cmd)
VVXwLJ     = 0
VV1KgA      = 1
VVLtMu   = 2
VVHwH1      = 3
VVpkv3      = 4
VVBHhc     = 5
VVn00Q     = 6
VVmVK0  = 7
VVxYAi = 8
VVPG5X  = 9
VVaP3C     = 10
VVc0hz  = 11
VVimgP  = 12
def FF9LLs(parmNum, grepTxt):
 if   parmNum == VVXwLJ  : param = ["update"   , "dpkg update" ]
 elif parmNum == VV1KgA   : param = ["list"   , "apt list" ]
 elif parmNum == VVLtMu: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFeW8z()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFVVjD(parmNum, package):
 if   parmNum == VVHwH1      : param = ["info"      ,"apt show"          ]
 elif parmNum == VVpkv3      : param = ["files"      ,"dpkg -L"          ]
 elif parmNum == VVBHhc     : param = ["download"     ,"apt-get download"        ]
 elif parmNum == VVn00Q     : param = ["install"     ,"apt-get install -y"       ]
 elif parmNum == VVmVK0  : param = ["install --force-reinstall" ,"apt-get install --reinstall -y"    ]
 elif parmNum == VVxYAi : param = ["install --force-downgrade" ,"apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVPG5X  : param = ["install --force-depends" ,"apt-get install --no-install-recommends -y" ]
 elif parmNum == VVaP3C     : param = ["remove"      ,"apt-get purge --auto-remove -y"    ]
 elif parmNum == VVc0hz  : param = ["remove --force-remove"  ,"dpkg --purge --force-all"      ]
 elif parmNum == VVimgP  : param = ["remove --force-depends"  ,"dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFeW8z()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFJwh1():
 result = FFLHG0("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFVVjD(VVn00Q , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFgzF5("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFgzF5("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFPqb8(failed1, VVApsx))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFPqb8(failed2, VVApsx))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFPqb8(failed3, VVP3bf))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFgyQn(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFVVjD(VVn00Q , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFgzF5("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFPqb8(failed1, VVApsx))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFPqb8(failed2, VVP3bf))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FF4L18(timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect(("1.1.1.1", 53))
  return True
 except:
  return False
def FFUy6Y(path, maxSize=-1):
 from io import open as ioOpen
 encodings = (None, "utf-8", "ISO8859-15", 'iso6937', "windows-1250", "windows-1252")
 txt = ""
 for enc in encodings:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFDyYj(path, keepends=False, maxSize=-1):
 lines = FFUy6Y(path, maxSize)
 return lines.splitlines(keepends)
def FFkCVq(SELF, path):
 title = FFIP5j()
 if fileExists(path):
  fSize = os.path.getsize(path)
  maxSize = 60000
  if (fSize > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFDyYj(path, maxSize=maxSize)
  if lines: FF6wpe(SELF, lines, title=title, VVfs8s=VVAqA7)
  else : FFDXjZ(SELF, path, title=title)
 else:
  FF4LjO(SELF, path, title)
def FFHaIY(SELF, path, title):
 if fileExists(path):
  txt = FFUy6Y(path)
  txt = txt.replace("#W#", VVI8UI)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVLIgE)
  txt = txt.replace("#C#", VVbHZ1)
  txt = txt.replace("#P#", VVEiu9)
  FF6wpe(SELF, txt, title=title)
 else:
  FF4LjO(SELF, path, title)
def FF3zwk(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFy5LY(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFV5FT(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFGYYB(parent)
 else    : return FFgkOw(parent)
def FFjNVY(path):
 try:
  return os.path.getsize(path)
 except:
  return 0
def FFGYYB(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFgkOw(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFBjDX():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVgvyL)
 paths.append(VVgvyL.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFy5LY(ba)
 for p in list:
  p = ba + p + VVgvyL
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVTGQU, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVgvyL, VVTGQU , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VV5riz, VV1ggQ = FFBjDX()
def FFIa5N():
 def VV2BAG(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 VVVpnB  = VV2BAG(CFG.backupPath, CCr029.VVcUvJ())
 VVCVeM  = VV2BAG(CFG.downloadedPackagesPath, t)
 VVEZXM = VV2BAG(CFG.exportedTablesPath, t)
 VVmVMg = VV2BAG(CFG.exportedPIconsPath, t)
 VVheZ2  = VV2BAG(CFG.packageOutputPath, t)
 global VVhuan
 VVhuan = FFGYYB(CFG.backupPath.getValue())
 if VVVpnB or VVheZ2 or VVCVeM or VVEZXM or VVmVMg:
  configfile.save()
 return VVVpnB, VVheZ2, VVCVeM, VVEZXM, VVmVMg
def FFJYfS(path):
 path = FFgkOw(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFmu4y(SELF, pathList, tarFileName, addTimeStamp=True):
 VVpuR3 = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVpuR3.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVpuR3.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVpuR3.append(path)
 if not VVpuR3:
  FF538m(SELF, "Files not found!")
 elif not pathExists(VVhuan):
  FF538m(SELF, "Path not found!\n\n%s" % VVhuan)
 else:
  VVOUw8 = FFGYYB(VVhuan)
  tarFileName = "%s%s" % (VVOUw8, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFAH5e())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVpuR3:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VV8ben
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFPqb8(tarFileName, VVbnJx))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFPqb8(failed, VVbnJx))
  cmd += "fi;"
  cmd +=  sep
  FFtFVx(SELF, cmd)
def FFEGhq(SELF, title, VVkojI):
 SELF.session.open(boundFunction(CC4on1, Title=title, VVkojI=VVkojI))
def FFGJQR(labelObj, VVkojI):
 if VVkojI and fileExists(VVkojI):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VV6BLS(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VV6BLS)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VVkojI)
   return True
  except:
   pass
 return False
def FFKjLn(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFL3a5(satNum)
  return satName
def FFL3a5(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFjjiy(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFKjLn(val)
  else  : sat = FFL3a5(val)
 return sat
def FFe0Vt(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFKjLn(num)
 except:
  pass
 return sat
def FFPApr(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFpNp5(SELF, isFromSession=None):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFzao7(info, iServiceInformation.sServiceref)
   prov = FFzao7(info, iServiceInformation.sProvider)
   state = str(FFzao7(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFYHCc(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFIv3N(refCode)
 return info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFzao7(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFMJnf(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFoZoJ(refCode):
 info = FFd692(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFUtnl(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFBSXf(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFd692(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VV7Rux = eServiceCenter.getInstance()
  if VV7Rux:
   info = VV7Rux.info(service)
 return info
def FFY1uw(SELF, refCode, VVda8V=True, checkParentalControl=False):
 if not refCode.endswith(":"):
  refCode += ":"
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  SELF.session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
  if VVda8V:
   FFJZPp(SELF)
 try:
  VVjcM6 = InfoBar.instance
  if VVjcM6:
   VVbmHV = VVjcM6.servicelist
   if VVbmHV:
    servRef = eServiceReference(refCode)
    VVbmHV.saveChannel(servRef)
 except:
  pass
def FFYHCc(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFIv3N(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFFkUX(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFbSHG(userBfile):
 txt = ""
 bFile = VVGnNm + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVGnNm + userBfile):
  fTxt = FFUy6Y(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFLHG0('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
 return
def FFFkUX(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FFERNa(url):
 if iQuote : return iQuote(url)
 else  : return url
def FFoNNB(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFhawA(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFQutI(txt):
 try:
  return FFoNNB(FFhawA(txt)) == txt
 except:
  return False
def FFJZPp(SELF, isFromSession=None):
 if isFromSession: session = SELF
 else   : session = SELF.session
 info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpNp5(SELF, isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCuzJP)
 else      : FFQu96(session, reopen=True)
def FFQu96(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFQu96, session), CC6K0D)
  except:
   try:
    FFok6P(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFPyKW(refCode):
 tp = CCoReX()
 if tp.VVMb9I(refCode) : return True
 else        : return False
def FFHhAj(refCode, isHide):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FF3PkJ():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FF3Zym():
 VVjcM6 = InfoBar.instance
 if VVjcM6:
  VVbmHV = VVjcM6.servicelist
  if VVbmHV:
   return VVbmHV.getBouquetList()
 return None
def FF33QU():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFjvet():
 path = FF33QU()
 if path:
  txt = FFUy6Y(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFZTo6(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VV7Rux = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VV7Rux.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FFyxvv():
 VVX3Kv = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVkhtC = list(VVX3Kv)
 return VVkhtC, VVX3Kv
def FFVJYE():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFfbem(session, VVfmGa):
 VVYW5r, VVeQSq, VVysJT, camCommand = FFbKLn()
 if VVeQSq:
  runLog = False
  if   VVfmGa == CCObh2.VVDZx2 : runLog = True
  elif VVfmGa == CCObh2.VVM5Cm : runLog = True
  elif not VVysJT          : FFok6P(session, message="SoftCam not started yet!")
  elif fileExists(VVysJT)        : runLog = True
  else             : FFok6P(session, message="File not found !\n\n%s" % VVysJT)
  if runLog:
   session.open(boundFunction(CCObh2, VVYW5r=VVYW5r, VVeQSq=VVeQSq, VVysJT=VVysJT, VVfmGa=VVfmGa))
 else:
  FFok6P(session, message="No active OSCam/NCam found !", title="Live Log")
def FFbKLn():
 VVYW5r = "/etc/tuxbox/config/"
 VVeQSq = None
 VVysJT  = None
 camCommand = FFLHG0("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVeQSq = "oscam"
 elif "ncam"  in camCommand : VVeQSq = "ncam"
 if VVeQSq:
  path = FFLHG0(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFGYYB(path)
  if pathExists(path):
   VVYW5r = path
  tFile = VVYW5r + VVeQSq + ".conf"
  tFile = FFLHG0("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVysJT = tFile
 return VVYW5r, VVeQSq, VVysJT, camCommand
def FFbrdA(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFDqAA():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFAH5e():
 return FFDqAA().replace(" ", "_").replace("-", "").replace(":", "")
def FFhCAD(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFOwIM(url, outFile, timeout=3):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCQps6.VVJZCV(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCQps6.VVOH83(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFgzF5("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFhtLX(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFnufR(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFTWi9():
 return int(FFiQod("cat /proc/meminfo | grep MemFree | awk '{print $2}'"))
def FFX7ii():
 global VVOgvu_TIME, VVIoC5
 VVIoC5  = int(FFTWi9())
 VVOgvu_TIME = iTime()
def FFCHiS():
 elapsed = iTime() - VVOgvu_TIME
 elapsed = "{:.6f}".format(elapsed).rstrip("0").rstrip(".")
 mem  = FFTWi9() - VVIoC5
 FFnGpC(">>>>>> Elapsed\t: {} seconds ... Memory\t: {} bytes".format(elapsed, mem))
def FFRg6s(SELF, message, title=""):
 SELF.session.open(boundFunction(CCntWy, title=title, message=message, VVx7ne=True))
def FF6wpe(SELF, message, title="", VVfs8s=VVAqA7, **kwargs):
 SELF.session.open(boundFunction(CCntWy, title=title, message=message, VVfs8s=VVfs8s, **kwargs))
def FF538m(SELF, message, title="")  : FFok6P(SELF.session, message, title)
def FF4LjO(SELF, path, title="") : FFok6P(SELF.session, "File not found !\n\n%s" % path, title)
def FFDXjZ(SELF, path, title="") : FFok6P(SELF.session, "File is empty !\n\n%s"  % path, title)
def FF9VHl(SELF, title="")  : FFok6P(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFok6P(session, message, title="") : session.open(boundFunction(CCWmhs, title=title, message=message))
def FF5iHn(SELF, VVuWtK, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVuWtK, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVuWtK, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVuWtK, boundFunction(CCMG11, title=title, message=message, VVxCeq=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FF538m(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFcSjz(SELF, callBack_Yes, VVRS1f, callBack_No=None, title="", VV5nHT=False):
 SELF.session.openWithCallback(boundFunction(FF5EHn, callBack_Yes, callBack_No)
        , boundFunction(CC6ucE, title=title, VVRS1f=VVRS1f, VVUSaH=True, VV5nHT=VV5nHT))
def FF5EHn(callBack_Yes, callBack_No, FFcSjzed):
 if FFcSjzed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFyMZt(SELF, message="", milliSeconds=0):
 try:
  SELF["myInfoBody"].setText(str(message))
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FF46FE(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFJbeE(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
myTimer = eTimer()
def FF46FE(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFgW0B, SELF))
 try:
  myTimer_conn = myTimer.timeout.connect(boundFunction(FFgW0B, SELF))
 except:
  myTimer.callback.append(boundFunction(FFgW0B, SELF))
 myTimer.start(milliSeconds, 1)
def FFgW0B(SELF):
 myTimer.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFed34(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCOyCZ, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCOyCZ, **kwargs))
  FFnMch(win)
  return win
 except:
  return None
def FFrC6O(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CC7gw9, **kwargs))
 FFnMch(win)
 return win
def FFEpG1(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   obj = SELF[name]
   SELF[name].instance.setBorderColor(parseColor("#000000"))
   SELF[name].instance.setBorderWidth(3)
   SELF[name].instance.setNoWrap(True)
  except:
   pass
def FFIxV6(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVUC67, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFhCiv(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFIxV6(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFS34v():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFmGf6(VVQ020):
 screenSize  = FFS34v()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVQ020)
 return bodyFontSize
def FFP3rc(VVQ020, extraSpace):
 font = gFont(VVUC67, VVQ020)
 VVU7nN = fontRenderClass.getInstance().getLineHeight(font) or (VVQ020 * 1.25)
 return int(VVU7nN + VVU7nN * extraSpace)
def FF4fdl(fontName):
 fList = None
 try:
  from enigma import getFontFaces
  fList = getFontFaces()
 except:
  try:
   from skin import getFontFaces
   fList = getFontFaces()
  except:
   pass
 if fList and fontName in fList : return fontName
 else       : return VVUC67
def FF87m3(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFS34v()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * VVXU1D)
 bodyFontStr  = 'font="%s;%d"' % (VVUC67, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFP3rc(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVUC67, titleFontSize, alignLeftCenter)
 if winType == VVseVH or winType == VVal8u:
  if winType == VVal8u : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVt2o7:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.2)
  b2Left1 = marginLeft
  b2Left2 = b2Left1 + timeW + marginLeft
  b2Left3 = width - marginLeft - timeW
  infW = b2Left3 - b2Left2 - marginLeft
  tmp += '<widget name="myPlayBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="myPlayBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" />'   % (marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyColor)
  tmp += '<widget name="myPlayBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a005555" />' % (marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="myPlayBarM"  position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="myPlayVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="#0a002233" %s %s'   % (bodyFontStr, alignCenter)
  tmp += '<widget name="myPlayPos"  position="%d,%d" size="%d,%d" %s />' % (b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlayMsg"  position="%d,%d" size="%d,%d" %s />' % (b2Left2, b2Top, infW , barH, param)
  tmp += '<widget name="myPlayDur"  position="%d,%d" size="%d,%d" %s />' % (b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep"   position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  names = ["Jmp", "Skp", "Mrk", "Blu", "Inf"]
  b3W  = int((width - marginLeft * 6.0) / 5.0)
  left = marginLeft
  for i in range(5):
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" foregroundColor="#0affffff" backgroundColor="#11222222" %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter)
   left += b3W + marginLeft
 elif winType == VVEV4h:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVfGZx:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVem0w:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVjRal:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVUC67, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVUC67, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVZpeg:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFRg6sH = int(bodyH * 0.5)
  inpTop = bodyTop + FFRg6sH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFRg6sH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVUC67, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVUC67, mapF, alignCenter)
 elif winType == VVs0oG:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVo7vq:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVUC67, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVv5BW:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVUC67, fontH, alignCenter)
 elif winType == VVOcdu:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVUC67, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVUC67, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVUC67, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 else:
  if   winType == VVrlPa : align = alignLeftCenter
  elif winType == VVCHm0 : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVuUrL:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VVkuU0:
   moreParams = ""
  else:
   fontStr = bodyFontStr
   if usefixedFont and winType == VVCHm0:
    fontStr = 'font="%s;%d"' % (FF4fdl("Fixed"), bodyFontSize)
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" %s %s ' % (bodyColor, fontStr, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVQ020 = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVUC67, VVQ020, alignCenter)
 if topRightBtns > 0:
  btnW = int(ratioW * 80)
  btnH = int(titleH * 0.7)
  btnTop = int(titleH * 0.15)
  btnLeft = width - (btnW + btnTop)
  btnFont = int(btnH * 0.6)
  tmp += '<widget name="keyMenu2F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
  tmp += '<widget name="keyMenu2"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VVUC67, btnFont, alignCenter)
  if topRightBtns > 1:
   btnLeft = btnLeft - btnW - 8
   tmp += '<widget name="keyMenu1F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="keyMenu1"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VVUC67, btnFont, alignCenter)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVZHzf = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVUC67, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVZHzf[i], VVUC67, barFont, alignCenter)
   left += btnW + gap
 if winType == VVCHm0:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVZHzf = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVZHzf[i], VVUC67, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF87m3(VVseVH, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.hiddenMenuPass = ""
  self.themsList  = []
  VVei97 = []
  if VV1wSt:
   VVei97.append(("-- MY TEST --"    , "myTest"   ))
  VVei97.append(("File Manager"      , "FileManager"  ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Services/Channels"    , "ChannelsTools" ))
  VVei97.append(("IPTV"        , "IptvTools"  ))
  VVei97.append(("PIcons"       , "PIconsTools"  ))
  VVei97.append(("SoftCam"       , "SoftCam"   ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Plugins"       , "PluginsTools" ))
  VVei97.append(("Terminal"       , "Terminal"  ))
  VVei97.append(("Backup & Restore"     , "BackupRestore" ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Date/Time"      , "Date_Time"  ))
  VVei97.append(("Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVei97)
  FFyw62(self, VVei97=VVei97)
  FF3p62(self["keyRed"] , "Exit")
  FF3p62(self["keyGreen"] , "Settings")
  FF3p62(self["keyYellow"], "Dev. Info.")
  FF3p62(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVZyQX       ,
   "yellow"  : self.VVfBvH       ,
   "blue"   : self.VVF6qk       ,
   "info"   : self.VVF6qk       ,
   "next"   : self.VVibc0       ,
   "0"    : boundFunction(self.VVigUl, 0) ,
   "1"    : boundFunction(self.VVhzQP, 1)   ,
   "2"    : boundFunction(self.VVhzQP, 2)   ,
   "3"    : boundFunction(self.VVhzQP, 3)   ,
   "4"    : boundFunction(self.VVhzQP, 4)   ,
   "5"    : boundFunction(self.VVhzQP, 5)   ,
   "6"    : boundFunction(self.VVhzQP, 6)   ,
   "7"    : boundFunction(self.VVhzQP, 7)   ,
   "8"    : boundFunction(self.VVhzQP, 8)   ,
   "9"    : boundFunction(self.VVhzQP, 9)
  })
  self.onShown.append(self.VViwS9)
  self.onClose.append(self.onExit)
  global VVU5KH, VVyEf8
  VVU5KH = VVyEf8 = False
 def VVnr3G(self):
  item = FFKfA8(self)
  self.VVhzQP(item)
 def VVhzQP(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVnz8b()
   elif item in ("FileManager"  , 1) : self.session.open(CCyaF0)
   elif item in ("ChannelsTools" , 2) : self.session.open(CC3RQY)
   elif item in ("IptvTools"  , 3) : self.session.open(CCQps6)
   elif item in ("PIconsTools"  , 4) : self.VVAyuq()
   elif item in ("SoftCam"   , 5) : self.session.open(CCihea)
   elif item in ("PluginsTools" , 6) : self.session.open(CCqhir)
   elif item in ("Terminal"  , 7) : self.session.open(CCAiz5)
   elif item in ("BackupRestore" , 8) : self.session.open(CCblzJ)
   elif item in ("Date_Time"  , 9) : self.session.open(CChNfr)
   elif item in ("CheckInternet" , 10) : self.session.open(CCDNoQ)
   else         : self.close()
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  FFgNUr(self["myMenu"])
  FFhCiv(self)
  FFEpG1(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVOn61)
  self["myTitle"].setText(title)
  VVVpnB, VVheZ2, VVCVeM, VVEZXM, VVmVMg = FFIa5N()
  self.VVjP4f()
  if VVVpnB or VVheZ2 or VVCVeM or VVEZXM or VVmVMg:
   VVWqEf = lambda path, subj: "%s:\n%s\n\n" % (subj, FFUIPk(path, VVP3bf)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVWqEf(VVVpnB   , "Backup/Restore Path"    )
   txt += VVWqEf(VVheZ2  , "Created Package Files (IPK/DEB)" )
   txt += VVWqEf(VVCVeM  , "Download Packages (from feeds)" )
   txt += VVWqEf(VVEZXM , "Exported Tables"     )
   txt += VVWqEf(VVmVMg , "Exported PIcons"     )
   txt += "\nYou can change paths from Settings.\n"
   FF6wpe(self, txt, title="Settings Paths")
  if (EASY_MODE or VVZKa6 or VV1wSt):
   FFrhNb(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFyMZt(self, "Welcome", 300)
  FF5Ov8(boundFunction(self.VVE3zB, title))
 def VVE3zB(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCr029.VVCCDS()
   if url:
    newWebVer = CCr029.VVmfkh(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFgzF5("rm /tmp/ajpanel*"))
 def VVigUl(self, digit):
  self.hiddenMenuPass += str(digit)
  if len(self.hiddenMenuPass) == 4:
   if self.hiddenMenuPass == "0" * 4:
    global VVU5KH
    VVU5KH = True
    FFrhNb(self["myTitle"], "#800080")
   else:
    self.hiddenMenuPass = "x"
 def VVibc0(self):
  self.hiddenMenuPass += ">"
  if self.hiddenMenuPass == ("0" * 4) + ">>":
   global VVyEf8
   VVyEf8 = True
   FFrhNb(self["myTitle"], "#dd5588")
 def VVAyuq(self):
  found = False
  pPath = CCsPD3.VVkefR()
  if pathExists(pPath):
   for fName, fType in CCsPD3.VVF2sv(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCsPD3)
  else:
   VVei97 = []
   VVei97.append(("PIcons Manager" , "CCsPD3" ))
   VVei97.append(VVhJ3E)
   VVei97.append(CCsPD3.VVOG9d())
   VVei97.append(VVhJ3E)
   VVei97 += CCsPD3.VVzp6S()
   FFrC6O(self, self.VV2kNr, VVei97=VVei97)
 def VV2kNr(self, item=None):
  if item:
   if   item == "CCsPD3"   : self.session.open(CCsPD3)
   elif item == "VVDppt"  : CCsPD3.VVDppt(self)
   elif item == "VVGdHu"  : CCsPD3.VVGdHu(self)
   elif item == "findPiconBrokenSymLinks" : CCsPD3.VVnVSr(self, True)
   elif item == "FindAllBrokenSymLinks" : CCsPD3.VVnVSr(self, False)
 def VVZyQX(self):
  self.session.open(CCr029)
 def VVfBvH(self):
  self.session.open(CCXkHz)
 def VVF6qk(self):
  changeLogFile = VV1ggQ + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FFDyYj(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFUIPk("\n%s\n%s\n%s" % (VV8ben, line, VV8ben), VVEiu9, VVI8UI)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FFUIPk(line, VVLIgE, VVI8UI)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FF6wpe(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVOn61), VVQ020=26)
 def VVjP4f(self):
  p = VVhuan + "ajpanel_colors"
  if fileExists(p):
   txt = FFUy6Y(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    try:
     if   txt == "main_title_fg" : FFkgl3(self["myTitle"], c)
     elif txt == "main_title_bg" : FFrhNb(self["myTitle"], c)
     elif txt == "main_body_fg" : FFkgl3(self["myMenu"], c)
     elif txt == "main_body_bg" :
      FFrhNb(self["myBody"], c)
      FFrhNb(self["myMenu"], c)
     elif txt == "main_cursor_fg" : self["myMenu"].instance.setForegroundColorSelected(parseColor(c))
     elif txt == "main_cursor_bg" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(c))
     elif txt == "main_bar_bg"  : FFrhNb(self["myBar"], c)
    except:
     pass
 def VVnz8b(self):
  opt = 11
  if   opt ==  0 : FFRg6s(self, "This is My Message.", "Testing")
  elif opt == 11:
   pass
class CCXkHz(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF87m3(VVseVH, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVei97 = []
  VVei97.append(("Settings File"        , "SettingsFile"   ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Box Info"          , "VV5ZjT"    ))
  VVei97.append(("Tuners Info"         , "VVdJts"   ))
  VVei97.append(("Python Version"        , "VVR9gP"   ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Screen Size"         , "ScreenSize"    ))
  VVei97.append(("Locale"          , "Locale"     ))
  VVei97.append(("Processor"         , "Processor"    ))
  VVei97.append(("Operating System"        , "OperatingSystem"   ))
  VVei97.append(("Drivers"          , "drivers"     ))
  VVei97.append(VVhJ3E)
  VVei97.append(("System Users"         , "SystemUsers"    ))
  VVei97.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVei97.append(("Uptime"          , "Uptime"     ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Host Name"         , "HostName"    ))
  VVei97.append(("MAC Address"         , "MACAddress"    ))
  VVei97.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVei97.append(("Network Status"        , "NetworkStatus"   ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Disk Usage"         , "VVQZ1B"    ))
  VVei97.append(("Mount Points"         , "MountPoints"    ))
  VVei97.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVei97.append(("USB Devices"         , "USB_Devices"    ))
  VVei97.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVei97.append(("Directory Size"        , "DirectorySize"   ))
  VVei97.append(("Memory"          , "Memory"     ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVei97.append(("Running Processes"       , "RunningProcesses"  ))
  VVei97.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFyw62(self, VVei97=VVei97, title="Device Information")
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  FFgNUr(self["myMenu"])
  FFhCiv(self)
 def VVnr3G(self):
  global VV8CgR
  VV8CgR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCxNVk)
   elif item == "VV5ZjT"    : self.VV5ZjT()
   elif item == "VVdJts"   : self.VVdJts()
   elif item == "VVR9gP"   : self.VVR9gP()
   elif item == "ScreenSize"    : FF6wpe(self, "Width\t: %s\nHeight\t: %s" % (FFS34v()[0], FFS34v()[1]))
   elif item == "Locale"     : self.VVMNha()
   elif item == "Processor"    : self.VViwAR()
   elif item == "OperatingSystem"   : FF5DF6(self, "uname -a"        )
   elif item == "drivers"     : self.VVV8Gi()
   elif item == "SystemUsers"    : FF5DF6(self, "id"          )
   elif item == "LoggedInUsers"   : FF5DF6(self, "who -a"         )
   elif item == "Uptime"     : FF5DF6(self, "uptime"         )
   elif item == "HostName"     : FF5DF6(self, "hostname"        )
   elif item == "MACAddress"    : self.VVSk08()
   elif item == "NetworkConfiguration"  : FF5DF6(self, "ifconfig %s %s" % (FFPqb8("HWaddr", VV5Hmu), FFPqb8("addr:", VVApsx)))
   elif item == "NetworkStatus"   : FF5DF6(self, "netstat -tulpn"       )
   elif item == "VVQZ1B"    : self.VVQZ1B()
   elif item == "MountPoints"    : FF5DF6(self, "mount %s" % (FFPqb8(" on ", VVApsx)))
   elif item == "FileSystemTable"   : FF5DF6(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FF5DF6(self, "lsusb"         )
   elif item == "listBlockDevices"   : FF5DF6(self, "blkid"         )
   elif item == "DirectorySize"   : FF5DF6(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VV5KHh="Reading size ...")
   elif item == "Memory"     : FF5DF6(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVtsOv()
   elif item == "RunningProcesses"   : FF5DF6(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FF5DF6(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVtASc()
   else         : self.close()
 def VVSk08(self):
  res = FFiQod("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FF6wpe(self, txt)
  else:
   FF5DF6(self, "ip link")
 def VV0zs6(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFofdg(cmd)
  return lines
 def VVyFqU(self, lines, headerRepl, widths, VVZOJU):
  VVbelk = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVbelk.append(parts)
  if VVbelk and len(header) == len(widths):
   VVbelk.sort(key=lambda x: x[0].lower())
   FFed34(self, None, header=header, VVpuR3=VVbelk, VVZOJU=VVZOJU, VVEFlP=widths, VVQ020=22, VV6WOa=True)
   return True
  else:
   return False
 def VVQZ1B(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VV0zs6(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVZOJU = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVyFqU(lines, headerRepl, widths, VVZOJU)
  if not allOK:
   lines = FFofdg(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFgkOw(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVbnJx:
     note = "\n%s" % FFUIPk("Green = Mounted Partitions", VVbnJx)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVApsx
     elif line.endswith(mountList) : color = VVbnJx
     else       : color = VVLIgE
     txt += FFUIPk(line, color) + "\n"
    FF6wpe(self, txt + note)
   else:
    FF538m(self, "Not data from system !")
 def VVtsOv(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VV0zs6(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVZOJU = (LEFT , CENTER, LEFT )
  allOK = self.VVyFqU(lines, headerRepl, widths, VVZOJU)
  if not allOK:
   FF5DF6(self, cmd)
 def VVMNha(self):
  from locale import getdefaultlocale
  loc = getdefaultlocale()
  FF6wpe(self, "Language\t: %s\nEncoding\t: %s" % (loc[0], loc[1]))
 def VVV8Gi(self):
  cmd = FF9LLs(VVLtMu, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FF5DF6(self, cmd)
  else : FF9VHl(self)
 def VViwAR(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FF5DF6(self, cmd)
 def VVtASc(self):
  cmd = FF9LLs(VV1KgA, "| grep secondstage")
  if cmd : FF5DF6(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FF9VHl(self)
 def VV5ZjT(self):
  c = VVbnJx
  VVpuR3 = []
  VVpuR3.append((FFUIPk("Box Type"  , c), FFUIPk(self.VVmMfW("boxtype").upper(), c)))
  VVpuR3.append((FFUIPk("Board Version", c), FFUIPk(self.VVmMfW("board_revision") , c)))
  VVpuR3.append((FFUIPk("Chipset"  , c), FFUIPk(self.VVmMfW("chipset")  , c)))
  VVpuR3.append((FFUIPk("S/N"   , c), FFUIPk(self.VVmMfW("sn")    , c)))
  VVpuR3.append((FFUIPk("Version"  , c), FFUIPk(self.VVmMfW("version")  , c)))
  VVTULF   = []
  VVr7Ph = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVr7Ph = SystemInfo[key]
     else:
      VVTULF.append((FFUIPk(str(key), VVbHZ1), FFUIPk(str(SystemInfo[key]), VVbHZ1)))
  except:
   pass
  if VVr7Ph:
   VVejei = self.VVtlIz(VVr7Ph)
   if VVejei:
    VVejei.sort(key=lambda x: x[0].lower())
    VVpuR3 += VVejei
  if VVTULF:
   VVTULF.sort(key=lambda x: x[0].lower())
   VVpuR3 += VVTULF
  if VVpuR3:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFed34(self, None, header=header, VVpuR3=VVpuR3, VVEFlP=widths, VVQ020=22, VV6WOa=True)
  else:
   FF6wpe(self, "Could not read info!")
 def VVmMfW(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFDyYj(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVtlIz(self, mbDict):
  try:
   mbList = list(mbDict)
   VVpuR3 = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVpuR3.append((FFUIPk(subject, VVApsx), FFUIPk(value, VVApsx)))
  except:
   pass
  return VVpuR3
 def VVdJts(self):
  txt = self.VVkLZE("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVkLZE("/proc/bus/nim_sockets")
  if not txt: txt = self.VV9ht3()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FF6wpe(self, txt)
 def VV9ht3(self):
  txt = ""
  VVWqEf = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVWqEf("Slot Name" , slot.getSlotName())
     txt += FFUIPk(slotName, VVApsx)
     txt += VVWqEf("Description"  , slot.getFullDescription())
     txt += VVWqEf("Frontend ID"  , slot.frontend_id)
     txt += VVWqEf("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVkLZE(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFDyYj(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFUIPk(line, VVApsx)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVR9gP(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FF6wpe(self, txt)
class CCxNVk(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF87m3(VVseVH, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVei97 = []
  VVei97.append(("Settings (All)"   , "Settings_All"   ))
  VVei97.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVei97.append(("Settings (FHDG-17)"  , "Settings_FHDG_17"  ))
  VVei97.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVei97.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVei97.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVei97.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVei97.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFyw62(self, VVei97=VVei97)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  FFgNUr(self["myMenu"])
  FFhCiv(self)
 def VVnr3G(self):
  global VV8CgR
  VV8CgR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FF5DF6(self, cmd                )
   elif item == "Settings_HotKeys"   : FF5DF6(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FF5DF6(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FF5DF6(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FF5DF6(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FF5DF6(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FF5DF6(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FF5DF6(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCihea(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF87m3(VVseVH, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVYW5r, VVeQSq, VVysJT, camCommand = FFbKLn()
  self.VVeQSq = VVeQSq
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVei97 = []
  VVei97.append(("OSCam Files"        , "OSCamFiles"  ))
  VVei97.append(("NCam Files"        , "NCamFiles"  ))
  VVei97.append(("CCcam Files"        , "CCcamFiles"  ))
  VVei97.append(VVhJ3E)
  VVei97.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVei97.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVei97.append(VVhJ3E)
  if VVeQSq:
   if   "oscam" in VVeQSq : camName = "OSCam"
   elif "ncam"  in VVeQSq : camName = "NCam"
   VVei97.append((camName + " Info."      , "camInfo"   ))
   VVei97.append((camName + " Live Status"    , "camLiveStatus" ))
   VVei97.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVei97.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVei97.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFyw62(self, VVei97=VVei97)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  FFgNUr(self["myMenu"])
  FFhCiv(self)
 def VVnr3G(self):
  global VV8CgR
  VV8CgR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCmQIY, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCmQIY, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCmQIY, "cccam"))
   elif item == "OSCamReaders"  : self.VVuSjJ("os")
   elif item == "NSCamReaders"  : self.VVuSjJ("n")
   elif item == "camInfo"   : FFhU60(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFfbem(self.session, CCObh2.VVDZx2)
   elif item == "camLiveReaders" : FFfbem(self.session, CCObh2.VVM5Cm)
   elif item == "camLiveLog"  : FFfbem(self.session, CCObh2.VVdMa1)
   else       : self.close()
 def VVuSjJ(self, camPrefix):
  VVbelk = self.VVNMyL(camPrefix)
  if VVbelk:
   VVbelk.sort(key=lambda x: int(x[0]))
   if self.VVeQSq and self.VVeQSq.startswith(camPrefix):
    VVY4BM = ("Toggle State", self.VVTkNZ, [camPrefix], "Changing State ...")
   else:
    VVY4BM = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVZOJU  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFed34(self, None, header=header, VVpuR3=VVbelk, VVZOJU=VVZOJU, VVEFlP=widths, VVQ020=22, VVY4BM=VVY4BM, VVwC3K=True)
 def VVNMyL(self, camPrefix):
  readersFile = self.VVYW5r + camPrefix + "cam.server"
  VVbelk = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFDyYj(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVbelk.append((str(len(VVbelk) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVbelk:
    FF538m(self, "No readers found !")
  else:
   FF4LjO(self, readersFile)
  return VVbelk
 def VVTkNZ(self, VVyGLE, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVYW5r, camPrefix)
  readerState  = VVyGLE.VVGmDB(1)
  readerLabel  = VVyGLE.VVGmDB(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCihea.VVG8Pf(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVyGLE.VVDtzl()
    FF538m(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVbelk = self.VVNMyL(camPrefix)
   if VVbelk:
    VVyGLE.VVwB4B(VVbelk)
 @staticmethod
 def VVG8Pf(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFDyYj(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FF538m(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FF538m(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FF4LjO(SELF, confFile)
   return None
  if not iRequest:
   FF538m(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FF538m(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FF538m(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCmQIY(Screen):
 def __init__(self, VVhFCI, session, args=0):
  self.skin, self.skinParam = FF87m3(VVseVH, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVYW5r, VVeQSq, VVysJT, camCommand = FFbKLn()
  if   VVhFCI == "ncam" : self.prefix = "n"
  elif VVhFCI == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVei97 = []
  if self.prefix == "":
   VVei97.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVei97.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVei97.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVei97.append(("constant.cw"         , "x_constant_cw" ))
   VVei97.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVei97.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVei97.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVei97.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVei97.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVei97.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVei97.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVei97.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVei97.append(VVhJ3E)
   VVei97.append(("SoftCam.Key"         , "x_SoftCam_Key" ))
   VVei97.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVei97.append(VVhJ3E)
   VVei97.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVei97.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVei97.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFyw62(self, VVei97=VVei97)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  FFgNUr(self["myMenu"])
  FFhCiv(self)
 def VVnr3G(self):
  global VV8CgR
  VV8CgR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFkCVq(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFkCVq(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFkCVq(self, self.VVYW5r + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFkCVq(self, self.VVYW5r + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVUUN1("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVUUN1("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVUUN1("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVUUN1("cam.provid"        )
   elif item == "x_cam_server"  : self.VVUUN1("cam.server"        )
   elif item == "x_cam_services" : self.VVUUN1("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVUUN1("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVUUN1("cam.user"        )
   elif item == "x_VV8ben"   : pass
   elif item == "x_SoftCam_Key" : FFkCVq(self, self.VVYW5r + "SoftCam.Key"   )
   elif item == "x_CCcam_cfg"  : FFkCVq(self, self.VVYW5r + "CCcam.cfg"    )
   elif item == "x_VV8ben"   : pass
   elif item == "x_cam_log"  : FFkCVq(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFkCVq(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFkCVq(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVUUN1(self, fileName):
  FFkCVq(self, self.VVYW5r + self.prefix + fileName)
class CCObh2(Screen):
 VVDZx2  = 0
 VVM5Cm = 1
 VVdMa1 = 2
 def __init__(self, session, VVYW5r="", VVeQSq="", VVysJT="", VVfmGa=VVDZx2):
  self.skin, self.skinParam = FF87m3(VVCHm0, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVysJT   = VVysJT
  self.VVfmGa  = VVfmGa
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVYW5r + VVeQSq + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVeQSq : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVYW5r, self.camPrefix)
  if self.VVfmGa == self.VVDZx2:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVfmGa == self.VVM5Cm:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFyw62(self, self.Title, addScrollLabel=True)
  FF3p62(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVtuIL
  self.onShown.append(self.VViwS9)
  self.onClose.append(self.onExit)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  self["myLabel"].VVEY9M(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFEpG1(self)
  self.VVtuIL()
 def onExit(self):
  self.timer.stop()
 def VVZtcj(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVTala)
  except:
   self.timer.callback.append(self.VVTala)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFyMZt(self, "Started", 1000)
 def VVQarx(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVTala)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFyMZt(self, "Stopped", 1000)
 def VVtuIL(self):
  if self.timerRunning:
   self.VVQarx()
  else:
   self.VVZtcj()
   if self.VVfmGa == self.VVDZx2 or self.VVfmGa == self.VVM5Cm:
    if self.VVfmGa == self.VVDZx2 : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCihea.VVG8Pf(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FF5Ov8(self.VVqv47)
    else:
     self.close()
   else:
    self.VV4okT()
 def VVTala(self):
  if self.timerRunning:
   if   self.VVfmGa == self.VVDZx2 : self.VVhId6()
   elif self.VVfmGa == self.VVM5Cm : self.VVhId6()
   else            : self.VV4okT()
 def VV4okT(self):
  if fileExists(self.VVysJT):
   fTime = FFbrdA(os.path.getmtime(self.VVysJT))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVvNTL(), VVfs8s=VVwXIf)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVysJT)
 def VVqv47(self):
  self.VVhId6()
 def VVhId6(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFUIPk("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVEiu9))
   self.camWebIfErrorFound = True
   self.VVQarx()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVfmGa == self.VVDZx2 : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFUIPk("Error while parsing data elements !\n\nError = %s" % str(e), VVP3bf)
   self.camWebIfErrorFound = True
   self.VVQarx()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVBc5T(root)
  self["myLabel"].setText(txt, VVfs8s=VVwXIf)
  self["myBar"].setText("Last Update : %s" % FFDqAA())
 def VVBc5T(self, rootElement):
  def VVWqEf(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVfmGa == self.VVDZx2:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFUIPk(status, VVbnJx)
    else          : status = FFUIPk(status, VVP3bf)
    txt += VV8ben + "\n"
    txt += VVWqEf("Name"  , name)
    txt += VVWqEf("Description" , desc)
    txt += VVWqEf("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVWqEf("Protocol" , protocol)
    txt += VVWqEf("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFUIPk("Yes", VVbnJx)
    else    : enabTxt = FFUIPk("No", VVP3bf)
    txt += VV8ben + "\n"
    txt += VVWqEf("Label"  , label)
    txt += VVWqEf("Protocol" , protocol)
    txt += VVWqEf("Enabled" , enabTxt)
  return txt
 def VVvNTL(self):
  wordsDict = self.VVJIWK()
  color = [ VVApsx, VV5Hmu, VVbnJx, VVP3bf, VVbHZ1, VVju96]
  lines = FFofdg("tail -n %d %s" % (100, self.VVysJT))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVEiu9 + line[:19] + VVLIgE + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVI8UI + line[ndx + 3:] + VVLIgE
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVApsx + line[ndx + 8 : ndx1 + 4] + VVLIgE + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVLIgE)
   elif line.startswith("----") or ">>" in line:
    line = FFUIPk(line, VVApsx)
   txt += line + "\n"
  return txt
 def VVJIWK(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFDyYj(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCblzJ(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF87m3(VVseVH, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVei97 = []
  VVei97.append(("Backup Channels"        , "VVTPxM"   ))
  VVei97.append(("Restore Channels"        , "Restore_Channels"  ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Backup SoftCAM Files"       , "VVAcOr" ))
  VVei97.append(("Restore SoftCAM Files"      , "Restore_SoftCAM_Files" ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Backup Tuner Settings"      , "Backup_TunerDiSEqC"  ))
  VVei97.append(("Restore Tuner Settings"      , "Restore_TunerDiSEqC"  ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Backup HotKeys & FHDG17 Settings"    , "Backup_Hotkey_FHDG17" ))
  VVei97.append(("Restore HotKeys & FHDG17 Settings"   , "Restore_Hotkey_FHDG17" ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Backup Network Settings"      , "VVWvMU"   ))
  VVei97.append(("Restore Network Settings"      , "Restore_Network"   ))
  if VVyEf8:
   VVei97.append(VVhJ3E)
   VVei97.append((VVEiu9 + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME , "VVGdcZ"   ))
   VVei97.append((VVbnJx + "2- Create %s for IPK"   % PLUGIN_NAME , "createMyIpk"   ))
   VVei97.append((VVbnJx + "3- Create %s for DEB"   % PLUGIN_NAME , "createMyDeb"   ))
   VVei97.append((VVbHZ1 + "Create %s TAR (Absolute Path)" % PLUGIN_NAME , "createMyTar"   ))
   VVei97.append((VVbHZ1 + "Decode %s Crash Report"   % PLUGIN_NAME , "VVu37o" ))
  FFyw62(self, VVei97=VVei97)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  FFgNUr(self["myMenu"])
  FFhCiv(self)
 def VVnr3G(self):
  global VV8CgR
  VV8CgR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVTPxM"    : self.VVTPxM()
   elif item == "Restore_Channels"    : self.VVeHtY("channels_backup*.tar.gz", self.VVa8i5)
   elif item == "VVAcOr"   : self.VVAcOr()
   elif item == "Restore_SoftCAM_Files"  : self.VVeHtY("softcam_backup*.tar.gz", self.VV3BIb)
   elif item == "Backup_TunerDiSEqC"   : self.VVkOR2("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVeHtY("tuner_backup*.backup", boundFunction(self.VVU36e, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVkOR2("hotkey_fhdg17_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVeHtY("hotkey_fhdg17_backup*.backup", boundFunction(self.VVU36e, "misc"))
   elif item == "VVWvMU"    : self.VVWvMU()
   elif item == "Restore_Network"    : self.VVeHtY("network_backup*.tar.gz", self.VVveU5)
   elif item == "VVGdcZ"     : FFcSjz(self, boundFunction(FFpgNe, self, boundFunction(CCblzJ.VVGdcZ, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVjNEx(False)
   elif item == "createMyDeb"     : self.VVjNEx(True)
   elif item == "createMyTar"     : self.VV3MJQ()
   elif item == "VVu37o"   : self.VVu37o()
 @staticmethod
 def VVGdcZ(SELF):
  OBF_Path = VV5riz + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VV5riz, VVOn61, VV0rqe)
   if err : FF538m(SELF, err)
   else : FF6wpe(SELF, txt)
  else:
   FF4LjO(SELF, OBF_Path)
 def VVjNEx(self, VVW9b2):
  OBF_Path = VV5riz + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FF538m(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VV5riz)
  os.system("mv -f %s %s" % (VV5riz + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VV5riz + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VV5riz + "plugin.py"))
  self.session.openWithCallback(self.VVjNEx1, boundFunction(CCbs97, path=VV5riz, VVW9b2=VVW9b2))
 def VVjNEx1(self):
  os.system("mv -f %s %s" % (VV5riz + "OBF/main.py"  , VV5riz))
  os.system("mv -f %s %s" % (VV5riz + "OBF/plugin.py" , VV5riz))
 def VVu37o(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FF538m(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FF538m(self, "No log files in:\n\n%s" % path)
   return
  VVpuR3 = []
  for f in files:
   f = os.path.basename(f)
   VVpuR3.append((f, f))
  FFrC6O(self, boundFunction(self.VVyzzC, path), VVei97=VVpuR3)
 def VVyzzC(self, path, item=None):
  if item:
   codF = ""
   cFiles = iGlob("%s*.list" % path)
   if cFiles:
    codF = cFiles[0]
    if fileExists(codF):
     logF = path + item
     if fileExists(logF):
      lst  = []
      lines = FFDyYj(codF)
      for line in lines:
       line = line.split(":")[1]
       parts = line.split("->")
       lst.append((parts[1].strip(), parts[0].strip()))
      if lst:
       logTxt = FFUy6Y(logF)
       for item in lst:
        logTxt = logTxt.replace(item[0], item[1])
       resF = logF + ".decoded.log"
       with open(resF, "w") as f:
        f.write(logTxt)
       FFRg6s(self, "Output File:\n\n%s" % resF)
      else: FF538m(self, "No codes in : %s" % codF)
     else: FF4LjO(self, logF)
   else: FF4LjO(self, codF)
 def VV3MJQ(self):
  VVpuR3 = []
  VVpuR3.append("%s%s" % (VV5riz, "*.py"))
  VVpuR3.append("%s%s" % (VV5riz, "*.png"))
  VVpuR3.append("%s%s" % (VV5riz, "*.xml"))
  VVpuR3.append("%s"  % (VV1ggQ))
  FFmu4y(self, VVpuR3, "%s_%s" % (PLUGIN_NAME, VVOn61), addTimeStamp=False)
 def VVTPxM(self):
  path1 = VVGnNm
  path2 = "/etc/tuxbox/"
  VVpuR3 = []
  VVpuR3.append("%s%s" % (path1, "*.tv"))
  VVpuR3.append("%s%s" % (path1, "*.radio"))
  VVpuR3.append("%s%s" % (path1, "*list"))
  VVpuR3.append("%s%s" % (path1, "lamedb*"))
  VVpuR3.append("%s%s" % (path2, "*.xml"))
  FFmu4y(self, VVpuR3, "channels_backup", addTimeStamp=True)
 def VVAcOr(self):
  VVpuR3 = []
  VVpuR3.append("/etc/tuxbox/config/")
  VVpuR3.append("/usr/keys/")
  VVpuR3.append("/usr/scam/")
  VVpuR3.append("/etc/CCcam.cfg")
  FFmu4y(self, VVpuR3, "softcam_backup", addTimeStamp=True)
 def VVWvMU(self):
  VVpuR3 = []
  VVpuR3.append("/etc/hostname")
  VVpuR3.append("/etc/default_gw")
  VVpuR3.append("/etc/resolv.conf")
  VVpuR3.append("/etc/wpa_supplicant*.conf")
  VVpuR3.append("/etc/network/interfaces")
  VVpuR3.append("/etc/enigma2/nameserversdns.conf")
  FFmu4y(self, VVpuR3, "network_backup", addTimeStamp=True)
 def VVa8i5(self, fileName):
  if fileName:
   FFcSjz(self, boundFunction(self.VVKR3K, fileName), "Overwrite current channels ?")
 def VVKR3K(self, fileName):
  path = "%s%s" % (VVhuan, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CC3RQY.VVZ74d()
   lamedb5File, diabled5File = CC3RQY.VVeyKf()
   cmd = ""
   cmd += FFgzF5("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFgzF5("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FF3PkJ()
   if res == 0 : FFRg6s(self, "Channels Restored.")
   else  : FF538m(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FF4LjO(self, path)
 def VV3BIb(self, fileName):
  if fileName:
   FFcSjz(self, boundFunction(self.VVbVrp, fileName), "Overwrite SoftCAM files ?")
 def VVbVrp(self, fileName):
  fileName = "%s%s" % (VVhuan, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VV8ben
   note = "You may need to restart your SoftCAM."
   FFLPvq(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFPqb8(note, VVApsx), sep))
  else:
   FF4LjO(self, fileName)
 def VVveU5(self, fileName):
  if fileName:
   FFcSjz(self, boundFunction(self.VVuNYi, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVuNYi(self, fileName):
  fileName = "%s%s" % (VVhuan, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FF8mHD(self,  cmd)
  else:
   FF4LjO(self, fileName)
 def VVeHtY(self, pattern, callBackFunction, isTuner=False):
  title = FFIP5j()
  if pathExists(VVhuan):
   myFiles = iGlob("%s%s" % (VVhuan, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVpuR3 = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVpuR3.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVdFS8 = ("Sat. List", self.VV4cS2)
    else  : VVdFS8 = None
    FFrC6O(self, callBackFunction, title=title, VVei97=VVpuR3, VVdFS8=VVdFS8)
   else:
    FF538m(self, "No files found in:\n\n%s" % VVhuan, title)
  else:
   FF538m(self, "Path not found:\n\n%s" % VVhuan, title)
 def VVkOR2(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCZ10W()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVnUdG, filePrefix))
 def VVnUdG(self, filePrefix, result, retval):
  title = FFIP5j()
  if pathExists(VVhuan):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FF538m(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVhuan, filePrefix, FFAH5e())
    try:
     VVpuR3 = str(result.strip()).split()
     if VVpuR3:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVpuR3:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VV8ben, FFUIPk(fName, VVApsx), VV8ben)
       FF6wpe(self, txt, title=title, VVfs8s=VVwXIf)
      else:
       FF538m(self, "File creation failed!", title)
     else:
      FF538m(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFgzF5("rm %s" % fName))
     FF538m(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFgzF5("rm %s" % fName))
     FF538m(self, "Error while writing file.")
  else:
   FF538m(self, "Path not found:\n\n%s" % VVhuan, title)
 def VVU36e(self, mode, path):
  if path:
   path = "%s%s" % (VVhuan, path)
   if fileExists(path):
    lines = FFDyYj(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys/FHDG17"
     FFcSjz(self, boundFunction(self.VVmde3, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFDXjZ(self, path, title=FFIP5j())
   else:
    FF4LjO(self, path)
 def VVmde3(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVlqxJ = []
  VVlqxJ.append("echo -e 'Reading current settings ...'")
  VVlqxJ.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVlqxJ.append("echo -e 'Preparing new settings ...'")
  VVlqxJ.append(settingsLines)
  VVlqxJ.append("echo -e 'Applying new settings ...'")
  VVlqxJ.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFw6rd(self, VVlqxJ)
 def VV4cS2(self, VVQlLPObj, path):
  if not path:
   return
  path = VVhuan + path
  if not fileExists(path):
   FF4LjO(self, path)
   return
  txt = FFUy6Y(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVpuR3  = []
   for item in satList:
    VVpuR3.append("%s\t%s" % (item[0], FFKjLn(item[1])))
   FF6wpe(self, VVpuR3, title="  Satellites List")
  else:
   FF538m(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCqhir(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF87m3(VVseVH, 850, 700, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVei97 = []
  VVei97.append(("Plugins Browser List"       , "VVn7Fe"   ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVei97.append(("Remove Packages (show all)"     , "VViUgMsAll"   ))
  VVei97.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Update List of Available Packages"   , "VVaJpC"   ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Packaging Tool"        , "VVJ6rQ"    ))
  VVei97.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFyw62(self, VVei97=VVei97)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  FFgNUr(self["myMenu"])
  FFhCiv(self)
 def VVnr3G(self):
  global VV8CgR
  VV8CgR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVn7Fe"   : self.VVn7Fe()
   elif item == "pluginsDirList"    : self.VVKCjE()
   elif item == "downloadInstallPackages"  : FFpgNe(self, boundFunction(self.VVRAa9, 0, ""))
   elif item == "VViUgMsAll"   : FFpgNe(self, boundFunction(self.VVRAa9, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFpgNe(self, boundFunction(self.VVRAa9, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVaJpC"   : self.VVaJpC()
   elif item == "VVJ6rQ"    : self.VVJ6rQ()
   elif item == "packagesFeeds"    : self.VV9Ttw()
   else          : self.close()
 def VVKCjE(self):
  extDirs  = FFy5LY(VVgvyL)
  sysDirs  = FFy5LY(VVkvs5)
  VVpuR3  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVpuR3.append((item, VVgvyL + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVpuR3.append((item, VVkvs5 + item))
  if VVpuR3:
   VVpuR3 = sorted(VVpuR3, key=lambda x: x[0].lower())
   VVcWvO = ("Package Info.", self.VVFuUu, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFed34(self, None, header=header, VVpuR3=VVpuR3, VVEFlP=widths, VVQ020=28, VVcWvO=VVcWvO)
  else:
   FF538m(self, "Nothing found!")
 def VVFuUu(self, VVyGLE, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVgvyL) : loc = "extensions"
  elif path.startswith(VVkvs5) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVWaVq(package)
  else:
   FF538m(self, "No info!")
 def VV9Ttw(self):
  pkg = FFeW8z()
  if pkg : FF5DF6(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FF9VHl(self)
 def VVn7Fe(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVWqEf(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VV8ben + "\n"
    txt += VVWqEf("Number"   , str(c))
    txt += VVWqEf("Name"   , FFUIPk(str(p.name), VVApsx))
    txt += VVWqEf("Path"  , p.path  )
    txt += VVWqEf("Description" , p.description )
    txt += VVWqEf("Icon"  , p.iconstr  )
    txt += VVWqEf("Wakeup Fnc" , p.wakeupfnc )
    txt += VVWqEf("NeedsRestart", p.needsRestart)
    txt += VVWqEf("Internal" , p.internal )
    txt += VVWqEf("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FF6wpe(self, txt)
 def VVaJpC(self):
  cmd = FF9LLs(VVXwLJ, "")
  if cmd : FF8mHD(self, cmd, checkNetAccess=True)
  else : FF9VHl(self)
 def VVJ6rQ(self):
  pkg = FFeW8z()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFRg6s(self, txt)
 def VVRAa9(self, mode, grep, VVyGLE=None, title=""):
  if   mode == 0: cmd = FF9LLs(VV1KgA    , grep)
  elif mode == 1: cmd = FF9LLs(VVLtMu , grep)
  elif mode == 2: cmd = FF9LLs(VVLtMu , grep)
  if not cmd:
   FF9VHl(self)
   return
  VVbelk = FFofdg(cmd)
  if not VVbelk:
   if VVyGLE: VVyGLE.VVDtzl()
   FF538m(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVpuR3  = []
  for item in VVbelk:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVpuR3.append((name, package, version))
  if mode > 0:
   extensions = FFofdg("ls %s -l | grep '^d' | awk '{print $9}'" % VVgvyL)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVpuR3:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVpuR3.append((name, VVgvyL + item, "-"))
   systemPlugins = FFofdg("ls %s -l | grep '^d' | awk '{print $9}'" % VVkvs5)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVpuR3:
      if item.lower() == row[0].lower():
       break
     else:
      VVpuR3.append((item, VVkvs5 + item, "-"))
  if not VVpuR3:
   FF538m(self, "No packages found!")
   return
  if VVyGLE:
   VVpuR3.sort(key=lambda x: x[0].lower())
   VVyGLE.VVwB4B(VVpuR3, title)
  else:
   widths = (20, 50, 30)
   VVY4BM = None
   VVKois = None
   if mode == 0:
    VV1DDw = ("Install" , self.VVdAwv   , [])
    VVY4BM = ("Download" , self.VVJVWV   , [])
    VVKois = ("Filter"  , self.VVDIgY , [])
   elif mode == 1:
    VV1DDw = ("Uninstall", self.VViUgM, [])
   elif mode == 2:
    VV1DDw = ("Uninstall", self.VViUgM, [])
    widths= (18, 57, 25)
   VVpuR3 = sorted(VVpuR3, key=lambda x: x[0].lower())
   VVcWvO = ("Package Info.", self.VV1Wjc, [])
   header   = ("Name" ,"Package" , "Version" )
   FFed34(self, None, header=header, VVpuR3=VVpuR3, VVEFlP=widths, VVQ020=24, VV1DDw=VV1DDw, VVY4BM=VVY4BM, VVcWvO=VVcWvO, VVKois=VVKois, VVsfQF=self.lastSelectedRow
     , VVCABW="#22110011", VVG1bZ="#22191111", VVZHzf="#22191111", VVjMdQ="#00003030", VVonRc="#00333333")
 def VV1Wjc(self, VVyGLE, title, txt, colList):
  package = colList[1]
  self.VVWaVq(package)
 def VVDIgY(self, VVyGLE, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVei97 = []
  VVei97.append(("All Packages", "all"))
  VVei97.append(VVhJ3E)
  VVei97.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVei97.append(VVhJ3E)
  for word in words:
   VVei97.append((word, word))
  FFrC6O(self, boundFunction(self.VVPflD, VVyGLE), VVei97=VVei97, title="Select Filter")
 def VVPflD(self, VVyGLE, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFpgNe(VVyGLE, boundFunction(self.VVRAa9, 0, grep, VVyGLE, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VViUgM(self, VVyGLE, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVgvyL, VVkvs5)):
   FFcSjz(self, boundFunction(self.VVEuJ7, VVyGLE, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVei97 = []
   VVei97.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVei97.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVei97.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFrC6O(self, boundFunction(self.VVYKz8, VVyGLE, package), VVei97=VVei97)
 def VVEuJ7(self, VVyGLE, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVmw9Y)
  FF8mHD(self, cmd, VVQEZn=boundFunction(self.VV4s6v, VVyGLE))
 def VVYKz8(self, VVyGLE, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVaP3C
   elif item == "remove_ForceRemove"  : cmdOpt = VVc0hz
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVimgP
   FFcSjz(self, boundFunction(self.VVAgmi, VVyGLE, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVAgmi(self, VVyGLE, package, cmdOpt):
  self.lastSelectedRow = VVyGLE.VVKtZk()
  cmd = FFVVjD(cmdOpt, package)
  if cmd : FF8mHD(self, cmd, VVQEZn=boundFunction(self.VV4s6v, VVyGLE))
  else : FF9VHl(self)
 def VV4s6v(self, VVyGLE):
  VVyGLE.cancel()
  FFVJYE()
 def VVdAwv(self, VVyGLE, title, txt, colList):
  package  = colList[1]
  VVei97 = []
  VVei97.append(("Install Package"         , "install_CheckVersion" ))
  VVei97.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVei97.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVei97.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFrC6O(self, boundFunction(self.VVeste, package), VVei97=VVei97)
 def VVeste(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVn00Q
   elif item == "install_ForceReinstall" : cmdOpt = VVmVK0
   elif item == "install_ForceDowngrade" : cmdOpt = VVxYAi
   elif item == "install_IgnoreDepends" : cmdOpt = VVPG5X
   FFcSjz(self, boundFunction(self.VVChzN, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVChzN(self, package, cmdOpt):
  cmd = FFVVjD(cmdOpt, package)
  if cmd : FF8mHD(self, cmd, VVQEZn=FFVJYE, checkNetAccess=True, enableSaveRes=True)
  else : FF9VHl(self)
 def VVJVWV(self, VVyGLE, title, txt, colList):
  package  = colList[1]
  FFcSjz(self, boundFunction(self.VVetFX, package), "Download Package ?\n\n%s" % package)
 def VVetFX(self, package):
  if FF4L18():
   cmd = FFVVjD(VVBHhc, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFPqb8(success, VVbnJx))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFPqb8(fail, VVP3bf))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FF8mHD(self, cmd, VVnYJv=[VVP3bf, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FF9VHl(self)
  else:
   FF538m(self, "No internet connection !")
 def VVWaVq(self, package):
  infoCmd  = FFVVjD(VVHwH1, package)
  filesCmd = FFVVjD(VVpkv3, package)
  listInstCmd = FF9LLs(VVLtMu, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFZAZA(VVApsx)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFPqb8(notInst, VVEiu9))
   cmd += "else "
   cmd +=   FFA58W("System Info", VVApsx)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFA58W("Related Files", VVApsx)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFX0Ip(self, cmd)
  else:
   FF9VHl(self)
class CC3RQY(Screen):
 VVnNKd  = 0
 VVKG55 = 1
 VVeje5  = 2
 VV0XDC  = 3
 VV0jLf = 4
 VVLmlD = 5
 VVo5KG = 6
 def __init__(self, session):
  self.skin, self.skinParam = FF87m3(VVseVH, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVe2Js = None
  self.lastfilterUsed  = None
  VVei97 = self.VVBH33()
  FFyw62(self, VVei97=VVei97, title="Services/Channels")
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self["myMenu"].setList(self.VVBH33())
  FFgNUr(self["myMenu"])
  FFhCiv(self)
 def VVBH33(self):
  VVei97 = []
  VVei97.append(("Current Service (Signal Monitor)"   , "currentServiceSignal"    ))
  VVei97.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Services (Reference)"      , "lameDB_allChannels_with_refCode"  ))
  VVei97.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVei97.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVei97.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVei97.append(("Services with PIcons for the System"  , "VVgNu2"     ))
  VVei97.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVei97.append(VVhJ3E)
  lamedbFile, disabledFile = CC3RQY.VVZ74d()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVei97.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVei97.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVei97.append(("Reset Parental Control Settings"   , "VVhS22"    ))
  VVei97.append(("Delete Channels with no names"   , "VVfryM"    ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Reload Channels and Bouquets"    , "VVxWxX"      ))
  return VVei97
 def VVnr3G(self):
  global VV8CgR
  VV8CgR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFJZPp(self)
   elif item == "currentServiceInfo"     : self.session.open(CCipAb)
   elif item == "TranspondersStats"     : FFpgNe(self, self.VVWKV8     )
   elif item == "lameDB_allChannels_with_refCode"  : FFpgNe(self, self.VVPFHY )
   elif item == "lameDB_allChannels_with_tranaponder" : FFpgNe(self, self.VV986F)
   elif item == "lameDB_allChannels_with_details"  : FFpgNe(self, self.VVIJXp )
   elif item == "parentalControlChannels"    : FFpgNe(self, self.VVX3Vg   )
   elif item == "showHiddenChannels"     : FFpgNe(self, self.VVc7Ba     )
   elif item == "VVgNu2"     : FFpgNe(self, self.VVgkp4     )
   elif item == "servicesWithMissingPIcons"   : FFpgNe(self, self.VVI1cL   )
   elif item == "enableHiddenChannels"     : self.VVtxRf(True)
   elif item == "disableHiddenChannels"    : self.VVtxRf(False)
   elif item == "VVhS22"    : FFcSjz(self, self.VVhS22, "Reset and Restart ?" )
   elif item == "VVfryM"    : FFpgNe(self, self.VVfryM)
   elif item == "VVxWxX"      : FFpgNe(self, boundFunction(CC3RQY.VVxWxX, self))
   else            : self.close()
 @staticmethod
 def VVxWxX(SELF):
  FF3PkJ()
  FFRg6s(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVPFHY(self):
  self.VVe2Js = None
  self.lastfilterUsed  = None
  self.filterObj   = CC08vA(self)
  VVbelk = CC3RQY.VVeovQ(self, self.VVnNKd)
  if VVbelk:
   VVbelk.sort(key=lambda x: x[0].lower())
   VVkbh1  = ("Zap"   , self.VVG3PP     , [])
   VVsYEM = (""    , self.VVEipJ   , [])
   VVcWvO = ("Options"  , self.VVuen3 , [])
   VVY4BM = ("Current Service", self.VVhryA , [])
   VVKois = ("Filter"   , self.VV6a2O  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVZOJU  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFed34(self, None, header=header, VVpuR3=VVbelk, VVZOJU=VVZOJU, VVEFlP=widths, VVQ020=22, VVkbh1=VVkbh1, VVsYEM=VVsYEM, VVY4BM=VVY4BM, VVcWvO=VVcWvO, VVKois=VVKois)
 def VV986F(self):
  self.VVe2Js = None
  self.lastfilterUsed  = None
  self.filterObj   = CC08vA(self)
  VVbelk = CC3RQY.VVeovQ(self, self.VVKG55)
  if VVbelk:
   VVbelk.sort(key=lambda x: x[0].lower())
   VVkbh1  = ("Zap"   , self.VVG3PP      , [])
   VVsYEM = (""    , self.VVEipJ    , [])
   VVY4BM = ("Current Service", self.VVhryA  , [])
   VVcWvO = ("Options"  , self.VVNmSF , [])
   VVKois = ("Filter"   , self.VVWAyw  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVZOJU  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFed34(self, None, header=header, VVpuR3=VVbelk, VVZOJU=VVZOJU, VVEFlP=widths, VVQ020=22, VVkbh1=VVkbh1, VVsYEM=VVsYEM, VVY4BM=VVY4BM, VVcWvO=VVcWvO, VVKois=VVKois)
 def VVuen3(self, VVyGLE, title, txt, colList):
  servName = colList[0]
  refCode  = colList[3]
  pcState  = colList[4]
  hidState = colList[5]
  mSel  = CCdfCX(self, VVyGLE, 3)
  mSel.VVsK91(servName, refCode, pcState, hidState)
 def VVNmSF(self, VVyGLE, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CCdfCX(self, VVyGLE, 3)
  mSel.VVWTQi(servName, refCode)
 def VVjGgL(self, VVyGLE, refCode, isAddToBlackList):
  self.VVe2Js = None
  self.lastfilterUsed  = None
  VVyGLE.VVTN1E("Changing state ...")
  path = "/etc/enigma2/blacklist"
  if not fileExists(path):
   os.system("echo '' > %s" % path)
  if fileExists(path):
   if not refCode.endswith(":"):
    refCode += ":"
   if isAddToBlackList :
    os.system("sed -i '/%s/d' %s" % (refCode, path))
    os.system("echo '%s' >> %s" % (refCode, path))
   else:
    os.system("sed -i '/%s/d' %s" % (refCode, path))
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   if refCode.endswith(":"):
    refCode = refCode[:-1]
   FFpgNe(self, boundFunction(self.VVk0GP, VVyGLE, refCode))
  else:
   FF4LjO(self, path)
 def VVy5Ch(self, VVyGLE, refCode, isHide):
  self.VVe2Js = None
  self.lastfilterUsed  = None
  VVyGLE.VVTN1E("Changing state ...")
  if FFPyKW(refCode):
   ret = FFHhAj(refCode, isHide)
   if ret : FFpgNe(self, boundFunction(self.VVk0GP, VVyGLE, refCode))
   else : FF538m(self, "Cannot Hide/Unhide this channel.")
  else:
   FF538m(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)")
 def VVk0GP(self, VVyGLE, refCode):
  VVbelk = CC3RQY.VVeovQ(self, self.VVnNKd, VV6nZl=[3, [refCode], False])
  done = False
  if VVbelk:
   data = VVbelk[0]
   if data[3] == refCode:
    done = VVyGLE.VVQ7gV(data)
  if not done:
   self.VVl868(VVyGLE, VVyGLE.VVfZxh(), self.VVnNKd)
  VVyGLE.VVDtzl()
 def VV6a2O(self, VVyGLE, title, txt, colList):
  self.filterObj.VVSv1e(1, VVyGLE, 2, boundFunction(self.VVHwSG, VVyGLE))
 def VVHwSG(self, VVyGLE, item):
  self.VVKuTg(VVyGLE, item, 2, self.VVnNKd)
 def VVWAyw(self, VVyGLE, title, txt, colList):
  self.filterObj.VVSv1e(2, VVyGLE, 4, boundFunction(self.VVd8vK, VVyGLE))
 def VVd8vK(self, VVyGLE, item):
  self.VVKuTg(VVyGLE, item, 4, self.VVKG55)
 def VVtliR(self, VVyGLE, title, txt, colList):
  self.filterObj.VVSv1e(0, VVyGLE, 4, boundFunction(self.VVpkIg, VVyGLE))
 def VVpkIg(self, VVyGLE, item):
  self.VVKuTg(VVyGLE, item, 4, self.VVeje5)
 def VVKuTg(self, VVyGLE, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVyGLE.VVGmDB(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVe2Js = None
  else:
   words, asPrefix = CC08vA.VVo2GC(words)
   self.VVe2Js = [col, words, asPrefix]
  if not words:
   FFyMZt(VVyGLE, "Incorrect filter", 2000)
  else:
   VVyGLE.VVTN1E("Reading Services ...")
   FFpgNe(self, boundFunction(self.VVl868, VVyGLE, title, mode))
 def VVl868(self, VVyGLE, title, mode):
  VVbelk = CC3RQY.VVeovQ(self, mode, VV6nZl=self.VVe2Js, VVAPVZ=False)
  if VVbelk:
   VVbelk.sort(key=lambda x: x[0].lower())
   VVyGLE.VVwB4B(VVbelk, title)
  else:
   VVyGLE.VVDtzl()
   FFyMZt(VVyGLE, "Not found!", 1500)
 def VVQnkB(self, VVpuR3, VVkbh1=None, VVsYEM=None, VV1DDw=None, VVY4BM=None, VVcWvO=None, VVKois=None):
  VVY4BM = ("Current Service", self.VVhryA, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVZOJU = (LEFT  , LEFT  , CENTER, LEFT    )
  FFed34(self, None, header=header, VVpuR3=VVpuR3, VVZOJU=VVZOJU, VVEFlP=widths, VVQ020=24, VVkbh1=VVkbh1, VVsYEM=VVsYEM, VV1DDw=VV1DDw, VVY4BM=VVY4BM, VVcWvO=VVcWvO, VVKois=VVKois)
 def VVhryA(self, VVyGLE, title, txt, colList):
  self.VVIBk6(VVyGLE)
 def VVg8A1(self, VVyGLE, title, txt, colList):
  self.VVIBk6(VVyGLE, True)
 def VVIBk6(self, VVyGLE, isFromDetails=False):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpNp5(self)
  if refCode:
   if isFromDetails:
    chName  = info.getName()
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVyGLE.VV8pUN(colDict, VVdtwB=True)
   else:
    VVyGLE.VVu02S(3, refCode, True)
   return
  FF538m(self, "Colud not read current Reference Code !")
 def VVIJXp(self):
  self.VVe2Js = None
  self.lastfilterUsed  = None
  self.filterObj   = CC08vA(self)
  VVbelk = CC3RQY.VVeovQ(self, self.VVeje5)
  if VVbelk:
   VVbelk.sort(key=lambda x: x[0].lower())
   VVsYEM = (""    , self.VV9dpx , []      )
   VVY4BM = ("Current Service", self.VVg8A1  , []      )
   VVKois = ("Filter"   , self.VVtliR   , [], "Loading Filters ..." )
   VVkbh1  = ("Zap"   , self.VVTdQm      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVZOJU  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFed34(self, None, header=header, VVpuR3=VVbelk, VVZOJU=VVZOJU, VVEFlP=widths, VVQ020=24, VVkbh1=VVkbh1, VVsYEM=VVsYEM, VVY4BM=VVY4BM, VVKois=VVKois)
 def VV9dpx(self, VVyGLE, title, txt, colList):
  refCode  = self.VVaqLr(colList)
  chName  = colList[0]
  png, path = CCsPD3.VViWZT(refCode, chName)
  txt   += "Reference\t: %s" % refCode
  CCipAb.VVZUpt(self, refCode, txt, title, path)
 def VVTdQm(self, VVyGLE, title, txt, colList):
  refCode = self.VVaqLr(colList)
  FFY1uw(self, refCode)
 def VVG3PP(self, VVyGLE, title, txt, colList):
  FFY1uw(self, colList[3])
 def VVaqLr(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVeovQ(SELF, mode, VV6nZl=None, VVAPVZ=True, VVtOwU=True):
  lamedbFile, disabledFile = CC3RQY.VVZ74d()
  if fileExists(lamedbFile):
   asPrefix = False
   if VV6nZl:
    filterCol = VV6nZl[0]
    filterWords = VV6nZl[1]
    asPrefix = VV6nZl[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CC3RQY.VVnNKd:
    blackList = None
    path = "/etc/enigma2/blacklist"
    if fileExists(path):
     blackList = FFDyYj(path)
     if blackList:
      blackList = set(blackList)
   elif mode == CC3RQY.VVKG55:
    tp = CCoReX()
   VVkhtC, VVX3Kv = FFyxvv()
   tagFound  = False
   if mode in (CC3RQY.VVLmlD, CC3RQY.VVo5KG):
    VVbelk = {}
   else:
    VVbelk = []
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     if not FFJbeE(SELF):
      return None
     line = line.strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
        sTypeInt = int(STYPE)
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFL3a5(val)
       servTypeHex = (hex(sTypeInt))[2:].upper()
       if mode == CC3RQY.VVeje5:
        if sTypeInt in VVkhtC:
         STYPE = VVX3Kv[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVbelk.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVbelk.append(tRow)
        else:
         VVbelk.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CC3RQY.VVLmlD:
         VVbelk[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CC3RQY.VVo5KG:
         VVbelk[chName] = refCode
        elif mode == CC3RQY.VVnNKd:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVbelk.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVbelk.append(tRow)
         else:
          VVbelk.append(tRow)
        elif mode == CC3RQY.VVKG55:
         if sTypeInt in VVkhtC:
          STYPE = VVX3Kv[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVm6Ia(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVbelk.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVbelk.append(tRow)
         else:
          VVbelk.append(tRow)
        elif mode == CC3RQY.VV0XDC:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VVbelk.append((chName, chProv, sat, refCode))
        elif mode == CC3RQY.VV0jLf:
         VVbelk.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VVbelk and VVAPVZ:
    FF538m(SELF, "No services found!")
   return VVbelk
  else:
   if VVtOwU:
    FF4LjO(SELF, lamedbFile)
   return None
 def VVX3Vg(self):
  path = "/etc/enigma2/blacklist"
  if fileExists(path):
   lines = FFDyYj(path)
   if lines:
    newRows  = []
    VVbelk = CC3RQY.VVeovQ(self, self.VV0jLf)
    if VVbelk:
     lines = set(lines)
     for item in VVbelk:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVbelk = newRows
      VVbelk.sort(key=lambda x: x[0].lower())
      VVsYEM = ("", self.VVEipJ, [])
      VVkbh1 = ("Zap", self.VVG3PP, [])
      self.VVQnkB(VVpuR3=VVbelk, VVkbh1=VVkbh1, VVsYEM=VVsYEM)
     else:
      FF6wpe(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVbelk)))
   else:
    FFRg6s(self, "No hidden services.", FFIP5j())
  else:
   FF4LjO(self, path)
 def VVc7Ba(self):
  VVbelk = CC3RQY.VVeovQ(self, self.VV0XDC)
  if VVbelk:
   if VVbelk:
    VVbelk.sort(key=lambda x: x[0].lower())
    VVsYEM = ("" , self.VVEipJ, [])
    VVkbh1  = ("Zap", self.VVG3PP, [])
    self.VVQnkB(VVpuR3=VVbelk, VVkbh1=VVkbh1, VVsYEM=VVsYEM)
   else:
    FF6wpe(self, "Lines\t: %d\nFound\t: %d\nLameDB\t: %d" % (len(lines), txt.count("\n"), len(VVbelk)))
 def VVWKV8(self):
  totT, totC, totA, totS, totS2, satList = self.VVcSUq()
  txt = FFUIPk("Total Transponders:\n\n", VVbHZ1)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFUIPk("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVbHZ1)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFPApr(item), satList.count(item))
  FF6wpe(self, txt)
 def VVcSUq(self):
  lamedbFile, disabledFile = CC3RQY.VVZ74d()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     if not FFJbeE(self):
      return 0, 0, 0, 0, 0, None
     line = line.strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FF4LjO(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VVgkp4(self):
  self.VVgNu2(True)
 def VVI1cL(self):
  self.VVgNu2(False)
 def VVgNu2(self, isWithPIcons):
  piconsPath = CCsPD3.VVkefR()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCsPD3.VVF2sv(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVbelk = CC3RQY.VVeovQ(self, self.VV0jLf)
    if VVbelk:
     channels = []
     for (chName, chProv, sat, refCode) in VVbelk:
      if not FFJbeE(self):
       return
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFBSXf(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVbelk)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVWqEf(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVWqEf("PIcons Path"  , piconsPath)
     txt += VVWqEf("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVWqEf("Total services" , totalServices)
     txt += VVWqEf("With PIcons"  , totalWithPIcons)
     txt += VVWqEf("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FF6wpe(self, txt)
     else:
      VVsYEM     = (""      , self.VVEipJ , [])
      if isWithPIcons : VVKois = ("Export Current PIcon", self.VVLDLv  , [])
      else   : VVKois = None
      VVcWvO     = ("Statistics", FF6wpe, [txt])
      VVkbh1      = ("Zap", self.VVG3PP, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVQnkB(VVpuR3=channels, VVkbh1=VVkbh1, VVsYEM=VVsYEM, VVcWvO=VVcWvO, VVKois=VVKois)
   else:
    FF538m(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FF538m(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVEipJ(self, VVyGLE, title, txt, colList):
  png, path = CCsPD3.VViWZT(colList[3], colList[0])
  CCipAb.VVZUpt(self, colList[3], txt, title, path)
 def VVLDLv(self, VVyGLE, title, txt, colList):
  png, path = CCsPD3.VViWZT(colList[3], colList[0])
  if path:
   CCsPD3.VVO7Fr(self, png, path)
 @staticmethod
 def VVZ74d():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVeyKf():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVtxRf(self, isEnable):
  lamedbFile, disabledFile = CC3RQY.VVZ74d()
  if isEnable and not fileExists(disabledFile):
   FFRg6s(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FF538m(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFcSjz(self, boundFunction(self.VVZsPN, isEnable), "%s Hidden Channels ?" % word)
 def VVZsPN(self, isEnable):
  lamedbFile , disabledFile = CC3RQY.VVZ74d()
  lamedb5File, diabled5File = CC3RQY.VVeyKf()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FF3PkJ()
  if res == 0 : FFRg6s(self, "Hidden List %s" % word)
  else  : FF538m(self, "Error while restoring:\n\n%s" % fileName)
 def VVhS22(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFw6rd(self, cmd)
 def VVfryM(self):
  lamedbFile, disabledFile = CC3RQY.VVZ74d()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFgzF5("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFDyYj(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFgzF5("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FF3PkJ()
   FF6wpe(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FF4LjO(self, lamedbFile)
class CCipAb(Screen):
 VV3uTV = 0
 VVh5bf   = 1
 VVnnkD   = 2
 EPG_MODE_SERVER_IPTV  = 3
 VV70ig    = 4
 def __init__(self, session, isFromSignal=False, extraInfoData=[]):
  self.skin, self.skinParam = FF87m3(VVCHm0, 1400, 800, 50, 30, 20, "#110B2830", "#050B242c", 30, addFramedPic=True)
  self.extraInfoData = extraInfoData
  if self.extraInfoData:
   self.infoMode = self.extraInfoData[0]
   if self.infoMode == self.VV70ig: title = self.extraInfoData[2]
   else         : title = "Channel Information"
  else:
   self.infoMode = self.VV3uTV
   title = "Current Service"
   if isFromSignal:
    title += FFUIPk("   (No Signal Monitor for IPTV)", VVZD1o)
  self.Sep = FFUIPk("%s\n", VVZD1o) % VV8ben
  self.session   = session
  FFyw62(self, title=title, addScrollLabel=True)
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  self["myLabel"].VVEY9M(enableSave=True)
  if   self.infoMode == self.VV3uTV : fnc = self.VVRjGI_fromCurrentChannel
  elif self.infoMode == self.VVh5bf  : fnc = self.VVRjGI_fromFindTable
  elif self.infoMode == self.VVnnkD  : fnc = self.VVRjGI_fromLocalIptvTable
  elif self.infoMode == self.EPG_MODE_SERVER_IPTV  : fnc = self.VVRjGI_fromServerIptvTable
  elif self.infoMode == self.VV70ig   : fnc = self.VVRjGI_fromOthers
  FFpgNe(self, fnc, title="Reading info. ...")
 def VVZh6u(self, err):
  self["myLabel"].setText(err)
  FFrhNb(self["myTitle"], "#22200000")
  FFrhNb(self["myBody"], "#22200000")
  self["myLabel"].FFrhNbColor("#22200000")
  self["myLabel"].VVQdyj()
 def VVoBYK(self, txt, isIptv, chName, refCode, decodedUrl, info=None):
  txt += self.VVg45C(isIptv, chName, refCode, decodedUrl, info)
  self.VVIV9F(txt)
 def VVRjGI_fromOthers(self):
  mode, refCode, txt, title, VVkojI = self.extraInfoData
  picShown = self.VVAJ0q(VVkojI)
  epg = self.VVZVyO(refCode, None)
  if epg:
   txt += epg
  self.VVIV9F(txt)
 def VVIV9F(self, txt):
  self["myLabel"].setText(txt, VVfs8s=VVAqA7)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVQdyj(minHeight=minH)
 def VVRjGI_fromFindTable(self):
  mode, chName, refCode, txt = self.extraInfoData
  txt += self.VVJMvL(refCode, refCode, chName)
  isIptv = FFYHCc(refCode)
  if isIptv:
   txt += self.VVGX1e(refCode)
  else:
   tp = CCoReX()
   tpTxt, namespace = tp.VVj5YZ(refCode)
   del tp
   if tpTxt:
    txt += self.Sep
    txt += tpTxt
  refCode, decodedUrl, origUrl, iptvRef = FFIv3N(refCode)
  self.VVoBYK(txt, isIptv, chName, refCode, decodedUrl)
 def VVRjGI_fromLocalIptvTable(self):
  mode, chName, refCode, decodedUrl, txt = self.extraInfoData
  txt += self.VVGX1e(refCode + decodedUrl)
  txt += "\n"
  txt += self.VVJMvL(refCode, refCode, chName)
  self.VVoBYK(txt, True, chName, refCode, decodedUrl)
 def VVRjGI_fromServerIptvTable(self):
  mode, chName, chUrl, picUrl, refCode, txt = self.extraInfoData
  decodedUrl = FFFkUX(chUrl.replace(refCode, "").replace(chName, "").strip(":").strip())
  self.VVoBYK(txt, True, chName, refCode, decodedUrl)
 def VVRjGI_fromCurrentChannel(self):
  info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
  try:
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpNp5(self)
  except:
   return
  if not info:
   self.VVZh6u("No data from system !")
   return
  chName = info.getName()
  txt = ""
  txt += "Service Name\t: %s\n" % FFUIPk(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVWqEf(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFUIPk(state, VVEiu9)
   txt += "State\t: %s\n" % state
  w = FFzao7(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFzao7(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = FFzao7(info      , iServiceInformation.sAspect)
  if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : aspect = "4:3"
  else           : aspect = "16:9"
  txt += "Video Format\t: %s\n" % aspect
  txt += self.VVWqEf(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVWqEf(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVWqEf(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  isIptv = len(iptvRef) > 0
  if iptvRef:
   txt += "Service Type\t: %s\n" % FFUIPk("IPTV", VVbHZ1)
   txt += self.VVGX1e(iptvRef)
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not refCode:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    path = serv.getPath()
    if path:
     txt += "Path\t: %s\n" % path
  txt += "\n"
  txt += self.VVJMvL(refCode, iptvRef, chName)
  if not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCoReX()
    tpTxt, namespace = tp.VVj5YZ(refCode)
    del tp
    if tpTxt:
     txt += FFUIPk("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFUIPk("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVWqEf(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVWqEf(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVWqEf(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVWqEf(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVWqEf(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVWqEf(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVWqEf(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVWqEf(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVWqEf(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  self.VVoBYK(txt, isIptv, chName, refCode, decodedUrl, info)
 def VVWqEf(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFzao7(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVfpvI(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVfpvI(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVg45C(self, isIptv, chName, refCode, decodedUrl, info):
  txt = ""
  sep = "%s\n" % VV8ben
  png, path = CCsPD3.VViWZT(refCode, chName)
  picShown = False
  if png:
   if VVU5KH:
    txt += "\n"
    txt += sep
    txt += "PIcon:\n"
    txt += "%s\n" % path
   picShown = self.VVAJ0q(path)
  txt = ""
  if isIptv:
   epg, err = self.VVww3t(decodedUrl, refCode, not picShown)
   txt += FFUIPk("\n%sEPG:\n%s" % (sep, sep), COLOR_CONS_BRIGHT_YELLOW)
   if epg : txt += epg
   elif err: txt += FFUIPk(err, VVZD1o)
  else:
   epg = self.VVZVyO(refCode, info)
   if epg:
    txt += epg
  return txt
 def VVZVyO(self, refCode, info):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVH7oN(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVH7oN(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVH7oN(event, 0)
     except:
      pass
  return epg
 def VVH7oN(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName()    or ""
   evTime = event.getBeginTime()    or ""
   evDur = event.getDuration()    or ""
   evShort = event.getShortDescription()  or ""
   evDesc = event.getExtendedDescription() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    if evName          : txt += "Name\t: %s\n"   % FFUIPk(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evTime           : txt += "Start Time\t: %s\n" % FFbrdA(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFbrdA(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFhCAD(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFhCAD(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFhCAD(evTime - now)
    if evShort and evShort.strip()     : txt += "\nSummary:\n%s\n"  % FFUIPk(evShort, VVLIgE)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFUIPk(evDesc , VVLIgE)
    if txt:
     txt = FFUIPk("\n%s\n%s Event:\n%s\n" % (VV8ben, ("Current", "Next")[evNum], VV8ben), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVww3t(self, decodedUrl, refCode, showPIcon):
  if not FF4L18():
   return "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCQps6.VVJZCV(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "No EPG (not a subscription ULR) !"
  if   uType == "live" : qUrl = "%s/player_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uHost, uUser, uPass, uId)
  elif uType == "movie" : qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
  elif uType == "series" : return "", "No EPG for Series Channels !"
  txt, err = CCQps6.VVBg9e(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "Could not parse server data !"
  epg  = ""
  if tDict:
   if uType == "live":
    epg, lang = self.VVsViQ(tDict)
    if epg:
     epg = "Language\t: %s\n\n%s" % (lang, epg)
   elif uType == "movie":
    epg, picUrl = self.VVrHgR(tDict)
    if showPIcon and picUrl:
     path, err = FFOwIM(picUrl, "ajpanel_tmp.png", timeout=2)
     picShown = self.VVAJ0q(path)
     self.VVYUbM(path, refCode)
  if epg : return epg, ""
  else : return "" ,  "No EPG from server !"
 def VVsViQ(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCQps6.VVDB0e(item, "title"    , is_base64=True )
     lang    = CCQps6.VVDB0e(item, "lang"         ).upper()
     description   = CCQps6.VVDB0e(item, "description"  , is_base64=True )
     start_timestamp  = CCQps6.VVDB0e(item, "start_timestamp" , isDate=True  )
     stop_timestamp  = CCQps6.VVDB0e(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCQps6.VVDB0e(item, "stop_timestamp"       )
     now_playing   = CCQps6.VVDB0e(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVI8UI, ""
      else     : color, txt = VVEiu9 , "    (CURRENT EVENT)"
      epg += FFUIPk("_" * 32 + "\n", VVZD1o)
      epg += FFUIPk("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      epg += "Description:\n%s\n" % FFUIPk(description, VVLIgE)
      evNum += 1
   except:
    pass
  return epg, lang
 def VVrHgR(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item =tDict["info"]
    movie_image   = CCQps6.VVDB0e(item, "movie_image" )
    genre    = CCQps6.VVDB0e(item, "genre"   ) or "-"
    plot    = CCQps6.VVDB0e(item, "plot"   ) or "-"
    cast    = CCQps6.VVDB0e(item, "cast"   ) or "-"
    rating    = CCQps6.VVDB0e(item, "rating"   ) or "-"
    director   = CCQps6.VVDB0e(item, "director"  ) or "-"
    releasedate   = CCQps6.VVDB0e(item, "releasedate" ) or "-"
    duration   = CCQps6.VVDB0e(item, "duration"  ) or "-"
    epg += "Genre\t: %s\n"  % genre
    epg += "Released\t: %s\n" % releasedate
    epg += "Duration\t: %s\n" % duration
    epg += "Director\t: %s\n" % director
    epg += "Rating\t: %s\n\n" % rating
    epg += "Cast:\n%s\n\n"  % FFUIPk(cast, VVLIgE)
    epg += "Plot:\n%s"   % FFUIPk(plot, VVLIgE)
   except:
    pass
  return epg, movie_image
 def VVYUbM(self, path, refCode):
  if path and fileExists(path) and os.system(FFgzF5("which ffmpeg")) == 0:
   pPath = CCsPD3.VVkefR()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
    cmd += FFgzF5("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVGX1e(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFIv3N(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   txt += "\n"
   txt += FFUIPk("URL:", VVbHZ1) + "\n%s\n" % decodedUrl
  else:
   txt = "\n"
   txt += FFUIPk("Reference:", VVbHZ1) + "\n%s\n" % refCode
  return txt
 def VVAJ0q(self, path):
  if path and fileExists(path):
   err, w, h = self.VVgWtp(path)
   if not err:
    if h > w:
     self.VVqMGU(self["myPicF"], w, h, True)
     self.VVqMGU(self["myPic"] , w, h, False)
   allOK = FFGJQR(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVqMGU(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVgWtp(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFLHG0(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVJMvL(self, refCode, iptvRef, chName):
  refCode = FFMJnf(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFUy6Y(VVGnNm + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFUy6Y(VVGnNm + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVpuR3 = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVGnNm + item
   if fileExists(path):
    txt = FFUy6Y(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVpuR3.append(bName)
  txt = self.Sep
  if VVpuR3:
   if len(VVpuR3) == 1:
    txt += "%s\t: %s\n" % (FFUIPk("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VVpuR3[0])
   else:
    txt += FFUIPk("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VVpuR3):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 @staticmethod
 def VVqVFq(SELF, chName, refCode, url, txt):
  SELF.session.open(boundFunction(CCipAb, extraInfoData=[CCipAb.VVnnkD, chName, refCode, url, txt]))
 @staticmethod
 def VVAUeq(SELF, chName, chUrl, picUrl, refCode, txt):
  SELF.session.open(boundFunction(CCipAb, extraInfoData=[CCipAb.EPG_MODE_SERVER_IPTV, chName, chUrl, picUrl, refCode, txt]))
 @staticmethod
 def VVeStt(SELF, chName, refCode, txt):
  SELF.session.open(boundFunction(CCipAb, extraInfoData=[CCipAb.VVh5bf, chName, refCode, txt]))
 @staticmethod
 def VVZUpt(SELF, refCode, txt, title, VVkojI):
  SELF.session.open(boundFunction(CCipAb, extraInfoData=[CCipAb.VV70ig, refCode, txt, title, VVkojI]))
class CCF8XP():
 def __init__(self):
  self.VVYDvz  = ""
  self.VVf8Cq   = ""
  self.VVvvTd  = ""
  self.colored_user  = "#f#11ffffaa#User"
  self.colored_server  = "#f#11aaffff#Server"
 def VVNGxB(self, url, mac, VVdtwB=True):
  self.VVYDvz = ""
  self.VVf8Cq  = ""
  self.VVvvTd = ""
  host = self.VV44dL(url)
  if not host:
   if VVdtwB:
    self.VVdtwBor("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VV0VhI(mac)
  if not host:
   if VVdtwB:
    self.VVdtwBor("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVYDvz = host
  self.VVf8Cq  = mac
  self.VVvvTd = ""
  return True
 def VVuFKD(self):
  res, err = self.VVpguz(self.VVYDvz, useCookies=False)
  if err:
   self.VVdtwBor(err, "Connect to Portal")
   return False
  if (res.status_code == 301):
   title = "Redirection"
   newUrl = res.headers['location']
   res, err = self.VVpguz(newUrl, res.cookies)
   if err:
    self.VVdtwBor(err, "URL Redirection")
    return False
   else:
    host = self.VV44dL(newUrl)
    if not host:
     self.VVdtwBor("Incorrect Redirection-URL Format !\n\n%s" % newUrl)
     return False
    self.VVYDvz = host
  token, profile = self.VVKusK()
  if not token:
   return False
  return True
 def VV44dL(self, url):
  ndx = url.lower().find("mac=")
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ ")
  return url
 def VV0VhI(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVKusK(self, VVdtwB=True):
  try:
   token = self.VVNzSn()
   if token:
    self.VVvvTd = token
   else:
    if VVdtwB:
     self.VVdtwBor("Could not get Token from server !")
    return "", ""
   return token, self.VVZpPM()
  except:
   return "", ""
 def VVNzSn(self):
  token  = ""
  res, err = self.VVpguz(self.VVPJZi())
  if not err:
   try:
    tDict = jLoads(res.text)
    token = CCQps6.VVDB0e(tDict['js'], "token")
   except:
    pass
  return token.strip()
 def VVZpPM(self):
  res, err = self.VVpguz(self.VVayoj())
  if not err:
   try:
    profJson = jLoads(res.text)
    return profJson
   except:
    pass
  return ""
 def VV7GMO(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVBtSL()
  if len(rows) < 10:
   rows = self.VVEX3o()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVYDvz ))
   rows.append(("MAC (from URL)" , self.VVf8Cq ))
   rows.append(("Token"   , self.VVvvTd ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VVf8Cq ))
   rows.append(("2", self.colored_server, "Host" , self.VVYDvz ))
   rows.append(("2", self.colored_server, "Token" , self.VVvvTd ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVmedo(self):
  token, profile = self.VVKusK()
  if not token:
   return ""
  m3u_Url = ""
  url = self.VVeaze()
  res, err = self.VVpguz(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCQps6.VVDB0e(tDict['js'], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = span.group(2)
     pass1 = span.group(3)
     m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
   except:
    pass
  return m3u_Url
 def VVBtSL(self):
  m3u_Url = self.VVmedo()
  rows = []
  if m3u_Url:
   res, err = self.VVpguz(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", )): val = FFbrdA(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFbrdA(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVEX3o(self):
  tDict = self.VVZpPM()
  try:
   item = tDict['js']
  except:
   return []
  if not isinstance(tDict, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFQutI(val): val = FFhawA(val.decode("UTF-8"))
     else     : val = self.VVf8Cq
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFbrdA(int(parts[1]))
      ends = FFbrdA(int(parts[1]) + int(parts[2]))
      val = " (%s ... %s)" % (pToken, started, ends)
    elif key in ("created", "last_watchdog"):
     val = FFbrdA(int(val))
     if key in "created": key = "Created/Expiry"
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), val)))
  return rows
 def VVPJZi(self):
  return self.VVYDvz + "/server/load.php?type=stb&action=handshake&token=&mac=%s" % self.VVf8Cq
 def VVayoj(self):
  return self.VVYDvz + "/server/load.php?type=stb&action=get_profile"
 def VVIPq5(self, mode):
  url = self.VVYDvz + "/server/load.php?type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVY4YP(self, catID):
  return self.VVYDvz + "/server/load.php?type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVBZKs(self, mode, catID, page):
  url = self.VVYDvz + "/server/load.php?type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "series" : url += "category=%s" % catID
  else    : url += "genre=%s&force_ch_link_check=" % catID
  return url
 def VVO3Tt(self, mode, catID):
  return self.VVYDvz + "/server/load.php?type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVhXO2(self, mode, chCm, serCode, serId):
  url = self.VVYDvz + "/server/load.php?action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVeaze(self):
  return self.VVYDvz + "/server/load.php?type=itv&action=create_link"
 def VVAtEj(self, mode, chCm, serCode, serId):
  chCm = chCm.replace(":", "%3a")
  serCode = serCode.replace(":", "%3a")
  serId = serId.replace(":", "%3a")
  macB64 = FFoNNB(self.VVf8Cq)
  return self.VVYDvz + "/j.php?mode=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, macB64, serCode, serId, chCm)
 def VV2fhT(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res   = iUrlparse(url)
  scheme  = res.scheme
  tDict  = iUrlparse_qs(res.query)
  chCode  = tDict.get("chCode", [""])[0].strip()
  chCm  = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  epNum  = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId  = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  phpParam = "mode=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, chCode, epNum, epId, chCm)
  netloc = res.netloc
  if scheme:
   scheme += "://"
  host = scheme + netloc
  mac  = FFhawA(chCode)
  valid = self.VV44dL(host) and self.VV44dL(mac)
  return valid, mode, host, mac, chCode, epNum, epId, chCm, phpParam
 def VVpguz(self, url, useCookies=True):
  err = ""
  try:
   import requests
   cookies = { "mac" : self.VVf8Cq, "stb_lang" : "en" }
   headers = { 'User-Agent':  'Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3', }
   if self.VVvvTd:
    headers["Authorization"] = "Bearer %s" % self.VVvvTd
   if useCookies : res = requests.get(url, headers=headers, allow_redirects=False, timeout=2, cookies=cookies)
   else   : res = requests.get(url, headers=headers, allow_redirects=False, timeout=2)
   res.raise_for_status()
   return res, ""
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.exceptions.HTTPError as e  : err = "HTTP Error"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[120]
  return "", err + "\n\n" + url
 def VVqhJi(self, mode, catID, stID, chNum, chCm, chName, url):
  token, profile = self.VVKusK()
  if not token:
   return
  res, err = self.VVpguz(url)
  chUrl = ""
  try:
   tDict = jLoads(res.text)
   chUrl = CCQps6.VVDB0e(tDict['js'], "cmd")
  except:
   pass
  if chUrl:
   chUrl = chUrl.replace("ffmpeg ", "")
   chUrl = chUrl.replace(":", "%3a")
   chUrl = CCQps6.VV1fL5(catID, stID, chNum) + chUrl.strip() + ":" + chName
   ndx  = chUrl.find("play_token=")
   if ndx > -1:
    ndx = chUrl.find(":", ndx)
    if ndx > -1:
     left = chUrl[:ndx]
     right = chUrl[ndx:]
     chUrl = left + "&mode=%s&chCode=%s&chCm=%s&end=" % (mode, FFoNNB(self.VVf8Cq), chCm.replace(":", "%3a")) + right
  return chUrl
 @staticmethod
 def VVWj5b(host, mac, tType, action, keysList=[]):
  myPortal = CCF8XP()
  ok = myPortal.VVNGxB(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile = myPortal.VVKusK()
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VVpguz(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVDQEh(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVDQEh(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVdtwBor(self, err, title="Portal Browser"):
  FF538m(self, str(err), title=title)
class CC3gUj():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.adultWords  = ("adult", "sex" , "porn", "xxx", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.nameTagPatt = r"\s*[(|]\s*[A-Z]{2}\s*.?\s*[)|]\s*(?:.+[|]\s*)*(.+)"
 def VVZvBg(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  name = iSub(r"(b[-]*e[-]*I[-]*N)", r"beIN", name, flags=IGNORECASE).strip()
  if CCQps6.VVTock(name):
   return CCQps6.VV66ZH(name)
  if self.removeTag:
   if name.startswith("|"):
    name = name.split("|")[-1] or name
   else:
    span = iSearch(self.nameTagPatt, name, IGNORECASE)
    if span:
     name = span.group(1).strip() or name
  return name.strip()
 def VVKpqG(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  else:
   return name.strip()
class CCwWAx(CCF8XP):
 def __init__(self):
  CCF8XP.__init__(self)
 def VVcTZn(self):
  try:
   import requests
   FFpgNe(self, self.VVKoCO, title="Searching ...")
  except:
   FFcSjz(self, self.VVihWJ, '"Requests Library" is required to read Portal.\n\nInstall the library ?')
 def VVVsPH(self, winSession, url, mac):
  if self.VVNGxB(url, mac):
   FFpgNe(winSession, self.VV5sNj, title="Checking Server ...")
  else:
   FF538m(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVihWJ(self):
  from sys import version_info
  cmdUpd = FF9LLs(VVXwLJ, "")
  if cmdUpd:
   cmdInst = FFVVjD(VVn00Q, "python-requests")
   if version_info[0] >= 3:
    cmdInst = cmdInst.replace("python-", "python3-")
   cmd = cmdUpd + " && " + cmdInst
   FF8mHD(self, cmd, checkNetAccess=True, title="Installing Requests Library")
  else:
   FF9VHl(self)
 def VVKoCO(self):
  lines = FFofdg('find / %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % FFRwKj(1))
  if lines:
   lines.sort()
   VVei97 = []
   for line in lines:
    VVei97.append((line, line))
   OKBtnFnc = self.VVRcve
   FFrC6O(self, None, title="Select Portals File", VVei97=VVei97, width=1200, OKBtnFnc=OKBtnFnc)
  else:
   FF538m(self, "No portal files found\n\nFile example : portalxx.txt \n(separate URL and MAC with space/tab/comma)")
 def VVRcve(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFpgNe(menuInstance, boundFunction(self.VVAeF7, path), title="Reading File ...")
 def VVAeF7(self, path):
  list  = self.VVk6al(path)
  title = "Portals List File"
  if list:
   VV1DDw  = ("Home Menu", FFW3h5, [])
   VVKois  = None #("Check & Filter" , boundFunction(self.filterPortalAuthorizedServers, path), [])
   VVcWvO = ("Edit File" , boundFunction(self.VVxJ4j, path) , [])
   VVkbh1  = ("Select"  , self.VVVsPH_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVZOJU  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   FFed34(self, None, title=title, header=header, VVpuR3=list, VVZOJU=VVZOJU, VVEFlP=widths, VVQ020=22, VVkbh1=VVkbh1, VV1DDw=VV1DDw, VVcWvO=VVcWvO, VVKois=VVKois, VVCABW="#0a001111", VVG1bZ="#0a001122", VVZHzf="#0a001122", VVjMdQ="#00000000", VVwC3K=True, searchCol=1)
  else:
   FF538m(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVVsPH_fromMacFiles(self, VVyGLE, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVVsPH(VVyGLE, url, mac)
 def VVxJ4j(self, path, VVyGLE, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCi8JT(self, path, VVuWtK=boundFunction(self.VVYhQa, VVyGLE), curRowNum=rowNum)
  else    : FF4LjO(self, path)
 def VVYhQa(self, VVyGLE, fileChanged):
  if fileChanged:
   VVyGLE.cancel()
 def VVk6al(self, path):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  list  = []
  url   = ""
  c   = 0
  lines  = FFDyYj(path)
  for lineNum, line in enumerate(lines, start=1):
   line = line.strip()
   if not line:
    continue
   span = iSearch(urlMacPatt, line, IGNORECASE)
   if span:
    c  += 1
    subj = span.group(1).strip() or "-"
    url  = span.group(2).strip()
    mac  = span.group(3).strip().replace(" ", "").upper()
    info = span.group(4).strip() or "-"
    host = self.VV44dL(url)
    mac  = self.VV0VhI(mac)
    if host and mac:
     list.append((str(c), str(lineNum), subj, host, mac, info))
    url  = ""
    continue
   if not url:
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if not span:
     span = iSearch(urlOnlyPatt, line, IGNORECASE)
     if span:
      url = span.group(1)
   else:
    span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     mac  = span.group(2).strip().replace(" ", "").upper()
     info = span.group(3).strip() or "-"
     host = self.VV44dL(url)
     mac  = self.VV0VhI(mac)
     if host and mac and not mac.startswith("AC"):
      list.append((str(c), str(lineNum), "-", host, mac, info))
    else:
     span = iSearch(urlOnlyPatt, line, IGNORECASE)
     if span:
      url = span.group(1)
  return list
 def VVl1CY(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFhawA(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VV5sNj(self):
  if self.VVuFKD():
   VVei97 = []
   VVei97.append(("Live"     , "stbLive"  ))
   VVei97.append(("VOD"     , "stbVod"  ))
   VVei97.append(("Series (Seasons)"  , "stbSeries" ))
   VVei97.append(VVhJ3E)
   VVei97.append(("Portal Account Info." , "accountInfo" ))
   OKBtnFnc  = self.VV9JU5
   VVmf6o  = ("Home Menu", FFW3h5)
   FFrC6O(self, None, title="Portal Resources (MAC=%s)" % self.VVf8Cq, VVei97=VVei97, OKBtnFnc=OKBtnFnc, VVmf6o=VVmf6o)
 def VV9JU5(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "stbLive"  : mode = "itv"
   elif ref == "stbVod"  : mode = "vod"
   elif ref == "stbSeries"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFpgNe(menuInstance, boundFunction(self.VVQzfp, mode), title="Reading Categories ...")
   else : FFpgNe(menuInstance, boundFunction(self.VVBoH2, menuInstance, title), title="Reading Account ...")
 def VVBoH2(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VV7GMO(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVf8Cq)
  VV1DDw  = ("Home Menu" , FFW3h5, [])
  if totCols == 2:
   VVKois = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
   VVKois = ("Other Info." , boundFunction(self.VVSvK2, menuInstance) , [])
  FFed34(self, None, title=title, header=header, VVpuR3=rows, VVEFlP=widths, VVQ020=26, VV1DDw=VV1DDw, VVKois=VVKois, VVCABW="#0a00292B", VVG1bZ="#0a002126", VVZHzf="#0a002126", VVjMdQ="#00000000", searchCol=searchCol)
 def VVSvK2(self, menuInstance, VVyGLE, title, txt, colList):
  VVyGLE.cancel()
  FFpgNe(menuInstance, boundFunction(self.VVBoH2, menuInstance, title, forceMoreInfo=True), title="Reading Account ...")
 def VVQzfp(self, mode):
  token, profile = self.VVKusK()
  if not token:
   return
  res, err = self.VVpguz(self.VVIPq5(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CC3gUj()
     chList = tDict['js']
     for item in chList:
      Id   = CCQps6.VVDB0e(item, "id"       )
      Title  = CCQps6.VVDB0e(item, "title"      )
      censored = CCQps6.VVDB0e(item, "censored"     )
      Title = processChanName.VVKpqG(Title)
      if Title and not Title.strip().lower() == "all":
       list.append((Title.strip(), Id))
   except:
    pass
  if mode == "series" : title = mode.capitalize()
  else    : title = mode.upper()
  title += " Categories"
  if list:
   VVcWvO = None #("Find %s Name" % fName, boundFunction(self.VVdTAr, fMode), [])
   VVkbh1  = ("Show Channels" , boundFunction(self.VVFx0u, mode) , [])
   VV1DDw = ("Home Menu"  , FFW3h5         , [])
   header   = ("Category", "catID" )
   widths   = (100   , 0  )
   FFed34(self, None, title=title, header=header, VVpuR3=list, VVEFlP=widths, VVQ020=30, VV1DDw=VV1DDw, VVcWvO=VVcWvO, VVkbh1=VVkbh1, VVCABW="#0a00292B", VVG1bZ="#0a002126", VVZHzf="#0a002126", VVjMdQ="#00000000")
  else:
   FF538m(self, "Could not get Categories from server!", title=title)
 def VVjnbK(self, mode, VVyGLE, title, txt, colList):
  FFpgNe(VVyGLE, boundFunction(self.VVFsgd, mode, VVyGLE, title, txt, colList), title="Downloading ...")
 def VVFsgd(self, mode, VVyGLE, title, txt, colList):
  token, profile = self.VVKusK()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVpguz(self.VVY4YP(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict['js']['data']
     for item in chList:
      Id    = CCQps6.VVDB0e(item, "id"    )
      actors   = CCQps6.VVDB0e(item, "actors"   )
      added   = CCQps6.VVDB0e(item, "added"   )
      age    = CCQps6.VVDB0e(item, "age"   )
      category_id  = CCQps6.VVDB0e(item, "category_id" )
      description  = CCQps6.VVDB0e(item, "description" )
      director  = CCQps6.VVDB0e(item, "director"  )
      genres_str  = CCQps6.VVDB0e(item, "genres_str"  )
      name   = CCQps6.VVDB0e(item, "name"   )
      path   = CCQps6.VVDB0e(item, "path"   )
      screenshot_uri = CCQps6.VVDB0e(item, "screenshot_uri" )
      series   = CCQps6.VVDB0e(item, "series"   )
      cmd    = CCQps6.VVDB0e(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VVkbh1  = ("Play"  , boundFunction(self.VVeRTR, mode)        , [])
   VV1DDw = ("Home Menu" , FFW3h5                , [])
   VVY4BM = ("Download PIcons" , boundFunction(self.VVV7aR, mode)      , [])
   VVcWvO = ("Add ALL to Bouquet" , boundFunction(self.VVp09F, mode, seriesName) , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01  , 0.01 , 0  , 0.01  , 0.01  , 0.01  , 0.01   , 0    , 0  )
   VVZOJU  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT  , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFed34(self, None, title=seriesName, header=header, VVpuR3=list, VVZOJU=VVZOJU, VVEFlP=widths, VVQ020=26, VV1DDw=VV1DDw, VVY4BM=VVY4BM, VVcWvO=VVcWvO, VVkbh1=VVkbh1, VVCABW="#0a00292B", VVG1bZ="#0a002126", VVZHzf="#0a002126", VVjMdQ="#00000000")
  else:
   FF538m(self, "Could not get Episodes from server!", title=seriesName)
 def VVFx0u(self, mode, VVyGLE, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.session.open(CCg6oa, barTheme=CCg6oa.VVIt71
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVo2ut, mode, bName, catID)
      , VVuWtK = boundFunction(self.VVlNBu, mode, bName, catID))
 def VVlNBu(self, mode, bName, catID, VVNx6Z, VVQKYK, threadCounter, threadTotal, threadErr):
  if VVQKYK:
   if mode == "series":
    VVkbh1  = ("Episodes", boundFunction(self.VVjnbK, mode) , [])
    VVY4BM = None
    VVcWvO = None
   else:
    VVkbh1  = ("Play"    , boundFunction(self.VVeRTR, mode)     , [])
    VVY4BM = ("Download PIcons" , boundFunction(self.VVV7aR, mode)     , [])
    VVcWvO = ("Add ALL to Bouquet" , boundFunction(self.VVp09F, mode, bName) , [])
   VVsYEM = (""      , boundFunction(self.VV8usR, mode)    , [])
   VV1DDw = ("Home Menu"    , FFW3h5             , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVZOJU  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER)
   VVyGLE = FFed34(self, None, title=bName, header=header, VVpuR3=VVQKYK, VVZOJU=VVZOJU, VVEFlP=widths, VVQ020=26, VV1DDw=VV1DDw, VVY4BM=VVY4BM, VVcWvO=VVcWvO, VVkbh1=VVkbh1, VVsYEM=VVsYEM, VVCABW="#0a00292B", VVG1bZ="#0a002126", VVZHzf="#0a002126", VVjMdQ="#00000000", VVwC3K=True, searchCol=1)
   if not VVNx6Z:
    tot = "( %d of %d )" % (threadCounter, threadTotal)
    VVyGLE.VVgPDp(VVyGLE.VVfZxh() + "  " + FFUIPk(tot, VVP3bf))
    if threadErr: FFyMZt(VVyGLE, "Error while reading !", 2000)
    else  : FFyMZt(VVyGLE, "Cancelled", 1000)
  else:
   FF538m(self, "Could not get list from server !", title=bName)
 def VV8usR(self, mode, VVyGLE, title, txt, colList):
  cmd = colList[5]
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpNp5(self)
  if "chCm=" + cmd in decodedUrl:
   self.session.open(CCipAb)
  else:
   txt += "\n" + FFUIPk("More information is available if the channel is playing.", VVZD1o)
   FF6wpe(self, txt, title=title)
 def VVo2ut(self, mode, bName, catID, progBarObj):
  try:
   token, profile = self.VVKusK()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVQKYK, total_items, max_page_items, err = self.VV3e1j(mode, catID, 1, 1)
   progBarObj.VVjB0W(max_page_items)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVQKYK and total_items > -1 and max_page_items > -1:
    progBarObj.VVx0AF(total_items)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VV3e1j(mode, catID, page, counter)
     if err:
      progBarObj.VVcSmY()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVQKYK += list
      progBarObj.VVjB0W(len(list))
  except:
   pass
 def VV3e1j(self, mode, catID, page, counter):
  list  = []
  total_items = max_page_items = -1
  res, err = self.VVpguz(self.VVBZKs(mode, catID, page))
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict['js']
     total_items  = self.VVOGfk(CCQps6.VVDB0e(item, "total_items" ))
     max_page_items = self.VVOGfk(CCQps6.VVDB0e(item, "max_page_items" ))
     processChanName = CC3gUj()
     chList = tDict['js']['data']
     for item in chList:
      Id    = CCQps6.VVDB0e(item, "id"    )
      name   = CCQps6.VVDB0e(item, "name"   )
      tv_genre_id  = CCQps6.VVDB0e(item, "tv_genre_id" )
      number   = CCQps6.VVDB0e(item, "number"   ) or str(counter)
      logo   = CCQps6.VVDB0e(item, "logo"   )
      screenshot_uri = CCQps6.VVDB0e(item, "screenshot_uri" )
      cmd    = CCQps6.VVDB0e(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      picon   = logo or screenshot_uri
      counter += 1
      name = processChanName.VVZvBg(name)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVp09F(self, mode, bName, VVyGLE, title, txt, colList):
  FFpgNe(VVyGLE, boundFunction(self.VV8an5, mode, bName, VVyGLE, title, txt, colList), title="Adding Channels ...")
 def VV8an5(self, mode, bName, VVyGLE, title, txt, colList):
  bNameFile = CCQps6.VVOH83(bName)
  num  = 0
  path = VVGnNm + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVGnNm + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVyGLE.VVwPno():
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVMzGI(mode, row)
    chUrl = self.VVAtEj(mode, chCm, serCode, serId)
    chUrl = chUrl.replace("ffmpeg ", "")
    chUrl = chUrl.replace(":", "%3a")
    chUrl = self.VV1fL5(catID, stID, chNum) + chUrl.strip() + ":" + chName
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FFbSHG(os.path.basename(path))
  self.VVkNaC(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVOGfk(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVeRTR(self, mode, VVyGLE, title, txt, colList, forceZap=False):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVMzGI(mode, colList)
  url = self.VVhXO2(mode, chCm, serCode, serId)
  if not forceZap and self.VVTock(chName):
   FFyMZt(VVyGLE, "This is a marker!", 300)
  else:
   chUrl = self.VVAtEj(mode, chCm, serCode, serId)
   chUrl = chUrl.replace("ffmpeg ", "")
   chUrl = chUrl.replace(":", "%3a")
   chUrl = self.VV1fL5(catID, stID, chNum) + chUrl.strip() + ":" + chName
   FFY1uw(self, chUrl, VVda8V=False)
   self.session.open(CCuzJP, portalTableParam=(self, VVyGLE, mode))
 def VVMzGI(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName, catID, stID, chNum, chCm, serCode, serId, picUrl
class CCQps6(Screen, CCwWAx):
 VVXcMm = 0
 VVVHpX = 1
 VVk1T0 = 2
 VVCdAd = 3
 VVoXzl  = 4
 VVjlJR  = 5
 VVx7jT  = 6
 VVDuDc  = 7
 VV4ei3   = 8
 VVvMD3  = 9
 VVpv5c  = 10
 VVuvA7  = 11
 VV7E7W  = 12
 VVzBv1   = 13
 VV0sfY   = 14
 VV0MKY   = 15
 VVHHOO   = 16
 VVUb4y   = 17
 VVt3hg    = 0
 VVALAM   = 1
 VVSh8y   = 2
 VVMrA4   = 3
 VV002F  = 4
 VVT0JG   = 5
 VVU1SG   = 6
 VVvxVi  = 7
 VVnokx  = 8
 VVOMbA   = 9
 VV8MrB = 10
 VVv33U   = 11
 def __init__(self, session):
  self.skin, self.skinParam = FF87m3(VVseVH, 1100, 1050, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.VVyGLE  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVwgstData  = {}
  self.lastFindIptvName = ""
  CCwWAx.__init__(self)
  VVei97= self.VVnt3X()
  FFyw62(self, VVei97=VVei97)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  FFgNUr(self["myMenu"])
  FFhCiv(self)
  FFnMch(self)
 def VVnt3X(self):
  files = self.VVVkzz()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"    , "VVwgst_fromPlayList" ))
  tList.append(("IPTV Server Browser (from M3U File)"     , "VVwgst_fromM3u"  ))
  tList.append(("IPTV Server Browser (from Portal File)"    , "VVwgst_fromMac"  ))
  qUrl, iptvRef = self.VVYBp2()
  if qUrl:
   tList.append(("IPTV Server Browser (from Current Channel)"  , "VVwgst_fromCurrChan"  ))
  VVei97 = []
  if files:
   if self.VVyGLE:
    VVei97.append(("Add Current List to a New Bouquet"      , "VVP3Cc"  ))
    VVei97.append(VVhJ3E)
    VVei97.append(("Change Current List References to Unique Codes"   , "VVBhpv"))
    VVei97.append(("Change Current List References to Identical Codes"  , "VVtj2l_rows" ))
    VVei97.append(VVhJ3E)
    VVei97.append(("Share Reference with Satellite/C/T Channel"    , "VVBJBO" ))
   else:
    VVei97 += tList
    VVei97.append(VVhJ3E)
    VVei97.append(("Local IPTV Channels (Live)"        , "iptvTable_live"   ))
    VVei97.append(("Local IPTV Channels (All)"        , "iptvTable_all"   ))
    VVei97.append(VVhJ3E)
    VVei97.append(("Count Available IPTV Channels"       , "VVaD84"    ))
    VVei97.append(("Check Reference Codes Format"        , "VV6Xlh"   ))
    VVei97.append(("Check System Acceptable Reference Types"     , "VV6O8u"   ))
    VVei97.append(VVhJ3E)
    VVei97.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVpbs4"  ))
    VVei97.append(("Change ALL References to Matching Sat/C/T Channels"  , "VViFjs" ))
    VVei97.append(("Change ALL References to Unique Codes"     , "VVKv6C" ))
    VVei97.append(("Change ALL References to Identical Codes"     , "VVtj2l_all" ))
  if not self.VVyGLE:
   if not files:
    VVei97 += tList
   VVei97.append(VVhJ3E)
   VVei97.append(("Analyse m3u File"            , "VVZGj0"   ))
   VVei97.append(("Convert m3u File to Bouquet (from File Manager)"    , "VVGopB" ))
   VVei97.append(("Convert m3u File to Bouquet (from m3u File List)"    , "VVCMI9" ))
   VVei97.append(('Convert m3u File to Bouquet (Download from "Play Lists")'  , "VVX8B5" ))
   VVei97.append(VVhJ3E)
   VVei97.append(("Reload Channels and Bouquets"         , "VVxWxX"   ))
  return VVei97
 def VVhzQP(self, item):
  if item is not None:
   if   item == "VVP3Cc"   : FF5iHn(self, self.VVP3Cc, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVBhpv" : FFcSjz(self, boundFunction(FFpgNe, self.VVyGLE, self.VVBhpv ), "Change Current List References to Unique Codes ?")
   elif item == "VVtj2l_rows" : FFcSjz(self, boundFunction(FFpgNe, self.VVyGLE, self.VVtj2l   ), "Change Current List References to Identical Codes ?")
   elif item == "VVBJBO" : FFpgNe(self.VVyGLE, self.VVBJBO, title="Searching ...")
   elif item == "VVwgst_fromPlayList" : FFpgNe(self, boundFunction(self.VVLIcY, True), title="Searching ...")
   elif item == "VVwgst_fromM3u"  : FFpgNe(self, boundFunction(self.VV1GqB, 0), title="Searching ...")
   elif item == "VVwgst_fromMac"  : self.VVcTZn()
   elif item == "VVwgst_fromCurrChan" : self.VVVsPH_fromCurrChan()
   elif item == "iptvTable_live"   : FFpgNe(self, boundFunction(self.VV63Gw, self.VVDuDc ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFpgNe(self, boundFunction(self.VV63Gw, self.VVXcMm) , title="Loading Channels ...")
   elif item == "VVaD84"    : FFpgNe(self, self.VVaD84)
   elif item == "VV6Xlh"    : FFpgNe(self, self.VV6Xlh)
   elif item == "VV6O8u"   : FFpgNe(self, self.VV6O8u)
   elif item == "VVpbs4"  : self.VVpbs4()
   elif item == "VViFjs"  : FFcSjz(self, boundFunction(FFpgNe, self, self.VViFjs ), "Copy from existing Sat. Channel" )
   elif item == "VVKv6C" : FFcSjz(self, boundFunction(FFpgNe, self, self.VVKv6C ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVtj2l_all" : FFcSjz(self, boundFunction(FFpgNe, self, self.VVtj2l  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "VVZGj0"   : FFpgNe(self, boundFunction(self.VV1GqB, 1), title="Searching ...")
   elif item == "VVGopB" : self.VVGopB()
   elif item == "VVCMI9" : FFpgNe(self, boundFunction(self.VV1GqB, 2), title="Searching ...")
   elif item == "VVX8B5" : FFpgNe(self, boundFunction(self.VVLIcY, False), title="Searching ...")
   elif item == "VVxWxX"   : FFpgNe(self, boundFunction(CC3RQY.VVxWxX, self))
 def VVnr3G(self):
  global VV8CgR
  VV8CgR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVhzQP(item)
 def VV63Gw(self, mode):
  VVbelk = self.VVHvaI(mode)
  if VVbelk:
   VVY4BM = ("Current Service", self.VVZkVY , [])
   VVcWvO = ("Options"  , self.VVwaMx   , [])
   VVKois = ("Filter"   , self.VVqAVn    , [])
   VVkbh1  = ("Zap"   , self.VVRBGc   , [])
   VVsYEM = (""    , self.VVsF5v    , [])
   VVoSIN = (""    , self.VV0WQy     , [])
   VVVrwp = (""    , self.VVZl2l    , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVZOJU  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFed34(self, None, header=header, VVpuR3=VVbelk, VVZOJU=VVZOJU, VVEFlP=widths, VVQ020=22
     , VVkbh1=VVkbh1, VVY4BM=VVY4BM, VVcWvO=VVcWvO, VVKois=VVKois, VVsYEM=VVsYEM, VVoSIN=VVoSIN
     , VVCABW="#0a00292B", VVG1bZ="#0a002126", VVZHzf="#0a002126", VVjMdQ="#00000000", VVwC3K=True, searchCol=1)
  else:
   if mode == self.VVDuDc: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FF538m(self, err)
 def VV0WQy(self, VVyGLE, title, txt, colList):
  self.VVyGLE = VVyGLE
 def VVZl2l(self, VVyGLE):
  self.VVyGLE = None
 def VVwaMx(self, VVyGLE, title, txt, colList):
  VVei97= self.VVnt3X()
  FFrC6O(self, self.VVhzQP, title="IPTV Tools", VVei97=VVei97)
 def VVqAVn(self, VVyGLE, title, txt, colList):
  VVei97 = []
  VVei97.append(("All"         , "all"   ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Prefix of Selected Channel"   , "sameName" ))
  VVei97.append(("Suggest Words from Selected Channel" , "partName" ))
  VVei97.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Live TV"        , "live"  ))
  VVei97.append(("VOD"         , "vod"   ))
  VVei97.append(("Series"        , "series"  ))
  VVei97.append(("Uncategorised"      , "uncat"  ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Video"        , "video"  ))
  VVei97.append(("Audio"        , "audio"  ))
  VVei97.append(VVhJ3E)
  VVei97.append(("MKV"         , "MKV"   ))
  VVei97.append(("MP4"         , "MP4"   ))
  VVei97.append(("MP3"         , "MP3"   ))
  VVei97.append(("AVI"         , "AVI"   ))
  VVei97.append(("FLV"         , "FLV"   ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVGiTs()
  if bNames:
   bNames.sort()
   VVei97.append(VVhJ3E)
   for item in bNames:
    VVei97.append((item, "__b__" + item))
  filterObj = CC08vA(self)
  filterObj.VVJwRd(VVei97, VVei97, boundFunction(self.VVrpvE, VVyGLE))
 def VVrpvE(self, VVyGLE, item=None):
  prefix = VVyGLE.VVGmDB(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVXcMm, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVVHpX , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVk1T0 , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVCdAd , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVDuDc  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VV4ei3   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVvMD3  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVpv5c  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVuvA7  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VV7E7W  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVzBv1   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VV0sfY   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VV0MKY   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVHHOO   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVUb4y   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVx7jT  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVoXzl  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVjlJR  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVk1T0:
   VVei97 = []
   chName = VVyGLE.VVGmDB(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVei97.append((item, item))
    if not VVei97 and chName:
     VVei97.append((chName, chName))
    FFrC6O(self, boundFunction(self.VVthSO_partOfName, title), title="Words from Current Selection", VVei97=VVei97)
   else:
    VVyGLE.VVPKXQ("Invalid Channel Name")
  else:
   words, asPrefix = CC08vA.VVo2GC(words)
   if not words and mode in (self.VVoXzl, self.VVjlJR):
    FFyMZt(self.VVyGLE, "Incorrect filter", 2000)
   else:
    FFpgNe(self.VVyGLE, boundFunction(self.VVaGrw, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVthSO_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFpgNe(self.VVyGLE, boundFunction(self.VVaGrw, self.VVk1T0, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VV66ZH(txt):
  return "#f#11ffff00#" + txt
 def VVaGrw(self, mode, words, asPrefix, title):
  VVbelk = self.VVHvaI(mode=mode, words=words, asPrefix=asPrefix)
  if VVbelk : self.VVyGLE.VVwB4B(VVbelk, title)
  else  : self.VVyGLE.VVPKXQ("Not found")
 def VVHvaI(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVbelk = []
  files  = self.VVVkzz()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFUy6Y(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VV9lF6 = span.group(1)
    else : VV9lF6 = ""
    VV9lF6_lCase = VV9lF6.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVTock(chName): chNameMod = self.VV66ZH(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VV9lF6, chType, refCode, url)
     ok = False
     tUrl = FFFkUX(url).lower()
     if mode == self.VVXcMm       : ok = True
     elif mode == self.VVx7jT       : ok = True
     elif mode == self.VVuvA7:
      if CCQps6.VVJZCV(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VV7E7W:
      if CCQps6.VVJZCV(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVDuDc:
      if CCQps6.VVJZCV(tUrl, compareType="live")  : ok = True
     elif mode == self.VV4ei3:
      if CCQps6.VVJZCV(tUrl, compareType="movie") : ok = True
     elif mode == self.VVvMD3:
      if CCQps6.VVJZCV(tUrl, compareType="series") : ok = True
     elif mode == self.VVpv5c:
      if CCQps6.VVJZCV(tUrl, compareType="")   : ok = True
     elif mode == self.VVzBv1:
      if CCQps6.VVJZCV(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VV0sfY:
      if CCQps6.VVJZCV(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VV0MKY:
      if CCQps6.VVJZCV(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVHHOO:
      if CCQps6.VVJZCV(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVUb4y:
      if CCQps6.VVJZCV(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVVHpX:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVk1T0:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVCdAd:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVoXzl:
      if words[0] == VV9lF6_lCase:
       ok = True
     elif mode == self.VVjlJR:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VVbelk.append(row)
      chNum += 1
  if VVbelk and mode == self.VVx7jT:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VVbelk)
   for item in VVbelk:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VVbelk = newRows
  return VVbelk
 def VVP3Cc(self, bName):
  if bName:
   FFpgNe(self.VVyGLE, boundFunction(self.VVJGDp, bName), title="Adding Channels ...")
 def VVJGDp(self, bName):
  num = 0
  path = VVGnNm + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVGnNm + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVyGLE.VVwPno():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFfEyW(row[1]))
    totChange += 1
  FFbSHG(os.path.basename(path))
  self.VVkNaC(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVpbs4(self):
  txt = "Stream Type "
  VVei97 = []
  VVei97.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVei97.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVei97.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVei97.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVei97.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVei97.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFrC6O(self, self.VV37ir, title="Change Reference Types to:", VVei97=VVei97)
 def VV37ir(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVOn66("1"   )
   elif item == "RT_4097" : self.VVOn66("4097")
   elif item == "RT_5001" : self.VVOn66("5001")
   elif item == "RT_5002" : self.VVOn66("5002")
   elif item == "RT_8192" : self.VVOn66("8192")
   elif item == "RT_8193" : self.VVOn66("8193")
 def VVOn66(self, rType):
  FFcSjz(self, boundFunction(FFpgNe, self, boundFunction(self.VVMQ7O, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVMQ7O(self, refType):
  totChange = 0
  files  = self.VVVkzz()
  if files:
   for path in files:
    txt = FFUy6Y(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFbSHG(os.path.basename(path))
  self.VVkNaC(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVaD84(self):
  totFiles = 0
  files  = self.VVVkzz()
  if files:
   totFiles = len(files)
  totChans = 0
  VVbelk = self.VVHvaI()
  if VVbelk:
   totChans = len(VVbelk)
  FF6wpe(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VV6Xlh(self):
  files  = self.VVVkzz()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFUy6Y(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVbnJx
   else    : color = VVEiu9
   totInvalid = FFUIPk(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFUIPk("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FF6wpe(self, txt, title="Check IPTV References")
 def VV6O8u(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVGnNm + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFbSHG(os.path.basename(path))
  FF3PkJ()
  acceptedList = []
  VVsIrB = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVsIrB:
   VVADZJ = FFZTo6(VVsIrB)
   if VVADZJ:
    for service in VVADZJ:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVGnNm + userBName
  bFile = VVGnNm + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFgzF5("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFgzF5("rm -f '%s'" % path)
  os.system(cmd)
  FF3PkJ()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVbnJx
    else     : res, color = "No" , VVEiu9
    txt += "    %s\t: %s\n" % (item, FFUIPk(res, color))
   FF6wpe(self, txt, title=title)
  else:
   txt = FF538m(self, "Could not complete the test on your system!", title=title)
 def VViFjs(self):
  lameDbChans = CC3RQY.VVeovQ(self, CC3RQY.VVo5KG)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVVkzz():
    toSave = False
    txt = FFUy6Y(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVkNaC(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FF538m(self, 'No channels in "lamedb" !')
 def VVKv6C(self):
  files  = self.VVVkzz()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFDyYj(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVIuBM(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVkNaC(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVBhpv(self):
  iptvRefList = []
  files  = self.VVVkzz()
  if files:
   for path in files:
    txt = FFUy6Y(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVyGLE.VVTtN2(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVIuBM(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVVkzz()
  if files:
   for path in files:
    lines = FFDyYj(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVkNaC(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVIuBM(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVtj2l(self):
  list = None
  if self.VVyGLE:
   list = []
   for row in self.VVyGLE.VVwPno():
    list.append(row[4] + row[5])
  files  = self.VVVkzz()
  totChange = 0
  if files:
   for path in files:
    lines = FFDyYj(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVkNaC(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVkNaC(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FF3PkJ()
   if refreshTable and self.VVyGLE:
    VVbelk = self.VVHvaI()
    if VVbelk and self.VVyGLE:
     self.VVyGLE.VVwB4B(VVbelk, self.tableTitle)
     self.VVyGLE.VVPKXQ(txt)
   FF6wpe(self, txt, title=title)
  else:
   FFRg6s(self, "No changes.")
 def VVGiTs(self):
  files = self.VVVkzz()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with open(path, "r") as f:
     span = iSearch(r"#NAME\s+(.*)", f.readline(), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VVFg3t = FF3Zym()
    if VVFg3t:
     for b in VVFg3t:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVVkzz(self):
  return CCQps6.VVpNPN(self)
 @staticmethod
 def VVpNPN(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVGnNm + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFUy6Y(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVsF5v(self, VVyGLE, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFFkUX(colList[5]).strip()
  ndx = txt.find("Ref.")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "Row Number\t: %d of %d\n\n%s" % (VVyGLE.VVKtZk() + 1, VVyGLE.VV6WUd(), txt)
  CCipAb.VVqVFq(self, chName, refCode, url, txt)
 def VVRBGc(self, VVyGLE, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  self.VVlxE5(VVyGLE, chName, chUrl, "localIptv")
 def VVi7kJ(self, mode, VVyGLE, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVKMwa(mode, colList)
  self.VVlxE5(VVyGLE, chName, chUrl, mode)
 def VVlxE5(self, VVyGLE, chName, chUrl, playerFlag):
  chName = FFfEyW(chName)
  if not self.VVTock(chName):
   FFY1uw(self, chUrl, VVda8V=False)
   self.session.open(CCuzJP, portalTableParam=(self, VVyGLE, playerFlag))
  else:
   FFyMZt(VVyGLE, "This is a marker!", 300)
 @staticmethod
 def VVTock(chName):
  mark = ("--", "__", "==", "##", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVZkVY(self, VVyGLE, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpNp5(self)
  if refCode:
   bName = FFjvet()
   if any(x in origUrl for x in ("mode=", "&end=")):
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFMJnf(refCode, origUrl, chName) }
   VVyGLE.VV8pUN_partial(colDict, VVdtwB=True)
 def VVGopB(self):
  self.session.open(CCyaF0)
  self.close()
 def VV1GqB(self, m3uMode):
  lines = FFofdg("find / %s -iname '*.m3u' | grep -i '.m3u'" % FFRwKj(1))
  if lines:
   lines.sort()
   VVei97 = []
   for line in lines:
    VVei97.append((line, line))
   if   m3uMode == 0 : title = "Browse Server from M3U URLs"
   elif m3uMode == 1 : title = "Analyse M3U File:"
   else    : title = "Convert M3U File to Bouquet"
   if m3uMode in [0, 2]: VVQixJ = ("All to Playlist", self.VVmdB5)
   else    : VVQixJ = None
   OKBtnFnc = boundFunction(self.VV3ClE, m3uMode, title)
   VVdFS8 = ("Show Full Path", self.VVcYaz)
   FFrC6O(self, None, title=title, VVei97=VVei97, OKBtnFnc=OKBtnFnc, VVdFS8=VVdFS8, VVQixJ=VVQixJ)
  else:
   FF538m(self, 'No "m3u" files found.')
 def VVcYaz(self, VVQlLPObj, url):
  FF6wpe(self, url, title="Full Path")
 def VV3ClE(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if   m3uMode == 0 : FFpgNe(menuInstance, boundFunction(self.VVWSws, title, path))
   elif m3uMode == 1 : FFpgNe(menuInstance, boundFunction(self.VVZGj0, title, path))
   else    : self.VVPCJQ(menuInstance, path)
 def VVmdB5(self, VVQlLPObj, item=None):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVQlLPObj.VVei97):
    path = item[1]
    if fileExists(path):
     with open(path, "r") as f:
      for line in f:
       url = self.VVdbUc(line)
       if url:
        if not url in pList : pList.append(url)
        else    : dupl += 1
        break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    pListF = "%sPlaylist_%s.txt" % (FFGYYB(CFG.exportedTablesPath.getValue()), FFAH5e())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVQlLPObj.VVei97)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FF6wpe(self, txt, title=title)
   else:
    FF538m(self, "Could not obtain URLs from this file list !", title=title)
 def VVZGj0(self, title, path):
  if fileExists(path):
   txt = FFUy6Y(path)
   totChan   = 0
   totLive   = 0
   totVod   = 0
   totSeries  = 0
   totUncat  = 0
   totVideo  = 0
   totAudio  = 0
   for match in iFinditer(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?((.+)(:[^:\/]+$)|.+)", txt, IGNORECASE):
    totChan += 1
    chName  = match.group(1).strip()
    fullUrl  = match.group(2).strip()
    urlPart1 = match.group(3)
    if urlPart1 : tUrl = urlPart1
    else  : tUrl = fullUrl
    tUrl = FFFkUX(tUrl).lower()
    chType, host, username, password, streamId, chName = CCQps6.VVJZCV(tUrl)
    if   chType == "live" : totLive += 1
    elif chType == "movie" : totVod += 1
    elif chType == "series" : totSeries += 1
    else     : totUncat += 1
    aud_vid = CCQps6.VVJZCV(tUrl, getAudVid=True)
    if   aud_vid == "vid" : totVideo += 1
    elif aud_vid == "aud" : totAudio += 1
   txt = ""
   txt += FFUIPk("File:\n", VVbHZ1)
   txt += "    %s\n"    % path
   txt += "\n"
   txt += FFUIPk("Channels:\n", VVbHZ1)
   txt += "    Total\t: %d\n" % totChan
   txt += "\n"
   txt += FFUIPk("Category:\n", VVbHZ1)
   txt += "    Live\t: %d\n" % totLive
   txt += "    VOD\t: %d\n" % totVod
   txt += "    Series\t: %d\n" % totSeries
   txt += "    Uncat.\t: %d\n" % totUncat
   txt += "\n"
   txt += FFUIPk("Content:\n", VVbHZ1)
   txt += "    Video\t: %d\n" % totVideo
   txt += "    Audio\t: %d\n" % totAudio
   txt += "\n"
   FF6wpe(self, txt, title="M3U File Analysis")
  else:
   FF538m(SELF, "Cannot open file :\n\n%s" % path, title=title)
   return
 def VVLIcY(self, isBrowseServer):
  lines = FFofdg('find / %s -iname "*playlist*" | grep -i ".txt"' % FFRwKj(1))
  if lines:
   lines.sort()
   VVei97 = []
   for line in lines:
    VVei97.append((line, line))
   OKBtnFnc = boundFunction(self.VVPyof, isBrowseServer)
   FFrC6O(self, None, title="Select Playlist File", VVei97=VVei97, width=1200, OKBtnFnc=OKBtnFnc)
  else:
   FF4LjO(self, "( playlist.txt  or  playlists.txt )")
 def VVPyof(self, isBrowseServer, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   VVei97 = []
   lines = FFDyYj(path)
   for line in lines:
    line = line.strip()
    span = iSearch(r"http.+php.+username=.+password=.+", line, IGNORECASE)
    if span:
     VVei97.append((line, line))
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFGYYB(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      line = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
      VVei97.append((line, line))
   if VVei97:
    if isBrowseServer : title = "Select Server URL  (Total = %d)" % len(VVei97)
    else    : title = "Convert to Bouquet"
    OKBtnFnc  = boundFunction(self.VVAceK, isBrowseServer, title)
    VVmf6o  = ("Home Menu"  , FFW3h5)
    VVdFS8  = ("Show URL"  , self.VVp6Gw)
    VVQixJ   = ("Check & Filter" , boundFunction(self.VVARvV, path, menuInstance, isBrowseServer))
    FFrC6O(self, None, title=title, VVei97=VVei97, width=1200, OKBtnFnc=OKBtnFnc, VVmf6o=VVmf6o, VVdFS8=VVdFS8, VVQixJ=VVQixJ)
   else:
    FF538m(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVp6Gw(self, VVQlLPObj, url):
  FF6wpe(self, url, title="URL")
 def VVAceK(self, isBrowseServer, title, item=None):
  if item:
   menuInstance, txt, url, ndx = item
   if isBrowseServer:
    FFpgNe(menuInstance, boundFunction(self.VV2131, title, url), title="Checking Server ...")
   else:
    FFcSjz(self, boundFunction(FFpgNe, menuInstance, boundFunction(self.VVWq9J, menuInstance, url), title="Downloading ..."), "Download m3u file from this URL ?\n\n%s" % url, title=title)
 def VVWq9J(self, menuInstance, url):
  path, err = FFOwIM(url, "ajpanel_tmp.m3u", timeout=3)
  title = "Download Problem"
  if err:
   FF538m(self, err, title=title)
  else:
   if fileExists(path):
    txt = FFUy6Y(path)
    if '{"user_info":{"auth":0}}' in txt:
     FF538m(self, "Unauthorized", title=title)
     os.system(FFgzF5("rm -f '%s'" % path))
     return
   self.VVPCJQ(menuInstance, path)
 def VVBJBO(self):
  curChName = self.VVyGLE.VVGmDB(1)
  curRefCode = self.VVyGLE.VVGmDB(4)
  curUrl  = self.VVyGLE.VVGmDB(5)
  FFyMZt(self, "Loading Channels ...")
  tableRows = []
  lameDbChans = CC3RQY.VVeovQ(self, CC3RQY.VVLmlD, VVAPVZ=False, VVtOwU=False)
  if lameDbChans:
   curCh = curChName.lower().replace(" hd", "").replace(" fm", "").replace("4k", "")
   for refCode in lameDbChans:
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCsPD3.VVNsLy(chName.lower(), curCh)
    if ratio > 50:
     tableRows.append((chName, FFe0Vt(sat), refCode.replace("_", ":")))
  FFyMZt(self)
  title = "Share Reference with Satellite/C/T Channel"
  if tableRows:
   tableRows.sort(key=lambda x: x[0].lower())
   VVkbh1  = ("Share Sat/C/T Ref.", boundFunction(self.VVR5iq, title, curChName, curRefCode, curUrl) , [])
   header   = ("Name" , "Sat"  , "Reference" )
   widths   = (34  , 33  , 33   )
   FFed34(self, None, title=title, header=header, VVpuR3=tableRows, VVEFlP=widths, VVQ020=24, VVkbh1=VVkbh1, VVCABW="#0a00112B", VVG1bZ="#0a001126", VVZHzf="#0a001126", VVjMdQ="#00000000")
  else:
   FF538m(self, "No similar names found !", title)
 def VVR5iq(self, newtitle, curChName, curRefCode, curUrl, VVyGLE, title, txt, colList):
  VVyGLE.cancel()
  newChName = colList[0]
  newRefCode = colList[2]
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  FFpgNe(self.VVyGLE, boundFunction(self.VVKKa9, data, ques, newtitle))
 def VVKKa9(self, data, ques, title):
  FFcSjz(self.VVyGLE, boundFunction(FFpgNe, self.VVyGLE, boundFunction(self.VVaWNj, data)), ques, title=title, VV5nHT=True)
 def VVaWNj(self, data):
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  if curFullUrl and newFullUrl:
   for path in self.VVVkzz():
    txt = FFUy6Y(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FF3PkJ()
    newRow = []
    for i in range(6):
     newRow.append(self.VVyGLE.VVGmDB(i))
    newRow[4] = newRefCode
    done = self.VVyGLE.VVQ7gV(newRow)
    FFRg6s(self, "Done", title=title)
   else:
    FF538m(self, "Not found in IPTV files !", title=title)
  else:
   FF538m(self, "Could not read channel info !", title=title)
 def VVARvV(self, path, parentMenuInstance, isBrowseServer, menuInstance, url):
  FFpgNe(menuInstance, boundFunction(self.VVdLOD, path, parentMenuInstance, isBrowseServer, menuInstance), title="Filtering Servers ...")
 def VVdLOD(self, path, parentMenuInstance, isBrowseServer, menuInstance):
  urlList = []
  for ndx, item in enumerate(menuInstance.VVei97):
   qUrl = self.VVl5aH(self.VVt3hg, item[0])
   txt, err = self.VVBg9e(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVDB0e(item, "auth") == "0":
       urlList.append(qUrl)
    except:
     pass
  title = "Authorized Servers"
  if urlList:
   totChk = len(menuInstance.VVei97)
   totAuth = len(urlList)
   if not totAuth == totChk:
    newPath = path + "_OK_%s.txt" % FFAH5e()
    with open(newPath, "w") as f:
     for item in urlList:
      f.write("%s\n" % item)
    self.VVLIcY(isBrowseServer)
    txt = ""
    txt += "Checked\t: %d\n"  %  totChk
    txt += "Authorized\t: %s\n\n" %  FFUIPk(str(totAuth), VVbnJx)
    txt += "Output File:\n%s\n " %  FFUIPk(newPath, VVLIgE)
    FF6wpe(self, txt, title=title)
    menuInstance.close()
    parentMenuInstance.close()
   else:
    FFRg6s(self, "All URLs are authorized.", title=title)
  else:
   FF538m(self, "No authorized URL found !", title=title)
 def VVPCJQ(self, parentInstant, path):
  files = CCQps6.VVpNPN(self, atLeastOne=True)
  if files: exitCurWin = False
  else : exitCurWin = True
  CCQps6.VVUYlo(parentInstant, path, exitCurWin)
 @staticmethod
 def VVUYlo(SELF, path, exitCurWin):
  FFcSjz(SELF, boundFunction(FFpgNe, SELF, boundFunction(CCQps6.VVEAV6, SELF, path, exitCurWin), title="Converting ...")
    , "Convert file to bouquet ?\n\n%s" % path, title="Convert m3u file")
 @staticmethod
 def VVEAV6(SELF, path, exitCurWin):
  SID = TSID = ONID = 0
  MAX = 65535
  title = "Convert m3u File to Bouquet"
  if not fileExists(path):
   FF538m(SELF, "Cannot open file :\n\n%s" % path, title=title)
   return
  bName  = os.path.basename(path)
  bName  = os.path.splitext(bName)[0]
  bName   = CCQps6.VVOH83(bName)
  bName  = "IPTV_" + bName
  bFileName = "userbouquet.%s.tv" % bName
  if fileExists(VVGnNm + bFileName):
   while True:
    SID += 1
    tmpBName = "%s_%d" % (bName, SID)
    bFileName = "userbouquet.%s.tv" % tmpBName
    if not fileExists(VVGnNm + bFileName):
     bName = tmpBName
     break
  txt = FFUy6Y(path)
  pattern = r"#EXTINF.+,(.+)\n(.+)"
  span = iSearch(r"#EXTINF.+,(.+)\n(.+)", txt, IGNORECASE)
  if span:
   with open(VVGnNm + bFileName, "w") as f:
    totChan = 0
    f.write("#NAME %s\n" % bName.replace("IPTV_", "IPTV - ", 1))
    for match in iFinditer(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?(.+)", txt, IGNORECASE):
     TSID += 1
     if TSID > MAX:
      TSID = MAX
      ONID += 1
      if ONID > MAX:
       ONID = 0
     chName = match.group(1).strip()
     url  = FFERNa(match.group(2).strip())
     rType = CFG.iptvAddToBouquetRefType.getValue()
     refCode = "%s:0:1:%s:%s:%s:0:0:0:0:" % (rType, hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:])
     line1 = "#SERVICE %s%s\n" % (refCode.upper(), url)
     line2 = "#DESCRIPTION %s\n" % chName
     f.write(line1 + line2)
     totChan += 1
   FFbSHG(bFileName)
   FF3PkJ()
   FFRg6s(SELF, 'New Bouquet = %s\n\nTotal Channels = %d' % (bName, totChan), title=title)
  else:
   FF538m(SELF, "No channels found in file (or invalid file format) !\n\n%s" % path, title=title)
  if exitCurWin:
   SELF.close()
 @staticmethod
 def VVBg9e(url, timeout=3):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   res = res.read().decode("UTF-8")
   if res:
    if "<!DOCTYPE html>" in res : return "", "Incorrect data format from server !"
    else      : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 def VVKVTA(self, url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     key, val = part.split("=")
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVJZCV(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = parts[1]
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVl5aH(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVKVTA(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVt3hg   : return "%s"            % url
  elif mode == self.VVALAM   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVSh8y   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVMrA4  : return "%s&action=get_series_categories"     % url
  elif mode == self.VV002F : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVT0JG   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVU1SG    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVvxVi  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVnokx  : return "%s&action=get_simple_data_table&stream_id=%s"  % (url, Id)
  elif mode == self.VVOMbA  : return "%s&action=get_short_epg&stream_id=%s"    % (url, Id)
  elif mode == self.VV8MrB : return "%s&action=get_short_epg&stream_id=%s&limit=%s" % (url, Id, limit)
  elif mode == self.VVv33U   : return "%s&action=get_vod_info&vod_id=%s"     % (url, Id)
 @staticmethod
 def VVDB0e(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFbrdA(int(val))
    elif is_base64 : val = FFhawA(val)
    elif isToHHMMSS : val = FFhCAD(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVWSws(self, title, path):
  if fileExists(path):
   qUrl = ""
   with open(path, "r") as f:
    for line in f:
     qUrl = self.VVdbUc(line)
     if qUrl:
      break
   if qUrl : self.VV2131(title, qUrl)
   else : FF538m(self, "No valid Server URL found in:\n\n%s" % path, title=title)
  else:
   FF538m(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVVsPH_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVYBp2()
  if qUrl:
   host, mac, isPortalUrl = self.VVl1CY(iptvRef)
   if isPortalUrl:
    if host and mac : self.VVVsPH(self, host, mac)
    else   : FF538m(self, "Error in current channel URL/MAC !", title=title)
   else:
    FFpgNe(self, boundFunction(self.VV2131, title, qUrl), title="Checking Server ...")
  else:
   FF538m(self, "Error in current channel URL !", title=title)
 def VVYBp2(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpNp5(self)
  qUrl = self.VVdbUc(decodedUrl)
  return qUrl, iptvRef
 def VVdbUc(self, url):
  if url.startswith("#"):
   return ""
  url = url.lstrip(" /").rstrip(" /")
  if not url.startswith("http://"):
   url = "http://" + url
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  path = res.path.strip("/")
  host = scheme + "://" +  netloc
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) >= 2 : return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else    : return ""
 def VV2131(self, title, url):
  self.VVwgstData = {}
  qUrl = self.VVl5aH(self.VVt3hg, url)
  txt, err = self.VVBg9e(qUrl)
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVwgstData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVwgstData["username"    ] = self.VVDB0e(item, "username"        )
    self.VVwgstData["password"    ] = self.VVDB0e(item, "password"        )
    self.VVwgstData["message"    ] = self.VVDB0e(item, "message"        )
    self.VVwgstData["auth"     ] = self.VVDB0e(item, "auth"         )
    self.VVwgstData["status"    ] = self.VVDB0e(item, "status"        )
    self.VVwgstData["exp_date"    ] = self.VVDB0e(item, "exp_date"    , isDate=True )
    self.VVwgstData["is_trial"    ] = self.VVDB0e(item, "is_trial"        )
    self.VVwgstData["active_cons"   ] = self.VVDB0e(item, "active_cons"       )
    self.VVwgstData["created_at"   ] = self.VVDB0e(item, "created_at"   , isDate=True )
    self.VVwgstData["max_connections"  ] = self.VVDB0e(item, "max_connections"      )
    self.VVwgstData["allowed_output_formats"] = self.VVDB0e(item, "allowed_output_formats"    )
    lst = []
    key = "allowed_output_formats"
    if key in item:
     for item in item[key]:
      lst.append(str(item))
     self.VVwgstData[key] = lst
    item = tDict["server_info"]
    self.VVwgstData["url"    ] = self.VVDB0e(item, "url"        )
    self.VVwgstData["port"    ] = self.VVDB0e(item, "port"        )
    self.VVwgstData["https_port"  ] = self.VVDB0e(item, "https_port"      )
    self.VVwgstData["server_protocol" ] = self.VVDB0e(item, "server_protocol"     )
    self.VVwgstData["rtmp_port"   ] = self.VVDB0e(item, "rtmp_port"       )
    self.VVwgstData["timezone"   ] = self.VVDB0e(item, "timezone"       )
    self.VVwgstData["timestamp_now"  ] = self.VVDB0e(item, "timestamp_now"  , isDate=True )
    self.VVwgstData["time_now"   ] = self.VVDB0e(item, "time_now"       )
    VVei97 = []
    VVei97.append(("Live"     , "serverLive"  ))
    VVei97.append(("VOD"     , "serverVod"  ))
    VVei97.append(("Series (Seasons)"  , "serverSeries" ))
    VVei97.append(VVhJ3E)
    VVei97.append(("User/Server Info." , "serverInfo"  ))
    OKBtnFnc  = self.VVwgstOptions
    VVmf6o  = ("Home Menu", FFW3h5)
    FFrC6O(self, None, title="IPTV Server Resources", VVei97=VVei97, OKBtnFnc=OKBtnFnc, VVmf6o=VVmf6o)
   else:
    err = "Could not get data from server !"
  if err:
   FF538m(self, err, title=title)
  FFyMZt(self)
 def VVwgstOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "serverLive" : FFpgNe(menuInstance, boundFunction(self.VVcBJO, self.VVALAM , title=title), title=wTxt)
   elif ref == "serverVod"  : FFpgNe(menuInstance, boundFunction(self.VVcBJO, self.VVSh8y , title=title), title=wTxt)
   elif ref == "serverSeries" : FFpgNe(menuInstance, boundFunction(self.VVcBJO, self.VVMrA4, title=title), title=wTxt)
   elif ref == "serverInfo" : FFpgNe(menuInstance, boundFunction(self.VV6kWa          , title=title), title=wTxt)
 def VV6kWa(self, title):
  rows = []
  for key, val in self.VVwgstData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VV1DDw = ("Home Menu", FFW3h5, [])
  header   = ("Num", "User/Server" , "Subject" , "Value" )
  widths   = (0 , 15   , 35  , 50  )
  FFed34(self, None, title=title, header=header, VVpuR3=rows, VVEFlP=widths, VVQ020=26, VV1DDw=VV1DDw, VVCABW="#0a00292B", VVG1bZ="#0a002126", VVZHzf="#0a002126", VVjMdQ="#00000000", searchCol=2)
 def VVvn0j(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CC3gUj()
    if mode == self.VVT0JG:
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVDB0e(item, "num"         )
      name     = self.VVDB0e(item, "name"        )
      stream_id    = self.VVDB0e(item, "stream_id"       )
      stream_icon    = self.VVDB0e(item, "stream_icon"       )
      epg_channel_id   = self.VVDB0e(item, "epg_channel_id"      )
      added     = self.VVDB0e(item, "added"    , isDate=True )
      is_adult    = self.VVDB0e(item, "is_adult"       )
      category_id    = self.VVDB0e(item, "category_id"       )
      name = processChanName.VVZvBg(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVU1SG:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVDB0e(item, "num"         )
      name    = self.VVDB0e(item, "name"        )
      stream_id   = self.VVDB0e(item, "stream_id"       )
      stream_icon   = self.VVDB0e(item, "stream_icon"       )
      added    = self.VVDB0e(item, "added"    , isDate=True )
      is_adult   = self.VVDB0e(item, "is_adult"       )
      category_id   = self.VVDB0e(item, "category_id"       )
      container_extension = self.VVDB0e(item, "container_extension"     ) or "mp4"
      name = processChanName.VVZvBg(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVvxVi:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVDB0e(item, "num"        )
      name    = self.VVDB0e(item, "name"       )
      series_id   = self.VVDB0e(item, "series_id"      )
      cover    = self.VVDB0e(item, "cover"       )
      genre    = self.VVDB0e(item, "genre"       )
      episode_run_time = self.VVDB0e(item, "episode_run_time"    )
      category_id   = self.VVDB0e(item, "category_id"      )
      container_extension = self.VVDB0e(item, "container_extension"    ) or "mp4"
      name = processChanName.VVZvBg(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVcBJO(self, mode, title):
  qUrl = self.VVl5aH(mode, self.VVwgstData["playListURL"])
  txt, err = self.VVBg9e(qUrl)
  if not err:
   list = []
   err  = ""
   try:
    hideAdult = CFG.hideIptvServerAdultWords.getValue()
    tDict = jLoads(txt)
    if tDict:
     processChanName = CC3gUj()
     for item in tDict:
      category_id  = self.VVDB0e(item, "category_id"  )
      category_name = self.VVDB0e(item, "category_name" )
      parent_id  = self.VVDB0e(item, "parent_id"  )
      category_name = processChanName.VVKpqG(category_name)
      if category_name:
       list.append((category_name, category_id, parent_id))
   except:
    err = "Cannot parse received data !"
  else:
   FF538m(self, err, title=title)
  if err:
   FF538m(self, err, title=title)
  elif list:
   list.sort(key=lambda x: x[0].lower())
   if   mode == self.VVALAM  : okTitle, fName, fMode = "Show Channels", "Live" , self.VVT0JG
   elif mode == self.VVSh8y  : okTitle, fName, fMode = "Show Channels", "VOD" , self.VVU1SG
   elif mode == self.VVMrA4 : okTitle, fName, fMode = "Show List"  , "Series" , self.VVvxVi
   VVcWvO = ("Find %s Name" % fName, boundFunction(self.VVdTAr, fMode), [])
   VVkbh1  = (okTitle, boundFunction(self.VVR1vR, mode)  , [])
   VV1DDw = ("Home Menu"   , FFW3h5        , [])
   header   = ("Category", "catID" , "ParentID" )
   widths   = (100   , 0  , 0    )
   FFed34(self, None, title=title, header=header, VVpuR3=list, VVEFlP=widths, VVQ020=30, VV1DDw=VV1DDw, VVcWvO=VVcWvO, VVkbh1=VVkbh1, VVCABW="#0a00292B", VVG1bZ="#0a002126", VVZHzf="#0a002126", VVjMdQ="#00000000")
  else:
   FF538m(self, "No list from server !", title=title)
  FFyMZt(self)
 def VVR1vR(self, mode, VVyGLE, title, txt, colList):
  title = colList[1]
  FFpgNe(VVyGLE, boundFunction(self.VV8sAX, mode, VVyGLE, title, txt, colList), title="Downloading ...")
 def VV8sAX(self, mode, VVyGLE, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title  = bName
  if   mode == self.VVALAM  : mode, title = self.VVT0JG  , "Live = %s" % title
  elif mode == self.VVSh8y  : mode, title = self.VVU1SG  , "VOD = %s" % title
  elif mode == self.VVMrA4 : mode, title = self.VVvxVi , "Series = %s" % title
  qUrl  = self.VVl5aH(mode, self.VVwgstData["playListURL"], catID)
  txt, err = self.VVBg9e(qUrl)
  list  = []
  if not err and mode in (self.VVT0JG, self.VVU1SG, self.VVvxVi):
   list, err = self.VVvn0j(mode, txt)
  if err:
   FF538m(self, err, title=title)
  elif list:
   VV1DDw  = ("Home Menu"   , FFW3h5            , [])
   if mode == self.VVT0JG:
    VVkbh1  = ("Play"    , boundFunction(self.VVi7kJ, mode)    , [])
    VVsYEM = (""     , boundFunction(self.VVl6cO, mode)    , [])
    VVY4BM = ("Download PIcons" , boundFunction(self.VVV7aR, mode)    , [])
    VVcWvO = ("Add ALL to Bouquet" , boundFunction(self.VVoHBW, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVZOJU  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVU1SG:
    VVkbh1  = ("Play"    , boundFunction(self.VVi7kJ, mode)    , [])
    VVsYEM = (""     , boundFunction(self.VVl6cO, mode)    , [])
    VVY4BM = ("Download PIcons" , boundFunction(self.VVV7aR, mode)    , [])
    VVcWvO = ("Add ALL to Bouquet" , boundFunction(self.VVoHBW, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVZOJU  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVvxVi:
    VVkbh1  = ("Show Seasons", boundFunction(self.VVsDL4, mode), [])
    VVsYEM = ("", boundFunction(self.VVlbZz, mode), [])
    VVY4BM = None
    VVcWvO = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVZOJU  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFed34(self, None, title=title, header=header, VVpuR3=list, VVZOJU=VVZOJU, VVEFlP=widths, VVQ020=26, VVkbh1=VVkbh1, VV1DDw=VV1DDw, VVY4BM=VVY4BM, VVcWvO=VVcWvO, VVsYEM=VVsYEM, VVCABW="#0a00292B", VVG1bZ="#0a002126", VVZHzf="#0a002126", VVjMdQ="#00000000", VVwC3K=True, searchCol=1)
  else:
   FF538m(self, "No Channels found !", title=title)
  FFyMZt(self)
 def VVsDL4(self, mode, VVyGLE, title, txt, colList):
  title = colList[1]
  FFpgNe(VVyGLE, boundFunction(self.VVldCv, mode, VVyGLE, title, txt, colList), title="Downloading ...")
 def VVldCv(self, mode, VVyGLE, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVl5aH(self.VV002F, self.VVwgstData["playListURL"], series_id)
  txt, err = self.VVBg9e(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVDB0e(tDict["info"], "name"   )
      category_id = self.VVDB0e(tDict["info"], "category_id" )
      icon  = self.VVDB0e(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVDB0e(EP, "id"     )
        episode_num   = self.VVDB0e(EP, "episode_num"   )
        epTitle    = self.VVDB0e(EP, "title"     )
        container_extension = self.VVDB0e(EP, "container_extension" )
        seasonNum   = self.VVDB0e(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FF538m(self, err, title=title)
  elif list:
   VV1DDw = ("Home Menu"   , FFW3h5            , [])
   VVY4BM = ("Download PIcons" , boundFunction(self.VVV7aR , mode)   , [])
   VVcWvO = ("Add ALL to Bouquet" , boundFunction(self.VVoHBW, mode, title) , [])
   VVsYEM = (""     , boundFunction(self.VVl6cO, mode)    , [])
   VVkbh1  = ("Play"    , boundFunction(self.VVi7kJ, mode)    , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVZOJU  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFed34(self, None, title=title, header=header, VVpuR3=list, VVZOJU=VVZOJU, VVEFlP=widths, VVQ020=26, VV1DDw=VV1DDw, VVY4BM=VVY4BM, VVkbh1=VVkbh1, VVsYEM=VVsYEM, VVcWvO=VVcWvO, VVCABW="#0a00292B", VVG1bZ="#0a002126", VVZHzf="#0a002126", VVjMdQ="#00000000")
  else:
   FF538m(self, "No Channels found !", title=title)
  FFyMZt(self)
 def VVdTAr(self, mode, VVyGLE, title, txt, colList):
  VVei97 = []
  VVei97.append(("Keyboard" , "manualEntry"))
  VVei97.append(("From Filter" , "fromFilter"))
  FFrC6O(self, boundFunction(self.VV70cV, VVyGLE, mode), title="Input Type", VVei97=VVei97, width=400)
 def VV70cV(self, VVyGLE, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FF5iHn(self, boundFunction(self.VVNS05, VVyGLE, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CC08vA(self)
    filterObj.VVErIA(boundFunction(self.VVNS05, VVyGLE, mode))
 def VVNS05(self, VVyGLE, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words: FFpgNe(VVyGLE, boundFunction(self.VVSMAY, VVyGLE, mode, title, words, toFind, asPrefix), title="Searching for:\n%s ..." % toFind[:20])
   else : FF538m(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVSMAY(self, VVyGLE, mode, title, words, toFind, asPrefix):
  list  = []
  for row in VVyGLE.VVwPno():
   catName  = row[0]
   catID  = row[1]
   qUrl  = self.VVl5aH(mode, self.VVwgstData["playListURL"], catID)
   txt, err = self.VVBg9e(qUrl)
   if not err:
    tList, err = self.VVvn0j(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      if asPrefix and not name.startswith(words) : continue
      elif any(x in name for x in words)   : pass
      else          : continue
      if mode == self.VVT0JG:
       num, name, catID, ID, Icon, added, epgID, isAdult = item
       list.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
      elif mode == self.VVU1SG:
       num, name, catID, ID, Icon, added, isAdult, ext = item
       list.append((num, name, catID, ID, Icon, catName, isAdult, ext))
      elif mode == self.VVvxVi:
       num, name, catID, ID, genre, dur, ext, cover = item
       list.append((num, name, catID, ID, genre, catName, ext, cover))
  if list:
   if mode == self.VVT0JG or mode == self.VVU1SG:
    bName   = CCQps6.VVOH83(toFind)
    VVkbh1  = ("Play"   , boundFunction(self.VVi7kJ, mode), [])
    VVcWvO = ("Add ALL to Bouquet" , boundFunction(self.VVoHBW, mode, bName) , [])
    VVY4BM = ("Download PIcons" , boundFunction(self.VVV7aR, mode)    , [])
   elif mode == self.VVvxVi:
    VVkbh1  = ("Show Seasons", boundFunction(self.VVsDL4, mode), [])
    VVcWvO = None
    VVY4BM = None
   VVsYEM = (""     , boundFunction(self.VVl6cO, mode)    , [])
   VV1DDw = ("Home Menu"   , FFW3h5            , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVZOJU  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   FFed34(self, None, title="Find (%s)" % toFind, header=header, VVpuR3=list, VVZOJU=VVZOJU, VVEFlP=widths, VVQ020=26, VVkbh1=VVkbh1, VV1DDw=VV1DDw, VVY4BM=VVY4BM, VVcWvO=VVcWvO, VVsYEM=VVsYEM, VVCABW="#0a00292B", VVG1bZ="#0a002126", VVZHzf="#0a002126", VVjMdQ="#00000000", VVwC3K=True, searchCol=1)
  else:
   FF538m(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVKMwa(self, mode, colList):
  if mode == self.VVT0JG:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVU1SG:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFfEyW(chName)
  url = self.VVwgstData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVKVTA(url)
  refCode = self.VV1fL5(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVl6cO(self, mode, VVyGLE, title, txt, colList):
  FFpgNe(VVyGLE, boundFunction(self.VVlB3M, mode, VVyGLE, title, txt, colList))
 def VVlB3M(self, mode, VVyGLE, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVKMwa(mode, colList)
  CCipAb.VVAUeq(self, chName, chUrl, picUrl, refCode, txt)
 def VVlbZz(self, mode, VVyGLE, title, txt, colList):
  FFpgNe(VVyGLE, boundFunction(self.VViKoa, mode, VVyGLE, title, txt, colList))
 def VViKoa(self, mode, VVyGLE, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  += "Duration\t: %s" % Dur
  if Cover: path, err = FFOwIM(Cover, "ajpanel_tmp.png", timeout=1)
  else : path = ""
  CCipAb.VVZUpt(self, "", txt, title, path)
 def VVoHBW(self, mode, bName, VVyGLE, title, txt, colList):
  FFpgNe(VVyGLE, boundFunction(self.VVszA1, mode, bName, VVyGLE, title, txt, colList), title="Adding Channels ...")
 def VVszA1(self, mode, bName, VVyGLE, title, txt, colList):
  url = self.VVwgstData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVKVTA(url)
  bNameFile = CCQps6.VVOH83(bName)
  num  = 0
  path = VVGnNm + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVGnNm + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVyGLE.VVwPno():
    chName, chUrl, picUrl, refCode = self.VVKMwa(mode, row)
    f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
    f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
    totChange += 1
  FFbSHG(os.path.basename(path))
  self.VVkNaC(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVV7aR(self, mode, VVyGLE, title, txt, colList):
  if os.system(FFgzF5("which ffmpeg")) == 0:
   self.session.open(CCg6oa, barTheme=CCg6oa.VVQ3yX
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VVeq3E, VVyGLE, mode)
       , VVuWtK = self.VV9mbA)
  else:
   FFcSjz(self, self.VVUrhH, '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?')
 def VV9mbA(self, VVNx6Z, VVQKYK, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVQKYK["proces"], VVQKYK["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVQKYK["ok"], VVQKYK["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVQKYK["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVQKYK["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVQKYK["badURL"]
  txt += "PIcons Path\t\t: %s\n"    % VVQKYK["path"]
  if not VVNx6Z  : color = "#11402000"
  elif VVQKYK["err"]: color = "#11201000"
  else     : color = None
  if VVQKYK["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVQKYK["err"], txt)
  title = "PIcons Download Result"
  if not VVNx6Z:
   title += "  (cancelled)"
  FF6wpe(self, txt, title=title, VVZHzf=color)
 def VVeq3E(self, VVyGLE, mode, progBarObj):
  totRows = VVyGLE.VV6WUd()
  progBarObj.VVx0AF(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CCsPD3.VVkefR()
  progBarObj.VVQKYK = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for row in VVyGLE.VVwPno():
    if progBarObj.isCancelled:
     break
    progBarObj.VVQKYK["proces"] += 1
    progBarObj.VVjB0W(1)
    if mode in ("itv", "vod", "series"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVMzGI(mode, row)
     refCode = CCQps6.VV1fL5(catID, stID, chNum)
    else:
     chName, chUrl, picUrl, refCode = self.VVKMwa(mode, row)
    if picUrl:
     picon = refCode.replace(":", "_").rstrip("_") + ".png"
     if not fileExists(pPath + picon):
      progBarObj.VVQKYK["attempt"] += 1
      path, err = FFOwIM(picUrl, picon, timeout=1)
      if path:
       progBarObj.VVQKYK["ok"] += 1
       if FFjNVY(path) > 0:
        cmd = ""
        if not mode == CCQps6.VVT0JG:
         cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
        cmd += FFgzF5("mv -f '%s' '%s'" % (path, pPath)) + ";"
        os.system(cmd)
       else:
        progBarObj.VVQKYK["size0"] += 1
        os.system(FFgzF5("rm -f '%s'" % path))
      elif err:
       progBarObj.VVQKYK["fail"] += 1
       if any(x in err.lower() for x in ("time-out", "unauthorized")):
        progBarObj.VVQKYK["err"] = err.title()
        break
     else:
      progBarObj.VVQKYK["exist"] += 1
    else:
     progBarObj.VVQKYK["badURL"] += 1
  except:
   pass
 def VVUrhH(self):
  cmd = FFVVjD(VVn00Q, "ffmpeg")
  if cmd : FF8mHD(self, cmd, title="Installing FFmpeg")
  else : FF9VHl(self)
 @staticmethod
 def VV1fL5(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCQps6.VVppHu(catID, MAX_4b)
  TSID = CCQps6.VVppHu(chNum, MAX_4b)
  ONID = CCQps6.VVppHu(chNum, MAX_4b)
  NS  = CCQps6.VVppHu(stID, MAX_8b)
  int(catID) if catID.isdigit() else ""
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVppHu(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVOH83(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
class CCNuRU(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FF87m3(VVseVH, 700, 700, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVl15Q  = 0
  self.VVsIE7 = 1
  self.VVpVid  = 2
  VVei97 = []
  VVei97.append(("Find All (from filter)"    , "VVJRq5" ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Find All"        , "VV5eWk"    ))
  VVei97.append(("Find TV"        , "VVt1ra"    ))
  VVei97.append(("Find Radio"       , "VVh9Wq"   ))
  if self.VVzExl():
   VVei97.append(VVhJ3E)
   VVei97.append(("Hide Channel: %s" % self.servName , "VVQryI"   ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Zap History"       , "VVSi7n"    ))
  VVei97.append(VVhJ3E)
  VVei97.append(("PIcons Tools"       , "PIconsTools"     ))
  VVei97.append(("Channels Tools"      , "ChannelsTools"    ))
  FFyw62(self, VVei97=VVei97, title=title)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  FFgNUr(self["myMenu"])
  FFhCiv(self)
  if self.isFindMode:
   self.VVVgsZ(self.VVkBu2())
 def VVnr3G(self):
  global VV8CgR
  VV8CgR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV5eWk"    : self.VV5eWk()
   elif item == "VVJRq5" : self.VVJRq5()
   elif item == "VVt1ra"    : self.VVt1ra()
   elif item == "VVh9Wq"   : self.VVh9Wq()
   elif item == "VVQryI"   : self.VVQryI()
   elif item == "VVSi7n"    : self.VVSi7n()
   elif item == "PIconsTools"     : self.session.open(CCsPD3)
   elif item == "ChannelsTools"    : self.session.open(CC3RQY)
 def VVt1ra(self) : self.VVVgsZ(self.VVl15Q)
 def VVh9Wq(self) : self.VVVgsZ(self.VVsIE7)
 def VV5eWk(self) : self.VVVgsZ(self.VVpVid)
 def VVVgsZ(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FF5iHn(self, boundFunction(self.VVQuXP, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVJRq5(self):
  filterObj = CC08vA(self)
  filterObj.VVErIA(self.VVYw9N)
 def VVYw9N(self, item):
  self.VVQuXP(self.VVpVid, item)
 def VVzExl(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFYHCc(self.refCode)        : return False
  return True
 def VVQuXP(self, mode, VVO3vB):
  FFpgNe(self, boundFunction(self.VV8NIx, mode, VVO3vB), title="Searching ...")
 def VV8NIx(self, mode, VVO3vB):
  if VVO3vB:
   self.findTxt = VVO3vB
   if   mode == self.VVl15Q  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVsIE7 : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVO3vB)
   if len(title) > 55:
    title = title[:55] + ".."
   VVbelk = self.VVkHW0(VVO3vB, servTypes)
   if self.isFindMode or mode == self.VVpVid:
    VVbelk += self.VVL57A(VVO3vB)
   if VVbelk:
    VVbelk.sort(key=lambda x: x[0].lower())
    VVVrwp = self.VVW9XX
    VVkbh1  = ("Zap"   , self.VVnZN5    , [])
    VVY4BM = ("Current Service", self.VVSVKN , [])
    VVcWvO = ("Options"  , self.VVVNlQ , [])
    VVsYEM = (""    , self.VVkipN , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVZOJU  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFed34(self, None, title=title, header=header, VVpuR3=VVbelk, VVZOJU=VVZOJU, VVEFlP=widths, VVQ020=25, VVkbh1=VVkbh1, VVVrwp=VVVrwp, VVY4BM=VVY4BM, VVcWvO=VVcWvO, VVsYEM=VVsYEM)
   else:
    self.VVVgsZ(self.VVkBu2())
    FFRg6s(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVkHW0(self, VVO3vB, servTypes):
  VV7Rux  = eServiceCenter.getInstance()
  VVoRCu   = '%s ORDER BY name' % servTypes
  VVB3Mf   = eServiceReference(VVoRCu)
  VVWVS6 = VV7Rux.list(VVB3Mf)
  if VVWVS6: VVpuR3 = VVWVS6.getContent("CN", False)
  else     : VVpuR3 = None
  VVbelk = []
  if VVpuR3:
   VVkhtC, VVX3Kv = FFyxvv()
   tp   = CCoReX()
   words, asPrefix = CC08vA.VVo2GC(VVO3vB)
   colorYellow  = CCvT7T.VVD8kt(VVApsx)
   colorWhite  = CCvT7T.VVD8kt(VVI8UI)
   for s in VVpuR3:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFjjiy(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVkhtC:
        STYPE = VVX3Kv[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVm6Ia(refCode)
       if not "-S" in syst:
        sat = syst
       VVbelk.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVbelk
 def VVL57A(self, VVO3vB):
  VVO3vB = VVO3vB.lower()
  VVFg3t = FF3Zym()
  VVbelk = []
  colorYellow  = CCvT7T.VVD8kt(VVApsx)
  colorWhite  = CCvT7T.VVD8kt(VVI8UI)
  if VVFg3t:
   for b in VVFg3t:
    VV9lF6  = b[0]
    VVrVnz  = b[1].toString()
    VVsIrB = eServiceReference(VVrVnz)
    VVADZJ = FFZTo6(VVsIrB)
    for service in VVADZJ:
     refCode  = service[0]
     if FFYHCc(refCode):
      servName = service[1]
      if VVO3vB in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VVO3vB), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VVbelk.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVbelk
 def VVkBu2(self):
  VVjcM6 = InfoBar.instance
  if VVjcM6:
   VVbmHV = VVjcM6.servicelist
   if VVbmHV:
    return VVbmHV.mode == 1
  return self.VVpVid
 def VVW9XX(self, VVyGLE):
  self.close()
  VVyGLE.cancel()
 def VVnZN5(self, VVyGLE, title, txt, colList):
  FFY1uw(VVyGLE, colList[2], VVda8V=False, checkParentalControl=True)
 def VVSVKN(self, VVyGLE, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpNp5(VVyGLE)
  if refCode:
   VVyGLE.VVu02S(2, FFMJnf(refCode, iptvRef, chName), True)
 def VVVNlQ(self, VVyGLE, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CCdfCX(self, VVyGLE, 2)
  mSel.VVWTQi(servName, refCode)
 def VVkipN(self, VVyGLE, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  CCipAb.VVeStt(self, chName, refCode, txt)
 def VVQryI(self):
  FFcSjz(self, self.VVVsOS, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVVsOS(self):
  ret = FFHhAj(self.refCode, True)
  if ret:
   self.VVTa2Q()
   self.close()
  else:
   FFyMZt(self, "Cannot change state" , 1000)
 def VVTa2Q(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVXHus()
  except:
   self.VVodBn()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      self.session.nav.playService(serviceRef)
 def VVCvk8(self):
  VVjcM6 = InfoBar.instance
  if VVjcM6:
   VVbmHV = VVjcM6.servicelist
   if VVbmHV:
    VVbmHV.setMode()
 def VVXHus(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVjcM6 = InfoBar.instance
   if VVjcM6:
    VVbmHV = VVjcM6.servicelist
    if VVbmHV:
     hList = VVbmHV.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVbmHV.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVbmHV.history  = newList
       VVbmHV.history_pos = pos
 def VVodBn(self):
  VVjcM6 = InfoBar.instance
  if VVjcM6:
   VVbmHV = VVjcM6.servicelist
   if VVbmHV:
    VVbmHV.history  = []
    VVbmHV.history_pos = 0
 def VVSi7n(self):
  VVjcM6 = InfoBar.instance
  VVbelk = []
  if VVjcM6:
   VVbmHV = VVjcM6.servicelist
   if VVbmHV:
    VVkhtC, VVX3Kv = FFyxvv()
    for chParams in VVbmHV.history:
     refCode = chParams[-1].toString()
     chName = FFoZoJ(refCode)
     isIptv = FFYHCc(refCode)
     if isIptv: sat = "-"
     else  : sat = FFjjiy(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVkhtC:
       STYPE = VVX3Kv[sTypeInt]
     VVbelk.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVbelk:
   VVkbh1  = ("Zap"   , self.VVjyGm   , [])
   VVcWvO = ("Clear History" , self.VVyVm5   , [])
   VVsYEM = (""    , self.VVRjGIFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVZOJU  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFed34(self, None, title=title, header=header, VVpuR3=VVbelk, VVZOJU=VVZOJU, VVEFlP=widths, VVQ020=23, VVkbh1=VVkbh1, VVcWvO=VVcWvO, VVsYEM=VVsYEM)
  else:
   FFRg6s(self, "Not found", title=title)
 def VVjyGm(self, VVyGLE, title, txt, colList):
  FFY1uw(VVyGLE, colList[3], VVda8V=False, checkParentalControl=True)
 def VVyVm5(self, VVyGLE, title, txt, colList):
  FFcSjz(self, boundFunction(self.VVC17w, VVyGLE), "Clear Zap History ?")
 def VVC17w(self, VVyGLE):
  self.VVodBn()
  VVyGLE.cancel()
 def VVRjGIFromZapHistory(self, VVyGLE, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  png, path = CCsPD3.VViWZT(refCode, chName)
  CCipAb.VVZUpt(self, refCode, txt, title, path)
class CCsPD3(Screen):
 VVUoQS   = 0
 VV907k  = 1
 VVdRMq  = 2
 VVLKLj  = 3
 VVUHei  = 4
 VVcQD6  = 5
 VVBDQO  = 6
 VV2MzL  = 7
 VVnRVU = 8
 VVBwk6 = 9
 def __init__(self, session):
  self.skin, self.skinParam = FF87m3(VVOcdu, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFyw62(self, self.Title)
  FF3p62(self["keyRed"] , "OK = Zap")
  FF3p62(self["keyGreen"] , "Current Service")
  FF3p62(self["keyYellow"], "Page Options")
  FF3p62(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCsPD3.VVkefR()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVpuR3    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVXeo1        ,
   "green"   : self.VVUPck       ,
   "yellow"  : self.VVICwX        ,
   "blue"   : self.VVjBQY        ,
   "menu"   : self.VVnhmP        ,
   "info"   : self.VVRjGI         ,
   "up"   : self.VVZzbA          ,
   "down"   : self.VVqzdb         ,
   "left"   : self.VVpaMT         ,
   "right"   : self.VVbQZO         ,
   "pageUp"  : boundFunction(self.VVtlND, True) ,
   "chanUp"  : boundFunction(self.VVtlND, True) ,
   "pageDown"  : boundFunction(self.VVtlND, False) ,
   "chanDown"  : boundFunction(self.VVtlND, False) ,
   "next"   : self.VV7Mgk        ,
   "last"   : self.VV0SFj         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  FFEpG1(self)
  FFrhNb(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFpgNe(self, boundFunction(self.VVNJ35, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVnhmP(self):
  if not self.isBusy:
   VVei97 = []
   VVei97.append(("Statistics"           , "VVX6YP"    ))
   VVei97.append(VVhJ3E)
   VVei97.append(("Suggest PIcons for Current Channel"     , "VVtVuC"   ))
   VVei97.append(("Set to Current Channel (copy file)"     , "VVi9z2_file"  ))
   VVei97.append(("Set to Current Channel (as SymLink)"     , "VVi9z2_link"  ))
   VVei97.append(VVhJ3E)
   VVei97.append(CCsPD3.VVOG9d())
   VVei97.append(VVhJ3E)
   VVei97.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVnmpR"  ))
   VVei97.append(VVhJ3E)
   VVei97 += CCsPD3.VVzp6S()
   VVei97.append(VVhJ3E)
   VVei97.append(("RCU Keys Help"          , "VViuP9"    ))
   FFrC6O(self, self.VVhzQP, title=self.Title, VVei97=VVei97)
 def VVhzQP(self, item=None):
  if item is not None:
   if   item == "VVX6YP"     : self.VVX6YP()
   elif item == "VVtVuC"    : FFpgNe(self, self.VVtVuC, clearMsg=False)
   elif item == "VVi9z2_file"   : self.VVi9z2(0)
   elif item == "VVi9z2_link"   : self.VVi9z2(1)
   elif item == "VVDZFE_file"  : self.VVDZFE(0)
   elif item == "VVDZFE_link"  : self.VVDZFE(1)
   elif item == "VVPOUz"   : self.VVPOUz()
   elif item == "VV6zZq"  : self.VV6zZq()
   elif item == "VVaf4b"   : self.VVaf4b()
   elif item == "VVnmpR"   : self.VVnmpR()
   elif item == "VVDppt"   : CCsPD3.VVDppt(self)
   elif item == "VVGdHu"   : CCsPD3.VVGdHu(self)
   elif item == "findPiconBrokenSymLinks"  : CCsPD3.VVnVSr(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCsPD3.VVnVSr(self, False)
   elif item == "VViuP9"      : self.VViuP9()
 def VVICwX(self):
  if not self.isBusy:
   VVei97 = []
   VVei97.append(("Go to First PIcon"  , "VVHvVm"  ))
   VVei97.append(("Go to Last PIcon"   , "VVoJkr"  ))
   VVei97.append(VVhJ3E)
   VVei97.append(("Sort by Channel Name"     , "sortByChan" ))
   VVei97.append(("Sort by File Name"  , "sortByFile" ))
   VVei97.append(VVhJ3E)
   VVei97.append(("Find from File List .." , "VVmz63" ))
   FFrC6O(self, self.VVdK4F, title=self.Title, VVei97=VVei97)
 def VVdK4F(self, item=None):
  if item is not None:
   if   item == "VVHvVm"   : self.VVHvVm()
   elif item == "VVoJkr"   : self.VVoJkr()
   elif item == "sortByChan"  : self.VVYggn(2)
   elif item == "sortByFile"  : self.VVYggn(0)
   elif item == "VVmz63"  : self.VVmz63()
 def VViuP9(self):
  FFHaIY(self, VV1ggQ + "_help_picons", "PIcons Manager (Keys Help)")
 def VVZzbA(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVoJkr()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VV7ccX()
 def VVqzdb(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVHvVm()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VV7ccX()
 def VVpaMT(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVoJkr()
  else:
   self.curCol -= 1
   self.VV7ccX()
 def VVbQZO(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVHvVm()
  else:
   self.curCol += 1
   self.VV7ccX()
 def VV0SFj(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VV7ccX(True)
 def VV7Mgk(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VV7ccX(True)
 def VVHvVm(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VV7ccX(True)
 def VVoJkr(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VV7ccX(True)
 def VVmz63(self):
  VVei97 = []
  for item in self.VVpuR3:
   VVei97.append((item[0], item[0]))
  FFrC6O(self, self.VVNH94, title='PIcons ".png" Files', VVei97=VVei97, VVrJr1=True)
 def VVNH94(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVemiz(ndx)
 def VVXeo1(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VV5DwS()
   if refCode:
    FFY1uw(self, refCode)
    self.VVSLqM()
    self.VVQHoi()
 def VVtlND(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVSLqM()
   self.VVQHoi()
  except:
   pass
 def VVUPck(self):
  if self["keyGreen"].getVisible():
   self.VVemiz(self.curChanIndex)
 def VVemiz(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VV7ccX(True)
  else:
   FFyMZt(self, "Not found", 1000)
 def VVYggn(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFpgNe(self, boundFunction(self.VVNJ35, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVi9z2(self, mode):
  title = "Change Current Channel PIcon"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpNp5(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VV5DwS()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVei97 = []
     VVei97.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVei97.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFrC6O(self, boundFunction(self.VVkMPE, mode, curChF, selPiconF), VVei97=VVei97, title="Current Channel PIcon (already exists)")
    else:
     self.VVkMPE(mode, curChF, selPiconF, "overwrite")
   else:
    FF538m(self, "Cannot change PIcon to itself !", title=title)
  else:
   FF538m(self, "Could not read current channel info. !", title=title)
 def VVkMPE(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFpgNe(self, boundFunction(self.VVNJ35, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVDZFE(self, mode):
  pass
 def VVPOUz(self):
  pass
 def VV6zZq(self):
  pass
 def VVaf4b(self):
  pass
 def VVnmpR(self):
  lines = FFofdg("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFcSjz(self, boundFunction(self.VVtSCS, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VV5nHT=True)
  else:
   FFRg6s(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVtSCS(self, fList):
  os.system(FFgzF5("find -L '%s' -type l -delete" % self.pPath))
  FFRg6s(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVRjGI(self):
  FFpgNe(self, self.VVMO0t)
 def VVMO0t(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VV5DwS()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFUIPk("PIcon Directory:\n", VVbHZ1)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFJYfS(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFJYfS(path)
   txt += FFUIPk("PIcon File:\n", VVbHZ1)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFofdg(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFUIPk("Found %d SymLink%s to this file from:\n" % (tot, s), VVbHZ1)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFoZoJ(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFUIPk(tChName, VVbnJx)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFUIPk(line, VVLIgE), tChName)
    txt += "\n"
   if chName:
    txt += FFUIPk("Channel:\n", VVbHZ1)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFUIPk(chName, VVbnJx)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFUIPk("Remarks:\n", VVbHZ1)
    txt += "  %s\n" % FFUIPk("Unused", VVEiu9)
  else:
   txt = "No info found"
  CCipAb.VVZUpt(self, refCode, txt, "PIcon Info.", self.pPath + filName)
 def VV5DwS(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVpuR3[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFe0Vt(sat)
  return fName, refCode, chName, sat, inDB
 def VVSLqM(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpNp5(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVpuR3):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVQHoi(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VV5DwS()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFUIPk("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVbHZ1))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VV5DwS()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFUIPk(self.curChanName, VVApsx)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVX6YP(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VVpuR3:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFLHG0("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FF6wpe(self, txt, title=self.Title)
 def VVjBQY(self):
  if not self.isBusy:
   VVei97 = []
   VVei97.append(("All"         , "all"   ))
   VVei97.append(VVhJ3E)
   VVei97.append(("Used by Channels"      , "used"  ))
   VVei97.append(("Unused PIcons"      , "unused"  ))
   VVei97.append(VVhJ3E)
   VVei97.append(("PIcons Files"       , "pFiles"  ))
   VVei97.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVei97.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVei97.append(VVhJ3E)
   VVei97.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVei97.append(VVhJ3E)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFL3a5(val)
      VVei97.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CC08vA(self)
   filterObj.VVzk3o(VVei97, self.nsList, self.VVMujx)
 def VVMujx(self, item=None):
  if item is not None:
   self.VVthSO(item)
 def VVthSO(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVUoQS   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VV907k   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVdRMq  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVLKLj  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVUHei  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVcQD6  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVBDQO   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VV2MzL   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVnRVU , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVcQD6:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFofdg("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFyMZt(self, "Not found", 1000)
     return
   elif mode == self.VVBwk6:
    return
   else:
    words, asPrefix = CC08vA.VVo2GC(words)
   if not words and mode in (self.VV2MzL, self.VVnRVU):
    FFyMZt(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFpgNe(self, boundFunction(self.VVNJ35, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVtVuC(self):
  FFyMZt(self, "Loading Channels ...")
  lameDbChans = CC3RQY.VVeovQ(self, CC3RQY.VVLmlD, VVAPVZ=False, VVtOwU=False)
  files = []
  words = []
  if lameDbChans:
   curCh = self.curChanName.lower().replace(" hd", "").replace(" fm", "").replace("4k", "")
   for refCode in lameDbChans:
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCsPD3.VVNsLy(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCsPD3.VVtblb(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       words.append(f.replace(".png", ""))
  if words:
   FFpgNe(self, boundFunction(self.VVNJ35, mode=self.VVBwk6, words=words), title="Filtering ...", clearMsg=False)
  else:
   FFyMZt(self, "Not found", 1000)
 def VVNJ35(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVtxUB(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CC3RQY.VVeovQ(self, CC3RQY.VVLmlD, VVAPVZ=False, VVtOwU=False)
  iptvRefList = self.VVgJgU()
  tList = []
  for fName, fType in CCsPD3.VVF2sv(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVUoQS:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VV907k  and chName         : isAdd = True
   elif mode == self.VVdRMq and not chName        : isAdd = True
   elif mode == self.VVLKLj  and fType == 0        : isAdd = True
   elif mode == self.VVUHei  and fType == 1        : isAdd = True
   elif mode == self.VVcQD6  and fName in words       : isAdd = True
   elif mode == self.VVBwk6 and fName in words       : isAdd = True
   elif mode == self.VVBDQO  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VV2MzL  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVnRVU:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVpuR3   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFyMZt(self)
  else:
   self.isBusy = False
   FFyMZt(self, "Not found", 1000)
   return
  self.VVpuR3.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVSLqM()
  self.totalPIcons = len(self.VVpuR3)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VV7ccX(True)
 def VVtxUB(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCsPD3.VVF2sv(self.pPath):
    if fName:
     return True
   if isFirstTime : FF538m(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFyMZt(self, "Not found", 1000)
  else:
   FF538m(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVgJgU(self):
  VVbelk = {}
  files  = CCQps6.VVpNPN(self)
  if files:
   for path in files:
    txt = FFUy6Y(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVbelk[refCode] = item[1]
  return VVbelk
 def VV7ccX(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVhv3M = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVhv3M: self.curPage = VVhv3M
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVOmTL()
  if self.curPage == VVhv3M:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVQHoi()
  filName, refCode, chName, sat, inDB = self.VV5DwS()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVOmTL(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVpuR3[ndx]
   fName = self.VVpuR3[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFUIPk(chName, VVbnJx))
    else : lbl.setText("-")
   except:
    lbl.setText(FFUIPk(chName, VV5Hmu))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVNsLy(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVOG9d():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVDppt"   )
 @staticmethod
 def VVzp6S():
  VVei97 = []
  VVei97.append(("Find SymLinks (to PIcon Directory)"   , "VVGdHu"   ))
  VVei97.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVei97.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVei97
 @staticmethod
 def VVDppt(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpNp5(SELF)
  png, path = CCsPD3.VViWZT(refCode)
  if path : CCsPD3.VVO7Fr(SELF, png, path)
  else : FF538m(SELF, "No PIcon found for current channel in:\n\n%s" % CCsPD3.VVkefR())
 @staticmethod
 def VVGdHu(SELF):
  if VVApsx:
   sed1 = FFPqb8("->", VVApsx)
   sed2 = FFPqb8("picon", VVEiu9)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VV5Hmu, VVI8UI)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFX0Ip(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFRwKj(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVnVSr(SELF, isPIcon):
  sed1 = FFPqb8("->", VV5Hmu)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFPqb8("picon", VVEiu9)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFX0Ip(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFRwKj(), grep, sed1, sed2))
 @staticmethod
 def VVF2sv(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVkefR():
  path = CFG.PIconsPath.getValue()
  return FFGYYB(path)
 @staticmethod
 def VViWZT(refCode, chName=None):
  if FFYHCc(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFIv3N(refCode)
  allPath, fName, refCodeFile, pList = CCsPD3.VVtblb(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVO7Fr(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFPqb8("%s%s" % (dest, png), VVbnJx))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFPqb8(errTxt, VVP3bf))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FF5DF6(SELF, cmd)
 @staticmethod
 def VVtblb(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCsPD3.VVkefR()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFfEyW(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCxd3b():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VV6kqS  = None
  self.VVtQ3y = ""
  self.VVLWz3  = noService
  self.VVxTuC = 0
  self.VVpx2t  = noService
  self.VVHQaW = 0
  self.VVpYkr  = "-"
  self.VVMecE = 0
  self.VVmZ1a  = ""
  self.serviceName = ""
 def VVyvzb(self, service):
  if service:
   feinfo = service.frontendInfo()
   if feinfo:
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VV6kqS = frontEndStatus
     self.VVozgj()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVozgj(self):
  if self.VV6kqS:
   val = self.VV6kqS.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVtQ3y = "%3.02f dB" % (val / 100.0)
   else         : self.VVtQ3y = ""
   val = self.VV6kqS.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVxTuC = int(val)
   self.VVLWz3  = "%d%%" % val
   val = self.VV6kqS.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVHQaW = int(val)
   self.VVpx2t  = "%d%%" % val
   val = self.VV6kqS.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVpYkr  = "%d" % val
   val = int(val * 100 / 500)
   self.VVMecE = min(500, val)
   val = self.VV6kqS.get("tuner_locked", 0)
   if val == 1 : self.VVmZ1a = "Locked"
   else  : self.VVmZ1a = "Not locked"
 def VVUvNp(self)   : return self.VVtQ3y
 def VVwL4o(self)   : return self.VVLWz3
 def VVrvXO(self)  : return self.VVxTuC
 def VVQLeM(self)   : return self.VVpx2t
 def VVfG9j(self)  : return self.VVHQaW
 def VVekK2(self)   : return self.VVpYkr
 def VV1qjq(self)  : return self.VVMecE
 def VVMkEL(self)   : return self.VVmZ1a
 def VVIGqt(self) : return self.serviceName
class CCoReX():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVC4Wt(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFUtnl(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVDg8c(self.ORPOS  , mod=1   )
      self.sat2  = self.VVDg8c(self.ORPOS  , mod=2   )
      self.freq  = self.VVDg8c(self.FREQ  , mod=3   )
      self.sr   = self.VVDg8c(self.SR   , mod=4   )
      self.inv  = self.VVDg8c(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVDg8c(self.POL  , self.D_POL )
      self.fec  = self.VVDg8c(self.FEC  , self.D_FEC )
      self.syst  = self.VVDg8c(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVDg8c("modulation" , self.D_MOD )
       self.rolof = self.VVDg8c("rolloff"  , self.D_ROLOF )
       self.pil = self.VVDg8c("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVDg8c("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVDg8c("pls_code"  )
       self.iStId = self.VVDg8c("is_id"   )
       self.t2PlId = self.VVDg8c("t2mi_plp_id" )
       self.t2PId = self.VVDg8c("t2mi_pid"  )
 def VVDg8c(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFL3a5(val)
  elif mod == 2   : return FFKjLn(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVj5YZ(self, refCode):
  txt = ""
  self.VVC4Wt(refCode)
  if self.data:
   def VVWqEf(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVWqEf("System"   , self.syst)
    txt += VVWqEf("Satellite"  , self.sat2)
    txt += VVWqEf("Frequency"  , self.freq)
    txt += VVWqEf("Inversion"  , self.inv)
    txt += VVWqEf("Symbol Rate"  , self.sr)
    txt += VVWqEf("Polarization" , self.pol)
    txt += VVWqEf("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVWqEf("Modulation" , self.mod)
     txt += VVWqEf("Roll-Off" , self.rolof)
     txt += VVWqEf("Pilot"  , self.pil)
     txt += VVWqEf("Input Stream", self.iStId)
     txt += VVWqEf("T2MI PLP ID" , self.t2PlId)
     txt += VVWqEf("T2MI PID" , self.t2PId)
     txt += VVWqEf("PLS Mode" , self.plsMod)
     txt += VVWqEf("PLS Code" , self.plsCod)
   else:
    txt += VVWqEf("System"   , self.txMedia)
    txt += VVWqEf("Frequency"  , self.freq)
  return txt, self.namespace
 def VV9XaE(self, refCode):
  txt = "Transpoder : ?"
  self.VVC4Wt(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVbHZ1 + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVm6Ia(self, refCode):
  self.data = None
  servRef = eServiceReference(refCode)
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFUtnl(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVDg8c(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVDg8c(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVDg8c(self.SYST, self.D_SYS_S)
     freq = self.VVDg8c(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVDg8c(self.POL , self.D_POL)
      fec = self.VVDg8c(self.FEC , self.D_FEC)
      sr = self.VVDg8c(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVMb9I(self, refCode):
  self.data = None
  self.VVC4Wt(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCi8JT():
 def __init__(self, VVFa7E, path, VVuWtK=None, curRowNum=-1):
  self.VVFa7E  = VVFa7E
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVuWtK  = VVuWtK
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFgzF5("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVIWaH(curRowNum)
  else:
   FF538m(self.VVFa7E, "Error while preparing edit!")
 def VVIWaH(self, curRowNum):
  VVbelk = self.VVwrk5()
  VV1DDw = None #("Delete Line" , self.deleteLine  , [])
  VVY4BM = ("Save Changes" , self.VVT4At   , [])
  VVkbh1  = ("Edit Line"  , self.VVHk15    , [])
  VVKois = ("Line Options" , self.VVykeI   , [])
  VVoSIN = (""    , self.VVLxDz , [])
  VVVrwp = self.VVuwRc
  VVrjcc  = self.VVUONP
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVZOJU  = (CENTER  , LEFT  )
  VVyGLE = FFed34(self.VVFa7E, None, title=self.Title, header=header, VVpuR3=VVbelk, VVZOJU=VVZOJU, VVEFlP=widths, VVQ020=24, VV1DDw=VV1DDw, VVY4BM=VVY4BM, VVkbh1=VVkbh1, VVKois=VVKois, VVVrwp=VVVrwp, VVrjcc=VVrjcc, VVoSIN=VVoSIN, VVwC3K=True
    , VVCABW   = "#11001111"
    , VVG1bZ   = "#11001111"
    , VVZHzf   = "#11001111"
    , VVjMdQ  = "#05333333"
    , VVonRc  = "#00222222"
    , VV8hLc  = "#11331133"
    )
  VVyGLE.VVqjOl(curRowNum)
 def VVykeI(self, VVyGLE, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVyGLE.VVWXHx()
  VVei97 = []
  VVei97.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVei97.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVcPS7"  ))
  VVei97.append(VVhJ3E)
  VVei97.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVrcHB:
   VVei97.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVei97.append(VVhJ3E)
  VVei97.append(  ("Delete Line"         , "deleteLine"   ))
  FFrC6O(self.VVFa7E, boundFunction(self.VV5Y94, VVyGLE, lineNum), VVei97=VVei97, title="Line Options")
 def VV5Y94(self, VVyGLE, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVInuv("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVyGLE)
   elif item == "VVcPS7"  : self.VVcPS7(VVyGLE, lineNum)
   elif item == "copyToClipboard"  : self.VVwLAf(VVyGLE, lineNum)
   elif item == "pasteFromClipboard" : self.VVyrQE(VVyGLE, lineNum)
   elif item == "deleteLine"   : self.VVInuv("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVyGLE)
 def VVUONP(self, VVyGLE):
  VVyGLE.VVadAo()
 def VVLxDz(self, VVyGLE, title, txt, colList):
  if   self.insertMode == 1: VVyGLE.VV5eiw()
  elif self.insertMode == 2: VVyGLE.VVz50Z()
  self.insertMode = 0
 def VVcPS7(self, VVyGLE, lineNum):
  if lineNum == VVyGLE.VVWXHx():
   self.insertMode = 1
   self.VVInuv("echo '' >> '%s'" % self.tmpFile, VVyGLE)
  else:
   self.insertMode = 2
   self.VVInuv("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVyGLE)
 def VVwLAf(self, VVyGLE, lineNum):
  global VVrcHB
  VVrcHB = FFLHG0("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVyGLE.VVPKXQ("Copied to clipboard")
 def VVT4At(self, VVyGLE, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFgzF5("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFgzF5("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVyGLE.VVPKXQ("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVyGLE.VVadAo()
    else:
     FF538m(self.VVFa7E, "Cannot save file!")
   else:
    FF538m(self.VVFa7E, "Cannot create backup copy of original file!")
 def VVuwRc(self, VVyGLE):
  if self.fileChanged:
   FFcSjz(self.VVFa7E, boundFunction(self.VVJnJM, VVyGLE), "Cancel changes ?")
  else:
   finalOK = os.system(FFgzF5("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVJnJM(VVyGLE)
 def VVJnJM(self, VVyGLE):
  VVyGLE.cancel()
  os.system(FFgzF5("rm -f '%s'" % self.tmpFile))
  if self.VVuWtK:
   self.VVuWtK(self.fileSaved)
 def VVHk15(self, VVyGLE, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVI8UI + "ORIGINAL TEXT:\n" + VVLIgE + lineTxt
  FF5iHn(self.VVFa7E, boundFunction(self.VV0l9x, lineNum, VVyGLE), title="File Line", defaultText=lineTxt, message=message)
 def VV0l9x(self, lineNum, VVyGLE, VVxCeq):
  if not VVxCeq is None:
   if VVyGLE.VVWXHx() <= 1:
    self.VVInuv("echo %s > '%s'" % (VVxCeq, self.tmpFile), VVyGLE)
   else:
    self.VV5tWL(VVyGLE, lineNum, VVxCeq)
 def VVyrQE(self, VVyGLE, lineNum):
  if lineNum == VVyGLE.VVWXHx() and VVyGLE.VVWXHx() == 1:
   self.VVInuv("echo %s >> '%s'" % (VVrcHB, self.tmpFile), VVyGLE)
  else:
   self.VV5tWL(VVyGLE, lineNum, VVrcHB)
 def VV5tWL(self, VVyGLE, lineNum, newTxt):
  VVyGLE.VVTN1E("Saving ...")
  lines = FFDyYj(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVyGLE.VVbiPX()
  VVbelk = self.VVwrk5()
  VVyGLE.VVwB4B(VVbelk)
 def VVInuv(self, cmd, VVyGLE):
  tCons = CCZ10W()
  tCons.ePopen(cmd, boundFunction(self.VVamw9, VVyGLE))
  self.fileChanged = True
  VVyGLE.VVbiPX()
 def VVamw9(self, VVyGLE, result, retval):
  VVbelk = self.VVwrk5()
  VVyGLE.VVwB4B(VVbelk)
 def VVwrk5(self):
  if fileExists(self.tmpFile):
   lines = FFDyYj(self.tmpFile)
   VVbelk = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVbelk.append((str(ndx), line.strip()))
   if not VVbelk:
    VVbelk.append((str(1), ""))
   return VVbelk
  else:
   FF4LjO(self.VVFa7E, self.tmpFile)
class CC08vA():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVei97   = []
  self.satList   = []
 def VVErIA(self, VVuWtK):
  self.VVei97 = []
  VVei97, VVsX43 = self.VVrrqh(False, True)
  if VVei97:
   self.VVei97 += VVei97
   self.VVmgXT(VVuWtK, VVsX43)
 def VVSv1e(self, mode, VVyGLE, satCol, VVuWtK):
  VVyGLE.VVTN1E("Loading Filters ...")
  self.VVei97 = []
  self.VVei97.append(("All Services" , "all"))
  if mode == 1:
   self.VVei97.append(VVhJ3E)
   self.VVei97.append(("Parental Control", "parentalControl"))
   self.VVei97.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVei97.append(VVhJ3E)
   self.VVei97.append(("Selected Transponder"   , "selectedTP" ))
   self.VVei97.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVSY83(VVyGLE, satCol)
  VVei97, VVsX43 = self.VVrrqh(True, False)
  if VVei97:
   VVei97.insert(0, VVhJ3E)
   self.VVei97 += VVei97
  VVyGLE.VVDtzl()
  self.VVmgXT(VVuWtK, VVsX43)
 def VVzk3o(self, VVei97, sats, VVuWtK):
  self.VVei97 = VVei97
  VVei97, VVsX43 = self.VVrrqh(True, False)
  if VVei97:
   self.VVei97.append(VVhJ3E)
   self.VVei97 += VVei97
  self.VVmgXT(VVuWtK, VVsX43)
 def VVJwRd(self, VVei97, sats, VVuWtK):
  self.VVei97 = VVei97
  VVei97, VVsX43 = self.VVrrqh(True, False)
  if VVei97:
   self.VVei97.append(VVhJ3E)
   self.VVei97 += VVei97
  self.VVmgXT(VVuWtK, VVsX43)
 def VVmgXT(self, VVuWtK, VVsX43):
  VVdFS8 = ("Edit Filter", boundFunction(self.VVCEC4, VVsX43))
  VVQixJ  = ("Filter Help", boundFunction(self.VVyrbb, VVsX43))
  FFrC6O(self.callingSELF, boundFunction(self.VVJYbE, VVuWtK), VVei97=self.VVei97, title="Select Filter", VVdFS8=VVdFS8, VVQixJ=VVQixJ)
 def VVJYbE(self, VVuWtK, item):
  if item:
   VVuWtK(item)
 def VVCEC4(self, VVsX43, VVQlLPObj, sel):
  if fileExists(VVsX43) : CCi8JT(self.callingSELF, VVsX43, VVuWtK=None)
  else       : FF4LjO(self.callingSELF, VVsX43)
  VVQlLPObj.cancel()
 def VVyrbb(self, VVsX43, VVQlLPObj, sel):
  FFHaIY(self.callingSELF, VV1ggQ + "_help_service_filter", "Service Filter")
 def VVSY83(self, VVyGLE, satColNum):
  if not self.satList:
   satList = VVyGLE.VVTtN2(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFe0Vt(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVhJ3E)
  if self.VVei97:
   self.VVei97 += self.satList
 def VVrrqh(self, addTag, VVdtwB):
  FFIa5N()
  fileName  = "ajpanel_services_filter"
  VVsX43 = VVhuan + fileName
  VVei97  = []
  if not fileExists(VVsX43):
   os.system(FFgzF5("cp -f '%s' '%s'" % (VV1ggQ + fileName, VVsX43)))
  fileFound = False
  if fileExists(VVsX43):
   fileFound = True
   lines = FFDyYj(VVsX43)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVei97.append((line, "__w__" + line))
       else  : VVei97.append((line, line))
  if VVdtwB:
   if   not fileFound : FF4LjO(self.callingSELF , VVsX43)
   elif not VVei97 : FFDXjZ(self.callingSELF , VVsX43)
  return VVei97, VVsX43
 @staticmethod
 def VVo2GC(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CCdfCX():
 def __init__(self, callingSELF, VVyGLE, refCodeColNum):
  self.callingSELF = callingSELF
  self.VVyGLE = VVyGLE
  self.refCodeColNum = refCodeColNum
  self.VVei97 = []
  iMulSel = self.VVyGLE.VV2LY7()
  if iMulSel : self.VVei97.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVei97.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVyGLE.VVk8NP()
  self.VVei97.append(    ("Select all"    , "selectAll"  ))
  if tot > 0:
   self.VVei97.append(   ("Unselect all"    , "unselectAll"  ))
  self.VVei97.append(VVhJ3E)
 def VVWTQi(self, servName, refCode):
  tot = self.VVyGLE.VVk8NP()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVei97.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVoB6I_multi" ))
  else    : self.VVei97.append( ("Add to Bouquet : %s"      % servName , "VVoB6I_one" ))
  self.VVNu1F(servName, refCode)
 def VVsK91(self, servName, refCode, pcState, hidState):
  self.VVei97 = []
  if pcState == "No" : self.VVei97.append(("Add to Parental Control"  , "parentalControl_add"  ))
  else    : self.VVei97.append(("Remove from Parental Control" , "parentalControl_remove" ))
  if hidState == "No" : self.VVei97.append(("Add to Hidden Services"  , "hiddenServices_add"  ))
  else    : self.VVei97.append(("Remove from Hidden Services" , "hiddenServices_remove" ))
  self.VVNu1F(servName, refCode)
 def VVNu1F(self, servName, refCode):
  FFrC6O(self.callingSELF, boundFunction(self.VVZYCm, servName, refCode), title="Options", VVei97=self.VVei97)
 def VVZYCm(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"    : self.VVyGLE.VV0r1n(True)
   elif item == "MultSelDisab"    : self.VVyGLE.VV0r1n(False)
   elif item == "selectAll"    : self.VVyGLE.VVelRB()
   elif item == "unselectAll"    : self.VVyGLE.VVOqpL()
   elif item == "parentalControl_add"  : self.callingSELF.VVjGgL(self.VVyGLE, refCode, True)
   elif item == "parentalControl_remove" : self.callingSELF.VVjGgL(self.VVyGLE, refCode, False)
   elif item == "hiddenServices_add"  : self.callingSELF.VVy5Ch(self.VVyGLE, refCode, True)
   elif item == "hiddenServices_remove" : self.callingSELF.VVy5Ch(self.VVyGLE, refCode, False)
   elif item == "VVoB6I_multi" : self.VVoB6I(refCode, True)
   elif item == "VVoB6I_one" : self.VVoB6I(refCode, False)
 def VVoB6I(self, refCode, isMulti):
  bouquets = FF3Zym()
  if bouquets:
   VVei97 = []
   for item in bouquets:
    VVei97.append((item[0], item[1].toString()))
   VVdFS8 = ("Create New", boundFunction(self.VV4S1B, refCode, isMulti))
   FFrC6O(self.callingSELF, boundFunction(self.VVsVaV, refCode, isMulti), VVei97=VVei97, title="Add to Bouquet", VVdFS8=VVdFS8, VVrJr1=True, VV4qsP=True)
  else:
   FFcSjz(self.callingSELF, boundFunction(self.VVOc1I, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVsVaV(self, refCode, isMulti, bName=None):
  if bName:
   FFpgNe(self.VVyGLE, boundFunction(self.VV7JaA, refCode, isMulti, bName), title="Adding Channels ...")
 def VV7JaA(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVVOyH(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVjcM6 = InfoBar.instance
    if VVjcM6:
     VVbmHV = VVjcM6.servicelist
     if VVbmHV:
      mutableList = VVbmHV.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVyGLE.VVDtzl()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFRg6s(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FF538m(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVVOyH(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVyGLE.VVlab8(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VV4S1B(self, refCode, isMulti, VVQlLPObj, path):
  self.VVOc1I(refCode, isMulti)
 def VVOc1I(self, refCode, isMulti):
  FF5iHn(self.callingSELF, boundFunction(self.VVG2Ay, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVG2Ay(self, refCode, isMulti, name):
  if name:
   FFpgNe(self.VVyGLE, boundFunction(self.VVRbJL, refCode, isMulti, name), title="Adding Channels ...")
 def VVRbJL(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVVOyH(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVjcM6 = InfoBar.instance
    if VVjcM6:
     VVbmHV = VVjcM6.servicelist
     if VVbmHV:
      try:
       VVbmHV.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVbmHV.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVyGLE.VVDtzl()
   title = "Add to Bouquet"
   if allOK: FFRg6s(self.callingSELF, "Added to : %s" % name, title=title)
   else : FF538m(self.callingSELF, "Nothing added!", title=title)
class CChNfr(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF87m3(VVjRal, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFyw62(self)
  FF3p62(self["keyRed"]  , "Exit")
  FF3p62(self["keyGreen"]  , "Save")
  FF3p62(self["keyYellow"] , "Refresh")
  FF3p62(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVG6AF  ,
   "green"   : self.VVt0yE ,
   "yellow"  : self.VVbpqy  ,
   "blue"   : self.VVPd6K   ,
   "up"   : self.VVZzbA    ,
   "down"   : self.VVqzdb   ,
   "left"   : self.VVpaMT   ,
   "right"   : self.VVbQZO   ,
   "cancel"  : self.VVG6AF
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVbpqy()
  self.VVOAsT()
  FFEpG1(self)
 def VVG6AF(self) : self.close(True)
 def VVQlOG(self) : self.close(False)
 def VVPd6K(self):
  self.session.openWithCallback(self.VVWuEy, boundFunction(CCxlYm))
 def VVWuEy(self, closeAll):
  if closeAll:
   self.close()
 def VVZzbA(self):
  self.VV4WRY(1)
 def VVqzdb(self):
  self.VV4WRY(-1)
 def VVpaMT(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVOAsT()
 def VVbQZO(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVOAsT()
 def VV4WRY(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VViqal(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VViqal(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VViqal(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVM9of(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVM9of(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVOAsT(self):
  for obj in self.list:
   FFrhNb(obj, "#11404040")
  FFrhNb(self.list[self.index], "#11ff8000")
 def VVbpqy(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVt0yE(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCZ10W()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVkdTu)
 def VVkdTu(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFRg6s(self, "Nothing returned from the system!")
  else:
   FFRg6s(self, str(result))
class CCxlYm(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF87m3(VVrlPa, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFyw62(self, addLabel=True)
  FF3p62(self["keyRed"]  , "Exit")
  FF3p62(self["keyGreen"]  , "Sync")
  FF3p62(self["keyYellow"] , "Refresh")
  FF3p62(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVG6AF   ,
   "green"   : self.VVfk8g  ,
   "yellow"  : self.VVDiuy ,
   "blue"   : self.VVwvYc  ,
   "cancel"  : self.VVG6AF
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVnn51()
  self.onShow.append(self.start)
 def start(self):
  FF5Ov8(self.refresh)
  FFEpG1(self)
 def refresh(self):
  self.VVCEYh()
  self.VVW0nF(False)
 def VVG6AF(self)  : self.close(True)
 def VVwvYc(self) : self.close(False)
 def VVnn51(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVCEYh(self):
  self.VVNW0J()
  self.VV3Qph()
  self.VVYBOp()
  self.VVoHBI()
 def VVDiuy(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVnn51()
   self.VVCEYh()
   FF5Ov8(self.refresh)
 def VVfk8g(self):
  if len(self["keyGreen"].getText()) > 0:
   FFcSjz(self, self.VVK4Ap, "Synchronize with Internet Date/Time ?")
 def VVK4Ap(self):
  self.VVCEYh()
  FF5Ov8(boundFunction(self.VVW0nF, True))
 def VVNW0J(self)  : self["keyRed"].show()
 def VVquYc(self)  : self["keyGreen"].show()
 def VVzQHE(self) : self["keyYellow"].show()
 def VVjC4K(self)  : self["keyBlue"].show()
 def VV3Qph(self)  : self["keyGreen"].hide()
 def VVYBOp(self) : self["keyYellow"].hide()
 def VVoHBI(self)  : self["keyBlue"].hide()
 def VVW0nF(self, sync):
  localTime = FFDqAA()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVcRNR(server)
   if epoch_time is not None:
    ntpTime = FFbrdA(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCZ10W()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVkdTu, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVzQHE()
  self.VVjC4K()
  if ok:
   self.VVquYc()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVkdTu(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVW0nF(False)
  except:
   pass
 def VVcRNR(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FF4L18():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCDNoQ(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF87m3(VV3Am4, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFyw62(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  FF5Ov8(self.VV1Xhe)
 def VV1Xhe(self):
  if FF4L18(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFrhNb(self["myBody"], color)
   FFrhNb(self["myLabel"], color)
  except:
   pass
class CC6K0D(Screen):
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFS34v()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FF87m3(VVo7vq, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCAG0G(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCAG0G(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCAG0G(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCxd3b()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFyw62(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVZzbA          ,
   "down"  : self.VVqzdb         ,
   "left"  : self.VVpaMT         ,
   "right"  : self.VVbQZO         ,
   "info"  : self.VVuTDm        ,
   "epg"  : self.VVuTDm        ,
   "menu"  : self.VViuP9         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "last"  : boundFunction(self.VVqUWM, -1)  ,
   "next"  : boundFunction(self.VVqUWM, 1)  ,
   "pageUp" : boundFunction(self.VVlB20, True) ,
   "chanUp" : boundFunction(self.VVlB20, True) ,
   "pageDown" : boundFunction(self.VVlB20, False) ,
   "chanDown" : boundFunction(self.VVlB20, False) ,
   "0"   : boundFunction(self.VVqUWM, 0)  ,
   "1"   : boundFunction(self.VVED83, pos=1) ,
   "2"   : boundFunction(self.VVED83, pos=2) ,
   "3"   : boundFunction(self.VVED83, pos=3) ,
   "4"   : boundFunction(self.VVED83, pos=4) ,
   "5"   : boundFunction(self.VVED83, pos=5) ,
   "6"   : boundFunction(self.VVED83, pos=6) ,
   "7"   : boundFunction(self.VVED83, pos=7) ,
   "8"   : boundFunction(self.VVED83, pos=8) ,
   "9"   : boundFunction(self.VVED83, pos=9) ,
  }, -1)
  self.onShown.append(self.VViwS9)
  self.onClose.append(self.onExit)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  self.sliderSNR.VV1A9F()
  self.sliderAGC.VV1A9F()
  self.sliderBER.VV1A9F(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVED83()
  self.VVAOeRInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVAOeR)
  except:
   self.timer.callback.append(self.VVAOeR)
  self.timer.start(500, False)
 def VVAOeRInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVyvzb(service)
  serviceName = self.tunerInfo.VVIGqt()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpNp5(self)
  tp = CCoReX()
  txt = tp.VV9XaE(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVAOeR(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVyvzb(service)
  self["mySNRdB"].setText(self.tunerInfo.VVUvNp())
  self["mySNR"].setText(self.tunerInfo.VVwL4o())
  self["myAGC"].setText(self.tunerInfo.VVQLeM())
  self["myBER"].setText(self.tunerInfo.VVekK2())
  self.sliderSNR.VV06nS(self.tunerInfo.VVrvXO())
  self.sliderAGC.VV06nS(self.tunerInfo.VVfG9j())
  self.sliderBER.VV06nS(self.tunerInfo.VV1qjq())
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpNp5(self)
    if state and not state == "Tuned":
     FFyMZt(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVuTDm(self):
  self.session.open(CCipAb)
 def VViuP9(self):
  FFHaIY(self, VV1ggQ + "_help_signal", "Signal Monitor (Keys)")
 def VVZzbA(self)  : self.VVED83(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVqzdb(self) : self.VVED83(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVpaMT(self) : self.VVED83(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVbQZO(self) : self.VVED83(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVED83(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVqUWM(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFhtLX(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVlB20(self, isUp):
  FFyMZt(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVAOeRInfo()
  except:
   pass
class CCAG0G(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VV1A9F(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFrhNb(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VV1ggQ +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFrhNb(self.covObj, self.covColor)
   else:
    FFrhNb(self.covObj, "#00006688")
    self.isColormode = True
  self.VV06nS(0)
 def VV06nS(self, val):
  val  = FFhtLX(val, self.minN, self.maxN)
  width = int(FFnufR(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFhtLX(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCg6oa(Screen):
 VVKktX    = 0
 VVQ3yX = 1
 VVIt71 = 2
 def __init__(self, session, titlePrefix="Processing", fncToRun=None, VVuWtK=None, barTheme=VVKktX):
  ratio = self.VVBjjY(barTheme)
  self.skin, self.skinParam = FF87m3(VVv5BW, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.fncToRun  = fncToRun
  self.VVuWtK = VVuWtK
  self.isCancelled = False
  self.isError  = False
  self.curValue  = 0
  self.maxValue  = 1
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVQKYK = None
  self.numInTitle  = False
  self.timer   = eTimer()
  self.myThread  = None
  FFyw62(self, title="Connecting ...")
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VViwS9)
  self.onClose.append(self.onExit)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  self.VVf10b()
  FFrhNb(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVItFp()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVItFp)
  except:
   self.timer.callback.append(self.VVItFp)
  self.timer.start(300, False)
  from threading import Thread as iThread
  self.myThread = iThread(name="download_PIcons", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def onExit(self):
  self.timer.stop()
 def VVx0AF(self, val):
  self.maxValue = val
  self.numInTitle = True
 def VVjB0W(self, addVal):
  self.counter += addVal
 def VVcSmY(self):
  self.isError = True
  self.cancel()
 def cancel(self):
  FFyMZt(self, "Cancelling ...")
  self.isCancelled = True
  if self.VVuWtK:
   self.VVuWtK(False, self.VVQKYK, self.counter, self.maxValue, self.isError)
  self.close()
 def VVItFp(self):
  val  = self.counter
  val  = FFhtLX(self.counter, 0, self.maxValue)
  width = int(FFnufR(val, 0, self.maxValue, 0, self.barWidth))
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
  if self.numInTitle:
   self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, val, self.maxValue))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if self.VVuWtK and not self.isCancelled:
    self.VVuWtK(True, self.VVQKYK, self.counter, self.maxValue, self.isError)
   self.close()
 def VVf10b(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme == self.VVQ3yX:
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
  elif self.barTheme == self.VVIt71:
   pass
 def VVBjjY(self, barTheme):
  if   barTheme == self.VVQ3yX : return 0.8
  elif barTheme == self.VVIt71 : return 1
  else              : return 1
class CCZ10W(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVuWtK = {}
  self.commandRunning = False
  self.VVW9b2  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVuWtK, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVuWtK[name] = VVuWtK
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVW9b2:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVMwGP, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVc76S , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVMwGP, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVc76S , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVc76S(name, retval)
  return True
 def VVMwGP(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVc76S(self, name, retval):
  if not self.VVW9b2:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVuWtK[name]:
   self.VVuWtK[name](self.appResults[name], retval)
  del self.VVuWtK[name]
 def VVTfHP(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCGImd(Screen):
 def __init__(self, session, title="", VVlqxJ=None, VV8HGF=False, VVjlzY=False, VV3rwq=False, VV4mTt=False, VVqQmI=False, VVglDm=False, VVfs8s=VVXhsS, VVQEZn=None, VVu1oF=False, VVnYJv=None, VV5KHh="", checkNetAccess=False, enableSaveRes=False):
  self.skin, self.skinParam = FF87m3(VVCHm0, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFyw62(self, addScrollLabel=True)
  if not VV5KHh:
   VV5KHh = "Processing ..."
  self["myLabel"].setText("   %s" % VV5KHh)
  self.VV8HGF   = VV8HGF
  self.VVjlzY   = VVjlzY
  self.VV3rwq   = VV3rwq
  self.VV4mTt  = VV4mTt
  self.VVqQmI = VVqQmI
  self.VVglDm = VVglDm
  self.VVfs8s   = VVfs8s
  self.VVQEZn = VVQEZn
  self.VVu1oF  = VVu1oF
  self.VVnYJv  = VVnYJv
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCZ10W()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFIP5j()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVlqxJ, str):
   self.VVlqxJ = [VVlqxJ]
  else:
   self.VVlqxJ = VVlqxJ
  if self.VV3rwq or self.VV4mTt:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VV8ben, VV8ben)
   self.VVlqxJ.append("echo -e '\n%s\n' %s" % (restartNote, FFPqb8(restartNote, VVApsx)))
   if self.VV3rwq:
    self.VVlqxJ.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVlqxJ.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVqQmI:
   FFyMZt(self, "Processing ...")
  self.onLayoutFinish.append(self.VVJx5t)
  self.onClose.append(self.VVveVG)
 def VVJx5t(self):
  self["myLabel"].VVEY9M(enableSave=self.enableSaveRes)
  if self.VV8HGF:
   self["myLabel"].VVQdyj()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVyaxr()
  else:
   self.VV2KEI()
 def VVyaxr(self):
  if FF4L18():
   self["myLabel"].setText("Processing ...")
   self.VV2KEI()
  else:
   self["myLabel"].setText(FFUIPk("\n   No connection to internet!", VVEiu9))
 def VV2KEI(self):
  allOK = self.container.ePopen(self.VVlqxJ[0], self.VVdP9T, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVdP9T("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVglDm or self.VV3rwq or self.VV4mTt:
    self["myLabel"].setText(FFlZwH("STARTED", VVApsx) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVnYJv:
   colorWhite = CCvT7T.VVD8kt(VVI8UI)
   color  = CCvT7T.VVD8kt(self.VVnYJv[0])
   words  = self.VVnYJv[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVfs8s=self.VVfs8s)
 def VVdP9T(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVlqxJ):
   allOK = self.container.ePopen(self.VVlqxJ[self.cmdNum], self.VVdP9T, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVdP9T("Cannot connect to Console!", -1)
  else:
   if self.VVqQmI and FFJbeE(self):
    FFyMZt(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVglDm:
    self["myLabel"].appendText("\n" + FFlZwH("FINISHED", VVApsx), self.VVfs8s)
   if self.VV8HGF or self.VVjlzY:
    self["myLabel"].VVQdyj()
   if self.VVQEZn is not None:
    self.VVQEZn()
   if not retval and self.VVu1oF:
    self.VVveVG()
 def VVveVG(self):
  if self.container.VVTfHP():
   self.container.killAll()
class CCAiz5(Screen):
 def __init__(self, session, VVlqxJ=None, VVqQmI=False):
  self.skin, self.skinParam = FF87m3(VVCHm0, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVhuan + "ajpanel_terminal.history"
  self.customCommandsFile = VVhuan + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFLHG0("pwd") or "/home/root"
  self.container   = CCZ10W()
  FFyw62(self, addScrollLabel=True)
  FF3p62(self["keyRed"] , "Stop Command")
  FF3p62(self["keyGreen"] , "OK = History")
  FF3p62(self["keyYellow"], "Menu = Custom Cmds")
  FF3p62(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVmSDo ,
   "red"  : self.VVH2kB   ,
   "cancel" : self.VVNSZQ   ,
   "menu"  : self.VV46gV ,
   "last"  : self.VVbGh9  ,
   "next"  : self.VVbGh9  ,
   "1"   : self.VVbGh9  ,
   "2"   : self.VVbGh9  ,
   "3"   : self.VVbGh9  ,
   "4"   : self.VVbGh9  ,
   "5"   : self.VVbGh9  ,
   "6"   : self.VVbGh9  ,
   "7"   : self.VVbGh9  ,
   "8"   : self.VVbGh9  ,
   "9"   : self.VVbGh9  ,
   "0"   : self.VVbGh9
  })
  self.onLayoutFinish.append(self.VViwS9)
  self.onClose.append(self.VVH2kB)
 def VViwS9(self):
  self["myLabel"].VVEY9M(isResizable=False)
  FFrhNb(self["keyGreen"]  , self.skinParam["titleColor"])
  FFrhNb(self["keyYellow"] , self.skinParam["titleColor"])
  FFrhNb(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVefxH(FFLHG0("date"), 5)
  result = FFLHG0("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVIOXl()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VV1ggQ + "LinuxCommands.lst"
   newTemplate = VV1ggQ + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFgzF5("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFgzF5("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVH2kB(self):
  if self.container.VVTfHP():
   self.container.killAll()
   self.VVefxH("Process killed\n", 4)
   self.VVIOXl()
 def VVNSZQ(self):
  if self.container.VVTfHP():
   FFcSjz(self, self.close, "Terminate command and exit ?")
  else:
   self.close()
 def VVIOXl(self):
  self.VVefxH(self.prompt, 1)
  self["keyRed"].hide()
 def VVefxH(self, txt, mode):
  if   mode == 1 : color = VVApsx
  elif mode == 2 : color = VVbHZ1
  elif mode == 3 : color = VVI8UI
  elif mode == 4 : color = VVEiu9
  elif mode == 5 : color = VVLIgE
  elif mode == 6 : color = VVZD1o
  else   : color = VVI8UI
  try:
   self["myLabel"].appendText(FFUIPk(txt, color))
  except:
   pass
 def VVp6kY(self, cmd):
  self["keyRed"].show()
  cmd = cmd.strip()
  if "#" in cmd:
   parts = cmd.split("#")
   left  = FFUIPk(parts[0].strip(), VVbHZ1)
   right = FFUIPk("#" + parts[1].strip(), VVZD1o)
   txt = "%s    %s\n" % (left, right)
  else:
   txt = "%s\n" % cmd
  self.VVefxH(txt, 2)
  lastLine = self.VVI9k4()
  if not lastLine or not cmd == lastLine:
   self.lastCommand = cmd
   self.VVWSSQ(cmd)
  span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
  if span:
   self.curDir = span.group(1)
  allOK = self.container.ePopen(cmd, self.VVdP9T, dataAvailFnc=self.dataAvail, curDir=self.curDir)
  if not allOK:
   FF538m(self, "Cannot connect to Console!")
  self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVefxH(data, 3)
 def VVdP9T(self, data, retval):
  if not retval == 0:
   self.VVefxH("Exit Code : %d\n" % retval, 4)
  self.VVIOXl()
 def VVmSDo(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVI9k4() == "":
   self.VVWSSQ("cd /tmp")
   self.VVWSSQ("ls")
  VVbelk = []
  if fileExists(self.commandHistoryFile):
   lines  = FFDyYj(self.commandHistoryFile)
   c = 0
   for line in reversed(lines):
    line = line.strip()
    if line and not line.startswith("#"):
     c += 1
     VVbelk.append((str(c), line))
   self.VVTwlc(VVbelk, title, self.commandHistoryFile, isHistory=True)
  else:
   FF4LjO(self, self.commandHistoryFile, title=title)
 def VVI9k4(self):
  lastLine = FFLHG0("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVWSSQ(self, cmd):
  os.system("echo '%s' >> %s" % (cmd, self.commandHistoryFile))
 def VV46gV(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFDyYj(self.customCommandsFile)
   lastLineIsSep = False
   VVbelk = []
   c = 0
   for line in lines:
    line = line.strip()
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVbelk.append((str(c), line))
   self.VVTwlc(VVbelk, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FF4LjO(self, self.customCommandsFile, title=title)
 def VVTwlc(self, VVbelk, title, filePath=None, isHistory=False):
  if VVbelk:
   VVjMdQ = "#05333333"
   if isHistory: VVCABW = VVG1bZ = VVZHzf = "#11000020"
   else  : VVCABW = VVG1bZ = VVZHzf = "#06002020"
   VVkbh1     = ("Send"   , self.VVnS7t  , [])
   VVcWvO    = ("Modify & Send" , self.VVEZTr  , [])
   if filePath : VVKois = ("Edit File"  , self.VV6G9Q , [filePath])
   else  : VVKois = None
   header      = ("No."  , "Commands")
   widths      = (7   , 93   )
   VVZOJU     = (CENTER  , LEFT   )
   FFed34(self, None, title=title, header=header, VVpuR3=VVbelk, VVZOJU=VVZOJU, VVEFlP=widths, VVQ020=22, VVkbh1=VVkbh1, VVcWvO=VVcWvO, VVKois=VVKois, VVwC3K=True
     , VVCABW   = VVCABW
     , VVG1bZ   = VVG1bZ
     , VVZHzf   = VVZHzf
     , VVaobe  = "#05ffff00"
     , VVjMdQ  = VVjMdQ
    )
  else:
   FFDXjZ(self, filePath, title=title)
 def VVnS7t(self, VVyGLE, title, txt, colList):
  cmd = colList[1].strip()
  VVyGLE.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVefxH("\n%s\n" % cmd, 6)
   self.VVefxH(self.prompt, 1)
  else:
   if cmd.startswith("passwd"):
    self.VVefxH(cmd, 2)
    self.VVefxH("\nCannot change passwrod from Console this way. Try using:\n", 4)
    txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
    for ch in txt:
     if not ch == "#":
      self.VVefxH(ch, 0)
    self.VVefxH("\nor\n", 4)
    self.VVefxH("echo root:NEW_PASSWORD | chpasswd\n", 0)
    self.VVIOXl()
   else:
    self.VVp6kY(cmd)
 def VVEZTr(self, VVyGLE, title, txt, colList):
  cmd = colList[1]
  self.VV9LAO(VVyGLE, cmd)
 def VV6G9Q(self, VVyGLE, filePath):
  if fileExists(filePath):
   CCi8JT(self, filePath, VVuWtK=boundFunction(self.VV4Fx6))
   VVyGLE.cancel()
  else:
   FF4LjO(self, filePath)
 def VV4Fx6(self, fileChanged):
  FF5Ov8(self.VV46gV)
 def VVbGh9(self):
  self.VV9LAO(None, self.lastCommand)
 def VV9LAO(self, VVyGLE, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FF5iHn(self, boundFunction(self.VVTUOH, VVyGLE), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVTUOH(self, VVyGLE, cmd):
  if cmd and len(cmd) > 0:
   self.VVp6kY(cmd)
   if VVyGLE:
    VVyGLE.cancel()
class CCMG11(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVxCeq="", VVNgBx=False, VVdnuB=False, isTrimEnds=True):
  self.skin, self.skinParam = FF87m3(VVZpeg, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFyw62(self, title, addLabel=True)
  FF3p62(self["keyRed"] , "Up/Down = Change")
  FF3p62(self["keyGreen"] , "Overwrite")
  FF3p62(self["keyYellow"], "Pick Key Map")
  FF3p62(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVdnuB   = VVdnuB
  self.VVNgBx  = VVNgBx
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVxCeq, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VV3MrQ      ,
   "green"    : self.VVJtYi    ,
   "yellow"   : self.VVCR6O      ,
   "blue"    : self.VVvZls     ,
   "menu"    : self.VV3qi8     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVG7Hw, True) ,
   "down"    : boundFunction(self.VVG7Hw, False) ,
   "left"    : self.VVxcUQ       ,
   "right"    : self.VVG8r4       ,
   "home"    : self.VVRJTK       ,
   "end"    : self.VVUAPx       ,
   "next"    : self.VVG0FV      ,
   "last"    : self.VV6qk1      ,
   "deleteForward"  : self.VVG0FV      ,
   "deleteBackward" : self.VV6qk1      ,
   "tab"    : self.VV5uU1       ,
   "toggleOverwrite" : self.VVJtYi    ,
   "0"     : self.VV6Q4j     ,
   "1"     : self.VV6Q4j     ,
   "2"     : self.VV6Q4j     ,
   "3"     : self.VV6Q4j     ,
   "4"     : self.VV6Q4j     ,
   "5"     : self.VV6Q4j     ,
   "6"     : self.VV6Q4j     ,
   "7"     : self.VV6Q4j     ,
   "8"     : self.VV6Q4j     ,
   "9"     : self.VV6Q4j
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVsID1()
  self.onShown.append(self.VViwS9)
  self.onClose.append(self.onExit)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  self["myLabel"].setText(self.message)
  self.VVa3NY()
  if self.VVNgBx : self.VVJtYi()
  else    : self.VVgVUh()
  FFEpG1(self)
  FFrhNb(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV9vtW)
  except:
   self.timer.callback.append(self.VV9vtW)
 def onExit(self):
  self.timer.stop()
 def VV3MrQ(self):
  self.VV3PJK()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VV3PJK()
  self.close(None)
 def VV3qi8(self):
  VVei97 = []
  VVei97.append(("Home"         , "home"    ))
  VVei97.append(("End"         , "end"     ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Clear All"       , "clearAll"   ))
  VVei97.append(("Clear To Home"      , "clearToHome"   ))
  VVei97.append(("Clear To End"       , "clearToEnd"   ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVrcHB:
   VVei97.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVei97.append(VVhJ3E)
  VVei97.append(("To Capital Letters"     , "toCapital"   ))
  VVei97.append(("To Small Letters"      , "toSmall"    ))
  FFrC6O(self, self.VVEUZa, title="Edit Options", VVei97=VVei97)
 def VVEUZa(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVRJTK()
   elif item == "end"     : self.VVUAPx()
   elif item == "clearAll"    : self.VV0WCr()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVRJTK()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVrcHB
    VVrcHB = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVrcHB)
    self.VVRJTK()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VV9vtW(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVJtYi(self):
  self["myInput"].toggleOverwrite()
  self.VVgVUh()
 def VVCR6O(self):
  self.session.openWithCallback(self.VVi5bX, boundFunction(CCPJrA, mode=self.charMode, VVdnuB=self.VVdnuB))
 def VVi5bX(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVa3NY()
 def VVgVUh(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVsID1(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VV3PJK(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVvNbK(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVxcUQ(self)     : self.VVuLDm(self["myInput"].left)
 def VVG8r4(self)     : self.VVuLDm(self["myInput"].right)
 def VVG0FV(self)     : self.VVuLDm(self["myInput"].delete)
 def VVRJTK(self)     : self.VVuLDm(self["myInput"].home)
 def VVUAPx(self)     : self.VVuLDm(self["myInput"].end)
 def VV6qk1(self)    : self.VVuLDm(self["myInput"].deleteBackward)
 def VV5uU1(self)     : self.VVuLDm(self["myInput"].tab)
 def VV0WCr(self)     : self["myInput"].setText("")
 def VVuLDm(self, fnc):
  fnc()
  self.VV9vtW()
 def VV6Q4j(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVvNbK(newChar, overwrite)
   self.VV0F0a(newChar, self["myInput"].mapping[number])
 def VVG7Hw(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCPJrA.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCPJrA.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVvNbK(newChar, True)
   for group in groups:
    if newChar in group:
     self.VV0F0a(newChar, group)
     break
 def VV0F0a(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVI8UI:
    group = VVLIgE + group.replace(newChar, FFUIPk(newChar, VVI8UI, VVLIgE))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVvZls(self):
  if self.VVdnuB : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVa3NY()
 def VVa3NY(self):
  self["myInput"].mapping = CCPJrA.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCPJrA.RCU_MAP_TITLES[self.charMode])
class CCPJrA(Screen):
 VVzfLy  = 0
 VVegEw  = 1
 VVsY9U  = 2
 VVuRT4  = 3
 VVqPHg = 4
 VVpNkB = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols, arabic_nums1, arabic1)
       , ( symbols, arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A" , u"\u0628")
       , (u"\u0647" , u"\u062A")
       )
 def __init__(self, session, mode=VVzfLy, VVdnuB=False):
  self.skin, self.skinParam = FF87m3(VVs0oG, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVdnuB  = VVdnuB
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFyw62(self, title=self.Title)
  FF3p62(self["keyRed"] ,"OK = Select")
  FF3p62(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVW9fh     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVLVXQ, -1) ,
   "next"  : boundFunction(self.VVLVXQ, +1) ,
   "left"  : boundFunction(self.VVLVXQ, -1) ,
   "right"  : boundFunction(self.VVLVXQ, +1) ,
  }, -1)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  FFrhNb(self["keyRed"], "#11222222")
  FFrhNb(self["keyGreen"], "#11222222")
  self.VV0FcD()
 def VV0FcD(self):
  self.VVmd5i()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVmd5i(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVLVXQ(self, direction):
  if self.VVdnuB : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VV0FcD()
 def VVW9fh(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCntWy(Screen):
 def __init__(self, session, title="", message="", VVfs8s=VVXhsS, VVx7ne=False, VVZHzf=None, VVQ020=30):
  self.skin, self.skinParam = FF87m3(VVCHm0, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVQ020)
  self.session   = session
  FFyw62(self, title, addScrollLabel=True)
  self.VVfs8s   = VVfs8s
  self.VVx7ne   = VVx7ne
  self.VVZHzf   = VVZHzf
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  self["myLabel"].VVEY9M(VVx7ne=self.VVx7ne)
  self["myLabel"].setText(self.message, self.VVfs8s)
  if self.VVZHzf:
   FFrhNb(self["myBody"], self.VVZHzf)
   FFrhNb(self["myLabel"], self.VVZHzf)
   FFInme(self["myLabel"], self.VVZHzf)
  self["myLabel"].VVQdyj()
class CCWmhs(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FF87m3(VVuUrL, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFyw62(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  path = VV1ggQ + "err.png"
  if fileExists(path):
   self["errPic"].instance.setScale(1)
   self["errPic"].instance.setPixmapFromFile(path)
class CCuzJP(Screen, CCF8XP):
 def __init__(self, session, enableZapping=True, portalTableParam=None):
  self.skin, self.skinParam = FF87m3(VVt2o7, 800, 170, 25, 10, 6, "#1100202a", "#1100202a", 20)
  CCF8XP.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.winHeight    = 0
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.cutListCounter   = 0
  self.isCutListFound   = 0
  FFyw62(self, "", addLabel=True)
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayBarM"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayJmp"] = Label("Jump: %d m" % self.jumpMinutes)
  self["myPlaySkp"] = Label()
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayInf"] = Label("Info")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVnr3G         ,
   "info"  : self.VVuTDm        ,
   "epg"  : self.VVuTDm        ,
   "menu"  : self.VViuP9         ,
   "cancel" : self.cancel         ,
   "blue"  : self.VV6NVq        ,
   "green"  : boundFunction(self.VV95Cj, True) ,
   "play"  : self.VVWY7N        ,
   "pause"  : self.VVWY7N        ,
   "stop"  : self.VVWY7N        ,
   "left"  : boundFunction(self.VVRutC, -1)   ,
   "right"  : boundFunction(self.VVRutC,  1)   ,
   "rewind" : self.VVE98i        ,
   "forward" : self.VVJR2B        ,
   "last"  : boundFunction(self.VVfqEH, 0)    ,
   "next"  : self.VVr5Z2        ,
   "pageUp" : boundFunction(self.VVEBxz, True) ,
   "chanUp" : boundFunction(self.VVEBxz, True) ,
   "pageDown" : boundFunction(self.VVEBxz, False) ,
   "chanDown" : boundFunction(self.VVEBxz, False) ,
   "0"   : boundFunction(self.VVOjYL , 10)  ,
   "1"   : boundFunction(self.VVOjYL , 1)  ,
   "2"   : boundFunction(self.VVOjYL , 2)  ,
   "3"   : boundFunction(self.VVOjYL , 3)  ,
   "4"   : boundFunction(self.VVOjYL , 4)  ,
   "5"   : boundFunction(self.VVOjYL , 5)  ,
   "6"   : boundFunction(self.VVOjYL , 6)  ,
   "7"   : boundFunction(self.VVOjYL , 7)  ,
   "8"   : boundFunction(self.VVOjYL , 8)  ,
   "9"   : boundFunction(self.VVOjYL , 9)
  }, -1)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  self.VVswxn()
  self.instance.move(ePoint(40, 40))
  size = self.instance.size()
  self.VVbHTj = int(size.width())
  self.winHeight1 = int(size.height())
  self.winHeight2 = int(self["myPlaySep"].getPosition()[1])
  FFkgl3(self["myPlayJmp"], "#0a666666")
  FFkgl3(self["myPlaySkp"], "#0affff00")
  FFrhNb(self["myPlayBlu"], "#1118188b")
  FFrhNb(self["myPlayInf"], "#11444444")
  self["myPlayBarM"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVNHG8)
  except:
   self.timer.callback.append(self.VVNHG8)
  self.timer.start(1000, False)
  self.VVNHG8("Checking ...")
  self.VV95Cj()
 def onExit(self):
  self.timer.stop()
 def VVswxn(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpNp5(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
 def VViuP9(self):
  FFHaIY(self, VV1ggQ + "_help_player", "Player Controller (Keys)")
 def VVnr3G(self):
  if self.isManualSeek:
   self.VVnYuZ()
   self.VVfqEH(self.manualSeekPts)
  else:
   if self.shown: self.hide()
   else   : self.show()
 def cancel(self):
  if self.isManualSeek:
   self.VVnYuZ()
  else:
   self.close()
 def VVuTDm(self):
  self.session.open(CCipAb)
 def VVWY7N(self):
  try:
   InfoBar.instance.playpauseService()
  except Exception as e:
   pass
  self.VVNHG8("Toggling Play/Pause ...")
 def VVnYuZ(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayBarM"].hide()
   self["myPlaySkp"].hide()
 def VVRutC(self, direc):
  seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt = self.VVV8RG()
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayBarM"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.jumpMinutes * 60.0
   else:
    self.manualSeekSec += direc * self.jumpMinutes * 60.0
    self.manualSeekSec = FFhtLX(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayBarM"].instance.size().width() + 1
   left = int(FFnufR(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayBarM"].instance.move(ePoint(left, int(self["myPlayBarM"].getPosition()[1])))
   self["myPlaySkp"].setText(FFhCAD(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVOjYL(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   FF3p62(self["myPlayJmp"], "Jump: %d m" % self.jumpMinutes)
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVNHG8("Changed Jump Minutes to : %d" % val)
 def VVNHG8(self, title=""):
  if title:
   self.timer.stop()
  txt = self.Title
  seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt = self.VVV8RG()
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(str(posTxt))
    self["myPlayVal"].setText(percTxt)
    val  = FFhtLX(percVal, 0, 100)
    width = int(FFnufR(val, 0, 100, 0, self.barWidth))
    self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
   if durTxt:
    self["myPlayDur"].setText(str(durTxt))
  if not self.isCutListFound and self.cutListCounter < 5:
   self.cutListCounter += 1
   if self.VV3tf6():
    self["myPlayBlu"].show()
    self.isCutListFound
  winH = self.instance.size().height()
  if durTxt:
   if winH < self.winHeight1:
    self.instance.resize(eSize(*(self.VVbHTj, self.winHeight1)))
  else:
   self["myPlayVal"].setText("0 %")
   if winH > self.winHeight2:
    self.instance.resize(eSize(*(self.VVbHTj, self.winHeight2)))
  if title:
   stateTxt = title
   FFkgl3(self["myPlayMsg"], "#00ff8000")
   self.timer.start(1000, False)
  else:
   stateTxt = ""
   if not posTxt and not durTxt:
    stateTxt = "Not playing yet ..."
   state = self.VVhXYg()
   if state:
    if state == "Playing" and not posTxt: stateTxt = "Unknown state"
    elif percVal == 100     : stateTxt = "End"
    else        : stateTxt = state
   state = self.VVYOhz()
   if state:
    stateTxt = state
   if stateTxt == "Playing": FFkgl3(self["myPlayMsg"], "#0000ff00")
   else     : FFkgl3(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVV8RG(self):
  percVal = durVal = posVal = seekable = 0
  percTxt = durTxt = posTxt = ""
  isEnded = False
  try:
   service = self.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFhCAD(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFhCAD(posVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt
 def VV6NVq(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VV3tf6()
   if cList:
    VVei97 = []
    for pts, what in cList:
     txt = FFhCAD(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVei97.append((txt, pts))
    FFrC6O(self, self.VVUiSq, VVei97=VVei97, title="Cut List")
   else:
    self.VVNHG8("No Cut-List for this channel !")
 def VVUiSq(self, item=None):
  if item:
   self.VVfqEH(item)
 def VV3tf6(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVJR2B(self) : self.VVATVx(self.jumpMinutes)
 def VVE98i(self) : self.VVATVx(-self.jumpMinutes)
 def VVATVx(self, mins):
  try:
   inst = InfoBar.instance
   inst.doSeekRelative(mins * 60 * 90000)
   inst.hide()
   if   mins > 0 : self.VVNHG8("Forawrd (%d min) ..." % self.jumpMinutes)
   elif mins < 0 : self.VVNHG8("Rewind (%d min) ..." % self.jumpMinutes)
  except:
   self.VVNHG8("Cannot jump")
 def VVF2ui(self):
  InfoBar.instance.VVF2ui()
 def VVfqEH(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVNHG8("Changing Time ...")
 def VVr5Z2(self):
  try:
   seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt = self.VVV8RG()
   if durVal > 0:
    pts = int(durVal * 60 * 90000)
    InfoBar.instance.doSeek(pts)
    self.VVNHG8("Jumping to end ...")
  except:
   pass
 def VVhXYg(self):
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVYOhz(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVEBxz(self, isUp):
  if self.enableZapping:
   if self.portalTableParam:
    self.VVEl61(isUp)
   else:
    try:
     if isUp : InfoBar.instance.zapDown()
     else : InfoBar.instance.zapUp()
     ok = True
    except:
     pass
    self.VVswxn()
    self.VV95Cj()
 def VVEl61(self, isUp):
  CCQps6_inatance, VVyGLE, mode = self.portalTableParam
  totRows = VVyGLE.VV6WUd()
  curRow = VVyGLE.VVKtZk()
  if totRows > 1:
   if isUp:
    nextRow = curRow + 1
    if nextRow > totRows - 1:
     nextRow = 0
   else:
    nextRow = curRow - 1
    if nextRow < 0:
     nextRow = totRows - 1
  VVyGLE.VVqjOl(nextRow)
  FFpgNe(VVyGLE, boundFunction(self.VVC0aj, mode, VVyGLE, CCQps6_inatance), title="Playing ...")
 def VVC0aj(self, mode, VVyGLE, CCQps6_inatance):
  colList = VVyGLE.VVgfwt()
  if mode == "localIptv":
   CCQps6_inatance.VVRBGc(VVyGLE, "", "", colList)
  elif isinstance(mode, int):
   CCQps6_inatance.VVi7kJ(mode, VVyGLE, "", "", colList)
  else:
   CCQps6_inatance.VVeRTR(mode, VVyGLE, "", "", colList, forceZap=True)
  self.close()
 def VV95Cj(self, refresh=False):
  try:
   if not refresh:
    seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt = self.VVV8RG()
    if posTxt:
     return
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFpNp5(self)
   valid, mode, host, mac, chCode, epNum, epId, chCm, phpParam = self.VV2fhT(decodedUrl)
   if not valid:
    return
   self.VVYDvz = host
   self.VVf8Cq  = mac
   url = self.VVhXO2(mode, chCm, epNum, epId)
   if self.VVYDvz and self.VVf8Cq:
    if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
     self.VVNHG8("Refreshing Portal")
     FF5Ov8(boundFunction(self.VVOPW9, mode, refCode, chName, iptvRef, url, phpParam))
  except:
   pass
 def VVOPW9(self, mode, refCode, chName, iptvRef, url, phpParam):
  token, profile = self.VVKusK(VVdtwB=False)
  if not token:
   return False
  res, err = self.VVpguz(url)
  newCmd  = ""
  if not err:
   try:
    newCmd = CCQps6.VVDB0e(jLoads(res.text)['js'], "cmd")
   except:
    pass
  newRefCode = ""
  if newCmd:
   if not refCode.endswith(":"):
    refCode += ":"
   chUrl = newCmd.replace("ffmpeg ", "")
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl.strip() + ":" + chName
   ndx = chUrl.find("play_token=")
   if ndx > -1:
    ndx = chUrl.find(":", ndx)
    if ndx > -1:
     left  = chUrl[:ndx]
     right  = chUrl[ndx:]
     newRefCode = left + "&" + phpParam + right
   ndx = iptvRef.find("&end=")
   if ndx > -1:
    left = iptvRef[:ndx]
    right = iptvRef[ndx:]
    iptvRef = left + right.replace("%3a", ":")
  if newRefCode:
   success = self.VVSRTM(iptvRef, newRefCode)
   FFY1uw(self, newRefCode, VVda8V=False)
 def VVSRTM(self, oldCode, newCode):
  bPath = FF33QU()
  if bPath:
   txt = FFUy6Y(bPath)
   if oldCode in txt:
    txt = txt.replace(oldCode, newCode)
    with open(bPath, "w") as f:
     f.write(txt)
    FF3PkJ()
    return True
  return False
class CC6ucE(Screen):
 def __init__(self, session, title="", VVRS1f="Continue?", VVUSaH=True, VV5nHT=False):
  self.skin, self.skinParam = FF87m3(VVfGZx, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVRS1f = VVRS1f
  self.VV5nHT = VV5nHT
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVUSaH : VVei97 = [no , yes]
  else   : VVei97 = [yes, no ]
  FFyw62(self, title, VVei97=VVei97, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVnr3G ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVRS1f)
  if self.VV5nHT:
   self["myLabel"].instance.setHAlign(0)
  self.VVS2Fw()
  FFgNUr(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFUtq8(self["myMenu"])
  FFIxV6(self, self["myMenu"])
 def VVnr3G(self):
  item = FFKfA8(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVS2Fw(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CC7gw9(Screen):
 def __init__(self, session, title="", VVei97=None, width=1000, OKBtnFnc=None, VVmf6o=None, VVVheL=None, VVdFS8=None, VVQixJ=None, VVrJr1=False, VV4qsP=False):
  self.skin, self.skinParam = FF87m3(VVseVH, width, 850, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVei97   = VVei97
  self.OKBtnFnc   = OKBtnFnc
  self.VVmf6o   = VVmf6o
  self.VVVheL  = VVVheL
  self.VVdFS8  = VVdFS8
  self.VVQixJ   = VVQixJ
  self.VVrJr1  = VVrJr1
  self.VV4qsP  = VV4qsP
  FFyw62(self, title, VVei97=VVei97)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVnr3G          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVoEJy         ,
   "green"  : self.VVuwoM         ,
   "yellow" : self.VVQWt9         ,
   "blue"  : self.VVZU8Z         ,
   "pageUp" : self.VV8HQh       ,
   "chanUp" : self.VV8HQh       ,
   "pageDown" : self.VVnICs        ,
   "chanDown" : self.VVnICs
  }, -1)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  FFgNUr(self["myMenu"])
  FFhCiv(self)
  self.VVnqYF(self["keyRed"]  , self.VVmf6o )
  self.VVnqYF(self["keyGreen"] , self.VVVheL )
  self.VVnqYF(self["keyYellow"] , self.VVdFS8 )
  self.VVnqYF(self["keyBlue"]  , self.VVQixJ )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFEpG1(self)
 def VVnqYF(self, btnObj, btnFnc):
  if btnFnc:
   FF3p62(btnObj, btnFnc[0])
 def VVnr3G(self):
  item = FFKfA8(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVrJr1: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVoEJy(self)  : self.VVuLDm(self.VVmf6o)
 def VVuwoM(self) : self.VVuLDm(self.VVVheL)
 def VVQWt9(self) : self.VVuLDm(self.VVdFS8)
 def VVZU8Z(self) : self.VVuLDm(self.VVQixJ)
 def VVuLDm(self, btnFnc):
  if btnFnc:
   item = FFKfA8(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VV4qsP:
    self.cancel()
 def VVzrHw(self, VVei97):
  if len(VVei97) > 0:
   newList = []
   for item in VVei97:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VViCHK(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VV8HQh(self):
  self["myMenu"].moveToIndex(0)
 def VVnICs(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCOyCZ(Screen):
 def __init__(self, session, title="", header=None, VVpuR3=None, VVZOJU=None, VVEFlP=None, VVQ020=24, VVwC3K=False, VVkbh1=None, VVsYEM=None, VV1DDw=None, VVY4BM=None, VVcWvO=None, VVKois=None, VVrjcc=None, VVoSIN=None, VVVrwp=None, VVsfQF=-1, VV6WOa=False, searchCol=0, VVCABW=None, VVG1bZ=None, VVumOa="#00dddddd", VVZHzf="#11002233", VVaobe="#00ff8833", VVjMdQ="#11111111", VVonRc="#0a555555", VVwPp6="#0affffff", VV8hLc="#11552200", VVCEvn="#0055ff55"):
  self.skin, self.skinParam = FF87m3(VVem0w, 1400, 800, 50, 10, 5, "#22003344", "#22002233", 24, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFyw62(self, title)
  self.header     = header
  self.VVpuR3     = VVpuR3
  self.totalCols    = len(VVpuR3[0])
  self.VVLoNb   = 0
  self.lastSortModeIsReverese = False
  self.VVwC3K   = VVwC3K
  self.VVdvot   = 0.01
  self.VV5TZP   = 0.02
  self.VVqKnn  = 1
  self.VVEFlP = VVEFlP
  self.colWidthPixels   = []
  self.VVkbh1   = VVkbh1
  self.OKButtonObj   = None
  self.VVsYEM   = VVsYEM
  self.VV1DDw   = VV1DDw
  self.VVY4BM   = VVY4BM
  self.VVcWvO  = VVcWvO
  self.VVKois   = VVKois
  self.VVrjcc    = VVrjcc
  self.VVoSIN   = VVoSIN
  self.VVVrwp  = VVVrwp
  self.VVsfQF    = VVsfQF
  self.VV6WOa   = VV6WOa
  self.searchCol    = searchCol
  self.VVZOJU    = VVZOJU
  self.keyPressed    = -1
  self.VVQ020    = FFmGf6(VVQ020)
  self.VVU7nN    = FFP3rc(self.VVQ020, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVCABW    = VVCABW
  self.VVG1bZ      = VVG1bZ
  self.VVumOa    = FFB7IS(VVumOa)
  self.VVZHzf    = FFB7IS(VVZHzf)
  self.VVaobe    = FFB7IS(VVaobe)
  self.VVjMdQ    = FFB7IS(VVjMdQ)
  self.VVonRc   = FFB7IS(VVonRc)
  self.VVwPp6    = FFB7IS(VVwPp6)
  self.VV8hLc    = FFB7IS(VV8hLc)
  self.VVCEvn   = FFB7IS(VVCEvn)
  self.VVABAC  = False
  self.selectedItems   = 0
  self.VVXhrG   = FFB7IS("#01fefe01")
  self.VVkHmY   = FFB7IS("#11400040")
  self.VV9Xrx  = self.VVXhrG
  self.VVsoKO  = self.VVjMdQ
  if self.VV6WOa:
   self["keyMenu1F"].hide()
   self["keyMenu1"].hide()
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVBR1I  ,
   "red"   : self.VVKZ1v  ,
   "green"   : self.VVnAjj ,
   "yellow"  : self.VVtEus ,
   "blue"   : self.VVZ5Ti  ,
   "menu"   : self.VVtJEa ,
   "info"   : self.VVa656  ,
   "cancel"  : self.VVrPUD  ,
   "up"   : self.VVLJXB    ,
   "down"   : self.VVNieP  ,
   "left"   : self.VV0SFj   ,
   "right"   : self.VV7Mgk  ,
   "pageUp"  : self.VVRx4q  ,
   "chanUp"  : self.VVRx4q  ,
   "pageDown"  : self.VVz50Z  ,
   "chanDown"  : self.VVz50Z
  }, -1)
  FFSIMa(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  try:
   self.VVHbGC()
  except Exception as err:
   FF538m(self, str(err))
   self.close(None)
 def VVHbGC(self):
  FFEpG1(self)
  if self.VVCABW:
   FFrhNb(self["myTitle"], self.VVCABW)
  if self.VVG1bZ:
   FFrhNb(self["myBody"] , self.VVG1bZ)
   FFrhNb(self["myTableH"] , self.VVG1bZ)
   FFrhNb(self["myTable"] , self.VVG1bZ)
   FFrhNb(self["myBar"]  , self.VVG1bZ)
  self.VVnqYF(self.VV1DDw  , self["keyRed"])
  self.VVnqYF(self.VVY4BM  , self["keyGreen"])
  self.VVnqYF(self.VVcWvO , self["keyYellow"])
  self.VVnqYF(self.VVKois  , self["keyBlue"])
  if self.VVkbh1:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVkbh1[0])
    FFrhNb(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVU7nN)
  self["myTableH"].l.setFont(0, gFont(VVUC67, self.VVQ020))
  self["myTable"].l.setItemHeight(self.VVU7nN)
  self["myTable"].l.setFont(0, gFont(VVUC67, self.VVQ020))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVU7nN)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVU7nN))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVU7nN)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVU7nN
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVU7nN * len(self.VVpuR3) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVEFlP:
   self.VVEFlP = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVEFlP)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVZOJU:
   self.VVZOJU = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVZOJU
   self.VVZOJU = []
   for item in tmpList:
    self.VVZOJU.append(item | RT_VALIGN_CENTER)
  self.VV2REw()
  if self.VVrjcc:
   self.VVrjcc(self)
 def VVnqYF(self, btnFnc, btn):
  if btnFnc : FF3p62(btn, btnFnc[0])
  else  : FF3p62(btn, "")
 def VVqXT5(self, waitTxt):
  FFpgNe(self, self.VV2REw, title=waitTxt)
 def VV2REw(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVVQ4N(0, self.header, self.VVwPp6, self.VV8hLc, self.VVwPp6, self.VV8hLc, self.VVCEvn)])
   rows = []
   for c, row in enumerate(self.VVpuR3):
    rows.append(self.VVVQ4N(c, row, self.VVumOa, self.VVZHzf, self.VVaobe, self.VVjMdQ, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVsfQF > -1:
    self["myTable"].moveToIndex(self.VVsfQF )
   self.VVHCva()
   if self.VV6WOa:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVU7nN * len(self.VVpuR3)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVoSIN:
    self.VVuLDm(self.VVoSIN, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FF538m(self, str(err))
    self.close()
   except:
    pass
 def VVVQ4N(self, keyIndex, columns, VVumOa, VVZHzf, VVaobe, VVjMdQ, VVCEvn):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVCEvn and ndx == self.VVLoNb : textColor = VVCEvn
   else           : textColor = VVumOa
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.+)", entry, IGNORECASE)
   if span:
    c = FFB7IS(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVZHzf = c
    entry = span.group(3)
   if self.VVZOJU[ndx] & LEFT:
    entry = " " + entry
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVU7nN)
           , font   = 0
           , flags   = self.VVZOJU[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVZHzf
           , color_sel  = VVaobe
           , backcolor_sel = VVjMdQ
           , border_width = 1
           , border_color = self.VVonRc
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVa656(self):
  rowData = self.VVQ8zJ()
  if rowData:
   title, txt, colList = rowData
   if self.VVsYEM:
    fnc  = self.VVsYEM[1]
    params = self.VVsYEM[2]
    fnc(self, title, txt, colList)
   else:
    FF6wpe(self, txt, title)
 def VVBR1I(self):
  if   self.VVABAC : self.VV6l2H(self.VVKtZk(), mode=2)
  elif self.VVkbh1  : self.VVuLDm(self.VVkbh1, None)
  else      : self.VVa656()
 def VVKZ1v(self) : self.VVuLDm(self.VV1DDw , self["keyRed"])
 def VVnAjj(self) : self.VVuLDm(self.VVY4BM , self["keyGreen"])
 def VVtEus(self): self.VVuLDm(self.VVcWvO , self["keyYellow"])
 def VVZ5Ti(self) : self.VVuLDm(self.VVKois , self["keyBlue"])
 def VVuLDm(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFyMZt(self, buttonFnc[3])
    FF5Ov8(boundFunction(self.VVDouf, buttonFnc))
   else:
    self.VVDouf(buttonFnc)
 def VVDouf(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVQ8zJ()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VV6l2H(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VVpuR3[ndx]
   isSelected = row[1][9] == self.VVXhrG
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVVQ4N(ndx, item, self.VVumOa, self.VVZHzf, self.VVaobe, self.VVjMdQ, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVVQ4N(ndx, item, self.VVXhrG, self.VVkHmY, self.VV9Xrx, self.VVsoKO, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVHCva()
 def VVelRB(self):
  FFpgNe(self, self.VV8Tfx, title="Selecting all ...")
 def VV8Tfx(self):
  self.VV0r1n(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVXhrG
   if not isSelected:
    item = self.VVpuR3[ndx]
    newRow = self.VVVQ4N(ndx, item, self.VVXhrG, self.VVkHmY, self.VV9Xrx, self.VVsoKO, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVHCva()
  self.VVDbve()
 def VVOqpL(self):
  FFpgNe(self, self.VVMAjc, title="Unselecting all ...")
 def VVMAjc(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVXhrG:
    item = self.VVpuR3[ndx]
    newRow = self.VVVQ4N(ndx, item, self.VVumOa, self.VVZHzf, self.VVaobe, self.VVjMdQ, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVHCva()
  self.VVDbve()
 def VVQ8zJ(self):
  item = self["myTable"].getCurrent()
  if item:
   rowNum = item[0] + 1
   txt  = ""
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    if self.VVEFlP[i - 1] > 1 or self.VVEFlP[i - 1] == self.VVdvot:
     if self.header : txt += "%s\t: %s\n" % (self.header[i - 1], colTxt)
     else   : txt += "Col-%d\t: %s\n" % (i, colTxt)
    colList.append(colTxt)
   return "Row Number : %d of %d\n\n" % (rowNum, len(self.VVpuR3)), txt, colList
  else:
   return None
 def VVrPUD(self):
  if self.VVVrwp : self.VVVrwp(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVfZxh(self):
  return self["myTitle"].getText().strip()
 def VVgPDp(self, title):
  self["myTitle"].setText("  " + title)
 def VVTN1E(self, txt):
  FFyMZt(self, txt)
 def VVPKXQ(self, txt):
  FFyMZt(self, txt, 1000)
 def VVDtzl(self):
  FFyMZt(self)
 def VVWXHx(self):
  return len(self.VVpuR3)
 def VVbiPX(self): self["keyGreen"].show()
 def VVadAo(self): self["keyGreen"].hide()
 def VVKtZk(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VV6WUd(self):
  return len(self["myTable"].list)
 def VV0r1n(self, isOn):
  self.VVABAC = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   if self.VVKois: self["keyBlue"].hide()
   if self.VVkbh1 and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
   if self.VVKois: self["keyBlue"].show()
   if self.VVkbh1 and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVkbh1[0])
   self.VVOqpL()
  FFrhNb(self["myTitle"], color)
  FFrhNb(self["myBar"]  , color)
 def VV2LY7(self):
  return self.VVABAC
 def VVk8NP(self):
  return self.selectedItems
 def VVDbve(self):
  self.hide()
  self.show()
 def VVqjOl(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVHCva()
 def VV5eiw(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVHCva()
 def VVw7pK(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VVpuR3:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVk8mA(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVWXHx()
  txt += FFlZwH("Total Unique Items", VVEiu9)
  for i in range(self.totalCols):
   if self.VVEFlP[i - 1] > 1 or self.VVEFlP[i - 1] == self.VVdvot:
    name, tot = self.VVw7pK(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FF6wpe(self, txt)
 def VVGmDB(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVgfwt(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVwB4B(self, newList, newTitle=""):
  if newList:
   self.VVpuR3 = newList
   if self.VVwC3K and self.VVLoNb == 0:
    self.VVpuR3 = sorted(self.VVpuR3, key=lambda x: int(x[self.VVLoNb])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VVpuR3 = sorted(self.VVpuR3, key=lambda x: x[self.VVLoNb].lower(), reverse=self.lastSortModeIsReverese)
   self.VVqXT5("Refreshing ...")
   if newTitle:
    self.VVgPDp(newTitle)
  else:
   FF538m(self, "Cannot refresh list")
   self.cancel()
 def VVQ7gV(self, data):
  ndx = self.VVKtZk()
  newRow = self.VVVQ4N(ndx, data, self.VVumOa, self.VVZHzf, self.VVaobe, self.VVjMdQ, None)
  if newRow:
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVDbve()
   return True
  else:
   return False
 def VVu02S(self, colNum, textToFind, VVdtwB=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVHCva()
    break
  else:
   if VVdtwB:
    FFyMZt(self, "Not found", 1000)
 def VV8pUN(self, colDict, VVdtwB=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVHCva()
    return
  if VVdtwB:
   FFyMZt(self, "Not found", 1000)
 def VV8pUN_partial(self, colDict, VVdtwB=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVHCva()
    return
  if VVdtwB:
   FFyMZt(self, "Not found", 1000)
 def VVTtN2(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVlab8(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVXhrG:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVwPno(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVtJEa(self):
  if not self["keyMenu2F"].getVisible():
   return
  if not self.VV6WOa:
   VVei97 = []
   VVei97.append(("Table Statistcis"             , "tableStat"  ))
   VVei97.append(VVhJ3E)
   VVei97.append((FFUIPk("Export Table to .html"     , VVEiu9) , "VVsHuD" ))
   VVei97.append((FFUIPk("Export Table to .csv"     , VVEiu9) , "VV5ocZ" ))
   VVei97.append((FFUIPk("Export Table to .txt (Tab Separated)", VVEiu9) , "VVeios" ))
   VVei97.append(VVhJ3E)
   for i in range(self.totalCols):
    if self.header : name = self.header[i]
    else   : name = "Col-%d" % i
    if self.VVEFlP[i] > 1 or self.VVEFlP[i] == self.VV5TZP:
     VVei97.append(("Sort by : %s" % name, i))
   if VVei97:
    FFrC6O(self, self.VVsFsd, VVei97=VVei97, title=self.VVfZxh())
 def VVsFsd(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVk8mA()
   elif item == "VVsHuD": FFpgNe(self, self.VVsHuD, title=title)
   elif item == "VV5ocZ" : FFpgNe(self, self.VV5ocZ , title=title)
   elif item == "VVeios" : FFpgNe(self, self.VVeios , title=title)
   else:
    isReversed = False
    if self.VVLoNb == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVwC3K and item == 0:
     self.VVpuR3 = sorted(self.VVpuR3, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VVpuR3 = sorted(self.VVpuR3, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVLoNb = item
    self.VVqXT5("Sorting ...")
 def VVLJXB(self):
  self["myTable"].up()
  self.VVHCva()
 def VVNieP(self):
  self["myTable"].down()
  self.VVHCva()
 def VV0SFj(self):
  self["myTable"].pageUp()
  self.VVHCva()
 def VV7Mgk(self):
  self["myTable"].pageDown()
  self.VVHCva()
 def VVRx4q(self):
  self["myTable"].moveToIndex(0)
  self.VVHCva()
 def VVz50Z(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVHCva()
 def VVeios(self):
  expFile = self.VVEJ81() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVq1Tj()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VVpuR3:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVEFlP[ndx] > self.VVqKnn:
      col = self.VVkZGO(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVF1nQ(expFile)
 def VV5ocZ(self):
  expFile = self.VVEJ81() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVq1Tj()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VVpuR3:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVEFlP[ndx] > self.VVqKnn:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVkZGO(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVF1nQ(expFile)
 def VVsHuD(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVfZxh(), PLUGIN_NAME, VVOn61)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVfZxh()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVq1Tj()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVEFlP:
   colgroup += '   <colgroup>'
   for w in self.VVEFlP:
    if w > self.VVqKnn:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVEJ81() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VVpuR3:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVEFlP[ndx] > self.VVqKnn:
      col = self.VVkZGO(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVF1nQ(expFile)
 def VVq1Tj(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVEFlP[ndx] > self.VVqKnn:
     newRow.append(col.strip())
  return newRow
 def VVkZGO(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  return FFfEyW(col)
 def VVEJ81(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVfZxh())
  fileName = fileName.replace("__", "_")
  path  = FFGYYB(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFAH5e()
  return expFile
 def VVF1nQ(self, expFile):
  FFRg6s(self, "File exported to:\n\n%s" % expFile, title=self.VVfZxh())
 def VVHCva(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CC4on1(Screen):
 def __init__(self, session, Title="", VVkojI=None):
  self.skin, self.skinParam = FF87m3(VVkuU0, 1400, 800, 50, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FFyw62(self, Title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VVkojI = VVkojI
  if len(Title) == 0 : Title = FFIP5j()
  else    : Title = "File : %s" % VVkojI
  self["myTitle"] = Label("  %s" % Title)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  allOK = FFGJQR(self["myLabel"], self.VVkojI)
  if not allOK:
   FF538m(self, "Could not view this picture file")
   self.close()
class CCr029(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FF87m3(VVal8u, 1400, 950, 50, 40, 40, "#11201010", "#11101010", 30, barHeight=40, topRightBtns=1)
  self.session  = session
  FFyw62(self)
  FF3p62(self["keyGreen"], "Save")
  self.VVpuR3 = []
  self.VVpuR3.append(getConfigListEntry("Show in Main Menu"         , CFG.showInMainMenu   ))
  self.VVpuR3.append(getConfigListEntry("Show in Extensions Menu"        , CFG.showInExtensionMenu  ))
  self.VVpuR3.append(getConfigListEntry("Show in Channel List Context Menu"     , CFG.showInChannelListMenu  ))
  self.VVpuR3.append(getConfigListEntry("Input Type"           , CFG.keyboard     ))
  self.VVpuR3.append(getConfigListEntry("Signal & Player Cotroller Hotkey"     , CFG.hotkey_signal    ))
  self.VVpuR3.append(getConfigListEntry(VV8ben *2            ,         ))
  self.VVpuR3.append(getConfigListEntry("Default IPTV Reference Type"       , CFG.iptvAddToBouquetRefType ))
  self.VVpuR3.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"    , CFG.hideIptvServerAdultWords ))
  self.VVpuR3.append(getConfigListEntry('Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)' , CFG.hideIptvServerChannPrefix ))
  self.VVpuR3.append(getConfigListEntry(VV8ben *2            ,         ))
  self.VVpuR3.append(getConfigListEntry("PIcons Path"           , CFG.PIconsPath    ))
  self.VVpuR3.append(getConfigListEntry(VV8ben *2            ,         ))
  self.VVpuR3.append(getConfigListEntry("Backup/Restore Path"         , CFG.backupPath    ))
  self.VVpuR3.append(getConfigListEntry("Created Package Files (IPK/DEB)"      , CFG.packageOutputPath   ))
  self.VVpuR3.append(getConfigListEntry("Downloaded Packages (from feeds)"     , CFG.downloadedPackagesPath ))
  self.VVpuR3.append(getConfigListEntry("Exported Tables"          , CFG.exportedTablesPath  ))
  self.VVpuR3.append(getConfigListEntry("Exported PIcons"          , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, self.VVpuR3, session)
  self["setupActions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard", "OkCancelActions"],
  {
   "ok"  : self.VVnr3G   ,
   "OK"  : self.VVnr3G   ,
   "green"  : self.VV9Av0  ,
   "menu"  : self.VV0ODf ,
   "cancel" : self.VVRAKD
  }, -1)
  self.titleText = "  Settings"
  self["myTitle"].setText(self.titleText)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  FFgNUr(self["config"])
  FFhCiv(self,  self["config"])
  FFEpG1(self)
 def VVnr3G(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.PIconsPath    : self.VVyXp5(item)
   elif item == CFG.backupPath    : self.VVyXp5(item)
   elif item == CFG.packageOutputPath  : self.VVyXp5(item)
   elif item == CFG.downloadedPackagesPath : self.VVyXp5(item)
   elif item == CFG.exportedTablesPath  : self.VVyXp5(item)
   elif item == CFG.exportedPIconsPath  : self.VVyXp5(item)
 def VVyXp5(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(boundFunction(self.VV2FHi, configObj)
         , boundFunction(CCyaF0, mode=CCyaF0.BROWSER_MODE_DIR_PICKER, VVGjUA=sDir))
 def VV2FHi(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVRAKD(self):
  if CFG.showInMainMenu.isChanged()    or \
   CFG.showInExtensionMenu.isChanged()   or \
   CFG.showInChannelListMenu.isChanged()  or \
   CFG.keyboard.isChanged()     or \
   CFG.hotkey_signal.isChanged()    or \
   CFG.iptvAddToBouquetRefType.isChanged()  or \
   CFG.hideIptvServerAdultWords.isChanged() or \
   CFG.hideIptvServerChannPrefix.isChanged() or \
   CFG.PIconsPath.isChanged()     or \
   CFG.backupPath.isChanged()     or \
   CFG.packageOutputPath.isChanged()   or \
   CFG.downloadedPackagesPath.isChanged()  or \
   CFG.exportedTablesPath.isChanged()   or \
   CFG.exportedPIconsPath.isChanged():
    FFcSjz(self, self.VV9Av0, "Save Changes ?", callBack_No=self.cancel)
  else:
   self.cancel()
 def VV9Av0(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVvqly()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VV0ODf(self):
  VVei97 = []
  VVei97.append(("Use Backup directory in all other paths"      , "VVfvcb"   ))
  VVei97.append(("Reset all to default (including File Manager bookmarks)"  , "VV0Oy2"   ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Change Text Color Scheme (for Transparent Text)"    , "changeColorScheme" ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Backup %s Settings" % PLUGIN_NAME        , "VVTaMt"  ))
  VVei97.append(("Restore %s Settings" % PLUGIN_NAME       , "VVi1xz"  ))
  if fileExists(VVhuan + VVEMg1):
   VVei97.append(VVhJ3E)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVei97.append(('%s Checking for Update' % txt1       , txt2     ))
   VVei97.append(("Reinstall %s" % PLUGIN_NAME        , "VVu01u"  ))
   VVei97.append(("Update %s" % PLUGIN_NAME        , "VVXn8W"   ))
  FFrC6O(self, self.VVAo1P, VVei97=VVei97, title="Config. Options")
 def VVAo1P(self, item=None):
  if item:
   if   item == "VVfvcb"  : FFcSjz(self, self.VVfvcb , "Use Backup directory in all other paths (and save) ?")
   elif item == "VV0Oy2"  : FFcSjz(self, self.VV0Oy2, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCvT7T)
   elif item == "VVTaMt" : self.VVTaMt()
   elif item == "VVi1xz" : FFpgNe(self, self.VVi1xz, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVGEz7(True)
   elif item == "disableChkUpdate" : self.VVGEz7(False)
   elif item == "VVu01u" : FFpgNe(self, self.VVu01u , "Checking Server ...")
   elif item == "VVXn8W"  : FFpgNe(self, self.VVXn8W  , "Checking Server ...")
 def VVTaMt(self):
  path = "%sajpanel_settings_%s" % (VVhuan, FFAH5e())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFRg6s(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVi1xz(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFofdg("find / %s -iname '%s*' | grep %s" % (FFRwKj(1), name, name))
  if lines:
   lines.sort()
   VVei97 = []
   for line in lines:
    VVei97.append((line, line))
   FFrC6O(self, boundFunction(self.VVzonr, title), title=title, VVei97=VVei97, width=1200)
  else:
   FF538m(self, "No settings files found !", title=title)
 def VVzonr(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFDyYj(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVvqly()
    FFIa5N()
   else:
    FF4LjO(SELF, path, title=title)
 def VVGEz7(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVfvcb(self):
  newPath = FFGYYB(VVhuan)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVvqly()
 @staticmethod
 def VVcUvJ():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VV0Oy2(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.PIconsPath.setValue(VVLTqb)
  CFG.backupPath.setValue(CCr029.VVcUvJ())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  CFG.showInMainMenu.save()
  CFG.showInExtensionMenu.save()
  CFG.showInChannelListMenu.save()
  CFG.keyboard.save()
  CFG.hotkey_signal.save()
  CFG.iptvAddToBouquetRefType.save()
  CFG.hideIptvServerAdultWords.save()
  CFG.hideIptvServerChannPrefix.save()
  CFG.PIconsPath.save()
  CFG.backupPath.save()
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  CFG.browserStartPath.save()
  CFG.browserBookmarks.save()
  self.VVvqly()
  self.close()
 def VVvqly(self):
  configfile.save()
  global VVhuan
  VVhuan = CFG.backupPath.getValue()
  FF5DqA()
 def VVXn8W(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVVfGG(title)
  if webVer:
   FFcSjz(self, boundFunction(FFpgNe, self, boundFunction(self.VVNEiS, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVu01u(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVVfGG(title, True)
  if webVer:
   FFcSjz(self, boundFunction(FFpgNe, self, boundFunction(self.VVNEiS, webVer, title)), "Install and Restart ?", title=title)
 def VVNEiS(self, webVer, title):
  url = self.VVCCDS(self, title)
  if url:
   VVW9b2 = FFeW8z() == "dpkg"
   if VVW9b2 == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVW9b2 else "ipk")
   path, err = FFOwIM(url + fName, fName, timeout=2)
   if path:
    cmd = FFVVjD(VVmVK0, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FF8mHD(self, cmd)
    else:
     FF9VHl(self, title=title)
   else:
    FF538m(self, err, title=title)
 def VVVfGG(self, title, anyVer=False):
  url = self.VVCCDS(self, title)
  if not url:
   return ""
  path, err = FFOwIM(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FF538m(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFUy6Y(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FF538m(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVOn61.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFofdg(cmd)
   if list and curVer == list[0]:
    return webVer
  FFRg6s(self, FFUIPk("No update required.", VVbnJx) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVCCDS(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVhuan + VVEMg1
  if fileExists(path):
   span = iSearch(r"(http.+)", FFUy6Y(path), IGNORECASE)
   if span : url = FFGYYB(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FF538m(SELF, err, title)
  return url
 @staticmethod
 def VVmfkh(url):
  path, err = FFOwIM(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFUy6Y(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVOn61.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFofdg(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCvT7T(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FF87m3(VVEV4h, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVKrK3
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFyw62(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVDuzD("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVDuzD("\c00888888", i) + sp + "GREY\n"
   txt += self.VVDuzD("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVDuzD("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVDuzD("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVDuzD("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVDuzD("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVDuzD("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVDuzD("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVDuzD("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVDuzD("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVDuzD("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVnr3G ,
   "green"   : self.VVnr3G ,
   "left"   : self.VVpaMT ,
   "right"   : self.VVbQZO ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  self.VVxRO7()
 def VVnr3G(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFcSjz(self, self.VVgWh1, "Change to : %s" % txt, title=self.Title)
 def VVgWh1(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVKrK3
  VVKrK3 = self.cursorPos
  self.VVNiXG()
  self.close()
 def VVpaMT(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVxRO7()
 def VVbQZO(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVxRO7()
 def VVxRO7(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVDuzD(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVD8kt(color):
  if VVApsx: return "\\" + color
  else    : return ""
 @staticmethod
 def VVNiXG():
  global VVZD1o, VVLIgE, VVP3bf, VVEiu9, VVju96, VVRZG6, VVbnJx, VVApsx, COLOR_CONS_BRIGHT_YELLOW, VVbHZ1, VV5Hmu, VVI8UI
  VVI8UI   = CCvT7T.VVDuzD("\c00FFFFFF", VVKrK3)
  VVLIgE    = CCvT7T.VVDuzD("\c00888888", VVKrK3)
  VVZD1o  = CCvT7T.VVDuzD("\c005A5A5A", VVKrK3)
  VVRZG6    = CCvT7T.VVDuzD("\c00FF0000", VVKrK3)
  VVP3bf   = CCvT7T.VVDuzD("\c00FF5000", VVKrK3)
  VVApsx   = CCvT7T.VVDuzD("\c00FFFF00", VVKrK3)
  COLOR_CONS_BRIGHT_YELLOW = CCvT7T.VVDuzD("\c00FFFFAA", VVKrK3)
  VVbnJx   = CCvT7T.VVDuzD("\c0000FF00", VVKrK3)
  VVju96    = CCvT7T.VVDuzD("\c000066FF", VVKrK3)
  VVbHZ1    = CCvT7T.VVDuzD("\c0000FFFF", VVKrK3)
  VV5Hmu   = CCvT7T.VVDuzD("\c00FA55E7", VVKrK3)
  VVEiu9    = CCvT7T.VVDuzD("\c00FF8F5F", VVKrK3)
CCvT7T.VVNiXG()
class CCbs97(Screen):
 def __init__(self, session, path, VVW9b2):
  self.skin, self.skinParam = FF87m3(VVrlPa, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVhCvp   = path
  self.VV2ksC   = ""
  self.VVghCW   = ""
  self.VVW9b2    = VVW9b2
  self.VVUuJt    = ""
  self.VVjIbn  = ""
  self.VVJ7w9    = False
  self.VVtIw6  = False
  self.postInstAcion   = 0
  self.VVb2CL  = "enigma2-plugin-extensions"
  self.VVokZj  = "enigma2-plugin-systemplugins"
  self.VVuxwK = "enigma2"
  self.VVPV1G  = 0
  self.VVoFL3  = 1
  self.VVaDk3  = 2
  if pathExists(self.Path + "DEBIAN") : self.VV60BT = "DEBIAN"
  else        : self.VV60BT = "CONTROL"
  self.controlPath = self.Path + self.VV60BT
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVW9b2:
   self.packageExt  = ".deb"
   self.VVZHzf  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVZHzf  = "#11001020"
  FFyw62(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FF3p62(self["keyRed"] , "Create")
  FF3p62(self["keyGreen"] , "Post Install")
  FF3p62(self["keyYellow"], "Installation Path")
  FF3p62(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVDqu1  ,
   "green"   : self.VV5liJ ,
   "yellow"  : self.VVxH0q  ,
   "blue"   : self.VVedlc  ,
   "cancel"  : self.VVG6AF
  }, -1)
  self.onShown.append(self.VViwS9)
 def VViwS9(self):
  self.onShown.remove(self.VViwS9)
  FFEpG1(self)
  if self.VVZHzf:
   FFrhNb(self["myBody"], self.VVZHzf)
   FFrhNb(self["myLabel"], self.VVZHzf)
  self.VVVnLF(True)
  self.VVRjGI(True)
 def VVRjGI(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVDPeq()
  if isFirstTime:
   if   package.startswith(self.VVb2CL) : self.VVhCvp = VVgvyL + self.VVUuJt + "/"
   elif package.startswith(self.VVokZj) : self.VVhCvp = VVkvs5 + self.VVUuJt + "/"
   else            : self.VVhCvp = self.Path
  if self.VVJ7w9 : myColor = VVEiu9
  else    : myColor = VVI8UI
  txt  = ""
  txt += "Source Path\t: %s\n" % FFUIPk(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFUIPk(self.VVhCvp, VVApsx)
  if self.VVghCW : txt += "Package File\t: %s\n" % FFUIPk(self.VVghCW, VVLIgE)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFUIPk("Check Control File fields : %s" % errTxt, VVP3bf)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFUIPk("Restart GUI", VVEiu9)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFUIPk("Reboot Device", VVEiu9)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFUIPk("Post Install", VVbnJx), act)
  if not errTxt and VVP3bf in controlInfo:
   txt += "Warning\t: %s\n" % FFUIPk("Errors in control file may affect the result package.", VVP3bf)
  txt += "\nControl File\t: %s\n" % FFUIPk(self.controlFile, VVLIgE)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VV5liJ(self):
  VVei97 = []
  VVei97.append(("No Action"    , "noAction"  ))
  VVei97.append(("Restart GUI"    , "VV3rwq"  ))
  VVei97.append(("Reboot Device"   , "rebootDev"  ))
  FFrC6O(self, self.VVRjL4, title="Package Installation Option (after completing installation)", VVei97=VVei97)
 def VVRjL4(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VV3rwq"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVVnLF(False)
   self.VVRjGI()
 def VVxH0q(self):
  rootPath = FFUIPk("/%s/" % self.VVUuJt, VVZD1o)
  VVei97 = []
  VVei97.append(("Current Path"        , "toCurrent"  ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Extension Path"       , "toExtensions" ))
  VVei97.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVei97.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFrC6O(self, self.VVbYfJ, title="Installation Path", VVei97=VVei97)
 def VVbYfJ(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVsvrf(FFV5FT(self.Path, True))
   elif item == "toExtensions"  : self.VVsvrf(VVgvyL)
   elif item == "toSystemPlugins" : self.VVsvrf(VVkvs5)
   elif item == "toRootPath"  : self.VVsvrf("/")
   elif item == "toRoot"   : self.VVsvrf("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVJNPg, boundFunction(CCyaF0, mode=CCyaF0.BROWSER_MODE_DIR_PICKER, VVGjUA=VVhuan))
 def VVJNPg(self, path):
  if len(path) > 0:
   self.VVsvrf(path)
 def VVsvrf(self, parent, withPackageName=True):
  if withPackageName : self.VVhCvp = parent + self.VVUuJt + "/"
  else    : self.VVhCvp = "/"
  mode = self.VVTCmw()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVq40T(mode), self.controlFile))
  self.VVRjGI()
 def VVedlc(self):
  if fileExists(self.controlFile):
   lines = FFDyYj(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FF5iHn(self, self.VVjtI3, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FF538m(self, "Version not found or incorrectly set !")
  else:
   FF4LjO(self, self.controlFile)
 def VVjtI3(self, VVxCeq):
  if VVxCeq:
   version, color = self.VVdrsk(VVxCeq, False)
   if color == VVbHZ1:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVxCeq, self.controlFile))
    self.VVRjGI()
   else:
    FF538m(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVG6AF(self):
  if self.newControlPath:
   if self.VVJ7w9:
    self.VVaEnE()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFUIPk(self.newControlPath, VVLIgE)
    txt += FFUIPk("Do you want to keep these files ?", VVApsx)
    FFcSjz(self, self.close, txt, callBack_No=self.VVaEnE, title="Create Package", VV5nHT=True)
  else:
   self.close()
 def VVaEnE(self):
  os.system(FFgzF5("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVq40T(self, mode):
  if   mode == self.VVoFL3 : prefix = self.VVb2CL
  elif mode == self.VVaDk3 : prefix = self.VVokZj
  else        : prefix = self.VVuxwK
  return prefix + "-" + self.VVjIbn
 def VVTCmw(self):
  if   self.VVhCvp.startswith(VVgvyL) : return self.VVoFL3
  elif self.VVhCvp.startswith(VVkvs5) : return self.VVaDk3
  else            : return self.VVPV1G
 def VVVnLF(self, isFirstTime):
  self.VVUuJt   = os.path.basename(os.path.normpath(self.Path))
  self.VVUuJt   = "_".join(self.VVUuJt.split())
  self.VVjIbn = self.VVUuJt.lower()
  self.VVJ7w9 = self.VVjIbn == VVTGQU.lower()
  if self.VVJ7w9 and self.VVjIbn.endswith("ajpan"):
   self.VVjIbn += "el"
  if self.VVJ7w9 : self.VV2ksC = VVhuan
  else    : self.VV2ksC = CFG.packageOutputPath.getValue()
  self.VV2ksC = FFGYYB(self.VV2ksC)
  if not pathExists(self.controlPath):
   os.system(FFgzF5("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVJ7w9 : t = PLUGIN_NAME
  else    : t = self.VVUuJt
  self.VVuQ0V(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VV5riz.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVJ7w9 : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVuQ0V(self.postrmFile, txt)
  if self.VVJ7w9:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVOn61)
   self.VVuQ0V(self.preinstFile, txt)
  else:
   self.VVuQ0V(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVUuJt)
  mode = self.VVTCmw()
  if isFirstTime and not mode == self.VVPV1G:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VV8ben
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVuQ0V(self.postinstFile, txt, VVNgBx=True)
  os.system(FFgzF5("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVJ7w9 : version, descripton, maintainer = VVOn61 , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVUuJt , self.VVUuJt
   txt = ""
   txt += "Package: %s\n"  % self.VVq40T(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVuQ0V(self, path, lines, VVNgBx=False):
  if not fileExists(path) or VVNgBx:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVDPeq(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFDyYj(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFUIPk(line, VVP3bf)
     elif not line.startswith(" ")    : line = FFUIPk(line, VVP3bf)
     else          : line = FFUIPk(line, VVbHZ1)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVbHZ1
   else   : color = VVP3bf
   descr = FFUIPk(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVP3bf
     elif line.startswith((" ", "\t")) : color = VVP3bf
     elif line.startswith("#")   : color = VVLIgE
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVdrsk(val, True)
      elif key == "Version"  : version, color = self.VVdrsk(val, False)
      elif key == "Maintainer" : maint  , color = val, VVbHZ1
      elif key == "Architecture" : arch  , color = val, VVbHZ1
      else:
       color = VVbHZ1
      if not key == "OE" and not key.istitle():
       color = VVP3bf
     else:
      color = VVEiu9
     txt += FFUIPk(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVghCW = self.VV2ksC + packageName
   self.VVtIw6 = True
   errTxt = ""
  else:
   self.VVghCW  = ""
   self.VVtIw6 = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVdrsk(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVbHZ1
  else          : return val, VVP3bf
 def VVDqu1(self):
  if not self.VVtIw6:
   FF538m(self, "Please fix Control File errors first.")
   return
  if self.VVW9b2: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFV5FT(self.VVhCvp, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVUuJt
  symlinkTo  = FFgkOw(self.Path)
  dataDir   = self.VVhCvp.rstrip("/")
  removePorjDir = FFgzF5("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFgzF5("rm -f '%s'" % self.VVghCW) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFJwh1()
  if self.VVW9b2:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFgyQn("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVJ7w9:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVhCvp == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VV60BT)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVghCW, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVghCW
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVghCW, FFPqb8(result  , VVbnJx))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVhCvp, FFPqb8(instPath, VVbHZ1))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFPqb8(failed, VVP3bf))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FF8mHD(self, cmd)
class CCyaF0(Screen):
 BROWSER_MODE_NORMAL   = 0
 BROWSER_MODE_DIR_PICKER  = 1
 MAX_BOOKMARKS = 20
 def __init__(self, session, VVGjUA="/", mode=BROWSER_MODE_NORMAL, VVqpSd="Select", VVQ020=30):
  self.skin, self.skinParam = FF87m3(VVseVH, 1400, 820, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFyw62(self)
  FF3p62(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVqpSd = VVqpSd
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  if   self.mode == self.BROWSER_MODE_NORMAL  : VVYcAX, self.VVGjUA = True , CFG.browserStartPath.getValue()
  elif self.mode == self.BROWSER_MODE_DIR_PICKER : VVYcAX, self.VVGjUA = False, VVGjUA
  else           : VVYcAX, self.VVGjUA = True , VVGjUA
  VVGjUA = FFGYYB(VVGjUA)
  self["myMenu"] = CCBdWe(  directory   = "/"
         , VVYcAX   = VVYcAX
         , VV7Pxz = True
         , VVbHTj   = self.skinParam["width"]
         , VVQ020   = self.skinParam["bodyFontSize"]
         , VVU7nN  = self.skinParam["bodyLineH"]
         , VVxwdn  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVnr3G      ,
   "cancel"   : self.cancel      ,
   "green"    : self.VVrP5T    ,
   "yellow"   : self.VVbOH7   ,
   "blue"    : self.VVMNm0   ,
   "menu"    : self.VVgRri    ,
   "info"    : self.VVkYmJ    ,
   "pageUp"   : self.VVQCGh     ,
   "chanUp"   : self.VVQCGh
  }, -1)
  FFSIMa(self, self["myMenu"])
  self.onShown.append(self.start)
  self["myMenu"].onSelectionChanged.append(self.VVOAsT)
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVOAsT)
  FFgNUr(self["myMenu"], bg="#06003333")
  FFEpG1(self)
  self.maxTitleWidth = self["keyMenu1"].getPosition()[0] - 40
  if self.mode == self.BROWSER_MODE_DIR_PICKER:
   FF3p62(self["keyGreen"], self.VVqpSd)
   color = "#22000022"
   FFrhNb(self["myBody"], color)
   FFrhNb(self["myMenu"], color)
   color = "#22220000"
   FFrhNb(self["myTitle"], color)
   FFrhNb(self["myBar"], color)
  self.VVOAsT()
  if self.VV8EC0(self.VVGjUA) > self.bigDirSize:
   FFyMZt(self, "Changing directory...")
   FF5Ov8(self.VViR51)
  else:
   self.VViR51()
 def VViR51(self):
  self["myMenu"].VVXD0l(self.VVGjUA)
 def VVd2aH(self):
  self["myMenu"].refresh()
  FFVJYE()
 def VV8EC0(self, folder):
  totalItems = 0
  if pathExists(folder):
   totalItems = len(os.listdir(folder))
  return totalItems
 def VVnr3G(self):
  if self["myMenu"].VVkUG5():
   path = self.VV036I(self.VVQlLP())
   if self.VV8EC0(path) > self.bigDirSize:
    FFyMZt(self, "Changing directory...")
    FF5Ov8(self.VVI8vh)
   else:
    self.VVI8vh()
  else:
   self.VVPJDN()
 def VVI8vh(self):
  self["myMenu"].descent()
  self["myMenu"].moveToIndex(0)
  self.VVOAsT()
 def VVQCGh(self):
  if self["myMenu"].VVFKD9():
   self["myMenu"].moveToIndex(0)
   self.VVI8vh()
 def cancel(self):
  if not FFJbeE(self):
   self.close("")
 def VVrP5T(self):
  if self.mode == self.BROWSER_MODE_DIR_PICKER:
   path = self.VV036I(self.VVQlLP())
   self.close(path)
 def VVkYmJ(self):
  FFpgNe(self, self.VVyD4L, title="Calculating size ...")
 def VVyD4L(self):
  path = self.VV036I(self.VVQlLP())
  param = self.VVhm4k(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = ""
   if typeChar == "d":
    result = FFLHG0("myDir='%s'; totDirs=$(find $myDir -type d | wc -l); totFiles=$(find $myDir ! -type d | wc -l); echo $totDirs','$totFiles" % path)
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents  = "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
    size = FFLHG0("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    size = int(size)
   if size >= 1024 : size = "%s  ( %s bytes )" % (self.VVVUCH(size), format(size, ',d'))
   else   : size = "%s" % self.VVVUCH(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFUIPk(pathTxt, VVEiu9) + "\n"
   if slBroken : fileTime = self.VVLrTd(path)
   else  : fileTime = self.VVG0mq(path)
   def VVZXK9(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVZXK9("Path"    , pathTxt)
   txt += VVZXK9("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVZXK9("Target"   , slTarget)
   txt += VVZXK9("Size"    , "%s" % size)
   txt += contents
   txt += "\n"
   txt += VVZXK9("Owner"    , owner)
   txt += VVZXK9("Group"    , group)
   txt += VVZXK9("Perm. (User)"  , permUser)
   txt += VVZXK9("Perm. (Group)"  , permGroup)
   txt += VVZXK9("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVZXK9("Perm. (Ext.)" , permExtra)
   txt += VVZXK9("iNode"    , iNode)
   txt += VVZXK9("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VV8ben, VV8ben)
    txt += hLinkedFiles
  else:
   FF538m(self, "Cannot access information !")
  if len(txt) > 0:
   FF6wpe(self, txt)
 def VVhm4k(self, path):
  path = path.strip()
  path = FFgkOw(path)
  result = FFLHG0("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VV87uH(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VV87uH(perm, 1, 4)
   permGroup = VV87uH(perm, 4, 7)
   permOther = VV87uH(perm, 7, 10)
   permExtra = VV87uH(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFiQod("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVG0mq(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFbrdA(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFbrdA(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFbrdA(os.path.getctime(path))
  return txt
 def VVLrTd(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFLHG0("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFLHG0("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFLHG0("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVVUCH(self, size):
  power = 1024.0
  n = 0
  power_labels = {0 : 'B', 1: 'kB', 2: 'MB', 3: 'GB', 4: 'TB'}
  while size > power:
   size /= power
   n += 1
  size = "%.1f" % size
  if size.endswith(".0"):
   size = size[:-2]
  return "%s %s" % (size, power_labels[n])
 def VV036I(self, currentSel):
  currentDir  = self["myMenu"].VVFKD9()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVkUG5():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVQlLP(self):
  return self["myMenu"].getSelection()[0]
 def VVOAsT(self):
  FFyMZt(self)
  path = self.VV036I(self.VVQlLP())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VVpuR3 = self.VVHh3K()
  if VVpuR3 and len(VVpuR3) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VVCLoh(path)
  if self.mode == self.BROWSER_MODE_NORMAL and len(path) > 0:
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
  else:
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
 def VVCLoh(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVwXFC(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVgRri(self):
  if self.mode == self.BROWSER_MODE_NORMAL:
   path  = self.VV036I(self.VVQlLP())
   isDir  = os.path.isdir(path)
   VVei97 = []
   VVei97.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVOHJy(path):
     sepShown = True
     VVei97.append(VVhJ3E)
     VVei97.append( (VVEiu9 + "Archiving / Packaging"      , "VVWj3q"  ))
    if self.VVEcWg(path):
     if not sepShown:
      VVei97.append(VVhJ3E)
     VVei97.append( (VVEiu9 + "Read Backup information"     , "VVC1KR"  ))
     VVei97.append( (VVEiu9 + "Compress Octagon Image (to zip File)"  , "VVUmvz" ))
   elif os.path.isfile(path):
    selFile = self.VVQlLP()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip"))   : VVei97.extend(self.VVCkmD(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVei97.extend(self.VV9OUX(True))
    elif selFile.endswith(".m3u")              : VVei97.extend(self.VVCuBI(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FF3zwk(path):
     VVei97.append(VVhJ3E)
     VVei97.append((VVEiu9 + "View" , "text_View" ))
     VVei97.append((VVEiu9 + "Edit" , "text_Edit" ))
    if len(txt) > 0:
     VVei97.append(VVhJ3E)
     VVei97.append(   (VVEiu9 + txt      , "VVPJDN"  ))
   VVei97.append(VVhJ3E)
   VVei97.append(     ("Create SymLink"       , "VVlc21" ))
   if not self.VVOHJy(path):
    VVei97.append(   ("Rename"          , "VV5oY5" ))
    VVei97.append(   ("Copy"           , "copyFileOrDir" ))
    VVei97.append(   ("Move"           , "moveFileOrDir" ))
    VVei97.append(   ("DELETE"          , "VVg2IV" ))
    if fileExists(path):
     VVei97.append(VVhJ3E)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVei97.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVei97.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVei97.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVei97.append(VVhJ3E)
   VVei97.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVei97.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   VVei97.append(VVhJ3E)
   VVei97.append(    ("Set current directory as \"Startup Path\"" , "VVht6u" ))
   FFrC6O(self, self.VVgDT0, title="Options", VVei97=VVei97)
 def VVgDT0(self, item=None):
  if self.mode == self.BROWSER_MODE_NORMAL:
   if item is not None:
    path = self.VV036I(self.VVQlLP())
    selFile = self.VVQlLP()
    if   item == "properties"    : self.VVkYmJ()
    elif item == "VVWj3q"  : self.VVWj3q(path)
    elif item == "VVC1KR"  : self.VVC1KR(path)
    elif item == "VVUmvz" : self.VVUmvz(path)
    elif item.startswith("extract_")  : self.VVM233(path, selFile, item)
    elif item.startswith("script_")   : self.VVDQpQ(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVhzQPItem_m3u(path, selFile, item)
    elif item.startswith("text_View")  : FFkCVq(self, path)
    elif item.startswith("text_Edit")  : CCi8JT(self, path)
    elif item == "chmod644"     : self.VV1EaI(path, selFile, "644")
    elif item == "chmod755"     : self.VV1EaI(path, selFile, "755")
    elif item == "chmod777"     : self.VV1EaI(path, selFile, "777")
    elif item == "VVlc21"   : self.VVlc21(path, selFile)
    elif item == "VV5oY5"   : self.VV5oY5(path, selFile)
    elif item == "copyFileOrDir"   : self.VVn50D(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVn50D(path, selFile, True)
    elif item == "VVg2IV"   : self.VVg2IV(path, selFile)
    elif item == "createNewFile"   : self.VVLbLw(path, True)
    elif item == "createNewDir"    : self.VVLbLw(path, False)
    elif item == "VVht6u"   : self.VVht6u(path)
    elif item == "VVPJDN"    : self.VVPJDN()
    else         : self.close()
 def VVPJDN(self):
  selFile = self.VVQlLP()
  path  = self.VV036I(selFile)
  if os.path.isfile(path):
   VVlqxJ = []
   category = self["myMenu"].VVYBO4(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVU0LH(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FFEGhq(self, selFile, path)
   elif category == "txt"         : FFkCVq(self, path)
   elif category in ("tar", "zip")       : self.VViXQy(path, selFile)
   elif category == "scr"         : self.VVFVxy(path, selFile)
   elif category == "m3u"         : self.VVeRS0(path, selFile)
   elif category in ("ipk", "deb")       : self.VV71h6(path, selFile)
   elif category == "mus"         : self.VVnd85(path)
   elif category == "mov"         : self.VVnd85(path)
   elif not FF3zwk(path)        : FFkCVq(self, path)
 def VVnd85(self, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   FFY1uw(self, refCode)
  except:
   pass
 def VVbOH7(self):
  path = self.VV036I(self.VVQlLP())
  action = self.VVCLoh(path)
  if action == 1:
   self.VVXAON(path)
   FFyMZt(self, "Added", 500)
  elif action == -1:
   self.VVFu4G(path)
   FFyMZt(self, "Removed", 500)
  self.VVCLoh(path)
 def VVXAON(self, path):
  VVpuR3 = self.VVHh3K()
  if not VVpuR3:
   VVpuR3 = []
  if len(VVpuR3) >= self.MAX_BOOKMARKS:
   FF538m(SELF, "Max bookmarks reached (max=%d)." % self.MAX_BOOKMARKS)
  elif not path in VVpuR3:
   VVpuR3 = [path] + VVpuR3
   self.VVSFZk(VVpuR3)
 def VVMNm0(self):
  VVpuR3 = self.VVHh3K()
  if VVpuR3:
   newList = []
   for line in VVpuR3:
    newList.append((line, line))
   VVmf6o  = ("Delete"  , self.VVh3OJ )
   VVdFS8 = ("Move Up"   , self.VVAdn0 )
   VVQixJ  = ("Move Down" , self.VVxcgB )
   self.bookmarkMenu = FFrC6O(self, self.VVi5jm, title="Bookmarks", VVei97=newList, VVmf6o=VVmf6o, VVdFS8=VVdFS8, VVQixJ=VVQixJ)
 def VVh3OJ(self, VVQlLPObj, path):
  if self.bookmarkMenu:
   VVpuR3 = self.VVFu4G(path)
   self.bookmarkMenu.VVzrHw(VVpuR3)
 def VVAdn0(self, VVQlLPObj, path):
  if self.bookmarkMenu:
   VVpuR3 = self.bookmarkMenu.VViCHK(True)
   if VVpuR3:
    self.VVSFZk(VVpuR3)
 def VVxcgB(self, VVQlLPObj, path):
  if self.bookmarkMenu:
   VVpuR3 = self.bookmarkMenu.VViCHK(False)
   if VVpuR3:
    self.VVSFZk(VVpuR3)
 def VVi5jm(self, folder=None):
  if folder:
   if not folder.endswith("/"):
    folder += "/"
   self["myMenu"].VVXD0l(folder)
   self["myMenu"].moveToIndex(0)
  self.VVOAsT()
 def VVHh3K(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVwXFC(self, path):
  VVpuR3 = self.VVHh3K()
  if VVpuR3 and path in VVpuR3:
   return True
  else:
   return False
 def VVK85C(self):
  if VVHh3K():
   return True
  else:
   return False
 def VVSFZk(self, VVpuR3):
  line = ",".join(VVpuR3)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVFu4G(self, path):
  VVpuR3 = self.VVHh3K()
  if VVpuR3:
   while path in VVpuR3:
    VVpuR3.remove(path)
   self.VVSFZk(VVpuR3)
   return VVpuR3
 def VVht6u(self, path):
  if not os.path.isdir(path):
   path = FFV5FT(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVU0LH(self, selFile, VVRS1f, command):
  FFcSjz(self, boundFunction(FF8mHD, self, command, VVQEZn=self.VVd2aH), "%s\n\n%s" % (VVRS1f, selFile))
 def VVCkmD(self, path, calledFromMenu):
  destPath = self.VVaqNa(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVei97 = []
  if calledFromMenu:
   VVei97.append(VVhJ3E)
   color = VVEiu9
  else:
   color = ""
  VVei97.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVei97.append(VVhJ3E)
  VVei97.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVei97.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVei97.append((color + "Extract Here"            , "extract_here"  ))
  if VVyEf8 and path.endswith(".tar.gz"):
   VVei97.append(VVhJ3E)
   VVei97.append((color + 'Convert to ".ipk" Package' , "VVA8D4"  ))
   VVei97.append((color + 'Convert to ".deb" Package' , "VVIZkm"  ))
  return VVei97
 def VViXQy(self, path, selFile):
  FFrC6O(self, boundFunction(self.VVM233, path, selFile), title="Tar File Options", VVei97=self.VVCkmD(path, False))
 def VVM233(self, path, selFile, item=None):
  if item is not None:
   parent  = FFV5FT(path, False)
   destPath = self.VVaqNa(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VV8ben
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += "echo '';"
     cmd += "unzip -l '%s';" % path
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VV8ben, VV8ben)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFX0Ip(self, cmd)
   elif path.endswith(".zip"):
    self.VVdA9A(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFgzF5("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVU0LH(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVU0LH(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFV5FT(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVU0LH(selFile, "Extract Here ?"      , cmd)
   elif item == "VVA8D4" : self.VVA8D4(path)
   elif item == "VVIZkm" : self.VVIZkm(path)
 def VVaqNa(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVdA9A(self, item, path, parent, destPath, VVRS1f):
  FFcSjz(self, boundFunction(self.VVb3Ra, item, path, parent, destPath), VVRS1f)
 def VVb3Ra(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VV8ben
  cmd  = FFgyQn("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFPqb8(destPath, VVbnJx))
  cmd +=   sep
  cmd += "fi;"
  FFLPvq(self, cmd, VVQEZn=self.VVd2aH)
 def VV9OUX(self, addSep=False):
  VVei97 = []
  if addSep:
   VVei97.append(VVhJ3E)
  VVei97.append((VVEiu9 + "View Script File"  , "script_View"  ))
  VVei97.append((VVEiu9 + "Execute Script File" , "script_Execute" ))
  VVei97.append((VVEiu9 + "Edit"     , "script_Edit" ))
  return VVei97
 def VVFVxy(self, path, selFile):
  FFrC6O(self, boundFunction(self.VVDQpQ, path, selFile), title="Script File Options", VVei97=self.VV9OUX())
 def VVDQpQ(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFkCVq(self, path)
   elif item == "script_Execute" : self.VVU0LH(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCi8JT(self, path)
 def VVCuBI(self, addSep=False):
  VVei97 = []
  if addSep:
   VVei97.append(VVhJ3E)
  VVei97.append((VVEiu9 + "View"      , "m3u_View" ))
  VVei97.append((VVEiu9 + "Edit"      , "m3u_Edit" ))
  VVei97.append((VVEiu9 + "Convert to IPTV Bouquet" , "m3u_Convert" ))
  return VVei97
 def VVeRS0(self, path, selFile):
  FFrC6O(self, boundFunction(self.VVhzQPItem_m3u, path, selFile), title="M3U File Options", VVei97=self.VVCuBI())
 def VVhzQPItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_View"  : FFkCVq(self, path)
   elif item == "m3u_Edit"  : CCi8JT(self, path)
   elif item == "m3u_Convert" : CCQps6.VVUYlo(self, path, False)
 def VV1EaI(self, path, selFile, newChmod):
  FFcSjz(self, boundFunction(self.VVqTCX, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVqTCX(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVmw9Y)
  result = FFLHG0(cmd)
  if result == "Successful" : FFRg6s(self, result)
  else      : FF538m(self, result)
 def VVlc21(self, path, selFile):
  parent = FFV5FT(path, False)
  self.session.openWithCallback(self.VV9DfH, boundFunction(CCyaF0, mode=CCyaF0.BROWSER_MODE_DIR_PICKER, VVGjUA=parent, VVqpSd="Create Symlink here"))
 def VV9DfH(self, newPath):
  if len(newPath) > 0:
   target = self.VV036I(self.VVQlLP())
   target = FFgkOw(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFGYYB(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FF538m(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFcSjz(self, boundFunction(self.VVFc94, target, link), "Create Soft Link ?\n\n%s" % txt, VV5nHT=True)
 def VVFc94(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVmw9Y)
  result = FFLHG0(cmd)
  if result == "Successful" : FFRg6s(self, result)
  else      : FF538m(self, result)
 def VV5oY5(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FF5iHn(self, boundFunction(self.VVnITS, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVnITS(self, path, selFile, VVxCeq):
  if VVxCeq:
   parent = FFV5FT(path, True)
   if os.path.isdir(path):
    path = FFgkOw(path)
   newName = parent + VVxCeq
   cmd = "mv '%s' '%s' %s" % (path, newName, VVmw9Y)
   if VVxCeq:
    if selFile != VVxCeq:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFcSjz(self, boundFunction(self.VVLGL6, cmd), message, title="Rename file?")
    else:
     FF538m(self, "Cannot use same name!", title="Rename")
 def VVLGL6(self, cmd):
  result = FFLHG0(cmd)
  if "Fail" in result:
   FF538m(self, result)
  self.VVd2aH()
 def VVn50D(self, path, selFile, isMove):
  if isMove : VVqpSd = "Move to here"
  else  : VVqpSd = "Copy to here"
  parent = FFV5FT(path, False)
  self.session.openWithCallback(boundFunction(self.VVh3vG, isMove, path, selFile)
         , boundFunction(CCyaF0, mode=CCyaF0.BROWSER_MODE_DIR_PICKER, VVGjUA=parent, VVqpSd=VVqpSd))
 def VVh3vG(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFgkOw(path)
   newPath = FFGYYB(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFcSjz(self, boundFunction(FF5DF6, self, cmd, VVQEZn=self.VVd2aH), txt, VV5nHT=True)
   else:
    FF538m(self, "Cannot %s to same directory !" % action.lower())
 def VVg2IV(self, path, fileName):
  path = FFgkOw(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFcSjz(self, boundFunction(self.VVY4Wj, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVY4Wj(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("rm %s '%s'" % (opt, path))
  self.VVd2aH()
 def VVOHJy(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVU5KH and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVLbLw(self, path, isFile):
  dirName = FFGYYB(os.path.dirname(path))
  if isFile : objName, VVxCeq = "File"  , self.edited_newFile
  else  : objName, VVxCeq = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FF5iHn(self, boundFunction(self.VVRxfL, dirName, isFile, title), title=title, defaultText=VVxCeq, message="Enter %s Name:" % objName)
 def VVRxfL(self, dirName, isFile, title, VVxCeq):
  if VVxCeq:
   if isFile : self.edited_newFile = VVxCeq
   else  : self.edited_newDir  = VVxCeq
   path = dirName + VVxCeq
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVmw9Y)
    else  : cmd = "mkdir '%s' %s" % (path, VVmw9Y)
    result = FFLHG0(cmd)
    if "Fail" in result:
     FF538m(self, result)
    self.VVd2aH()
   else:
    FF538m(self, "Name already exists !\n\n%s" % path, title)
 def VV71h6(self, path, selFile):
  VVei97 = []
  VVei97.append(("List Package Files"          , "VVNpop"     ))
  VVei97.append(("Package Information"          , "VVCtG8"     ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Install Package"           , "VVP8yy_CheckVersion" ))
  VVei97.append(("Install Package (force reinstall)"      , "VVP8yy_ForceReinstall" ))
  VVei97.append(("Install Package (force downgrade)"      , "VVP8yy_ForceDowngrade" ))
  VVei97.append(("Install Package (ignore failed dependencies)"    , "VVP8yy_IgnoreDepends" ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Remove Related Package"         , "VVQ6wH_ExistingPackage" ))
  VVei97.append(("Remove Related Package (force remove)"     , "VVQ6wH_ForceRemove"  ))
  VVei97.append(("Remove Related Package (ignore failed dependencies)"  , "VVQ6wH_IgnoreDepends" ))
  VVei97.append(VVhJ3E)
  VVei97.append(("Extract Files"           , "VV6oGG"     ))
  VVei97.append(("Unbuild Package"           , "VVhY24"     ))
  FFrC6O(self, boundFunction(self.VVewJ0, path, selFile), VVei97=VVei97)
 def VVewJ0(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVNpop"      : self.VVNpop(path, selFile)
   elif item == "VVCtG8"      : self.VVCtG8(path)
   elif item == "VVP8yy_CheckVersion"  : self.VVP8yy(path, selFile, VVn00Q     )
   elif item == "VVP8yy_ForceReinstall" : self.VVP8yy(path, selFile, VVmVK0 )
   elif item == "VVP8yy_ForceDowngrade" : self.VVP8yy(path, selFile, VVxYAi )
   elif item == "VVP8yy_IgnoreDepends" : self.VVP8yy(path, selFile, VVPG5X )
   elif item == "VVQ6wH_ExistingPackage" : self.VVQ6wH(path, selFile, VVaP3C     )
   elif item == "VVQ6wH_ForceRemove"  : self.VVQ6wH(path, selFile, VVc0hz  )
   elif item == "VVQ6wH_IgnoreDepends"  : self.VVQ6wH(path, selFile, VVimgP )
   elif item == "VV6oGG"     : self.VV6oGG(path, selFile)
   elif item == "VVhY24"     : self.VVhY24(path, selFile)
   else           : self.close()
 def VVNpop(self, path, selFile):
  if FFLUR1("ar") : cmd = "allOK='1';"
  else    : cmd  = FFJwh1()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VV8ben, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VV8ben, VV8ben)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFtFVx(self, cmd, VVQEZn=self.VVd2aH)
 def VV6oGG(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFV5FT(path, True) + selFile[:-4]
  cmd  =  FFJwh1()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFgzF5("mkdir '%s'" % dest) + ";"
  cmd +=    FFgzF5("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFPqb8(dest, VVbnJx))
  cmd += "fi;"
  FF8mHD(self, cmd, VVQEZn=self.VVd2aH)
 def VVhY24(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVOUw8 = os.path.splitext(path)[0]
  else        : VVOUw8 = path + "_"
  if path.endswith(".deb")   : VV60BT = "DEBIAN"
  else        : VV60BT = "CONTROL"
  cmd  = FFJwh1()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVOUw8, FF8JsR())
  cmd += "  mkdir '%s';"    % VVOUw8
  cmd += "  CONTPATH='%s/%s';"  % (VVOUw8, VV60BT)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVOUw8
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVOUw8, VVOUw8)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVOUw8
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVOUw8, VVOUw8)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVOUw8
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVOUw8
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVOUw8, FFPqb8(VVOUw8, VVbnJx))
  cmd += "fi;"
  FF8mHD(self, cmd, VVQEZn=self.VVd2aH)
 def VVCtG8(self, path):
  listCmd  = FF9LLs(VVLtMu, "")
  infoCmd  = FFVVjD(VVHwH1 , "")
  filesCmd = FFVVjD(VVpkv3, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFZAZA(VVApsx)
   notInst = "Package not installed."
   cmd  = FFA58W("File Info", VVApsx)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFA58W("System Info", VVApsx)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFPqb8(notInst, VVEiu9))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFA58W("Related Files", VVApsx)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFX0Ip(self, cmd)
  else:
   FF9VHl(self)
 def VVP8yy(self, path, selFile, cmdOpt):
  cmd = FFVVjD(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFcSjz(self, boundFunction(FF8mHD, self, cmd, VVQEZn=FFVJYE), "Install Package ?\n\n%s" % selFile)
  else:
   FF9VHl(self)
 def VVQ6wH(self, path, selFile, cmdOpt):
  listCmd  = FF9LLs(VVLtMu, "")
  infoCmd  = FFVVjD(VVHwH1, "")
  instRemCmd = FFVVjD(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFPqb8(errTxt, VVEiu9))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFPqb8(cannotTxt, VVEiu9))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFPqb8(tryTxt, VVEiu9))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFcSjz(self, boundFunction(FF8mHD, self, cmd, VVQEZn=FFVJYE), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FF9VHl(self)
 def VVX9Ag(self, path):
  hostName = FFLHG0("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVEcWg(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVX9Ag(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVWj3q(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVei97 = []
  VVei97.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVei97.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVei97.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVei97.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVei97.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVei97.append(VVhJ3E)
  VVei97.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVei97.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVei97.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVei97.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVei97.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVei97.append(VVhJ3E)
  VVei97.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVei97.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFrC6O(self, boundFunction(self.VVo0Kf, path), VVei97=VVei97)
 def VVo0Kf(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVyg5O(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVyg5O(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVyg5O(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVyg5O(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVyg5O(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVyg5O(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVyg5O(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVyg5O(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVyg5O(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVyg5O(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVs1Zo(path, False)
   elif item == "convertDirToDeb"   : self.VVs1Zo(path, True)
   else         : self.close()
 def VVs1Zo(self, path, VVW9b2):
  self.session.openWithCallback(self.VVd2aH, boundFunction(CCbs97, path=path, VVW9b2=VVW9b2))
 def VVyg5O(self, path, fileExt, preserveDirStruct):
  parent  = FFV5FT(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFgyQn("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFgyQn("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFgyQn("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VV8ben
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFgzF5("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FFPqb8(resultFile, VVbnJx))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FFPqb8(failed, VVP3bf))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFtFVx(self, cmd, VVQEZn=self.VVd2aH)
 def VVC1KR(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFkCVq(self, versionFile)
 def VVUmvz(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVX9Ag(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FF538m(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFDyYj(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFV5FT(path, False)
  VVOUw8 = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FFPqb8(errCmd, VVP3bf))
  installCmd = FFVVjD(VVn00Q , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVOUw8, VVOUw8)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVOUw8
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVOUw8
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVOUw8, VVOUw8)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FF8mHD(self, cmd, VVQEZn=self.VVd2aH)
 def VVA8D4(self, path):
  FF538m(self, "Under Construction.")
 def VVIZkm(self, path):
  FF538m(self, "Under Construction.")
class CCBdWe(MenuList):
 def __init__(self, VV7Pxz=False, directory="/", VVLnvq=True, VVYcAX=True, VV96ar=True, VVL5il=None, VV5UrT=False, VVvjS0=False, VVSPbu=False, isTop=False, VVmdhC=None, VVbHTj=1000, VVQ020=30, VVU7nN=30, VVxwdn="#00000000"):
  MenuList.__init__(self, list, VV7Pxz, eListboxPythonMultiContent)
  self.VVLnvq  = VVLnvq
  self.VVYcAX    = VVYcAX
  self.VV96ar  = VV96ar
  self.VVL5il  = VVL5il
  self.VV5UrT   = VV5UrT
  self.VVvjS0   = VVvjS0 or []
  self.VVSPbu   = VVSPbu or []
  self.isTop     = isTop
  self.additional_extensions = VVmdhC
  self.VVbHTj    = VVbHTj
  self.VVQ020    = VVQ020
  self.VVU7nN    = VVU7nN
  self.pngBGColor    = FFB7IS(VVxwdn)
  self.EXTENSIONS    = self.VVtR9r()
  self.VV7Rux   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVUC67, self.VVQ020))
  self.l.setItemHeight(self.VVU7nN)
  self.png_mem   = self.VVS4aY("mem")
  self.png_usb   = self.VVS4aY("usb")
  self.png_fil   = self.VVS4aY("fil")
  self.png_dir   = self.VVS4aY("dir")
  self.png_dirup   = self.VVS4aY("dirup")
  self.png_srv   = self.VVS4aY("srv")
  self.png_slwfil   = self.VVS4aY("slwfil")
  self.png_slbfil   = self.VVS4aY("slbfil")
  self.png_slwdir   = self.VVS4aY("slwdir")
  self.VVREOu()
  self.VVXD0l(directory)
 def VVS4aY(self, category):
  return LoadPixmap("%s%s.png" % (VV1ggQ, category), getDesktop(0))
 def VVtR9r(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u"
  }
 def VVFEjw(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFgkOw(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFUIPk(" -> " , VVApsx) + FFUIPk(os.readlink(path), VVbnJx)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVU7nN + 10, 0, self.VVbHTj, self.VVU7nN, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVulDh: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVU7nN-4, self.VVU7nN-4, png, self.pngBGColor, self.pngBGColor, VVulDh))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVU7nN-4, self.VVU7nN-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVYBO4(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVREOu(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVmQvs(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VV0gb9(self, file):
  if os.path.realpath(file) == file:
   return self.VVmQvs(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVmQvs(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVmQvs(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVuNOm(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VV7Rux.info(l[0][0]).getEvent(l[0][0])
 def VVGIzN(self):
  return self.list
 def VVivWB(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVXD0l(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VV96ar:
    self.current_mountpoint = self.VV0gb9(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VV96ar:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVSPbu and not self.VVivWB(path, self.VVvjS0):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVFEjw(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VV5UrT:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VV7Rux = eServiceCenter.getInstance()
   list = VV7Rux.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVLnvq and not self.isTop:
   if directory == self.current_mountpoint and self.VV96ar:
    self.list.append(self.VVFEjw(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVSPbu and self.VVmQvs(directory) in self.VVSPbu):
    self.list.append(self.VVFEjw(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVLnvq:
   for x in directories:
    if not (self.VVSPbu and self.VVmQvs(x) in self.VVSPbu) and not self.VVivWB(x, self.VVvjS0):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVFEjw(name = name, absolute = x, isDir = True, png = png))
  if self.VVYcAX:
   for x in files:
    if self.VV5UrT:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFUIPk(" -> " , VVApsx) + FFUIPk(target, VVbnJx)
       else:
        png = self.png_slbfil
        name += FFUIPk(" -> " , VVApsx) + FFUIPk(target, VVP3bf)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVYBO4(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VV1ggQ, category))
    if (self.VVL5il is None) or iCompile(self.VVL5il).search(path):
     self.list.append(self.VVFEjw(name = name, absolute = x , isDir = False, png = png))
  if self.VV96ar and len(self.list) == 0:
   self.list.append(self.VVFEjw(name = FFUIPk("No USB connected", VVLIgE), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVFKD9(self):
  return self.current_directory
 def VVkUG5(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVXD0l(self.getSelection()[0], select = self.current_directory)
 def VVecnN(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVed3Q(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VV8qWI)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VV8qWI)
 def refresh(self):
  self.VVXD0l(self.current_directory, self.VVecnN())
 def VV8qWI(self, action, device):
  self.VVREOu()
  if self.current_directory is None:
   self.refresh()
class CC0QxB(ScrollLabel):
 def __init__(self, parentSELF, text="", VVr5i1=True):
  ScrollLabel.__init__(self, text)
  self.VVr5i1=VVr5i1
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVUlB6  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVQ020    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close   ,
   "cancel"  : parentSELF.close   ,
   "red"   : self.VVKroH   ,
   "green"   : self.VVJCXW  ,
   "yellow"  : self.VV6GKb  ,
   "blue"   : self.VVa7yw  ,
   "up"   : self.pageUp    ,
   "down"   : self.pageDown    ,
   "left"   : self.pageUp    ,
   "right"   : self.pageDown    ,
   "pageUp"  : self.VVVTdN    ,
   "chanUp"  : self.VVVTdN    ,
   "pageDown"  : self.VVhv3M    ,
   "chanDown"  : self.VVhv3M
  }, -1)
 def VVEY9M(self, isResizable=True, VVx7ne=False, enableSave=False):
  if enableSave:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFEpG1(self.parentSELF, True)
  self.isResizable = isResizable
  if VVx7ne:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVQ020  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFrhNb(self, color)
 def FFrhNbColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVUlB6 - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VV6aI2()
 def pageUp(self):
  if self.VVUlB6 > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVUlB6 > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVVTdN(self):
  self.setPos(0)
 def VVhv3M(self):
  self.setPos(self.VVUlB6-self.pageHeight)
 def VVOO52(self):
  return self.VVUlB6 <= self.pageHeight or self.curPos == self.VVUlB6 - self.pageHeight
 def VV6aI2(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVUlB6, 3))
   start = int((100 - vis) * self.curPos / (self.VVUlB6 - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVfs8s=VVXhsS):
  old_VVOO52 = self.VVOO52()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VVUlB6 = self.long_text.calculateSize().height()
   if self.VVr5i1 and self.VVUlB6 > self.pageHeight:
    self.scrollbar.show()
    self.VV6aI2()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVUlB6))
   if   VVfs8s == VVAqA7: self.setPos(0)
   elif VVfs8s == VVwXIf : self.VVhv3M()
   elif old_VVOO52    : self.VVhv3M()
 def appendText(self, text, VVfs8s=VVwXIf):
  self.setText(self.message + str(text), VVfs8s)
 def VV6GKb(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVfz8Z(size)
 def VVa7yw(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVfz8Z(size)
 def VVJCXW(self):
  self.VVfz8Z(self.VVQ020)
 def VVfz8Z(self, VVQ020):
  self.long_text.setFont(gFont(self.fontFamily, VVQ020))
  self.setText(self.message, VVfs8s=VVXhsS)
  self.VVQdyj(calledFromFontSizer=True)
 def VVKroH(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "Save to File"
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_Info_%s.txt" % (FFGYYB(expPath), FFAH5e())
    with open(outF, "w") as f:
     f.write(FFfEyW(self.message))
    FFRg6s(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FF538m(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVQdyj(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVUlB6 > 0 and self.pageHeight > 0:
   if self.VVUlB6 < self.pageHeight * 0.8:
    self.setText("\n" + self.message.strip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVUlB6
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
