import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile
except: iMove = iCopyfile = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVHz5F   = "v7.4.0"
VVEpF4    = "21-10-2022"
EASY_MODE    = 0
VVLDgg   = 0
VVktXS   = 0
VVEK1s  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVTdNX  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVL4Xa    = "/media/usb/"
VVKSkH    = "/usr/share/enigma2/picon/"
VVVISw = "/etc/enigma2/blacklist"
VVoDv6   = "/etc/enigma2/"
VVsUI5  = "ajpanel_update_url"
VVWcf6   = "AJPan"
VVqwOi  = "AUTO FIND"
VV0WeH  = "Custom"
VVgXBs    = ""
VVhadi = "Regular"
VVdS9F = "Fixed"
VV10vq  = "AJP_Main"
VVLWmv = "AJP_Terminal"
VV0P9U = "AJP_System"
VVdbIk  = VVhadi
VVU8ll      = "-" * 80
VV4c5n    = ("-" * 100, )
VVnWCp    = ""
VVU0Ra   = " && echo 'Successful' || echo 'Failed!'"
VVL2pj    = []
VVTzA8  = "Cannot continue (No Enough Memory) !"
VVtMJJ  = False
VV5uVo  = False
VVSJRi = False
VVLAKc     = 0
VVqRLf    = 1
VVp52N    = 2
VVvNKl   = 3
VVXQ7N    = 4
VVfuBG    = 5
VVpCD5 = 6
VVQhFe = 7
VVZpaa  = 8
VVVTym   = 9
VVLVhk  = 10
VVQ9al  = 11
VVFdj2 = 12
VV5zNN    = 13
VVOVX1   = 14
VVQp8r   = 15
VViXrc    = 16
VVXKIb    = 17
VVNXcd  = 18
VVR3Vk    = 19
VVBuVN   = 0
VVmDB2   = 1
VV08OK   = 2
def FFiwO0():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVdbIk
  if VV10vq in lst and CFG.fontPathMain.getValue(): VVdbIk = VV10vq
  else               : VVdbIk = VVhadi
  return lst
 else:
  return [VVhadi]
def FFV9L6(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[ ("v", "Virtual Keyboard"), ("s", "System Default") ])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[ ("d", "Directory Up"), ("e", "Exit File Manage") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[ ("jpg", "JPG"), ("png", "PNG"), ("bmp", "BMP"), ("off", "Off") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices=[ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVqwOi, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.PIconsPath     = ConfigDirectory(default=VVKSkH, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVL4Xa, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
tmp = [("srt", "FROM SRT FILE"), ("#00FFFF", "Aqua"), ("#000000", "Black"), ("#0000FF", "Blue"), ("#FF00FF", "Fuchsia"), ("#808080", "Gray"), ("#008000", "Green"), ("#00FF00", "Lime"), ("#800000", "Maroon"), ("#000080", "Navy"), ("#808000", "Olive"), ("#800080", "Purple"), ("#FF0000", "Red"), ("#C0C0C0", "Silver"), ("#008080", "Teal"), ("#FFFFFF", "White"), ("#FFFF00", "Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVdbIk, choices=[(x,  x) for x in FFiwO0()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[ ("0", "Left"), ("1", "Center"), ("2", "Right") ])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FFJi6b():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVDsh8  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VV5ENK = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVDsh8  : return 0
  elif VV5ENK : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
COLOR_SCHEME_NUM = FFJi6b()
VV4U5y = VVyLoh = VVwmjQ = VVPUgM = VVFBP5 = VV61Yf = VVx4sJ = VVCfWA = VVqQXm = VV6svy = VVy0iZ = VVtSeQ = VVE6YJ = VVxpap = VVOBCT = VVCLGj = ""
def FFx3J7()  : FFstBf(FFU7Vm())
def FFREwq()  : FFstBf(FF8pMC())
def FFm9Z7(tDict): FFstBf(iDumps(tDict, indent=4, sort_keys=True))
def FFSAOH(*args): FF74iE(True, True, *args)
def FFstBf(*args) : FF74iE(True , False , *args)
def FFb3M6(*args): FF74iE(False, False, *args)
def FF74iE(addSep=True, isArray=True, *args):
 if VVLDgg:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(key.ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFSMFv(*args):
 if VVLDgg:
  path = "/tmp/ajpanel_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FFb3M6("Added to : %s" % path)
def FFvJeP(txt, isAppend=True, ignoreErr=False):
 if VVLDgg:
  tm = FFR4Gb()
  err = ""
  if not ignoreErr:
   err = FF8pMC()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFstBf(err)
  FFstBf("Output Log File : %s" % fileName)
def FF8pMC():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFR4Gb()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFU7Vm():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVG7Gx = 0
def FFunJ6():
 global VVG7Gx
 VVG7Gx = iTime()
def FFurNM(txt=""):
 FFstBf(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VVG7Gx)).rstrip("0"), txt))
VVL2pj = []
def FFI3MP(win):
 global VVL2pj
 if not win in VVL2pj:
  VVL2pj.append(win)
def FFoI8M(*args):
 global VVL2pj
 for win in VVL2pj:
  try:
   win.close()
  except:
   pass
 VVL2pj = []
def FFqXrd():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VV0xHX = FFqXrd()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFpKCR()    : return PluginDescriptor(fnc=FFX7T2, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FF6H3S()      : return getDescriptor(FFE5c3 , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFkNlp()     : return getDescriptor(FFJ2uZ  , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFqtua()  : return getDescriptor(FFUCPY, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFSJwh() : return getDescriptor(FFCweb , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FFjK1p()  : return getDescriptor(FFwkCL , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFghAt()  : return getDescriptor(FFlRSv  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFPeyA()    : return getDescriptor(FFiuYv, [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFkNlp() , FF6H3S() , FFpKCR() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFqtua())
  result.append(FFSJwh())
  result.append(FFjK1p())
  result.append(FFghAt())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFPeyA())
 return result
def FFX7T2(reason, **kwargs):
 if reason == 0:
  FF7lRV()
  if "session" in kwargs:
   session = kwargs["session"]
   FFBaHA(session)
   CCgXBA(session)
def FFE5c3(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFJ2uZ, PLUGIN_NAME, 45)]
 else:
  return []
def FFJ2uZ(session, **kwargs):
 session.open(Main_Menu)
def FFUCPY(session, **kwargs):
 session.open(CCqXgM)
def FFCweb(session, **kwargs):
 session.open(CCCwQV)
def FFwkCL(session, **kwargs):
 CCKx3s.VVpa1E(session, isFromExternal=True)
def FFlRSv(session, **kwargs):
 FFieRK(session, reopen=True)
def FFiuYv(session, **kwargs):
 session.open(CCy52I, fncMode=CCy52I.VVRoI8)
def FFg43c():
 FFJJ5m(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFqtua(), FFSJwh(), FFjK1p(), FFghAt() ])
 FFJJ5m(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFPeyA() ])
def FFJJ5m(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VV3dPC = None
def FF7lRV():
 try:
  global VV3dPC
  if VV3dPC is None:
   VV3dPC    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFFfMA
  ChannelContextMenu.FFtOkt = FFtOkt
 except:
  pass
def FFFfMA(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VV3dPC(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , BF(SELF.FFtOkt, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , BF(SELF.FFtOkt, title1, csel, isFind=True))))
def FFtOkt(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFTpSI(refCode)
 except:
  pass
 self.session.open(BF(CCxaT0, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFBaHA(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FFoREh, session, "lok")
 hk.actions["longCancel"]= BF(FFoREh, session, "lesc")
 hk.actions["longRed"] = BF(FFoREh, session, "lred")
 for k in (CCuXhY.VVuqcr, CCuXhY.VVptsk, CCuXhY.VVGlu4):
  hk.actions[k] = BF(CCuXhY.VVaMRB, session, k)
def FFoREh(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CCFRcE.VVCwPJ:
    CCFRcE.VVCwPJ.close()
   if not CCKx3s.VVwJWf:
    CCKx3s.VVpa1E(session, isFromExternal=True)
  except:
   pass
def FFu7KK(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FFVOCw(SELF, title="", addLabel=False, addScrollLabel=False, VVJ4QS=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFyAmw()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCqCpD(SELF)
 if VVJ4QS:
  SELF["myMenu"] = MenuList(VVJ4QS)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVfFPM        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFCDOS(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFQnnD, SELF, "0") ,
  "1" : BF(FFQnnD, SELF, "1") ,
  "2" : BF(FFQnnD, SELF, "2") ,
  "3" : BF(FFQnnD, SELF, "3") ,
  "4" : BF(FFQnnD, SELF, "4") ,
  "5" : BF(FFQnnD, SELF, "5") ,
  "6" : BF(FFQnnD, SELF, "6") ,
  "7" : BF(FFQnnD, SELF, "7") ,
  "8" : BF(FFQnnD, SELF, "8") ,
  "9" : BF(FFQnnD, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFthPj, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFQnnD(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVCLGj:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVCLGj + SELF.keyPressed + VVyLoh)
    txt = VVyLoh + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFHbVj(SELF, txt)
def FFthPj(SELF, tableObj, colNum):
 FFHbVj(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VVeb2k(i)
     break
 except:
  pass
def FFzDv6(SELF, setMenuAction=True):
 if setMenuAction:
  global VVnWCp
  VVnWCp = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFyAmw():
 return ("  %s" % VVnWCp)
def FFdufS(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFVK2H(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFyhto(color):
 return parseColor(color).argb()
def FFq6y3(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFg8wK(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FF9Sok(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFT6nF(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVCLGj)
 else:
  return ""
def FFAR3g(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVU8ll, word, VVU8ll, VVCLGj)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVU8ll, word, VVU8ll)
def FFrGgO(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVCLGj
def FFGsQg(color):
 if color: return "echo -e '%s' %s;" % (VVU8ll, FFT6nF(VVU8ll, VVy0iZ))
 else : return "echo -e '%s';" % VVU8ll
def FFEuDm(title, color):
 title = "%s\n%s\n%s\n" % (VVU8ll, title, VVU8ll)
 return FFrGgO(title, color)
def FFAoMS(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFwAdu(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFS6vB(callBackFunction):
 tCons = CCjjBT()
 tCons.ePopen("echo", BF(FFzntE, callBackFunction))
def FFzntE(callBackFunction, result, retval):
 callBackFunction()
def FFlaBE(SELF, fnc, title="Processing ...", clearMsg=True):
 FFHbVj(SELF, title)
 tCons = CCjjBT()
 tCons.ePopen("echo", BF(FFXXao, SELF, fnc, clearMsg))
def FFXXao(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFHbVj(SELF)
def FFc7L0(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVTzA8
  else       : return ""
def FFz7l2(cmd):
 txt = FFc7L0(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFIgoM(cmd):
 lines = FFz7l2(cmd)
 if lines: return lines[0]
 else : return ""
def FFtE6f(SELF, cmd):
 lines = FFz7l2(cmd)
 VVjhh4 = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVjhh4.append((key, val))
  elif line:
   VVjhh4.append((line, ""))
 if VVjhh4:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFA1pv(SELF, None, header=header, VVITUl=VVjhh4, VV7ux5=widths, VVy2kz=28)
 else:
  FFJWo9(SELF, cmd)
def FFJWo9(    SELF, cmd, **kwargs): SELF.session.open(CCZgNT, VVe6kp=cmd, VVpwtj=True, VVbIg5=VVmDB2, **kwargs)
def FF3qwl(  SELF, cmd, **kwargs): SELF.session.open(CCZgNT, VVe6kp=cmd, **kwargs)
def FFy4dI(   SELF, cmd, **kwargs): SELF.session.open(CCZgNT, VVe6kp=cmd, VVMHrW=True, VVEmyj=True, VVbIg5=VVmDB2, **kwargs)
def FFH1sU(  SELF, cmd, **kwargs): SELF.session.open(CCZgNT, VVe6kp=cmd, VVMHrW=True, VVEmyj=True, VVbIg5=VV08OK, **kwargs)
def FFyKCd(  SELF, cmd, **kwargs): SELF.session.open(CCZgNT, VVe6kp=cmd, VVLemo=True , **kwargs)
def FFjOQv(  session, cmd, **kwargs):      session.open(CCZgNT, VVe6kp=cmd, VVLemo=True , **kwargs)
def FFfrF5( SELF, cmd, **kwargs): SELF.session.open(CCZgNT, VVe6kp=cmd, VV644R=True   , **kwargs)
def FFW93x( SELF, cmd, **kwargs): SELF.session.open(CCZgNT, VVe6kp=cmd, VVUCBd=True  , **kwargs)
def FFyto6(cmd):
 return cmd + " > /dev/null 2>&1"
def FF0r54(cmd):
 return cmd + " 2> /dev/null"
def FFP76l():
 return " > /dev/null 2>&1"
def FFemcg(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFRjyr(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFHJyu():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FFIgoM(cmd)
VVNauh     = 0
VV3ITS      = 1
VV6nhb   = 2
VVlKhU      = 3
VV1iyq      = 4
VVPceO     = 5
VVi1jL     = 6
VVgRg8 = 7
VVwcQY = 8
VVujU7 = 9
VVFaXR  = 10
VVnArD     = 11
VVunnv  = 12
VVmQkd  = 13
def FFFOwQ(parmNum, grepTxt):
 if   parmNum == VVNauh  : param = ["update"   , "dpkg update" ]
 elif parmNum == VV3ITS   : param = ["list"   , "apt list" ]
 elif parmNum == VV6nhb: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFHJyu()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFMotr(parmNum, package):
 if   parmNum == VVlKhU      : param = ["info"      , "apt show"         ]
 elif parmNum == VV1iyq      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVPceO     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVi1jL     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVgRg8 : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVwcQY : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VVujU7 : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVFaXR  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVnArD     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVunnv  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVmQkd  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFHJyu()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFF2ep():
 result = FFIgoM("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFMotr(VVi1jL , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFyto6("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFyto6("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFT6nF(failed1, VVy0iZ))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFT6nF(failed2, VVy0iZ))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFT6nF(failed3, VVwmjQ))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFC4vV(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFMotr(VVi1jL , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFyto6("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFT6nF(failed1, VVy0iZ))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFT6nF(failed2, VVwmjQ))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFHkZ8(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFyto6('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFyto6("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFZF5l(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CC7qa7.VVa7bt()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FFup4P(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFZF5l(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFFebl(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FF2Omp(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFZF5l(path, maxSize=maxSize, encLst=encLst)
  if lines: FFCxQN(SELF, lines, title=title, VVbIg5=VVmDB2)
  else : FFTXJH(SELF, path, title=title)
 else:
  FF6vdZ(SELF, path, title)
def FFrc1O(SELF, path, title):
 if fileExists(path):
  txt = FFZF5l(path)
  txt = txt.replace("#W#", VVCLGj)
  txt = txt.replace("#Y#", VVtSeQ)
  txt = txt.replace("#G#", VVyLoh)
  txt = txt.replace("#C#", VVE6YJ)
  txt = txt.replace("#P#", VVFBP5)
  FFCxQN(SELF, txt, title=title)
 else:
  FF6vdZ(SELF, path, title)
def FFKPga(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFxBb9(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFegwS(parent)
 else    : return FFFTbs(parent)
def FFbSa4(path):
 return os.path.basename(os.path.normpath(path))
def FF2Omp(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFM75P(path):
 try:
  os.remove(path)
 except:
  pass
def FFegwS(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFFTbs(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFSWtc():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVEK1s)
 paths.append(VVEK1s.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFKPga(ba)
 for p in list:
  p = ba + p + VVEK1s
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVWcf6, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVEK1s, VVWcf6 , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VV2qoQ, VVnEh8 = FFSWtc()
def FFTS1C():
 def VVRJVE(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VVeBTK   = VVRJVE(CFG.backupPath, CCVsdm.VViBwI())
 VVxPHS   = VVRJVE(CFG.downloadedPackagesPath, t)
 VVQSI3  = VVRJVE(CFG.exportedTablesPath, t)
 VVKGac  = VVRJVE(CFG.exportedPIconsPath, t)
 VVeMKu   = VVRJVE(CFG.packageOutputPath, t)
 global VVL4Xa
 VVL4Xa = FFegwS(CFG.backupPath.getValue())
 if VVeBTK or VVeMKu or VVxPHS or VVQSI3 or VVKGac or oldMovieDownloadPath:
  configfile.save()
 return VVeBTK, VVeMKu, VVxPHS, VVQSI3, VVKGac, oldMovieDownloadPath
def FFGMwb(path):
 path = FFFTbs(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFu4wu(SELF, pathList, tarFileName, addTimeStamp=True):
 VVITUl = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVITUl.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVITUl.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVITUl.append(path)
 if not VVITUl:
  FFfYN0(SELF, "Files not found!")
 elif not pathExists(VVL4Xa):
  FFfYN0(SELF, "Path not found!\n\n%s" % VVL4Xa)
 else:
  VVoH5O = FFegwS(VVL4Xa)
  tarFileName = "%s%s" % (VVoH5O, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFSZ6D())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVITUl:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVU8ll
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFT6nF(tarFileName, VVqQXm))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFT6nF(failed, VVqQXm))
  cmd += "fi;"
  cmd +=  sep
  FF3qwl(SELF, cmd)
def FFABOX(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FF5qCx(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FF5qCx(SELF["keyInfo"], "info")
def FF5qCx(barObj, fName):
 path = "%s%s%s" % (VVnEh8, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FF80S3(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFBdLm(satNum)
  return satName
def FFBdLm(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFQQpf(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FF80S3(val)
  else  : sat = FFBdLm(val)
 return sat
def FFjx2y(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FF80S3(num)
 except:
  pass
 return sat
def FFOBOl(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FF6soe(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFmiK9(info, iServiceInformation.sServiceref)
   prov = FFmiK9(info, iServiceInformation.sProvider)
   state = str(FFmiK9(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFCeZx(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFeiz0(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFmiK9(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FF95YK(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFTpSI(refCode):
 info = FFlduQ(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFUjGn(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFyiHM(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFlduQ(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVKzVO = eServiceCenter.getInstance()
  if VVKzVO:
   info = VVKzVO.info(service)
 return info
def FFbrIp(SELF, refCode, VVVlLd=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFTPuE(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVVlLd:
   FFubtH(SELF, isFromSession)
 try:
  VVdeEx = InfoBar.instance
  if VVdeEx:
   VVBoUf = VVdeEx.servicelist
   if VVBoUf:
    servRef = eServiceReference(refCode)
    VVBoUf.saveChannel(servRef)
 except:
  pass
def FFTPuE(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCAVwF()
    if pr.VV6PGQ(refCode, chName, decodedUrl, iptvRef):
     pr.VVXY5q(SELF, isFromSession)
def FFCeZx(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFMUSj(url): return FFwFJ3(url) or FFfXsY(url)
def FFwFJ3(url)  : return any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFfXsY(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFeiz0(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFaTzZ(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFaTzZ(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFjRDJ(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFWMj3(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFO6Qx(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFrhk5(txt):
 try:
  return FFWMj3(FFO6Qx(txt)) == txt
 except:
  return False
def FFQ9JP(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FFegwS(newPath), patt))
def FFubtH(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: CCKx3s.VVpa1E(session, isFromExternal=isFromSession)
 else      : FFieRK(session, reopen=True)
def FFieRK(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FFieRK, session), CCFRcE)
  except:
   try:
    FFgF4z(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFB5r2(refCode):
 tp = CCoeZX()
 if tp.VVQtNM(refCode) : return True
 else        : return False
def FFWATy(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFpUU8(True)
     return True
 return False
def FFpUU8(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FFgKLi()
def FFgKLi():
 VVdeEx = InfoBar.instance
 if VVdeEx:
  VVBoUf = VVdeEx.servicelist
  if VVBoUf:
   VVBoUf.setMode()
def FF5CZv(root):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVKzVO = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVKzVO.info(service)
    lst.append((service.toString(), info.getName(service)))
 except:
  pass
 return lst
def FFxdEf():
 VVMouC = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VV7i3E = list(VVMouC)
 return VV7i3E, VVMouC
def FFKjU2():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFWucH(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FF4ENQ(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFkTm6():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFSZ6D():
 return FFkTm6().replace(" ", "_").replace("-", "").replace(":", "")
def FFxB2b(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFR4Gb():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFSAwr(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCCwQV.VVY4JM(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCCwQV.VVomSS(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFyto6("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFXWUV(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FFIMVJ(num):
 return "s" if num > 1 else ""
def FFle5S(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFWAiI(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FF1xYR(a, b):
 return (a > b) - (a < b)
def FFmcic(a, b):
 def VV36bb(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VV36bb(a)
 b = VV36bb(b)
 return (a > b) - (a < b)
def FF0Q8q(mycmp):
 class CCthYi(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CCthYi
def FF8O6K(SELF, message, title="", VVGpYx=None):
 SELF.session.openWithCallback(VVGpYx, CCj9qb, title=title, message=message, VVLMX6=True)
def FFCxQN(SELF, message, title="", VVbIg5=VVmDB2, VVGpYx=None, **kwargs):
 SELF.session.openWithCallback(VVGpYx, CCj9qb, title=title, message=message, VVbIg5=VVbIg5, **kwargs)
def FFfYN0(SELF, message, title="")  : FFgF4z(SELF.session, message, title)
def FF6vdZ(SELF, path, title="") : FFgF4z(SELF.session, "File not found !\n\n%s" % path, title)
def FFTXJH(SELF, path, title="") : FFgF4z(SELF.session, "File is empty !\n\n%s"  % path, title)
def FF1KkZ(SELF, title="")  : FFgF4z(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFgF4z(session, message, title="") : session.open(BF(CChcJ4, title=title, message=message))
def FFoW9P(SELF, VVGpYx, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVGpYx, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVGpYx, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFfYN0(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFZw7B(SELF, callBack_Yes, VVgyFZ, callBack_No=None, title="", VV5RdC=False, VV6xap=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FFCT1Q, callBack_Yes, callBack_No)
         , BF(CCvoBn, title=title, VVgyFZ=VVgyFZ, VV6xap=VV6xap, VV5RdC=VV5RdC))
def FFCT1Q(callBack_Yes, callBack_No, FFZw7Bed):
 if FFZw7Bed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFHbVj(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFg8wK(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FF4fj5(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFGcL0(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VV8nqG = eTimer()
def FF4fj5(SELF, milliSeconds=1000):
 SELF.onClose.append(BF(FFD64s, SELF))
 fnc = BF(FFD64s, SELF)
 try:
  t = VV8nqG.timeout.connect(fnc)
 except:
  VV8nqG.callback.append(fnc)
 VV8nqG.start(milliSeconds, 1)
def FFD64s(SELF):
 VV8nqG.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFA1pv(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCeuNr, **kwargs))
  else   : win = SELF.session.open(BF(CCeuNr, **kwargs))
  FFI3MP(win)
  return win
 except:
  return None
def FFZP3S(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CCpR55, **kwargs))
 FFI3MP(win)
 return win
def FFksVn(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFzeU3(SELF, **kwargs):
 SELF.session.open(CCy52I, **kwargs)
def FFeAg3(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFqDBE(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFlegS(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVdbIk, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFJdIh(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFlegS(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize  = winInst.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFerEQ():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFzL3c(VVy2kz):
 screenSize  = FFerEQ()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVy2kz)
 return bodyFontSize
def FFbwug(VVy2kz, extraSpace):
 font = gFont(VVdbIk, VVy2kz)
 VVkXuR = fontRenderClass.getInstance().getLineHeight(font) or (VVy2kz * 1.25)
 return int(VVkXuR + VVkXuR * extraSpace)
def FFNQkv(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True):
 screenSize = FFerEQ()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVdbIk, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFbwug(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVdbIk, titleFontSize, alignLeftCenter)
 if winType == VVLAKc or winType == VVqRLf:
  if winType == VVqRLf : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVNXcd:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == VVXKIb:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVdbIk, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d"    position="1,%d" size="%d,%d" zPosition="6" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VV5zNN:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FF8O6KL = b2Left2 + timeW + marginLeft
  FF8O6KW = b2Left3 - marginLeft - FF8O6KL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FF8O6KL , b2Top, FF8O6KW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVOVX1:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVXQ7N:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVp52N:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVvNKl:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVdbIk, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVdbIk, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVLVhk:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVdbIk, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVQp8r:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVdbIk, fontH, alignCenter)
 elif winType in (VVQ9al, VVFdj2):
  if winType == VVQ9al: totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  else         : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - boxT) / totRows)
  picH = int(boxH * picR)
  lblH = int(boxH * lblR) - 2
  lblT = boxT + picH + 2
  lblFont = int(lblH * 0.65)
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVQ9al:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h , fg, bg[i]  , VVdbIk, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h , fg, bg[i+3], VVdbIk, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVdbIk, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVdbIk, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h , fg, bg, VVdbIk, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h , fg, bg, VVdbIk, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00FFFF00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2, transpBG)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVdbIk, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VViXrc:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVfuBG:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VVQhFe : align = alignLeftCenter
  elif winType == VVpCD5 : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVVTym:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVdbIk
  if usefixedFont and winType == VVpCD5:
   fLst = FFiwO0()
   if   VVLWmv in fLst and CFG.fontPathTerm.getValue(): fontName = VVLWmv
   elif VVdS9F in fLst         : fontName = VVdS9F
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVy2kz = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVdbIk, VVy2kz, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVop6p = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVdbIk, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVop6p[i], VVdbIk, barFont, alignCenter)
   left += btnW + gap
 if winType == VVpCD5:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVop6p = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVop6p[i], VVdbIk, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFNQkv(VVLAKc, 800, 950, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VVcbKT = ""
  self.themsList  = []
  s = "  "
  VVJ4QS = []
  if VVktXS:
   VVJ4QS.append(("-- MY TEST --"    , "myTest"   ))
  VVJ4QS.append((s + "File Manager"     , "FileManager"  ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append((s + "Services/Channels"   , "ChannelsTools" ))
  VVJ4QS.append((s + "IPTV"       , "IptvTools"  ))
  VVJ4QS.append((s + "PIcons"      , "PIconsTools"  ))
  VVJ4QS.append((s + "SoftCam"      , "SoftCam"   ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append((s + "Plugins"      , "PluginsTools" ))
  VVJ4QS.append((s + "Terminal"      , "Terminal"  ))
  VVJ4QS.append((s + "Backup & Restore"    , "BackupRestore" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append((s + "Date/Time"     , "Date_Time"  ))
  VVJ4QS.append((s + "Check Internet Connection" , "CheckInternet" ))
  self.totalItems = len(VVJ4QS)
  FFVOCw(self, VVJ4QS=VVJ4QS)
  FFdufS(self["keyRed"] , "Exit")
  FFdufS(self["keyGreen"] , "Settings")
  FFdufS(self["keyYellow"], "Dev. Info.")
  FFdufS(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close      ,
   "green"   : self.VVHnpL     ,
   "yellow"  : self.VVfqOG     ,
   "blue"   : self.VVCUCb     ,
   "info"   : self.VVCUCb     ,
   "next"   : self.VVUFxJ     ,
   "menu"   : self.VVLY0q   ,
   "0"    : BF(self.VVepMA, 0)  ,
   "1"    : BF(self.VVgSzF, 1)   ,
   "2"    : BF(self.VVgSzF, 2)   ,
   "3"    : BF(self.VVgSzF, 3)   ,
   "4"    : BF(self.VVgSzF, 4)   ,
   "5"    : BF(self.VVgSzF, 5)   ,
   "6"    : BF(self.VVgSzF, 6)   ,
   "7"    : BF(self.VVgSzF, 7)   ,
   "8"    : BF(self.VVgSzF, 8)   ,
   "9"    : BF(self.VVgSzF, 9)
  })
  self.onShown.append(self.VV47vn)
  self.onClose.append(self.onExit)
  global VVtMJJ, VV5uVo, VVSJRi
  VVtMJJ = VV5uVo = VVSJRi = False
 def VVfFPM(self):
  item = FFzDv6(self)
  self.VVgSzF(item)
 def VVgSzF(self, item):
  if item is not None:
   if item in range(1, 9):
    self["myMenu"].moveToIndex(item + 1)
    item = FFzDv6(self)
   if   item == "myTest"     : self.VVe7Du()
   elif item in ("FileManager"  , 1) : self.session.open(CCqXgM)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCpE07)
   elif item in ("IptvTools"  , 3) : self.session.open(CCCwQV)
   elif item in ("PIconsTools"  , 4) : self.VVN1et()
   elif item in ("SoftCam"   , 5) : self.session.open(CCUpIE)
   elif item in ("PluginsTools" , 6) : self.session.open(CC1pHg)
   elif item in ("Terminal"  , 7) : self.session.open(CCiQFL)
   elif item in ("BackupRestore" , 8) : self.session.open(CCHP0M)
   elif item in ("Date_Time"  , 9) : self.session.open(CCOCDL)
   elif item in ("CheckInternet" , 10) : self.session.open(CCjdSK)
   else         : self.close()
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FFAoMS(self["myMenu"])
  FFJdIh(self)
  FFeAg3(self)
  FFABOX(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVHz5F)
  self["myTitle"].setText(title)
  VVeBTK, VVeMKu, VVxPHS, VVQSI3, VVKGac, oldMovieDownloadPath = FFTS1C()
  self.VVwyBe()
  if VVeBTK or VVeMKu or VVxPHS or VVQSI3 or VVKGac or oldMovieDownloadPath:
   VVzg89 = lambda path, subj: "%s:\n%s\n\n" % (subj, FFrGgO(path, VVPUgM)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVzg89(VVeBTK   , "Backup/Restore Path"    )
   txt += VVzg89(VVeMKu  , "Created Package Files (IPK/DEB)" )
   txt += VVzg89(VVxPHS  , "Download Packages (from feeds)" )
   txt += VVzg89(VVQSI3 , "Exported Tables"     )
   txt += VVzg89(VVKGac , "Exported PIcons"     )
   txt += VVzg89(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFCxQN(self, txt, title="Settings Paths")
  if (EASY_MODE or VVLDgg or VVktXS):
   FFg8wK(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFHbVj(self, "Welcome", 300)
  FFS6vB(BF(self.VVUH3P, title))
 def VVUH3P(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCVsdm.VVgR05()
   if url:
    newWebVer = CCVsdm.VVNLfy(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFyto6("rm /tmp/ajpanel*"))
  global VVtMJJ, VV5uVo, VVSJRi
  VVtMJJ = VV5uVo = VVSJRi = False
 def VVepMA(self, digit):
  self.VVcbKT += str(digit)
  ln = len(self.VVcbKT)
  global VVtMJJ, VVSJRi
  if ln == 4:
   if self.VVcbKT == "0" * ln:
    VVtMJJ = True
    FFg8wK(self["myTitle"], "#800080")
   else:
    self.VVcbKT = "x"
  elif self.VVcbKT == "0" * 8:
   VVSJRi = True
 def VVUFxJ(self):
  self.VVcbKT += ">"
  if self.VVcbKT == "0" * 4 + ">" * 2:
   global VV5uVo
   VV5uVo = True
   FFg8wK(self["myTitle"], "#dd5588")
 def VVN1et(self):
  found = False
  pPath = CC8ahC.VVmFFX()
  if pathExists(pPath):
   for fName, fType in CC8ahC.VVSlLY(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CC8ahC)
  else:
   VVJ4QS = []
   VVJ4QS.append(("PIcons Tools" , "CC8ahC" ))
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append(CC8ahC.VVN4mg())
   VVJ4QS.append(VV4c5n)
   VVJ4QS += CC8ahC.VV1TeT()
   FFZP3S(self, self.VVhmn9, VVJ4QS=VVJ4QS)
 def VVhmn9(self, item=None):
  if item:
   if   item == "CC8ahC"   : self.session.open(CC8ahC)
   elif item == "VV6Wt9"  : CC8ahC.VV6Wt9(self)
   elif item == "VVuWBg"  : CC8ahC.VVuWBg(self)
   elif item == "findPiconBrokenSymLinks" : CC8ahC.VVGBpq(self, True)
   elif item == "FindAllBrokenSymLinks" : CC8ahC.VVGBpq(self, False)
 def VVHnpL(self):
  self.session.open(CCVsdm)
 def VVfqOG(self):
  self.session.open(CC7LVQ)
 def VVCUCb(self):
  changeLogFile = VVnEh8 + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FFup4P(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFrGgO("\n%s\n%s\n%s" % (VVU8ll, line, VVU8ll), VVy0iZ, VVCLGj)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FFrGgO(line, VVyLoh, VVCLGj)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFCxQN(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVHz5F, PLUGIN_DESCRIPTION), VVy2kz=26)
 def VVLY0q(self):
  title = "Style Changer"
  c1, c2, c3, c4 = VV6svy, VVPUgM, VVtSeQ, VV61Yf
  VVJ4QS = []
  VVJ4QS.append((c1 + "Change Title Colors"    , "title"  ))
  VVJ4QS.append((c1 + "Change Menu Area Colors"   , "body"  ))
  VVJ4QS.append((c1 + "Change Menu Pointer Colors"  , "cursor"  ))
  VVJ4QS.append((c1 + "Change Bottom Bar Colors"  , "bar"   ))
  VVJ4QS.append((c2 + "Reset Colors"     , "resetColor" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append((c3 + "Change %s Font" % PLUGIN_NAME , "mainFont" ))
  VVJ4QS.append((c3 + "Change Termianl Font"    , "termFont" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append((c4 + "Change System Font"     , "sysFont"  ))
  FFZP3S(self, BF(self.VV3mwE, title), VVJ4QS=VVJ4QS, width=800, title=title)
 def VV3mwE(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VV2HaY()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VV9ptQ, tDict, item), CCSXlr, defFG=fg, defBG=bg)
   elif item == "resetColor" : FFZw7B(self, self.VV074l, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVL0fn(VV10vq  )
   elif item == "termFont"  : self.VVL0fn(VVLWmv)
   elif item == "sysFont"  : self.VVL0fn(VV0P9U  )
 def VVojZB(self):
  return VVL4Xa + "ajpanel_colors"
 def VV2HaY(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVojZB()
  if fileExists(p):
   txt = FFZF5l(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VV9ptQ(self, tDict, item, fg, bg):
  if fg:
   self.VVbJb7(item, fg)
   self.VVkkLR(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVuhM4(tDict)
 def VVuhM4(self, tDict):
   p = self.VVojZB()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVbJb7(self, item, fg):
  if   item == "title" : FFq6y3(self["myTitle"], fg)
  elif item == "body"  :
   FFq6y3(self["myMenu"], fg)
   FFq6y3(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFg8wK(self["myBar"], fg)
   FFq6y3(self["keyRed"], fg)
   FFq6y3(self["keyGreen"], fg)
   FFq6y3(self["keyYellow"], fg)
   FFq6y3(self["keyBlue"], fg)
 def VVkkLR(self, item, bg):
  if   item == "title" : FFg8wK(self["myTitle"], bg)
  elif item == "body"  :
   FFg8wK(self["myMenu"], bg)
   FFg8wK(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFg8wK(self["myBar"], bg)
 def VV074l(self):
  os.system(FFyto6("rm %s" % self.VVojZB()))
  self.close()
 def VVwyBe(self):
  tDict = self.VV2HaY()
  self.VVhNxZ(tDict, "title")
  self.VVhNxZ(tDict, "body")
  self.VVhNxZ(tDict, "cursor")
  self.VVhNxZ(tDict, "bar")
 def VVhNxZ(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVbJb7(name, fg)
  if bg: self.VVkkLR(name, bg)
 def VVL0fn(self, which):
  if   which == VV10vq  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VVLWmv : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VV0P9U  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CCyNA0.VVqQIc(self, "Change %s Font" % title, defFnt, rest, BF(self.VVT4nP, which))
 def VVT4nP(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VV10vq  : FFu7KK(CFG.fontPathMain, path)
   elif which == VVLWmv: FFu7KK(CFG.fontPathTerm, path)
   elif which == VV0P9U  : FFu7KK(CFG.fontPathSys , path)
   err = Main_Menu.VVKOwu(which)
   if err          : FFfYN0(self, err, title=title)
   elif which == VV10vq   : self.close()
   elif which == VVLWmv  : FFHbVj(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VV0P9U and path: FFHbVj(self, "System font applied", 1500, isGrn=True)
   elif which == VV0P9U   : FFZw7B(self, BF(Main_Menu.VV644R, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VV644R(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVKOwu(name):
  if   name == VV10vq : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VVLWmv: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VV0P9U : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FFiwO0()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VV0P9U:
   nameLst = []
   for nm in FFiwO0():
    if not nm in (VV10vq, VVLWmv):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FFV9L6(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FFiwO0()
  else    : return "Could not add font"
 def VVe7Du(self):
  CCKx3s.VVpa1E(self.session)
class CCuXhY():
 VVuqcr  = "all"
 VVptsk = "vid"
 VVGlu4  = "osd"
 @staticmethod
 def VVaMRB(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FFemcg("grab"):
    winShown = session.current_dialog.shown
    if k == CCuXhY.VVptsk and winShown: session.current_dialog.hide()
    FFS6vB(BF(CCuXhY.VVOLxx, title, session, k, winShown))
   else:
    FFgF4z(session, "No Grab command !", title=title)
 @staticmethod
 def VVOLxx(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CCuXhY.VVGlu4:
   if not winShown:
    FFgF4z(session, "No Window to capture !", title=title)
    return
   if not CCuXhY.VVT9N7(session, title, isFromExternal=True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CCuXhY.VVG481(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FFgF4z(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(session, isFromSession=True)
   chName = iSub(r"[^A-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FFegwS(CFG.exportedPIconsPath.getValue()), fTitle, FFSZ6D(), ext)
  res = os.system(FF0r54("grab -q -s %s > '%s'" % (typ, path)))
  if k == CCuXhY.VVptsk and winShown:
   session.current_dialog.show()
  elif k == CCuXhY.VVGlu4:
   ok = CCuXhY.VVpkwn(path, x, y, w, h)
   if not ok:
    FFM75P(path)
    FFgF4z(session, "Error while cropping image file !", title=title)
    return
  if res == 0 and fileExists(path): session.open(BF(CCkc9M, title=path, VVksLF=path))
  else       : FFgF4z(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VVT9N7(SELF, title, isFromExternal):
  try:
   from PIL import Image
   return True
  except:
   FFZw7B(SELF, BF(CCuXhY.VVgtUD, SELF), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VVgtUD(SELF):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  FFjOQv(SELF, FFMotr(VVi1jL, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VVG481(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-z0-9]" ,repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VVpkwn(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FFerEQ()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FFWAiI(x , 0, scrW, 0, w)
     y  = FFWAiI(y , 0, scrH, 0, h)
     x1 = FFWAiI(x1, 0, scrW, 0, w)
     y1 = FFWAiI(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
class CCyNA0(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FFNQkv(VVLAKc, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FFrGgO(" (Requires GUI Restart)", VV61Yf) if withRestart else ""
  VVJ4QS = []
  for path in self.fontsList:
   VVJ4QS.append((os.path.splitext(os.path.basename(path))[0], path))
  VVJ4QS.sort(key=lambda x: x[0].lower())
  VVJ4QS.insert(0, VV4c5n)
  VVJ4QS.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VVJ4QS):
    if len(item) == 2 and item[1] == self.defFnt:
     VVJ4QS[ndx] = (VVqQXm + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVJ4QS[curIndex] = (VVqQXm + VVJ4QS[curIndex][0], VVJ4QS[curIndex][1])
  FFVOCw(self, VVJ4QS=VVJ4QS, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FFAoMS(self["myMenu"])
  FFJdIh(self)
  self["myMenu"].onSelectionChanged.append(self.VVff6E)
  self["myBar"].setText(self.VVAcnr())
  self["myBar"].instance.setHAlign(1)
  self.VVff6E()
 def VVfFPM(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVff6E(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FFV9L6(path, fnt, isRepl=1)
  else:
   fnt = VVhadi
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VVAcnr(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VVqQIc(SELF, title, defFnt, rest, VVGpYx):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FFQ9JP(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VVGpYx, CCyNA0, title, fontsList, defFnt, rest)
  else  : FFfYN0(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CC7qa7():
 @staticmethod
 def VVa7bt():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VV5Rut(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFA1pv(SELF, None, VVITUl=lst, VVy2kz=30, VVR0cj=True)
 @staticmethod
 def VV6aJR(path, SELF=None):
  for enc in CC7qa7.VVa7bt():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFfYN0(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVkIl0(SELF, path, cbFnc, defEnc="utf8", onlyWorkingEnc=True, title="Select Encoding"):
  FFHbVj(SELF)
  lst = CC7qa7.VVihkz(path, onlyWorkingEnc=onlyWorkingEnc)
  if lst:
   VVJ4QS = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if defEnc == enc:
     txt = FFrGgO(txt, VVqQXm)
    VVJ4QS.append((txt, enc))
   if onlyWorkingEnc: VV1Y9q, VVMnLe = "#22003344", "#22002233"
   else    : VV1Y9q, VVMnLe = "#22220000", "#22220000"
   FFZP3S(SELF, cbFnc, title=title, VVJ4QS=VVJ4QS, width=900, VV1Y9q=VV1Y9q, VVMnLe=VVMnLe)
  else:
   FFHbVj(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVihkz(path, onlyWorkingEnc=True):
  encLst = []
  cPath = VVnEh8 + "codecs"
  if fileExists(cPath):
   lines = FFup4P(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CC7qa7.VVa7bt())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if onlyWorkingEnc:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CC7LVQ(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFNQkv(VVLAKc, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVJ4QS = []
  VVJ4QS.append(("Settings File"        , "SettingsFile"   ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Box Info"          , "VVqYT8"    ))
  VVJ4QS.append(("Tuners Info"         , "VVwHXK"   ))
  VVJ4QS.append(("Python Version"        , "VVNsC3"   ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Screen Size"         , "ScreenSize"    ))
  VVJ4QS.append(("Language/Locale"        , "Locale"     ))
  VVJ4QS.append(("Processor"         , "Processor"    ))
  VVJ4QS.append(("Operating System"        , "OperatingSystem"   ))
  VVJ4QS.append(("Drivers"          , "drivers"     ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("System Users"         , "SystemUsers"    ))
  VVJ4QS.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVJ4QS.append(("Uptime"          , "Uptime"     ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Host Name"         , "HostName"    ))
  VVJ4QS.append(("MAC Address"         , "MACAddress"    ))
  VVJ4QS.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVJ4QS.append(("Network Status"        , "NetworkStatus"   ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Disk Usage"         , "VVtMfC"    ))
  VVJ4QS.append(("Mount Points"         , "MountPoints"    ))
  VVJ4QS.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVJ4QS.append(("USB Devices"         , "USB_Devices"    ))
  VVJ4QS.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVJ4QS.append(("Directory Size"        , "DirectorySize"   ))
  VVJ4QS.append(("Memory"          , "Memory"     ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVJ4QS.append(("Running Processes"       , "RunningProcesses"  ))
  VVJ4QS.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFVOCw(self, VVJ4QS=VVJ4QS, title="Device Information")
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FFAoMS(self["myMenu"])
  FFJdIh(self)
 def VVfFPM(self):
  global VVnWCp
  VVnWCp = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCiaYP)
   elif item == "VVqYT8"    : self.VVqYT8()
   elif item == "VVwHXK"   : self.VVwHXK()
   elif item == "VVNsC3"   : self.VVNsC3()
   elif item == "ScreenSize"    : FFCxQN(self, "Width\t: %s\nHeight\t: %s" % (FFerEQ()[0], FFerEQ()[1]))
   elif item == "Locale"     : CC7qa7.VV5Rut(self)
   elif item == "Processor"    : self.VVbWOO()
   elif item == "OperatingSystem"   : FFJWo9(self, "uname -a"        )
   elif item == "drivers"     : self.VVQWAl()
   elif item == "SystemUsers"    : FFJWo9(self, "id"          )
   elif item == "LoggedInUsers"   : FFJWo9(self, "who -a"         )
   elif item == "Uptime"     : FFJWo9(self, "uptime"         )
   elif item == "HostName"     : FFJWo9(self, "hostname"        )
   elif item == "MACAddress"    : self.VVNVMQ()
   elif item == "NetworkConfiguration"  : FFJWo9(self, "ifconfig %s %s" % (FFT6nF("HWaddr", VVOBCT), FFT6nF("addr:", VVy0iZ)))
   elif item == "NetworkStatus"   : FFJWo9(self, "netstat -tulpn"       )
   elif item == "VVtMfC"    : self.VVtMfC()
   elif item == "MountPoints"    : FFJWo9(self, "mount %s" % (FFT6nF(" on ", VVy0iZ)))
   elif item == "FileSystemTable"   : FFJWo9(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFJWo9(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFJWo9(self, "blkid"         )
   elif item == "DirectorySize"   : FFJWo9(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VV4FcT="Reading size ...")
   elif item == "Memory"     : FFJWo9(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVC3wP()
   elif item == "RunningProcesses"   : FFJWo9(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFJWo9(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVCjeV()
   else         : self.close()
 def VVNVMQ(self):
  res = FFc7L0("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFCxQN(self, txt)
  else:
   FFJWo9(self, "ip link")
 def VVj5Ya(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFz7l2(cmd)
  return lines
 def VVczKP(self, lines, headerRepl, widths, VVavJp):
  VVjhh4 = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVjhh4.append(parts)
  if VVjhh4 and len(header) == len(widths):
   VVjhh4.sort(key=lambda x: x[0].lower())
   FFA1pv(self, None, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=28, VVR0cj=True)
   return True
  else:
   return False
 def VVtMfC(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFc7L0(cmd)
  if not "invalid option" in txt:
   lines  = self.VVj5Ya(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVavJp = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVczKP(lines, headerRepl, widths, VVavJp)
  else:
   cmd = "df -h"
   lines  = self.VVj5Ya(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVavJp = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVczKP(lines, headerRepl, widths, VVavJp)
  if not allOK:
   lines = FFz7l2(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFFTbs(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVqQXm:
     note = "\n%s" % FFrGgO("Green = Mounted Partitions", VVqQXm)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVy0iZ
     elif line.endswith(mountList) : color = VVqQXm
     else       : color = VVyLoh
     txt += FFrGgO(line, color) + "\n"
    FFCxQN(self, txt + note)
   else:
    FFfYN0(self, "Not data from system !")
 def VVC3wP(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVj5Ya(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVavJp = (LEFT , CENTER, LEFT )
  allOK = self.VVczKP(lines, headerRepl, widths, VVavJp)
  if not allOK:
   FFJWo9(self, cmd)
 def VVQWAl(self):
  cmd = FFFOwQ(VV6nhb, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFJWo9(self, cmd)
  else : FF1KkZ(self)
 def VVbWOO(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFJWo9(self, cmd)
 def VVCjeV(self):
  cmd = FFFOwQ(VV3ITS, "| grep secondstage")
  if cmd : FFJWo9(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FF1KkZ(self)
 def VVqYT8(self):
  c = VVqQXm
  VVITUl = []
  VVITUl.append((FFrGgO("Box Type"  , c), FFrGgO(self.VVC8iz("boxtype").upper(), c)))
  VVITUl.append((FFrGgO("Board Version", c), FFrGgO(self.VVC8iz("board_revision") , c)))
  VVITUl.append((FFrGgO("Chipset"  , c), FFrGgO(self.VVC8iz("chipset")  , c)))
  VVITUl.append((FFrGgO("S/N"   , c), FFrGgO(self.VVC8iz("sn")    , c)))
  VVITUl.append((FFrGgO("Version"  , c), FFrGgO(self.VVC8iz("version")  , c)))
  VV2PT9   = []
  VVqmr1 = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVqmr1 = SystemInfo[key]
     else:
      VV2PT9.append((FFrGgO(str(key), VVE6YJ), FFrGgO(str(SystemInfo[key]), VVE6YJ)))
  except:
   pass
  if VVqmr1:
   VVjZXV = self.VV1HcW(VVqmr1)
   if VVjZXV:
    VVjZXV.sort(key=lambda x: x[0].lower())
    VVITUl += VVjZXV
  if VV2PT9:
   VV2PT9.sort(key=lambda x: x[0].lower())
   VVITUl += VV2PT9
  if VVITUl:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFA1pv(self, None, header=header, VVITUl=VVITUl, VV7ux5=widths, VVy2kz=28, VVR0cj=True)
  else:
   FFCxQN(self, "Could not read info!")
 def VVC8iz(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFup4P(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VV1HcW(self, mbDict):
  try:
   mbList = list(mbDict)
   VVITUl = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVITUl.append((FFrGgO(subject, VVy0iZ), FFrGgO(value, VVy0iZ)))
  except:
   pass
  return VVITUl
 def VVwHXK(self):
  txt = self.VVNtr8("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVNtr8("/proc/bus/nim_sockets")
  if not txt: txt = self.VVxRTw()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFCxQN(self, txt)
 def VVxRTw(self):
  txt = ""
  VVzg89 = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVzg89("Slot Name" , slot.getSlotName())
     txt += FFrGgO(slotName, VVy0iZ)
     txt += VVzg89("Description"  , slot.getFullDescription())
     txt += VVzg89("Frontend ID"  , slot.frontend_id)
     txt += VVzg89("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVNtr8(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFup4P(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFrGgO(line, VVy0iZ)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVNsC3(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFCxQN(self, txt)
 @staticmethod
 def VVZq40():
  def VVzg89(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VVzg89(v,0), "/etc/issue.net": VVzg89(v,1), "/etc/image-version": VVzg89(v,2)}
  for p1, d in v.items():
   img = CC7LVQ.VVf2A3(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VVzg89(v,0), p + "Plugins/": VVzg89(v,1), VVTdNX: VVzg89(v,2), VVEK1s: VVzg89(v,3)}
  for p1, d in v.items():
   img = CC7LVQ.VVrQUV(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VVf2A3(path, d):
  if fileExists(path):
   txt = FFZF5l(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVrQUV(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CCiaYP(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFNQkv(VVLAKc, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVJ4QS = []
  VVJ4QS.append(("Settings (All)"   , "Settings_All"   ))
  VVJ4QS.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVJ4QS.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVJ4QS.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVJ4QS.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVJ4QS.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVJ4QS.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VV5uVo:
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVJ4QS.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FFVOCw(self, VVJ4QS=VVJ4QS)
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FFAoMS(self["myMenu"])
  FFJdIh(self)
 def VVfFPM(self):
  global VVnWCp
  VVnWCp = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %ssettings" % VVoDv6
   grep = " | grep "
   if   item == "Settings_All"    : FFJWo9(self, cmd                )
   elif item == "Settings_HotKeys"   : FFJWo9(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_ajp"    : FFJWo9(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME     )
   elif item == "Settings_FHDG_17"   : FFJWo9(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFJWo9(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFJWo9(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFJWo9(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFJWo9(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFJWo9(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCUpIE(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFNQkv(VVLAKc, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVKste, VVNkR0, VVQQN7, camCommand = CCUpIE.VVeaHh()
  self.VVNkR0 = VVNkR0
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VVNkR0:
   c = VV6svy if VVQQN7 else VVxpap
   if   "oscam" in VVNkR0 : camName, oC = "OSCam", c
   elif "ncam"  in VVNkR0 : camName, nC = "NCam" , c
  VVJ4QS = []
  VVJ4QS.append(("OSCam Files" , "OSCamFiles"  ))
  VVJ4QS.append(("NCam Files" , "NCamFiles"  ))
  VVJ4QS.append(("CCcam Files" , "CCcamFiles"  ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append((VVtSeQ + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VVfA2x" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVJ4QS.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVJ4QS.append(VV4c5n)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  if VVNkR0: VVJ4QS.append((c + txt  , "camInfo" ))
  else  : VVJ4QS.append((txt  ,    ))
  VVJ4QS.append(VV4c5n)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VVNkR0:
   for item in camLst: VVJ4QS.append(item)
  else:
   for item in camLst: VVJ4QS.append((item[0], ))
  FFVOCw(self, VVJ4QS=VVJ4QS)
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FFAoMS(self["myMenu"])
  FFJdIh(self)
 def VVfFPM(self):
  global VVnWCp
  VVnWCp = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCPvA9, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCPvA9, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCPvA9, "cccam"))
   elif item == "VVfA2x" : self.VVfA2x()
   elif item == "OSCamReaders"  : self.VVVLrX("os")
   elif item == "NSCamReaders"  : self.VVVLrX("n")
   elif item == "camInfo"   : FFtE6f(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CCUpIE.VVSjBA(self.session, CCLvia.VVWC9J)
   elif item == "camLiveReaders" : CCUpIE.VVSjBA(self.session, CCLvia.VVrzMN)
   elif item == "camLiveLog"  : CCUpIE.VVSjBA(self.session, CCLvia.VVKH6G)
   else       : self.close()
 def VVfA2x(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVL4Xa, FFSZ6D())
  if fileExists(path):
   lines = FFup4P("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VVzg89 = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VVzg89("label"    , "CCcam-Line-%d" % ndx))
      f.write(VVzg89("description"  , "CCcam-Line-%d" % ndx))
      f.write(VVzg89("protocol"   , "cccam"))
      f.write(VVzg89("device"    , "%s,%s" % (host, port)))
      f.write(VVzg89("user"    , User))
      f.write(VVzg89("password"   , Pass))
      f.write(VVzg89("fallback"   , "1"))
      f.write(VVzg89("group"    , "64"))
      f.write(VVzg89("cccversion"   , "2.3.2"))
      f.write(VVzg89("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FF8O6K(self, "Output = %d Reader%s in:\n\n%s" % (tot, FFIMVJ(tot), outFile))
   else:
    FFHbVj(self, "No valid CCcam lines", 1500)
  else:
   FFHbVj(self, "%s not found" % path, 1500)
 def VVVLrX(self, camPrefix):
  VVjhh4 = self.VVpLkk(camPrefix)
  if VVjhh4:
   VVjhh4.sort(key=lambda x: int(x[0]))
   if self.VVNkR0 and self.VVNkR0.startswith(camPrefix):
    VV7wPX = ("Toggle State", self.VVWCK3, [camPrefix], "Changing State ...")
   else:
    VV7wPX = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVavJp  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFA1pv(self, None, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VV7wPX=VV7wPX, VVFvoI=True)
 def VVpLkk(self, camPrefix):
  readersFile = self.VVKste + camPrefix + "cam.server"
  VVjhh4 = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFup4P(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVjhh4.append((str(len(VVjhh4) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVjhh4:
    FFfYN0(self, "No readers found !")
  else:
   FF6vdZ(self, readersFile)
  return VVjhh4
 def VVWCK3(self, VVToDv, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVKste, camPrefix)
  readerState  = VVToDv.VVzQU4(1)
  readerLabel  = VVToDv.VVzQU4(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCUpIE.VVypKE(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVToDv.VVDGPS()
    FFfYN0(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVjhh4 = self.VVpLkk(camPrefix)
   if VVjhh4:
    VVToDv.VV3ih0(VVjhh4)
  else:
   VVToDv.VVDGPS()
 @staticmethod
 def VVypKE(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFup4P(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFfYN0(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFfYN0(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FF6vdZ(SELF, confFile)
   return None
  if not iRequest:
   FFfYN0(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CCUpIE.VVAr4S(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FFfYN0(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VVAr4S(SELF):
  if iElem:
   return True
  else:
   FFfYN0(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVSjBA(session, VVHjcz):
  VVKste, VVNkR0, VVQQN7, camCommand = CCUpIE.VVeaHh()
  if VVNkR0:
   runLog = False
   if   VVHjcz == CCLvia.VVWC9J : runLog = True
   elif VVHjcz == CCLvia.VVrzMN : runLog = True
   elif not VVQQN7          : FFgF4z(session, message="SoftCam not started yet!")
   elif fileExists(VVQQN7)        : runLog = True
   else             : FFgF4z(session, message="File not found !\n\n%s" % VVQQN7)
   if runLog:
    session.open(BF(CCLvia, VVKste=VVKste, VVNkR0=VVNkR0, VVQQN7=VVQQN7, VVHjcz=VVHjcz))
  else:
   FFgF4z(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VVeaHh():
  VVKste = "/etc/tuxbox/config/"
  VVNkR0 = None
  VVQQN7  = None
  camCommand = FFIgoM("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VVNkR0 = "oscam"
   elif camCmd.startswith("ncam") : VVNkR0 = "ncam"
  if VVNkR0:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFZF5l(path), IGNORECASE)
     if span:
      VVKste = FFegwS(span.group(1))
      break
   else:
    path = FFIgoM(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FFegwS(path)
    if pathExists(path):
     VVKste = path
   tFile = FFegwS(VVKste) + VVNkR0 + ".conf"
   tFile = FFIgoM("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVQQN7 = tFile
  return VVKste, VVNkR0, VVQQN7, camCommand
class CCPvA9(Screen):
 def __init__(self, VVp9sV, session, args=0):
  self.skin, self.skinParam = FFNQkv(VVLAKc, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVKste, VVNkR0, VVQQN7, camCommand = CCUpIE.VVeaHh()
  if   VVp9sV == "ncam" : self.prefix = "n"
  elif VVp9sV == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVJ4QS = []
  if self.prefix == "":
   VVJ4QS.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVJ4QS.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVJ4QS.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVJ4QS.append(("constant.cw"         , "x_constant_cw" ))
   VVJ4QS.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVJ4QS.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVJ4QS.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVJ4QS.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVJ4QS.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVJ4QS.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVJ4QS.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVJ4QS.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVJ4QS.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVJ4QS.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVJ4QS.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFVOCw(self, VVJ4QS=VVJ4QS)
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FFAoMS(self["myMenu"])
  FFJdIh(self)
 def VVfFPM(self):
  global VVnWCp
  VVnWCp = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFFebl(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFFebl(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFFebl(self, self.VVKste + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFFebl(self, self.VVKste + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVbTGB("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVbTGB("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVbTGB("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVbTGB("cam.provid"        )
   elif item == "x_cam_server"  : self.VVbTGB("cam.server"        )
   elif item == "x_cam_services" : self.VVbTGB("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVbTGB("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVbTGB("cam.user"        )
   elif item == "x_VVU8ll"   : pass
   elif item == "x_SoftCam_Key" : self.VVRnu0()
   elif item == "x_CCcam_cfg"  : FFFebl(self, self.VVKste + "CCcam.cfg"    )
   elif item == "x_VVU8ll"   : pass
   elif item == "x_cam_log"  : FFFebl(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFFebl(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFFebl(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVbTGB(self, fileName):
  FFFebl(self, self.VVKste + self.prefix + fileName)
 def VVRnu0(self):
  path = self.VVKste + "SoftCam.Key"
  if fileExists(path) : FFFebl(self, path)
  else    : FFFebl(self, path.replace(".Key", ".key"))
class CCLvia(Screen):
 VVWC9J  = 0
 VVrzMN = 1
 VVKH6G = 2
 def __init__(self, session, VVKste="", VVNkR0="", VVQQN7="", VVHjcz=VVWC9J):
  self.skin, self.skinParam = FFNQkv(VVpCD5, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVQQN7   = VVQQN7
  self.VVHjcz  = VVHjcz
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVKste + VVNkR0 + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVNkR0 : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVKste, self.camPrefix)
  if self.VVHjcz == self.VVWC9J:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVHjcz == self.VVrzMN:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFVOCw(self, self.Title, addScrollLabel=True)
  FFdufS(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VV8Zhe
  self.onShown.append(self.VV47vn)
  self.onClose.append(self.onExit)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  self["myLabel"].VVYtUm(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFeAg3(self)
  self.VV8Zhe()
 def onExit(self):
  self.timer.stop()
 def VVnjYd(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVmqnU)
  except:
   self.timer.callback.append(self.VVmqnU)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFHbVj(self, "Started", 1000)
 def VVA3Yy(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVmqnU)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFHbVj(self, "Stopped", 1000)
 def VV8Zhe(self):
  if self.timerRunning:
   self.VVA3Yy()
  else:
   self.VVnjYd()
   if self.VVHjcz == self.VVWC9J or self.VVHjcz == self.VVrzMN:
    if self.VVHjcz == self.VVWC9J : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCUpIE.VVypKE(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFS6vB(self.VVa6YI)
    else:
     self.close()
   else:
    self.VVf3iH()
 def VVmqnU(self):
  if self.timerRunning:
   if   self.VVHjcz == self.VVWC9J : self.VV8kC7()
   elif self.VVHjcz == self.VVrzMN : self.VV8kC7()
   else            : self.VVf3iH()
 def VVf3iH(self):
  if fileExists(self.VVQQN7):
   fTime = FF4ENQ(os.path.getmtime(self.VVQQN7))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVdyh7(), VVbIg5=VV08OK)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVQQN7)
 def VVa6YI(self):
  self.VV8kC7()
 def VV8kC7(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFrGgO("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVFBP5))
   self.camWebIfErrorFound = True
   self.VVA3Yy()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVHjcz == self.VVWC9J : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFrGgO("Error while parsing data elements !\n\nError = %s" % str(e), VVwmjQ)
   self.camWebIfErrorFound = True
   self.VVA3Yy()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVwmAF(root)
  self["myLabel"].setText(txt, VVbIg5=VV08OK)
  self["myBar"].setText("Last Update : %s" % FFkTm6())
 def VVwmAF(self, rootElement):
  def VVzg89(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVHjcz == self.VVWC9J:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFrGgO(status, VVqQXm)
    else          : status = FFrGgO(status, VVwmjQ)
    txt += VVU8ll + "\n"
    txt += VVzg89("Name"  , name)
    txt += VVzg89("Description" , desc)
    txt += VVzg89("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVzg89("Protocol" , protocol)
    txt += VVzg89("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFrGgO("Yes", VVqQXm)
    else    : enabTxt = FFrGgO("No", VVwmjQ)
    txt += VVU8ll + "\n"
    txt += VVzg89("Label"  , label)
    txt += VVzg89("Protocol" , protocol)
    txt += VVzg89("Enabled" , enabTxt)
  return txt
 def VVdyh7(self):
  lines = FFz7l2("tail -n %d %s" % (100, self.VVQQN7))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VV61Yf + line[:19] + VVyLoh + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVx4sJ + "WebIf" + VVyLoh)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VVE6YJ + h1 + h2 + VVyLoh + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VVqQXm + span.group(2) + VVtSeQ + span.group(3) + VVyLoh + span.group(4)
    line = self.VVzHOm(line, VVtSeQ, ("(webif)", ))
    line = self.VVzHOm(line, VVtSeQ, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VVzHOm(line, VVqQXm, ("OSCam", "NCam", "log switched"))
    line = self.VVzHOm(line, VVPUgM, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVy0iZ + line[ndx + 3:] + VVyLoh
   elif line.startswith("----") or ">>" in line:
    line = FFrGgO(line, VVCLGj)
   txt += line + "\n"
  return txt
 def VVzHOm(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVyLoh + t3
  return line
class CCHP0M(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFNQkv(VVLAKc, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVJ4QS = []
  VVJ4QS.append(("Backup Channels"    , "VVc4nL"   ))
  VVJ4QS.append(("Restore Channels"    , "Restore_Channels"  ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Backup SoftCAM Files"   , "VVwCRH" ))
  VVJ4QS.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVJ4QS.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVJ4QS.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Backup Network Settings"  , "VVOuns"   ))
  VVJ4QS.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VV5uVo:
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append((VVFBP5 + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VVGMms"   ))
   VVJ4QS.append((VVqQXm + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVEpF4) , "createMyIpk"   ))
   VVJ4QS.append((VVqQXm + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVEpF4) , "createMyDeb"   ))
   VVJ4QS.append((VVE6YJ + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVJ4QS.append((VVE6YJ + "Decode %s Crash Report"   % PLUGIN_NAME     , "VV44YC" ))
  FFVOCw(self, VVJ4QS=VVJ4QS)
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FFAoMS(self["myMenu"])
  FFJdIh(self)
 def VVfFPM(self):
  global VVnWCp
  VVnWCp = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVc4nL"    : self.VVc4nL()
   elif item == "Restore_Channels"    : self.VVYdhy("channels_backup*.tar.gz", self.VV9LOS, isChan=True)
   elif item == "VVwCRH"   : self.VVwCRH()
   elif item == "Restore_SoftCAM_Files"  : self.VVYdhy("softcam_backup*.tar.gz", self.VVgDES)
   elif item == "Backup_TunerDiSEqC"   : self.VVRJGx("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVYdhy("tuner_backup*.backup", BF(self.VVFrb2, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVRJGx("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVYdhy("hotkey_*backup*.backup", BF(self.VVFrb2, "misc"))
   elif item == "VVOuns"    : self.VVOuns()
   elif item == "Restore_Network"    : self.VVYdhy("network_backup*.tar.gz", self.VVopRR)
   elif item == "VVGMms"     : FFZw7B(self, BF(FFlaBE, self, BF(CCHP0M.VVGMms, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVtRU7(False)
   elif item == "createMyDeb"     : self.VVtRU7(True)
   elif item == "createMyTar"     : self.VVnYeC()
   elif item == "VV44YC"   : self.VV44YC()
 @staticmethod
 def VVGMms(SELF):
  OBF_Path = VV2qoQ + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VV2qoQ, VVHz5F, VVEpF4)
   if err : FFfYN0(SELF, err)
   else : FFCxQN(SELF, txt)
  else:
   FF6vdZ(SELF, OBF_Path)
 def VVtRU7(self, VVZWSD):
  OBF_Path = VV2qoQ + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFfYN0(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VV2qoQ)
  os.system("mv -f %s %s" % (VV2qoQ + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VV2qoQ + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VV2qoQ + "plugin.py"))
  self.session.openWithCallback(self.VV6zS2, BF(CCcPEE, path=VV2qoQ, VVZWSD=VVZWSD))
 def VV6zS2(self):
  os.system("mv -f %s %s" % (VV2qoQ + "OBF/main.py"  , VV2qoQ))
  os.system("mv -f %s %s" % (VV2qoQ + "OBF/plugin.py" , VV2qoQ))
 def VV44YC(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFfYN0(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFfYN0(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVKgpx("%s*.list" % path)
  if err:
   FF6vdZ(self, path + "*.list")
   return
  srcF, err = self.VVKgpx("%s*main_final.py" % path)
  if err:
   FF6vdZ(self, path + "*.final.py")
   return
  VVITUl = []
  for f in files:
   f = os.path.basename(f)
   VVITUl.append((f, f))
  FFZP3S(self, BF(self.VVZ4lV, path, codF, srcF), VVJ4QS=VVITUl)
 def VVZ4lV(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FF6vdZ(self, logF)
   else     : FFlaBE(self, BF(self.VVCUys, logF, codF, srcF))
 def VVCUys(self, logF, codF, srcF):
  lst  = []
  lines = FFup4P(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFfYN0(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVVgCP(lst, logF, newLogF)
  totSrc  = self.VVVgCP(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFCxQN(self, txt)
 def VVKgpx(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVVgCP(self, lst, f1, f2):
  txt = FFZF5l(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVnYeC(self):
  VVITUl = []
  VVITUl.append("%s%s" % (VV2qoQ, "*.py"))
  VVITUl.append("%s%s" % (VV2qoQ, "*.png"))
  VVITUl.append("%s%s" % (VV2qoQ, "*.xml"))
  VVITUl.append("%s"  % (VVnEh8))
  FFu4wu(self, VVITUl, "%s_%s" % (PLUGIN_NAME, VVHz5F), addTimeStamp=False)
 def VVc4nL(self):
  path1 = VVoDv6
  path2 = "/etc/tuxbox/"
  VVITUl = []
  VVITUl.append("%s%s" % (path1, "*.tv"))
  VVITUl.append("%s%s" % (path1, "*.radio"))
  VVITUl.append("%s%s" % (path1, "*list"))
  VVITUl.append("%s%s" % (path1, "lamedb*"))
  VVITUl.append("%s%s" % (path2, "*.xml"))
  FFu4wu(self, VVITUl, self.VVBh6Y("channels_backup"), addTimeStamp=True)
 def VVwCRH(self):
  VVITUl = []
  VVITUl.append("/etc/tuxbox/config/")
  VVITUl.append("/usr/keys/")
  VVITUl.append("/usr/scam/")
  VVITUl.append("/etc/CCcam.cfg")
  FFu4wu(self, VVITUl, self.VVBh6Y("softcam_backup"), addTimeStamp=True)
 def VVOuns(self):
  VVITUl = []
  VVITUl.append("/etc/hostname")
  VVITUl.append("/etc/default_gw")
  VVITUl.append("/etc/resolv.conf")
  VVITUl.append("/etc/wpa_supplicant*.conf")
  VVITUl.append("/etc/network/interfaces")
  VVITUl.append("%snameserversdns.conf" % VVoDv6)
  FFu4wu(self, VVITUl, self.VVBh6Y("network_backup"), addTimeStamp=True)
 def VVBh6Y(self, fName):
  img = CC7LVQ.VVZq40()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VV9LOS(self, fileName=None):
  if fileName:
   FFZw7B(self, BF(FFlaBE, self, BF(self.VV8Z3U, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VV8Z3U(self, fileName):
  path = "%s%s" % (VVL4Xa, fileName)
  if fileExists(path):
   if CCqXgM.VV7Sv5(path):
    VVv3dm , VVzOT4 = CCpE07.VVNijv()
    VVUTFl, VVGHU5 = CCpE07.VVJ555()
    cmd  = FFyto6("cd %s" % VVoDv6) + ";"
    cmd += FFyto6("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VVzOT4, VVGHU5))+ ";"
    cmd += "tar -xzf '%s' -C /" % path
    res = os.system(cmd)
    FFpUU8()
    if res == 0 : FF8O6K(self, "Channels Restored.")
    else  : FFfYN0(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FFfYN0(self, "Invalid tar file:\n\n%s" % path)
  else:
   FF6vdZ(self, path)
 def VVgDES(self, fileName=None):
  if fileName:
   FFZw7B(self, BF(self.VVX2eh, fileName), "Overwrite SoftCAM files ?")
 def VVX2eh(self, fileName):
  fileName = "%s%s" % (VVL4Xa, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVU8ll
   note = "You may need to restart your SoftCAM."
   FFH1sU(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFT6nF(note, VVy0iZ), sep))
  else:
   FF6vdZ(self, fileName)
 def VVopRR(self, fileName=None):
  if fileName:
   FFZw7B(self, BF(self.VVtqbu, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVtqbu(self, fileName):
  fileName = "%s%s" % (VVL4Xa, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFyKCd(self,  cmd)
  else:
   FF6vdZ(self, fileName)
 def VVYdhy(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFyAmw()
  if pathExists(VVL4Xa):
   myFiles = FFQ9JP(VVL4Xa, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVITUl = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVITUl.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VV5lv1 = ("Sat. List", self.VVnj29)
    elif isChan and iTar: VV5lv1 = ("Bouquets Importer", CCCEeD.VVU8zH)
    else    : VV5lv1 = None
    VVU5gS = ("Delete File", self.VVPRLh)
    FFZP3S(self, callBackFunction, title=title, width=1200, VVJ4QS=VVITUl, VV5lv1=VV5lv1, VVU5gS=VVU5gS)
   else:
    FFfYN0(self, "No files found in:\n\n%s" % VVL4Xa, title)
  else:
   FFfYN0(self, "Path not found:\n\n%s" % VVL4Xa, title)
 def VVPRLh(self, VVi8BRObj, path):
  FFZw7B(self, BF(self.VVn1oZ, VVi8BRObj, path), "Delete this file ?\n\n%s" % path)
 def VVn1oZ(self, VVi8BRObj, path):
  path = VVL4Xa + path
  FFM75P(path)
  if fileExists(path) : FFHbVj(VVi8BRObj, "Not deleted", 1000)
  else    : VVi8BRObj.VVZEkP()
 def VVRJGx(self, filePrefix, wordsFilter):
  settingFile = "%ssettings" % VVoDv6
  tCons = CCjjBT()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VVc0E0, filePrefix))
 def VVc0E0(self, filePrefix, result, retval):
  title = FFyAmw()
  if pathExists(VVL4Xa):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFfYN0(self, "Cannot read settings file", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVL4Xa, filePrefix, self.VVBh6Y(""), FFSZ6D())
    try:
     VVITUl = str(result.strip()).split()
     if VVITUl:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVITUl:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVU8ll, FFrGgO(fName, VVy0iZ), VVU8ll)
       FFCxQN(self, txt, title=title, VVbIg5=VV08OK)
      else:
       FFfYN0(self, "File creation failed!", title)
     else:
      FFfYN0(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFyto6("rm %s" % fName))
     FFfYN0(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFyto6("rm %s" % fName))
     FFfYN0(self, "Error while writing file.")
  else:
   FFfYN0(self, "Path not found:\n\n%s" % VVL4Xa, title)
 def VVFrb2(self, mode, path=None):
  if path:
   path = "%s%s" % (VVL4Xa, path)
   if fileExists(path):
    lines = FFup4P(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFZw7B(self, BF(self.VVFRWf, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFTXJH(self, path, title=FFyAmw())
   else:
    FF6vdZ(self, path)
 def VVFRWf(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVe6kp = []
  VVe6kp.append("echo -e 'Reading current settings ...'")
  VVe6kp.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVe6kp.append("echo -e 'Preparing new settings ...'")
  VVe6kp.append(settingsLines)
  VVe6kp.append("echo -e 'Applying new settings ...'")
  VVe6kp.append("mv -f /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFW93x(self, VVe6kp)
 def VVnj29(self, VVi8BRObj, path):
  if not path:
   return
  path = VVL4Xa + path
  if not fileExists(path):
   FF6vdZ(self, path)
   return
  txt = FFZF5l(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FF80S3(item[1]))
   FFCxQN(self, txt, title="Satellites List")
  else:
   FFfYN0(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCCEeD():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VVU8zH(SELF, fName):
  bi = CCCEeD(SELF)
  bi.instance = bi
  bi.VVjvaG(SELF, fName)
 @staticmethod
 def VVyoFy(SELF):
  bi = CCCEeD(SELF)
  bi.instance = bi
  bi.VV37HX()
 def VVjvaG(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVL4Xa + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FFlaBE(waitObg, self.VVpOu3, title="Reading bouquets ...")
  else      : self.VVGJTa(self.filePath)
 def VVF7Fx(self, txt) : FFfYN0(self.SELF, txt, title=self.Title)
 def VVdnur(self, txt)  : FFHbVj(self, txt, 1500)
 def VVGJTa(self, path) : FF6vdZ(self.SELF, path, title=self.Title)
 def VV37HX(self):
  if pathExists(VVL4Xa):
   lst = FFQ9JP(VVL4Xa, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VVhOWh())
   if len(lst) > 0:
    VVJ4QS = []
    for item in lst:
     item = os.path.basename(item)
     txt = FFrGgO(item, VVtSeQ) if item.endswith(".zip") else item
     VVJ4QS.append((txt, item))
    VVJ4QS.sort(key=lambda x: x[1].lower())
    OKBtnFnc = self.VVvB79
    FFZP3S(self.SELF, self.VVFGXx, title=self.Title, width=1200, VVJ4QS=VVJ4QS, OKBtnFnc=OKBtnFnc, VV1Y9q="#22111111", VVMnLe="#22111111")
   else:
    self.VVF7Fx("No valid backup files found in:\n\n%s" % VVL4Xa)
  else:
   self.VVF7Fx("Backup Directory not found:\n\n%s" % VVL4Xa)
 def VVvB79(self, item=None):
  if item:
   menuInstance, txt, fName, ndx = item
   self.VVjvaG(menuInstance, fName)
 def VVFGXx(self, item=None):
  if not item and self.instance:
   del self.instance
 def VVhOWh(self):
  files = FFQ9JP(VVL4Xa, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VVpOu3(self):
  lines, err = CCCEeD.VV6zPg(self.filePath, "bouquets.tv")
  if err:
   self.VVF7Fx(err)
   return
  bTvSortLst  = self.VVAtCK(lines)
  lines, err = CCCEeD.VV6zPg(self.filePath, "bouquets.radio")
  if err:
   self.VVF7Fx(err)
   return
  bRadSortLst = self.VVAtCK(lines)
  VVjhh4 = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VVvAEu(f, mode, len(VVjhh4), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVjhh4.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VVvAEu(f, mode, len(VVjhh4), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VVvAEu(f, mode, len(VVjhh4), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVjhh4.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VVvAEu(f, mode, len(VVjhh4), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVjhh4:
   VVjhh4.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVjhh4): VVjhh4[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVjhh4):
     if key == os.path.basename(row[9]):
      VVjhh4 = VVjhh4[:ndx+1] + lst + VVjhh4[ndx+1:]
      break
   for ndx, item in enumerate(VVjhh4): VVjhh4[ndx][0] = str(ndx + 1)
   VVop6p = "#11000600"
   VVHFFO  = ("Show Services" , self.VVP7rB  , [], "Reading ..." )
   VVbdhP = ("Options"  , self.VVIyp2, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 43   , 7  , 7   , 7  , 7  , 7   , 7   , 8   ,  0.01 )
   VVavJp  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER ,  LEFT )
   FFA1pv(self.SELF, None, title=self.Title, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=24, VVHFFO=VVHFFO, VVbdhP=VVbdhP, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VV1Y9q=VVop6p, VVMnLe=VVop6p, VVop6p=VVop6p, VVZZ2X="#11ffffff", VViLdG="#00004455", VVmDPu="#0a282828")
  else:
   self.VVF7Fx("No valid bouquets in:\n\n%s" % self.filePath)
 def VVAtCK(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VVIyp2(self, VVToDv, title, txt, colList):
  mSel = CC6FeI(self.SELF, VVToDv)
  if VVToDv.VVmDY2:
   totSel = VVToDv.VVFx4F()
   if totSel: VVJ4QS = [("Import %s Bouquet%s" % (FFrGgO(str(totSel), VVqQXm), FFIMVJ(totSel)), "imp")]
   else  : VVJ4QS = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FFrGgO(bName, VVqQXm)
   VVJ4QS = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FFlaBE, VVToDv, BF(CCCEeD.VV3HVz, self.SELF, VVToDv, self.filePath))}
  mSel.VV9EgX(VVJ4QS, cbFncDict)
 def VVP7rB(self, VVToDv, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CCCEeD.VV6zPg(self.filePath, "lamedb")
   if err:
    self.VVF7Fx(err)
    return
   dbServLst = CCpE07.VVLIhj(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totLoc, totMrk, totBnb, fName = VVToDv.VVKPIF()
   lines, err = CCCEeD.VV6zPg(self.filePath, os.path.basename(fName))
   if err:
    self.VVF7Fx(err)
    return
   VVjhh4 = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVjhh4.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVjhh4.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVjhh4.append((span.group(1).strip() or "-", "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVjhh4.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVjhh4.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CCpE07.VVAWJ0(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVjhh4.append((name.strip() or "-", FFQQpf(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVjhh4):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CCCEeD.VV6zPg(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVjhh4[ndx] = (bName, descr)
   if VVjhh4:
    VVop6p = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VVavJp = (LEFT  , CENTER)
    FFA1pv(self.SELF, None, title="Services in : %s" % bName, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=28, VV1Y9q=VVop6p, VVMnLe=VVop6p, VVop6p=VVop6p, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FFHbVj(VVToDv, err, 1500)
  else : VVToDv.VVDGPS()
 def VVvAEu(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VVF7Fx("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VV4wPN(var):
   return str(var) if var else VV4U5y + str(var)
  totItem = VVy0iZ + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VVFBP5   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVtSeQ, "Sub-B."
  else  : bColor, totBnb = ""      , VV4wPN(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VV4wPN(totDVB), VV4wPN(totIptv), VV4wPN(totLoc), VV4wPN(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VV3HVz(SELF, VVToDv, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVoDv6 + "bouquets.tv"
  radBouquetFile = VVoDv6 + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FF6vdZ(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FF6vdZ(SELF, radBouquetFile, title=title)
   return
  isMulti = VVToDv.VVmDY2
  if isMulti : rows = VVToDv.VVspyc()
  else  : rows = [VVToDv.VVKPIF()]
  for num, bName, bMode, totItem, totDVB, totIptv, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FFfYN0(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FFVK2H(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FFVK2H(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVoDv6 + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVoDv6 + newFile
    CCCEeD.VVsI9j(archPath, fName, VVoDv6, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   CC54zE.VV5Ckv(tvBouquetFile)
   CC54zE.VV5Ckv(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CCCEeD.VVOhrh(SELF, archPath, bList)
   FFpUU8()
  txt  = FFrGgO("Added:\n", VVtSeQ)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FFrGgO("Imported to lamedab:\n", VVtSeQ)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FFrGgO("Missing from archived lamedb:\n", VVFBP5)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FFCxQN(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVOhrh(SELF, archPath, bList):
  VVv3dm, err = CCpE07.VVlds4(SELF, VVfXeW=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CCpE07.VVQgxf(VVv3dm, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FFup4P(VVoDv6 + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CCpE07.VVAWJ0(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CCpE07.VVDkFM(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CCCEeD.VVvd2B(archPath, dbName)
   CCCEeD.VVsI9j(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CCpE07.VVQgxf(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CCpE07.VVQgxf(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CCpE07.VVQgxf(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CCpE07.VVQgxf(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFM75P(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VVv3dm + ".tmp"
   lines   = FFup4P(VVv3dm)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   os.system(FFyto6("mv -f '%s' '%s'" % (tmpDbFile, VVv3dm)))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VVbLUD(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VVvd2B(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVsI9j(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VV6zPg(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CC1pHg(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFNQkv(VVLAKc, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVJ4QS = []
  VVJ4QS.append(("Plugins Browser List"       , "VVUEiz"   ))
  VVJ4QS.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVJ4QS.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Download/Install Packages (from image feeds)" , "downloadInstallPackages"  ))
  VVJ4QS.append(("Remove Packages (show all)"     , "VVPLKnsAll"   ))
  VVJ4QS.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Update List of Available Packages"   , "VVneQJ"   ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Packaging Tool"        , "VVrVdP"    ))
  VVJ4QS.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFVOCw(self, VVJ4QS=VVJ4QS)
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FFAoMS(self["myMenu"])
  FFJdIh(self)
 def VVfFPM(self):
  global VVnWCp
  VVnWCp = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVUEiz"   : self.VVUEiz()
   elif item == "pluginsMenus"     : self.VVytKU(0)
   elif item == "pluginsStartup"    : self.VVytKU(1)
   elif item == "pluginsDirList"    : self.VVmQIV()
   elif item == "downloadInstallPackages"  : FFlaBE(self, BF(self.VVx8r7, 0, ""))
   elif item == "VVPLKnsAll"   : FFlaBE(self, BF(self.VVx8r7, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFlaBE(self, BF(self.VVx8r7, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVneQJ"   : self.VVneQJ()
   elif item == "VVrVdP"    : self.VVrVdP()
   elif item == "packagesFeeds"    : self.VV0grJ()
   else          : self.close()
 def VVmQIV(self):
  extDirs  = FFKPga(VVEK1s)
  sysDirs  = FFKPga(VVTdNX)
  VVITUl  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVITUl.append((item, VVEK1s + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVITUl.append((item, VVTdNX + item))
  if VVITUl:
   VVITUl.sort(key=lambda x: x[0].lower())
   VVbdhP = ("Package Info.", self.VVq2s8, [])
   VVUB3Q = ("Open in File Manager", BF(self.VVJRs0, 1), [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFA1pv(self, None, header=header, VVITUl=VVITUl, VV7ux5=widths, VVy2kz=28, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q)
  else:
   FFfYN0(self, "Nothing found!")
 def VVq2s8(self, VVToDv, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVEK1s) : loc = "extensions"
  elif path.startswith(VVTdNX) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVFPvz(package)
  else:
   FFfYN0(self, "No info!")
 def VV0grJ(self):
  pkg = FFHJyu()
  if pkg : FFJWo9(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FF1KkZ(self)
 def VVUEiz(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVzg89(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVU8ll + "\n"
    txt += VVzg89("Number"   , str(c))
    txt += VVzg89("Name"   , FFrGgO(str(p.name), VVy0iZ))
    txt += VVzg89("Path"  , p.path  )
    txt += VVzg89("Description" , p.description )
    txt += VVzg89("Icon"  , p.iconstr  )
    txt += VVzg89("Wakeup Fnc" , p.wakeupfnc )
    txt += VVzg89("NeedsRestart", p.needsRestart)
    txt += VVzg89("Internal" , p.internal )
    txt += VVzg89("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFCxQN(self, txt)
 def VVytKU(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVITUl = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVITUl.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVITUl:
   VVITUl.sort(key=lambda x: x[0].lower())
   VVUB3Q = ("Open in File Manager", BF(self.VVJRs0, 4), [])
   header   = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths   = (19  , 25 , 20  , 27   , 9  )
   FFA1pv(self, None, title=title, header=header, VVITUl=VVITUl, VV7ux5=widths, VVy2kz=26, VVUB3Q=VVUB3Q)
  else:
   FFfYN0(self, "Nothing Found", title=title)
 def VVJRs0(self, pathColNum, VVToDv, title, txt, colList):
  path = colList[pathColNum].strip()
  if pathExists(path) : self.session.open(CCqXgM, mode=CCqXgM.VVvbEJ, VVjq2g=path)
  else    : FFHbVj(VVToDv, "Path not found !", 1500)
 def VVneQJ(self):
  cmd = FFFOwQ(VVNauh, "")
  if cmd : FFyKCd(self, cmd, checkNetAccess=True)
  else : FF1KkZ(self)
 def VVrVdP(self):
  pkg = FFHJyu()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FF8O6K(self, txt)
 def VVx8r7(self, mode, grep, VVToDv=None, title=""):
  if   mode == 0: cmd = FFFOwQ(VV3ITS    , grep)
  elif mode == 1: cmd = FFFOwQ(VV6nhb , grep)
  elif mode == 2: cmd = FFFOwQ(VV6nhb , grep)
  if not cmd:
   FF1KkZ(self)
   return
  VVjhh4 = FFz7l2(cmd)
  if not VVjhh4:
   if VVToDv: VVToDv.VVDGPS()
   FFfYN0(self, "No packages found!")
   return
  elif len(VVjhh4) == 1 and VVjhh4[0] == VVTzA8:
   FFfYN0(self, VVTzA8)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVITUl  = []
  for item in VVjhh4:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVITUl.append((name, package, version))
  if mode > 0:
   extensions = FFz7l2("ls %s -l | grep '^d' | awk '{print $9}'" % VVEK1s)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVITUl:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVITUl.append((name, VVEK1s + item, "-"))
   systemPlugins = FFz7l2("ls %s -l | grep '^d' | awk '{print $9}'" % VVTdNX)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVITUl:
      if item.lower() == row[0].lower():
       break
     else:
      VVITUl.append((item, VVTdNX + item, "-"))
  if not VVITUl:
   FFfYN0(self, "No packages found!")
   return
  if VVToDv:
   VVITUl.sort(key=lambda x: x[0].lower())
   VVToDv.VV3ih0(VVITUl, title)
  else:
   widths = (20, 50, 30)
   VV7wPX = None
   VVUB3Q = None
   if mode == 0:
    VVcjza = ("Install" , self.VVHImv   , [])
    VV7wPX = ("Download" , self.VVAhpu   , [])
    VVUB3Q = ("Filter"  , self.VV7RfF , [])
   elif mode == 1:
    VVcjza = ("Uninstall", self.VVPLKn, [])
   elif mode == 2:
    VVcjza = ("Uninstall", self.VVPLKn, [])
    widths= (18, 57, 25)
   VVITUl.sort(key=lambda x: x[0].lower())
   VVbdhP = ("Package Info.", self.VVBgoI, [])
   header   = ("Name" ,"Package" , "Version" )
   FFA1pv(self, None, header=header, VVITUl=VVITUl, VV7ux5=widths, VVy2kz=28, VVcjza=VVcjza, VV7wPX=VV7wPX, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q, VVR6Ea=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VV1Y9q="#22110011", VVMnLe="#22191111", VVop6p="#22191111", VViLdG="#00003030", VVmDPu="#00333333")
 def VVBgoI(self, VVToDv, title, txt, colList):
  package = colList[1]
  self.VVFPvz(package)
 def VV7RfF(self, VVToDv, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVJ4QS = []
  VVJ4QS.append(("All Packages", "all"))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVJ4QS.append(VV4c5n)
  for word in words:
   VVJ4QS.append((word, word))
  FFZP3S(self, BF(self.VVcAeu, VVToDv), VVJ4QS=VVJ4QS, title="Select Filter")
 def VVcAeu(self, VVToDv, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFlaBE(VVToDv, BF(self.VVx8r7, 0, grep, VVToDv, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVPLKn(self, VVToDv, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVEK1s, VVTdNX)):
   FFZw7B(self, BF(self.VVZhx9, VVToDv, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVJ4QS = []
   VVJ4QS.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVJ4QS.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVJ4QS.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFZP3S(self, BF(self.VVlBJW, VVToDv, package), VVJ4QS=VVJ4QS)
 def VVZhx9(self, VVToDv, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVU0Ra)
  FFyKCd(self, cmd, VV5en0=BF(self.VVmc0l, VVToDv))
 def VVlBJW(self, VVToDv, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVnArD
   elif item == "remove_ForceRemove"  : cmdOpt = VVunnv
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVmQkd
   FFZw7B(self, BF(self.VVXFGy, VVToDv, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVXFGy(self, VVToDv, package, cmdOpt):
  self.lastSelectedRow = VVToDv.VVYt3A()
  cmd = FFMotr(cmdOpt, package)
  if cmd : FFyKCd(self, cmd, VV5en0=BF(self.VVmc0l, VVToDv))
  else : FF1KkZ(self)
 def VVmc0l(self, VVToDv):
  VVToDv.cancel()
  FFKjU2()
 def VVHImv(self, VVToDv, title, txt, colList):
  package  = colList[1]
  VVJ4QS = []
  VVJ4QS.append(("Install Package"         , "install_CheckVersion" ))
  VVJ4QS.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVJ4QS.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VVJ4QS.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVJ4QS.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFZP3S(self, BF(self.VVfzHA, package), VVJ4QS=VVJ4QS)
 def VVfzHA(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVi1jL
   elif item == "install_ForceReinstall" : cmdOpt = VVgRg8
   elif item == "install_ForceOverwrite" : cmdOpt = VVwcQY
   elif item == "install_ForceDowngrade" : cmdOpt = VVujU7
   elif item == "install_IgnoreDepends" : cmdOpt = VVFaXR
   FFZw7B(self, BF(self.VVrqKw, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVrqKw(self, package, cmdOpt):
  cmd = FFMotr(cmdOpt, package)
  if cmd : FFyKCd(self, cmd, VV5en0=FFKjU2, checkNetAccess=True)
  else : FF1KkZ(self)
 def VVAhpu(self, VVToDv, title, txt, colList):
  package  = colList[1]
  FFZw7B(self, BF(self.VVraWG, package), "Download Package ?\n\n%s" % package)
 def VVraWG(self, package):
  if FFHkZ8():
   cmd = FFMotr(VVPceO, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFT6nF(success, VVqQXm))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFT6nF(fail, VVwmjQ))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFyKCd(self, cmd, VVzShN=[VVwmjQ, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FF1KkZ(self)
  else:
   FFfYN0(self, "No internet connection !")
 def VVFPvz(self, package):
  infoCmd  = FFMotr(VVlKhU, package)
  filesCmd = FFMotr(VV1iyq, package)
  listInstCmd = FFFOwQ(VV6nhb, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFGsQg(VVy0iZ)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFT6nF(notInst, VVFBP5))
   cmd += "else "
   cmd +=   FFAR3g("System Info", VVy0iZ)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFAR3g("Related Files", VVy0iZ)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFy4dI(self, cmd)
  else:
   FF1KkZ(self)
class CCWiTw():
 def VVBrCr(self, isRef):
  self.shareIsRef   = isRef
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VVFxLZ()
 def VVFxLZ(self):
  files = FFQ9JP(VVL4Xa, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVJ4QS = []
   for fil in files:
    VVJ4QS.append((os.path.basename(fil), fil))
   if self.shareIsRef : VV1Y9q, VVMnLe = "#22221133", "#22221133"
   else    : VV1Y9q, VVMnLe = "#22003344", "#22002233"
   VV5lv1  = ("Add new File", self.VVOelk)
   VVU5gS = ("Delete File", self.VVbTkS)
   FFZP3S(self, self.VVxHi9, VVJ4QS=VVJ4QS, width=1100, VV5lv1=VV5lv1, VVU5gS=VVU5gS, minRows=4, VV1Y9q=VV1Y9q, VVMnLe=VVMnLe)
  else:
   FFZw7B(self, self.VV0i1P, "No files found.\n\nCreate a new file ?")
 def VV0i1P(self):
  path = self.VVtxZs()
  if fileExists(path) : self.VVFxLZ()
  else    : FFHbVj(self, "Cannot create file", 1500)
 def VVOelk(self, menuInstance, path):
  path = self.VVtxZs()
  menuInstance.VVpwZ4((os.path.basename(path), path), isSort=True)
 def VVtxZs(self):
  path = "%s%s%s.xml" % (VVL4Xa, self.shareFilePrefix, FFSZ6D())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VVbTkS(self, menuInstance, path):
  FFZw7B(self, BF(self.VVSZYU, menuInstance, path), "Delete this file ?\n\n%s" % path)
 def VVSZYU(self, menuInstance, path):
  FFM75P(path)
  if fileExists(path) : FFHbVj(menuInstance, "Not deleted", 1000)
  else    : menuInstance.VVZEkP()
 def VVxHi9(self, path=None):
  if path:
   FFlaBE(self, BF(self.VVRIOk, path))
 def VVRIOk(self, path):
  if not fileExists(path):
   FF6vdZ(self, path)
   return
  elif not CCqXgM.VV7Hvo(self, path, FFyAmw()):
   return
  else:
   self.shareFilePath = path
  if not CCUpIE.VVAr4S(self):
   return
  tree = CCpE07.VVlO5S(self, self.shareFilePath)
  if not tree:
   return
  refLst = CC54zE.VVSqHV()
  def VVzg89(refCode):
   if   FFB5r2(refCode): return FFrGgO("DVB", VV6svy)
   elif refCode in refLst     : return FFrGgO("IPTV", VV6svy)
   else         : return ""
  VVjhh4= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VVYUcA(ch)
   if ok:
    srcTxt = VVzg89(srcRef)
    dstTxt = VVzg89(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVjhh4:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVjhh4.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVjhh4:
   if self.shareIsRef : VV1Y9q, VVMnLe, optTxt = "#22221133", "#22221133", "Share Reference"
   else    : VV1Y9q, VVMnLe, optTxt = "#1a003344", "#1a002233", "Copy EPG/PIcons"
   VVcwgo = (""    , BF(self.VV0Wg4, dupl), [])
   VVXuip = (""    , self.VVnvMF    , [])
   VVcjza = ("Delete Entry" , self.VV9xU1   , [])
   VV7wPX = ("Add Entry"  , self.VV9zZg   , [])
   VVbdhP = (optTxt   , self.VVvFIB  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VVavJp = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVToDv = FFA1pv(self, None, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=24, VVcwgo=VVcwgo, VVXuip=VVXuip, VVcjza=VVcjza, VV7wPX=VV7wPX, VVbdhP=VVbdhP, VVFvoI=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VV1Y9q=VV1Y9q, VVMnLe=VVMnLe, VVop6p=VVMnLe, VVZZ2X="#00ffffaa", VViLdG="#0a000000")
  else:
   FFfYN0(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VV0Wg4(self, dupl, VVToDv, title, txt, colList):
  if dupl:
   VVToDv.VVB7wY("Skipped %d duplicate%s" % (dupl, FFIMVJ(dupl)), 2000)
 def VVnvMF(self, VVToDv, title, txt, colList):
  def VVzg89(key, val): return "%s\t: %s\n" % (key, val or FFrGgO("?", VVPUgM))
  Keys = VVToDv.VVo26g()
  Vals = VVToDv.VVKPIF()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VVzg89(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VVqQXm, VVPUgM
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FFCxQN(self, txt + txt1, title=title)
 def VVYUcA(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VV9xU1(self, VVToDv, title, txt, colList):
  if VVToDv.VVYt3A() == 0 and VVToDv.VVLfEh() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FFZw7B(self, BF(self.VVNOI3, isLast, VVToDv), ques)
 def VVNOI3(self, isLast, VVToDv):
  if isLast:
   FFM75P(self.shareFilePath)
   VVToDv.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVToDv.VVKPIF()
   if self.VVO9y7(srcName, srcRef, dstName, dstRef):
    VVToDv.VVemQb()
    VVToDv.VVDX4N()
    FFHbVj(VVToDv, "Deleted", 500, isGrn=True)
   else:
    FFHbVj(VVToDv, "Cannot delete from file", 2000)
 def VV9zZg(self, VVToDv, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VVHrNB(VVToDv, isDvb=True)
  else    : self.VVs7gX(VVToDv, "Source Channel", "#22003344", "#22002233")
 def VVs7gX(self, mainTableInst, title, VV1Y9q, VVMnLe):
  FFZP3S(self, BF(self.VV6L14, mainTableInst, title), VVJ4QS=[("DVB", "DVB"), ("IPTV", "IPTV")], title=title + " Type", width=800, VV1Y9q=VV1Y9q, VVMnLe=VVMnLe)
 def VV6L14(self, mainTableInst, title, item=None):
  if item:
   FFlaBE(mainTableInst, BF(self.VVhRRT, mainTableInst, title, item), clearMsg=False)
 def VVhRRT(self, mainTableInst, title, item):
  FFHbVj(mainTableInst)
  if item == "DVB": self.VVHrNB(mainTableInst, isDvb=True)
  else   : self.VVHrNB(mainTableInst, isDvb=False)
 def VVCEsi(self, mainTableInst, chType, VVToDv, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVToDv.VVYt3A()
  if   chType == "DVB" : FFu7KK(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FFu7KK(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVF8iU()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FFfYN0(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VVpolK(srcName, srcRef, dstName, dstRef):
      mainTableInst.VVEwnc((str(mainTableInst.VVLfEh() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FFHbVj(mainTableInst, "Added", 500, isGrn=True)
     else:
      FFHbVj(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FFHbVj(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VVHrNB(mainTableInst, isDvb=False)
   else    : FFS6vB(BF(self.VVs7gX, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVToDv.cancel()
 def VV7M1k(self, item, VVToDv, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVToDv.VVeb2k(ndx)
 def VVHrNB(self, VVToDv, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VVCEsi, VVToDv, typ)
  doneFnc = BF(self.VV7M1k, typ)
  if isDvb: CCWiTw.VVvEI6(VVToDv , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CCWiTw.VVfles(VVToDv, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VVvEI6(SELF, title, okFnc, doneFnc=None):
  FFlaBE(SELF, BF(CCWiTw.VVXzu0, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVXzu0(SELF, title, okFnc, doneFnc=None):
  VVjhh4, err = CCpE07.VV5WFr(SELF, CCpE07.VVI1kI)
  if VVjhh4:
   color = "#0a000022"
   VVjhh4.sort(key=lambda x: x[0].lower())
   VVHFFO = ("Select" , okFnc, [])
   VVcwgo= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VVavJp = (LEFT  , LEFT  , CENTER, LEFT    )
   FFA1pv(SELF, None, title=title, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VV1Y9q=color, VVMnLe=color, VVop6p=color, VVHFFO=VVHFFO, VVcwgo=VVcwgo, lastFindConfigObj=CFG.lastFindServices)
  else:
   FFfYN0(SELF, "No DVB Services !")
 @staticmethod
 def VVfles(SELF, title, okFnc, doneFnc=None):
  FFlaBE(SELF, BF(CCWiTw.VVDajP, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VVDajP(SELF, title, okFnc, doneFnc=None):
  VVjhh4 = CCWiTw.VVc3J1()
  if VVjhh4:
   color = "#0a112211"
   VVjhh4.sort(key=lambda x: x[0].lower())
   VVHFFO = ("Select" , okFnc, [])
   VVcwgo= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FFA1pv(SELF, None, title=title, header=header, VVITUl=VVjhh4, VV7ux5=widths, VVy2kz=26, VV1Y9q=color, VVMnLe=color, VVop6p=color, VVHFFO=VVHFFO, VVcwgo=VVcwgo, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFfYN0(SELF, "No IPTV Services !")
 @staticmethod
 def VVc3J1():
  VVjhh4 = []
  files  = CCCwQV.VVplgE()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFZF5l(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVBAfT = span.group(1)
    else : VVBAfT = ""
    VVBAfT_lCase = VVBAfT.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVjhh4.append((chName, VVBAfT, url, refCode))
  return VVjhh4
 def VVpolK(self, srcName, srcRef, dstName, dstRef):
  tree = CCpE07.VVlO5S(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VVD36Z(tree, root)
  return True
 def VVO9y7(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CCpE07.VVlO5S(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VVYUcA(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VVD36Z(tree, root)
  return found
 def VVD36Z(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CCpE07.VVWcnJ(xmlTxt)
  parser = CCpE07.CCrGwU()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VVvFIB(self, VVToDv, title, txt, colList):
  VVJ4QS = []
  if self.shareIsRef:
   FFZw7B(self, BF(FFlaBE, VVToDv, BF(self.VVkqWo, VVToDv)), "Copy all References from Source to Destination ?")
  else:
   VVJ4QS.append(("Copy EPG\t (All List)" , "epg"  ))
   VVJ4QS.append(("Copy Picons\t (All List)" , "picon" ))
   FFZP3S(self, BF(self.VVgrr6, VVToDv), VVJ4QS=VVJ4QS, width=1000)
 def VVgrr6(self, VVToDv, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VVuX2W  , "EPG"
   elif item == "picon": fnc, txt = self.VVfv1k , "PIcons"
   title = "Copy %s" % txt
   tot   = VVToDv.VVLfEh()
   FFZw7B(self, BF(FFlaBE, VVToDv, BF(fnc, VVToDv, title)), "Overwrite %s for %d Service%s ?" % (FFrGgO(txt, VVy0iZ), tot, FFIMVJ(tot)), title=title)
 def VVkqWo(self, VVToDv):
  files = CCCwQV.VVplgE()
  totChange = 0
  if files:
   for path in files:
    txt = FFZF5l(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVToDv.VVF8iU():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFpUU8()
  tot = VVToDv.VVLfEh()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FFCxQN(self, txt)
 def VVfv1k(self, VVToDv, title):
  if not iCopyfile:
   FFfYN0(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CC8ahC.VVmFFX()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVToDv.VVF8iU():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVToDv.VVLfEh()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FFCxQN(self, txt, title=title)
 def VVuX2W(self, VVToDv, title):
  from enigma import eEPGCache
  totFound = totEvents = totSuccess = totInvalid = 0
  epgInst = eEPGCache.getInstance()
  if not epgInst:
   FFfYN0(self, "Cannot access EPG Cache !", title=title)
   return
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVToDv.VVF8iU():
   if remark == "0":
    evList = epgInst.lookupEvent(["BDTSE", (srcRef, 0, -1, 20160)])
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CCy52I.VVM43F(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CCWiTw.VVtPAt()
  txt  = "Services\t: %d\n"  % VVToDv.VVLfEh()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  FFCxQN(self, txt, title=title)
 class CCrGwU(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VVlO5S(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CCpE07.CCrGwU())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FFrGgO("XML Parse Error in:", VVPUgM), path)
   txt += "%s\n%s\n\n" % (FFrGgO("Error:", VVPUgM), str(e))
   FFCxQN(SELF, txt, VVop6p="#11220000", title=title)
   return None
 @staticmethod
 def VVWcnJ(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
 @staticmethod
 def VVtPAt():
  try:
   from enigma import eEPGCache
   epgInst = eEPGCache.getInstance()
   if epgInst and hasattr(eEPGCache, "save"):
    epgInst.save()
  except:
   pass
class CCpE07(Screen, CCWiTw):
 VVAXy7  = 0
 VVIgvw = 1
 VV8pxp  = 2
 VVHah1  = 3
 VVPSnJ = 4
 VVARox = 5
 VVVgns = 6
 VVI1kI   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FFNQkv(VVLAKc, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VV9wYB = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVJ4QS = self.VV6gQq()
  FFVOCw(self, VVJ4QS=VVJ4QS, title="Services/Channels")
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self["myMenu"].setList(self.VV6gQq())
  FFAoMS(self["myMenu"])
  FFJdIh(self)
 def VV6gQq(self):
  VVJ4QS = []
  c = VV6svy
  VVJ4QS.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVJ4QS.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVJ4QS.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVJ4QS.append(VV4c5n)
  c = VVtSeQ
  VVJ4QS.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVJ4QS.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVJ4QS.append((VVPUgM + "More tables ..."     , "VVqzb2"    ))
  c = VVxpap
  VVJ4QS.append(VV4c5n)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVJ4QS.append((c + txt          , "VVyoFy"  ))
  else : VVJ4QS.append((txt           ,          ))
  VVJ4QS.append((c + 'Export Services to "channels.xml"'    , "VVx7w0"      ))
  VVJ4QS.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VV61Yf
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVJ4QS.append((c + "Invalid Services Cleaner"       , "VVjnVn"    ))
  c = VV61Yf
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append((c + "Delete Channels with no names"     , "VVZo7I"    ))
  VVJ4QS.append((c + "Delete Empty Bouquets"       , "VVdGsB"     ))
  VVJ4QS.append(VV4c5n)
  VVv3dm, VVzOT4 = CCpE07.VVNijv()
  if fileExists(VVv3dm):
   enab = fileExists(VVzOT4)
   if enab: VVJ4QS.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVJ4QS.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVJ4QS.append(("Reset Parental Control Settings"      , "VVFj9u"    ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Reload Channels and Bouquets"       , "VVH6bN"      ))
  return VVJ4QS
 def VVfFPM(self):
  global VVnWCp
  VVnWCp = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCKx3s.VVpa1E(self.session)
   elif item == "openSignal"       : FFieRK(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFzeU3(self, fncMode=CCy52I.VVRoI8)
   elif item == "lameDB_allChannels_with_refCode"  : FFlaBE(self, self.VVDClG)
   elif item == "lameDB_allChannels_with_tranaponder" : FFlaBE(self, self.VVLk0a)
   elif item == "VVqzb2"     : self.VVqzb2()
   elif item == "VVyoFy"  : CCCEeD.VVyoFy(self)
   elif item == "VVx7w0"      : self.VVx7w0()
   elif item == "copyEpgPicons"      : self.VVBrCr(False)
   elif item == "SatellitesCleaner"     : FFlaBE(self, self.FFlaBE_SatellitesCleaner)
   elif item == "VVjnVn"    : FFlaBE(self, BF(self.VVjnVn))
   elif item == "VVZo7I"    : FFlaBE(self, self.VVZo7I)
   elif item == "VVdGsB"     : self.VVdGsB(self)
   elif item == "enableHiddenChannels"     : self.VVLZSN(True)
   elif item == "disableHiddenChannels"    : self.VVLZSN(False)
   elif item == "VVFj9u"    : FFZw7B(self, self.VVFj9u, "Reset and Restart ?")
   elif item == "VVH6bN"      : FFlaBE(self, BF(CCpE07.VVH6bN, self))
 def VVqzb2(self):
  VVJ4QS = []
  VVJ4QS.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVJ4QS.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVJ4QS.append(("Services with PIcons for the System"  , "VVY1PK"     ))
  VVJ4QS.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVJ4QS.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"     ))
  FFZP3S(self, self.VVGH1G, VVJ4QS=VVJ4QS, title="Service Information", VV7GES=True)
 def VVGH1G(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FFlaBE(self, BF(self.VVwSc4, title))
   elif ref == "parentalControlChannels"   : FFlaBE(self, BF(self.VVK1St, title))
   elif ref == "showHiddenChannels"    : FFlaBE(self, BF(self.VVN7oT, title))
   elif ref == "VVY1PK"    : FFlaBE(self, BF(self.VVp6GS, title))
   elif ref == "servicesWithMissingPIcons"   : FFlaBE(self, BF(self.VV1aC3, title))
   elif ref == "TranspondersStats"     : FFlaBE(self, BF(self.VVOVfI, title))
   elif ref == "SatellitesXmlStats"    : FFlaBE(self, BF(self.VVZuOx, title))
 def VVx7w0(self):
  VVJ4QS = []
  VVJ4QS.append(("All DVB-S/C/T Services", "all"))
  VVJ4QS.extend(CC54zE.VVtYge())
  FFZP3S(self, self.VVltJF, VVJ4QS=VVJ4QS, title="", VV7GES=True)
 def VVltJF(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCpE07.VVzHUI("1:7:")
   else   : lst = FF5CZv(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFQQpf(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFCeZx(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FFegwS(CFG.exportedTablesPath.getValue()), FFSZ6D())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FF8O6K(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFHbVj(self, "No Services found !", 1500)
 @staticmethod
 def VVH6bN(SELF):
  FFpUU8()
  FF8O6K(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVDClG(self):
  self.VV9wYB = None
  self.lastfilterUsed  = None
  self.filterObj   = CCMA5J(self)
  VVjhh4, err = CCpE07.VV5WFr(self, self.VVAXy7)
  if VVjhh4:
   VVjhh4.sort(key=lambda x: x[0].lower())
   VVHFFO  = ("Zap"   , self.VVl2Tl     , [])
   VVXuip = (""    , self.VVd3N2   , [])
   VVbdhP = ("Options"  , self.VVSoN9 , [])
   VV7wPX = ("Current Service", self.VV71uf , [])
   VVUB3Q = ("Filter"   , self.VVp6Kb  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVavJp  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFA1pv(self, None, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VVHFFO=VVHFFO, VVXuip=VVXuip, VV7wPX=VV7wPX, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q, lastFindConfigObj=CFG.lastFindServices)
 def VVLk0a(self):
  self.VV9wYB = None
  self.lastfilterUsed  = None
  self.filterObj   = CCMA5J(self)
  VVjhh4, err = CCpE07.VV5WFr(self, self.VVIgvw)
  if VVjhh4:
   VVjhh4.sort(key=lambda x: x[0].lower())
   VVHFFO  = ("Zap"   , self.VVl2Tl      , [])
   VVXuip = (""    , self.VVd3N2    , [])
   VV7wPX = ("Current Service", self.VV71uf  , [])
   VVbdhP = ("Options"  , self.VVDQq4 , [])
   VVUB3Q = ("Filter"   , self.VVBhY0  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVavJp  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFA1pv(self, None, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VVHFFO=VVHFFO, VVXuip=VVXuip, VV7wPX=VV7wPX, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q, lastFindConfigObj=CFG.lastFindServices)
 def VVSoN9(self, VVToDv, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CC6FeI(self, VVToDv)
  VVJ4QS = []
  isMulti = VVToDv.VVmDY2
  if isMulti:
   refCodeList = VVToDv.VVAoir(3)
   if refCodeList:
    VVJ4QS.append(("Add Selection to Parental Control"    , "parentalControl_sel_add"  ))
    VVJ4QS.append(("Remove Selection from Parental Control"   , "parentalControl_sel_remove" ))
    VVJ4QS.append(VV4c5n)
    VVJ4QS.append(("Add Selection to Hidden Services"    , "hiddenServices_sel_add"  ))
    VVJ4QS.append(("Remove Selection from Hidden Services"   , "hiddenServices_sel_remove" ))
    VVJ4QS.append(VV4c5n)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVJ4QS.append((txt1, "parentalControl_add" ))
    VVJ4QS.append((txt2,       ))
   else:
    VVJ4QS.append((txt1,       ))
    VVJ4QS.append((txt2, "parentalControl_remove"))
   VVJ4QS.append(VV4c5n)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVJ4QS.append((txt1, "hiddenServices_add" ))
    VVJ4QS.append((txt2,       ))
   else:
    VVJ4QS.append((txt1,       ))
    VVJ4QS.append((txt2, "hiddenServices_remove" ))
   VVJ4QS.append(VV4c5n)
  cbFncDict = { "parentalControl_add"   : BF(self.VV3Rjz, VVToDv, refCode, True)
     , "parentalControl_remove"  : BF(self.VV3Rjz, VVToDv, refCode, False)
     , "hiddenServices_add"   : BF(self.VV0yyX, VVToDv, refCode, True)
     , "hiddenServices_remove"  : BF(self.VV0yyX, VVToDv, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVPuhU, VVToDv, True)
     , "parentalControl_sel_remove" : BF(self.VVPuhU, VVToDv, False)
     , "hiddenServices_sel_add"  : BF(self.VVgeNf, VVToDv, True)
     , "hiddenServices_sel_remove" : BF(self.VVgeNf, VVToDv, False)
     }
  VVJ4QS1, cbFncDict1 = CCpE07.VVpbzK(self, VVToDv, servName, 3)
  VVJ4QS.extend(VVJ4QS1)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VV9EgX(VVJ4QS, cbFncDict)
 def VVDQq4(self, VVToDv, title, txt, colList):
  servName = colList[0]
  mSel = CC6FeI(self, VVToDv)
  VVJ4QS, cbFncDict = CCpE07.VVpbzK(self, VVToDv, servName, 3)
  mSel.VV9EgX(VVJ4QS, cbFncDict)
 @staticmethod
 def VVpbzK(SELF, VVToDv, servName, refCodeCol):
  tot = VVToDv.VVFx4F()
  if tot > 0:
   sTxt = FFrGgO("%d Service%s" % (tot, FFIMVJ(tot)), VVtSeQ)
   VVJ4QS = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FFVK2H(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FFrGgO(servName, VVtSeQ)
   VVJ4QS = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CCpE07.VVK3ZG, SELF, VVToDv, refCodeCol, True)
     , "addToBouquet_one" : BF(CCpE07.VVK3ZG, SELF, VVToDv, refCodeCol, False)
     }
  return VVJ4QS, cbFncDict
 @staticmethod
 def VVK3ZG(SELF, VVToDv, refCodeCol, isMulti):
  picker = CC54zE(SELF, VVToDv, "Add to Bouquet", BF(CCpE07.VVv02j, VVToDv, refCodeCol, isMulti))
 @staticmethod
 def VVv02j(VVToDv, refCodeCol, isMulti):
  if isMulti : refCodeList = VVToDv.VVAoir(refCodeCol)
  else  : refCodeList = [VVToDv.VVKPIF()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VV3Rjz(self, VVToDv, refCode, isAddToBlackList):
  VVToDv.VV3rfE("Processing ...")
  FFS6vB(BF(self.VVEdaI, VVToDv, [refCode], isAddToBlackList))
 def VVPuhU(self, VVToDv, isAddToBlackList):
  refCodeList = VVToDv.VVAoir(3)
  if not refCodeList:
   FFfYN0(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVToDv.VV3rfE("Processing ...")
  FFS6vB(BF(self.VVEdaI, VVToDv, refCodeList, isAddToBlackList))
 def VVEdaI(self, VVToDv, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVVISw, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVVISw):
   lines = FFup4P(VVVISw)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVVISw, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVToDv.VVmDY2
   if isMulti:
    self.VVnqGU(VVToDv, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VV7paa(VVToDv, refCode)
    VVToDv.VVDGPS()
  else:
   VVToDv.VVB7wY("No changes")
 def VV0yyX(self, VVToDv, refCode, isHide):
  title = "Change Hidden State"
  if FFB5r2(refCode):
   VVToDv.VV3rfE("Processing ...")
   ret = FFWATy(refCode, isHide)
   if ret : FFlaBE(self, BF(self.VV7paa, VVToDv, refCode))
   else : FFfYN0(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFfYN0(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VV7paa(self, VVToDv, refCode):
  VVjhh4, err = CCpE07.VV5WFr(self, self.VVAXy7, VVXKbF=[3, [refCode], False])
  done = False
  if VVjhh4:
   data = VVjhh4[0]
   if data[3] == refCode:
    done = VVToDv.VViiSN(data)
  if not done:
   self.VVtid5(VVToDv, VVToDv.VVgfJ7(), self.VVAXy7)
  VVToDv.VVDGPS()
 def VVnqGU(self, VVToDv, totRefCodes):
  VVjhh4, err = CCpE07.VV5WFr(self, self.VVAXy7, VVXKbF=self.VV9wYB)
  VVToDv.VV3ih0(VVjhh4)
  VVToDv.VVQ2Pz(False)
  VVToDv.VVB7wY("%d Processed" % totRefCodes)
 def VVgeNf(self, VVToDv, isHide):
  refCodeList = VVToDv.VVAoir(3)
  if not refCodeList:
   FFfYN0(self, "Nothing selected", title="Change Hidden State")
   return
  VVToDv.VV3rfE("Processing ...")
  FFS6vB(BF(self.VV8d9T, VVToDv, refCodeList, isHide))
 def VV8d9T(self, VVToDv, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFWATy(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFpUU8(True)
   self.VVnqGU(VVToDv, len(refCodeList))
  else:
   VVToDv.VVB7wY("No changes")
 def VVp6Kb(self, VVToDv, title, txt, colList):
  inFilterFnc = BF(self.VVXwYs, VVToDv) if self.VV9wYB else None
  self.filterObj.VVvekh(1, VVToDv, 2, BF(self.VVs82i, VVToDv), inFilterFnc=inFilterFnc)
 def VVs82i(self, VVToDv, item):
  self.VV6nm9(VVToDv, False, item, 2, self.VVAXy7)
 def VVXwYs(self, VVToDv, menuInstance, item):
  self.VV6nm9(VVToDv, True, item, 2, self.VVAXy7)
 def VVBhY0(self, VVToDv, title, txt, colList):
  inFilterFnc = BF(self.VV3UH6, VVToDv) if self.VV9wYB else None
  self.filterObj.VVvekh(2, VVToDv, 4, BF(self.VVkcrp, VVToDv), inFilterFnc=inFilterFnc)
 def VVkcrp(self, VVToDv, item):
  self.VV6nm9(VVToDv, False, item, 4, self.VVIgvw)
 def VV3UH6(self, VVToDv, menuInstance, item):
  self.VV6nm9(VVToDv, True, item, 4, self.VVIgvw)
 def VVaSzZ(self, VVToDv, title, txt, colList):
  inFilterFnc = BF(self.VVcnQq, VVToDv) if self.VV9wYB else None
  self.filterObj.VVvekh(0, VVToDv, 4, BF(self.VVxjUV, VVToDv), inFilterFnc=inFilterFnc)
 def VVxjUV(self, VVToDv, item):
  self.VV6nm9(VVToDv, False, item, 4, self.VV8pxp)
 def VVcnQq(self, VVToDv, menuInstance, item):
  self.VV6nm9(VVToDv, True, item, 4, self.VV8pxp)
 def VV6nm9(self, VVToDv, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVToDv.VVzQU4(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VV9wYB = None
  else:
   words, asPrefix = CCMA5J.VVBkhG(words)
   self.VV9wYB = [col, words, asPrefix]
  if words: FFlaBE(VVToDv, BF(self.VVtid5, VVToDv, title, mode), clearMsg=False)
  else : FFHbVj(VVToDv, "Incorrect filter", 2000)
 def VVtid5(self, VVToDv, title, mode):
  VVjhh4, err = CCpE07.VV5WFr(self, mode, VVXKbF=self.VV9wYB, VVlRYz=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVToDv.VVF8iU():
    try:
     ndx = VVjhh4.index(tuple(list(map(str.strip, row))))
     lst.append(VVjhh4[ndx])
    except:
     pass
   VVjhh4 = lst
  if VVjhh4:
   VVjhh4.sort(key=lambda x: x[0].lower())
   VVToDv.VV3ih0(VVjhh4, title)
  else:
   FFHbVj(VVToDv, "Not found!", 1500)
 def VVtwCD(self, title, VVITUl, VVHFFO=None, VVXuip=None, VVcjza=None, VV7wPX=None, VVbdhP=None, VVUB3Q=None):
  VV7wPX = ("Current Service", self.VV71uf, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVavJp = (LEFT  , LEFT  , CENTER, LEFT    )
  FFA1pv(self, None, title=title, header=header, VVITUl=VVITUl, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VVHFFO=VVHFFO, VVXuip=VVXuip, VVcjza=VVcjza, VV7wPX=VV7wPX, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q, lastFindConfigObj=CFG.lastFindServices)
 def VV71uf(self, VVToDv, title, txt, colList):
  self.VV8jll(VVToDv)
 def VVqSZm(self, VVToDv, title, txt, colList):
  self.VV8jll(VVToDv, True)
 def VV8jll(self, VVToDv, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVToDv.VVirXl(colDict, VVdnur=True)
   else:
    VVToDv.VV0HXt(3, refCode, True)
   return
  FFfYN0(self, "Colud not read current Reference Code !")
 def VVwSc4(self, title):
  self.VV9wYB = None
  self.lastfilterUsed  = None
  self.filterObj   = CCMA5J(self)
  VVjhh4, err = CCpE07.VV5WFr(self, self.VV8pxp)
  if VVjhh4:
   VVjhh4.sort(key=lambda x: x[0].lower())
   VVXuip = (""    , self.VV1tCR , []      )
   VV7wPX = ("Current Service", self.VVqSZm  , []      )
   VVUB3Q = ("Filter"   , self.VVaSzZ   , [], "Loading Filters ..." )
   VVHFFO  = ("Zap"   , self.VVIPLC      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVavJp  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFA1pv(self, None, title=title, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VVHFFO=VVHFFO, VVXuip=VVXuip, VV7wPX=VV7wPX, VVUB3Q=VVUB3Q, lastFindConfigObj=CFG.lastFindServices)
 def VV1tCR(self, VVToDv, title, txt, colList):
  refCode  = self.VVcrr8(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFzeU3(self, fncMode=CCy52I.VVNtf4, refCode=refCode, chName=chName, text=txt)
 def VVIPLC(self, VVToDv, title, txt, colList):
  refCode = self.VVcrr8(colList)
  FFbrIp(self, refCode)
 def VVl2Tl(self, VVToDv, title, txt, colList):
  FFbrIp(self, colList[3])
 def VVcrr8(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVQgxf(VVv3dm, mode=0):
  lines = FFup4P(VVv3dm, encLst=["UTF-8"])
  return CCpE07.VVLIhj(lines, mode)
 @staticmethod
 def VVLIhj(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VV5WFr(SELF, mode, VVXKbF=None, VVlRYz=True, VVfXeW=True):
  VVv3dm, err = CCpE07.VVlds4(SELF, VVfXeW)
  if err:
   return None, err
  asPrefix = False
  if VVXKbF:
   filterCol = VVXKbF[0]
   filterWords = VVXKbF[1]
   asPrefix = VVXKbF[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCpE07.VVAXy7:
   blackList = None
   if fileExists(VVVISw):
    blackList = FFup4P(VVVISw)
    if blackList:
     blackList = set(blackList)
  elif mode == CCpE07.VVIgvw:
   tp = CCoeZX()
  VV7i3E, VVMouC = FFxdEf()
  if mode in (CCpE07.VVARox, CCpE07.VVVgns):
   VVjhh4 = {}
  else:
   VVjhh4 = []
  tagFound = False
  with ioOpen(VVv3dm, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFBdLm(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCpE07.VV8pxp:
       if sTypeInt in VV7i3E:
        STYPE = VVMouC[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVjhh4.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVjhh4.append(tRow)
       else:
        VVjhh4.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCpE07.VVI1kI:
        VVjhh4.append((chName, chProv, sat, refCode))
       elif mode == CCpE07.VVARox:
        VVjhh4[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCpE07.VVVgns:
        VVjhh4[chName] = refCode
       elif mode == CCpE07.VVAXy7:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVjhh4.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVjhh4.append(tRow)
        else:
         VVjhh4.append(tRow)
       elif mode == CCpE07.VVIgvw:
        if sTypeInt in VV7i3E:
         STYPE = VVMouC[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVcy5m(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVjhh4.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVjhh4.append(tRow)
        else:
         VVjhh4.append(tRow)
       elif mode == CCpE07.VVHah1:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVjhh4.append((chName, chProv, sat, refCode))
       elif mode == CCpE07.VVPSnJ:
        VVjhh4.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVjhh4 and VVlRYz:
   FFfYN0(SELF, "No services found!")
  return VVjhh4, ""
 def VVK1St(self, title):
  if fileExists(VVVISw):
   lines = FFup4P(VVVISw)
   if lines:
    newRows = []
    VVjhh4, err = CCpE07.VV5WFr(self, self.VVPSnJ)
    if VVjhh4:
     lines = set(lines)
     for item in VVjhh4:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVjhh4 = newRows
      VVjhh4.sort(key=lambda x: x[0].lower())
      VVXuip = ("", self.VVd3N2, [])
      VVHFFO = ("Zap", self.VVl2Tl, [])
      self.VVtwCD(title, VVjhh4, VVHFFO=VVHFFO, VVXuip=VVXuip)
     else:
      FFCxQN(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVjhh4)))
   else:
    FF8O6K(self, "No active Parental Control services.", FFyAmw())
  else:
   FF6vdZ(self, VVVISw)
 def VVN7oT(self, title):
  VVjhh4, err = CCpE07.VV5WFr(self, self.VVHah1)
  if VVjhh4:
   VVjhh4.sort(key=lambda x: x[0].lower())
   VVXuip = ("" , self.VVd3N2, [])
   VVHFFO  = ("Zap", self.VVl2Tl, [])
   self.VVtwCD(title, VVjhh4, VVHFFO=VVHFFO, VVXuip=VVXuip)
  elif err:
   pass
  else:
   FF8O6K(self, "No hidden services.", FFyAmw())
 def VVjnVn(self):
  title = "Services unused in Tuner Configuration"
  VVv3dm, err = CCpE07.VVlds4(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CCpE07.VV4WEt()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VV8lcj(str(item[0]))
    nsLst.add(ns)
  sysLst = CCpE07.VVzHUI("1:7:")
  tpLst  = CCpE07.VVQgxf(VVv3dm, mode=1)
  VVjhh4 = []
  for refCode, chName in sysLst:
   servID = CCpE07.VVAWJ0(refCode)
   tpID = CCpE07.VVDkFM(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVjhh4.append((chName, FFQQpf(refCode, False), refCode, servID))
  if VVjhh4:
   VVjhh4.sort(key=lambda x: x[0].lower())
   VVbdhP = ("Options"   , BF(self.VVHyuT, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VVavJp  = (LEFT  , CENTER , LEFT   , CENTER   )
   FFA1pv(self, None, title=title, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VVbdhP=VVbdhP, VV1Y9q="#0a001122", VVMnLe="#0a001122", VVop6p="#0a001122", VViLdG="#00004455", VVmDPu="#0a333333", VV15Y9="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FF8O6K(self, "No invalid service found !", title=title)
 def VVHyuT(self, Title, VVToDv, title, txt, colList):
  mSel = CC6FeI(self, VVToDv)
  isMulti = VVToDv.VVmDY2
  if isMulti : txt = "Remove %s Services" % FFrGgO(str(VVToDv.VVFx4F()), VVPUgM)
  else  : txt = "Remove : %s" % FFrGgO(VVToDv.VVKPIF()[0], VVPUgM)
  VVJ4QS = [(txt, "del")]
  cbFncDict = {"del": BF(FFlaBE, VVToDv, BF(self.VV4qnk, VVToDv, Title))}
  mSel.VV9EgX(VVJ4QS, cbFncDict)
 def VV4qnk(self, VVToDv, title):
  VVv3dm, err = CCpE07.VVlds4(self, title=title)
  if err:
   return
  isMulti = VVToDv.VVmDY2
  skipLst = []
  if isMulti : skipLst = VVToDv.VVAoir(3)
  else  : skipLst = [VVToDv.VVKPIF()[3]]
  tpLst = CCpE07.VVQgxf(VVv3dm, mode=0)
  servLst = CCpE07.VVQgxf(VVv3dm, mode=10)
  tmpDbFile = VVv3dm + ".tmp"
  lines   = FFup4P(VVv3dm)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  os.system(FFyto6("mv -f '%s' '%s'" % (tmpDbFile, VVv3dm)))
  VVjhh4 = []
  for row in VVToDv.VVF8iU():
   if not row[3] in skipLst:
    VVjhh4.append(row)
  FFpUU8()
  FFCxQN(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVjhh4:
   VVToDv.VV3ih0(VVjhh4, title)
   VVToDv.VVQ2Pz(False)
  else:
   VVToDv.cancel()
 def VVOVfI(self, title):
  VVv3dm, err = CCpE07.VVlds4(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VVowPq(VVv3dm)
  txt = FFrGgO("Total Transponders:\n\n", VVE6YJ)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFrGgO("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVE6YJ)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFOBOl(item), satList.count(item))
  FFCxQN(self, txt, title)
 def VVowPq(self, VVv3dm):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVv3dm, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVZuOx(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FF6vdZ(self, path, title=title)
   return
  elif not CCqXgM.VV7Hvo(self, path, title):
   return
  if not CCUpIE.VVAr4S(self):
   return
  tree = CCpE07.VVlO5S(self, path, title=title)
  if not tree:
   return
  VVjhh4 = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FFBdLm(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVjhh4.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVjhh4:
   VVjhh4.sort(key=lambda x: int(x[1]))
   VV7wPX = ("Current Satellite", BF(self.VVIktK, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VVavJp  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FFA1pv(self, None, title=title, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=25, VVenoQ=1, VV7wPX=VV7wPX, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFfYN0(self, "No data found !", title=title)
 def VVIktK(self, satCol, VVToDv, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self)
  sat = FFQQpf(refCode, False)
  for ndx, row in enumerate(VVToDv.VVF8iU()):
   if sat == row[satCol].strip():
    VVToDv.VVeb2k(ndx)
    break
  else:
   FFHbVj(VVToDv, "No listed !", 1500)
 def FFlaBE_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FFfYN0(self, "No Satellites found !")
   return
  usedSats = CCpE07.VV4WEt()
  VVjhh4 = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVjhh4.append((sat[1], posTxt, FFBdLm(sat[0]), tuners, str(posVal)))
  if VVjhh4:
   VVop6p = "#11222222"
   VVjhh4.sort(key=lambda x: int(x[1]))
   VV7wPX = ("Current Satellite" , BF(self.VVIktK, 2) , [])
   VVbdhP = ("Options"   , self.VVf6iL  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VVavJp  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FFA1pv(self, None, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=28, VV7wPX=VV7wPX, VVbdhP=VVbdhP, VV1Y9q=VVop6p, VVMnLe=VVop6p, VVop6p=VVop6p, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFfYN0(self, "No data found !")
 def VVf6iL(self, VVToDv, title, txt, colList):
  mSel = CC6FeI(self, VVToDv)
  isMulti = VVToDv.VVmDY2
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FFrGgO(str(VVToDv.VVFx4F()), VVPUgM)
  else  : txt = "Remove ALL Services on : %s" % FFrGgO(VVToDv.VVKPIF()[0], VVPUgM)
  VVJ4QS = []
  VVJ4QS.append((txt, "deleteSat"))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Delete Empty Bouquets", "VVdGsB"))
  cbFncDict = { "deleteSat"   : BF(FFlaBE, VVToDv, BF(self.VVwJ7n, VVToDv))
     , "VVdGsB" : BF(self.VVdGsB, VVToDv)
     }
  mSel.VV9EgX(VVJ4QS, cbFncDict)
 def VVwJ7n(self, VVToDv):
  posLst = []
  isMulti = VVToDv.VVmDY2
  posLst = []
  if isMulti : posLst = VVToDv.VVAoir(4)
  else  : posLst = [VVToDv.VVKPIF()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VV8lcj(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VVLyN6(nsLst)
  FFpUU8(True)
  FFCxQN(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VVdGsB(self, winObj):
  title = "Delete Empty Bouquets"
  FFZw7B(self, BF(FFlaBE, winObj, BF(self.VVeTl0, title)), "Delete bouquets with no services ?", title=title)
 def VVeTl0(self, title):
  bList = CC54zE.VViCTt()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CC54zE.VVelIF(bRef)
    bPath = VVoDv6 + bFile
    FFM75P(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVoDv6 + fil
     if fileExists(path):
      lines = FFup4P(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFpUU8(True)
  if bNames: txt = "%s\n\n%s" % (FFrGgO("Deleted Bouquets:", VVtSeQ), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FFCxQN(self, txt, title=title)
 def VV8lcj(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VVLyN6(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVoDv6)
  for srcF in files:
   if fileExists(srcF):
    lines = FFup4P(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFUjGn(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VVp6GS(self, title)   : self.VVY1PK(title, True)
 def VV1aC3(self, title) : self.VVY1PK(title, False)
 def VVY1PK(self, title, isWithPIcons):
  piconsPath = CC8ahC.VVmFFX()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CC8ahC.VVSlLY(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVjhh4, err = CCpE07.VV5WFr(self, self.VVPSnJ)
    if VVjhh4:
     channels = []
     for (chName, chProv, sat, refCode) in VVjhh4:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFyiHM(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVjhh4)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVzg89(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVzg89("PIcons Path"  , piconsPath)
     txt += VVzg89("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVzg89("Total services" , totalServices)
     txt += VVzg89("With PIcons"  , totalWithPIcons)
     txt += VVzg89("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFCxQN(self, txt)
     else:
      VVXuip     = (""      , self.VVd3N2 , [])
      if isWithPIcons : VVUB3Q = ("Export Current PIcon", self.VVLLX8  , [])
      else   : VVUB3Q = None
      VVbdhP     = ("Statistics", FFCxQN, [txt])
      VVHFFO      = ("Zap", self.VVl2Tl, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVtwCD(title, channels, VVHFFO=VVHFFO, VVXuip=VVXuip, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q)
   else:
    FFfYN0(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFfYN0(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVd3N2(self, VVToDv, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFzeU3(self, fncMode=CCy52I.VVNtf4, refCode=refCode, chName=chName, text=txt)
 def VVLLX8(self, VVToDv, title, txt, colList):
  png, path = CC8ahC.VVt2aC(colList[3], colList[0])
  if path:
   CC8ahC.VVFpaA(self, png, path)
 @staticmethod
 def VVNijv():
  VVv3dm  = "%slamedb" % VVoDv6
  VVzOT4 = "%slamedb.disabled" % VVoDv6
  return VVv3dm, VVzOT4
 @staticmethod
 def VVJ555():
  VVUTFl  = "%slamedb5" % VVoDv6
  VVGHU5 = "%slamedb5.disabled" % VVoDv6
  return VVUTFl, VVGHU5
 def VVLZSN(self, isEnable):
  VVv3dm, VVzOT4 = CCpE07.VVNijv()
  if isEnable and not fileExists(VVzOT4):
   FF8O6K(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVv3dm):
   FFfYN0(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFZw7B(self, BF(self.VVvYC2, isEnable), "%s Hidden Channels ?" % word)
 def VVvYC2(self, isEnable):
  VVv3dm , VVzOT4 = CCpE07.VVNijv()
  VVUTFl, VVGHU5 = CCpE07.VVJ555()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVzOT4, VVzOT4, VVv3dm)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVGHU5, VVGHU5, VVUTFl)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (VVv3dm  , VVv3dm , VVzOT4)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (VVUTFl , VVUTFl, VVGHU5)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVzOT4, VVv3dm )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVGHU5, VVUTFl)
  res = os.system(cmd)
  FFpUU8()
  if res == 0 : FF8O6K(self, "Hidden List %s" % word)
  else  : FFfYN0(self, "Error while restoring:\n\n%s" % fileName)
 def VVFj9u(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %ssettings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVoDv6
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %ssettings" % VVoDv6
  FFW93x(self, cmd)
 def VVZo7I(self):
  VVv3dm, err = CCpE07.VVlds4(self)
  if err:
   return
  tmpFile = "/tmp/ajpanel_lamedb"
  FFM75P(tmpFile)
  totChan = totRemoved = 0
  lines = FFup4P(VVv3dm, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FFZw7B(self, BF(FFlaBE, self, BF(self.VVYSbN, tmpFile, VVv3dm, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FFIMVJ(totRemoved), totChan, FFIMVJ(totChan))
      , callBack_No=BF(self.VVJYCz, tmpFile))
  else:
   FFCxQN(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVYSbN(self, tmpFile, VVv3dm, totRemoved, totChan):
  os.system(FFyto6("mv -f '%s' '%s'" % (tmpFile, VVv3dm)))
  FFpUU8()
  FFCxQN(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VVJYCz(self, tmpFile):
  FFM75P(tmpFile)
 @staticmethod
 def VVlds4(SELF, VVfXeW=True, title=""):
  VVv3dm, VVzOT4 = CCpE07.VVNijv()
  if   not fileExists(VVv3dm)       : err = "File not found !\n\n%s" % VVv3dm
  elif not CCqXgM.VV7Hvo(SELF, VVv3dm) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VVfXeW:
   FFfYN0(SELF, err, title=title)
  return VVv3dm, err
 @staticmethod
 def VVDkFM(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VVAWJ0(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VVzHUI(servTypes):
  VVKzVO  = eServiceCenter.getInstance()
  VV4jUS   = '%s ORDER BY name' % servTypes
  VVIuih   = eServiceReference(VV4jUS)
  VVSGrD = VVKzVO.list(VVIuih)
  if VVSGrD: return VVSGrD.getContent("CN", False)
  else     : return []
 @staticmethod
 def VV4WEt():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CCy52I(Screen):
 VVRoI8  = 0
 VVvTvR   = 1
 VV2Sv8   = 2
 VVNtf4    = 3
 VVKOLG    = 4
 VVAXkn   = 5
 VVKdDX   = 6
 VVl5vO    = 7
 VVdbSh   = 8
 VVqHia   = 9
 VVnmYX   = 10
 VVB1Wm   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFNQkv(VVpCD5, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVRoI8)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFrGgO("%s\n", VV4U5y) % VVU8ll
  self.picViewer  = None
  FFVOCw(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVipM7 })
  self["myPicF"]  = Label()
  self["myPicB"]  = Label()
  self["myPic"]  = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VV47vn)
  self.onClose.append(self.onExit)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  self["myLabel"].VVYtUm(outputFileToSave="chann_info")
  if   self.fncMode == self.VVRoI8 : fnc = self.VVxGNI
  elif self.fncMode == self.VVvTvR  : fnc = self.VVxGNI
  elif self.fncMode == self.VV2Sv8  : fnc = self.VVxGNI
  elif self.fncMode == self.VVNtf4  : fnc = self.VVD7dR
  elif self.fncMode == self.VVKOLG  : fnc = self.VVlp9D
  elif self.fncMode == self.VVAXkn  : fnc = self.VVGZP2
  elif self.fncMode == self.VVKdDX  : fnc = self.VVYGyq
  elif self.fncMode == self.VVl5vO  : fnc = self.VV3a01
  elif self.fncMode == self.VVdbSh  : fnc = self.VV1uQk
  elif self.fncMode == self.VVqHia : fnc = self.VVDhia
  elif self.fncMode == self.VVnmYX  : fnc = self.VVfEAo
  elif self.fncMode == self.VVB1Wm : fnc = self.VVVtHO
  self["myLabel"].setText("\n   Reading Info ...")
  FFS6vB(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVl2Cc()
 def VVHivf(self, err):
  self["myLabel"].setText(err)
  FFg8wK(self["myTitle"], "#22200000")
  FFg8wK(self["myBody"], "#22200000")
  self["myLabel"].VVgnWb("#22200000")
  self["myLabel"].VVy8Bm()
 def VVxGNI(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self)
  self.refCode = refCode
  self.VVdDFO(chName)
 def VVD7dR(self):
  self.VVdDFO(self.chName)
 def VVlp9D(self):
  self.VVdDFO(self.chName)
 def VVGZP2(self):
  self.VVdDFO(self.chName)
 def VVYGyq(self):
  self.VVdDFO("Picon Info")
 def VV3a01(self):
  self.VVdDFO(self.chName)
 def VV1uQk(self):
  self.VVdDFO(self.chName)
 def VVDhia(self):
  self.VVdDFO(self.chName)
 def VVfEAo(self):
  self.chUrl = self.refCode + self.callingSELF.VVw9kH(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVdDFO(self.chName)
 def VVVtHO(self):
  self.VVdDFO(self.chName)
 def VVdDFO(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FF6soe(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVMfrT(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFrGgO(self.VVZSPF(tUrl), VVyLoh)
  if not self.epg:
   epg = self.VVmFee(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVmG3T(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CC8ahC.VVt2aC(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVmG3T(path)
  self.VVb1WB()
  self.VVQnHI()
  self["myLabel"].setText(self.text or "   No active service", VVbIg5=VVmDB2)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVy8Bm(minHeight=minH)
 def VVQnHI(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFCeZx(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VV4YWn(FFaTzZ(url))
  if epg:
   self.text += "\n" + FFEuDm("EPG:", VVtSeQ) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVb1WB()
 def VVb1WB(self):
  if not self.piconShown and self.picUrl:
   path, err = FFSAwr(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVmG3T(path)
    if self.piconShown and self.refCode:
     self.VVIJgl(path, self.refCode)
 def VVIJgl(self, path, refCode):
  if path and fileExists(path) and os.system(FFyto6("which ffmpeg")) == 0:
   pPath = CC8ahC.VVmFFX()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CCy52I.VVWRuE(path)
    cmd += FFyto6("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVmG3T(self, path):
  if path and fileExists(path):
   err, w, h = self.VVuXA8(path)
   if not err:
    if h > w:
     self.VVXDCo(self["myPicF"], w, h, True)
     self.VVXDCo(self["myPicB"], w, h, False)
     self.VVXDCo(self["myPic"] , w, h, False)
   self.picViewer = CC376o.VVnOBs(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VVXDCo(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVuXA8(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFIgoM(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVMfrT(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFrGgO(chName, VVtSeQ)
  txt += self.VVzg89(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFrGgO(state, VVFBP5)
   txt += "State\t: %s\n" % state
  w = FFmiK9(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFmiK9(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVpz3X(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVzg89(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVzg89(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVzg89(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VV5Miv()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVqxMD()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCy52I.VVlM2Y(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFrGgO("IPTV", VVE6YJ)
   txt += self.VVjwSd(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVRmQu(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCoeZX()
    tpTxt, namespace = tp.VVHlnR(refCode)
    if tpTxt:
     txt += FFrGgO("Tuner:\n", VVtSeQ)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFrGgO("Codes:\n", VVtSeQ)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVzg89(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVzg89(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVzg89(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVzg89(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVzg89(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVzg89(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVzg89(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVzg89(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVzg89(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVpz3X(info):
  if info:
   aspect = FFmiK9(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVzg89(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFmiK9(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVOBwr(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVOBwr(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VV5Miv(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VVqxMD(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVRmQu(self, refCode, iptvRef, chName):
  refCode = FF95YK(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFZF5l(VVoDv6 + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFZF5l(VVoDv6 + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VVITUl = []
  tmpRefCode = FFaTzZ(refCode)
  for item in fList:
   path = VVoDv6 + item
   if fileExists(path):
    txt = FFZF5l(path)
    if tmpRefCode in FFaTzZ(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVITUl.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VVITUl:
   if len(VVITUl) == 1:
    txt += "%s\t: %s%s\n" % (FFrGgO("Bouquet", VVtSeQ), VVITUl[0][0], " (%s)" % VVITUl[0][1] if VVtMJJ else "")
   else:
    txt += FFrGgO("Bouquets:\n", VVtSeQ)
    for ndx, item in enumerate(VVITUl):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVtMJJ else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVmFee(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VV7176(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VV7176(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VV7176(event, 0)
     except:
      pass
  return epg
 def VV7176(self, event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCy52I.VVZfRT(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = CCy52I.VVsHvI(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FFrGgO(evName, VVtSeQ)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FFrGgO(evNameTransl, VVtSeQ))
    if evTime           : txt += "Start Time\t: %s\n" % FF4ENQ(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FF4ENQ(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFxB2b(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFxB2b(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFxB2b(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFrGgO(evShort, VVxpap)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFrGgO(evDesc , VVxpap)
    if txt:
     txt = FFrGgO("\n%s\n%s Event:\n%s\n" % (VVU8ll, ("Current", "Next")[evNum], VVU8ll), VVtSeQ) + txt
  return txt
 def VVjwSd(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFeiz0(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCHEQq()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVTeL9(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFrGgO("URL:", VVE6YJ) + "\n%s\n" % self.VVZSPF(decodedUrl)
  else:
   txt = "\n"
   txt += FFrGgO("Reference:", VVE6YJ) + "\n%s\n" % refCode
  return txt
 def VVZSPF(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VV5uVo:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").replace("%3A", ":").strip()
 def VV4YWn(self, decodedUrl):
  if not FFHkZ8():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCCwQV.VVY4JM(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCCwQV.VVCWun(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VV8vxf(tDict)
   elif uType == "movie" : epg, picUrl = CCy52I.VVZ7Jo(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VV8vxf(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCCwQV.VVfM7o(item, "title"    , is_base64=True )
     lang    = CCCwQV.VVfM7o(item, "lang"         ).upper()
     description   = CCCwQV.VVfM7o(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCCwQV.VVfM7o(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCCwQV.VVfM7o(item, "start_timestamp"      )
     stop_timestamp  = CCCwQV.VVfM7o(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCCwQV.VVfM7o(item, "stop_timestamp"       )
     now_playing   = CCCwQV.VVfM7o(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVCLGj, ""
      else     : color, txt = VVFBP5 , "    (CURRENT EVENT)"
      epg += FFrGgO("_" * 32 + "\n", VV4U5y)
      epg += FFrGgO("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFrGgO(description, VVyLoh)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVM43F(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVZ7Jo(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCCwQV.VVfM7o(item, "movie_image" )
    genre  = CCCwQV.VVfM7o(item, "genre"   ) or "-"
    plot  = CCCwQV.VVfM7o(item, "plot"   ) or "-"
    cast  = CCCwQV.VVfM7o(item, "cast"   ) or "-"
    rating  = CCCwQV.VVfM7o(item, "rating"   ) or "-"
    director = CCCwQV.VVfM7o(item, "director"  ) or "-"
    releasedate = CCCwQV.VVfM7o(item, "releasedate" ) or "-"
    duration = CCCwQV.VVfM7o(item, "duration"  ) or "-"
    try:
     lang = CCCwQV.VVfM7o(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFrGgO(cast, VVyLoh)
    epg += "Plot:\n%s"    % FFrGgO(CCy52I.VVsHvI(plot), VVyLoh)
   except:
    pass
  return epg, movie_image
 @staticmethod
 def VVsHvI(evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = CCy52I.VVWsjA(evTxt, lang)
   return CCy52I.VVKVCZ(txt).strip() or evTxt
 def VVipM7(self):
  if VV5uVo:
   def VVzg89(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVzg89(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCHEQq()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVTeL9(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVzg89(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (VVU8ll, txt))
   FFHbVj(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVKVCZ(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VVHl3M(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   try:
    from enigma import eEPGCache
    eCache = eEPGCache.getInstance()
    if eCache:
     event = eCache.lookupEventTime(serv, -1, 0)
     if event: return CCy52I.VVZfRT(event)
   except:
    pass
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event: return CCy52I.VVZfRT(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVZfRT(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCy52I.VVzyRT(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVw68F(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   try:
    from enigma import eEPGCache
    eCache = eEPGCache.getInstance()
    if eCache:
     for evNum in range(2):
      event = eCache.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CCy52I.VVZfRT(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FF4ENQ(evTime)
       evEndTxt  = FF4ENQ(evEnd)
       evDurTxt  = FFxB2b(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FFxB2b(evPos)
        evRem = evEnd - now
        evRemTxt = FFxB2b(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FFxB2b(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VVWsjA(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFjRDJ(txt))
   txt, err = CCCwQV.VVCWun(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFaTzZ(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVM43F(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VV87mj(SELF):
  if not CCuKpK.VVLJ72(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(SELF)
  err = url =  fSize = resumable = ""
  if FFMUSj(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCHEQq.VVjHQa(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCHEQq.VVvxfa(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFfYN0(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCqXgM.VV4m3L(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFrGgO(" (M3U/M3U8 File)", VVyLoh)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCjOMG.VVuGwd(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VV4wPN(subj, val):
   return "%s\n%s\n\n" % (FFrGgO("%s:" % subj, VVtSeQ), val)
  title = "File Size"
  txt  = VV4wPN(title , fSize or "?")
  txt += VV4wPN("Name" , chName)
  txt += VV4wPN("URL" , url)
  if resumable: txt += VV4wPN("Supports Download-Resume", resumable)
  if err  : txt += FFrGgO("Error:\n", VVFBP5) + err
  FFCxQN(SELF, txt, title=title)
 @staticmethod
 def VVlM2Y(SELF):
  fPath, fDir, fName = CCqXgM.VVsA5T(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVzyRT(event):
  genre = PR = ""
  try:
   genre  = CCy52I.VVC7cF(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCy52I.VVSVXy(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVSVXy(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVC7cF(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCy52I.VVghUq()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVghUq():
  path = VVnEh8 + "genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFZF5l(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFZF5l(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVWRuE(path):
  return "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
 @staticmethod
 def VVtRHL(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CC8ahC.VVmFFX() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VVUMHy(serv):
  isLocal = isIptv = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if FFCeZx(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFUjGn(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCHEQq():
 def __init__(self):
  self.VVnFHs   = ""
  self.VVFH2j    = ""
  self.VVwv8h   = ""
  self.VV8LOV = ""
  self.VV5wOz  = ""
  self.VVZAtL = 0
  self.VVdM78    = ""
  self.VVyvSX   = "#f#11ffffaa#User"
  self.VVWy3E   = "#f#11aaffff#Server"
 def VVsOGu(self, url, mac, ph1="", VVdnur=True):
  self.VVnFHs   = ""
  self.VVFH2j    = ""
  self.VVwv8h   = ""
  self.VV8LOV = ""
  self.VV5wOz  = ""
  self.VVZAtL = 0
  self.VVdM78    = {"s": "/server/load.php", "p": "/portal.php"}.get(ph1, "")
  host = self.VVSLUE(url)
  if not host:
   if VVdnur:
    self.VVF7Fx("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVLOMt(mac)
  if not host:
   if VVdnur:
    self.VVF7Fx("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVnFHs = host
  self.VVFH2j  = mac
  return True
 def VVSLUE(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVLOMt(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VV5Wvu(self):
  res, err = self.VV0PlS(self.VV0j55())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VVnFHs:
   self.VVnFHs = self.VVnFHs.replace(urlPath, "")
   res, err = self.VV0PlS(self.VV0j55())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCCwQV.VVfM7o(tDict["js"], "token")
    rand  = CCCwQV.VVfM7o(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVYier(self, VVdnur=True):
  if not self.VVdM78:
   self.VVdM78 = self.VVEiRQ()
  err = blkMsg = FF8O6KTxt = ""
  try:
   token, rand, err = self.VV5Wvu()
   if token:
    self.VVwv8h = token
    self.VV8LOV = rand
    if rand:
     self.VVZAtL = 2
    prof, retTxt = self.VVhfXD(True)
    if prof:
     self.VV5wOz = retTxt
     if "device_id mismatch" in retTxt:
      self.VVZAtL = 3
      prof, retTxt = self.VVhfXD(False)
      if retTxt:
       self.VV5wOz = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FF8O6KTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FF8O6KTxt: tErr += "\n%s" % FF8O6KTxt
  if VVdnur:
   self.VVF7Fx(tErr)
  return "", "", tErr
 def VVEiRQ(self):
  try:
   import requests
   res = requests.get("%s/c/xpcom.common.js" % self.VVnFHs, headers=CCHEQq.VVvxfa(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       return span.group(1)
  except:
   pass
  return ""
 def VVhfXD(self, capMac):
  res, err = self.VV0PlS(self.VVlbAs(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCCwQV.VVfM7o(tDict["js"], "block_%s" % word)
    FF8O6KTxt = CCCwQV.VVfM7o(tDict["js"], word)
    return tDict, FF8O6KTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVlbAs(self, capMac):
  param = ""
  if self.VV5wOz or self.VV8LOV:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVFH2j.upper() if capMac else self.VVFH2j.lower(), self.VV8LOV))
  return self.VV1rqT() + "type=stb&action=get_profile" + param
 exec(FFO6Qx("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gID0gIiZhdXRoX3NlY29uZF9zdGVwPTEmaHdfdmVyc2lvbj0yLjE3LUlCLTAwJmh3X3ZlcnNpb25fMj02MiZzbj0lcyZkZXZpY2VfaWQ9JXMmZGV2aWNlX2lkMj0lcyZzaWduYXR1cmU9JXMiICUgKElkWzBdLCBJZFsxXSwgSWRbMV0sIElkWzJdKQ0KIHJldHVybiBwYXJhbSArICcmbWV0cmljcz17Im1hYyI6IiVzIiwic24iOiIlcyIsInR5cGUiOiJTVEIiLCJtb2RlbCI6Ik1BRzI1MCIsInJhbmRvbSI6IiVzIn0nICUgKElkWzNdLCBJZFswXSwgSWRbNF0pDQpkZWYgZ2V0TW9yZUF1dGhfSURzKHNlbGYsIG0sIHIpOg0KIGltcG9ydCBoYXNobGliDQogbWFjVXRmOCA9IG0uZW5jb2RlKCd1dGYtOCcpDQogcyA9IGhhc2hsaWIubWQ1KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKClbOjEzXQ0KIHJldHVybiBzLCBoYXNobGliLnNoYTI1NihtYWNVdGY4KS5oZXhkaWdlc3QoKS51cHBlcigpLCBoYXNobGliLnNoYTI1NigocyArIG0pLmVuY29kZSgndXRmLTgnKSkuaGV4ZGlnZXN0KCkudXBwZXIoKSwgbSwgcg=="))
 def VV9bT9(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVYRqH()
  if len(rows) < 10:
   rows = self.VVq5gL()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVnFHs ))
   rows.append(("MAC (from URL)" , self.VVFH2j ))
   rows.append(("Token"   , self.VVwv8h ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVyvSX  , "MAC" , self.VVFH2j ))
   rows.append(("2", self.VVWy3E, "Host" , self.VVnFHs ))
   rows.append(("2", self.VVWy3E, "Token" , self.VVwv8h ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVuYBb(self, isPhp=True, VVdnur=False):
  token, profile, tErr = self.VVYier(VVdnur)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VVrwYV()
  res, err = self.VV0PlS(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCCwQV.VVfM7o(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFjRDJ(span.group(2))
     pass1 = FFjRDJ(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VVYRqH(self):
  m3u_Url, host, user1, pass1, err = self.VVuYBb()
  rows = []
  if m3u_Url:
   res, err = self.VV0PlS(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FF4ENQ(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVyvSX, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FF4ENQ(int(val))
      else      : val = str(val)
      rows.append(("2", self.VVWy3E, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVq5gL(self):
  token, profile, tErr = self.VVYier()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFrhk5(val): val = FFO6Qx(val.decode("UTF-8"))
     else     : val = self.VVFH2j
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FF4ENQ(int(parts[1]))
      if parts[2] : ends = FF4ENQ(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FF4ENQ(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVw9kH(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVYier(VVdnur=False)
  if not token:
   return ""
  crLinkUrl = self.VVR90X(mode, chCm, epNum, epId)
  res, err = self.VV0PlS(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCCwQV.VVfM7o(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VV1rqT(self):
  return self.VVnFHs + (self.VVdM78 or "/server/load.php") + "?"
 def VV0j55(self):
  return self.VV1rqT() + "type=stb&action=handshake&token=&mac=%s" % self.VVFH2j
 def VVZ3tZ(self, mode):
  url = self.VV1rqT() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VV54Wf(self, catID):
  return self.VV1rqT() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVRKjN(self, mode, catID, page):
  url = self.VV1rqT() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVNWX2(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VV1rqT() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVlpUW(self, mode, catID):
  return self.VV1rqT() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVR90X(self, mode, chCm, serCode, serId):
  url = self.VV1rqT() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=false" % (mode, chCm)
  return url
 def VVrwYV(self):
  return self.VV1rqT() + "type=itv&action=create_link"
 def VVvhj2(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVSsc4(catID, stID, chNum)
  query = self.VVow29(mode, self.VVdM78[1:2], FFWMj3(host), FFWMj3(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVow29(self, mode, ph1, host, mac, serCode, serId, chCm):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVTeL9(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVow29(mode, ph1, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFO6Qx(host)
  mac   = FFO6Qx(mac)
  valid = False
  if self.VVSLUE(playHost) and self.VVSLUE(host) and self.VVSLUE(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query
 def VV0PlS(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCHEQq.VVvxfa()
   if self.VVwv8h:
    headers["Authorization"] = "Bearer %s" % self.VVwv8h
   if useCookies : cookies = {"mac": self.VVFH2j, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok :
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVcpBl(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCHEQq.VVvxfa(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVvxfa():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVTlgn(host, mac, tType, action, keysList=[]):
  myPortal = CCHEQq()
  ph1 = "s"
  pref = "/portal.php" if par == "p" else "/server/load.php"
  ok = myPortal.VVsOGu(host, mac, ph1)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVYier(VVdnur=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s%s?type=%s&action=%s" % (host, ph1, tType, action)
  res, err = myPortal.VV0PlS(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVAmkp(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVAmkp(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVF7Fx(self, err, title="Portal Browser"):
  FFfYN0(self, str(err), title=title)
 def VVK6yZ(self, mode):
  if   mode in ("itv"  , CCCwQV.VVt6oY , CCCwQV.VV59qS)  : return "Live"
  elif mode in ("vod"  , CCCwQV.VVXQci , CCCwQV.VVITeH)  : return "VOD"
  elif mode in ("series" , CCCwQV.VVrqLx , CCCwQV.VV467U) : return "Series"
  else                          : return "IPTV"
 def VVU5DT(self, mode, searchName):
  return 'Find in %s : %s' % (self.VVK6yZ(mode), FFrGgO(searchName, VVyLoh))
 def VV5ul7(self, catchup=False):
  VVJ4QS = []
  VVJ4QS.append(("Live"    , "live"  ))
  VVJ4QS.append(("VOD"    , "vod"   ))
  VVJ4QS.append(("Series"   , "series"  ))
  if catchup:
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append(("Catch-up TV" , "catchup"  ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Account Info." , "accountInfo" ))
  return VVJ4QS
 @staticmethod
 def VVlswK(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCHEQq()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVTeL9(decodedUrl)
  if valid:
   ok = p.VVsOGu(host, mac, ph1, VVdnur=False)
   if ok:
    m3u_Url, host, user1, pass1, err = p.VVuYBb(isPhp=False, VVdnur=False)
    streamId = CCHEQq.VVe8GT(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err
 @staticmethod
 def VVe8GT(decodedUrl):
  p = CCHEQq()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVTeL9(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFO6Qx(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVjHQa(decodedUrl):
  p = CCHEQq()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVTeL9(decodedUrl)
  if valid:
   if CCHEQq.VVs0XE(chCm):
    return FFaTzZ(chCm)
   else:
    ok = p.VVsOGu(host, mac, ph1, VVdnur=False)
    if ok:
     try:
      chUrl = p.VVw9kH(mode, chCm, epNum, epId)
      return FFaTzZ(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VVs0XE(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
class CCAVwF(CCHEQq):
 def __init__(self):
  CCHEQq.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VV6PGQ(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVTeL9(decodedUrl)
  if valid:
   if self.VVsOGu(host, mac, ph1, VVdnur=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVXY5q(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVw9kH(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CCHEQq.VVs0XE(self.chCm):
   chUrl = FFaTzZ(self.chCm)
   chUrl = FFjRDJ(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VV1rra(chUrl)
  bPath = CC54zE.VVoJdB()
  if newIptvRef:
   if passedSELF:
    FFbrIp(passedSELF, newIptvRef, VVVlLd=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFbrIp(self, newIptvRef, VVVlLd=False, fromPrtalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VVAHwJ(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VV1rra(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVAHwJ(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("&ph1=s", "&ph1=p", "&ph1=")
   for param in params: newPar = newPar.replace(param, "")
   lines = FFup4P(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for param in params: filePar = filePar.replace(param, "")
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFpUU8()
class CCgXBA(CCAVwF):
 def __init__(self, passedSession):
  CCAVwF.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVKOwu(VV10vq  )
  Main_Menu.VVKOwu(VVLWmv)
  Main_Menu.VVKOwu(VV0P9U  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVFGQ9, iPlayableService.evEOF: self.VVoc2g, iPlayableService.evEnd: self.VVMuJh})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVia1z)
  except:
   self.timer2.callback.append(self.VVia1z)
  self.timer2.start(3000, False)
  self.VVia1z()
 def VVia1z(self):
  if not CFG.downloadMonitor.getValue():
   self.VVHF8G()
   return
  lst = CCjOMG.VVX6pZ()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FF2Omp(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCjOMG.VVm2Ja(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin:
    self.dnldWin = self.passedSession.instantiateDialog(CCqDaf, txt, 30)
    self.dnldWin.instance.move(ePoint(30, 20))
    self.dnldWin.show()
    FFqDBE(self.dnldWin["myWinTitle"], "#440000", 1)
   else:
    self.dnldWin["myWinTitle"].setText(txt)
  elif self.dnldWin:
   self.VVHF8G()
 def VVHF8G(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVFGQ9(self):
  self.startTime = iTime()
 def VVoc2g(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self.passedSession, isFromSession=True)
    if iptvRef and not FFMUSj(decodedUrl):
     self.isFromEOF = True
     CCt6lo(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVMuJh(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VV32pS)
  except:
   self.timer1.callback.append(self.VV32pS)
  self.timer1.start(100, True)
 def VV32pS(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VV6PGQ(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCKx3s.VVwJWf:
       self.isFromEOF = False
       self.VVXY5q(self.passedSession, isFromSession=True)
class CCIrc5():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-z0-9\/\-._:|\]\[]+[\])|:](.+)")
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "xxi", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.adultWords2 = ("\u042d\u0440\u043e\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0435", "dla doros\u0142ych")
 def VVy0DL(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCCwQV.VV5DrD(name):
   return CCCwQV.VVykfS(name)
  name = self.VV8zRB(name)
  return name.strip() or name
 def VV8zRB(self, name):
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     return tName
  return name
 def VV97qa(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VV8zRB(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVwk7O(self, name):
  if self.hideAdult:
   if any(x in name.lower() for x in self.adultWords):
    return ""
   elif any(x in name.encode('ascii', 'backslashreplace').decode('utf-8').lower() for x in self.adultWords2):
    return ""
  return name.strip()
 def VVswk1(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVhcyV(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCuKpK(CCHEQq):
 def __init__(self):
  CCHEQq.__init__(self)
 def VVvLlA(self):
  if CCuKpK.VVLJ72(self):
   FFlaBE(self, BF(self.VV64EJ, 2), title="Searching ...")
 def VVPLHI(self, winSession, url, mac):
  if CCuKpK.VVLJ72(self):
   if self.VVsOGu(url, mac):
    FFlaBE(winSession, self.VVTc02, title="Checking Server ...")
   else:
    FFfYN0(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVuQyK(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CC7qa7.VV6aJR(path, self)
   if enc == -1:
    return
   self.session.open(CCwieb, barTheme=CCwieb.VV8xER
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVl0P3, path, enc)
       , VVGpYx = BF(self.VVx3jm, menuInstance, path))
 def VVl0P3(self, path, enc, VVqtmp):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVqtmp.VVZre9(totLines)
  VVqtmp.VV1c0w = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVqtmp or VVqtmp.isCancelled:
     return
    VVqtmp.VVIW1d(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVSLUE(url)
     mac  = self.VVLOMt(mac)
     if host and mac and VVqtmp:
      VVqtmp.VV1c0w.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVSLUE(url)
      mac  = self.VVLOMt(mac)
      if host and mac and not mac.startswith("AC") and VVqtmp:
       VVqtmp.VV1c0w.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVx3jm(self, menuInstance, path, VVLpbv, VV1c0w, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VV1c0w:
   VVcjza  = ("Home Menu"  , FFoI8M            , [])
   VVbdhP = ("Edit File"  , BF(self.VVwQXK, path)       , [])
   VV7wPX = ("M3U Options" , self.VV4Q0K         , [])
   VVUB3Q = ("Check & Filter" , BF(self.VVhX8V, menuInstance, path), [])
   VVHFFO  = ("Select"   , self.VVxF6p      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVavJp  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVToDv = FFA1pv(self, None, title=title, header=header, VVITUl=VV1c0w, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VVHFFO=VVHFFO, VVcjza=VVcjza, VV7wPX=VV7wPX, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q, VV1Y9q="#0a001122", VVMnLe="#0a001122", VVop6p="#0a001122", VViLdG="#00004455", VVmDPu="#0a333333", VV15Y9="#11331100", VVFvoI=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VVLpbv:
    FFHbVj(VVToDv, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVLpbv:
    FFfYN0(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VV4Q0K(self, VVToDv, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVJ4QS = []
  VVJ4QS.append(("Browse as M3U"  , "browse"))
  VVJ4QS.append(("Download M3U File" , "downld"))
  FFZP3S(self, BF(self.VVvz9f, VVToDv, host, mac), title=title, VVJ4QS=VVJ4QS, width=600, VV7GES=True)
 def VVvz9f(self, VVToDv, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FFlaBE(VVToDv, BF(self.VVY6S5, VVToDv, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFZw7B(self, BF(FFlaBE, VVToDv, BF(self.VVY6S5, VVToDv, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVY6S5(self, VVToDv, title, host, mac, item):
  p = CCHEQq()
  m3u_Url = ""
  ok = p.VVsOGu(host, mac, VVdnur=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VVuYBb(VVdnur=False)
  if m3u_Url:
   if   item == "browse": self.VV67Mo(title, m3u_Url)
   elif item == "downld": self.VVPw4f(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FFfYN0(self, err or "No response from Server !", title=title)
 def VVxF6p(self, VVToDv, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVPLHI(VVToDv, url, mac)
 def VVwQXK(self, path, VVToDv, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCbzSm(self, path, VVGpYx=BF(self.VVshM5, VVToDv), curRowNum=rowNum)
  else    : FF6vdZ(self, path)
 def VVhX8V(self, menuInstance, path, VVToDv, title, txt, colList):
  self.session.open(CCwieb, barTheme=CCwieb.VVkrqu
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVQ7Gy, VVToDv)
      , VVGpYx = BF(self.VVfZVo, menuInstance, VVToDv, path))
 def VVQ7Gy(self, VVToDv, VVqtmp):
  VVqtmp.VV1c0w = []
  VVqtmp.VVZre9(VVToDv.VVLfEh())
  for row in VVToDv.VVF8iU():
   if not VVqtmp or VVqtmp.isCancelled:
    return
   VVqtmp.VVIW1d(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVsOGu(host, mac, VVdnur=False):
    token, profile, tErr = self.VVYier(VVdnur=False)
    if token and VVqtmp and not VVqtmp.isCancelled:
     res, err = self.VV0PlS(self.VVZ3tZ("itv"))
     if res and VVqtmp and not VVqtmp.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVqtmp.VVIW1d(0, showFound=True)
       VVqtmp.VV1c0w.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVqtmp:
    return
 def VVfZVo(self, menuInstance, VVToDv, path, VVLpbv, VV1c0w, threadCounter, threadTotal, threadErr):
  if VV1c0w:
   VVToDv.close()
   menuInstance.close()
   newPath = "%s_OK_%s.txt" % (path, FFSZ6D())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VV1c0w:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FFrGgO(str(threadCounter), VVFBP5)
    skipped = FFrGgO(str(threadTotal - threadCounter), VVFBP5)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VV1c0w)
   txt += "%s\n\n%s"    %  (FFrGgO("Result File:", VVtSeQ), newPath)
   FFCxQN(self, txt, title="Accessible Portals")
  elif VVLpbv:
   FFfYN0(self, "No portal access found !", title="Accessible Portals")
 def VV9uox(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFO6Qx(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVTc02(self):
  token, profile, tErr = self.VVYier()
  if token:
   dots = "." * self.VVZAtL
   dots += "+" if self.VVdM78[1:2] == "p" else ""
   VVJ4QS  = self.VV5ul7()
   OKBtnFnc = self.VVsqxU
   VVY1MF = ("Home Menu", FFoI8M)
   VVU5gS= ("Add to Menu", BF(CCCwQV.VVOkup, self, True, self.VVnFHs + "\t" + self.VVFH2j))
   VVaSnd = ("Bookmark Server", BF(CCCwQV.VVPONO, self, True, self.VVnFHs + "\t" + self.VVFH2j))
   FFZP3S(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVFH2j, dots), VVJ4QS=VVJ4QS, OKBtnFnc=OKBtnFnc, VVY1MF=VVY1MF, VVU5gS=VVU5gS, VVaSnd=VVaSnd)
 def VVsqxU(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFlaBE(menuInstance, BF(self.VVWEXf, mode), title="Reading Categories ...")
   else : FFlaBE(menuInstance, BF(self.VV7htH, menuInstance, title), title="Reading Account ...")
 def VV7htH(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VV9bT9(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVFH2j)
  VVcjza  = ("Home Menu" , FFoI8M         , [])
  VV7wPX  = None
  if VVtMJJ:
   VV7wPX = ("Get JS"  , BF(self.VVrQw6, self.VVnFHs), [])
  if totCols == 2:
   VVUB3Q = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVUB3Q = ("More Info.", BF(self.VVhRvr, menuInstance)  , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFA1pv(self, None, title=title, width=1200, header=header, VVITUl=rows, VV7ux5=widths, VVy2kz=26, VVcjza=VVcjza, VV7wPX=VV7wPX, VVUB3Q=VVUB3Q, VV1Y9q="#0a00292B", VVMnLe="#0a002126", VVop6p="#0a002126", VViLdG="#00000000", searchCol=searchCol)
 def VVrQw6(self, url, VVToDv, title, txt, colList):
  FFlaBE(VVToDv, BF(self.VVYZ3C, url), title="Getting JS ...")
 def VVYZ3C(self, url):
  txt = "// Host\t: %s\n" % url
  verOK = False
  ver, err = self.VVlQBf("%s/c/version.js" % url)
  if err:
   txt += err
  else:
   txt += "// Version\t: %s\n\n" % ver
   js, err = self.VVlQBf("%s/c/xpcom.common.js" % url)
   if err: txt += err
   else  : txt += "%s" % js
  FFCxQN(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VVlQBf(self, url):
  res, err = self.VV0PlS(url)
  if err:
   return "", "Error: %s" % err
  else:
   cont = res.headers.get("content-type")
   if "javascript" in cont : return res.text, ""
   else     : return "", "\nError: content-type = %s" % cont
 def VVhRvr(self, menuInstance, VVToDv, title, txt, colList):
  VVToDv.cancel()
  FFlaBE(menuInstance, BF(self.VV7htH, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVWEXf(self, mode):
  token, profile, tErr = self.VVYier()
  if not token:
   return
  res, err = self.VV0PlS(self.VVZ3tZ(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     VVrYfH = CCIrc5()
     chList = tDict["js"]
     for item in chList:
      Id   = CCCwQV.VVfM7o(item, "id"       )
      Title  = CCCwQV.VVfM7o(item, "title"      )
      censored = CCCwQV.VVfM7o(item, "censored"     )
      Title = VVrYfH.VVwk7O(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVtMJJ:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVK6yZ(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VV1Y9q, VVMnLe, VVop6p, VViLdG = self.VVgxNf(mode)
   mName = self.VVK6yZ(mode)
   VVHFFO   = ("Show List"   , BF(self.VVwz14, mode)   , [])
   VVcjza  = ("Home Menu"   , FFoI8M        , [])
   if mode in ("vod", "series"):
    VVbdhP = ("Find in %s" % mName , BF(self.VV3vLn, mode, False), [])
    VVUB3Q = ("Find in Selected" , BF(self.VV3vLn, mode, True) , [])
   else:
    VVbdhP = None
    VVUB3Q = None
   header   = None
   widths   = (100   , 0  )
   FFA1pv(self, None, title=title, width=1200, header=header, VVITUl=list, VV7ux5=widths, VVy2kz=30, VVcjza=VVcjza, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q, VVHFFO=VVHFFO, VV1Y9q=VV1Y9q, VVMnLe=VVMnLe, VVop6p=VVop6p, VViLdG=VViLdG, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VV5wOz:
     txt += "\n\n( %s )" % self.VV5wOz
   else:
    txt = "Could not get Categories from server!"
   FFfYN0(self, txt, title=title)
 def VVwNfg(self, mode, VVToDv, title, txt, colList):
  FFlaBE(VVToDv, BF(self.VVm2ia, mode, VVToDv, title, txt, colList), title="Downloading ...")
 def VVm2ia(self, mode, VVToDv, title, txt, colList):
  token, profile, tErr = self.VVYier()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VV0PlS(self.VV54Wf(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCCwQV.VVfM7o(item, "id"    )
      actors   = CCCwQV.VVfM7o(item, "actors"   )
      added   = CCCwQV.VVfM7o(item, "added"   )
      age    = CCCwQV.VVfM7o(item, "age"   )
      category_id  = CCCwQV.VVfM7o(item, "category_id" )
      description  = CCCwQV.VVfM7o(item, "description" )
      director  = CCCwQV.VVfM7o(item, "director"  )
      genres_str  = CCCwQV.VVfM7o(item, "genres_str"  )
      name   = CCCwQV.VVfM7o(item, "name"   )
      path   = CCCwQV.VVfM7o(item, "path"   )
      screenshot_uri = CCCwQV.VVfM7o(item, "screenshot_uri" )
      series   = CCCwQV.VVfM7o(item, "series"   )
      cmd    = CCCwQV.VVfM7o(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VVHFFO  = ("Play"    , BF(self.VVeE6n, mode)       , [])
   VVXuip = (""     , BF(self.VVSrdZ, mode)     , [])
   VVcjza = ("Home Menu"   , FFoI8M            , [])
   VV7wPX = ("Download Options" , BF(self.VVpM5l, mode, "sp", seriesName) , [])
   VVbdhP = ("Options"   , BF(self.VVDQ2s, "pEp", mode, seriesName) , [])
   VVUB3Q = ("Posters Mode"  , BF(self.VVssv6, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVavJp  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFA1pv(self, None, title=seriesName, width=1200, header=header, VVITUl=list, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VVHFFO=VVHFFO, VVXuip=VVXuip, VVcjza=VVcjza, VV7wPX=VV7wPX, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q, lastFindConfigObj=CFG.lastFindIptv, VV1Y9q="#0a00292B", VVMnLe="#0a002126", VVop6p="#0a002126", VViLdG="#00000000")
  else:
   FFfYN0(self, "Could not get Episodes from server!", title=seriesName)
 def VV3vLn(self, mode, searchInCat, VVToDv, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVJ4QS = []
  VVJ4QS.append(("Keyboard"  , "manualEntry"))
  VVJ4QS.append(("From Filter" , "fromFilter"))
  FFZP3S(self, BF(self.VVBW1U, VVToDv, mode, searchCatId), title="Input Type", VVJ4QS=VVJ4QS, width=400)
 def VVBW1U(self, VVToDv, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFoW9P(self, BF(self.VVZxLa, VVToDv, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCMA5J(self)
    filterObj.VVEg8v(BF(self.VVZxLa, VVToDv, mode, searchCatId))
 def VVZxLa(self, VVToDv, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FFu7KK(CFG.lastFindIptv, searchName)
   title = self.VVU5DT(mode, searchName)
   if "," in searchName : FFfYN0(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FFfYN0(self, "Enter at least 3 characters.", title=title)
   else     :
    VVrYfH = CCIrc5()
    if CFG.hideIptvServerAdultWords.getValue() and VVrYfH.VVswk1([searchName]):
     FFfYN0(self, VVrYfH.VVhcyV(), title=title)
    else:
     self.VVH1A1(mode, searchName, "", searchName, searchCatId)
 def VVwz14(self, mode, VVToDv, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVH1A1(mode, bName, catID, "", "")
 def VVH1A1(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CCwieb, barTheme=CCwieb.VV8xER
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVQStX, mode, bName, catID, searchName, searchCatId)
      , VVGpYx = BF(self.VVHoh3, mode, bName, catID, searchName, searchCatId))
 def VVHoh3(self, mode, bName, catID, searchName, searchCatId, VVLpbv, VV1c0w, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVU5DT(mode, searchName)
  else   : title = "%s : %s" % (self.VVK6yZ(mode), bName)
  if VV1c0w:
   VV7wPX = None
   VVbdhP = None
   if mode == "series":
    VV1Y9q, VVMnLe, VVop6p, VViLdG = self.VVgxNf("series2")
    VVHFFO  = ("Episodes"   , BF(self.VVwNfg, mode)           , [])
   else:
    VV1Y9q, VVMnLe, VVop6p, VViLdG = self.VVgxNf("")
    VVHFFO  = ("Play"    , BF(self.VVeE6n, mode)           , [])
    VV7wPX = ("Download Options" , BF(self.VVpM5l, mode, "vp" if mode == "vod" else "", "") , [])
    VVbdhP = ("Options"   , BF(self.VVDQ2s, "pCh", mode, bName)      , [])
   VVXuip = (""      , BF(self.VVnr9T, mode)         , [])
   VVcjza = ("Home Menu"    , FFoI8M                , [])
   VVUB3Q = ("Posters Mode"   , BF(self.VVssv6, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Category/Genre" , "Logo")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25    , 6  )
   VVavJp  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT    , CENTER)
   VVToDv = FFA1pv(self, None, title=title, header=header, VVITUl=VV1c0w, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VVcjza=VVcjza, VV7wPX=VV7wPX, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q, lastFindConfigObj=CFG.lastFindIptv, VVHFFO=VVHFFO, VVXuip=VVXuip, VV1Y9q=VV1Y9q, VVMnLe=VVMnLe, VVop6p=VVop6p, VViLdG=VViLdG, VVFvoI=True, searchCol=1)
   if not VVLpbv:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVToDv.VVr0zd(VVToDv.VVgfJ7() + tot)
    if threadErr: FFHbVj(VVToDv, "Error while reading !", 2000)
    else  : FFHbVj(VVToDv, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFfYN0(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFfYN0(self, "Could not get list from server !", title=title)
 def VVnr9T(self, mode, VVToDv, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFzeU3(self, fncMode=CCy52I.VVB1Wm, portalHost=self.VVnFHs, portalMac=self.VVFH2j, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVMjjz(mode, VVToDv, title, txt, colList)
 def VVSrdZ(self, mode, VVToDv, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFrGgO(colList[10], VVyLoh)
  txt += "Description:\n%s" % FFrGgO(colList[11], VVyLoh)
  self.VVMjjz(mode, VVToDv, title, txt, colList)
 def VVMjjz(self, mode, VVToDv, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVWxTC(mode, colList)
  refCode, chUrl = self.VVvhj2(self.VVnFHs, self.VVFH2j, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFzeU3(self, fncMode=CCy52I.VVnmYX, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVQStX(self, mode, bName, catID, searchName, searchCatId, VVqtmp):
  try:
   token, profile, tErr = self.VVYier()
   if not token:
    return
   if VVqtmp.isCancelled:
    return
   VVqtmp.VV1c0w, total_items, max_page_items, err = self.VVD1TJ(mode, catID, 1, 1, searchName, searchCatId)
   if VVqtmp.isCancelled:
    return
   if VVqtmp.VV1c0w and total_items > -1 and max_page_items > -1:
    VVqtmp.VVZre9(total_items)
    VVqtmp.VVIW1d(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVqtmp.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVD1TJ(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVqtmp.VVUtKe()
     if VVqtmp.isCancelled:
      return
     if list:
      VVqtmp.VV1c0w += list
      VVqtmp.VVIW1d(len(list), True)
  except:
   pass
 def VVD1TJ(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVNWX2(mode, searchName, searchCatId, page)
  else   : url = self.VVRKjN(mode, catID, page)
  res, err = self.VV0PlS(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVPukI(CCCwQV.VVfM7o(item, "total_items" ))
     max_page_items = self.VVPukI(CCCwQV.VVfM7o(item, "max_page_items" ))
     VVrYfH = CCIrc5()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCCwQV.VVfM7o(item, "id"    )
      name   = CCCwQV.VVfM7o(item, "name"   )
      o_name   = CCCwQV.VVfM7o(item, "o_name"   )
      tv_genre_id  = CCCwQV.VVfM7o(item, "tv_genre_id" )
      number   = CCCwQV.VVfM7o(item, "number"   ) or str(counter)
      logo   = CCCwQV.VVfM7o(item, "logo"   )
      screenshot_uri = CCCwQV.VVfM7o(item, "screenshot_uri" )
      cmd    = CCCwQV.VVfM7o(item, "cmd"   )
      censored  = CCCwQV.VVfM7o(item, "censored"  )
      genres_str  = CCCwQV.VVfM7o(item, "genres_str"  )
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       span = iSearch(r"stream=(.+)&", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
       else:
        span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      isIcon = "Yes" if picon else ""
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVnFHs + picon).replace(sp * 2, sp)
      counter += 1
      name = VVrYfH.VVy0DL(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd, genres_str, isIcon))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVPukI(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVeE6n(self, mode, VVToDv, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVWxTC(mode, colList)
  refCode, chUrl = self.VVvhj2(self.VVnFHs, self.VVFH2j, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VV5DrD(chName):
   FFHbVj(VVToDv, "This is a marker!", 300)
  else:
   FFlaBE(VVToDv, BF(self.VV5mPe, mode, VVToDv, chUrl), title="Playing ...")
 def VV5mPe(self, mode, VVToDv, chUrl):
  FFbrIp(self, chUrl, VVVlLd=False)
  CCKx3s.VVpa1E(self.session, iptvTableParams=(self, VVToDv, mode))
 def VV2Jkg(self, mode, VVToDv, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVWxTC(mode, colList)
  refCode, chUrl = self.VVvhj2(self.VVnFHs, self.VVFH2j, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVWxTC(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVLJ72(SELF):
  try:
   import requests
   return True
  except:
   title = 'Install "Requests"'
   VVJ4QS = []
   VVJ4QS.append((title        , "inst" ))
   VVJ4QS.append(("Update Packages then %s" % title , "updInst" ))
   FFZP3S(SELF, BF(CCuKpK.VVsOcF, SELF), title='This requires Python "Requests" library', VVJ4QS=VVJ4QS)
   return False
 @staticmethod
 def VVsOcF(SELF, item=None):
  if item:
   cmdUpd = FFFOwQ(VVNauh, "")
   if cmdUpd:
    cmdInst = FFMotr(VVi1jL, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFyKCd(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library')
   else:
    FF1KkZ(SELF)
class CCCwQV(Screen, CCuKpK, CCWiTw):
 VVQLfJ    = 0
 VVbl2W    = 1
 VVw98K    = 2
 VVMYp3    = 3
 VVD0LV     = 4
 VVhMzB     = 5
 VVbXTS     = 6
 VVK7vn     = 7
 VVTgUI     = 8
 VV0caJ      = 9
 VVvLYw     = 10
 VV0VFR     = 11
 VVeYQP     = 12
 VVsPui     = 13
 VVMNV3      = 14
 VV8q7P      = 15
 VVJMLg      = 16
 VVOslC      = 17
 VV5OR5      = 18
 VVHnyz    = 0
 VVt6oY   = 1
 VVXQci   = 2
 VVrqLx   = 3
 VVkOl7  = 4
 VVUxLF  = 5
 VV59qS   = 6
 VVITeH   = 7
 VV467U  = 8
 VVTUhb  = 9
 VVIsPU  = 10
 VVSTK0 = 0
 VVIvPt = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFNQkv(VVLAKc, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVToDv    = None
  self.tableTitle     = "IPTV Channels List"
  self.VVr0grData    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CCCwQV.VVplgE(atLeastOne=True)
  self.isFirstTime    = True
  CCuKpK.__init__(self)
  VVJ4QS = self.VV6gQq()
  FFVOCw(self, title="IPTV", VVJ4QS=VVJ4QS)
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self["myMenu"].setList(self.VV6gQq())
  FFJdIh(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFAoMS(self["myMenu"])
   FFI3MP(self)
   if self.m3uOrM3u8File:
    self.VVpaIA(self.m3uOrM3u8File, (0, (), False, ""))
 def VV6gQq(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VV61Yf
  VVJ4QS = []
  if isFav1: VVJ4QS.append((c +  "Favourite Playlist Server"   , "VVpzs5" ))
  if isFav2: VVJ4QS.append((c +  "Favourite Portal Server"    , "VVZAZuPortal" ))
  VVJ4QS.append(("IPTV Server Browser (from Playlists)"     , "VVr0gr_fromPlayList" ))
  VVJ4QS.append(("IPTV Server Browser (from Portal List)"    , "VVr0gr_fromMac"  ))
  VVJ4QS.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VVr0gr_fromM3u"  ))
  qUrl, iptvRef = self.VVeMIi()
  item = "IPTV Server Browser (from Current Channel)"
  if qUrl or "chCode" in iptvRef : VVJ4QS.append((item     , "VVr0gr_fromCurrChan" ))
  else       : VVJ4QS.append((item     ,       ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("M3U/M3U8 File Browser"        , "VVvzvs"   ))
  if self.iptvFileAvailable:
   VVJ4QS.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVJ4QS.append(VV4c5n)
  item1 = "Update Current Bouquet EPG (from IPTV Server)"
  item2 = "Update Current Bouquet PIcons (from IPTV Server)"
  if qUrl or "chCode" in iptvRef:
   VVJ4QS.append((item1            , "refreshIptvEPG"   ))
   VVJ4QS.append((item2            , "refreshIptvPicons"  ))
  else:
   VVJ4QS.append((item1            ,       ))
   VVJ4QS.append((item2            ,       ))
  if self.iptvFileAvailable:
   VVJ4QS.append(VV4c5n)
   c1, c2 = VVxpap, VVtSeQ
   t1 = FFrGgO("auto-match names", VV61Yf)
   t2 = FFrGgO("from xml file"  , VV61Yf)
   VVJ4QS.append((c1 + "Count Available IPTV Channels"    , "VVIMw9"    ))
   VVJ4QS.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVJ4QS.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VVFcdg" ))
   VVJ4QS.append((VVPUgM + "More Reference Tools ..."  , "VVhIsR"   ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Reload Channels and Bouquets"       , "VVH6bN"   ))
  VVJ4QS.append(VV4c5n)
  if not CCjOMG.VVQeoC():
   VVJ4QS.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVJ4QS.append(("Download Manager ... No donwloads"    ,       ))
  return VVJ4QS
 def VVgSzF(self, item):
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVF0R1"   : self.VVF0R1()
   elif item == "VVEXM0" : FFZw7B(self, self.VVEXM0, "Change Current List References to Unique Codes ?")
   elif item == "VVerWV_rows" : FFZw7B(self, BF(FFlaBE, self.VVToDv, self.VVerWV), "Change Current List References to Identical Codes ?")
   elif item == "VV78oO"   : self.VV78oO(tTitle)
   elif item == "VVq9ad"   : self.VVq9ad(tTitle)
   elif item == "VVpzs5" : self.VVZAZu(False)
   elif item == "VVZAZuPortal" : self.VVZAZu(True)
   elif item == "VVr0gr_fromPlayList" : FFlaBE(self, BF(self.VV64EJ, 1), title=title)
   elif item == "VVr0gr_fromM3u"  : FFlaBE(self, BF(self.VV48XX, 0), title=title)
   elif item == "VVr0gr_fromMac"  : self.VVvLlA()
   elif item == "VVr0gr_fromCurrChan" : self.VVmaZX()
   elif item == "VVvzvs"   : self.VVvzvs()
   elif item == "iptvTable_all"   : FFlaBE(self, BF(self.VVohil, self.VVQLfJ), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VVnYg1()
   elif item == "refreshIptvPicons"  : self.VVgGze()
   elif item == "VVIMw9"    : FFlaBE(self, self.VVIMw9)
   elif item == "copyEpgPicons"   : self.VVBrCr(False)
   elif item == "renumIptvRef_fromFile" : self.VVBrCr(True)
   elif item == "VVFcdg" : FFZw7B(self, BF(FFlaBE, self, self.VVFcdg), VVgyFZ="Continue ?")
   elif item == "VVhIsR"    : self.VVhIsR()
   elif item == "VVH6bN"   : FFlaBE(self, BF(CCpE07.VVH6bN, self))
   elif item == "dload_stat"    : CCjOMG.VVUHLU(self)
 def VVvzvs(self):
  if CCuKpK.VVLJ72(self):
   FFlaBE(self, BF(self.VV48XX, 1), title="Searching ...")
 def VVfFPM(self):
  global VVnWCp
  VVnWCp = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVgSzF(item)
 def VVohil(self, mode):
  VVjhh4 = self.VVDeuO(mode)
  if VVjhh4:
   VV7wPX = ("Current Service", self.VVvpdD , [])
   VVbdhP = ("Options"  , self.VV7bH2   , [])
   VVUB3Q = ("Filter"   , self.VV8qlg   , [])
   VVHFFO  = ("Play"   , BF(self.VVekvH)  , [])
   VVXuip = (""    , self.VVHjHt    , [])
   VVcwgo = (""    , self.VV54is     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VVavJp  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FFA1pv(self, None, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26
     , VVHFFO=VVHFFO, VV7wPX=VV7wPX, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q, VVXuip=VVXuip, VVcwgo=VVcwgo
     , VV1Y9q="#0a00292B", VVMnLe="#0a002126", VVop6p="#0a002126", VViLdG="#00000000", VVFvoI=True, searchCol=1)
  else:
   if mode == self.VVTgUI: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFfYN0(self, err)
 def VV54is(self, VVToDv, title, txt, colList):
  self.VVToDv = VVToDv
 def VV7bH2(self, VVToDv, title, txt, colList):
  VVJ4QS = []
  VVJ4QS.append(("Add Current List to a New Bouquet"    , "VVF0R1"  ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Change Current List References to Unique Codes" , "VVEXM0"))
  VVJ4QS.append(("Change Current List References to Identical Codes", "VVerWV_rows" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Share Reference with DVB Service (manual entry)" , "VV78oO"   ))
  VVJ4QS.append(("Share Reference with DVB Service (auto-find)"  , "VVq9ad"   ))
  FFZP3S(self, self.VVgSzF, title="IPTV Tools", VVJ4QS=VVJ4QS)
 def VV8qlg(self, VVToDv, title, txt, colList):
  VVJ4QS = []
  VVJ4QS.append(("All"         , "all"   ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Prefix of Selected Channel"   , "sameName" ))
  VVJ4QS.append(("Suggest Words from Selected Channel" , "partName" ))
  VVJ4QS.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVJ4QS.append(("Duplicate References"     , "depRef"  ))
  VVJ4QS.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVJ4QS.append(FFksVn("Category"))
  VVJ4QS.append(("Live TV"        , "live"  ))
  VVJ4QS.append(("VOD"         , "vod"   ))
  VVJ4QS.append(("Series"        , "series"  ))
  VVJ4QS.append(("Uncategorised"      , "uncat"  ))
  VVJ4QS.append(FFksVn("Media"))
  VVJ4QS.append(("Video"        , "video"  ))
  VVJ4QS.append(("Audio"        , "audio"  ))
  VVJ4QS.append(FFksVn("File Type"))
  VVJ4QS.append(("MKV"         , "MKV"   ))
  VVJ4QS.append(("MP4"         , "MP4"   ))
  VVJ4QS.append(("MP3"         , "MP3"   ))
  VVJ4QS.append(("AVI"         , "AVI"   ))
  VVJ4QS.append(("FLV"         , "FLV"   ))
  VVJ4QS.extend(CC54zE.VVtYge(prefix="__b__"))
  inFilterFnc = BF(self.VVq7JM, VVToDv) if VVToDv.VVgfJ7().startswith("IPTV Filter ") else None
  filterObj = CCMA5J(self)
  filterObj.VVvh0P(VVJ4QS, VVJ4QS, BF(self.VV4j3O, VVToDv, False), inFilterFnc=inFilterFnc)
 def VVq7JM(self, VVToDv, menuInstance, item):
  self.VV4j3O(VVToDv, True, item)
 def VV4j3O(self, VVToDv, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVToDv.VVzQU4(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVQLfJ , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVbl2W , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVw98K , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVMYp3 , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVbXTS  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VVK7vn  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "live"    : mode, words, title = self.VVTgUI  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VV0caJ   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVvLYw  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VV0VFR  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVeYQP  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVsPui  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVMNV3   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VV8q7P   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVJMLg   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVOslC   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VV5OR5   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVD0LV  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVhMzB  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVw98K:
   VVJ4QS = []
   chName = VVToDv.VVzQU4(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVJ4QS.append((item, item))
    if not VVJ4QS and chName:
     VVJ4QS.append((chName, chName))
    FFZP3S(self, BF(self.VVSrbQ, title), title="Words from Current Selection", VVJ4QS=VVJ4QS)
   else:
    VVToDv.VVB7wY("Invalid Channel Name")
  else:
   words, asPrefix = CCMA5J.VVBkhG(words)
   if not words and mode in (self.VVD0LV, self.VVhMzB):
    FFHbVj(self.VVToDv, "Incorrect filter", 2000)
   else:
    FFlaBE(self.VVToDv, BF(self.VVzjsi, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVSrbQ(self, title, word=None):
  if word:
   words = [word.lower()]
   FFlaBE(self.VVToDv, BF(self.VVzjsi, self.VVw98K, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVykfS(txt):
  return "#f#11ffff00#" + txt
 def VVzjsi(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVjhh4 = self.VVoRnS(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVjhh4 = self.VVDeuO(mode=mode, words=words, asPrefix=asPrefix)
  if VVjhh4 : self.VVToDv.VV3ih0(VVjhh4, title)
  else  : self.VVToDv.VVB7wY("Not found")
 def VVoRnS(self, mode=0, words=None, asPrefix=False):
  VVjhh4 = []
  for row in self.VVToDv.VVF8iU():
   row = list(map(str.strip, row))
   chNum, chName, VVBAfT, chType, refCode, url = row
   if self.VVzYIC(mode, refCode, FFaTzZ(url).lower(), chName, words, VVBAfT.lower(), asPrefix):
    VVjhh4.append(row)
  VVjhh4 = self.VVdpzk(mode, VVjhh4)
  return VVjhh4
 def VVDeuO(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVjhh4 = []
  files  = self.VVJtZM()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFZF5l(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVBAfT = span.group(1)
    else : VVBAfT = ""
    VVBAfT_lCase = VVBAfT.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VV5DrD(chName): chNameMod = self.VVykfS(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVBAfT, chType, refCode, url)
     if self.VVzYIC(mode, refCode, FFaTzZ(url).lower(), chName, words, VVBAfT_lCase, asPrefix):
      VVjhh4.append(row)
      chNum += 1
  VVjhh4 = self.VVdpzk(mode, VVjhh4)
  return VVjhh4
 def VVdpzk(self, mode, VVjhh4):
  newRows = []
  if VVjhh4 and mode == self.VVbXTS:
   from collections import Counter
   counted  = Counter(elem[4] for elem in VVjhh4)
   for item in VVjhh4:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVjhh4
 def VVzYIC(self, mode, refCode, tUrl, chName, words, VVBAfT_lCase, asPrefix):
  if   mode == self.VVQLfJ : return True
  elif mode == self.VVbXTS : return True
  elif mode == self.VVK7vn  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VVeYQP  : return CCCwQV.VVY4JM(tUrl, getAudVid=True) == "vid"
  elif mode == self.VVsPui  : return CCCwQV.VVY4JM(tUrl, getAudVid=True) == "aud"
  elif mode == self.VVTgUI  : return CCCwQV.VVY4JM(tUrl, compareType="live")
  elif mode == self.VV0caJ  : return CCCwQV.VVY4JM(tUrl, compareType="movie")
  elif mode == self.VVvLYw : return CCCwQV.VVY4JM(tUrl, compareType="series")
  elif mode == self.VV0VFR  : return CCCwQV.VVY4JM(tUrl, compareType="")
  elif mode == self.VVMNV3  : return CCCwQV.VVY4JM(tUrl, compareExt="mkv")
  elif mode == self.VV8q7P  : return CCCwQV.VVY4JM(tUrl, compareExt="mp4")
  elif mode == self.VVJMLg  : return CCCwQV.VVY4JM(tUrl, compareExt="mp3")
  elif mode == self.VVOslC  : return CCCwQV.VVY4JM(tUrl, compareExt="avi")
  elif mode == self.VV5OR5  : return CCCwQV.VVY4JM(tUrl, compareExt="flv")
  elif mode == self.VVbl2W: return chName.lower().startswith(words[0])
  elif mode == self.VVw98K: return words[0] in chName.lower()
  elif mode == self.VVMYp3: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVD0LV : return words[0] == VVBAfT_lCase
  elif mode == self.VVhMzB :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVF0R1(self):
  picker = CC54zE(self, self.VVToDv, "Add to Bouquet", self.VVw7g1)
 def VVw7g1(self):
  chUrlLst = []
  for row in self.VVToDv.VVF8iU():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VVhIsR(self):
  c1 = VV6svy
  t1 = FFrGgO("Bouquet", VV61Yf)
  t2 = FFrGgO("ALL", VV61Yf)
  refTxt = "(1/4097/5001/5002/8192/8193)"
  VVJ4QS = []
  VVJ4QS.append((c1 + "Check System Acceptable Reference Types" , "VVZg46"    ))
  if self.iptvFileAvailable:
   VVJ4QS.append((c1 + "Check Reference Codes Format"  , "VVbJoF"    ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(('Change %s Ref. Types to %s ..' % (t1, refTxt) , "VV0p7X" ))
  VVJ4QS.append(('Change %s Ref. Types to %s ..' % (t2, refTxt) , "VVTNNc_all"  ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Change %s References to Unique Codes" % t2 , "VVKQ4d"  ))
  VVJ4QS.append(("Change %s References to Identical Codes" % t2 , "VVerWV_all"  ))
  OKBtnFnc = self.VVFmtO
  FFZP3S(self, None, width=1200, title="Reference Tools", VVJ4QS=VVJ4QS, OKBtnFnc=OKBtnFnc)
 def VVFmtO(self, item=None):
  if item:
   ques = "Continue ?"
   menuInstance, txt, item, ndx = item
   if   item == "VVZg46"    : FFlaBE(menuInstance, self.VVZg46)
   elif item == "VVbJoF"     : FFlaBE(menuInstance, self.VVbJoF)
   elif item == "VV0p7X" : self.VV0p7X(menuInstance)
   elif item == "VVTNNc_all"  : self.VV4T3N(menuInstance, None, None)
   elif item == "VVKQ4d"  : FFZw7B(self, BF(self.VVKQ4d , menuInstance, txt), title=txt, VVgyFZ=ques)
   elif item == "VVerWV_all"  : FFZw7B(self, BF(FFlaBE, menuInstance, self.VVerWV), title=txt, VVgyFZ=ques)
 def VV4T3N(self, menuInstance, bName, bPath):
  txt = "Stream Type "
  VVJ4QS = []
  VVJ4QS.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVJ4QS.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVJ4QS.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVJ4QS.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVJ4QS.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVJ4QS.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFZP3S(self, BF(self.VVAhfY, menuInstance, bName, bPath), width=750, title="Change Reference Types to:", VVJ4QS=VVJ4QS)
 def VVAhfY(self, menuInstance, bName, bPath, item=None):
  if item:
   if   item == "RT_1"  : self.VVHGg3(menuInstance, bName, bPath, "1"   )
   elif item == "RT_4097" : self.VVHGg3(menuInstance, bName, bPath, "4097")
   elif item == "RT_5001" : self.VVHGg3(menuInstance, bName, bPath, "5001")
   elif item == "RT_5002" : self.VVHGg3(menuInstance, bName, bPath, "5002")
   elif item == "RT_8192" : self.VVHGg3(menuInstance, bName, bPath, "8192")
   elif item == "RT_8193" : self.VVHGg3(menuInstance, bName, bPath, "8193")
 def VV0p7X(self, menuInstance):
  VVJ4QS = CC54zE.VVtYge()
  if VVJ4QS:
   FFZP3S(self, BF(self.VVyCvp, menuInstance), VVJ4QS=VVJ4QS, title="IPTV Bouquets", VV7GES=True)
  else:
   FFHbVj(menuInstance, "No bouquets Found !", 1500)
 def VVyCvp(self, menuInstance, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVoDv6 + span.group(1)
    if fileExists(bPath): self.VV4T3N(menuInstance, bName, bPath)
    else    : FFHbVj(menuInstance, "Bouquet file not found!", 2000)
   else:
    FFHbVj(menuInstance, "Cannot process bouquet !", 2000)
 def VVHGg3(self, menuInstance, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FFrGgO(bName, VVy0iZ)
  else : title = "Change for %s" % FFrGgO("All IPTV Services", VVy0iZ)
  FFZw7B(self, BF(FFlaBE, menuInstance, BF(self.VVv8vl, menuInstance, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FFrGgO(rType, VVy0iZ), title=title)
 def VVv8vl(self, menuInstance, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = self.VVJtZM()
  if files:
   newRType = rType + ":"
   piconPath = CC8ahC.VVmFFX()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CCqXgM.VV7Hvo(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FFfYN0(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           os.system(FFyto6("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png")))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    os.system(FFyto6(cmd))
  self.VVSrTF(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VVIMw9(self):
  totFiles = 0
  files  = self.VVJtZM()
  if files:
   totFiles = len(files)
  totChans = 0
  VVjhh4 = self.VVDeuO()
  if VVjhh4:
   totChans = len(VVjhh4)
  FFCxQN(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVbJoF(self):
  files  = self.VVJtZM()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFZF5l(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVqQXm
   else    : color = VVFBP5
   totInvalid = FFrGgO(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFrGgO("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFCxQN(self, txt, title="Check IPTV References")
 def VVZg46(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  chUrlLst  = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CC54zE.VV5b6v(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VV1mHV = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VV1mHV:
   VVJSeO = FF5CZv(VV1mHV)
   if VVJSeO:
    for service in VVJSeO:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVoDv6 + userBName
  bFile = VVoDv6 + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFyto6("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFyto6("rm -f '%s'" % path)
  os.system(cmd)
  FFpUU8()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVqQXm
    else     : res, color = "No" , VVFBP5
    txt += "    %s\t: %s\n" % (item, FFrGgO(res, color))
   FFCxQN(self, txt, title=title)
  else:
   txt = FFfYN0(self, "Could not complete the test on your system!", title=title)
 def VVFcdg(self):
  VVUIlQ, err = CCpE07.VV5WFr(self, CCpE07.VVVgns)
  if VVUIlQ:
   totChannels = 0
   totChange = 0
   for path in self.VVJtZM():
    toSave = False
    txt = FFZF5l(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVUIlQ.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVSrTF(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFfYN0(self, 'No channels in "lamedb" !')
 def VVKQ4d(self, menuInstance, title):
  bFiles = self.VVJtZM()
  if bFiles:
   self.session.open(CCwieb, barTheme=CCwieb.VVkrqu
       , titlePrefix = "Renumbering References"
       , fncToRun  = BF(self.VVGpTO, bFiles)
       , VVGpYx = BF(self.VVe4yi, title))
  else:
   FFHbVj(menuInstance, "No bouquets files !", 1500)
 def VVGpTO(self, bFiles, VVqtmp):
  VVqtmp.VV1c0w = ""
  VVqtmp.VVhQo4("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FFup4P(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVqtmp or VVqtmp.isCancelled:
   return
  elif not totLines:
   VVqtmp.VV1c0w = "No IPTV Services !"
   return
  else:
   VVqtmp.VVZre9(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVqtmp or VVqtmp.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FFup4P(path)
    for ndx, line in enumerate(lines):
     if not VVqtmp or VVqtmp.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVqtmp:
       VVqtmp.VVhQo4("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVqtmp:
       VVqtmp.VVIW1d(1)
      refCode, startId, startNS = CC54zE.VVXkSD(rType, CC54zE.VV3SYF, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVqtmp:
        VVqtmp.VV1c0w = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VVe4yi(self, title, VVLpbv, VV1c0w, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VV1c0w:
   txt += "\n\n%s\n%s" % (FFrGgO("Ended with Error:", VVFBP5), VV1c0w)
  self.VVSrTF(True, title, txt)
 def VVEXM0(self):
  bFiles = self.VVJtZM()
  if not bFiles:
   FFHbVj(self.VVToDv, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVToDv.VVF8iU():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FFHbVj(self.VVToDv, "Cannot read list", 1500)
   return
  self.session.open(CCwieb, barTheme=CCwieb.VVkrqu
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VV6GAK, bFiles, tableRefList)
      , VVGpYx = BF(self.VVe4yi, "Change Current List References to Unique Codes"))
 def VV6GAK(self, bFiles, tableRefList, VVqtmp):
  VVqtmp.VV1c0w = ""
  VVqtmp.VVhQo4("Reading System References ...")
  refLst = CC54zE.VVZjqZ(CC54zE.VV3SYF, stripRType=True)
  if not VVqtmp or VVqtmp.isCancelled:
   return
  VVqtmp.VVZre9(len(tableRefList))
  rType  = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVqtmp or VVqtmp.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFZF5l(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVqtmp or VVqtmp.isCancelled:
     return
    VVqtmp.VVhQo4("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVqtmp or VVqtmp.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVqtmp.VVIW1d(1)
      refCode, startId, startNS = CC54zE.VVXkSD(rType, CC54zE.VV3SYF, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVqtmp:
        VVqtmp.VV1c0w = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VVerWV(self):
  list = None
  if self.VVToDv:
   list = []
   for row in self.VVToDv.VVF8iU():
    list.append(row[4] + row[5])
  files  = self.VVJtZM()
  totChange = 0
  if files:
   for path in files:
    lines = FFup4P(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VVSrTF(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVSrTF(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFpUU8()
   if refreshTable and self.VVToDv:
    VVjhh4 = self.VVDeuO()
    if VVjhh4 and self.VVToDv:
     self.VVToDv.VV3ih0(VVjhh4, self.tableTitle)
     self.VVToDv.VVB7wY(txt)
   FFCxQN(self, txt, title=title)
  else:
   FF8O6K(self, "No changes.")
 def VVJtZM(self):
  return CCCwQV.VVplgE()
 @staticmethod
 def VVplgE(atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVoDv6 + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFZF5l(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVHjHt(self, VVToDv, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFaTzZ(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFzeU3(self, fncMode=CCy52I.VVl5vO, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVoFIv(self, VVToDv, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVekvH(self, VVToDv, title, txt, colList):
  chName, chUrl = self.VVoFIv(VVToDv, colList)
  self.VVn5dI(VVToDv, chName, chUrl, "localIptv")
 def VVLVOl(self, mode, VVToDv, colList):
  chName, chUrl, picUrl, refCode = self.VVNHXJ(mode, colList)
  return chName, chUrl
 def VVoCiN(self, mode, VVToDv, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVNHXJ(mode, colList)
  self.VVn5dI(VVToDv, chName, chUrl, mode)
 def VVn5dI(self, VVToDv, chName, chUrl, playerFlag):
  chName = FFVK2H(chName)
  if self.VV5DrD(chName):
   FFHbVj(VVToDv, "This is a marker!", 300)
  else:
   FFlaBE(VVToDv, BF(self.VVznVV, VVToDv, chUrl, playerFlag), title="Playing ...")
 def VVznVV(self, VVToDv, chUrl, playerFlag):
  FFbrIp(self, chUrl, VVVlLd=False)
  CCKx3s.VVpa1E(self.session, iptvTableParams=(self, VVToDv, playerFlag))
 @staticmethod
 def VV5DrD(chName):
  mark = ("--", "__", "==", "##",  "**", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVvpdD(self, VVToDv, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self)
  if refCode:
   url1 = FFaTzZ(origUrl.strip())
   for ndx, row in enumerate(VVToDv.VVF8iU()):
    if refCode in row[4]:
     tableRow = FFaTzZ(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVToDv.VVeb2k(ndx)
      break
   else:
    FFHbVj(VVToDv, "No found", 1000)
 def VV48XX(self, m3uMode):
  lines = self.VVikZa(3)
  if lines:
   lines.sort()
   VVJ4QS = []
   for line in lines:
    VVJ4QS.append((line, line))
   if m3uMode == self.VVSTK0:
    title = "Browse Server from M3U URLs"
    VVaSnd = ("All to Playlist", self.VVfrXB)
   else:
    title = "M3U/M3U8 File Browser"
    VVaSnd = None
   OKBtnFnc = BF(self.VVncX8, m3uMode, title)
   VV5lv1  = ("Show Full Path", self.VVSkHI)
   VVU5gS = ("Delete File", self.VVA63w)
   FFZP3S(self, None, title=title, VVJ4QS=VVJ4QS, width=1200, OKBtnFnc=OKBtnFnc, VV5lv1=VV5lv1, VVU5gS=VVU5gS, VVaSnd=VVaSnd, VV1Y9q="#11221122", VVMnLe="#11221122")
 def VVncX8(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == self.VVSTK0:
    FFlaBE(menuInstance, BF(self.VVM298, title, path))
   else:
    self.VVpn9Z(menuInstance, path)
 def VVpn9Z(self, menuInstance, path=None):
  if path:
   VVJ4QS = []
   VVJ4QS.append(("All"         , "all"   ))
   VVJ4QS.append(FFksVn("Category"))
   VVJ4QS.append(("Live TV"        , "live"  ))
   VVJ4QS.append(("VOD"         , "vod"   ))
   VVJ4QS.append(("Series"        , "series"  ))
   VVJ4QS.append(("Uncategorised"      , "uncat"  ))
   VVJ4QS.append(FFksVn("Media"))
   VVJ4QS.append(("Video"        , "video"  ))
   VVJ4QS.append(("Audio"        , "audio"  ))
   VVJ4QS.append(FFksVn("File Type"))
   VVJ4QS.append(("MKV"         , "MKV"   ))
   VVJ4QS.append(("MP4"         , "MP4"   ))
   VVJ4QS.append(("MP3"         , "MP3"   ))
   VVJ4QS.append(("AVI"         , "AVI"   ))
   VVJ4QS.append(("FLV"         , "FLV"   ))
   filterObj = CCMA5J(self, VV1Y9q="#11552233", VVMnLe="#11552233")
   filterObj.VVvh0P(VVJ4QS, [], BF(self.VVsApl, menuInstance, path), inFilterFnc=None)
 def VVsApl(self, menuInstance, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VVQLfJ , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VVTgUI  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VV0caJ  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VVvLYw  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VV0VFR  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VVeYQP  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VVsPui  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VVMNV3  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VV8q7P  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VVJMLg  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVOslC  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VV5OR5  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVhMzB  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CCMA5J.VVBkhG(words)
   if not mode == self.VVQLfJ:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FFrGgO(fTitle, VVyLoh)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FFlaBE(menuInstance, BF(self.VVpaIA, path, m3uFilterParam))
 def VVpaIA(self, srcPath, m3uFilterParam):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFZF5l(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  VVrYfH = CCIrc5()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVVNkK(propLine, "group-title") or "-"
   if not group == "-" and VVrYfH.VVy0DL(group):
    groups.add(group)
  VVjhh4 = []
  if len(groups) > 0:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   for group in groups:
    VVjhh4.append((group, group))
   VVjhh4.append(("ALL", ""))
   VVjhh4.sort(key=lambda x: x[0].lower())
   VVzffX = self.VVUWBT
   VVHFFO  = ("Select" , BF(self.VVD0g8, srcPath, m3uFilterParam), [])
   widths   = (100  , 0)
   VVavJp  = (LEFT  , LEFT)
   FFA1pv(self, None, title=title, width= 1000, header=None, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=30, VVHFFO=VVHFFO, VVzffX=VVzffX, lastFindConfigObj=CFG.lastFindIptv
     , VV1Y9q="#11110022", VVMnLe="#11110022", VVop6p="#11110022", VViLdG="#00444400")
  else:
   txt = FFZF5l(srcPath)
   self.VVvLuz(txt, "", m3uFilterParam)
 def VVD0g8(self, srcPath, m3uFilterParam, VVToDv, title, txt, colList):
  group = colList[1]
  txt = FFZF5l(srcPath)
  self.VVvLuz(txt, group, m3uFilterParam)
 def VVvLuz(self, txt, filterGroup="", m3uFilterParam=None):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CCwieb, barTheme=CCwieb.VV8xER
       , titlePrefix = "Reading File Lines"
       , fncToRun  = BF(self.VVZ94c, lst, filterGroup, m3uFilterParam)
       , VVGpYx = BF(self.VV1sB1, title, bName))
  else:
   self.VVIjQH("Not valid lines found !", title)
 def VVZ94c(self, lst, filterGroup, m3uFilterParam, VVqtmp):
  VVqtmp.VV1c0w = []
  VVqtmp.VVZre9(len(lst))
  VVrYfH = CCIrc5()
  num = 0
  for cols in lst:
   if not VVqtmp or VVqtmp.isCancelled:
    return
   VVqtmp.VVIW1d(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVVNkK(propLine, "tvg-logo")
   group = self.VVVNkK(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not VVrYfH.VVy0DL(group) : skip = True
    elif chName and not VVrYfH.VVy0DL(chName) : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VVzYIC(mode, "", FFaTzZ(url).lower(), chName, words, "", asPrefix)
    if not skip and VVqtmp:
     num += 1
     VVqtmp.VV1c0w.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if VVqtmp:
   VVqtmp.VVtvgL("Loading %d Channels" % len(VVqtmp.VV1c0w))
 def VV1sB1(self, title, bName, VVLpbv, VV1c0w, threadCounter, threadTotal, threadErr):
  if VV1c0w:
   VVzffX = self.VVUWBT
   VVHFFO  = ("Select"   , BF(self.VVdKyN, title)   , [])
   VVXuip = (""    , self.VV2eDS        , [])
   VV7wPX = ("Download PIcons", self.VVKmja       , [])
   VVbdhP = ("Options"  , BF(self.VVDQ2s, "m3Ch", "", bName) , [])
   VVUB3Q = ("Posters Mode" , BF(self.VVssv6, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVavJp  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFA1pv(self, None, title=title, header=header, VVITUl=VV1c0w, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=28, VVHFFO=VVHFFO, VVzffX=VVzffX, VVXuip=VVXuip, VV7wPX=VV7wPX, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q, lastFindConfigObj=CFG.lastFindIptv, VVFvoI=True, searchCol=1
     , VV1Y9q="#0a00192B", VVMnLe="#0a00192B", VVop6p="#0a00192B", VViLdG="#00000000")
  else:
   self.VVIjQH("Not found !", title)
 def VVKmja(self, VVToDv, title, txt, colList):
  self.VVW7RV(VVToDv, "m3u/m3u8")
 def VVFYIt(self, rowNum, url, chName):
  refCode = self.VVVKqm(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFjRDJ(url), chName)
  return chUrl
 def VVVKqm(self, rowNum, url, chName):
  span = iSearch(r"\/(\d{2,})", url, IGNORECASE)
  if span : stID = span.group(1)
  else : stID = "444"
  catID = "333"
  chNum = str(rowNum + 1)
  refCode = self.VVSsc4(catID, stID, chNum)
  return refCode
 def VVVNkK(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVdKyN(self, Title, VVToDv, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFlaBE(VVToDv, BF(self.VVm5VD, Title, VVToDv, colList), title="Checking Server ...")
  else:
   self.VVPrdY(VVToDv, url, chName)
 def VVm5VD(self, title, VVToDv, colList):
  if not CCuKpK.VVLJ72(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCHEQq.VVcpBl(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVJ4QS = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCCwQV.VVoleU(url, fPath)
     VVJ4QS.append((resol, fullUrl))
    if VVJ4QS:
     if len(VVJ4QS) > 1:
      FFZP3S(self, BF(self.VVqWrd, VVToDv, chName), VVJ4QS=VVJ4QS, title="Resolution", VV7GES=True, VVbHGu=True)
     else:
      self.VVPrdY(VVToDv, VVJ4QS[0][1], chName)
    else:
     self.VVF7Fx("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVvLuz(txt, filterGroup="")
      return
    self.VVPrdY(VVToDv, url, chName)
   else:
    self.VVIjQH("Cannot process this channel !", title)
  else:
   self.VVIjQH(err, title)
 def VVqWrd(self, VVToDv, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVPrdY(VVToDv, resolUrl, chName)
 def VVPrdY(self, VVToDv, url, chName):
  FFlaBE(VVToDv, BF(self.VVFaK0, VVToDv, url, chName), title="Playing ...")
 def VVFaK0(self, VVToDv, url, chName):
  chUrl = self.VVFYIt(VVToDv.VVYt3A(), url, chName)
  FFbrIp(self, chUrl, VVVlLd=False)
  CCKx3s.VVpa1E(self.session, iptvTableParams=(self, VVToDv, "m3u/m3u8"))
 def VVwVBX(self, VVToDv, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVFYIt(VVToDv.VVYt3A(), url, chName)
  return chName, chUrl
 def VV2eDS(self, VVToDv, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFzeU3(self, fncMode=CCy52I.VVl5vO, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVIjQH(self, err, title):
  FFfYN0(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVUWBT(self, VVToDv):
  if self.m3uOrM3u8File:
   self.close()
  VVToDv.cancel()
 def VVfrXB(self, VVi8BRObj, item=None):
  FFlaBE(VVi8BRObj, BF(self.VVe30p, VVi8BRObj, item))
 def VVe30p(self, VVi8BRObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVi8BRObj.VVJ4QS):
    path = item[1]
    if fileExists(path):
     enc = CC7qa7.VV6aJR(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VVa2Nh(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCCwQV.VV1xkO()
    pListF = "%sPlaylist_%s.txt" % (path, FFSZ6D())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVi8BRObj.VVJ4QS)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFCxQN(self, txt, title=title)
   else:
    FFfYN0(self, "Could not obtain URLs from this file list !", title=title)
 def VV64EJ(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVvKR5
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VVuQyK
  lines = self.VVikZa(mode)
  if lines:
   lines.sort()
   VVJ4QS = []
   for line in lines:
    VVJ4QS.append((FFrGgO(line, VVtSeQ) if "Bookmarks" in line else line, line))
   VVU5gS = ("Delete File", self.VVA63w)
   VV5lv1  = ("Show Full Path", self.VVSkHI)
   FFZP3S(self, None, title=title, VVJ4QS=VVJ4QS, width=1200, OKBtnFnc=okFnc, VV5lv1 =VV5lv1 , VVU5gS=VVU5gS)
 def VVSkHI(self, menuInstance, url):
  FFCxQN(self, url, title="Full Path")
 def VVA63w(self, VVi8BRObj, path):
  FFZw7B(self, BF(self.VVwgBt, VVi8BRObj, path), "Delete this file ?\n\n%s" % path)
 def VVwgBt(self, VVi8BRObj, path):
  FFM75P(path)
  if fileExists(path) : FFHbVj(VVi8BRObj, "Not deleted", 1000)
  else    : VVi8BRObj.VVZEkP()
 def VVvKR5(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFlaBE(menuInstance, BF(self.VVUdRn, menuInstance, path), title="Processing File ...")
 def VVUdRn(self, VVOsSR, path):
  enc = CC7qa7.VV6aJR(path, self)
  if enc == -1:
   return
  VVjhh4 = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFegwS(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCCwQV.VVhOf8(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVjhh4:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVjhh4.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVjhh4:
   title = "Playlist File : %s" % os.path.basename(path)
   VVHFFO  = ("Start"    , BF(self.VV0ob8, "Playlist File")      , [])
   VVcjza = ("Home Menu"   , FFoI8M             , [])
   VV7wPX = ("Download M3U File" , self.VVT04e         , [])
   VVbdhP = ("Edit File"   , BF(self.VVt8aw, path)        , [])
   VVUB3Q = ("Check & Filter"  , BF(self.VVSNgT, VVOsSR, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVavJp  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFA1pv(self, None, title=title, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VVHFFO=VVHFFO, VVcjza=VVcjza, VVUB3Q=VVUB3Q, VV7wPX=VV7wPX, VVbdhP=VVbdhP, VV1Y9q="#11001116", VVMnLe="#11001116", VVop6p="#11001116", VViLdG="#00003635", VVmDPu="#0a333333", VV15Y9="#11331100", VVFvoI=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FFfYN0(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVT04e(self, VVToDv, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFZw7B(self, BF(FFlaBE, VVToDv, BF(self.VVPw4f, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVPw4f(self, title, url):
  path, err = FFSAwr(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFfYN0(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFZF5l(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFM75P(path)
    FFfYN0(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFM75P(path)
    FFfYN0(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCCwQV.VV1xkO() + fName
    os.system(FFyto6("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FF8O6K(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFfYN0(self, "Could not download the M3U file!", title=errTitle)
 def VV0ob8(self, Title, VVToDv, title, txt, colList):
  url = colList[6]
  FFlaBE(VVToDv, BF(self.VV67Mo, Title, url), title="Checking Server ...")
 def VVt8aw(self, path, VVToDv, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCbzSm(self, path, VVGpYx=BF(self.VVshM5, VVToDv), curRowNum=rowNum)
  else    : FF6vdZ(self, path)
 def VVshM5(self, VVToDv, fileChanged):
  if fileChanged:
   VVToDv.cancel()
 def VV78oO(self, title):
  curChName = self.VVToDv.VVzQU4(1)
  FFoW9P(self, BF(self.VVEZKI, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVEZKI(self, title, name):
  if name:
   VVUIlQ, err = CCpE07.VV5WFr(self, CCpE07.VVPSnJ, VVlRYz=False, VVfXeW=False)
   list = []
   if VVUIlQ:
    VVrYfH = CCIrc5()
    name = VVrYfH.VV97qa(name)
    ratio = "1"
    for item in VVUIlQ:
     if name in item[0].lower():
      list.append((item[0], FFjx2y(item[2]), item[3], ratio))
   if list : self.VVSMjw(list, title)
   else : FFfYN0(self, "Not found:\n\n%s" % name, title=title)
 def VVq9ad(self, title):
  curChName = self.VVToDv.VVzQU4(1)
  self.session.open(CCwieb, barTheme=CCwieb.VV8xER
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVi0CL
      , VVGpYx = BF(self.VVdORA, title, curChName))
 def VVi0CL(self, VVqtmp):
  curChName = self.VVToDv.VVzQU4(1)
  VVUIlQ, err = CCpE07.VV5WFr(self, CCpE07.VVARox, VVlRYz=False, VVfXeW=False)
  if not VVUIlQ or not VVqtmp or VVqtmp.isCancelled:
   return
  VVqtmp.VV1c0w = []
  VVqtmp.VVZre9(len(VVUIlQ))
  VVrYfH = CCIrc5()
  curCh = VVrYfH.VV97qa(curChName)
  for refCode in VVUIlQ:
   chName, sat, inDB = VVUIlQ.get(refCode, ("", "", 0))
   ratio = CC8ahC.VVeBuF(chName.lower(), curCh)
   if not VVqtmp or VVqtmp.isCancelled:
    return
   VVqtmp.VVIW1d(1, True)
   if VVqtmp and ratio > 50:
    VVqtmp.VV1c0w.append((chName, FFjx2y(sat), refCode.replace("_", ":"), str(ratio)))
 def VVdORA(self, title, curChName, VVLpbv, VV1c0w, threadCounter, threadTotal, threadErr):
  if VV1c0w: self.VVSMjw(VV1c0w, title)
  elif VVLpbv: FFfYN0(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVSMjw(self, VVjhh4, title):
  curChName = self.VVToDv.VVzQU4(1)
  VVJ8Ic = self.VVToDv.VVzQU4(4)
  curUrl  = self.VVToDv.VVzQU4(5)
  VVjhh4.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVHFFO  = ("Share Sat/C/T Ref.", BF(self.VVi71q, title, curChName, VVJ8Ic, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFA1pv(self, None, title=title, header=header, VVITUl=VVjhh4, VV7ux5=widths, VVy2kz=26, VVHFFO=VVHFFO, VV1Y9q="#0a00112B", VVMnLe="#0a001126", VVop6p="#0a001126", VViLdG="#00000000")
 def VVi71q(self, newtitle, curChName, VVJ8Ic, curUrl, VVToDv, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVJ8Ic, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFZw7B(self.VVToDv, BF(FFlaBE, self.VVToDv, BF(self.VVTDC0, VVToDv, data)), ques, title=newtitle, VV5RdC=True)
 def VVTDC0(self, VVToDv, data):
  VVToDv.cancel()
  title, curChName, VVJ8Ic, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVJ8Ic = VVJ8Ic.strip()
  newRefCode = newRefCode.strip()
  if not VVJ8Ic.endswith(":") : VVJ8Ic += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVJ8Ic, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVJ8Ic + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVJtZM():
    txt = FFZF5l(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFpUU8()
    newRow = []
    for i in range(6):
     newRow.append(self.VVToDv.VVzQU4(i))
    newRow[4] = newRefCode
    done = self.VVToDv.VViiSN(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFS6vB(BF(FF8O6K , self, resTxt, title=title))
  elif resErr: FFS6vB(BF(FFfYN0, self, resErr, title=title))
 def VVSNgT(self, VVOsSR, path, VVToDv, title, txt, colList):
  self.session.open(CCwieb, barTheme=CCwieb.VVkrqu
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVo8Or, VVToDv)
      , VVGpYx = BF(self.VVyLut, VVOsSR, path, VVToDv))
 def VVo8Or(self, VVToDv, VVqtmp):
  VVqtmp.VVZre9(VVToDv.VVp58T())
  VVqtmp.VV1c0w = []
  for row in VVToDv.VVF8iU():
   if not VVqtmp or VVqtmp.isCancelled:
    return
   VVqtmp.VVIW1d(1, True)
   qUrl = self.VVa0ap(self.VVHnyz, row[6])
   txt, err = self.VVCWun(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVfM7o(item, "auth") == "0":
       VVqtmp.VV1c0w.append(qUrl)
    except:
     pass
 def VVyLut(self, VVOsSR, path, VVToDv, VVLpbv, VV1c0w, threadCounter, threadTotal, threadErr):
  if VVLpbv:
   list = VV1c0w
   title = "Authorized Servers"
   if list:
    totChk = VVToDv.VVp58T()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFSZ6D()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VV64EJ(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFrGgO(str(totAuth), VVqQXm)
     txt += "%s\n\n%s"    %  (FFrGgO("Result File:", VVtSeQ), newPath)
     FFCxQN(self, txt, title=title)
     VVToDv.close()
     VVOsSR.close()
    else:
     FF8O6K(self, "All URLs are authorized.", title=title)
   else:
    FFfYN0(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVCWun(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVhOf8(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVY4JM(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CCGzH5.VVQ3D5()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VV1Jy6(decodedUrl):
  return CCCwQV.VVY4JM(decodedUrl, justRetDotExt=True)
 def VVa0ap(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVhOf8(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVHnyz   : return "%s"            % url
  elif mode == self.VVt6oY   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVXQci   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVrqLx  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVkOl7  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVUxLF : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VV59qS   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVITeH    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VV467U  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVIsPU : return "%s&action=get_live_streams"      % url
  elif mode == self.VVTUhb  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVfM7o(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FF4ENQ(int(val))
    elif is_base64 : val = FFO6Qx(val)
    elif isToHHMMSS : val = FFxB2b(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVM298(self, title, path):
  if fileExists(path):
   enc = CC7qa7.VV6aJR(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VVa2Nh(line)
     if qUrl:
      break
   if qUrl : self.VV67Mo(title, qUrl)
   else : FFfYN0(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFfYN0(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVmaZX(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVeMIi()
  if qUrl or "chCode" in iptvRef:
   p = CCHEQq()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVTeL9(iptvRef)
   if valid:
    self.VVPLHI(self, host, mac)
    return
   elif qUrl:
    FFlaBE(self, BF(self.VV67Mo, title, qUrl), title="Checking Server ...")
    return
  FFfYN0(self, "Error in current channel URL !", title=title)
 def VVeMIi(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self)
  qUrl = self.VVa2Nh(decodedUrl)
  return qUrl, iptvRef
 def VVa2Nh(self, url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VV67Mo(self, title, url):
  self.VVr0grData = {}
  qUrl = self.VVa0ap(self.VVHnyz, url)
  txt, err = self.VVCWun(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVr0grData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVr0grData["username"    ] = self.VVfM7o(item, "username"        )
    self.VVr0grData["password"    ] = self.VVfM7o(item, "password"        )
    self.VVr0grData["message"    ] = self.VVfM7o(item, "message"        )
    self.VVr0grData["auth"     ] = self.VVfM7o(item, "auth"         )
    self.VVr0grData["status"    ] = self.VVfM7o(item, "status"        )
    self.VVr0grData["exp_date"    ] = self.VVfM7o(item, "exp_date"    , isDate=True )
    self.VVr0grData["is_trial"    ] = self.VVfM7o(item, "is_trial"        )
    self.VVr0grData["active_cons"   ] = self.VVfM7o(item, "active_cons"       )
    self.VVr0grData["created_at"   ] = self.VVfM7o(item, "created_at"   , isDate=True )
    self.VVr0grData["max_connections"  ] = self.VVfM7o(item, "max_connections"      )
    self.VVr0grData["allowed_output_formats"] = self.VVfM7o(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVr0grData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVr0grData["url"    ] = self.VVfM7o(item, "url"        )
    self.VVr0grData["port"    ] = self.VVfM7o(item, "port"        )
    self.VVr0grData["https_port"  ] = self.VVfM7o(item, "https_port"      )
    self.VVr0grData["server_protocol" ] = self.VVfM7o(item, "server_protocol"     )
    self.VVr0grData["rtmp_port"   ] = self.VVfM7o(item, "rtmp_port"       )
    self.VVr0grData["timezone"   ] = self.VVfM7o(item, "timezone"       )
    self.VVr0grData["timestamp_now"  ] = self.VVfM7o(item, "timestamp_now"  , isDate=True )
    self.VVr0grData["time_now"   ] = self.VVfM7o(item, "time_now"       )
    VVJ4QS  = self.VV5ul7(True)
    OKBtnFnc = self.VVTSvM
    VVY1MF = ("Home Menu", FFoI8M)
    VVU5gS= ("Add to Menu", BF(CCCwQV.VVOkup, self, False, self.VVr0grData["playListURL"]))
    VVaSnd = ("Bookmark Server", BF(CCCwQV.VVPONO, self, False, self.VVr0grData["playListURL"]))
    FFZP3S(self, None, title="IPTV Server Resources", VVJ4QS=VVJ4QS, OKBtnFnc=OKBtnFnc, VVY1MF=VVY1MF, VVU5gS=VVU5gS, VVaSnd=VVaSnd)
   else:
    err = "Could not get data from server !"
  if err:
   FFfYN0(self, err, title=title)
  FFHbVj(self)
 def VVTSvM(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFlaBE(menuInstance, BF(self.VVgQsN, self.VVt6oY  , title=title), title=wTxt)
   elif ref == "vod"   : FFlaBE(menuInstance, BF(self.VVgQsN, self.VVXQci  , title=title), title=wTxt)
   elif ref == "series"  : FFlaBE(menuInstance, BF(self.VVgQsN, self.VVrqLx , title=title), title=wTxt)
   elif ref == "catchup"  : FFlaBE(menuInstance, BF(self.VVgQsN, self.VVkOl7 , title=title), title=wTxt)
   elif ref == "accountInfo" : FFlaBE(menuInstance, BF(self.VVBh79           , title=title), title=wTxt)
 def VVBh79(self, title):
  rows = []
  for key, val in self.VVr0grData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VVWy3E
   else:
    num, part = "1", self.VVyvSX
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVcjza  = ("Home Menu", FFoI8M, [])
  VV7wPX  = None
  if VVtMJJ:
   VV7wPX = ("Get JS" , BF(self.VVrQw6, "/".join(self.VVr0grData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFA1pv(self, None, title=title, width=1200, header=header, VVITUl=rows, VV7ux5=widths, VVy2kz=26, VVcjza=VVcjza, VV7wPX=VV7wPX, VV1Y9q="#0a00292B", VVMnLe="#0a002126", VVop6p="#0a002126", VViLdG="#00000000", searchCol=2)
 def VVQZry(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    VVrYfH = CCIrc5()
    if mode in (self.VV59qS, self.VVTUhb):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVfM7o(item, "num"         )
      name     = self.VVfM7o(item, "name"        )
      stream_id    = self.VVfM7o(item, "stream_id"       )
      stream_icon    = self.VVfM7o(item, "stream_icon"       )
      epg_channel_id   = self.VVfM7o(item, "epg_channel_id"      )
      added     = self.VVfM7o(item, "added"    , isDate=True )
      is_adult    = self.VVfM7o(item, "is_adult"       )
      category_id    = self.VVfM7o(item, "category_id"       )
      tv_archive    = self.VVfM7o(item, "tv_archive"       )
      direct_source   = self.VVfM7o(item, "direct_source"      )
      tv_archive_duration  = self.VVfM7o(item, "tv_archive_duration"     )
      name = VVrYfH.VVy0DL(name, is_adult)
      if name:
       if mode == self.VV59qS or mode == self.VVTUhb and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVITeH:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVfM7o(item, "num"         )
      name    = self.VVfM7o(item, "name"        )
      stream_id   = self.VVfM7o(item, "stream_id"       )
      stream_icon   = self.VVfM7o(item, "stream_icon"       )
      added    = self.VVfM7o(item, "added"    , isDate=True )
      is_adult   = self.VVfM7o(item, "is_adult"       )
      category_id   = self.VVfM7o(item, "category_id"       )
      container_extension = self.VVfM7o(item, "container_extension"     ) or "mp4"
      name = VVrYfH.VVy0DL(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VV467U:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVfM7o(item, "num"        )
      name    = self.VVfM7o(item, "name"       )
      series_id   = self.VVfM7o(item, "series_id"      )
      cover    = self.VVfM7o(item, "cover"       )
      genre    = self.VVfM7o(item, "genre"       )
      episode_run_time = self.VVfM7o(item, "episode_run_time"    )
      category_id   = self.VVfM7o(item, "category_id"      )
      container_extension = self.VVfM7o(item, "container_extension"    ) or "mp4"
      name = VVrYfH.VVy0DL(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVgQsN(self, mode, title):
  cList, err = self.VV7F98(mode)
  if cList and mode == self.VVkOl7:
   cList = self.VV7V1g(cList)
  if err:
   FFfYN0(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VV1Y9q, VVMnLe, VVop6p, VViLdG = self.VVgxNf(mode)
   mName = self.VVK6yZ(mode)
   if   mode == self.VVt6oY  : fMode = self.VV59qS
   elif mode == self.VVXQci  : fMode = self.VVITeH
   elif mode == self.VVrqLx : fMode = self.VV467U
   elif mode == self.VVkOl7 : fMode = self.VVTUhb
   if mode == self.VVkOl7:
    VVbdhP = None
    VVUB3Q = None
   else:
    VVbdhP = ("Find in %s" % mName , BF(self.VVm1PA, fMode, True) , [])
    VVUB3Q = ("Find in Selected" , BF(self.VVm1PA, fMode, False) , [])
   VVHFFO   = ("Show List"   , BF(self.VV051G, mode)  , [])
   VVcjza  = ("Home Menu"   , FFoI8M         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFA1pv(self, None, title=title, width=1200, header=header, VVITUl=cList, VV7ux5=widths, VVy2kz=30, VVcjza=VVcjza, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q, VVHFFO=VVHFFO, VV1Y9q=VV1Y9q, VVMnLe=VVMnLe, VVop6p=VVop6p, VViLdG=VViLdG, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFfYN0(self, "No list from server !", title=title)
  FFHbVj(self)
 def VV7F98(self, mode):
  qUrl  = self.VVa0ap(mode, self.VVr0grData["playListURL"])
  txt, err = self.VVCWun(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    VVrYfH = CCIrc5()
    for item in tDict:
     category_id  = self.VVfM7o(item, "category_id"  )
     category_name = self.VVfM7o(item, "category_name" )
     parent_id  = self.VVfM7o(item, "parent_id"  )
     category_name = VVrYfH.VVwk7O(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VV7V1g(self, catList):
  mode  = self.VVTUhb
  qUrl  = self.VVa0ap(mode, self.VVr0grData["playListURL"])
  txt, err = self.VVCWun(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVQZry(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VV051G(self, mode, VVToDv, title, txt, colList):
  title = colList[1]
  FFlaBE(VVToDv, BF(self.VVVJ68, mode, VVToDv, title, txt, colList), title="Downloading ...")
 def VVVJ68(self, mode, VVToDv, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVK6yZ(mode) + " : "+ bName
  if   mode == self.VVt6oY  : mode = self.VV59qS
  elif mode == self.VVXQci  : mode = self.VVITeH
  elif mode == self.VVrqLx : mode = self.VV467U
  elif mode == self.VVkOl7 : mode = self.VVTUhb
  qUrl  = self.VVa0ap(mode, self.VVr0grData["playListURL"], catID)
  txt, err = self.VVCWun(qUrl)
  list  = []
  if not err and mode in (self.VV59qS, self.VVITeH, self.VV467U, self.VVTUhb):
   list, err = self.VVQZry(mode, txt)
  if err:
   FFfYN0(self, err, title=title)
  elif list:
   VVcjza  = ("Home Menu"   , FFoI8M            , [])
   if mode in (self.VV59qS, self.VVTUhb):
    VV1Y9q, VVMnLe, VVop6p, VViLdG = self.VVgxNf(mode)
    VVXuip = (""     , BF(self.VVGBv5, mode)      , [])
    VV7wPX = ("Download Options" , BF(self.VVpM5l, mode, "", "")   , [])
    VVbdhP = ("Options"   , BF(self.VVDQ2s, "lv", mode, bName)   , [])
    VVUB3Q = ("Posters Mode"  , BF(self.VVssv6, mode, False)     , [])
    if mode == self.VV59qS:
     VVHFFO = ("Play"    , BF(self.VVoCiN, mode)       , [])
    else:
     VVHFFO = ("Programs"   , BF(self.VVzIfB, mode, bName) , [])
   elif mode == self.VVITeH:
    VV1Y9q, VVMnLe, VVop6p, VViLdG = self.VVgxNf(mode)
    VVHFFO  = ("Play"    , BF(self.VVoCiN, mode)       , [])
    VVXuip = (""     , BF(self.VVGBv5, mode)      , [])
    VV7wPX = ("Download Options" , BF(self.VVpM5l, mode, "v", "")   , [])
    VVbdhP = ("Options"   , BF(self.VVDQ2s, "v", mode, bName)   , [])
    VVUB3Q = ("Posters Mode"  , BF(self.VVssv6, mode, False)     , [])
   elif mode == self.VV467U:
    VV1Y9q, VVMnLe, VVop6p, VViLdG = self.VVgxNf("series2")
    VVHFFO  = ("Show Seasons"  , BF(self.VVpAPc, mode)       , [])
    VVXuip = (""     , BF(self.VVlQQd, mode)     , [])
    VV7wPX = None
    VVbdhP = None
    VVUB3Q = ("Posters Mode"  , BF(self.VVssv6, mode, True)      , [])
   header, widths, VVavJp = self.VVlbJd(mode)
   FFA1pv(self, None, title=title, header=header, VVITUl=list, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VVHFFO=VVHFFO, VVcjza=VVcjza, VV7wPX=VV7wPX, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q, lastFindConfigObj=CFG.lastFindIptv, VVXuip=VVXuip, VV1Y9q=VV1Y9q, VVMnLe=VVMnLe, VVop6p=VVop6p, VViLdG=VViLdG, VVFvoI=True, searchCol=1)
  else:
   FFfYN0(self, "No Channels found !", title=title)
  FFHbVj(self)
 def VVlbJd(self, mode):
  if mode in (self.VV59qS, self.VVTUhb):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VVavJp  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVITeH:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VVavJp  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VV467U:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VVavJp  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VVavJp
 def VVzIfB(self, mode, bName, VVToDv, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVr0grData["playListURL"]
  ok_fnc  = BF(self.VVXg1Y, hostUrl, chName, catId, streamId)
  FFlaBE(VVToDv, BF(CCCwQV.VV72z6, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVXg1Y(self, chUrl, chName, catId, streamId, VVToDv, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCCwQV.VVhOf8(chUrl)
   chNum = "333"
   refCode = CCCwQV.VVSsc4(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFbrIp(self, chUrl, VVVlLd=False)
   CCKx3s.VVpa1E(self.session)
  else:
   FFfYN0(self, "Incorrect Timestamp", pTitle)
 def VVpAPc(self, mode, VVToDv, title, txt, colList):
  title = colList[1]
  FFlaBE(VVToDv, BF(self.VVcpSL, mode, VVToDv, title, txt, colList), title="Downloading ...")
 def VVcpSL(self, mode, VVToDv, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVa0ap(self.VVUxLF, self.VVr0grData["playListURL"], series_id)
  txt, err = self.VVCWun(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVfM7o(tDict["info"], "name"   )
      category_id = self.VVfM7o(tDict["info"], "category_id" )
      icon  = self.VVfM7o(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      VVrYfH = CCIrc5()
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVfM7o(EP, "id"     )
        episode_num   = self.VVfM7o(EP, "episode_num"   )
        epTitle    = self.VVfM7o(EP, "title"     )
        container_extension = self.VVfM7o(EP, "container_extension" )
        seasonNum   = self.VVfM7o(EP, "season"    )
        epTitle = VVrYfH.VVy0DL(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFfYN0(self, err, title=title)
  elif list:
   VVcjza = ("Home Menu"   , FFoI8M          , [])
   VV7wPX = ("Download Options" , BF(self.VVpM5l, mode, "s", title), [])
   VVbdhP = ("Options"   , BF(self.VVDQ2s, "s", mode, title) , [])
   VVUB3Q = ("Posters Mode"  , BF(self.VVssv6, mode, False)   , [])
   VVXuip = (""     , BF(self.VVGBv5, mode)    , [])
   VVHFFO  = ("Play"    , BF(self.VVoCiN, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVavJp  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFA1pv(self, None, title=title, header=header, VVITUl=list, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VVcjza=VVcjza, VV7wPX=VV7wPX, VVHFFO=VVHFFO, VVXuip=VVXuip, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q, lastFindConfigObj=CFG.lastFindIptv, VV1Y9q="#0a00292B", VVMnLe="#0a002126", VVop6p="#0a002126", VViLdG="#00000000")
  else:
   FFfYN0(self, "No Channels found !", title=title)
  FFHbVj(self)
 def VVm1PA(self, mode, isAll, VVToDv, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVJ4QS = []
  VVJ4QS.append(("Keyboard"  , "manualEntry"))
  VVJ4QS.append(("From Filter" , "fromFilter"))
  FFZP3S(self, BF(self.VVHPDk, VVToDv, mode, onlyCatID), title="Input Type", VVJ4QS=VVJ4QS, width=400)
 def VVHPDk(self, VVToDv, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFoW9P(self, BF(self.VVPfKq, VVToDv, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCMA5J(self)
    filterObj.VVEg8v(BF(self.VVPfKq, VVToDv, mode, onlyCatID))
 def VVPfKq(self, VVToDv, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FFu7KK(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CCMA5J.VVBkhG(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FFfYN0(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FFfYN0(self, "All words must be at least 3 characters !", title=title)
        return
     VVrYfH = CCIrc5()
     if CFG.hideIptvServerAdultWords.getValue() and VVrYfH.VVswk1(words):
      FFfYN0(self, VVrYfH.VVhcyV(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CCwieb, barTheme=CCwieb.VV8xER
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVHTqf, VVToDv, mode, onlyCatID, title, words, toFind, asPrefix, VVrYfH)
          , VVGpYx = BF(self.VVTjbt, mode, toFind, title))
   if not words:
    FFHbVj(VVToDv, "Nothing to find !", 1500)
 def VVHTqf(self, VVToDv, mode, onlyCatID, title, words, toFind, asPrefix, VVrYfH, VVqtmp):
  VVqtmp.VVZre9(VVToDv.VVLfEh() if onlyCatID is None else 1)
  VVqtmp.VV1c0w = []
  for row in VVToDv.VVF8iU():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVqtmp or VVqtmp.isCancelled:
    return
   VVqtmp.VVIW1d(1)
   VVqtmp.VVQEx6(catName)
   qUrl  = self.VVa0ap(mode, self.VVr0grData["playListURL"], catID)
   txt, err = self.VVCWun(qUrl)
   if not err:
    tList, err = self.VVQZry(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = VVrYfH.VVy0DL(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       VVqtmp.VV1c0w.append(item)
 def VVTjbt(self, mode, toFind, title, VVLpbv, VV1c0w, threadCounter, threadTotal, threadErr):
  if VV1c0w:
   title = self.VVU5DT(mode, toFind)
   if mode == self.VV59qS or mode == self.VVITeH:
    if mode == self.VVITeH : typ = "v"
    else          : typ = ""
    bName   = CCCwQV.VVomSS(toFind)
    VVHFFO  = ("Play"     , BF(self.VVoCiN, mode)     , [])
    VV7wPX = ("Download Options" , BF(self.VVpM5l, mode, typ, "") , [])
    VVbdhP = ("Options"   , BF(self.VVDQ2s, "fnd", mode, bName), [])
    VVUB3Q = ("Posters Mode"  , BF(self.VVssv6, mode, False)   , [])
    VVXuip = (""     , BF(self.VVGBv5, mode)    , [])
   elif mode == self.VV467U:
    VVHFFO  = ("Show Seasons"  , BF(self.VVpAPc, mode)     , [])
    VVbdhP = None
    VV7wPX = None
    VVUB3Q = ("Posters Mode"  , BF(self.VVssv6, mode, True)    , [])
    VVXuip = (""     , BF(self.VVlQQd, mode)   , [])
   VVcjza  = ("Home Menu"   , FFoI8M          , [])
   header, widths, VVavJp = self.VVlbJd(mode)
   VVToDv = FFA1pv(self, None, title=title, header=header, VVITUl=VV1c0w, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VVHFFO=VVHFFO, VVcjza=VVcjza, VV7wPX=VV7wPX, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q, VVXuip=VVXuip, VV1Y9q="#0a00292B", VVMnLe="#0a002126", VVop6p="#0a002126", VViLdG="#00000000", VVFvoI=True, searchCol=1)
   if not VVLpbv:
    FFHbVj(VVToDv, "Stopped" , 1000)
  else:
   if VVLpbv:
    FFfYN0(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVNHXJ(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VV59qS, self.VVTUhb):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVITeH:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FFVK2H(chName)
  url = self.VVr0grData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVhOf8(url)
  refCode = self.VVSsc4(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVGBv5(self, mode, VVToDv, title, txt, colList):
  FFlaBE(VVToDv, BF(self.VVD8RW, mode, VVToDv, title, txt, colList))
 def VVD8RW(self, mode, VVToDv, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVNHXJ(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFzeU3(self, fncMode=CCy52I.VVdbSh, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVlQQd(self, mode, VVToDv, title, txt, colList):
  FFlaBE(VVToDv, BF(self.VVVpHN, mode, VVToDv, title, txt, colList))
 def VVVpHN(self, mode, VVToDv, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFzeU3(self, fncMode=CCy52I.VVqHia, chName=name, text=txt, picUrl=Cover)
 def VVssv6(self, mode, isSerNames, VVToDv, title, txt, colList):
  if   mode in ("itv"  , CCCwQV.VV59qS, CCCwQV.VVTUhb): category = "live"
  elif mode in ("vod"  , CCCwQV.VVITeH )          : category = "vod"
  elif mode in ("series" , CCCwQV.VV467U)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VV59qS : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVTUhb : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVITeH  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VV467U : picCol, descCol, descTxt = 5, 0, "Season"
  FFlaBE(VVToDv, BF(self.session.open, CCTGR0, VVToDv, category, nameCol, picCol, descCol, descTxt))
 def VVpM5l(self, mode, typ, seriesName, VVToDv, title, txt, colList):
  VVJ4QS = []
  isMulti = VVToDv.VVmDY2
  tot  = VVToDv.VVFx4F()
  if isMulti:
   if tot < 1:
    FFHbVj(VVToDv, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVJ4QS.append(("Download %s PIcon%s" % (name, FFIMVJ(tot)), "dnldPicons" ))
  if typ:
   VVJ4QS.append(VV4c5n)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVJ4QS.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVJ4QS.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVJ4QS.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCjOMG.VVQeoC():
    VVJ4QS.append(VV4c5n)
    VVJ4QS.append(("Download Manager"      , "dload_stat" ))
  FFZP3S(self, BF(self.VVI5dg, VVToDv, mode, typ, seriesName, colList), title="Download Options", VVJ4QS=VVJ4QS)
 def VVI5dg(self, VVToDv, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVW7RV(VVToDv, mode)
   elif item == "dnldSel"  : self.VVl5OG(VVToDv, mode, typ, colList, True)
   elif item == "addSel"  : self.VVl5OG(VVToDv, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVRlRz(VVToDv, mode, typ, seriesName)
   elif item == "dload_stat" : CCjOMG.VVUHLU(self)
 def VVl5OG(self, VVToDv, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVxQBO(mode, typ, colList)
  if startDnld:
   CCjOMG.VVcUev(self, decodedUrl)
  else:
   self.VVu0vg(VVToDv, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVRlRz(self, VVToDv, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVToDv.VVF8iU():
   chName, decodedUrl = self.VVxQBO(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVu0vg(VVToDv, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVu0vg(self, VVToDv, title, chName, decodedUrl_list, startDnld):
  FFZw7B(self, BF(self.VVe7wr, VVToDv, decodedUrl_list, startDnld), chName, title=title)
 def VVe7wr(self, VVToDv, decodedUrl_list, startDnld):
  added, skipped = CCjOMG.VVpSBh(decodedUrl_list)
  FFHbVj(VVToDv, "Added", 1000)
 def VVxQBO(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVNHXJ(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVWxTC(mode, colList)
   refCode, chUrl = self.VVvhj2(self.VVnFHs, self.VVFH2j, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFeiz0(chUrl)
  return chName, decodedUrl
 def VVW7RV(self, VVToDv, mode):
  if os.system(FFyto6("which ffmpeg")) == 0:
   self.session.open(CCwieb, barTheme=CCwieb.VVkrqu
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVqiXB, VVToDv, mode)
       , VVGpYx = self.VVXRdr)
  else:
   FFZw7B(self, BF(CCCwQV.VVWKy2, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVXRdr(self, VVLpbv, VV1c0w, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VV1c0w["proces"], VV1c0w["total"])
  txt += "Download Success\t: %d of %s\n"  % (VV1c0w["ok"], VV1c0w["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VV1c0w["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VV1c0w["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VV1c0w["badURL"]
  txt += "Download Failure\t: %d\n"   % VV1c0w["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VV1c0w["path"]
  if not VVLpbv  : color = "#11402000"
  elif VV1c0w["err"]: color = "#11201000"
  else     : color = None
  if VV1c0w["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VV1c0w["err"], txt)
  title = "PIcons Download Result"
  if not VVLpbv:
   title += "  (cancelled)"
  FFCxQN(self, txt, title=title, VVop6p=color)
 def VVqiXB(self, VVToDv, mode, VVqtmp):
  isMulti = VVToDv.VVmDY2
  if isMulti : totRows = VVToDv.VVFx4F()
  else  : totRows = VVToDv.VVLfEh()
  VVqtmp.VVZre9(totRows)
  VVqtmp.VVYFbK(0)
  counter     = VVqtmp.counter
  maxValue    = VVqtmp.maxValue
  pPath     = CC8ahC.VVmFFX()
  VVqtmp.VV1c0w = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for rowNum, row in enumerate(VVToDv.VVF8iU()):
    if VVqtmp.isCancelled:
     break
    if not isMulti or VVToDv.VVDjqE(rowNum):
     VVqtmp.VV1c0w["proces"] += 1
     VVqtmp.VVIW1d(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVWxTC(mode, row)
      refCode = CCCwQV.VVSsc4(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVVKqm(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVNHXJ(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVqtmp.VV1c0w["attempt"] += 1
       path, err = FFSAwr(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVqtmp:
         VVqtmp.VV1c0w["ok"] += 1
         VVqtmp.VVYFbK(VVqtmp.VV1c0w["ok"])
        if FF2Omp(path) > 0:
         cmd = CCy52I.VVWRuE(path)
         cmd += FFyto6("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         if VVqtmp:
          VVqtmp.VV1c0w["size0"] += 1
         FFM75P(path)
       elif err:
        if VVqtmp:
         VVqtmp.VV1c0w["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVqtmp:
          VVqtmp.VV1c0w["err"] = err.title()
         break
      else:
       if VVqtmp:
        VVqtmp.VV1c0w["exist"] += 1
     else:
      if VVqtmp:
       VVqtmp.VV1c0w["badURL"] += 1
  except:
   pass
 def VVgGze(self):
  title = "Download PIcons for Current Bouquet"
  if os.system(FFyto6("which ffmpeg")) == 0:
   self.session.open(CCwieb, barTheme=CCwieb.VVkrqu
       , titlePrefix = ""
       , fncToRun  = self.VVQkru
       , VVGpYx = BF(self.VVDQVb, title))
  else:
   FFZw7B(self, BF(CCCwQV.VVWKy2, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VVQkru(self, VVqtmp):
  bName = CC54zE.VVuBxU()
  pPath = CC8ahC.VVmFFX()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVqtmp.VV1c0w = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CC54zE.VVgo8J()
  if not VVqtmp or VVqtmp.isCancelled:
   return
  if not services or len(services) == 0:
   VVqtmp.VV1c0w = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVqtmp.VVZre9(totCh)
  VVqtmp.VVYFbK(0)
  for serv in services:
   if not VVqtmp or VVqtmp.isCancelled:
    return
   VVqtmp.VV1c0w = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVqtmp.VVIW1d(1)
   VVqtmp.VVYFbK(totPic)
   fullRef  = serv[0]
   if FFCeZx(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFeiz0(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CCHEQq.VVlswK(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CCCwQV.VVY4JM(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInv += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCCwQV.VVCWun(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CCy52I.VVZ7Jo(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFSAwr(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVqtmp:
     VVqtmp.VVYFbK(totPic)
    if FF2Omp(path) > 0:
     cmd = CCy52I.VVWRuE(path)
     cmd += FFyto6("mv -f '%s' '%s'" % (path, pPath)) + ";"
     os.system(cmd)
     totPicOK += 1
    else:
     totSize0
     FFM75P(path)
  if VVqtmp:
   VVqtmp.VV1c0w = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVDQVb(self, title, VVLpbv, VV1c0w, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VV1c0w
  if err:
   FFfYN0(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FFrGgO(str(totExist)  , VVFBP5)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFrGgO(str(totNotIptv)  , VVFBP5)
    if totServErr : txt += "Server Errors\t: %s\n" % FFrGgO(str(totServErr) + t1, VVFBP5)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FFrGgO(str(totParseErr) , VVFBP5)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FFrGgO(str(totInvServ)  , VVFBP5)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FFrGgO(str(totInvPicUrl) , VVFBP5)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FFrGgO(str(totSize0)  , VVFBP5)
   if not VVLpbv:
    title += "  (stopped)"
   FFCxQN(self, txt, title=title)
 @staticmethod
 def VVWKy2(SELF):
  cmd = FFMotr(VVi1jL, "ffmpeg")
  if cmd : FFyKCd(SELF, cmd, title="Installing FFmpeg")
  else : FF1KkZ(SELF)
 def VVnYg1(self):
  self.session.open(CCwieb, barTheme=CCwieb.VVkrqu
      , titlePrefix = ""
      , fncToRun  = self.VVeyat
      , VVGpYx = self.VV2d1o)
 def VVeyat(self, VVqtmp):
  bName = CC54zE.VVuBxU()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVqtmp.VV1c0w = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CC54zE.VVgo8J()
  if not VVqtmp or VVqtmp.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVqtmp.VVZre9(totCh)
   for serv in services:
    if not VVqtmp or VVqtmp.isCancelled:
     return
    VVqtmp.VVIW1d(1)
    fullRef = serv[0]
    if FFCeZx(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFeiz0(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     if span:
      valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CCHEQq.VVlswK(decodedUrl)
      if valid and mode == "itv" : uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
      else      : uHost = uUser = uPass = uId = uChName = ""
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCCwQV.VVY4JM(m3u_Url)
     if VVqtmp:
      VVqtmp.VVjt3f(totEpgOK, uChName)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCCwQV.VVXw41(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCy52I.VVM43F(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if VVqtmp:
     VVqtmp.VV1c0w = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVqtmp.VV1c0w = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VV2d1o(self, VVLpbv, VV1c0w, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VV1c0w
  title = "IPTV EPG Import"
  if err:
   FFfYN0(self, err, title=title)
  else:
   if VVLpbv and totEpgOK > 0:
    CCWiTw.VVtPAt()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFrGgO(str(totNotIptv), VVFBP5)
    if totServErr : txt += "Server Errors\t: %s\n" % FFrGgO(str(totServErr) + t1, VVFBP5)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFrGgO(str(totInv), VVFBP5)
   if not VVLpbv:
    title += "  (stopped)"
   FFCxQN(self, txt, title=title)
 @staticmethod
 def VVXw41(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCCwQV.VVhOf8(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCCwQV.VVCWun(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCCwQV.VVfM7o(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CCCwQV.VVfM7o(item, "lang"        ).upper()
    now_playing   = CCCwQV.VVfM7o(item, "now_playing"      )
    start    = CCCwQV.VVfM7o(item, "start"        )
    start_timestamp  = CCCwQV.VVfM7o(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCCwQV.VVfM7o(item, "start_timestamp"     )
    stop_timestamp  = CCCwQV.VVfM7o(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCCwQV.VVfM7o(item, "stop_timestamp"      )
    tTitle    = CCCwQV.VVfM7o(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVSsc4(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCCwQV.VVEImW(catID, MAX_4b)
  TSID = CCCwQV.VVEImW(chNum, MAX_4b)
  ONID = CCCwQV.VVEImW(chNum, MAX_4b)
  NS  = CCCwQV.VVEImW(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVEImW(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVomSS(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVgxNf(mode):
  if   mode in ("itv"  , CCCwQV.VVt6oY)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCCwQV.VVXQci)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCCwQV.VVrqLx) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCCwQV.VVkOl7) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCCwQV.VVTUhb    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVikZa(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVqwOi:
   excl = FFRjyr(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFfYN0(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFz7l2('find %s %s %s' % (path, excl, par))
  if not files:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFfYN0(self, err)
  elif len(files) == 1 and files[0] == VVTzA8:
   FFfYN0(self, VVTzA8)
  else:
   return files
 @staticmethod
 def VV1xkO():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FFegwS(path)
  return "/"
 @staticmethod
 def VV72z6(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CCCwQV.VVXw41(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FFfYN0(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VV1Y9q, VVMnLe, VVop6p, VViLdG = CCCwQV.VVgxNf("")
   VVcjza = ("Home Menu" , FFoI8M, [])
   VVHFFO  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVavJp  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFA1pv(SELF, None, title="Programs for : " + chName, header=header, VVITUl=pList, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=24, VVHFFO=VVHFFO, VVcjza=VVcjza, VV1Y9q=VV1Y9q, VVMnLe=VVMnLe, VVop6p=VVop6p, VViLdG=VViLdG)
  else:
   FFfYN0(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVoleU(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VVOkup(self, isPortal, line, VVi8BRObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FFZw7B(self, BF(self.VVlLJW, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FFu7KK(confItem, line)
   FF8O6K(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VVlLJW(self, title, confItem):
  FFu7KK(confItem, "")
  FF8O6K(self, "Removed from IPTV Menu.", title=title)
 def VVZAZu(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VVPLHI(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FFlaBE(self, BF(self.VV67Mo, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FFfYN0(self, "Incorrect server data !")
 @staticmethod
 def VVPONO(SELF, isPortal, line, VVi8BRObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCCwQV.VV1xkO()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFfYN0(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FF8O6K(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFfYN0(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVDQ2s(self, source, mode, curBName, VVToDv, title, txt, colList):
  isMulti = VVToDv.VVmDY2
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVToDv.VVFx4F()
   totTxt = "%d Service%s" % (tot, FFIMVJ(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FFrGgO(totTxt, VVtSeQ)
  title = "Add to Bouquet"
  mSel = CC6FeI(self, VVToDv, addSep=False)
  VVJ4QS, cbFncDict = [], None
  VVJ4QS.append(VV4c5n)
  if itemsOK:
   VVJ4QS.append(("Add %s to New Bouquet : %s" % (totTxt, FFrGgO(curBName, VVqQXm)) , "addToCur"))
   VVJ4QS.append(("Add %s to Other Bouquet ..." % (totTxt)          , "addToNew"))
   cbFncDict = { "addToCur": BF(FFlaBE, mSel.VVToDv, BF(self.VVtbB2,source, mode, curBName, VVToDv, title), title="Adding Services ...")
      , "addToNew": BF(self.VVOB8Z, source, mode, curBName, VVToDv, title)
      }
  else:
   VVJ4QS.append(("Add to Bouquet (nothing selected)", ))
  mSel.VV9EgX(VVJ4QS, cbFncDict)
 def VVtbB2(self, source, mode, curBName, VVToDv, Title):
  chUrlLst = self.VVjbwg(source, mode, VVToDv)
  CC54zE.VV5b6v(self, Title, curBName, "", chUrlLst)
 def VVOB8Z(self, source, mode, curBName, VVToDv, Title):
  picker = CC54zE(self, VVToDv, Title, BF(self.VVjbwg, source, mode, VVToDv), defBName=curBName)
 def VVjbwg(self, source, mode, VVToDv):
  totChange = 0
  isMulti = VVToDv.VVmDY2
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVToDv.VVF8iU()):
   if not isMulti or VVToDv.VVDjqE(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVWxTC(mode, row)
     refCode, chUrl = self.VVvhj2(self.VVnFHs, self.VVFH2j, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VVFYIt(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVNHXJ(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
class CCTGR0(Screen):
 def __init__(self, session, VVToDv, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FFNQkv(VVFdj2, 1870, 1030, 50, 10, 10, "#33000000", "#33000000", 50, topRightBtns=2)
  self.session   = session
  self.Title    = "Server Browser"
  FFVOCw(self, self.Title)
  self.VVToDv  = VVToDv
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.TOTAL_ROWS   = 2
  self.TOTAL_COLS   = 6
  self.PAGE_PICTURE  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.VVITUl    = []
  self.totPosterUrls  = 0
  self.totalChannels  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVL4Xa, subPath)
  if not pathExists(self.pPath):
   os.system(FFyto6("mkdir -p '%s'" % (self.pPath)))
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  for i in range(4):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVfFPM   ,
   "cancel"  : self.close   ,
   "menu"   : self.VVul35,
   "info"   : self.VVii4U ,
   "up"   : self.VVcoOu    ,
   "down"   : self.VV153S   ,
   "left"   : self.VVsfLd   ,
   "right"   : self.VVB1TT   ,
   "next"   : self.VV8kEj  ,
   "last"   : self.VVPPup
  }, -1)
  self.onShown.append(self.VV47vn)
  self.onClose.append(self.onExit)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FFABOX(self)
  FFeAg3(self)
  self.VVUP2m()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVul35(self):
  VVJ4QS = []
  VVJ4QS.append(("Show Poster/PIcon"      , "VVXCEr"   ))
  VVJ4QS.append(("Copy Poster/PIcon to Export-Directory" , "VVvefa"  ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Cache details"       , "VVBNFP" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Change Poster/Picon Transparency Color" , "VV9N9v" ))
  FFZP3S(self, self.VV9zcx, title=self.Title, VVJ4QS=VVJ4QS)
 def VV9zcx(self, item=None):
  if item is not None:
   if   item == "VVvefa"   : self.VVvefa()
   elif item == "VVXCEr"   : self.VVXCEr()
   elif item == "VVBNFP"  : FFlaBE(self, self.VVBNFP, title="Calculating ...")
   elif item == "VV9N9v" : self.VV9N9v()
 def VVfFPM(self):
  self.VVToDv.VVeb2k(self.curIndex)
  self.VVToDv.VV8HAl()
 def VVii4U(self):
  self.VVToDv.VVeb2k(self.curIndex)
  self.VVToDv.VVyOAW()
 def VV9N9v(self):
  fg = bg = CFG.transpColorPosters.getValue()
  self.session.openWithCallback(self.VVQuHV, CCSXlr, defFG=fg, defBG=bg, onlyBG=True)
 def VVQuHV(self, fg, bg):
  if bg:
   FFu7KK(CFG.transpColorPosters, bg)
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FFg8wK(self["myPosterRep%d%d" % (row, col)], bg)
 def VVUP2m(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
    self["myPosterLbl%d%d" % (row, col)].instance.setNoWrap(True)
  for colList in self.VVToDv.VVF8iU():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = os.path.basename(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VVITUl.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalChannels = len(self.VVITUl)
  self.totalPages  = int(self.totalChannels / self.PAGE_PICTURE) + (self.totalChannels % self.PAGE_PICTURE > 0)
  self.VVqmOC(True)
  self.VVNRnl(self.VVToDv.VVYt3A())
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVwnro)
  except:
   self.timer.callback.append(self.VVwnro)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VVgXP5)
  self.myThread.start()
 def VVgXP5(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VVITUl):
    if not self.stopThread:
     if picUrl and not fName:
      fName = os.path.basename(picUrl)
      path, err = FFSAwr(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       os.system(FFyto6("mv -f '%s' '%s'" % (path, self.pPath + fName)))
       self.VVITUl[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VVwnro(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVwmjQ + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalChannels
  f1 = self.curPage * self.PAGE_PICTURE
  f2 = f1 + self.PAGE_PICTURE
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVITUl[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VVITUl[ndx] = (chName, subj, desc, fName, "")
     try:
      self.VVnWtL(self["myPosterPic%d%d" % (row, col)], path)
     except:
      pass
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVtfQT(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
  last = self.totalChannels
  f1 = self.curPage * self.PAGE_PICTURE
  f2 = f1 + self.PAGE_PICTURE
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVITUl[ndx]
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.setText(chName)
   lbl.show()
   pic.show()
   path = ""
   if fName:
    path = self.pPath + fName
   if not fileExists(path):
    path = VVnEh8 + "iptv.png"
   try:
    self.VVnWtL(pic, path)
    pic.show()
   except:
    pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVnWtL(self, pixObj, path):
  if path.endswith(".png"):
   pixObj.instance.setPixmapFromFile(path)
  else:
   png = LoadPixmap(path)
   pixObj.instance.setScale(1)
   pixObj.instance.setPixmap(png)
 def VVqmOC(self, force=False):
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVrNRN = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVrNRN: self.curPage = VVrNRN
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVtfQT()
  if self.curPage == VVrNRN:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPosterPic%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICTURE + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVc0II()
  chName, subj, desc, fName, picUrl = self.VVITUl[self.curIndex]
 def VVc0II(self):
  chName, subj, desc, fName, picUrl = self.VVITUl[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalChannels))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVcoOu(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVGprW()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVqmOC()
 def VV153S(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVQ4Nx()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVqmOC()
 def VVsfLd(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVGprW()
  else:
   self.curCol -= 1
   self.VVqmOC()
 def VVB1TT(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVQ4Nx()
  else:
   self.curCol += 1
   self.VVqmOC()
 def VVPPup(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVqmOC(True)
 def VV8kEj(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVqmOC(True)
 def VVQ4Nx(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVqmOC(True)
 def VVGprW(self):
  self.curPage = self.totalPages - 1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVqmOC(True)
 def VVNRnl(self, ndx):
  self.curPage = int(ndx / self.PAGE_PICTURE)
  ndx     -= self.curPage * self.PAGE_PICTURE
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VVqmOC(True)
 def VVXCEr(self):
  chName, subj, desc, fName, picUrl = self.VVITUl[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCkc9M.VVthJo(self, self.pPath + fName)
  else          : FFHbVj(self, "File not found", 1500)
 def VVvefa(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VVITUl[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   res = os.system(FFyto6("cp -f '%s' '%s'" % (self.pPath + fName, dstF)))
   if res == 0 : FF8O6K(self, "File copied to:\n\n%s" % dstF, title=title)
   else  : FFfYN0(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FFfYN0(self, "No Poster/PIcon found", title=title)
 def VVBNFP(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVL4Xa, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FFIgoM("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CCqXgM.VV4m3L(size)
   txt += "%s\n    %s\n\n" % (FFrGgO(path, VVtSeQ), size)
  mainPath = "%sPosters" % VVL4Xa
  totFiles = FFIgoM("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FFIMVJ(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FFrGgO("Total space used by Posters/PIcons%s:" % totFTxt, VVy0iZ), CCqXgM.VV4m3L(totSize))
  mountPath = CCqXgM.VVwibR(mainPath)
  if pathExists(mountPath):
   totSize  = CCqXgM.VVW9Yx(mountPath)
   freeSize = CCqXgM.VVRyP5(mountPath)
   usedSize = CCqXgM.VV4m3L(totSize - freeSize)
   totSize  = CCqXgM.VV4m3L(totSize)
   freeSize = CCqXgM.VV4m3L(freeSize)
   txt += "%s\n" % VVU8ll
   txt += FFrGgO("Media Space:\n", VV61Yf)
   txt += "    Media Path\t: %s\n" % FFrGgO(mountPath, VVxpap)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FFCxQN(self, txt, title="Cache Used Size", height=1000)
class CCxaT0(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFNQkv(VVLAKc, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VV8rRP  = 0
  self.VVlb9b = 1
  self.VVLnQl  = 2
  VVJ4QS = []
  VVJ4QS.append(("Find in All Service (from filter)" , "VVPeSn" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Find in All (Manual Entry)"   , "VVxQYt"    ))
  VVJ4QS.append(("Find in TV"       , "VVITf4"    ))
  VVJ4QS.append(("Find in Radio"      , "VVwPuA"   ))
  if self.VV4Smh():
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append(("Hide Channel: %s" % self.servName , "VVuXoO"   ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Zap History"       , "VVReHa"    ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("IPTV Tools"       , "iptv"      ))
  VVJ4QS.append(("PIcons Tools"       , "PIconsTools"     ))
  VVJ4QS.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FFVOCw(self, VVJ4QS=VVJ4QS, title=title)
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FFAoMS(self["myMenu"])
  FFJdIh(self)
  if self.isFindMode:
   self.VV6IHT(self.VVgmJC())
 def VVfFPM(self):
  global VVnWCp
  VVnWCp = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVxQYt"    : self.VVxQYt()
   elif item == "VVPeSn" : self.VVPeSn()
   elif item == "VVITf4"    : self.VVITf4()
   elif item == "VVwPuA"   : self.VVwPuA()
   elif item == "VVuXoO"   : self.VVuXoO()
   elif item == "VVReHa"    : self.VVReHa()
   elif item == "iptv"       : self.session.open(CCCwQV)
   elif item == "PIconsTools"     : self.session.open(CC8ahC)
   elif item == "ChannelsTools"    : self.session.open(CCpE07)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVITf4(self) : self.VV6IHT(self.VV8rRP)
 def VVwPuA(self) : self.VV6IHT(self.VVlb9b)
 def VVxQYt(self) : self.VV6IHT(self.VVLnQl)
 def VV6IHT(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFoW9P(self, BF(self.VV6ZZV, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VVPeSn(self):
  filterObj = CCMA5J(self)
  filterObj.VVEg8v(self.VVlnLi)
 def VVlnLi(self, item):
  self.VV6ZZV(self.VVLnQl, item)
 def VV4Smh(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFCeZx(self.refCode)        : return False
  return True
 def VV6ZZV(self, mode, VVwDVE):
  FFlaBE(self, BF(self.VVonUb, mode, VVwDVE), title="Searching ...")
 def VVonUb(self, mode, VVwDVE):
  if VVwDVE:
   VVwDVE = VVwDVE.strip()
  if VVwDVE:
   self.findTxt = VVwDVE
   CFG.lastFindContextFind.setValue(VVwDVE)
   if   mode == self.VV8rRP  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVlb9b : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVwDVE)
   if len(title) > 55:
    title = title[:55] + ".."
   VVjhh4 = self.VVOX84(VVwDVE, servTypes)
   if self.isFindMode or mode == self.VVLnQl:
    VVjhh4 += self.VVwcFI(VVwDVE)
   if VVjhh4:
    VVjhh4.sort(key=lambda x: x[0].lower())
    VVzffX = self.VV0CjZ
    VVHFFO  = ("Zap"   , self.VVggho    , [])
    VV7wPX = ("Current Service", self.VVeUTx , [])
    VVbdhP = ("Options"  , self.VV3qN9 , [])
    VVXuip = (""    , self.VVQ4SK , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVavJp  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFA1pv(self, None, title=title, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VVHFFO=VVHFFO, VVzffX=VVzffX, VV7wPX=VV7wPX, VVbdhP=VVbdhP, VVXuip=VVXuip, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VV6IHT(self.VVgmJC())
    FF8O6K(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVOX84(self, VVwDVE, servTypes):
  VVITUl = CCpE07.VVzHUI(servTypes)
  VVjhh4 = []
  if VVITUl:
   VV7i3E, VVMouC = FFxdEf()
   tp = CCoeZX()
   words, asPrefix = CCMA5J.VVBkhG(VVwDVE)
   colorYellow  = CCr1Ch.VVDcL5(VVy0iZ)
   colorWhite  = CCr1Ch.VVDcL5(VVCLGj)
   for s in VVITUl:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFQQpf(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VV7i3E:
        STYPE = VVMouC[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVcy5m(refCode)
       if not "-S" in syst:
        sat = syst
       VVjhh4.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVjhh4
 def VVwcFI(self, VVwDVE):
  VVwDVE = VVwDVE.lower()
  VVjhh4 = []
  colorYellow  = CCr1Ch.VVDcL5(VVy0iZ)
  colorWhite  = CCr1Ch.VVDcL5(VVCLGj)
  for b in CC54zE.VVKYu3():
   VVBAfT  = b[0]
   VVpNL4  = b[1].toString()
   VV1mHV = eServiceReference(VVpNL4)
   VVJSeO = FF5CZv(VV1mHV)
   for service in VVJSeO:
    refCode  = service[0]
    if FFCeZx(refCode):
     servName = service[1]
     if VVwDVE in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVwDVE), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVjhh4.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVjhh4
 def VVgmJC(self):
  VVdeEx = InfoBar.instance
  if VVdeEx:
   VVBoUf = VVdeEx.servicelist
   if VVBoUf:
    return VVBoUf.mode == 1
  return self.VVLnQl
 def VV0CjZ(self, VVToDv):
  self.close()
  VVToDv.cancel()
 def VVggho(self, VVToDv, title, txt, colList):
  FFbrIp(VVToDv, colList[2], VVVlLd=False, checkParentalControl=True)
 def VVeUTx(self, VVToDv, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(VVToDv)
  if refCode:
   VVToDv.VV0HXt(2, FF95YK(refCode, iptvRef, chName), True)
 def VV3qN9(self, VVToDv, title, txt, colList):
  servName = colList[0]
  mSel = CC6FeI(self, VVToDv)
  VVJ4QS, cbFncDict = CCpE07.VVpbzK(self, VVToDv, servName, 2)
  mSel.VV9EgX(VVJ4QS, cbFncDict)
 def VVQ4SK(self, VVToDv, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFzeU3(self, fncMode=CCy52I.VVKOLG, refCode=refCode, chName=chName, text=txt)
 def VVuXoO(self):
  FFZw7B(self, self.VVts6D, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVts6D(self):
  ret = FFWATy(self.refCode, True)
  if ret:
   self.VVA1q4()
   self.close()
  else:
   FFHbVj(self, "Cannot change state" , 1000)
 def VVA1q4(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVypCv()
  except:
   self.VVf2wu()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFTPuE(self, serviceRef)
 def VVypCv(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVdeEx = InfoBar.instance
   if VVdeEx:
    VVBoUf = VVdeEx.servicelist
    if VVBoUf:
     hList = VVBoUf.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVBoUf.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVBoUf.history  = newList
       VVBoUf.history_pos = pos
 def VVf2wu(self):
  VVdeEx = InfoBar.instance
  if VVdeEx:
   VVBoUf = VVdeEx.servicelist
   if VVBoUf:
    VVBoUf.history  = []
    VVBoUf.history_pos = 0
 def VVReHa(self):
  VVdeEx = InfoBar.instance
  VVjhh4 = []
  if VVdeEx:
   VVBoUf = VVdeEx.servicelist
   if VVBoUf:
    VV7i3E, VVMouC = FFxdEf()
    for serv in VVBoUf.history:
     refCode = serv[-1].toString()
     chName = FFTpSI(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FFCeZx(refCode)
     if   isIptv or isLocal : sat = "-"
     else     : sat = FFQQpf(refCode, True)
     if isIptv : STYPE = "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VV7i3E:
       STYPE = VVMouC[sTypeInt]
     VVjhh4.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVjhh4:
   VVHFFO  = ("Zap"   , self.VVUvj1   , [])
   VVbdhP = ("Clear History" , self.VVUZsp   , [])
   VVXuip = (""    , self.VVSu5I , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVavJp  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFA1pv(self, None, title=title, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=28, VVHFFO=VVHFFO, VVbdhP=VVbdhP, VVXuip=VVXuip)
  else:
   FF8O6K(self, "Not found", title=title)
 def VVUvj1(self, VVToDv, title, txt, colList):
  FFbrIp(VVToDv, colList[3], VVVlLd=False, checkParentalControl=True)
 def VVUZsp(self, VVToDv, title, txt, colList):
  FFZw7B(self, BF(self.VVJmAo, VVToDv), "Clear Zap History ?")
 def VVJmAo(self, VVToDv):
  self.VVf2wu()
  VVToDv.cancel()
 def VVSu5I(self, VVToDv, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFzeU3(self, fncMode=CCy52I.VVAXkn, refCode=refCode, chName=chName, text=txt)
class CC8ahC(Screen):
 VVl3wU   = 0
 VVonfY  = 1
 VVICbz  = 2
 VVNhHP  = 3
 VVzVO6  = 4
 VVazwe  = 5
 VVZzQ5  = 6
 VVWeYx  = 7
 VVovXC = 8
 VV3wHs = 9
 VV6eIS = 10
 VVYwmZ = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFNQkv(VVQ9al, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFVOCw(self, self.Title)
  FFdufS(self["keyRed"] , "OK = Zap")
  FFdufS(self["keyGreen"] , "Current Service")
  FFdufS(self["keyYellow"], "Page Options")
  FFdufS(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CC8ahC.VVmFFX()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVITUl    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVAfWb     ,
   "green"   : self.VVLDwr    ,
   "yellow"  : self.VV1mfg     ,
   "blue"   : self.VVssXw     ,
   "menu"   : self.VVm5IZ     ,
   "info"   : self.VVIGMT    ,
   "up"   : self.VVcoOu       ,
   "down"   : self.VV153S      ,
   "left"   : self.VVsfLd      ,
   "right"   : self.VVB1TT      ,
   "pageUp"  : BF(self.VVtEkV, True) ,
   "chanUp"  : BF(self.VVtEkV, True) ,
   "pageDown"  : BF(self.VVtEkV, False) ,
   "chanDown"  : BF(self.VVtEkV, False) ,
   "next"   : self.VV8kEj     ,
   "last"   : self.VVPPup      ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FFABOX(self)
  FFeAg3(self)
  FFg8wK(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
    self["myPosterLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFlaBE(self, BF(self.VVyzbD, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVm5IZ(self):
  if not self.isBusy:
   VVJ4QS = []
   VVJ4QS.append(("Statistics"           , "VVRLQs"    ))
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append(("Suggest PIcons for Current Channel"     , "VVp718"   ))
   VVJ4QS.append(("Set to Current Channel (copy file)"     , "VVpeAk_file"  ))
   VVJ4QS.append(("Set to Current Channel (as SymLink)"     , "VVpeAk_link"  ))
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append(("Export Current File Names List"      , "VV7IoF" ))
   VVJ4QS.append(CC8ahC.VVN4mg())
   VVJ4QS.append(VV4c5n)
   movTxt = "Move Unused PIcons to a Directory"
   delTxt = "DELETE Unused PIcons"
   if self.filterTitle == "PIcons without Channels":
    c = VVPUgM
    VVJ4QS.append((c + movTxt           , "VVJlA3"  ))
    VVJ4QS.append((c + delTxt           , "VVuTnA" ))
   else:
    disTxt = " (Filter >> Unused PIcons)"
    VVJ4QS.append((movTxt + disTxt         ,       ))
    VVJ4QS.append((delTxt + disTxt         ,       ))
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVPUQo"  ))
   VVJ4QS.append(VV4c5n)
   VVJ4QS += CC8ahC.VV1TeT()
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append(("Change Poster/Picon Transparency Color"    , "VV9N9v"  ))
   VVJ4QS.append(("Keys Help"           , "VVary2"    ))
   FFZP3S(self, self.VVgSzF, width=1100, height=1050, title=self.Title, VVJ4QS=VVJ4QS)
 def VVgSzF(self, item=None):
  if item is not None:
   if   item == "VVRLQs"     : self.VVRLQs()
   elif item == "VVp718"    : self.VVp718()
   elif item == "VVpeAk_file"   : self.VVpeAk(0)
   elif item == "VVpeAk_link"   : self.VVpeAk(1)
   elif item == "VV7IoF"   : self.VV7IoF()
   elif item == "VV6Wt9"   : CC8ahC.VV6Wt9(self)
   elif item == "VVJlA3"    : self.VVJlA3()
   elif item == "VVuTnA"   : self.VVuTnA()
   elif item == "VVPUQo"   : self.VVPUQo()
   elif item == "VVuWBg"   : CC8ahC.VVuWBg(self)
   elif item == "findPiconBrokenSymLinks"  : CC8ahC.VVGBpq(self, True)
   elif item == "FindAllBrokenSymLinks"  : CC8ahC.VVGBpq(self, False)
   elif item == "VV9N9v"   : self.VV9N9v()
   elif item == "VVary2"      : self.VVary2()
 def VV1mfg(self):
  if not self.isBusy:
   VVJ4QS = []
   VVJ4QS.append(("Go to First PIcon"  , "VVQ4Nx"  ))
   VVJ4QS.append(("Go to Last PIcon"   , "VVGprW"  ))
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append(("Sort by Channel Name"     , "sortByChan" ))
   VVJ4QS.append(("Sort by File Name"  , "sortByFile" ))
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append(("Find from File List .." , "VVuFAi" ))
   FFZP3S(self, self.VVvoYi, title=self.Title, VVJ4QS=VVJ4QS)
 def VVvoYi(self, item=None):
  if item is not None:
   if   item == "VVQ4Nx"   : self.VVQ4Nx()
   elif item == "VVGprW"   : self.VVGprW()
   elif item == "sortByChan"  : self.VVFGC1(2)
   elif item == "sortByFile"  : self.VVFGC1(0)
   elif item == "VVuFAi"  : self.VVuFAi()
 def VV9N9v(self):
  fg = bg = CFG.transpColorPicons.getValue()
  self.session.openWithCallback(self.VVQuHV, CCSXlr, defFG=fg, defBG=bg, onlyBG=True)
 def VVQuHV(self, fg, bg):
  if bg:
   FFu7KK(CFG.transpColorPicons, bg)
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FFg8wK(self["myPosterRep%d%d" % (row, col)], bg)
 def VVary2(self):
  FFrc1O(self, VVnEh8 + "_help_picons", "PIcons Tools (Keys Help)")
 def VVcoOu(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVGprW()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VV3ncm()
 def VV153S(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVQ4Nx()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VV3ncm()
 def VVsfLd(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVGprW()
  else:
   self.curCol -= 1
   self.VV3ncm()
 def VVB1TT(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVQ4Nx()
  else:
   self.curCol += 1
   self.VV3ncm()
 def VVPPup(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VV3ncm(True)
 def VV8kEj(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VV3ncm(True)
 def VVQ4Nx(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VV3ncm(True)
 def VVGprW(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VV3ncm(True)
 def VVuFAi(self):
  VVJ4QS = []
  for item in self.VVITUl:
   VVJ4QS.append((item[0], item[0]))
  FFZP3S(self, self.VVKobG, title='PIcons ".png" Files', VVJ4QS=VVJ4QS, VV7GES=True)
 def VVKobG(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVq3bA(ndx)
 def VVAfWb(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVwYn7()
   if refCode:
    FFbrIp(self, refCode)
    self.VVwScS()
    self.VVbMss()
 def VVtEkV(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVwScS()
   self.VVbMss()
  except:
   pass
 def VVLDwr(self):
  if self["keyGreen"].getVisible():
   self.VVq3bA(self.curChanIndex)
 def VVq3bA(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VV3ncm(True)
  else:
   FFHbVj(self, "Not found", 1000)
 def VVFGC1(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFlaBE(self, BF(self.VVyzbD, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVpeAk(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVwYn7()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVJ4QS = []
     VVJ4QS.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVJ4QS.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFZP3S(self, BF(self.VVdC9E, mode, curChF, selPiconF), VVJ4QS=VVJ4QS, title="Current Channel PIcon (already exists)")
    else:
     self.VVdC9E(mode, curChF, selPiconF, "overwrite")
   else:
    FFfYN0(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFfYN0(self, "Could not read current channel info. !", title=title)
 def VVdC9E(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFlaBE(self, BF(self.VVyzbD, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVJlA3(self):
  defDir = FFegwS(CC8ahC.VVmFFX() + "picons_backup")
  os.system(FFyto6("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(BF(self.VVJzme, defDir), BF(CCqXgM
         , mode=CCqXgM.VViiv3, VVjq2g=CC8ahC.VVmFFX()))
 def VVJzme(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CC8ahC.VVmFFX():
    FFfYN0(self, "Cannot move to same directory !", title=title)
   else:
    if not FFegwS(path) == FFegwS(defDir):
     self.VVWHxr(defDir)
    FFZw7B(self, BF(FFlaBE, self, BF(self.VVIDB6, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVITUl), path), title=title)
  else:
   self.VVWHxr(defDir)
 def VVIDB6(self, title, defDir, toPath):
  if not iMove:
   self.VVWHxr(defDir)
   FFfYN0(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FFegwS(toPath)
  pPath = CC8ahC.VVmFFX()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVITUl:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVITUl)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFCxQN(self, txt, title=title, VVop6p="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVGfQP("all")
 def VVWHxr(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVuTnA(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVITUl)
  FFZw7B(self, BF(FFlaBE, self, BF(self.VVpv8r, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FFIMVJ(tot)), title=title)
 def VVpv8r(self, title):
  pPath = CC8ahC.VVmFFX()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVITUl:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVITUl)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFrGgO(str(totErr), VVFBP5)
  FFCxQN(self, txt, title=title)
 def VVPUQo(self):
  lines = FFz7l2("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FFZw7B(self, BF(self.VVUNgE, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FFIMVJ(tot)), VV5RdC=True)
  else:
   FF8O6K(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVUNgE(self, fList):
  os.system(FFyto6("find -L '%s' -type l -delete" % self.pPath))
  FF8O6K(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVIGMT(self):
  FFlaBE(self, self.VVYd6X)
 def VVYd6X(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVwYn7()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFrGgO("PIcon Directory:\n", VVE6YJ)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FFGMwb(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFGMwb(path)
   txt += FFrGgO("PIcon File:\n", VVE6YJ)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FFrGgO("Found %d SymLink%s to this file from:\n" % (tot, FFIMVJ(tot)), VVE6YJ)
     for fPath in slLst:
      txt += "  %s\n" % FFrGgO(fPath, VVyLoh)
     txt += "\n"
   if chName:
    txt += FFrGgO("Channel:\n", VVE6YJ)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFrGgO(chName, VVqQXm)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FFrGgO("Remarks:\n", VVE6YJ)
    txt += "  %s\n" % FFrGgO("Unused", VVFBP5)
  else:
   txt = "No info found"
  FFzeU3(self, fncMode=CCy52I.VVKdDX, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVwYn7(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVITUl[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFjx2y(sat)
  return fName, refCode, chName, sat, inDB
 def VVwScS(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVITUl):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVbMss(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVwYn7()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFrGgO("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVE6YJ))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVwYn7()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFrGgO(self.curChanName, VVy0iZ)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVRLQs(self):
  VV7i3E, VVMouC = FFxdEf()
  sTypeNameDict = {}
  for key, val in VVMouC.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVITUl:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VVMouC: sTypeDict[VVMouC[stNum]] = sTypeDict.get(VVMouC[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFIgoM("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVjhh4 = []
  c = "#b#11003333#"
  VVjhh4.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalPIcons, totUsedFiles + totUsedLinks)))
  VVjhh4.append((c + "Files" , "%d\tUsed = %s" % (self.totalPIcons - totSymLinks, totUsedFiles)))
  VVjhh4.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVjhh4.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVjhh4.append((c + "Not In Database (lamedb)" , str(self.totalPIcons - totInDB)))
  VVjhh4.append((c + "Satellites"    , str(len(self.nsList))))
  VVjhh4.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVjhh4.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVjhh4.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVjhh4.extend(sTypeRows)
  FFA1pv(self, None, title=self.Title, VVITUl=VVjhh4, VVy2kz=28, VViLdG="#00003333", VVmDPu="#00222222")
 def VV7IoF(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FFegwS(CFG.exportedTablesPath.getValue()), txt, FFSZ6D())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVITUl:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FF8O6K(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVssXw(self):
  if not self.isBusy:
   VVJ4QS = []
   VVJ4QS.append(("All"         , "all"   ))
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append(("Used by Channels"      , "used"  ))
   VVJ4QS.append(("Unused PIcons"      , "unused"  ))
   VVJ4QS.append(("IPTV PIcons"       , "iptv"  ))
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append(("PIcons Files"       , "pFiles"  ))
   VVJ4QS.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVJ4QS.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVJ4QS.append(("By Files Date ..."     , "pDate"  ))
   VVJ4QS.append(("By Service Type ..."     , "servType" ))
   if self.nsList:
    VVJ4QS.append(FFksVn("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFBdLm(val)
      VVJ4QS.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCMA5J(self)
   filterObj.VVvh0P(VVJ4QS, self.nsList, self.VVgaXB)
 def VVgaXB(self, item=None):
  if item is not None:
   self.VVGfQP(item)
 def VVGfQP(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVl3wU   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVonfY   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVICbz  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVZzQ5   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVNhHP  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVzVO6  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVazwe  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VV6eIS , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVYwmZ , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVWeYx   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVovXC , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVazwe:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFz7l2("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFbSa4(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFHbVj(self, "Not found", 1000)
     return
   elif mode == self.VV6eIS:
    self.VViuNx(mode)
    return
   elif mode == self.VVYwmZ:
    self.VVeBpC(mode)
    return
   elif mode == self.VV3wHs:
    return
   else:
    words, asPrefix = CCMA5J.VVBkhG(words)
   if not words and mode in (self.VVWeYx, self.VVovXC):
    FFHbVj(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFlaBE(self, BF(self.VVyzbD, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VViuNx(self, mode):
  VVJ4QS = []
  VVJ4QS.append(("Today"   , "today" ))
  VVJ4QS.append(("Since Yesterday" , "yest" ))
  VVJ4QS.append(("Since 7 days"  , "week" ))
  FFZP3S(self, BF(self.VV4xvE, mode), VVJ4QS=VVJ4QS, title="Filter by Added/Modified Date")
 def VV4xvE(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFWucH(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFWucH(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFWucH(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FFlaBE(self, BF(self.VVyzbD, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVeBpC(self, mode):
  VV7i3E, VVMouC = FFxdEf()
  lst = set()
  for key, val in VVMouC.items():
   lst.add(val)
  VVJ4QS = []
  for item in lst:
   VVJ4QS.append((item, item))
  VVJ4QS.sort(key=lambda x: x[0])
  FFZP3S(self, BF(self.VVs4JO, mode), VVJ4QS=VVJ4QS, title="Filter by Service Type")
 def VVs4JO(self, mode, item=None):
  if item:
   VV7i3E, VVMouC = FFxdEf()
   sTypeList = []
   for key, val in VVMouC.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FFlaBE(self, BF(self.VVyzbD, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVp718(self):
  self.session.open(CCwieb, barTheme=CCwieb.VV8xER
      , titlePrefix = ""
      , fncToRun  = self.VVw6Bn
      , VVGpYx = self.VVMkkg)
 def VVw6Bn(self, VVqtmp):
  VVUIlQ, err = CCpE07.VV5WFr(self, CCpE07.VVARox, VVlRYz=False, VVfXeW=False)
  files = []
  words = []
  if not VVqtmp or VVqtmp.isCancelled:
   return
  VVqtmp.VV1c0w = []
  VVqtmp.VVZre9(len(VVUIlQ))
  if VVUIlQ:
   VVrYfH = CCIrc5()
   curCh = VVrYfH.VV97qa(self.curChanName)
   for refCode in VVUIlQ:
    if not VVqtmp or VVqtmp.isCancelled:
     return
    VVqtmp.VVIW1d(1, True)
    chName, sat, inDB = VVUIlQ.get(refCode, ("", "", 0))
    ratio = CC8ahC.VVeBuF(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CC8ahC.VVHSDz(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFbSa4(f)
       fil = f.replace(".png", "")
       if not fil in VVqtmp.VV1c0w:
        VVqtmp.VV1c0w.append(fil)
 def VVMkkg(self, VVLpbv, VV1c0w, threadCounter, threadTotal, threadErr):
  if VV1c0w : FFlaBE(self, BF(self.VVyzbD, mode=self.VV3wHs, words=VV1c0w), title="Loading ...")
  else   : FFHbVj(self, "Not found", 2000)
 def VVyzbD(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VVv7tI(isFirstTime):
   return
  self.isBusy = True
  VVfXeW = True if isFirstTime else False
  VVUIlQ, err = CCpE07.VV5WFr(self, CCpE07.VVARox, VVlRYz=False, VVfXeW=VVfXeW)
  if err:
   self.close()
  iptvRefList = self.VVuUKu()
  tList = []
  for fName, fType in CC8ahC.VVSlLY(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVUIlQ:
    if fName in VVUIlQ:
     chName, sat, inDB = VVUIlQ.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVl3wU:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVonfY  and chName         : isAdd = True
   elif mode == self.VVICbz and not chName        : isAdd = True
   elif mode == self.VVNhHP  and fType == 0        : isAdd = True
   elif mode == self.VVzVO6  and fType == 1        : isAdd = True
   elif mode == self.VVazwe  and fName in words       : isAdd = True
   elif mode == self.VV3wHs and fName in words       : isAdd = True
   elif mode == self.VVZzQ5  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVWeYx  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVovXC:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VV6eIS:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVYwmZ:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVITUl   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FFHbVj(self)
  else:
   self.isBusy = False
   FFHbVj(self, "Not found", 1000)
   return
  self.VVITUl.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVwScS()
  self.totalPIcons = len(self.VVITUl)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VV3ncm(True)
 def VVv7tI(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CC8ahC.VVSlLY(self.pPath):
    if fName:
     return True
   if isFirstTime : FFfYN0(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFHbVj(self, "Not found", 1000)
  else:
   FFfYN0(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVuUKu(self):
  VVjhh4 = {}
  files  = CCCwQV.VVplgE()
  if files:
   for path in files:
    txt = FFZF5l(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVjhh4[refCode] = item[1]
  return VVjhh4
 def VV3ncm(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVrNRN = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVrNRN: self.curPage = VVrNRN
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVtfQT()
  if self.curPage == VVrNRN:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPosterPic%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVbMss()
  filName, refCode, chName, sat, inDB = self.VVwYn7()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVtfQT(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVITUl[ndx]
   fName = self.VVITUl[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFrGgO(chName, VVqQXm))
    else : lbl.setText("-")
   except:
    lbl.setText(FFrGgO(chName, VVOBCT))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVeBuF(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVN4mg():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VV6Wt9"   )
 @staticmethod
 def VV1TeT():
  VVJ4QS = []
  VVJ4QS.append(("Find SymLinks (to PIcon Directory)"   , "VVuWBg"   ))
  VVJ4QS.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVJ4QS.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVJ4QS
 @staticmethod
 def VV6Wt9(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(SELF)
  png, path = CC8ahC.VVt2aC(refCode)
  if path : CC8ahC.VVFpaA(SELF, png, path)
  else : FFfYN0(SELF, "No PIcon found for current channel in:\n\n%s" % CC8ahC.VVmFFX())
 @staticmethod
 def VVuWBg(SELF):
  if VVy0iZ:
   sed1 = FFT6nF("->", VVy0iZ)
   sed2 = FFT6nF("picon", VVFBP5)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVOBCT, VVCLGj)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFy4dI(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFRjyr(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVGBpq(SELF, isPIcon):
  sed1 = FFT6nF("->", VVOBCT)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFT6nF("picon", VVFBP5)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFy4dI(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFRjyr(), grep, sed1, sed2))
 @staticmethod
 def VVSlLY(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVmFFX():
  path = CFG.PIconsPath.getValue()
  return FFegwS(path)
 @staticmethod
 def VVt2aC(refCode, chName=None):
  if FFCeZx(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFeiz0(refCode)
  allPath, fName, refCodeFile, pList = CC8ahC.VVHSDz(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVFpaA(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFT6nF("%s%s" % (dest, png), VVqQXm))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFT6nF(errTxt, VVwmjQ))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFJWo9(SELF, cmd)
 @staticmethod
 def VVHSDz(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CC8ahC.VVmFFX()
   pList = []
   lst = FFQ9JP(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FFVK2H(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFbSa4(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CC0N3n():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVpzW1  = None
  self.VVkhyF = ""
  self.VVDxvD  = noService
  self.VVrkV6 = 0
  self.VVRJmG  = noService
  self.VVfubN = 0
  self.VV2YiL  = "-"
  self.VVSgPF = 0
  self.VVyZ6Q  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VV0aS2(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVpzW1 = frontEndStatus
     self.VVEc9v()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVEc9v(self):
  if self.VVpzW1:
   val = self.VVpzW1.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVkhyF = "%3.02f dB" % (val / 100.0)
   else         : self.VVkhyF = ""
   val = self.VVpzW1.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVrkV6 = int(val)
   self.VVDxvD  = "%d%%" % val
   val = self.VVpzW1.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVfubN = int(val)
   self.VVRJmG  = "%d%%" % val
   val = self.VVpzW1.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VV2YiL  = "%d" % val
   val = int(val * 100 / 500)
   self.VVSgPF = min(500, val)
   val = self.VVpzW1.get("tuner_locked", 0)
   if val == 1 : self.VVyZ6Q = "Locked"
   else  : self.VVyZ6Q = "Not locked"
 def VVAub0(self)   : return self.VVkhyF
 def VVOTyr(self)   : return self.VVDxvD
 def VVNxyB(self)  : return self.VVrkV6
 def VV1KVl(self)   : return self.VVRJmG
 def VVWnjE(self)  : return self.VVfubN
 def VVnfG0(self)   : return self.VV2YiL
 def VV90cW(self)  : return self.VVSgPF
 def VVwlfx(self)   : return self.VVyZ6Q
 def VVolxX(self) : return self.serviceName
class CCoeZX():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VV2mCL(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFUjGn(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVhUQx(self.ORPOS  , mod=1   )
      self.sat2  = self.VVhUQx(self.ORPOS  , mod=2   )
      self.freq  = self.VVhUQx(self.FREQ  , mod=3   )
      self.sr   = self.VVhUQx(self.SR   , mod=4   )
      self.inv  = self.VVhUQx(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVhUQx(self.POL  , self.D_POL )
      self.fec  = self.VVhUQx(self.FEC  , self.D_FEC )
      self.syst  = self.VVhUQx(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVhUQx("modulation" , self.D_MOD )
       self.rolof = self.VVhUQx("rolloff"  , self.D_ROLOF )
       self.pil = self.VVhUQx("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVhUQx("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVhUQx("pls_code"  )
       self.iStId = self.VVhUQx("is_id"   )
       self.t2PlId = self.VVhUQx("t2mi_plp_id" )
       self.t2PId = self.VVhUQx("t2mi_pid"  )
 def VVhUQx(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFBdLm(val)
  elif mod == 2   : return FF80S3(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VVHlnR(self, refCode):
  txt = ""
  self.VV2mCL(refCode)
  if self.data:
   def VVzg89(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVzg89("System"   , self.syst)
    txt += VVzg89("Satellite"  , self.sat2)
    txt += VVzg89("Frequency"  , self.freq)
    txt += VVzg89("Inversion"  , self.inv)
    txt += VVzg89("Symbol Rate"  , self.sr)
    txt += VVzg89("Polarization" , self.pol)
    txt += VVzg89("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVzg89("Modulation" , self.mod)
     txt += VVzg89("Roll-Off" , self.rolof)
     txt += VVzg89("Pilot"  , self.pil)
     txt += VVzg89("Input Stream", self.iStId)
     txt += VVzg89("T2MI PLP ID" , self.t2PlId)
     txt += VVzg89("T2MI PID" , self.t2PId)
     txt += VVzg89("PLS Mode" , self.plsMod)
     txt += VVzg89("PLS Code" , self.plsCod)
   else:
    txt += VVzg89("System"   , self.txMedia)
    txt += VVzg89("Frequency"  , self.freq)
  return txt, self.namespace
 def VVgEGr(self, refCode):
  txt = "Transpoder : ?"
  self.VV2mCL(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVcy5m(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFUjGn(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVhUQx(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVhUQx(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVhUQx(self.SYST, self.D_SYS_S)
     freq = self.VVhUQx(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVhUQx(self.POL , self.D_POL)
      fec = self.VVhUQx(self.FEC , self.D_FEC)
      sr = self.VVhUQx(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVQtNM(self, refCode):
  self.data = None
  self.VV2mCL(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCbzSm():
 def __init__(self, VVszCG, path, VVGpYx=None, curRowNum=-1):
  self.VVszCG  = VVszCG
  self.origFile   = path
  self.Title    = "File Editor: " + FFbSa4(path)
  self.VVGpYx  = VVGpYx
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  response = os.system(FFyto6("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVe2Pz(curRowNum)
  else:
   FFfYN0(self.VVszCG, "Error while preparing edit!")
 def VVe2Pz(self, curRowNum):
  VVjhh4 = self.VVTAXT()
  VV7wPX = ("Save Changes" , self.VVCgXY   , [])
  VVHFFO  = ("Edit Line"  , self.VVpCVU    , [])
  VVbdhP = ("Go to Line Num" , self.VVpC5E   , [])
  VVUB3Q = ("Line Options" , self.VViTVL   , [])
  VVcwgo = (""    , self.VVZHcb , [])
  VVzffX = self.VVtm9P
  VV597P  = self.VV4LPq
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVavJp  = (CENTER  , LEFT  )
  VVToDv = FFA1pv(self.VVszCG, None, title=self.Title, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VV7wPX=VV7wPX, VVHFFO=VVHFFO, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q, VVzffX=VVzffX, VV597P=VV597P, VVcwgo=VVcwgo, VVFvoI=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
    , VV1Y9q   = "#11001111"
    , VVMnLe   = "#11001111"
    , VVop6p   = "#11001111"
    , VViLdG  = "#05333333"
    , VVmDPu  = "#00222222"
    , VV15Y9  = "#11331133"
    )
  VVToDv.VVeb2k(curRowNum)
 def VVpC5E(self, VVToDv, title, txt, colList):
  totRows = VVToDv.VVLfEh()
  lineNum = VVToDv.VVYt3A() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FFoW9P(self.VVszCG, BF(self.VVv0h2, VVToDv, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VVv0h2(self, VVToDv, lineNum, totRows, VVRnvB):
  if VVRnvB:
   VVRnvB = VVRnvB.strip()
   if VVRnvB.isdigit():
    num = FFle5S(int(VVRnvB) - 1, 0, totRows)
    VVToDv.VVeb2k(num)
    self.lastLineNum = num + 1
   else:
    FFHbVj(VVToDv, "Incorrect number", 1500)
 def VViTVL(self, VVToDv, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVToDv.VVp58T()
  VVJ4QS = []
  VVJ4QS.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVJ4QS.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VV9Tli"  ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVgXBs:
   VVJ4QS.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(  ("Delete Line"         , "deleteLine"   ))
  FFZP3S(self.VVszCG, BF(self.VVNn8q, VVToDv, lineNum), VVJ4QS=VVJ4QS, title="Line Options")
 def VVNn8q(self, VVToDv, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVU5gp("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVToDv)
   elif item == "VV9Tli"  : self.VV9Tli(VVToDv, lineNum)
   elif item == "copyToClipboard"  : self.VV0V1L(VVToDv, lineNum)
   elif item == "pasteFromClipboard" : self.VVYZAV(VVToDv, lineNum)
   elif item == "deleteLine"   : self.VVU5gp("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVToDv)
 def VV4LPq(self, VVToDv):
  VVToDv.VVNsz9()
 def VVZHcb(self, VVToDv, title, txt, colList):
  if   self.insertMode == 1: VVToDv.VVwR15()
  elif self.insertMode == 2: VVToDv.VVZAOC()
  self.insertMode = 0
 def VV9Tli(self, VVToDv, lineNum):
  if lineNum == VVToDv.VVp58T():
   self.insertMode = 1
   self.VVU5gp("echo '' >> '%s'" % self.tmpFile, VVToDv)
  else:
   self.insertMode = 2
   self.VVU5gp("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVToDv)
 def VV0V1L(self, VVToDv, lineNum):
  global VVgXBs
  VVgXBs = FFIgoM("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVToDv.VVB7wY("Copied to clipboard")
 def VVCgXY(self, VVToDv, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFyto6("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFyto6("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVToDv.VVB7wY("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVToDv.VVNsz9()
    else:
     FFfYN0(self.VVszCG, "Cannot save file!")
   else:
    FFfYN0(self.VVszCG, "Cannot create backup copy of original file!")
 def VVtm9P(self, VVToDv):
  if self.fileChanged:
   FFZw7B(self.VVszCG, BF(self.VV5EIS, VVToDv), "Cancel changes ?")
  else:
   finalOK = os.system(FFyto6("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VV5EIS(VVToDv)
 def VV5EIS(self, VVToDv):
  VVToDv.cancel()
  FFM75P(self.tmpFile)
  if self.VVGpYx:
   self.VVGpYx(self.fileSaved)
 def VVpCVU(self, VVToDv, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVCLGj + "ORIGINAL TEXT:\n" + VVyLoh + lineTxt
  FFoW9P(self.VVszCG, BF(self.VVxciR, lineNum, VVToDv), title="File Line", defaultText=lineTxt, message=message)
 def VVxciR(self, lineNum, VVToDv, VVRnvB):
  if not VVRnvB is None:
   if VVToDv.VVp58T() <= 1:
    self.VVU5gp("echo %s > '%s'" % (VVRnvB, self.tmpFile), VVToDv)
   else:
    self.VVuMVu(VVToDv, lineNum, VVRnvB)
 def VVYZAV(self, VVToDv, lineNum):
  if lineNum == VVToDv.VVp58T() and VVToDv.VVp58T() == 1:
   self.VVU5gp("echo %s >> '%s'" % (VVgXBs, self.tmpFile), VVToDv)
  else:
   self.VVuMVu(VVToDv, lineNum, VVgXBs)
 def VVuMVu(self, VVToDv, lineNum, newTxt):
  VVToDv.VV3rfE("Saving ...")
  lines = FFup4P(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVToDv.VVKoUM()
  VVjhh4 = self.VVTAXT()
  VVToDv.VV3ih0(VVjhh4)
 def VVU5gp(self, cmd, VVToDv):
  tCons = CCjjBT()
  tCons.ePopen(cmd, BF(self.VVEZ1q, VVToDv))
  self.fileChanged = True
  VVToDv.VVKoUM()
 def VVEZ1q(self, VVToDv, result, retval):
  VVjhh4 = self.VVTAXT()
  VVToDv.VV3ih0(VVjhh4)
 def VVTAXT(self):
  if fileExists(self.tmpFile):
   lines = FFup4P(self.tmpFile)
   VVjhh4 = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVjhh4.append((str(ndx), line.strip()))
   if not VVjhh4:
    VVjhh4.append((str(1), ""))
   return VVjhh4
  else:
   FF6vdZ(self.VVszCG, self.tmpFile)
class CCMA5J():
 def __init__(self, callingSELF, VV1Y9q="#22003344", VVMnLe="#22002233"):
  self.callingSELF = callingSELF
  self.VVJ4QS  = []
  self.satList  = []
  self.VV1Y9q  = VV1Y9q
  self.VVMnLe   = VVMnLe
 def VVEg8v(self, VVGpYx):
  self.VVJ4QS = []
  VVJ4QS, VVlCEp = CCMA5J.VVqIre(self.callingSELF, False, True)
  if VVJ4QS:
   self.VVJ4QS += VVJ4QS
   self.VVwNYy(VVGpYx, VVlCEp)
 def VVvekh(self, mode, VVToDv, satCol, VVGpYx, inFilterFnc=None):
  VVToDv.VV3rfE("Loading Filters ...")
  self.VVJ4QS = []
  self.VVJ4QS.append(("All Services" , "all"))
  if mode == 1:
   self.VVJ4QS.append(VV4c5n)
   self.VVJ4QS.append(("Parental Control", "parentalControl"))
   self.VVJ4QS.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVJ4QS.append(VV4c5n)
   self.VVJ4QS.append(("Selected Transponder"   , "selectedTP" ))
   self.VVJ4QS.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVAxmE(VVToDv, satCol)
  VVJ4QS, VVlCEp = CCMA5J.VVqIre(self.callingSELF, True, False)
  if VVJ4QS:
   VVJ4QS.insert(0, FFksVn("Custom Words"))
   self.VVJ4QS += VVJ4QS
  VVToDv.VVDGPS()
  self.VVwNYy(VVGpYx, VVlCEp, inFilterFnc)
 def VVvh0P(self, VVJ4QS, sats, VVGpYx, inFilterFnc=None):
  self.VVJ4QS = VVJ4QS
  VVJ4QS, VVlCEp = CCMA5J.VVqIre(self.callingSELF, True, False)
  if VVJ4QS:
   self.VVJ4QS.append(FFksVn("Custom Words"))
   self.VVJ4QS += VVJ4QS
  self.VVwNYy(VVGpYx, VVlCEp, inFilterFnc)
 def VVwNYy(self, VVGpYx, VVlCEp, inFilterFnc=None):
  VV5lv1  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVU5gS = ("Edit Filter"  , BF(self.VVp84C, VVlCEp))
  VVaSnd  = ("Filter Help"  , BF(self.VVlXHS, VVlCEp))
  FFZP3S(self.callingSELF, BF(self.VVST1o, VVGpYx), VVJ4QS=self.VVJ4QS, title="Select Filter", VV5lv1=VV5lv1, VVU5gS=VVU5gS, VVaSnd=VVaSnd, VVbHGu=True, VV1Y9q=self.VV1Y9q, VVMnLe=self.VVMnLe)
 def VVST1o(self, VVGpYx, item):
  if item:
   VVGpYx(item)
 def VVp84C(self, VVlCEp, VVi8BRObj, sel):
  if fileExists(VVlCEp) : CCbzSm(self.callingSELF, VVlCEp, VVGpYx=None)
  else       : FF6vdZ(self.callingSELF, VVlCEp)
  VVi8BRObj.cancel()
 def VVlXHS(self, VVlCEp, VVi8BRObj, sel):
  FFrc1O(self.callingSELF, VVnEh8 + "_help_service_filter", "Service Filter")
 def VVAxmE(self, VVToDv, satColNum):
  if not self.satList:
   satList = VVToDv.VVBgAk(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFjx2y(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FFksVn("Satellites"))
  if self.VVJ4QS:
   self.VVJ4QS += self.satList
 @staticmethod
 def VVqIre(SELF, addTag, VVdnur):
  FFTS1C()
  fileName  = "ajpanel_services_filter"
  VVlCEp = VVL4Xa + fileName
  VVJ4QS  = []
  if not fileExists(VVlCEp):
   os.system(FFyto6("cp -f '%s' '%s'" % (VVnEh8 + fileName, VVlCEp)))
  fileFound = False
  if fileExists(VVlCEp):
   fileFound = True
   lines = FFup4P(VVlCEp)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVJ4QS.append((line, "__w__" + line))
       else  : VVJ4QS.append((line, line))
  if VVdnur:
   if   not fileFound : FF6vdZ(SELF, VVlCEp)
   elif not VVJ4QS : FFTXJH(SELF, VVlCEp)
  return VVJ4QS, VVlCEp
 @staticmethod
 def VVBkhG(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CC6FeI():
 def __init__(self, callingSELF, VVToDv, addSep=True):
  self.callingSELF = callingSELF
  self.VVToDv = VVToDv
  self.VVJ4QS = []
  iMulSel = self.VVToDv.VVF02t()
  if iMulSel : self.VVJ4QS.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVJ4QS.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVToDv.VVFx4F()
  self.VVJ4QS.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVJ4QS.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVJ4QS.append(VV4c5n)
 def VV9EgX(self, extraMenu, cbFncDict):
  if extraMenu:
   self.VVJ4QS.extend(extraMenu)
  FFZP3S(self.callingSELF, BF(self.VVAhPs, cbFncDict), title="Options", VVJ4QS=self.VVJ4QS)
 def VVAhPs(self, cbFncDict, item=None):
  if item:
   if   item == "multSelEnab" : self.VVToDv.VVQ2Pz(True)
   elif item == "MultSelDisab" : self.VVToDv.VVQ2Pz(False)
   elif item == "selectAll" : self.VVToDv.VVGnJp()
   elif item == "unselectAll" : self.VVToDv.VVG7vM()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
class CCOCDL(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFNQkv(VVvNKl, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFVOCw(self)
  FFdufS(self["keyRed"]  , "Exit")
  FFdufS(self["keyGreen"]  , "Save")
  FFdufS(self["keyYellow"] , "Refresh")
  FFdufS(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVChzf  ,
   "green"   : self.VVaHtM ,
   "yellow"  : self.VVECSn  ,
   "blue"   : self.VVAF94   ,
   "up"   : self.VVcoOu    ,
   "down"   : self.VV153S   ,
   "left"   : self.VVsfLd   ,
   "right"   : self.VVB1TT   ,
   "cancel"  : self.VVChzf
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VV47vn)
  self.onClose.append(self.onExit)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  self.VVECSn()
  self.VV9nV9()
  FFeAg3(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVvzzT)
  except:
   self.timer.callback.append(self.VVvzzT)
  self.timer.start(1000, False)
  self.VVvzzT()
 def onExit(self):
  self.timer.stop()
 def VVChzf(self) : self.close(True)
 def VV2GkI(self) : self.close(False)
 def VVAF94(self):
  self.session.openWithCallback(self.VV8CBq, BF(CC25MM))
 def VV8CBq(self, closeAll):
  if closeAll:
   self.close()
 def VVvzzT(self):
  self["curTime"].setText(str(FF4ENQ(iTime())))
 def VVcoOu(self):
  self.VVs2WP(1)
 def VV153S(self):
  self.VVs2WP(-1)
 def VVsfLd(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VV9nV9()
 def VVB1TT(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VV9nV9()
 def VVs2WP(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVn8Wj(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVn8Wj(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVn8Wj(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVV2VI(year)):
   days += 1
  return days
 def VVV2VI(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VV9nV9(self):
  for obj in self.list:
   FFg8wK(obj, "#11404040")
  FFg8wK(self.list[self.index], "#11ff8000")
 def VVECSn(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVaHtM(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCjjBT()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVMhv4)
 def VVMhv4(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FF8O6K(self, "Nothing returned from the system!")
  else:
   FF8O6K(self, str(result))
class CC25MM(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFNQkv(VVQhFe, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFVOCw(self, addLabel=True)
  FFdufS(self["keyRed"]  , "Exit")
  FFdufS(self["keyGreen"]  , "Sync")
  FFdufS(self["keyYellow"] , "Refresh")
  FFdufS(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVChzf   ,
   "green"   : self.VV1Ej3  ,
   "yellow"  : self.VVKiC1 ,
   "blue"   : self.VVmEfs  ,
   "cancel"  : self.VVChzf
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVXWqv()
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  FFeAg3(self)
  FFS6vB(self.refresh)
 def refresh(self):
  self.VV02yY()
  self.VVGsBZ(False)
 def VVChzf(self)  : self.close(True)
 def VVmEfs(self) : self.close(False)
 def VVXWqv(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VV02yY(self):
  self.VVTE0s()
  self.VVyAcA()
  self.VVqMtw()
  self.VVzW7M()
 def VVKiC1(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVXWqv()
   self.VV02yY()
   FFS6vB(self.refresh)
 def VV1Ej3(self):
  if len(self["keyGreen"].getText()) > 0:
   FFZw7B(self, self.VVRmpt, "Synchronize with Internet Date/Time ?")
 def VVRmpt(self):
  self.VV02yY()
  FFS6vB(BF(self.VVGsBZ, True))
 def VVTE0s(self)  : self["keyRed"].show()
 def VVWxEO(self)  : self["keyGreen"].show()
 def VVmiK8(self) : self["keyYellow"].show()
 def VVw7P5(self)  : self["keyBlue"].show()
 def VVyAcA(self)  : self["keyGreen"].hide()
 def VVqMtw(self) : self["keyYellow"].hide()
 def VVzW7M(self)  : self["keyBlue"].hide()
 def VVGsBZ(self, sync):
  localTime = FFkTm6()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVg4D8(server)
   if epoch_time is not None:
    ntpTime = FF4ENQ(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCjjBT()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VVMhv4, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVmiK8()
  self.VVw7P5()
  if ok:
   self.VVWxEO()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVMhv4(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVGsBZ(False)
  except:
   pass
 def VVg4D8(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFHkZ8():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCjdSK(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFNQkv(VVZpaa, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FFVOCw(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FFS6vB(self.VVzuwl)
 def VVzuwl(self):
  if FFHkZ8(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFg8wK(self["myBody"], color)
   FFg8wK(self["myLabel"], color)
  except:
   pass
class CCFRcE(Screen):
 VVCwPJ = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFerEQ()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFNQkv(VVLVhk, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCREAv(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCREAv(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCREAv(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CC0N3n()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFVOCw(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close      ,
   "up"  : self.VVcoOu       ,
   "down"  : self.VV153S      ,
   "left"  : self.VVsfLd      ,
   "right"  : self.VVB1TT      ,
   "info"  : self.VVRqIL     ,
   "epg"  : self.VVRqIL     ,
   "menu"  : self.VVary2      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVpAeE, -1)  ,
   "next"  : BF(self.VVpAeE, 1)  ,
   "pageUp" : BF(self.VV2kFN, True) ,
   "chanUp" : BF(self.VV2kFN, True) ,
   "pageDown" : BF(self.VV2kFN, False) ,
   "chanDown" : BF(self.VV2kFN, False) ,
   "0"   : BF(self.VVpAeE, 0)  ,
   "1"   : BF(self.VV7Y6K, pos=1) ,
   "2"   : BF(self.VV7Y6K, pos=2) ,
   "3"   : BF(self.VV7Y6K, pos=3) ,
   "4"   : BF(self.VV7Y6K, pos=4) ,
   "5"   : BF(self.VV7Y6K, pos=5) ,
   "6"   : BF(self.VV7Y6K, pos=6) ,
   "7"   : BF(self.VV7Y6K, pos=7) ,
   "8"   : BF(self.VV7Y6K, pos=8) ,
   "9"   : BF(self.VV7Y6K, pos=9) ,
  }, -1)
  self.onShown.append(self.VV47vn)
  self.onClose.append(self.onExit)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  if not CCFRcE.VVCwPJ:
   CCFRcE.VVCwPJ = self
  self.sliderSNR.VV1dsT()
  self.sliderAGC.VV1dsT()
  self.sliderBER.VV1dsT(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VV7Y6K()
  self.VVpGw3()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVlv8W)
  except:
   self.timer.callback.append(self.VVlv8W)
  self.timer.start(500, False)
 def VVpGw3(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VV0aS2(service)
  serviceName = self.tunerInfo.VVolxX()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self)
  tp = CCoeZX()
  tpTxt, satTxt = tp.VVgEGr(refCode)
  if tpTxt == "?" :
   tpTxt = FFrGgO("NO SIGNAL", VVPUgM)
  self["myTPInfo"].setText(tpTxt + "  " + FFrGgO(satTxt, VVtSeQ))
 def VVlv8W(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VV0aS2(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVAub0())
   self["mySNR"].setText(self.tunerInfo.VVOTyr())
   self["myAGC"].setText(self.tunerInfo.VV1KVl())
   self["myBER"].setText(self.tunerInfo.VVnfG0())
   self.sliderSNR.VVSbIi(self.tunerInfo.VVNxyB())
   self.sliderAGC.VVSbIi(self.tunerInfo.VVWnjE())
   self.sliderBER.VVSbIi(self.tunerInfo.VV90cW())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVSbIi(0)
   self.sliderAGC.VVSbIi(0)
   self.sliderBER.VVSbIi(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self)
    if state and not state == "Tuned":
     FFHbVj(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVRqIL(self):
  FFzeU3(self, fncMode=CCy52I.VVvTvR)
 def VVary2(self):
  FFrc1O(self, VVnEh8 + "_help_signal", "Signal Monitor (Keys)")
 def VVcoOu(self)  : self.VV7Y6K(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VV153S(self) : self.VV7Y6K(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVsfLd(self) : self.VV7Y6K(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVB1TT(self) : self.VV7Y6K(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VV7Y6K(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FFu7KK(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVpAeE(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFle5S(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FFu7KK(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CCFRcE.VVCwPJ = None
 def VV2kFN(self, isUp):
  FFHbVj(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVpGw3()
  except:
   pass
class CCREAv(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VV1dsT(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFg8wK(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVnEh8 +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFg8wK(self.covObj, self.covColor)
   else:
    FFg8wK(self.covObj, "#00006688")
    self.isColormode = True
  self.VVSbIi(0)
 def VVSbIi(self, val):
  val  = FFle5S(val, self.minN, self.maxN)
  width = int(FFWAiI(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFle5S(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCwieb(Screen):
 VV8xER    = 0
 VVkrqu = 1
 VVOLYp = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVGpYx=None, barTheme=VV8xER):
  ratio = self.VVjDt1(barTheme)
  self.skin, self.skinParam = FFNQkv(VVQp8r, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVGpYx = VVGpYx
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VV1c0w = None
  self.timer   = eTimer()
  self.myThread  = None
  FFVOCw(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VV47vn)
  self.onClose.append(self.onExit)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  self.VVt90Q()
  self["myProgBarVal"].setText("0%")
  FFg8wK(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVBkYm()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVBkYm)
  except:
   self.timer.callback.append(self.VVBkYm)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVZre9(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVQEx6(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VV1c0w), self.counter, self.maxValue, catName)
 def VVjt3f(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVYFbK(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VVtvgL(self, title):
  self.newTitle = title
  try:
   self.VVBkYm()
  except:
   pass
 def VVhQo4(self, txt):
  self.newTitle = txt
 def VVIW1d(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VV1c0w), self.counter, self.maxValue)
  except:
   pass
 def VVf1y5(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVkjpP(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVUtKe(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFHbVj(self, "Cancelling ...")
  self.isCancelled = True
  self.VVCXUs(False)
 def VVCXUs(self, isDone):
  if self.VVGpYx:
   self.VVGpYx(isDone, self.VV1c0w, self.counter, self.maxValue, self.isError)
  self.close()
 def VVBkYm(self):
  val = FFle5S(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFWAiI(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VVCXUs(True)
 def VVt90Q(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVkrqu, self.VVOLYp):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVjDt1(self, barTheme):
  if   barTheme == self.VVkrqu : return 0.7
  if   barTheme == self.VVOLYp : return 0.5
  else             : return 1
class CCjjBT(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVGpYx = {}
  self.commandRunning = False
  self.VVZWSD  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVGpYx, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVGpYx[name] = VVGpYx
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVZWSD:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVM3Ug, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVFcPe , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVM3Ug, name))
    self.appContainers[name].appClosed.append(BF(self.VVFcPe , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVFcPe(name, retval)
  return True
 def VVM3Ug(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FFrGgO("[UN-DECODED STRING]", VVPUgM))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVFcPe(self, name, retval):
  if not self.VVZWSD:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVGpYx[name]:
   self.VVGpYx[name](self.appResults[name], retval)
  del self.VVGpYx[name]
 def VVqGsj(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCZgNT(Screen):
 def __init__(self, session, title="", VVe6kp=None, VVpwtj=False, VVEmyj=False, VV644R=False, VVUCBd=False, VVMHrW=False, VVLemo=False, VVbIg5=VVBuVN, VV5en0=None, VVqN8X=False, VVzShN=None, VV4FcT="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFNQkv(VVpCD5, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFVOCw(self, addScrollLabel=True)
  if not VV4FcT:
   VV4FcT = "Processing ..."
  self["myLabel"].setText("   %s" % VV4FcT)
  self.VVpwtj   = VVpwtj
  self.VVEmyj   = VVEmyj
  self.VV644R   = VV644R
  self.VVUCBd  = VVUCBd
  self.VVMHrW = VVMHrW
  self.VVLemo = VVLemo
  self.VVbIg5   = VVbIg5
  self.VV5en0 = VV5en0
  self.VVqN8X  = VVqN8X
  self.VVzShN  = VVzShN
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCjjBT()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFyAmw()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVe6kp, str):
   self.VVe6kp = [VVe6kp]
  else:
   self.VVe6kp = VVe6kp
  if self.VV644R or self.VVUCBd:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVU8ll, VVU8ll)
   self.VVe6kp.append("echo -e '\n%s\n' %s" % (restartNote, FFT6nF(restartNote, VVy0iZ)))
   if self.VV644R:
    self.VVe6kp.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVe6kp.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVMHrW:
   FFHbVj(self, "Processing ...")
  self.onLayoutFinish.append(self.VVB1wL)
  self.onClose.append(self.VVqQGX)
 def VVB1wL(self):
  self["myLabel"].VVYtUm(outputFileToSave="console" if self.enableSaveRes else "")
  if self.VVpwtj:
   self["myLabel"].VVy8Bm()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVylzM()
  else:
   self.VVkJNy()
 def VVylzM(self):
  if FFHkZ8():
   self["myLabel"].setText("Processing ...")
   self.VVkJNy()
  else:
   self["myLabel"].setText(FFrGgO("\n   No connection to internet!", VVFBP5))
 def VVkJNy(self):
  allOK = self.container.ePopen(self.VVe6kp[0], self.VVWY60, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVWY60("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVLemo or self.VV644R or self.VVUCBd:
    self["myLabel"].setText(FFEuDm("STARTED", VVy0iZ) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVzShN:
   colorWhite = CCr1Ch.VVDcL5(VVCLGj)
   color  = CCr1Ch.VVDcL5(self.VVzShN[0])
   words  = self.VVzShN[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVbIg5=self.VVbIg5)
 def VVWY60(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVe6kp):
   allOK = self.container.ePopen(self.VVe6kp[self.cmdNum], self.VVWY60, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVWY60("Cannot connect to Console!", -1)
  else:
   if self.VVMHrW and FFGcL0(self):
    FFHbVj(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVLemo:
    self["myLabel"].appendText("\n" + FFEuDm("FINISHED", VVy0iZ), self.VVbIg5)
   if self.VVpwtj or self.VVEmyj:
    self["myLabel"].VVy8Bm()
   if self.VV5en0 is not None:
    self.VV5en0()
   if not retval and self.VVqN8X:
    self.VVqQGX()
 def VVqQGX(self):
  if self.container.VVqGsj():
   self.container.killAll()
class CCiQFL(Screen):
 def __init__(self, session, VVe6kp=None, VVMHrW=False):
  self.skin, self.skinParam = FFNQkv(VVpCD5, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVL4Xa + "ajpanel_terminal.history"
  self.customCommandsFile = VVL4Xa + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFIgoM("pwd") or "/home/root"
  self.container   = CCjjBT()
  FFVOCw(self, addScrollLabel=True)
  FFdufS(self["keyRed"] , "Exit = Stop Command")
  FFdufS(self["keyGreen"] , "OK = History")
  FFdufS(self["keyYellow"], "Menu = Custom Cmds")
  FFdufS(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VV12e3 ,
   "cancel" : self.VVvdKV  ,
   "menu"  : self.VVNmIg ,
   "last"  : self.VVdCPW  ,
   "next"  : self.VVdCPW  ,
   "1"   : self.VVdCPW  ,
   "2"   : self.VVdCPW  ,
   "3"   : self.VVdCPW  ,
   "4"   : self.VVdCPW  ,
   "5"   : self.VVdCPW  ,
   "6"   : self.VVdCPW  ,
   "7"   : self.VVdCPW  ,
   "8"   : self.VVdCPW  ,
   "9"   : self.VVdCPW  ,
   "0"   : self.VVdCPW
  })
  self.onLayoutFinish.append(self.VV47vn)
  self.onClose.append(self.VVJFg9)
 def VV47vn(self):
  self["myLabel"].VVYtUm(isResizable=False, outputFileToSave="terminal")
  FFq6y3(self["keyRed"]  , "#00ff8000")
  FFg8wK(self["keyRed"]  , self.skinParam["titleColor"])
  FFg8wK(self["keyGreen"]  , self.skinParam["titleColor"])
  FFg8wK(self["keyYellow"] , self.skinParam["titleColor"])
  FFg8wK(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVbQb0(FFIgoM("date"), 5)
  result = FFIgoM("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVuNXq()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVnEh8 + "LinuxCommands.lst"
   newTemplate = VVnEh8 + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFyto6("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFyto6("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVJFg9(self):
  if self.container.VVqGsj():
   self.container.killAll()
   self.VVbQb0("Process killed\n", 4)
   self.VVuNXq()
 def VVvdKV(self):
  if self.container.VVqGsj():
   self.VVJFg9()
  else:
   FFZw7B(self, self.close, "Exit ?", VV6xap=False)
 def VVuNXq(self):
  self.VVbQb0(self.prompt, 1)
  self["keyRed"].hide()
 def VVbQb0(self, txt, mode):
  if   mode == 1 : color = VVy0iZ
  elif mode == 2 : color = VVE6YJ
  elif mode == 3 : color = VVCLGj
  elif mode == 4 : color = VVFBP5
  elif mode == 5 : color = VVyLoh
  elif mode == 6 : color = VV4U5y
  else   : color = VVCLGj
  try:
   self["myLabel"].appendText(FFrGgO(txt, color))
  except:
   pass
 def VVwRnE(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVbQb0(cmd, 2)
   self.VVbQb0("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVbQb0(ch, 0)
   self.VVbQb0("\nor\n", 4)
   self.VVbQb0("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVuNXq()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFrGgO(parts[0].strip(), VVE6YJ)
    right = FFrGgO("#" + parts[1].strip(), VV4U5y)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVbQb0(txt, 2)
   lastLine = self.VVSGep()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVOFdY(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVWY60, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFfYN0(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVbQb0(data, 3)
 def VVWY60(self, data, retval):
  if not retval == 0:
   self.VVbQb0("Exit Code : %d\n" % retval, 4)
  self.VVuNXq()
 def VV12e3(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVSGep() == "":
   self.VVOFdY("cd /tmp")
   self.VVOFdY("ls")
  VVjhh4 = []
  if fileExists(self.commandHistoryFile):
   lines  = FFup4P(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVjhh4.append((str(c), line, str(lNum)))
   self.VVAt7a(VVjhh4, title, self.commandHistoryFile, isHistory=True)
  else:
   FF6vdZ(self, self.commandHistoryFile, title=title)
 def VVSGep(self):
  lastLine = FFIgoM("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVOFdY(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVNmIg(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFup4P(self.customCommandsFile)
   lastLineIsSep = False
   VVjhh4 = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVjhh4.append((str(c), line, str(lNum)))
   self.VVAt7a(VVjhh4, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FF6vdZ(self, self.customCommandsFile, title=title)
 def VVAt7a(self, VVjhh4, title, filePath=None, isHistory=False):
  if VVjhh4:
   VViLdG = "#05333333"
   if isHistory: VV1Y9q = VVMnLe = VVop6p = "#11000020"
   else  : VV1Y9q = VVMnLe = VVop6p = "#06002020"
   VVHFFO   = ("Send"   , BF(self.VVfj8L, isHistory) , [])
   VV7wPX  = ("Modify & Send" , self.VVn5JS     , [])
   if isHistory:
    VVbdhP = ("Clear History" , self.VVspF7     , [])
    VVUB3Q = None
   elif filePath:
    VVbdhP = None
    VVUB3Q = ("Edit File"  , BF(self.VVmxw3, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVavJp     = (CENTER  , LEFT   , CENTER )
   VVToDv = FFA1pv(self, None, title=title, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VVHFFO=VVHFFO, VV7wPX=VV7wPX, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q, lastFindConfigObj=CFG.lastFindTerminal, VVFvoI=True, searchCol=1
     , VV1Y9q   = VV1Y9q
     , VVMnLe   = VVMnLe
     , VVop6p   = VVop6p
     , VVZZ2X  = "#05ffff00"
     , VViLdG  = VViLdG
    )
   if not isHistory:
    VVToDv.VVeb2k(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FFTXJH(self, filePath, title=title)
 def VVfj8L(self, isHistory, VVToDv, title, txt, colList):
  if not isHistory:
   FFu7KK(CFG.lastTerminalCustCmdLineNum, VVToDv.VVYt3A())
  cmd = colList[1].strip()
  VVToDv.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVbQb0("\n%s\n" % cmd, 6)
   self.VVbQb0(self.prompt, 1)
  else:
   self.VVwRnE(cmd)
 def VVn5JS(self, VVToDv, title, txt, colList):
  cmd = colList[1]
  self.VV7zUR(VVToDv, cmd)
 def VVspF7(self, VVToDv, title, txt, colList):
  FFZw7B(self, BF(self.VVd22T, VVToDv), "Reset History File ?", title="Command History")
 def VVd22T(self, VVToDv):
  os.system(FFyto6("echo '' > %s" % self.commandHistoryFile))
  VVToDv.cancel()
 def VVmxw3(self, filePath, VVToDv, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCbzSm(self, filePath, VVGpYx=BF(self.VV7eDq, VVToDv), curRowNum=rowNum)
  else     : FF6vdZ(self, filePath)
 def VV7eDq(self, VVToDv, fileChanged):
  if fileChanged:
   VVToDv.cancel()
   FFS6vB(self.VVNmIg)
 def VVdCPW(self):
  self.VV7zUR(None, self.lastCommand)
 def VV7zUR(self, VVToDv, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFoW9P(self, BF(self.VVPFbQ, VVToDv), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVPFbQ(self, VVToDv, cmd):
  if cmd and len(cmd) > 0:
   self.VVwRnE(cmd)
   if VVToDv:
    VVToDv.cancel()
class CCj9qb(Screen):
 def __init__(self, session, title="", message="", VVbIg5=VVBuVN, width=1400, height=800, VVLMX6=False, VVop6p=None, VVy2kz=30, outputFileToSave=""):
  self.skin, self.skinParam = FFNQkv(VVpCD5, width, height, 50, 30, 20, "#22002020", "#22001122", VVy2kz)
  self.session   = session
  FFVOCw(self, title, addScrollLabel=True)
  self.VVbIg5   = VVbIg5
  self.VVLMX6   = VVLMX6
  self.VVop6p   = VVop6p
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  self["myLabel"].VVYtUm(VVLMX6=self.VVLMX6, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVbIg5)
  if self.VVop6p:
   FFg8wK(self["myBody"], self.VVop6p)
   FFg8wK(self["myLabel"], self.VVop6p)
   FF9Sok(self["myLabel"], self.VVop6p)
  self["myLabel"].VVy8Bm()
class CChcJ4(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFNQkv(VVVTym, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFVOCw(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FF5qCx(self["errPic"], "err")
class CCqDaf(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFNQkv(VVNXcd, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFVOCw(self, " ", addCloser=True)
class CCt6lo():
 def __init__(self, session, txt, timeout=1500):
  self.win = session.instantiateDialog(CCqDaf, txt, 24)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  FFqDBE(self.win["myWinTitle"], "#440000", 2)
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVtc9I)
  except:
   self.timer.callback.append(self.VVtc9I)
  self.timer.start(timeout, True)
 def VVtc9I(self):
  self.session.deleteDialog(self.win)
class CCjOMG():
 VV3VOK    = 0
 VVtqyW  = 1
 VV2tvy   = ""
 VVqHpL    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVToDv   = None
  self.timer     = eTimer()
  self.VVLxAW   = 0
  self.VV01ks  = 1
  self.VV7nxG  = 2
  self.VVdzmI   = 3
  self.VVF3GL   = 4
  VVjhh4 = self.VV2gLc()
  if VVjhh4:
   self.VVToDv = self.VVex8E(VVjhh4)
  if not VVjhh4 and mode == self.VV3VOK:
   self.VVF7Fx("Download list is empty !")
   self.cancel()
  if mode == self.VVtqyW:
   FFlaBE(self.VVToDv or self.SELF, BF(self.VVCoGb, startDnld, decodedUrl), title="Checking Server ...")
  self.VVIaU6(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVIaU6)
  except:
   self.timer.callback.append(self.VVIaU6)
  self.timer.start(1000, False)
 def VVex8E(self, VVjhh4):
  VVjhh4.sort(key=lambda x: int(x[0]))
  VVzffX = self.VVWGVm
  VVHFFO  = ("Play"  , self.VVhSTH , [])
  VVXuip = (""   , self.VVHuMh  , [])
  VVcjza = ("Stop"  , self.VVoSrJ  , [])
  VV7wPX = ("Resume"  , self.VVtW67 , [])
  VVbdhP = ("Options" , self.VVm5IZ  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVavJp  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFA1pv(self.SELF, None, title=self.Title, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VVHFFO=VVHFFO, VVXuip=VVXuip, VVzffX=VVzffX, VVcjza=VVcjza, VV7wPX=VV7wPX, VVbdhP=VVbdhP, lastFindConfigObj=CFG.lastFindIptv, VV1Y9q="#11220022", VVMnLe="#11110011", VVop6p="#11110011", VVZZ2X="#00ffff00", VViLdG="#00223025", VVmDPu="#0a333333", VV15Y9="#0a400040", VVFvoI=True, searchCol=1)
 def VV2gLc(self):
  lines = CCjOMG.VVzNNt()
  VVjhh4 = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVcD69(decodedUrl)
      if fName:
       if   FFwFJ3(decodedUrl) : sType = "Movie"
       elif FFfXsY(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVSP1n(decodedUrl, fName)
       if size > -1: sizeTxt = CCqXgM.VV4m3L(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVjhh4.append((str(len(VVjhh4) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVjhh4
 def VVifBj(self):
  VVjhh4 = self.VV2gLc()
  if VVjhh4:
   if self.VVToDv : self.VVToDv.VV3ih0(VVjhh4, VVXWqvMsg=False)
   else     : self.VVToDv = self.VVex8E(VVjhh4)
  else:
   self.cancel()
 def VVIaU6(self, force=False):
  if self.VVToDv:
   thrListUrls = self.VVQowF()
   VVjhh4 = []
   changed = False
   for ndx, row in enumerate(self.VVToDv.VVF8iU()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVLxAW
    if m3u8Log:
     percent = CCjOMG.VVm2Ja(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVdzmI , "%.2f %%" % percent
      else   : flag, progr = self.VVF3GL , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FF2Omp(mPath)
     if curSize > -1:
      fSize = CCqXgM.VV4m3L(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCqXgM.VV4m3L(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FF2Omp(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVdzmI , "%.2f %%" % percent
       else   : flag, progr = self.VVF3GL , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCqXgM.VV4m3L(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VV7nxG
     if m3u8Log :
      if not speed and not force : flag = self.VV01ks
      elif curSize == -1   : self.VVFgzm(False)
    elif flag == self.VVLxAW  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVLxAW  : color2 = "#f#00555555#"
    elif flag == self.VV01ks : color2 = "#f#0000FFFF#"
    elif flag == self.VV7nxG : color2 = "#f#0000FFFF#"
    elif flag == self.VVdzmI  : color2 = "#f#00FF8000#"
    elif flag == self.VVF3GL  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVvfpn(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVjhh4.append(row)
   if changed or force:
    self.VVToDv.VV3ih0(VVjhh4, VVXWqvMsg=False)
 def VVvfpn(self, flag):
  tDict = self.VVK23W()
  return tDict.get(flag, "?")
 def VVwk2k(self, state):
  for flag, txt in self.VVK23W().items():
   if txt == state:
    return flag
  return -1
 def VVK23W(self):
  return { self.VVLxAW: "Not started", self.VV01ks: "Connecting", self.VV7nxG: "Downloading", self.VVdzmI: "Stopped", self.VVF3GL: "Completed" }
 def VVEaNG(self, title):
  colList = self.VVToDv.VVKPIF()
  path = colList[6]
  url  = colList[8]
  if self.VVDRRd() : self.VVF7Fx("Cannot delete !\n\nFile is downloading.")
  else      : FFZw7B(self.SELF, BF(self.VVguQS, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVguQS(self, path, url):
  m3u8Log = self.VVToDv.VVKPIF()[12]
  if m3u8Log : os.system(FFyto6("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFyto6("rm -r '%s'" % path))
  self.VVeHLz(False)
  self.VVifBj()
 def VVeHLz(self, VVdnur=True):
  if self.VVDRRd():
   FFHbVj(self.VVToDv, self.VVvfpn(self.VV7nxG), 500)
  else:
   colList  = self.VVToDv.VVKPIF()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VVwk2k(state) in (self.VVLxAW, self.VVF3GL, self.VVdzmI):
    lines = CCjOMG.VVzNNt()
    newLines = []
    found = False
    for line in lines:
     if CCjOMG.VVQv8R(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VV8ulw(newLines)
     self.VVifBj()
     FFHbVj(self.VVToDv, "Removed.", 1000)
    else:
     FFHbVj(self.VVToDv, "Not found.", 1000)
   elif VVdnur:
    self.VVF7Fx("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVqG5O(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFZw7B(self.SELF, BF(self.VVjoAA, flag), ques, title=title)
 def VVjoAA(self, flag):
  list = []
  for ndx, row in enumerate(self.VVToDv.VVF8iU()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVwk2k(state)
   if   flag == flagVal == self.VVF3GL: list.append(decodedUrl)
   elif flag == flagVal == self.VVLxAW : list.append(decodedUrl)
  lines = CCjOMG.VVzNNt()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VV8ulw(newLines)
   self.VVifBj()
   FFHbVj(self.VVToDv, "%d removed." % totRem, 1000)
  else:
   FFHbVj(self.VVToDv, "Not found.", 1000)
 def VVpVyH(self):
  colList  = self.VVToDv.VVKPIF()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFHbVj(self.VVToDv, "Poster exists", 1500)
  else    : FFlaBE(self.VVToDv, BF(self.VV2TGP, decodedUrl, path, png), title="Checking Server ...")
 def VV2TGP(self, decodedUrl, path, png):
  err = self.VVkjt4(decodedUrl, path, png)
  if err:
   FFfYN0(self.SELF, err, title="Poster Download")
 def VVkjt4(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCHEQq.VVjHQa(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCCwQV.VVY4JM(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCCwQV.VVCWun(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCCwQV.VVfM7o(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFSAwr(pUrl, "ajpanel_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   os.system(FFyto6("mv -f '%s' '%s'" % (tPath, png)))
   CCkc9M.VVthJo(self.SELF, VVksLF=png, showGrnMsg="Downloaded")
   return ""
 def VVHuMh(self, VVToDv, title, txt, colList):
  def VV4wPN(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVzg89(key, val) : return "\n%s:\n%s\n" % (FFrGgO(key, VVtSeQ), val.strip())
  heads  = self.VVToDv.VVo26g()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VV4wPN(heads[i]  , CCqXgM.VV4m3L(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VV4wPN("Downloaded" , CCqXgM.VV4m3L(int(curSize), mode=0))
   else:
    txt += VV4wPN(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVzg89(heads[i], colList[i])
  FFCxQN(self.SELF, txt, title=title)
 def VVhSTH(self, VVToDv, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCqXgM.VVnUrp(self.SELF, path)
  else    : FFHbVj(self.VVToDv, "File not found", 1000)
 def VVWGVm(self, VVToDv):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVToDv:
   self.VVToDv.cancel()
  del self
 def VVm5IZ(self, VVToDv, title, txt, colList):
  c1, c2, c3 = VV61Yf, VVFBP5, VVtSeQ
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVJ4QS = []
  VVJ4QS.append((c1 + "Remove current row"       , "VVeHLz" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVJ4QS.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append((c2 + "Delete the file (and remove from list)"  , "VVEaNG"))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append((resumeTxt + " Auto Resume"       , "VVOcMt" ))
  VVJ4QS.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVJ4QS.append(VV4c5n)
  t = "Download Movie Poster "
  if FFwFJ3(decodedUrl): VVJ4QS.append((c3 + "%s(from server)" % t , "VVpVyH"  ))
  else      : VVJ4QS.append(("%s... Movies only" % t ,      ))
  if fileExists(path) : VVJ4QS.append((c3 + "Open in File Manager" , "inFileMan,%s" % path ))
  else    : VVJ4QS.append(("Open in File Manager"  ,      ))
  FFZP3S(self.SELF, BF(self.VVByOr, VVToDv), VVJ4QS=VVJ4QS, title=self.Title, VV7GES=True, width=800, VVbHGu=True, VV1Y9q="#1a001122", VVMnLe="#1a001122")
 def VVByOr(self, VVToDv, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVeHLz"  : self.VVeHLz()
   elif ref == "remFinished"   : self.VVqG5O(self.VVF3GL, txt)
   elif ref == "remPending"   : self.VVqG5O(self.VVLxAW, txt)
   elif ref == "VVEaNG" : self.VVEaNG(txt)
   elif ref == "VVpVyH"  : self.VVpVyH()
   elif ref == "VVOcMt"  : FFu7KK(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FFu7KK(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CCqXgM, mode=CCqXgM.VVDEbH, jumpToFile=path)
    else    : FFHbVj(VVToDv, "Path not found !", 1500)
 def VVCoGb(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCHEQq.VVjHQa(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVF7Fx("Could not get download link !\n\nTry again later.")
     return
  for line in CCjOMG.VVzNNt():
   if CCjOMG.VVQv8R(decodedUrl, line):
    if self.VVToDv:
     self.VVXTE6(decodedUrl)
     FFS6vB(BF(FFHbVj, self.VVToDv, "Already listed !", 2000))
    break
  else:
   params = self.VVQTc1(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVF7Fx(params[0])
   elif len(params) == 2:
    FFZw7B(self.SELF, BF(self.VVuDSn, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCqXgM.VV4m3L(fSize)
    FFZw7B(self.SELF, BF(self.VVmd26, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVmd26(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCjOMG.VVZft1(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVifBj()
  if self.VVToDv:
   self.VVToDv.VVZAOC()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCjOMG.VVqHpL, path, decodedUrl)
   self.VVASMf(threadName, url, decodedUrl, path, resp)
 def VVXTE6(self, decodedUrl):
  if self.VVToDv:
   for ndx, row in enumerate(self.VVToDv.VVF8iU()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVToDv:
     self.VVToDv.VVeb2k(ndx)
     break
 def VVQTc1(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVcD69(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVSP1n(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCHEQq.VVjHQa(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCHEQq.VVvxfa()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCjOMG.VVuGwd(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCjOMG.VVh1HT(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVuDSn(self, resp, decodedUrl):
  if not os.system(FFyto6("which ffmpeg")) == 0:
   FFZw7B(self.SELF, BF(CCCwQV.VVWKy2, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVcD69(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVKa9V(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFZw7B(self.SELF, BF(self.VVHMqj, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVHMqj(rTxt, rUrl)
  else:
   self.VVF7Fx("Cannot process m3u8 file !")
 def VVKa9V(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVJ4QS = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCCwQV.VVoleU(rUrl, fPath)
   VVJ4QS.append((resol, fullUrl))
  if VVJ4QS:
   FFZP3S(self.SELF, self.VVyKwT, VVJ4QS=VVJ4QS, title="Resolution", VV7GES=True, VVbHGu=True)
  else:
   self.VVF7Fx("Cannot get Resolutions list from server !")
 def VVyKwT(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFZw7B(self.SELF, BF(FFS6vB, BF(self.VVgxVi, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFS6vB(BF(self.VVgxVi, resolUrl))
 def VVgxVi(self, resolUrl):
  txt, err = CCHEQq.VVcpBl(resolUrl)
  if err : self.VVF7Fx(err)
  else : self.VVHMqj(txt, resolUrl)
 def VV9cgW(self, logF, decodedUrl):
  found = False
  lines = CCjOMG.VVzNNt()
  with open(CCjOMG.VVZft1(), "w") as f:
   for line in lines:
    if CCjOMG.VVQv8R(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCjOMG.VVZft1(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVifBj()
  if self.VVToDv:
   self.VVToDv.VVZAOC()
 def VVHMqj(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCCwQV.VVoleU(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVF7Fx("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VV9cgW(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFyto6("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCjOMG.VVqHpL, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVm2Ja(dnldLog):
  if fileExists(dnldLog):
   dur = CCjOMG.VVCo06(dnldLog)
   if dur > -1:
    tim = CCjOMG.VV0A6a(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVCo06(dnldLog):
  lines = FFz7l2("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VV0A6a(dnldLog):
  lines = FFz7l2("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVSP1n(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFfXsY(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFyto6("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVASMf(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVToDv.VVKPIF()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VVFlNo, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVFlNo(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VV2tvy == path:
       break
     else:
      break
  except:
   return
  if CCjOMG.VV2tvy:
   CCjOMG.VV2tvy = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FF2Omp(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVQTc1(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVFlNo(url, decodedUrl, path, resp, totFileSize, True)
 def VVoSrJ(self, VVToDv, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVNHcK() : FFHbVj(self.VVToDv, self.VVvfpn(self.VVF3GL), 500)
  elif not self.VVDRRd() : FFHbVj(self.VVToDv, self.VVvfpn(self.VVdzmI), 500)
  elif m3u8Log      : FFZw7B(self.SELF, self.VVFgzm, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVQowF():
    CCjOMG.VV2tvy = colList[6]
    FFHbVj(self.VVToDv, "Stopping ...", 1000)
   else:
    FFHbVj(self.VVToDv, "Stopped", 500)
 def VVFgzm(self, withMsg=True):
  if withMsg:
   FFHbVj(self.VVToDv, "Stopping ...", 1000)
  os.system(FFyto6("killall -INT ffmpeg"))
 def VVtW67(self, *args):
  if   self.VVNHcK() : FFHbVj(self.VVToDv, self.VVvfpn(self.VVF3GL) , 500)
  elif self.VVDRRd() : FFHbVj(self.VVToDv, self.VVvfpn(self.VV7nxG), 500)
  else:
   resume = False
   m3u8Log = self.VVToDv.VVKPIF()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFZw7B(self.SELF, BF(self.VVJyiL, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVkKjw():
    resume = True
   if resume: FFlaBE(self.VVToDv, BF(self.VV4nWS), title="Checking Server ...")
   else  : FFHbVj(self.VVToDv, "Cannot resume !", 500)
 def VVJyiL(self, m3u8Log):
  os.system(FFyto6("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFlaBE(self.VVToDv, BF(self.VV4nWS), title="Checking Server ...")
 def VV4nWS(self):
  colList  = self.VVToDv.VVKPIF()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCHEQq.VVjHQa(decodedUrl)
   if url:
    decodedUrl = self.VVjdXh(decodedUrl, url)
   else:
    self.VVF7Fx("Could not get download link !\n\nTry again later.")
    return
  curSize = FF2Omp(path)
  params = self.VVQTc1(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVF7Fx(params[0])
   return
  elif len(params) == 2:
   self.VVuDSn(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVjdXh(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCjOMG.VVqHpL, path, decodedUrl)
  if resumable: self.VVASMf(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVF7Fx("Cannot resume from server !")
 def VVcD69(self, decodedUrl):
  fileExt = CCCwQV.VV1Jy6(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FFMUSj(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVF7Fx(self, txt):
  FFfYN0(self.SELF, txt, title=self.Title)
 def VVQowF(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCjOMG.VVqHpL, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVDRRd(self):
  decodedUrl = self.VVToDv.VVKPIF()[9]
  return decodedUrl in self.VVQowF()
 def VVNHcK(self):
  colList = self.VVToDv.VVKPIF()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FF2Omp(path)) == size
 def VVkKjw(self):
  colList = self.VVToDv.VVKPIF()
  path = colList[6]
  size = int(colList[7])
  curSize = FF2Omp(path)
  if curSize > -1:
   size -= curSize
  err = CCjOMG.VVh1HT(size)
  if err:
   FFfYN0(self.SELF, err, title=self.Title)
   return False
  return True
 def VV8ulw(self, list):
  with open(CCjOMG.VVZft1(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVjdXh(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCjOMG.VVzNNt()
  url = decodedUrl
  with open(CCjOMG.VVZft1(), "w") as f:
   for line in lines:
    if CCjOMG.VVQv8R(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVifBj()
  return url
 @staticmethod
 def VVzNNt():
  list = []
  if fileExists(CCjOMG.VVZft1()):
   for line in FFup4P(CCjOMG.VVZft1()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVQv8R(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVh1HT(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCqXgM.VVRyP5(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCqXgM.VV4m3L(size), CCqXgM.VV4m3L(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVuQfh(SELF):
  tot = CCjOMG.VVOcRx()
  if tot:
   FFfYN0(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVOcRx():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCjOMG.VVqHpL):
    c += 1
  return c
 @staticmethod
 def VVX6pZ():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCjOMG.VVqHpL, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVQeoC():
  return len(CCjOMG.VVzNNt()) == 0
 @staticmethod
 def VVtp7l():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVmHpk():
  mPoints = CCjOMG.VVtp7l()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFyto6("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVZft1():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVUHLU(SELF):
  CCjOMG.VV5ah1(SELF, CCjOMG.VV3VOK)
 @staticmethod
 def VVw2kG(SELF):
  CCjOMG.VV5ah1(SELF, CCjOMG.VVtqyW, startDnld=True)
 @staticmethod
 def VVcUev(SELF, url):
  CCjOMG.VV5ah1(SELF, CCjOMG.VVtqyW, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVswKc(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(SELF)
  added, skipped = CCjOMG.VVpSBh([decodedUrl])
  FFHbVj(SELF, "Added", 1000)
 @staticmethod
 def VVpSBh(list):
  added = skipped = 0
  for line in CCjOMG.VVzNNt():
   for ndx, url in enumerate(list):
    if url and CCjOMG.VVQv8R(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCjOMG.VVZft1(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VV5ah1(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCuKpK.VVLJ72(SELF):
   return
  if mode == CCjOMG.VV3VOK and CCjOMG.VVQeoC():
   FFfYN0(SELF, "Download list is empty !", title=title)
  else:
   inst = CCjOMG(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVuGwd(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCKx3s(Screen, CCAVwF):
 VVwJWf = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, isFromExternal=False, enableDownloadMenu=True, enableOpenInFMan=True):
  self.skin, self.skinParam = FFNQkv(VV5zNN, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCAVwF.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.enableOpenInFMan  = enableOpenInFMan
  self.iptvTableParams  = iptvTableParams
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FFVOCw(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVJbsS())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVfFPM       ,
   "info"  : self.VVRqIL      ,
   "epg"  : self.VVRqIL      ,
   "menu"  : self.VVUSwi     ,
   "cancel" : self.cancel       ,
   "red"  : self.VVAclJ   ,
   "green"  : self.VVVfYV  ,
   "blue"  : self.VVF6ZT      ,
   "yellow" : self.VVoPa7 ,
   "left"  : BF(self.VVXTUM, -1)    ,
   "right"  : BF(self.VVXTUM,  1)    ,
   "play"  : self.VV4Vib      ,
   "pause"  : self.VV4Vib      ,
   "playPause" : self.VV4Vib      ,
   "stop"  : self.VV4Vib      ,
   "rewind" : self.VV9t1R      ,
   "forward" : self.VV3DIX      ,
   "rewindDm" : self.VV9t1R      ,
   "forwardDm" : self.VV3DIX      ,
   "last"  : self.VVm7jb      ,
   "next"  : self.VVeF3e      ,
   "pageUp" : BF(self.VVC3ZT, True)  ,
   "pageDown" : BF(self.VVC3ZT, False)  ,
   "chanUp" : BF(self.VVC3ZT, True)  ,
   "chanDown" : BF(self.VVC3ZT, False)  ,
   "up"  : BF(self.VVC3ZT, True)  ,
   "down"  : BF(self.VVC3ZT, False)  ,
   "audio"  : BF(self.VVM2HR, True)  ,
   "subtitle" : BF(self.VVM2HR, False)  ,
   "text"  : self.VVrIeM  ,
   "0"   : BF(self.VVSI90 , 10)   ,
   "1"   : BF(self.VVSI90 , 1)   ,
   "2"   : BF(self.VVSI90 , 2)   ,
   "3"   : BF(self.VVSI90 , 3)   ,
   "4"   : BF(self.VVSI90 , 4)   ,
   "5"   : BF(self.VVSI90 , 5)   ,
   "6"   : BF(self.VVSI90 , 6)   ,
   "7"   : BF(self.VVSI90 , 7)   ,
   "8"   : BF(self.VVSI90 , 8)   ,
   "9"   : BF(self.VVSI90 , 9)
  }, -1)
  self.onShown.append(self.VV47vn)
  self.onClose.append(self.onExit)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FFABOX(self)
  if not CCKx3s.VVwJWf:
   CCKx3s.VVwJWf = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FF5qCx(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FF5qCx(self["myPlayRpt"], "rpt")
  self.VVQXM1()
  self.instance.move(ePoint(40, 40))
  self.VVEEe6(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV3gcr)
  except:
   self.timer.callback.append(self.VV3gcr)
  self.timer.start(250, False)
  self.VV3gcr("Checking ...")
  self.VV5olE()
 def VVVfYV(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self)
  self.lastSubtitle = CCaiob.VVjNU3()
  if "chCode" in iptvRef:
   if CCuKpK.VVLJ72(self):
    self.VV5olE(True)
  else:
   self.VV3gcr("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVQXM1(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVREtd()
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VVPUgM + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FFg8wK(self["myTitle"], tColor)
  FFg8wK(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFg8wK(self["myPlay%s" % item], tColor)
  picFile = CCy52I.VVtRHL(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CCy52I.VVlM2Y(self)
  cl = CC376o.VVnOBs(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VV3gcr(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCjOMG.VVOcRx()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVREtd()
  if evName:
   evName = "    %s    " % FFrGgO(evName, VVyLoh)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VV5gPb():
   FFq6y3(self["myPlayBlu"], "#00FFFFFF")
   FFg8wK(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFq6y3(self["myPlayBlu"], "#00FFFF88")
   FFg8wK(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FFg8wK(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FFle5S(percVal, 0, 100)
   width = int(FFWAiI(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FFg8wK(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFq6y3(self["myPlayMsg"], "#0000ffff")
   else  : FFq6y3(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFq6y3(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFq6y3(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVpWIM()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VVGmAi(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CCaiob.VVkDWo(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVm7jb()
  state = self.VVMaCc()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFq6y3(self["myPlayMsg"], "#0000ff00")
  else     : FFq6y3(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVREtd(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FF6soe(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCKx3s.VVlGvH(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCy52I.VVUMHy(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CCoeZX()
   tpTxt, satTxt = tp.VVgEGr(refCode)
   self.satInfo_TP = tpTxt + "  " + FFrGgO(satTxt, VVxpap)
  evName = evNameNext = ""
  evLst = CCy52I.VVw68F(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFmiK9(info, iServiceInformation.sVideoWidth) or -1
   h = FFmiK9(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFmiK9(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CCy52I.VVpz3X(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VVlGvH(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFxB2b(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFxB2b(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFxB2b(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVUSwi(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVREtd()
  FFwFJ3Series = FFMUSj(decodedUrl)
  VVJ4QS = []
  if self.isFromExternal:
   VVJ4QS.append((VVxpap + "IPTV Menu"   , "iptv" ))
   VVJ4QS.append(VV4c5n)
  if isIptv and not "&end=" in decodedUrl and not FFwFJ3Series:
   uType, uHost, uUser, uPass, uId, uChName = CCCwQV.VVY4JM(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVJ4QS.append((VVxpap + "Catchup Programs", "catchup" ))
    VVJ4QS.append(VV4c5n)
  if refCode:
   c = VVPUgM
   VVJ4QS.append((c + "Stop Current Service"  , "stop"  ))
   VVJ4QS.append((c + "Restart Current Service" , "restart"  ))
   VVJ4QS.append(VV4c5n)
  if FFwFJ3Series:
   VVJ4QS.append((VVxpap + "File Size (on server)", "fileSize" ))
   VVJ4QS.append(VV4c5n)
  if self.enableDownloadMenu:
   c = VVxpap
   addSep = False
   if isIptv and FFwFJ3Series:
    VVJ4QS.append((c + "Start Download"   , "dload_cur" ))
    VVJ4QS.append((c + "Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCjOMG.VVQeoC():
    VVJ4QS.append((VVxpap + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVJ4QS.append(VV4c5n)
  fPath, fDir, fName = CCqXgM.VVsA5T(self)
  if fPath:
   c = VV6svy
   if self.enableOpenInFMan and not CCqXgM.VV0zZr:
    VVJ4QS.append((c + "Open path in File Manager", "VVj7EX"))
   VVJ4QS.append((c + "Add to Bouquet"             , "VVf762" ))
   VVJ4QS.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVpvcV"  ))
   VVJ4QS.append(VV4c5n)
  if isDvb:
   VVJ4QS.append((VVxpap + "Signal Monitor", "sigMon"   ))
  if posTxt and durTxt:
   VVJ4QS.append((VVtSeQ + "Start Subtitle", "VVABhY"))
   VVJ4QS.append(VV4c5n)
  if CFG.playerPos.getValue() : VVJ4QS.append(("Move Bar to Bottom"  , "botm"    ))
  else      : VVJ4QS.append(("Move Bar to Top"  , "top"     ))
  VVJ4QS.append(("Help"             , "help"    ))
  FFZP3S(self, self.VVnKtF, VVJ4QS=VVJ4QS, width=600, title="Options")
 def VVnKtF(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VVoPa7()
   elif item == "stop"     : self.VVG0ON(0)
   elif item == "restart"    : self.VVG0ON(1)
   elif item == "fileSize"    : FFlaBE(self, BF(CCy52I.VV87mj, self), title="Checking Server")
   elif item == "dload_cur"   : CCjOMG.VVw2kG(self)
   elif item == "addToDload"   : CCjOMG.VVswKc(self)
   elif item == "dload_stat"   : CCjOMG.VVUHLU(self)
   elif item == "VVj7EX" : self.close("close_openInFileMan")
   elif item == "VVf762" : self.VVf762()
   elif item == "VVABhY"  : self.VVb5cx()
   elif item == "VVpvcV"  : self.VVpvcV()
   elif item == "botm"     : self.VVEEe6(0)
   elif item == "top"     : self.VVEEe6(1)
   elif item == "sigMon"    : self.VVAclJ()
   elif item == "help"     : FFrc1O(self, VVnEh8 + "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCKx3s.VVwJWf = None
 def VVG0ON(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVQXM1()
   elif typ == 1:
    self.VV3gcr("Restarting Service ...")
    FFS6vB(BF(self.VVo0Oi, serv))
 def VVo0Oi(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self)
  if "&end=" in decodedUrl: BF(self.VV5olE, True)
  else     : self.session.nav.playService(serv)
 def VVf762(self):
  fPath, fDir, fName = CCqXgM.VVsA5T(self)
  if fPath: picker = CC54zE(self, self, "Add Current Movie to a Bouquet", BF(self.VVJv42, [fPath]))
  else : FFHbVj(self, "Path not found !", 1500)
 def VVJv42(self, pathLst):
  return CC54zE.VV1axl(pathLst)
 def VVpvcV(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCKx3s.VVlGvH(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VV3gcr(txt, highlight=ok)
 def VVEEe6(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FFu7KK(CFG.playerPos, pos)
 def VVAclJ(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCy52I.VVUMHy(serv)
   if isDvb: self.close("close_sig")
   else : self.VV3gcr("No Signal for Current Service")
 def VVb5cx(self):
  self.session.openWithCallback(self.VVXw2W, BF(CCaiob))
 def VVrIeM(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVREtd()
   if posTxt and durTxt: self.VVb5cx()
   else    : self.VV3gcr("No duration Info. !")
 def VVXw2W(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VVC3ZT(True)
  elif reason == "subtZapDn" : self.VVC3ZT(False)
  elif reason == "pause"  : self.VV4Vib()
  elif reason == "audio"  : self.VVM2HR(True)
  elif reason == "subtitle" : self.VVM2HR(False)
  elif reason == "rewind"     : self.VV9t1R()
  elif reason == "forward" : self.VV3DIX()
  elif reason == "rewindDm" : self.VV9t1R()
  elif reason == "forwardDm" : self.VV3DIX()
  else      : txt = reason
  if txt:
   FFHbVj(self, txt, 2000)
 def VVfFPM(self):
  if self.isManualSeek:
   self.VVGc7Y()
   self.VVGmAi(self.manualSeekPts)
  elif self.shown:
   if CCaiob.VVHYEx(self): self.VVb5cx()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVGc7Y()
  else    : self.close()
 def VVRqIL(self):
  FFzeU3(self, fncMode=CCy52I.VV2Sv8)
 def VV4Vib(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VV3gcr("Toggling Play/Pause ...")
 def VVGc7Y(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVXTUM(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCKx3s.VVlGvH(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VV8azp()
   else:
    self.manualSeekSec += direc * self.VV8azp()
    self.manualSeekSec = FFle5S(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFWAiI(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFxB2b(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVSI90(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVJbsS())
   FFu7KK(CFG.playerJumpMin, self.jumpMinutes)
  self.VV3gcr("Changed Seek Time to : %d%s" % (val, self.VVrI6p()))
 def VVJbsS(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVrI6p())
 def VVrI6p(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VViDKb(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VV8azp(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVpWIM(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVF6ZT(self):
  cList = self.VV5gPb()
  if cList:
   VVJ4QS = []
   for pts, what in cList:
    txt = FFxB2b(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVJ4QS.append((txt, pts))
   FFZP3S(self, self.VV2A85, VVJ4QS=VVJ4QS, title="Cut List")
  else:
   self.VV3gcr("No Cut-List for this channel !")
 def VV2A85(self, item=None):
  if item:
   self.VVGmAi(item)
 def VV5gPb(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VV3DIX(self) : self.VVhbWl(1)
 def VV9t1R(self) : self.VVhbWl(-1)
 def VVhbWl(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCKx3s.VVlGvH(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VV8azp() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VViDKb())
    self.VV3gcr(txt)
  except:
   self.VV3gcr("Cannot jump")
 def VVGmAi(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VV3gcr("Changing Time ...")
 def VVm7jb(self):
  self.VVG0ON(1)
  self.VV3gcr("Replaying ...")
  self.VVGc7Y()
 def VVeF3e(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCKx3s.VVlGvH(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VV3gcr("Jumping to end ...")
  except:
   pass
 def VVMaCc(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVC3ZT(self, isUp):
  if self.enableZapping:
   self.VV3gcr("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVGc7Y()
   if self.iptvTableParams:
    FFS6vB(BF(self.VVL8WG, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self)
    if "/timeshift/" in decodedUrl:
     self.VV3gcr("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVlgVJ()
  else:
   self.VV3gcr("Zap Disabled !")
 def VVlgVJ(self):
  self.lastPlayPos = 0
  self.VVQXM1()
  self.VV5olE()
 def VVL8WG(self, isUp):
  CCCwQV_inatance, VVToDv, mode = self.iptvTableParams
  if isUp : VVToDv.VV7w4B()
  else : VVToDv.VVFgYa()
  colList = VVToDv.VVKPIF()
  if mode == "localIptv":
   chName, chUrl = CCCwQV_inatance.VVoFIv(VVToDv, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCCwQV_inatance.VVwVBX(VVToDv, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCCwQV_inatance.VVLVOl(mode, VVToDv, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCCwQV_inatance.VV2Jkg(mode, VVToDv, colList)
  else:
   self.VV3gcr("Cannot Zap")
   return
  FFbrIp(self, chUrl, VVVlLd=False)
  self.VVlgVJ()
 def VV5olE(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCKx3s.VVlGvH(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self)
   if not self.VV6PGQ(refCode, chName, decodedUrl, iptvRef):
    return
   self.VV3gcr("Refreshing Portal")
   FFS6vB(self.VV2Fgn)
  except:
   pass
 def VV2Fgn(self):
  self.restoreLastPlayPos = self.VVXY5q()
 def VVoPa7(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self)
  if not decodedUrl or FFMUSj(decodedUrl):
   self.VV3gcr("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCCwQV.VVY4JM(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VV3gcr("Reading Program List ...")
   ok_fnc = BF(self.VVHrOH, refCode, chName, streamId, uHost, uUser, uPass)
   FFS6vB(BF(CCCwQV.VV72z6, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VV3gcr("Cannot process this channel")
 def VVHrOH(self, refCode, chName, streamId, uHost, uUser, uPass, VVToDv, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVToDv.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VV3gcr("Changing Program ...")
   FFS6vB(BF(self.VVmcib, chUrl))
  else:
   self.VV3gcr("Incorrect Timestamp !")
 def VVmcib(self, chUrl):
  FFbrIp(self, chUrl, VVVlLd=False)
  self.lastPlayPos = 0
  self.VVQXM1()
 def VVM2HR(self, isAudio):
  try:
   VVdeEx = InfoBar.instance
   if VVdeEx:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVdeEx)
    else  : self.session.open(SubtitleSelection, VVdeEx)
  except:
   pass
 @staticmethod
 def VVIXB3(session, mode=None):
  if   mode == "close_sig"   : FFieRK(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CCCwQV)
  elif mode == "close_openInFileMan" : session.open(CCqXgM, gotoMovie=True)
 @staticmethod
 def VVpa1E(session, isFromExternal=False, **kwargs):
  session.openWithCallback(BF(CCKx3s.VVIXB3, session), CCKx3s, isFromExternal=isFromExternal, **kwargs)
class CCvoBn(Screen):
 def __init__(self, session, title="", VVgyFZ="Continue?", VV6xap=True, VV5RdC=False):
  self.skin, self.skinParam = FFNQkv(VVXQ7N, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVgyFZ = VVgyFZ
  self.VV5RdC = VV5RdC
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VV6xap : VVJ4QS = [no , yes]
  else   : VVJ4QS = [yes, no ]
  FFVOCw(self, title, VVJ4QS=VVJ4QS, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVfFPM ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVgyFZ)
  if self.VV5RdC:
   self["myLabel"].instance.setHAlign(0)
  self.VVfTEx()
  FFAoMS(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFwAdu(self["myMenu"])
  FFlegS(self, self["myMenu"])
 def VVfFPM(self):
  item = FFzDv6(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVfTEx(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCpR55(Screen):
 def __init__(self, session, title="", VVJ4QS=None, width=1000, height=0, VVy2kz=30, barText="", minRows=1, OKBtnFnc=None, VVY1MF=None, VV5lv1=None, VVU5gS=None, VVaSnd=None, VV7GES=False, VVbHGu=False, VV1Y9q="#22003344", VVMnLe="#22002233"):
  if height == 0: height = 850
  self.skin, self.skinParam = FFNQkv(VVLAKc, width, height, 50, 40, 30, VV1Y9q, VVMnLe, VVy2kz, barHeight=40)
  self.session   = session
  self.VVJ4QS   = VVJ4QS
  self.barText   = barText
  self.minRows   = minRows
  self.OKBtnFnc   = OKBtnFnc
  self.VVY1MF   = VVY1MF
  self.VV5lv1  = VV5lv1
  self.VVU5gS  = VVU5gS
  self.VVaSnd   = VVaSnd
  self.VV7GES  = VV7GES
  self.VVbHGu  = VVbHGu
  FFVOCw(self, title, VVJ4QS=VVJ4QS)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVfFPM          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVVHTf         ,
   "green"  : self.VVZLBs         ,
   "yellow" : self.VVEoCk         ,
   "blue"  : self.VVL62p         ,
   "pageUp" : self.VVV0ZZ       ,
   "chanUp" : self.VVV0ZZ       ,
   "pageDown" : self.VVndQb        ,
   "chanDown" : self.VVndQb
  }, -1)
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FFAoMS(self["myMenu"])
  FFJdIh(self, minRows=self.minRows)
  self.VVNlDX(self["keyRed"]  , self.VVY1MF )
  self.VVNlDX(self["keyGreen"] , self.VV5lv1 )
  self.VVNlDX(self["keyYellow"] , self.VVU5gS )
  self.VVNlDX(self["keyBlue"]  , self.VVaSnd )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFeAg3(self)
 def VVNlDX(self, btnObj, btnFnc):
  if btnFnc:
   FFdufS(btnObj, btnFnc[0])
 def VVmw8Q(self, fnc=None):
  self.VV5lv1 = fnc
  if fnc : self.VVNlDX(self["keyGreen"], self.VV5lv1)
  else : self["keyGreen"].hide()
 def VVfFPM(self):
  item = FFzDv6(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VV7GES: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVVHTf(self)  : self.VVZR2t(self.VVY1MF)
 def VVZLBs(self) : self.VVZR2t(self.VV5lv1)
 def VVEoCk(self) : self.VVZR2t(self.VVU5gS)
 def VVL62p(self) : self.VVZR2t(self.VVaSnd)
 def VVZR2t(self, btnFnc):
  if btnFnc:
   item = FFzDv6(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVbHGu:
    self.cancel()
 def VVeAOS(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VVZEkP(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVJ4QS = self["myMenu"].list
  VVJ4QS.pop(ndx)
  if len(VVJ4QS) > 0: self["myMenu"].setList(VVJ4QS)
  else    : self.close()
 def VVMK10(self, VVJ4QS):
  if len(VVJ4QS) > 0:
   newList = []
   for item in VVJ4QS:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFJdIh(self, minRows=self.minRows)
  else:
   self.close("")
 def VVpwZ4(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FFJdIh(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVSogL(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVV0ZZ(self):
  self["myMenu"].moveToIndex(0)
 def VVndQb(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCeuNr(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VVITUl=None, VVavJp=None, VV7ux5=None, VVy2kz=26, VVFvoI=False, VVenoQ=0, VVHFFO=None, VVXuip=None, VVcjza=None, VV7wPX=None, VVbdhP=None, VVUB3Q=None, VV597P=None, VVcwgo=None, VVzffX=None, VVR6Ea=-1, VVR0cj=False, searchCol=0, lastFindConfigObj=None, VV1Y9q=None, VVMnLe=None, VVkfqz="#00dddddd", VVop6p="#11002233", VVZZ2X="#00ff8833", VViLdG="#11111111", VVmDPu="#0a555555", VVxjO7="#0affffff", VV15Y9="#11552200", VVYnzd="#0055ff55"):
  self.skin, self.skinParam = FFNQkv(VVp52N, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFVOCw(self, title)
  self.Title     = title
  self.header     = header
  self.VVITUl     = VVITUl
  self.totalCols    = len(VVITUl[0])
  self.VVenoQ   = VVenoQ
  self.lastSortModeIsReverese = False
  self.VVFvoI   = VVFvoI
  self.VVQjda   = 0.01
  self.VVrjfH   = 0.02
  self.VVySvy = 0.03
  self.VVhsFn  = 1
  self.VV7ux5 = VV7ux5
  self.colWidthPixels   = []
  self.VVHFFO   = VVHFFO
  self.OKButtonObj   = None
  self.VVXuip   = VVXuip
  self.VVcjza   = VVcjza
  self.VV7wPX   = VV7wPX
  self.VVbdhP  = VVbdhP
  self.VVUB3Q   = VVUB3Q
  self.VV597P    = VV597P
  self.VVcwgo   = VVcwgo
  self.tableRefreshCB   = None
  self.VVzffX  = VVzffX
  self.VVR6Ea    = VVR6Ea
  self.VVR0cj   = VVR0cj
  self.searchCol    = searchCol
  self.VVavJp    = VVavJp
  self.keyPressed    = -1
  self.VVy2kz    = FFzL3c(VVy2kz)
  self.VVkXuR    = FFbwug(self.VVy2kz, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VV1Y9q    = VV1Y9q
  self.VVMnLe      = VVMnLe
  self.VVkfqz    = FFyhto(VVkfqz)
  self.VVop6p    = FFyhto(VVop6p)
  self.VVZZ2X    = FFyhto(VVZZ2X)
  self.VViLdG    = FFyhto(VViLdG)
  self.VVmDPu   = FFyhto(VVmDPu)
  self.VVxjO7    = FFyhto(VVxjO7)
  self.VV15Y9    = FFyhto(VV15Y9)
  self.VVYnzd   = FFyhto(VVYnzd)
  self.VVmDY2  = False
  self.selectedItems   = 0
  self.VVZpXq   = FFyhto("#01fefe01")
  self.VVus3X   = FFyhto("#11400040")
  self.VVoucn  = self.VVZpXq
  self.VV2FuX  = self.VViLdG
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVR0cj:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV8HAl  ,
   "red"   : self.VVZmgr  ,
   "green"   : self.VVJX7M ,
   "yellow"  : self.VVfSET ,
   "blue"   : self.VVLJ5p  ,
   "menu"   : self.VVuuzo ,
   "info"   : self.VVyOAW  ,
   "cancel"  : self.VVH8j0  ,
   "up"   : self.VVFgYa    ,
   "down"   : self.VV7w4B  ,
   "left"   : self.VVPPup   ,
   "right"   : self.VV8kEj  ,
   "next"   : self.VVaPRg  ,
   "last"   : self.VVPN7k  ,
   "home"   : self.VV6jq7  ,
   "pageUp"  : self.VV6jq7  ,
   "chanUp"  : self.VV6jq7  ,
   "end"   : self.VVZAOC  ,
   "pageDown"  : self.VVZAOC  ,
   "chanDown"  : self.VVZAOC
  }, -1)
  FFCDOS(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FFABOX(self)
  try:
   self.VVrSfS()
  except Exception as e:
   FFfYN0(self, str(e), title=self.Title)
   self.close(None)
 def VVrSfS(self):
  FFeAg3(self)
  if self.VV1Y9q:
   FFg8wK(self["myTitle"], self.VV1Y9q)
  if self.VVMnLe:
   FFg8wK(self["myBody"] , self.VVMnLe)
   FFg8wK(self["myTableH"] , self.VVMnLe)
   FFg8wK(self["myTable"] , self.VVMnLe)
   FFg8wK(self["myBar"]  , self.VVMnLe)
  self.VVNlDX(self.VVcjza  , self["keyRed"])
  self.VVNlDX(self.VV7wPX  , self["keyGreen"])
  self.VVNlDX(self.VVbdhP , self["keyYellow"])
  self.VVNlDX(self.VVUB3Q  , self["keyBlue"])
  if self.VVHFFO:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVHFFO[0])
    FFg8wK(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVkXuR)
  self["myTableH"].l.setFont(0, gFont(VVdbIk, self.VVy2kz))
  self["myTable"].l.setItemHeight(self.VVkXuR)
  self["myTable"].l.setFont(0, gFont(VVdbIk, self.VVy2kz))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVkXuR)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVkXuR))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVkXuR)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVkXuR
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVkXuR * len(self.VVITUl) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VV7ux5:
   self.VV7ux5 = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VV7ux5)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVavJp:
   self.VVavJp = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVavJp
   self.VVavJp = []
   for item in tmpList:
    self.VVavJp.append(item | RT_VALIGN_CENTER)
  self.VVVKdN()
  if self.VV597P:
   self.VV597P(self)
 def VVNlDX(self, btnFnc, btn):
  if btnFnc : FFdufS(btn, btnFnc[0])
  else  : FFdufS(btn, "")
 def VVR5ur(self, waitTxt):
  FFlaBE(self, self.VVVKdN, title=waitTxt)
 def VVVKdN(self, onlyHeader=False):
  try:
   if self.header:
    self["myTableH"].setList([self.VVH5zt(0, self.header, self.VVxjO7, self.VV15Y9, self.VVxjO7, self.VV15Y9, self.VVYnzd)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVITUl):
    self["myTable"].list.append(self.VVH5zt(c, row, self.VVkfqz, self.VVop6p, self.VVZZ2X, self.VViLdG, None))
   self.VVITUl = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVR6Ea > -1:
    self["myTable"].moveToIndex(self.VVR6Ea )
   self.VVEsHy()
   if self.VVR0cj:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVkXuR * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVcwgo:
    self.VVZR2t(self.VVcwgo, None)
   if self.tableRefreshCB:
    self.VVZR2t(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FFfYN0(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VVH5zt(self, keyIndex, columns, VVkfqz, VVop6p, VVZZ2X, VViLdG, VVYnzd):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVYnzd and ndx == self.VVenoQ : textColor = VVYnzd
   else           : textColor = VVkfqz
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFyhto(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVop6p = c
    entry = span.group(3)
   if self.VVavJp[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVkXuR)
           , font   = 0
           , flags   = self.VVavJp[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVop6p
           , color_sel  = VVZZ2X
           , backcolor_sel = VViLdG
           , border_width = 1
           , border_color = self.VVmDPu
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVyOAW(self):
  rowData = self.VVIdwF()
  if rowData:
   title, txt, colList = rowData
   if self.VVXuip:
    fnc  = self.VVXuip[1]
    params = self.VVXuip[2]
    fnc(self, title, txt, colList)
   else:
    FFCxQN(self, txt, title)
 def VV8HAl(self):
  if   self.VVmDY2 : self.VVRxtV(self.VVYt3A(), mode=2)
  elif self.VVHFFO  : self.VVZR2t(self.VVHFFO, None)
  else      : self.VVyOAW()
 def VVZmgr(self) : self.VVZR2t(self.VVcjza , self["keyRed"])
 def VVJX7M(self) : self.VVZR2t(self.VV7wPX , self["keyGreen"])
 def VVfSET(self): self.VVZR2t(self.VVbdhP , self["keyYellow"])
 def VVLJ5p(self) : self.VVZR2t(self.VVUB3Q , self["keyBlue"])
 def VVZR2t(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFHbVj(self, buttonFnc[3])
    FFS6vB(BF(self.VVKLC2, buttonFnc))
   else:
    self.VVKLC2(buttonFnc)
 def VVKLC2(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVIdwF()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVRxtV(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][9] == self.VVZpXq
   newRow = self.VVKPIF()
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVH5zt(ndx, newRow, self.VVkfqz, self.VVop6p, self.VVZZ2X, self.VViLdG, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVH5zt(ndx, newRow, self.VVZpXq, self.VVus3X, self.VVoucn, self.VV2FuX, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   if self.VVYt3A() < len(self["myTable"].list) - 1:
    self.VV7w4B()
   else:
    self.VVEsHy()
 def VVGnJp(self)  : FFlaBE(self, BF(self.VVL5DH, True ), title="Selecting all ..."  )
 def VVG7vM(self) : FFlaBE(self, BF(self.VVL5DH, False), title="Unselecting all ...")
 def VVL5DH(self, isSel=True):
  if isSel:
   fg, bg = self.VVZpXq, self.VVus3X
   self.selectedItems = len(self["myTable"].list)
   self.VVQ2Pz(True)
  else:
   fg, bg = self.VVkfqz, self.VVop6p
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][9] == self.VVZpXq
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     param = list(self["myTable"].list[ndx][col])
     param[8]  = fg
     param[9]  = fg
     param[10] = bg
     self["myTable"].list[ndx][col] = tuple(param)
  self["myTable"].l.invalidate()
 def VVIdwF(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VV7ux5[i] > 1 or self.VV7ux5[i] == self.VVQjda or self.VV7ux5[i] == self.VVySvy:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VVH8j0(self):
  if self.VVzffX : self.VVzffX(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VVgfJ7(self):
  return self["myTitle"].getText().strip()
 def VVo26g(self):
  return self.header
 def VVr0zd(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VV3lnt(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFq6y3(self["myBar"], color)
 def VV3rfE(self, txt):
  FFHbVj(self, txt)
 def VVB7wY(self, txt, Time=1000):
  FFHbVj(self, txt, Time)
 def VVKoUM(self): self["keyGreen"].show()
 def VVNsz9(self): self["keyGreen"].hide()
 def VVDGPS(self):
  FFHbVj(self)
 def VV2DNR(self, fnc):
  self["myTable"].onSelectionChanged.append(fnc)
 def VVp58T(self):
  return len(self["myTable"].list)
 def VVYt3A(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVLfEh(self):
  return len(self["myTable"].list)
 def VVQ2Pz(self, isOn):
  self.VVmDY2 = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VVUB3Q: self["keyBlue"].hide()
   if self.VVHFFO and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVUB3Q: self["keyBlue"].show()
   if self.VVHFFO and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVHFFO[0])
   self.VVG7vM()
  FFg8wK(self["myTitle"], color)
  FFg8wK(self["myBar"]  , color)
 def VVF02t(self):
  return self.VVmDY2
 def VVFx4F(self):
  return self.selectedItems
 def VVwR15(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVEsHy()
 def VVE8l3(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVt5Zt(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVp58T()
  txt += FFEuDm("Total Unique Items", VVFBP5)
  for i in range(self.totalCols):
   if self.VV7ux5[i - 1] > 1 or self.VV7ux5[i - 1] == self.VVQjda or self.VV7ux5[i - 1] == self.VVySvy:
    name, tot = self.VVE8l3(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFCxQN(self, txt)
 def VVzQU4(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVKPIF(self):
  return self.VVy7pl(self["myTable"].l.getCurrentSelectionIndex())
 def VVy7pl(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VV3ih0(self, newList, newTitle="", VVXWqvMsg=True, tableRefreshCB=None):
  if newTitle:
   self.VVr0zd(newTitle)
  if newList:
   self.VVITUl = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VVFvoI and self.VVenoQ == 0:
    isNum = True
   else:
    for cols in self.VVITUl:
     if not FFXWUV(cols[self.VVenoQ]): break
    else:
     isNum = True
   if isNum: self.VVITUl.sort(key=lambda x: int(x[self.VVenoQ])  , reverse=self.lastSortModeIsReverese)
   else : self.VVITUl.sort(key=lambda x: x[self.VVenoQ].lower() , reverse=self.lastSortModeIsReverese)
   if VVXWqvMsg : self.VVR5ur("Refreshing ...")
   else   : self.VVVKdN()
  else:
   FFfYN0(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VVEwnc(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VVH5zt(self.VVLfEh(), row, self.VVkfqz, self.VVop6p, self.VVZZ2X, self.VViLdG, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VVZAOC()
 def VVemQb(self):
  self["myTable"].list.pop(self.VVYt3A())
  self["myTable"].l.setList(self["myTable"].list)
 def VViiSN(self, data):
  ndx = self.VVYt3A()
  newRow = self.VVH5zt(ndx, data, self.VVkfqz, self.VVop6p, self.VVZZ2X, self.VViLdG, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVEsHy()
   return True
  else:
   return False
 def VVlgEJ(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VVH5zt(ndx, data, self.VVkfqz, self.VVop6p, self.VVZZ2X, self.VViLdG, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVUdek()
 def VVUdek(self):
  self["myTable"].l.setList(self["myTable"].list)
 def VVDX4N(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VV0HXt(self, colNum, textToFind, VVdnur=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVEsHy()
    break
  else:
   if VVdnur:
    FFHbVj(self, "Not found", 1000)
 def VVirXl(self, colDict, VVdnur=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVEsHy()
    return
  if VVdnur:
   FFHbVj(self, "Not found", 1000)
 def VVBgAk(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVRGBb(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFXWUV(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVAoir(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVZpXq:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVspyc(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVZpXq:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VVDjqE(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VVZpXq: return True
  else        : return False
 def VVF8iU(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVuuzo(self):
  if not self["keyMenu"].getVisible() or self.VVR0cj:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVYt3A()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVJ4QS1, VVlCEp = CCMA5J.VVqIre(self, False, False)
  VVJ4QS = []
  VVJ4QS.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVJ4QS.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVJ4QS.append(("Find ...\t\t%s" % (FFrGgO(txt, VVE6YJ) if txt else ""), "findNew"   ))
  VVJ4QS.append(itemOf(bool(VVJ4QS1)    , "Find (from Filter) ..."   , "filter"   ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Table Statistcis"             , "tableStat"  ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append((FFrGgO("Export Table to .html"     , VVFBP5) , "VVOANZ" ))
  VVJ4QS.append((FFrGgO("Export Table to .csv"     , VVFBP5) , "VVxaXJ" ))
  VVJ4QS.append((FFrGgO("Export Table to .txt (Tab Separated)", VVFBP5) , "VVTmFv" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VV7ux5[i] > 1 or self.VV7ux5[i] == self.VVrjfH:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVJ4QS.append(VV4c5n)
   if tot == 1 : VVJ4QS.append(("Sort", sList[0][1]))
   else  : VVJ4QS += sList
  VVaSnd = ("Keys Help", self.FFA1pvHelp)
  FFZP3S(self, self.VVasiI, VVJ4QS=VVJ4QS, title=self.VVgfJ7(), VVaSnd=VVaSnd)
 def VVasiI(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVdR4P()
   elif item == "findPrev"  : self.VVdR4P(isPrev=True)
   elif item == "findNew"  : self.VVXcKg()
   elif item == "filter"  : self.VVpJFx()
   elif item == "tableStat" : self.VVt5Zt()
   elif item == "VVOANZ": FFlaBE(self, self.VVOANZ, title=title)
   elif item == "VVxaXJ" : FFlaBE(self, self.VVxaXJ , title=title)
   elif item == "VVTmFv" : FFlaBE(self, self.VVTmFv , title=title)
   else:
    self.lastSortModeIsReverese = False
    if self.VVenoQ == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVenoQ = item
    if self.VVFvoI and self.VVenoQ == 0 or self.VVRGBb(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVVKdN(onlyHeader=True)
 def FFA1pvHelp(self, menuInstance, path):
  FFrc1O(self, VVnEh8 + "_help_table", "Table (Keys Help)")
 def VVFgYa(self):
  self["myTable"].up()
  self.VVEsHy()
 def VV7w4B(self):
  self["myTable"].down()
  self.VVEsHy()
 def VVPPup(self):
  self["myTable"].pageUp()
  self.VVEsHy()
 def VV8kEj(self):
  self["myTable"].pageDown()
  self.VVEsHy()
 def VV6jq7(self):
  self["myTable"].moveToIndex(0)
  self.VVEsHy()
 def VVZAOC(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVEsHy()
 def VVeb2k(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVEsHy()
 def VVaPRg(self):
  if self.lastFindConfigObj.getValue():
   if self.VVYt3A() == len(self["myTable"].list) - 1 : FFHbVj(self, "End reached", 1000)
   else              : self.VVdR4P()
  else:
   FFHbVj(self, 'Set "Find" in Menu', 1500)
 def VVPN7k(self):
  if self.lastFindConfigObj.getValue():
   if self.VVYt3A() == 0 : FFHbVj(self, "Top reached", 1000)
   else       : self.VVdR4P(isPrev=True)
  else:
   FFHbVj(self, 'Set "Find" in Menu', 1500)
 def VV2cqy(self, txt):
  FFu7KK(self.lastFindConfigObj, txt)
 def VVXcKg(self):
  FFoW9P(self, self.VVDxIu, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VVDxIu(self, VVRnvB):
  if not VVRnvB is None:
   txt = VVRnvB.strip()
   self.VV2cqy(txt)
   if VVRnvB: self.VVdR4P(reset=True)
   else  : FFHbVj(self, "Nothing to find !", 1500)
 def VVpJFx(self):
  VVJ4QS, VVlCEp = CCMA5J.VVqIre(self, False, False)
  VVU5gS = ("Edit Filter", BF(self.VVnCSB, VVlCEp))
  if VVJ4QS : FFZP3S(self, self.VVgj0L, VVJ4QS=VVJ4QS, VVU5gS=VVU5gS, title="Find from Filter")
  else  : FFHbVj(self, "Filter Error !", 1500)
 def VVgj0L(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VV2cqy(txt)
    self.VVdR4P(reset=True)
   else:
    FFHbVj(self, "No entry !", 1500)
 def VVnCSB(self, VVlCEp, VVi8BRObj, sel):
  if fileExists(VVlCEp) : CCbzSm(self, VVlCEp, VVGpYx=None)
  else       : FF6vdZ(self, VVlCEp)
  VVi8BRObj.cancel()
 def VVdR4P(self, reset=False, isPrev=False):
  curRow = self.VVYt3A()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCMA5J.VVBkhG(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VVeb2k(i)
      break
    elif any(x in line for x in tupl):
     self.VVeb2k(i)
     break
   else:
    FFHbVj(self, "Not found", 1000)
  else:
   FFHbVj(self, "Check your query", 1500)
 def VVTmFv(self):
  expFile = self.VVHFNb() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VV2nMW()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVy7pl(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VV7ux5[ndx] > self.VVhsFn or self.VV7ux5[ndx] == self.VVySvy:
      col = self.VVh32u(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVxCBN(expFile)
 def VVxaXJ(self):
  expFile = self.VVHFNb() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VV2nMW()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVy7pl(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VV7ux5[ndx] > self.VVhsFn or self.VV7ux5[ndx] == self.VVySvy:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VVh32u(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVxCBN(expFile)
 def VVOANZ(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVgfJ7(), PLUGIN_NAME, VVHz5F)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVgfJ7()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VV2nMW()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VV7ux5:
   colgroup += '   <colgroup>'
   for w in self.VV7ux5:
    if w > self.VVhsFn or w == self.VVySvy:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVHFNb() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVy7pl(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VV7ux5[ndx] > self.VVhsFn or self.VV7ux5[ndx] == self.VVySvy:
      col = self.VVh32u(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVxCBN(expFile)
 def VV2nMW(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VV7ux5[ndx] > self.VVhsFn or self.VV7ux5[ndx] == self.VVySvy:
     newRow.append(col.strip())
  return newRow
 def VVh32u(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFVK2H(col)
 def VVHFNb(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVgfJ7())
  fileName = fileName.replace("__", "_")
  path  = FFegwS(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFSZ6D()
  return expFile
 def VVxCBN(self, expFile):
  FF8O6K(self, "File exported to:\n\n%s" % expFile, title=self.VVgfJ7())
 def VVEsHy(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CC376o():
 def __init__(self, pixmapObj, picPath, VVop6p=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VVop6p  = VVop6p or "#2200002a"
 def VVKwfc(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVPES4)
    except:
     self.picLoad.PictureData.get().append(self.VVPES4)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VVop6p])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVPES4(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVl2Cc(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVnOBs(pixmapObj, path, VVop6p=None):
  cl = CC376o(pixmapObj, path, VVop6p)
  ok = cl.VVKwfc()
  if ok: return cl
  else : return None
class CCkc9M(Screen):
 def __init__(self, session, title="", VVksLF=None, showGrnMsg="", fileList=[], curIndex=0):
  scrW, scrH = FFerEQ()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FFNQkv(VVfuBG, w, h, 30, 0, 0, "#22000060", "#2200002a", 30)
  self.Title  = title
  self.session = session
  FFVOCw(self)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "up" : BF(self.VVA8mr, -1),
   "down" : BF(self.VVA8mr,  1),
   "left" : BF(self.VVA8mr, -1),
   "right" : BF(self.VVA8mr,  1)
  }, -1)
  self["myPic"]  = Pixmap()
  self.VVksLF = VVksLF
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.picViewer  = None
  self.onShown.append(self.VV47vn)
  self.onClose.append(self.onExit)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  self.VVbMss()
  self.picViewer = CC376o.VVnOBs(self["myPic"], self.VVksLF)
  if self.picViewer:
   if self.showGrnMsg:
    FFHbVj(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFfYN0(self, "Cannot view picture file:\n\n%s" % self.VVksLF)
   self.close()
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVl2Cc()
 def VVA8mr(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.picViewer.picPath = FFegwS(os.path.dirname(self.VVksLF)) + fName
    self.picViewer.VVKwfc()
    self.VVbMss()
 def VVbMss(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VVksLF)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VVthJo(SELF, VVksLF, title="", showGrnMsg="", fileList=[], curIndex=0):
  SELF.session.open(BF(CCkc9M, title=title, VVksLF=VVksLF, showGrnMsg=showGrnMsg, fileList=fileList, curIndex=curIndex))
class CCaIeq(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FFNQkv(VVR3Vk, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FFVOCw(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VV47vn)
  self.onClose.append(self.onExit)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  res = os.system(FFyto6("showiframe %s" % self.mviFile))
  if not res == 0:
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VVR3gv(SELF, mviFile):
  SELF.session.openWithCallback(BF(CCaIeq.VVAY0a, SELF), CCaIeq, mviFile)
 @staticmethod
 def VVAY0a(SELF, reason=None):
  if reason == -1: FFfYN0(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CCVsdm(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFNQkv(VVqRLf, 1400, 1050, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFVOCw(self, title=self.Title)
  FFdufS(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("File Manage Exit-Button Action"        , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  if VVSJRi:
   lst.append(getConfigListEntry("EPG Translation Language"        , CFG.epgLanguage    ))
  lst.append(getConfigListEntry(VVU8ll *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Movie/Series Download Path"         , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VVU8ll *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VVU8ll *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVodB4()
  self.onShown.append(self.VV47vn)
 def VVodB4(self):
  kList = {
    "ok"  : self.VVfFPM    ,
    "green"  : self.VVztLG  ,
    "menu"  : self.VVs5lK  ,
    "cancel" : self.VVNw9w  ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVsMjr, 0)
     kList["chanDown"] = BF(self["config"].VVsMjr, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FFABOX(self)
  FFAoMS(self["config"])
  FFJdIh(self, self["config"])
  FFeAg3(self)
 def VVfFPM(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsMode   : self.VVyGSG()
   elif item == CFG.MovieDownloadPath   : self.VVyxN2(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VVnziK(item)
   elif item == CFG.backupPath    : self.VVnziK(item)
   elif item == CFG.packageOutputPath  : self.VVnziK(item)
   elif item == CFG.downloadedPackagesPath : self.VVnziK(item)
   elif item == CFG.exportedTablesPath  : self.VVnziK(item)
   elif item == CFG.exportedPIconsPath  : self.VVnziK(item)
 def VVyxN2(self, item, title):
  tot = CCjOMG.VVOcRx()
  if tot : FFfYN0(self, "Cannot change while downloading.", title=title)
  else : self.VVnziK(item)
 def VVyGSG(self):
  VVJ4QS = []
  VVJ4QS.append(("Auto Find" , "auto"))
  VVJ4QS.append(("Custom Path" , "cust"))
  FFZP3S(self, self.VV3M7y, VVJ4QS=VVJ4QS, title="IPTV Hosts Files Path")
 def VV3M7y(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVqwOi)
   elif item == "cust":
    VVjhh4 = self.VVMhdo()
    if VVjhh4 : self.VVfuVn(VVjhh4)
    else  : self.session.openWithCallback(self.VVNbmD, BF(CCqXgM, mode=CCqXgM.VViiv3, VVjq2g="/"))
 def VVfuVn(self, VVjhh4):
  VVzffX = self.VVKodj
  VVcjza = ("Remove"  , self.VVoxHU , [])
  VVbdhP = ("Add "  , self.VVpRmQ, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VVavJp  = (LEFT   , LEFT  )
  FFA1pv(self, None, title="IPTV Hosts Search Paths", header=header, VVITUl=VVjhh4, width=1200, height=700, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=26, VVzffX=VVzffX, VVcjza=VVcjza, VVbdhP=VVbdhP
    , VV1Y9q="#11220000", VVMnLe="#11110000", VVop6p="#11110011", VVZZ2X="#00ffff00", VViLdG="#00223025", VVmDPu="#0a333333", VV15Y9="#0a400040")
 def VVKodj(self, VVToDv):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VV0WeH)
  VVToDv.cancel()
 def VVNbmD(self, path):
  if path:
   FFu7KK(CFG.iptvHostsDirs, FFegwS(path.strip()))
   VVjhh4 = self.VVMhdo()
   if VVjhh4 : self.VVfuVn(VVjhh4)
   else  : FFHbVj(self, "Cannot add dir", 1500)
 def VVwlQt(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVqwOi:
   return []
  return lst
 def VVMhdo(self):
  lst = self.VVwlQt()
  if lst:
   VVjhh4 = []
   for Dir in lst:
    VVjhh4.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVjhh4.sort(key=lambda x: x[0].lower())
   return VVjhh4
  else:
   return []
 def VVpRmQ(self, VVToDv, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VVcbLY, VVToDv)
         , BF(CCqXgM, mode=CCqXgM.VViiv3, VVjq2g=sDir))
 def VVcbLY(self, VVToDv, path):
  if path:
   path = FFegwS(path.strip())
   if self.VVVqJu(VVToDv, path):
    FFHbVj(VVToDv, "Already added", 1500)
   else:
    lst = self.VVwlQt()
    lst.append(path)
    FFu7KK(CFG.iptvHostsDirs, ",".join(lst))
    VVjhh4 = self.VVMhdo()
    VVToDv.VV3ih0(VVjhh4, tableRefreshCB=BF(self.VVkPJf, path))
 def VVkPJf(self, path, VVToDv, title, txt, colList):
  self.VVVqJu(VVToDv, path)
 def VVVqJu(self, VVToDv, path):
  for ndx, row in enumerate(VVToDv.VVF8iU()):
   if row[0].strip() == path.strip():
    VVToDv.VVeb2k(ndx)
    return True
  return False
 def VVoxHU(self, VVToDv, title, txt, colList):
  path = colList[0]
  FFZw7B(self, BF(self.VVuaxp, VVToDv), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVuaxp(self, VVToDv):
  row = VVToDv.VVKPIF()
  path, rem = row[0], row[1]
  VVjhh4 = []
  lst = []
  for ndx, row in enumerate(VVToDv.VVF8iU()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVjhh4.append((tPath, tRem))
  if len(VVjhh4) > 0:
   FFu7KK(CFG.iptvHostsDirs, ",".join(lst))
   VVToDv.VV3ih0(VVjhh4)
   FFHbVj(VVToDv, "Deleted", 1500)
  else:
   FFu7KK(CFG.iptvHostsMode, VVqwOi)
   FFu7KK(CFG.iptvHostsDirs, "")
   VVToDv.cancel()
   FFS6vB(BF(FFHbVj, self, "Changed to Auto-Find", 1500))
 def VVnziK(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VVMkU2, configObj)
         , BF(CCqXgM, mode=CCqXgM.VViiv3, VVjq2g=sDir))
 def VVMkU2(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVNw9w(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFZw7B(self, self.VVztLG, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVztLG(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVk2l0()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVs5lK(self):
  VVJ4QS = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVJ4QS.append((txt    , "VVouwZ"   ))
  else        : VVJ4QS.append((txt    ,       ))
  VVJ4QS.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Reset %s Settings" % PLUGIN_NAME      , "VV56b4"   ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Backup %s Settings" % PLUGIN_NAME      , "VVGft2"  ))
  VVJ4QS.append(("Restore %s Settings" % PLUGIN_NAME     , "VV5VD7"  ))
  if fileExists(VVL4Xa + VVsUI5):
   VVJ4QS.append(VV4c5n)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVJ4QS.append(('%s Checking for Update' % txt1     , txt2     ))
   VVJ4QS.append(("Reinstall %s" % PLUGIN_NAME      , "VVdeGC"  ))
   VVJ4QS.append(("Update %s" % PLUGIN_NAME      , "VVW4pa"   ))
  FFZP3S(self, self.VVeoYz, VVJ4QS=VVJ4QS, title="Config. Options")
 def VVeoYz(self, item=None):
  if item:
   if   item == "VVouwZ"  : FFZw7B(self, self.VVouwZ , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CCr1Ch)
   elif item == "VV56b4"  : FFZw7B(self, self.VV56b4, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VVGft2" : self.VVGft2()
   elif item == "VV5VD7" : FFlaBE(self, self.VV5VD7, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FFu7KK(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FFu7KK(CFG.checkForUpdateAtStartup, False)
   elif item == "VVdeGC" : FFlaBE(self, self.VVdeGC , "Checking Server ...")
   elif item == "VVW4pa"  : FFlaBE(self, self.VVW4pa  , "Checking Server ...")
 def VVGft2(self):
  path = "%sajpanel_settings_%s" % (VVL4Xa, FFSZ6D())
  os.system("grep .%s. %ssettings > %s" % (PLUGIN_NAME, VVoDv6, path))
  FF8O6K(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VV5VD7(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFz7l2("find / %s -iname '%s*' | grep %s" % (FFRjyr(1), name, name))
  if lines:
   lines.sort()
   VVJ4QS = []
   for line in lines:
    VVJ4QS.append((line, line))
   FFZP3S(self, BF(self.VVu1oS, title), title=title, VVJ4QS=VVJ4QS, width=1200)
  else:
   FFfYN0(self, "No settings files found !", title=title)
 def VVu1oS(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFup4P(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVk2l0()
    FFTS1C()
   else:
    FF6vdZ(SELF, path, title=title)
 def VVouwZ(self):
  newPath = FFegwS(VVL4Xa)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVk2l0()
 @staticmethod
 def VViBwI():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VV56b4(self):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVk2l0()
  self.close()
 def VVk2l0(self):
  configfile.save()
  global VVL4Xa
  VVL4Xa = CFG.backupPath.getValue()
  FFg43c()
 def VVW4pa(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVHLX4(title)
  if webVer:
   FFZw7B(self, BF(FFlaBE, self, BF(self.VVNJ5I, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVdeGC(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVHLX4(title, True)
  if webVer:
   FFZw7B(self, BF(FFlaBE, self, BF(self.VVNJ5I, webVer, title, True)), "Install and Restart ?", title=title)
 def VVNJ5I(self, webVer, title, isReinst=False):
  url = self.VVgR05(self, title)
  if url:
   VVZWSD = FFHJyu() == "dpkg"
   if VVZWSD == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVZWSD else "ipk")
   path, err = FFSAwr(url + fName, fName, timeout=2)
   if path:
    if isReinst : cmd = FFMotr(VVgRg8, path)
    else  : cmd = FFMotr(VVwcQY, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFyKCd(self, cmd)
    else:
     FF1KkZ(self, title=title)
   else:
    FFfYN0(self, err, title=title)
 def VVHLX4(self, title, anyVer=False):
  url = self.VVgR05(self, title)
  if not url:
   return ""
  path, err = FFSAwr(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFfYN0(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFZF5l(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFfYN0(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVHz5F.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFz7l2(cmd)
   if list and curVer == list[0]:
    return webVer
  FF8O6K(self, FFrGgO("No update required.", VVqQXm) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVgR05(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVL4Xa + VVsUI5
  if fileExists(path):
   span = iSearch(r"(http.+)", FFZF5l(path), IGNORECASE)
   if span : url = FFegwS(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFfYN0(SELF, err, title)
  return url
 @staticmethod
 def VVNLfy(url):
  path, err = FFSAwr(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFZF5l(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVHz5F.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFz7l2(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCr1Ch(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFNQkv(VVOVX1, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = COLOR_SCHEME_NUM
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFVOCw(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVgfUQ("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVgfUQ("\c00888888", i) + sp + "GREY\n"
   txt += self.VVgfUQ("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVgfUQ("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVgfUQ("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVgfUQ("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVgfUQ("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVgfUQ("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVgfUQ("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVgfUQ("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVgfUQ("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVgfUQ("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVfFPM ,
   "green"   : self.VVfFPM ,
   "left"   : self.VVsfLd ,
   "right"   : self.VVB1TT ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  self.VVeMlJ()
 def VVfFPM(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFZw7B(self, self.VVxPaa, "Change to : %s" % txt, title=self.Title)
 def VVxPaa(self):
  FFu7KK(CFG.mixedColorScheme, self.cursorPos)
  global COLOR_SCHEME_NUM
  COLOR_SCHEME_NUM = self.cursorPos
  self.VVcu6N()
  self.close()
 def VVsfLd(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVeMlJ()
 def VVB1TT(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVeMlJ()
 def VVeMlJ(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVgfUQ(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVDcL5(color):
  if VVy0iZ: return "\\" + color
  else    : return ""
 @staticmethod
 def VVcu6N():
  global VV4U5y, VVyLoh, VVwmjQ, VVPUgM, VVFBP5, VV61Yf, VVx4sJ, VVCfWA, VVqQXm, VV6svy, VVy0iZ, VVtSeQ, VVE6YJ, VVxpap, VVOBCT, VVCLGj
  VVCLGj   = CCr1Ch.VVgfUQ("\c00FFFFFF", COLOR_SCHEME_NUM)
  VVyLoh    = CCr1Ch.VVgfUQ("\c00888888", COLOR_SCHEME_NUM)
  VV4U5y  = CCr1Ch.VVgfUQ("\c005A5A5A", COLOR_SCHEME_NUM)
  VVCfWA    = CCr1Ch.VVgfUQ("\c00FF0000", COLOR_SCHEME_NUM)
  VVwmjQ   = CCr1Ch.VVgfUQ("\c00FF5000", COLOR_SCHEME_NUM)
  VVPUgM   = CCr1Ch.VVgfUQ("\c00FFBB66", COLOR_SCHEME_NUM)
  VVy0iZ   = CCr1Ch.VVgfUQ("\c00FFFF00", COLOR_SCHEME_NUM)
  VVtSeQ = CCr1Ch.VVgfUQ("\c00FFFFAA", COLOR_SCHEME_NUM)
  VVqQXm   = CCr1Ch.VVgfUQ("\c0000FF00", COLOR_SCHEME_NUM)
  VV6svy  = CCr1Ch.VVgfUQ("\c00AAFFAA", COLOR_SCHEME_NUM)
  VVx4sJ    = CCr1Ch.VVgfUQ("\c000066FF", COLOR_SCHEME_NUM)
  VVE6YJ    = CCr1Ch.VVgfUQ("\c0000FFFF", COLOR_SCHEME_NUM)
  VVxpap  = CCr1Ch.VVgfUQ("\c00AAFFFF", COLOR_SCHEME_NUM)  #
  VVOBCT   = CCr1Ch.VVgfUQ("\c00FA55E7", COLOR_SCHEME_NUM)
  VVFBP5    = CCr1Ch.VVgfUQ("\c00FF8F5F", COLOR_SCHEME_NUM)
  VV61Yf  = CCr1Ch.VVgfUQ("\c00FFC0C0", COLOR_SCHEME_NUM)
CCr1Ch.VVcu6N()
class CCcPEE(Screen):
 def __init__(self, session, path, VVZWSD):
  self.skin, self.skinParam = FFNQkv(VVQhFe, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVLDgz   = path
  self.VVT81Z   = ""
  self.VVRsvh   = ""
  self.VVZWSD    = VVZWSD
  self.VVe2Ij    = ""
  self.VVYs8A  = ""
  self.VVLPKa    = False
  self.VV1sSE  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VVgbnf  = "enigma2-plugin-extensions-"
  self.VVQ8Tk  = "enigma2-plugin-systemplugins-"
  self.VV3Ltt = "enigma2-"
  self.VVroPl  = 0
  self.VV5Wdx  = 1
  self.VVLyZL  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVUlDU = "DEBIAN"
  else        : self.VVUlDU = "CONTROL"
  self.controlPath = self.Path + self.VVUlDU
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVZWSD:
   self.packageExt  = ".deb"
   self.VVop6p  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVop6p  = "#11001020"
  FFVOCw(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFdufS(self["keyRed"] , "Create")
  FFdufS(self["keyGreen"] , "Post Install")
  FFdufS(self["keyYellow"], "Installation Path")
  FFdufS(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVxtIj  ,
   "green"   : self.VVzDPt ,
   "yellow"  : self.VVa1cM  ,
   "blue"   : self.VViShS  ,
   "cancel"  : self.VVChzf
  }, -1)
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FFeAg3(self)
  if self.VVop6p:
   FFg8wK(self["myBody"], self.VVop6p)
   FFg8wK(self["myLabel"], self.VVop6p)
  self.VVnx8t(True)
  self.VVm0c9(True)
 def VVm0c9(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVRLKB()
  if isFirstTime:
   if   package.startswith(self.VVgbnf) : self.VVLDgz = VVEK1s + self.VVe2Ij + "/"
   elif package.startswith(self.VVQ8Tk) : self.VVLDgz = VVTdNX + self.VVe2Ij + "/"
   else            : self.VVLDgz = self.Path
  if self.VVLPKa : myColor = VVFBP5
  else    : myColor = VVCLGj
  txt  = ""
  txt += "Source Path\t: %s\n" % FFrGgO(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFrGgO(self.VVLDgz, VVy0iZ)
  if self.VVRsvh : txt += "Package File\t: %s\n" % FFrGgO(self.VVRsvh, VVyLoh)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFrGgO("Check Control File fields : %s" % errTxt, VVwmjQ)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFrGgO("Restart GUI", VVFBP5)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFrGgO("Reboot Device", VVFBP5)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FFrGgO("Post Install", VVqQXm), act)
  if not errTxt and VVwmjQ in controlInfo:
   txt += "Warning\t: %s\n" % FFrGgO("Errors in control file may affect the result package.", VVwmjQ)
  txt += "\nControl File\t: %s\n" % FFrGgO(self.controlFile, VVyLoh)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVzDPt(self):
  if self["keyGreen"].getVisible():
   VVJ4QS = []
   VVJ4QS.append(("No Action"    , "noAction"  ))
   VVJ4QS.append(("Restart GUI"    , "VV644R"  ))
   VVJ4QS.append(("Reboot Device"   , "rebootDev"  ))
   FFZP3S(self, self.VVPV1c, title="Package Installation Option (after completing installation)", VVJ4QS=VVJ4QS)
 def VVPV1c(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VV644R"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVnx8t(False)
   self.VVm0c9()
 def VVa1cM(self):
  rootPath = FFrGgO("/%s/" % self.VVe2Ij, VVtSeQ)
  VVJ4QS = []
  VVJ4QS.append(("Current Path"        , "toCurrent"  ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Extension Path"       , "toExtensions" ))
  VVJ4QS.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVJ4QS.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFZP3S(self, self.VV01B5, title="Installation Path", VVJ4QS=VVJ4QS)
 def VV01B5(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVlAIx(FFxBb9(self.Path, True))
   elif item == "toExtensions"  : self.VVlAIx(VVEK1s)
   elif item == "toSystemPlugins" : self.VVlAIx(VVTdNX)
   elif item == "toRootPath"  : self.VVlAIx("/")
   elif item == "toRoot"   : self.VVlAIx("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VV2TD6, BF(CCqXgM, mode=CCqXgM.VViiv3, VVjq2g=VVL4Xa))
 def VV2TD6(self, path):
  if len(path) > 0:
   self.VVlAIx(path)
 def VVlAIx(self, parent, withPackageName=True):
  if withPackageName : self.VVLDgz = parent + self.VVe2Ij + "/"
  else    : self.VVLDgz = "/"
  mode = self.VVhJEy()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVZXsm(mode), self.controlFile))
  self.VVm0c9()
 def VViShS(self):
  if fileExists(self.controlFile):
   lines = FFup4P(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFoW9P(self, self.VV77P6, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFfYN0(self, "Version not found or incorrectly set !")
  else:
   FF6vdZ(self, self.controlFile)
 def VV77P6(self, VVRnvB):
  if VVRnvB:
   version, color = self.VVxKzo(VVRnvB, False)
   if color == VVE6YJ:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVRnvB, self.controlFile))
    self.VVm0c9()
   else:
    FFfYN0(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVChzf(self):
  if self.newControlPath:
   if self.VVLPKa:
    self.VVCPMu()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFrGgO(self.newControlPath, VVyLoh)
    txt += FFrGgO("Do you want to keep these files ?", VVy0iZ)
    FFZw7B(self, self.close, txt, callBack_No=self.VVCPMu, title="Create Package", VV5RdC=True)
  else:
   self.close()
 def VVCPMu(self):
  os.system(FFyto6("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVZXsm(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VVYs8A
  if package.startswith(self.VV3Ltt):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VV3Ltt, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VV5Wdx : prefix = self.VVgbnf
  elif mode == self.VVLyZL : prefix = self.VVQ8Tk
  return (prefix + name).lower()
 def VVhJEy(self):
  if   self.VVLDgz.startswith(VVEK1s) : return self.VV5Wdx
  elif self.VVLDgz.startswith(VVTdNX) : return self.VVLyZL
  else            : return self.VVroPl
 def VVnx8t(self, isFirstTime):
  self.VVe2Ij   = FFbSa4(self.Path)
  self.VVe2Ij   = "_".join(self.VVe2Ij.split())
  self.VVYs8A = self.VVe2Ij.lower()
  self.VVLPKa = self.VVYs8A == VVWcf6.lower()
  if self.VVLPKa and self.VVYs8A.endswith("ajpan"):
   self.VVYs8A += "el"
  if self.VVLPKa : self.VVT81Z = VVL4Xa
  else    : self.VVT81Z = CFG.packageOutputPath.getValue()
  self.VVT81Z = FFegwS(self.VVT81Z)
  if not pathExists(self.controlPath):
   os.system(FFyto6("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VVhJEy()
  if fileExists(self.controlFile):
   lines = FFup4P(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VVLPKa : version, descripton, maintainer = VVHz5F , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVe2Ij , self.VVe2Ij
   txt = ""
   txt += "Package: %s\n"  % self.VVZXsm(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VVLPKa : t = PLUGIN_NAME
  else    : t = self.VVe2Ij
  self.VVDRUJ(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVDRUJ(self.postrmFile, "echo 'Package removed.'\n")
  if self.VVLPKa : self.VVDRUJ(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVHz5F))
  else    : self.VVDRUJ(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVe2Ij)
  if isFirstTime and not mode == self.VVroPl:
   self.postInstAcion = 1
  txt = self.VVqWWu(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFZF5l(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VVqWWu(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  os.system(FFyto6("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
 def VVDRUJ(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VVqWWu(self, action):
  sep  = "echo '%s'\n" % VVU8ll
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VVRLKB(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFup4P(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFrGgO(line, VVwmjQ)
     elif not line.startswith(" ")    : line = FFrGgO(line, VVwmjQ)
     else          : line = FFrGgO(line, VVE6YJ)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVE6YJ
   else   : color = VVwmjQ
   descr = FFrGgO(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVwmjQ
     elif line.startswith((" ", "\t")) : color = VVwmjQ
     elif line.startswith("#")   : color = VVyLoh
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVxKzo(val, True)
      elif key == "Version"  : version, color = self.VVxKzo(val, False)
      elif key == "Maintainer" : maint  , color = val, VVE6YJ
      elif key == "Architecture" : arch  , color = val, VVE6YJ
      else:
       color = VVE6YJ
      if not key == "OE" and not key.istitle():
       color = VVwmjQ
     else:
      color = VVFBP5
     txt += FFrGgO(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVRsvh = self.VVT81Z + packageName
   self.VV1sSE = True
   errTxt = ""
  else:
   self.VVRsvh  = ""
   self.VV1sSE = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVxKzo(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVE6YJ
  else          : return val, VVwmjQ
 def VVxtIj(self):
  if not self.VV1sSE:
   FFfYN0(self, "Please fix Control File errors first.")
   return
  if self.VVZWSD: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFxBb9(self.VVLDgz, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVe2Ij
  symlinkTo  = FFFTbs(self.Path)
  dataDir   = self.VVLDgz.rstrip("/")
  removePorjDir = FFyto6("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFyto6("rm -f '%s'" % self.VVRsvh) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFF2ep()
  if self.VVZWSD:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFC4vV("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVLPKa:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVLDgz == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVUlDU)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVRsvh, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVRsvh
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVRsvh, FFT6nF(result  , VVqQXm))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVLDgz, FFT6nF(instPath, VVE6YJ))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFT6nF(failed, VVwmjQ))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFyKCd(self, cmd)
class CC54zE():
 VV8nsL  = "666"
 VV3SYF   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.menuInstance   = None
  self.VV6U2T()
 def VV6U2T(self):
  VVJ4QS = CC54zE.VVtYge()
  if VVJ4QS:
   VVU5gS = ("Create New", self.VVLax6)
   self.menuInstance = FFZP3S(self.SELF, self.VVpdn8, VVJ4QS=VVJ4QS, title=self.Title, VVU5gS=VVU5gS, VV7GES=True, VV1Y9q="#22222233", VVMnLe="#22222233")
  else:
   self.VVLax6()
 def VVpdn8(self, item):
  if item:
   bName, bRef, ndx = item
   self.VVTi9G(bName, bRef)
  else:
   CC54zE.VVwedv(self)
 def VVLax6(self, VVi8BRObj=None, item=None):
  FFoW9P(self.SELF, BF(self.VV38UD), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VV38UD(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.menuInstance:
     self.menuInstance.cancel()
    self.VVTi9G(bName, "")
   else:
    FFHbVj(self.menuInstance, "Incorrect Bouquet Name !", 2000)
    CC54zE.VVwedv(self)
 def VVTi9G(self, bName, bRef):
  FFlaBE(self.waitMsgSELF, BF(self.VV4A1a, bName, bRef), title="Adding Services ...")
 def VV4A1a(self, bName, bRef):
  CC54zE.VV5b6v(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVwedv(classObj):
  del classObj
 @staticmethod
 def VV5b6v(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FFfYN0(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVoDv6 + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FF6vdZ(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CC54zE.VVelIF(bRef)
   bPath = VVoDv6 + bFile
  else:
   fName = CCCwQV.VVomSS(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVoDv6 + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVoDv6 + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  CC54zE.VV5Ckv(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   CC54zE.VV5Ckv(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CC8ahC.VVmFFX()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       os.system(FFyto6("cp -f '%s' '%s'" % (poster, picon)))
       os.system(CCy52I.VVWRuE(picon))
       break
  FFpUU8()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FFCxQN(SELF, txt, title=title)
 @staticmethod
 def VVtYge(mode=2, showTitle=True, prefix=""):
  VVJ4QS = []
  if mode in (0, 2): VVJ4QS.extend(CC54zE.VVmFWV(0, showTitle, prefix))
  if mode in (1, 2): VVJ4QS.extend(CC54zE.VVmFWV(1, showTitle, prefix))
  return VVJ4QS
 @staticmethod
 def VVmFWV(mode, showTitle, prefix):
  VVJ4QS = []
  lst = CC54zE.VVOMsM(mode)
  if lst:
   if showTitle:
    VVJ4QS.append(FFksVn("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVJ4QS.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVJ4QS.append((item[0], item[1].toString()))
  return VVJ4QS
 @staticmethod
 def VVKYu3():
  bLise = CC54zE.VVOMsM(0)
  bLise.extend(CC54zE.VVOMsM(1))
  return bLise
 @staticmethod
 def VVOMsM(mode=0):
  bList = []
  VVdeEx = InfoBar.instance
  VVBoUf = VVdeEx and VVdeEx.servicelist
  if VVBoUf:
   curMode = VVBoUf.mode
   CC54zE.VV0hAN(VVBoUf, mode)
   bList.extend(VVBoUf.getBouquetList() or [])
   CC54zE.VV0hAN(VVBoUf, curMode)
  return bList
 @staticmethod
 def VV0hAN(VVBoUf, mode):
  if not mode == VVBoUf.mode:
   if   mode == 0: VVBoUf.setModeTv()
   elif mode == 1: VVBoUf.setModeRadio()
 @staticmethod
 def VV5Ckv(fPath):
  with open(fPath, "rb+") as f:
   try:
    f.seek(-1, 2)
    if ord(f.read(1)) not in (10, 13):
     f.write(b"\n")
   except:
    pass
 @staticmethod
 def VVelIF(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : ""
 @staticmethod
 def VVoJdB():
  try:
   fName = CC54zE.VVelIF(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVoDv6, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VVuBxU():
  path = CC54zE.VVoJdB()
  if path:
   txt = FFZF5l(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VVgo8J():
  return FF5CZv(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VViCTt():
  lst = []
  for b in CC54zE.VVKYu3():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVoDv6 + CC54zE.VVelIF(bRef)
   if fileExists(path):
    lines = FFup4P(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VVRDTw(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VVZjqZ(SID="", stripRType=False):
  if SID : patt = CC54zE.VVRDTw(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CC54zE.VVKYu3():
   for service in FF5CZv(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVSqHV():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CC54zE.VVKYu3():
   for service in FF5CZv(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVXkSD(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VV1axl(pathLst):
  refLst = CC54zE.VVZjqZ(CC54zE.VV8nsL, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CC54zE.VVXkSD(rType, CC54zE.VV8nsL, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CCqXgM(Screen):
 VVDEbH   = 0
 VVvbEJ  = 1
 VViiv3  = 2
 VVRct7  = 3
 VVgePW    = 20
 VV0zZr  = None
 def __init__(self, session, VVjq2g="/", mode=VVDEbH, VVc6q2="Select", height=920, VVy2kz=30, gotoMovie=False, jumpToFile=""):
  self.skin, self.skinParam = FFNQkv(VVLAKc, 1400, height, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFVOCw(self)
  FFdufS(self["keyRed"] , "Exit" if mode == self.VVDEbH else "Cancel")
  FFdufS(self["keyYellow"], "More Options")
  FFdufS(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVc6q2 = VVc6q2
  self.jumpToFile   = jumpToFile
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = "#06003333"
  CCqXgM.VV0zZr = self
  if   self.jumpToFile       : VV5jbE, self.VVjq2g = True , FFxBb9(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VV5jbE, self.VVjq2g = True , CCqXgM.VVsA5T(self)[1] or "/"
  elif self.mode == self.VVDEbH  : VV5jbE, self.VVjq2g = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VViiv3 : VV5jbE, self.VVjq2g = False, VVjq2g
  elif self.mode == self.VVRct7 : VV5jbE, self.VVjq2g = True , VVjq2g
  else           : VV5jbE, self.VVjq2g = True , VVjq2g
  self.VVjq2g = FFegwS(self.VVjq2g)
  VVIlzS = None
  if self.mode == self.VVRct7:
   VVIlzS = "^.*\.srt"
  self["myMenu"] = CCGzH5(  directory   = None
         , VVIlzS = VVIlzS
         , VV5jbE   = VV5jbE
         , VVXmPK = True
         , VVzjtd = True
         , VVFKGn   = self.skinParam["width"]
         , VVy2kz   = self.skinParam["bodyFontSize"]
         , VVkXuR  = self.skinParam["bodyLineH"]
         , VV3GoA  = self.skinParam["bodyColor"]
         , pngBGColorSelStr = self.cursorBG)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVfFPM    ,
   "red"  : self.VVyVLb   ,
   "green"  : self.VVujVB,
   "yellow" : self.VVN1aD  ,
   "blue"  : self.VVRoE8 ,
   "menu"  : self.VVNTvp  ,
   "info"  : self.VVuHEO  ,
   "cancel" : self.VV8W3v    ,
   "pageUp" : self.VVFcdI   ,
   "chanUp" : self.VVFcdI
  }, -1)
  FFCDOS(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VV9nV9)
 def onExit(self):
  CCqXgM.VV0zZr = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VV9nV9)
  FFABOX(self)
  FFAoMS(self["myMenu"], bg=self.cursorBG)
  FFeAg3(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VViiv3, self.VVRct7):
   FFdufS(self["keyGreen"], self.VVc6q2)
   color = "#22000022"
   FFg8wK(self["myBody"], color)
   FFg8wK(self["myMenu"], color)
   color = "#22220000"
   FFg8wK(self["myTitle"], color)
   FFg8wK(self["myBar"], color)
  self.VV9nV9()
  if self.VVZQHn(self.VVjq2g) > self.bigDirSize: FFlaBE(self, self.VVjFLL, title="Changing directory...")
  else              : self.VVjFLL()
 def VVjFLL(self):
  if self.jumpToFile : self.VVNkFl(self.jumpToFile)
  elif self.gotoMovie : self.VVwqMc(chDir=False)
  else    : self["myMenu"].VV7Pcy(self.VVjq2g)
 def VVeb2k(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VV82Tk(self):
  self["myMenu"].refresh()
  FFKjU2()
 def VVZQHn(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VVfFPM(self):
  if self["myMenu"].VVE1SB() : self.VVJBki()
  else       : self.VVseIL()
 def VVFcdI(self):
  self["myMenu"].moveToIndex(0)
  if self["myMenu"].VVnyHl():
   self.VVJBki()
 def VVJBki(self, isDirUp=False):
  if self["myMenu"].VVE1SB():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVoWBh(self.VVi8BR())
   if self.VVZQHn(path) > self.bigDirSize : FFlaBE(self, self.VV0Glr, title="Changing directory...")
   else           : self.VV0Glr()
 def VV0Glr(self):
  self["myMenu"].descent()
  self.VV9nV9()
 def VV8W3v(self):
  if CFG.FileManagerExit.getValue() == "e": self.VVyVLb()
  else         : self.VVFcdI()
 def VVyVLb(self):
  if not FFGcL0(self):
   self.close("")
 def VVujVB(self):
  path = self.VVoWBh(self.VVi8BR())
  if self.mode == self.VViiv3:
   self.close(path)
  elif self.mode == self.VVRct7:
   if os.path.isfile(path) : self.close(path)
   else     : FFHbVj(self, "Only .srt files", 1000)
 def VVuHEO(self):
  if not self.mode == self.VVRct7:
   FFlaBE(self, self.VVw9EN, title="Calculating size ...")
 def VVw9EN(self):
  path = self.VVoWBh(self.VVi8BR())
  param = self.VVhnSo(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFIgoM("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCqXgM.VVW9Yx(path)
     freeSize = CCqXgM.VVRyP5(path)
     size = totSize - freeSize
     totSize  = CCqXgM.VV4m3L(totSize)
     freeSize = CCqXgM.VV4m3L(freeSize)
    else:
     size = FFIgoM("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CCqXgM.VV4m3L(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFrGgO(pathTxt, VVFBP5) + "\n"
   if slBroken : fileTime = self.VVPLqR(path)
   else  : fileTime = self.VVDnlk(path)
   def VV4wPN(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VV4wPN("Path"    , pathTxt)
   txt += VV4wPN("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VV4wPN("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VV4wPN("Total Size"   , "%s" % totSize)
    txt += VV4wPN("Used Size"   , "%s" % usedSize)
    txt += VV4wPN("Free Size"   , "%s" % freeSize)
   else:
    txt += VV4wPN("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VV4wPN("Owner"    , owner)
   txt += VV4wPN("Group"    , group)
   txt += VV4wPN("Perm. (User)"  , permUser)
   txt += VV4wPN("Perm. (Group)"  , permGroup)
   txt += VV4wPN("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VV4wPN("Perm. (Ext.)" , permExtra)
   txt += VV4wPN("iNode"    , iNode)
   txt += VV4wPN("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVU8ll, VVU8ll)
    txt += hLinkedFiles
   txt += self.VVE7wa(path)
  else:
   FFfYN0(self, "Cannot access information !")
  if len(txt) > 0:
   FFCxQN(self, txt)
 def VVhnSo(self, path):
  path = path.strip()
  path = FFFTbs(path)
  result = FFIgoM("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVHJcV(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVHJcV(perm, 1, 4)
   permGroup = VVHJcV(perm, 4, 7)
   permOther = VVHJcV(perm, 7, 10)
   permExtra = VVHJcV(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFc7L0("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVE7wa(self, path):
  txt  = ""
  res  = FFIgoM("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFrGgO("File Attributes:", VVOBCT), txt)
  return txt
 def VVDnlk(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FF4ENQ(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FF4ENQ(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FF4ENQ(os.path.getctime(path))
  return txt
 def VVPLqR(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFIgoM("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFIgoM("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFIgoM("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVoWBh(self, currentSel):
  currentDir  = self["myMenu"].VVWQbR()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVE1SB():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVi8BR(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VV9nV9(self):
  path = self.VVoWBh(self.VVi8BR())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVdWtx()
  if self.mode == self.VVDEbH and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
  if self.mode == self.VVRct7 and len(path) > 0 : self["keyInfo"].hide()
  else               : self["keyInfo"].show()
  if self.mode == self.VVRct7:
   path = self.VVoWBh(self.VVi8BR())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVdWtx(self):
  if self.VVxKT6() : self["keyBlue"].show()
  else      : self["keyBlue"].hide()
 def VVNTvp(self):
  if self.mode == self.VVDEbH:
   color1  = VV61Yf
   color2  = VVtSeQ
   path  = self.VVoWBh(self.VVi8BR())
   VVJ4QS = []
   VVJ4QS.append(("Properties", "properties"))
   if os.path.isdir(path):
    if not self.VVP6R1(path):
     VVJ4QS.append(VV4c5n)
     VVJ4QS.append((color1 + "Archiving / Packaging", "VVGGiE_dir"))
   elif os.path.isfile(path):
    selFile = self.VVi8BR()
    isArch = selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar"))
    if not isArch:
     VVJ4QS.append((color1 + "Archive ...", "VVGGiE_file"))
    isText = False
    txt = ""
    if   isArch            : VVJ4QS.extend(self.VVqQfc(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith(".m3u")       : VVJ4QS.extend(self.VVLJJw(True))
    elif selFile.endswith(".sh"):
     VVJ4QS.extend(self.VVzSc7(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CCqXgM.VVbo3a(path):
     VVJ4QS.append(VV4c5n)
     VVJ4QS.append((color2 + "View"     , "textView_def"))
     VVJ4QS.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVJ4QS.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVPqql(path) == "pic":
     if selFile.lower().endswith((".jpg", ".png")) and FFemcg("ffmpeg"):
      VVJ4QS.append(VV4c5n)
      VVJ4QS.append((color2 + "Convert to MVI (1280 x 720 )", "VVAPe4Hd"))
      VVJ4QS.append((color2 + "Convert to MVI (1920 x 1080)", "VVAPe4Fhd"))
    elif selFile.endswith(CCqXgM.VVduKk()):
     if selFile.endswith(".mvi"):
      if FFemcg("showiframe"):
       VVJ4QS.append(VV4c5n)
       VVJ4QS.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVJ4QS.append(VV4c5n)
      VVJ4QS.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVJ4QS.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
    if isText:
     VVJ4QS.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVJ4QS.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVJ4QS.append((color1 + "Convert Line-Breaks to Unix Format..." , "VV0069" ))
    if len(txt) > 0:
     VVJ4QS.append(VV4c5n)
     VVJ4QS.append((color1 + txt, "VVseIL"))
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append(("Create SymLink", "VVEeRN"))
   if not self.VVP6R1(path):
    VVJ4QS.append(("Rename"      , "VVYyun" ))
    VVJ4QS.append(("Copy"       , "copyFileOrDir" ))
    VVJ4QS.append(("Move"       , "moveFileOrDir" ))
    VVJ4QS.append((VVwmjQ + "DELETE" , "VVIq9p" ))
    if fileExists(path):
     VVJ4QS.append(VV4c5n)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVJ4QS.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVJ4QS.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVJ4QS.append((chmodTxt + "777)", "chmod777"))
   c = VVxpap
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append((c + "Create New File (in current directory)"  , "createNewFile" ))
   VVJ4QS.append((c + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCqXgM.VVsA5T(self)
   if fPath:
    VVJ4QS.append(VV4c5n)
    VVJ4QS.append((color2 + "Go to Current Movie Dir", "VVwqMc"))
   FFZP3S(self, self.VVSOwe, height=1050, title="Options", VVJ4QS=VVJ4QS, VV1Y9q="#00101020", VVMnLe="#00101A2A")
 def VVSOwe(self, item=None):
  if self.mode == self.VVDEbH:
   if item is not None:
    path = self.VVoWBh(self.VVi8BR())
    selFile = self.VVi8BR()
    if   item == "properties"    : self.VVuHEO()
    elif item == "VVGGiE_dir" : self.VVGGiE(path, True)
    elif item == "VVGGiE_file" : self.VVGGiE(path, False)
    elif item == "VVNpiw"  : self.VVNpiw(path)
    elif item == "VVTfCM"  : self.VVTfCM(path)
    elif item.startswith("extract_")  : self.VV1XfN(path, selFile, item)
    elif item.startswith("script_")   : self.VVTvEG(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVhbv9(path, selFile, item)
    elif item.startswith("textView_def") : FFFebl(self, path)
    elif item.startswith("textView_enc") : self.VV8s4d(path)
    elif item.startswith("text_Edit")  : FFlaBE(self, BF(CCbzSm, self, path), title="Opening File ...")
    elif item.startswith("textSave_encUtf8"): self.VVr79r(path, "Save as UTF-8"   , True)
    elif item.startswith("textSave_encOthr"): self.VVr79r(path, "Save as Other Encoding", False)
    elif item.startswith("VV0069") : self.VV0069(path)
    elif item == "viewAsBootlogo"   : self.VV0E4j(path, True)
    elif item == "addMovieToBouquet"  : self.VVOmtd(path, False)
    elif item == "addAllMoviesToBouquet" : self.VVOmtd(path, True)
    elif item == "VVAPe4Hd"   : FFlaBE(self, BF(self.VVAPe4, path, False))
    elif item == "VVAPe4Fhd"   : FFlaBE(self, BF(self.VVAPe4, path, True))
    elif item == "VVEeRN"   : self.VVEeRN(path, selFile)
    elif item == "VVYyun"   : self.VVYyun(path, selFile)
    elif item == "copyFileOrDir"   : self.VVq6Bm(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVq6Bm(path, selFile, True)
    elif item == "VVIq9p"   : self.VVIq9p(path, selFile)
    elif item == "chmod644"     : self.VVntXK(path, selFile, "644")
    elif item == "chmod755"     : self.VVntXK(path, selFile, "755")
    elif item == "chmod777"     : self.VVntXK(path, selFile, "777")
    elif item == "createNewFile"   : self.VVOp27(path, True)
    elif item == "createNewDir"    : self.VVOp27(path, False)
    elif item == "VVwqMc"   : self.VVwqMc()
    elif item == "VVseIL"    : self.VVseIL()
 def VVseIL(self):
  if self.mode == self.VVRct7:
   return
  selFile = self.VVi8BR()
  path  = self.VVoWBh(selFile)
  if os.path.isfile(path):
   VVe6kp  = []
   category = self["myMenu"].VVPqql(path)
   if   category == "pic"      : self.VVhZj2(path)
   elif category == "txt"      : FFFebl(self, path)
   elif category in ("tar", "zip", "rar")  : self.VVwknV(path, selFile)
   elif category == "scr"      : self.VVIXXV(path, selFile)
   elif category == "m3u"      : self.VVr4xo(path, selFile)
   elif category in ("ipk", "deb")    : self.VVpfT1(path, selFile)
   elif category in ("mov", "mus")    : self.VV0E4j(path)
   elif not CCqXgM.VVbo3a(path) : FFFebl(self, path)
 def VVhZj2(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VVPqql(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CCkc9M.VVthJo(self, path, fileList=lst, curIndex=curIndex)
 def VV0E4j(self, path, asLogo=False):
  if asLogo : CCaIeq.VVR3gv(self, path)
  else  : FFlaBE(self, BF(self.VVnUrp,self, path), title="Playing Media ...")
 def VVRoE8(self):
  if self["keyBlue"].getVisible():
   VVITUl = self.VVxKT6()
   if VVITUl:
    path = self.VVoWBh(self.VVi8BR())
    enableGreenBtn = False if path in self.VVxKT6() else True
    newList = []
    for line in VVITUl:
     newList.append((line, line))
    VVY1MF  = ("Delete"    , self.VVO3b6    )
    VV5lv1  = ("Add Current Dir"   , BF(self.VV6299, path) ) if enableGreenBtn else None
    VVU5gS = ("Move Up"     , self.VVCxqv    )
    VVaSnd  = ("Move Down"   , self.VVRlrp    )
    self.bookmarkMenu = FFZP3S(self, self.VVuZ1S, width=1200, title="Bookmarks", VVJ4QS=newList, minRows=10 ,VVY1MF=VVY1MF, VV5lv1=VV5lv1, VVU5gS=VVU5gS, VVaSnd=VVaSnd, VV1Y9q="#00000022", VVMnLe="#00000022")
 def VVO3b6(self, menuInstance=None, path=None):
  VVITUl = self.VVxKT6()
  if VVITUl:
   while path in VVITUl:
    VVITUl.remove(path)
   self.VVhNwp(VVITUl)
  if self.bookmarkMenu:
   self.bookmarkMenu.VVMK10(VVITUl)
   self.bookmarkMenu.VVmw8Q(("Add Current Dir", BF(self.VV6299, path)))
  else:
   FFHbVj(self, "Removed", 800)
  self.VVdWtx()
 def VV6299(self, path, menuInstance=None, item=None):
  VVITUl = self.VVxKT6()
  if len(VVITUl) >= self.VVgePW:
   FFfYN0(SELF, "Max bookmarks reached (max=%d)." % self.VVgePW)
  elif not path in VVITUl:
   newList = [path] + VVITUl
   self.VVhNwp(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VVMK10(newList)
    self.bookmarkMenu.VVmw8Q()
   else:
    FFHbVj(self, "Added", 800)
  self.VVdWtx()
 def VVCxqv(self, VVi8BRObj, path):
  if self.bookmarkMenu:
   VVITUl = self.bookmarkMenu.VVSogL(True)
   if VVITUl:
    self.VVhNwp(VVITUl)
 def VVRlrp(self, VVi8BRObj, path):
  if self.bookmarkMenu:
   VVITUl = self.bookmarkMenu.VVSogL(False)
   if VVITUl:
    self.VVhNwp(VVITUl)
 def VVuZ1S(self, folder=None):
  if folder:
   folder = FFegwS(folder)
   self["myMenu"].VV7Pcy(folder)
   self["myMenu"].moveToIndex(0)
  self.VV9nV9()
 def VVxKT6(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VVqm9N(self):
  return True if VVxKT6() else False
 def VVhNwp(self, VVITUl):
  line = ",".join(VVITUl)
  FFu7KK(CFG.browserBookmarks, line)
 def VVNkFl(self, path):
  if fileExists(path):
   fDir  = FFegwS(os.path.dirname(path))
   if fDir:
    self["myMenu"].VV7Pcy(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFHbVj(self, "Not found", 1000)
 def VVwqMc(self, chDir=True):
  fPath, fDir, fName = CCqXgM.VVsA5T(self)
  self.VVNkFl(fPath)
 def VVN1aD(self):
  path = self.VVoWBh(self.VVi8BR())
  isAdd = False if path in self.VVxKT6() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  VVJ4QS = []
  VVJ4QS.append(   ("Find Files ..."      , "find" ))
  VVJ4QS.append(   ("Sort ..."        , "sort" ))
  VVJ4QS.append(VV4c5n)
  if isAdd: VVJ4QS.append( ("Add %s Dir to Bookmarks" % dirTxt  , "addBM" ))
  else : VVJ4QS.append( ("Remove %s Dir from Bookmarks" % dirTxt, "remBM" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(   ('Set %s Dir as "Startup Dir"' % dirTxt , "start" ))
  FFZP3S(self, BF(self.VV1XG0, path), width=750, title="More Options", VVJ4QS=VVJ4QS, VV1Y9q="#00221111", VVMnLe="#00221111")
 def VV1XG0(self, path, item):
  if item:
   if   item == "find" : self.VVnZ09(path)
   elif item == "sort" : self.VV7QwN()
   elif item == "addBM": self.VV6299(path)
   elif item == "remBM": self.VVO3b6(None, path)
   elif item == "start": self.VV10kQ(path)
 def VVnZ09(self, path):
  VVJ4QS = []
  VVJ4QS.append(("Find in Current Directory"    , "findCur"  ))
  VVJ4QS.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVJ4QS.append(("Find in all Storage Systems"    , "findAll"  ))
  FFZP3S(self, BF(self.VVFubt, path), width=700, title="Find File/Pattern", VVJ4QS=VVJ4QS, VV7GES=True, VVbHGu=True, VV1Y9q="#00221111", VVMnLe="#00221111")
 def VVFubt(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VVUMuQ(0, path, title)
   elif item == "findCurR" : self.VVUMuQ(1, path, title)
   elif item == "findAll" : self.VVUMuQ(2, path, title)
 def VVUMuQ(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FFoW9P(self, BF(self.VVOhEn, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVOhEn(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FFu7KK(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FFHbVj(self, "No entery", 1500)
   elif badLst  : FFHbVj(self, "Too many file !", 1500)
   else   : FFlaBE(self, BF(self.VVGIQs, mode, path, title, filePatt), title="Searching ...", clearMsg=False)
 def VVGIQs(self, mode, path, title, filePatt):
  FFHbVj(self)
  lst = FFz7l2(FF0r54("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   if len(lst) == 1 and lst[0] == VVTzA8:
    FFfYN0(self, VVTzA8)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VVXuip = (""     , self.VVYD4C , [])
    VV7wPX = ("Go to File Location", self.VVBuq0  , [])
    FFA1pv(self, None, title="%s : %s" % (title, filePatt), header=header, VVITUl=lst, VV7ux5=widths, VVy2kz=26, VVXuip=VVXuip, VV7wPX=VV7wPX)
  else:
   FFHbVj(self, "Not found !", 2000)
 def VVBuq0(self, VVToDv, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVToDv.cancel()
   self.VVNkFl(path)
  else:
   FFHbVj(VVToDv, "Path not found !", 1000)
 def VVYD4C(self, VVToDv, title, txt, colList):
  txt = "%s\n%s\n\n" % (FFrGgO("File:"  , VVtSeQ), colList[0])
  txt += "%s\n%s"  % (FFrGgO("Directory:", VVtSeQ), FFegwS(colList[1]))
  FFCxQN(VVToDv, txt, title=title)
 def VV7QwN(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVAy2T()
  VVJ4QS = []
  VVJ4QS.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVJ4QS.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVJ4QS.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVJ4QS.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVaSnd = ("Mix", BF(self.VVI9GA, True))
  FFZP3S(self, BF(self.VVOep9, False), barText=txt, width=650, title="Sort Options", VVJ4QS=VVJ4QS, VVaSnd=VVaSnd, VVbHGu=True, VV1Y9q="#00221111", VVMnLe="#00221111")
 def VVI9GA(self, isMix, menuInstance, item):
  self.VVOep9(True, item)
 def VVOep9(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVAy2T()
   title = "Sorting ... "
   if   item == "nameAlp": FFlaBE(self, BF(self["myMenu"].VV844P, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FFlaBE(self, BF(self["myMenu"].VV844P, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FFlaBE(self, BF(self["myMenu"].VV844P, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FFlaBE(self, BF(self["myMenu"].VV844P, typeMode , isMix, False), title=title)
 def VV10kQ(self, path):
  if not os.path.isdir(path):
   path = FFxBb9(path, True)
  FFu7KK(CFG.browserStartPath, path)
  FFHbVj(self, "Done", 500)
 def VVzZtZ(self, selFile, VVgyFZ, command):
  FFZw7B(self, BF(FFyKCd, self, command, VV5en0=self.VV82Tk), "%s\n\n%s" % (VVgyFZ, selFile))
 def VVqQfc(self, path, calledFromMenu):
  destPath = self.VVxxqB(path)
  lastPart = FFbSa4(destPath)
  VVJ4QS = []
  if calledFromMenu:
   VVJ4QS.append(VV4c5n)
   color = VVtSeQ
  else:
   color = ""
  VVJ4QS.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVJ4QS.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVJ4QS.append((color + "Extract Here"            , "extract_here"  ))
  if iTar and iZip:
   if path.endswith(".zip"):
    if not calledFromMenu: VVJ4QS.append(VV4c5n)
    VVJ4QS.append((color + "Convert .zip to .tar.gz"       , "VVNpiw" ))
   elif path.endswith(".tar.gz"):
    if not calledFromMenu: VVJ4QS.append(VV4c5n)
    VVJ4QS.append((color + "Convert .tar.gz to .zip"       , "VVTfCM" ))
  return VVJ4QS
 def VVwknV(self, path, selFile):
  FFZP3S(self, BF(self.VV1XfN, path, selFile), title="Compressed File Options", VVJ4QS=self.VVqQfc(path, False))
 def VV1XfN(self, path, selFile, item=None):
  if item is not None:
   parent  = FFxBb9(path, False)
   destPath = self.VVxxqB(path)
   lastPart = FFbSa4(destPath)
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVU8ll
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFC4vV("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFC4vV("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVU8ll, VVU8ll)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFy4dI(self, cmd)
   elif path.endswith(".zip"):
    if item == "VVNpiw" : self.VVNpiw(path)
    else       : self.VVT11i(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "VVTfCM" and path.endswith(".tar.gz"):
    self.VVTfCM(path)
   elif path.endswith(".rar"):
    self.VVCRlR(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFyto6("mkdir '%s'"   % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVzZtZ(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVzZtZ(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FFxBb9(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVzZtZ(selFile, "Extract Here ?"      , cmd)
 def VVxxqB(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVT11i(self, item, path, parent, destPath, VVgyFZ):
  FFZw7B(self, BF(self.VVNSvT, item, path, parent, destPath), VVgyFZ)
 def VVNSvT(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVU8ll
  cmd  = FFC4vV("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFT6nF(destPath, VVqQXm))
  cmd +=   sep
  cmd += "fi;"
  FFH1sU(self, cmd, VV5en0=self.VV82Tk)
 def VVCRlR(self, item, path, parent, destPath, VVgyFZ):
  FFZw7B(self, BF(self.VVwdqZ, item, path, parent, destPath), VVgyFZ)
 def VVwdqZ(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFegwS(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVU8ll
  cmd  = FFC4vV("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFT6nF(destPath, VVqQXm))
  cmd +=   sep
  cmd += "fi;"
  FFH1sU(self, cmd, VV5en0=self.VV82Tk)
 def VVzSc7(self, addSep=False):
  VVJ4QS = []
  if addSep:
   VVJ4QS.append(VV4c5n)
  VVJ4QS.append((VVtSeQ + "View Script File"  , "script_View"  ))
  VVJ4QS.append((VVtSeQ + "Execute Script File" , "script_Execute" ))
  VVJ4QS.append((VVtSeQ + "Edit"     , "script_Edit" ))
  return VVJ4QS
 def VVIXXV(self, path, selFile):
  FFZP3S(self, BF(self.VVTvEG, path, selFile), title="Script File Options", VVJ4QS=self.VVzSc7())
 def VVTvEG(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFFebl(self, path)
   elif item == "script_Execute" : self.VVzZtZ(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCbzSm(self, path)
 def VVLJJw(self, addSep=False):
  VVJ4QS = []
  if addSep:
   VVJ4QS.append(VV4c5n)
  VVJ4QS.append((VVtSeQ + "Browse IPTV Channels"  , "m3u_Browse" ))
  VVJ4QS.append((VVtSeQ + "Edit"      , "m3u_Edit" ))
  VVJ4QS.append((VVtSeQ + "View"      , "m3u_View" ))
  return VVJ4QS
 def VVr4xo(self, path, selFile):
  FFZP3S(self, BF(self.VVhbv9, path, selFile), title="M3U/M3U8 File Options", VVJ4QS=self.VVLJJw())
 def VVhbv9(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFlaBE(self, BF(self.session.open, CCCwQV, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCbzSm(self, path)
   elif item == "m3u_View"  : FFFebl(self, path)
 def VV8s4d(self, path):
  if fileExists(path) : FFlaBE(self, BF(CC7qa7.VVkIl0, self, path, BF(self.VVFdjR, path)), title="Loading Codecs ...", clearMsg=False)
  else    : FF6vdZ(self, path)
 def VVFdjR(self, path, item=None):
  if item:
   FFFebl(self, path, encLst=item)
 def VVr79r(self, path, title, asUtf8):
  if fileExists(path) : FFlaBE(self, BF(CC7qa7.VVkIl0, self, path, BF(self.VVEA5K, path, title, asUtf8), title="Original Encoding"), clearMsg=False, title="Loading Codecs ...")
  else    : FF6vdZ(self, path)
 def VVEA5K(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8 : self.VV0Udu(path, title, fromEnc, "UTF-8")
   else  : CC7qa7.VVkIl0(self, path,  BF(self.VV0Udu, path, title, fromEnc), onlyWorkingEnc=False, title="Convert to Encoding")
 def VV0Udu(self, path, title, fromEnc, toEnc):
  if toEnc:
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FFrGgO("Successful\n\n", VVqQXm)
      txt += FFrGgO("From Encoding (%s):\n" % fromEnc, VVy0iZ)
      txt += "%s\n\n" % path
      txt += FFrGgO("To Encoding (%s):\n" % toEnc, VVy0iZ)
      txt += "%s\n\n" % outFile
      FFCxQN(self, txt, title=title)
    except:
     FFfYN0(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FFHbVj(self, "Cannot open file", 2000)
  self.VV82Tk()
 def VV0069(self, path):
  title = "File Line-Break Conversion"
  FFZw7B(self, BF(self.VVf8iE, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVf8iE(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FFrGgO("File converted:", VVqQXm), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FF8O6K(self, txt, title=title)
  else:
   FF6vdZ(self, path, title=title)
 def VVntXK(self, path, selFile, newChmod):
  FFZw7B(self, BF(self.VVddYV, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVddYV(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVU0Ra)
  result = FFIgoM(cmd)
  if result == "Successful" : FF8O6K(self, result)
  else      : FFfYN0(self, result)
 def VVEeRN(self, path, selFile):
  parent = FFxBb9(path, False)
  self.session.openWithCallback(self.VVKp90, BF(CCqXgM, mode=CCqXgM.VViiv3, VVjq2g=parent, VVc6q2="Create Symlink here"))
 def VVKp90(self, newPath):
  if len(newPath) > 0:
   target = self.VVoWBh(self.VVi8BR())
   target = FFFTbs(target)
   linkName = FFbSa4(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFegwS(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFfYN0(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFZw7B(self, BF(self.VVzy4H, target, link), "Create Soft Link ?\n\n%s" % txt, VV5RdC=True)
 def VVzy4H(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVU0Ra)
  result = FFIgoM(cmd)
  if result == "Successful" : FF8O6K(self, result)
  else      : FFfYN0(self, result)
 def VVYyun(self, path, selFile):
  lastPart = FFbSa4(path)
  FFoW9P(self, BF(self.VV1axq, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VV1axq(self, path, selFile, VVRnvB):
  if VVRnvB:
   parent = FFxBb9(path, True)
   if os.path.isdir(path):
    path = FFFTbs(path)
   newName = parent + VVRnvB
   cmd = "mv '%s' '%s' %s" % (path, newName, VVU0Ra)
   if VVRnvB:
    if selFile != VVRnvB:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFZw7B(self, BF(self.VVNU4z, cmd), message, title="Rename file?")
    else:
     FFfYN0(self, "Cannot use same name!", title="Rename")
 def VVNU4z(self, cmd):
  result = FFIgoM(cmd)
  if "Fail" in result:
   FFfYN0(self, result)
  self.VV82Tk()
 def VVq6Bm(self, path, selFile, isMove):
  if isMove : VVc6q2 = "Move to here"
  else  : VVc6q2 = "Paste here"
  parent = FFxBb9(path, False)
  self.session.openWithCallback(BF(self.VVqLiv, isMove, path, selFile)
         , BF(CCqXgM, mode=CCqXgM.VViiv3, VVjq2g=parent, VVc6q2=VVc6q2))
 def VVqLiv(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = FFbSa4(path)
   if os.path.isdir(path):
    path = FFFTbs(path)
   newPath = FFegwS(newPath)
   dest = newPath + lastPart
   if os.path.isdir(path) and os.path.isdir(dest):
    if isMove:
     FFfYN0(self, 'Same directory already exists:\n\n%s\n\n( Try to copy then delete the source )' % dest)
     return
    else:
     dest = newPath
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFZw7B(self, BF(FFJWo9, self, cmd, VV5en0=self.VV82Tk), txt, VV5RdC=True)
   else:
    FFfYN0(self, "Cannot %s to same directory !" % action.lower())
 def VVIq9p(self, path, fileName):
  path = FFFTbs(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFZw7B(self, BF(self.VVXMzn, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVXMzn(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VV82Tk()
 def VVP6R1(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVtMJJ and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVOp27(self, path, isFile):
  dirName = FFegwS(os.path.dirname(path))
  if isFile : objName, VVRnvB = "File"  , self.edited_newFile
  else  : objName, VVRnvB = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFoW9P(self, BF(self.VVMrGJ, dirName, isFile, title), title=title, defaultText=VVRnvB, message="Enter %s Name:" % objName)
 def VVMrGJ(self, dirName, isFile, title, VVRnvB):
  if VVRnvB:
   if isFile : self.edited_newFile = VVRnvB
   else  : self.edited_newDir  = VVRnvB
   path = dirName + VVRnvB
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVU0Ra)
    else  : cmd = "mkdir '%s' %s" % (path, VVU0Ra)
    result = FFIgoM(cmd)
    if "Fail" in result:
     FFfYN0(self, result)
    self.VV82Tk()
   else:
    FFfYN0(self, "Name already exists !\n\n%s" % path, title)
 def VVpfT1(self, path, selFile):
  c1, c2, c3 = VV6svy, VVtSeQ, VV61Yf
  VVJ4QS = []
  VVJ4QS.append((c1 + "List Package Files"         , "VVLgBr"     ))
  VVJ4QS.append((c1 + "Package Information"         , "VVTy7q"     ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append((c2 + "Install Package"          , "VVbKt4_CheckVersion" ))
  VVJ4QS.append((c2 + "Install Package (force reinstall)"     , "VVbKt4_ForceReinstall" ))
  VVJ4QS.append((c2 + "Install Package (force overwrite)"     , "VVbKt4_ForceOverwrite" ))
  VVJ4QS.append((c2 + "Install Package (force downgrade)"     , "VVbKt4_ForceDowngrade" ))
  VVJ4QS.append((c2 + "Install Package (ignore failed dependencies)"  , "VVbKt4_IgnoreDepends" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append((c3 + "Remove Related Package"        , "VVOTBY_ExistingPackage" ))
  VVJ4QS.append((c3 + "Remove Related Package (force remove)"    , "VVOTBY_ForceRemove"  ))
  VVJ4QS.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VVOTBY_IgnoreDepends" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Extract Files"           , "VVZtLA"     ))
  VVJ4QS.append(("Unbuild Package"           , "VV8juc"     ))
  FFZP3S(self, BF(self.VVyYXR, path, selFile), VVJ4QS=VVJ4QS)
 def VVyYXR(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVLgBr"      : self.VVLgBr(path, selFile)
   elif item == "VVTy7q"      : self.VVTy7q(path)
   elif item == "VVbKt4_CheckVersion"  : self.VVbKt4(path, selFile, VVi1jL     )
   elif item == "VVbKt4_ForceReinstall" : self.VVbKt4(path, selFile, VVgRg8 )
   elif item == "VVbKt4_ForceOverwrite" : self.VVbKt4(path, selFile, VVwcQY )
   elif item == "VVbKt4_ForceDowngrade" : self.VVbKt4(path, selFile, VVujU7 )
   elif item == "VVbKt4_IgnoreDepends" : self.VVbKt4(path, selFile, VVFaXR )
   elif item == "VVOTBY_ExistingPackage" : self.VVOTBY(path, selFile, VVnArD     )
   elif item == "VVOTBY_ForceRemove"  : self.VVOTBY(path, selFile, VVunnv  )
   elif item == "VVOTBY_IgnoreDepends"  : self.VVOTBY(path, selFile, VVmQkd )
   elif item == "VVZtLA"     : self.VVZtLA(path, selFile)
   elif item == "VV8juc"     : self.VV8juc(path, selFile)
   else           : self.close()
 def VVLgBr(self, path, selFile):
  if FFemcg("ar") : cmd = "allOK='1';"
  else    : cmd  = FFF2ep()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVU8ll, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVU8ll, VVU8ll)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FF3qwl(self, cmd, VV5en0=self.VV82Tk)
 def VVZtLA(self, path, selFile):
  lastPart = FFbSa4(path)
  dest  = FFxBb9(path, True) + selFile[:-4]
  cmd  =  FFF2ep()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFyto6("mkdir '%s'" % dest) + ";"
  cmd +=    FFyto6("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFT6nF(dest, VVqQXm))
  cmd += "fi;"
  FFyKCd(self, cmd, VV5en0=self.VV82Tk)
 def VV8juc(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVoH5O = os.path.splitext(path)[0]
  else        : VVoH5O = path + "_"
  if path.endswith(".deb")   : VVUlDU = "DEBIAN"
  else        : VVUlDU = "CONTROL"
  cmd  = FFF2ep()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVoH5O, FFP76l())
  cmd += "  mkdir '%s';"    % VVoH5O
  cmd += "  CONTPATH='%s/%s';"  % (VVoH5O, VVUlDU)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVoH5O
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVoH5O, VVoH5O)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVoH5O
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVoH5O, VVoH5O)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVoH5O
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVoH5O
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVoH5O, FFT6nF(VVoH5O, VVqQXm))
  cmd += "fi;"
  FFyKCd(self, cmd, VV5en0=self.VV82Tk)
 def VVTy7q(self, path):
  listCmd  = FFFOwQ(VV6nhb, "")
  infoCmd  = FFMotr(VVlKhU , "")
  filesCmd = FFMotr(VV1iyq, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFGsQg(VVy0iZ)
   notInst = "Package not installed."
   cmd  = FFAR3g("File Info", VVy0iZ)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFAR3g("System Info", VVy0iZ)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFT6nF(notInst, VVFBP5))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFAR3g("Related Files", VVy0iZ)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFy4dI(self, cmd)
  else:
   FF1KkZ(self)
 def VVbKt4(self, path, selFile, cmdOpt):
  cmd = FFMotr(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFZw7B(self, BF(FFyKCd, self, cmd, VV5en0=FFKjU2), "Install Package ?\n\n%s" % selFile)
  else:
   FF1KkZ(self)
 def VVOTBY(self, path, selFile, cmdOpt):
  listCmd  = FFFOwQ(VV6nhb, "")
  infoCmd  = FFMotr(VVlKhU, "")
  instRemCmd = FFMotr(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFT6nF(errTxt, VVFBP5))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFT6nF(cannotTxt, VVFBP5))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFT6nF(tryTxt, VVFBP5))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFZw7B(self, BF(FFyKCd, self, cmd, VV5en0=FFKjU2), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FF1KkZ(self)
 def VVa1fU(self, path):
  hostName = FFIgoM("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVGGiE(self, path, isDir):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVJ4QS = []
  VVJ4QS.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVJ4QS.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVJ4QS.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVJ4QS.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVJ4QS.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVJ4QS.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVJ4QS.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVJ4QS.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVJ4QS.append(("%s.zip"  % Path   , "archPath_zip"  ))
  if isDir:
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append(('Convert to ".ipk" Package' , "convertDirToIpk" ))
   VVJ4QS.append(('Convert to ".deb" Package' , "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFZP3S(self, BF(self.VVS6Eh, path, isDir, title), VVJ4QS=VVJ4QS, title=title, VV1Y9q=c1, VVMnLe=c2)
 def VVS6Eh(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVAKZc(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz"   : self.VVAKZc(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVAKZc(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVAKZc(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"    : self.VVAKZc(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"    : self.VVAKZc(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz"   : self.VVAKZc(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVAKZc(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVAKZc(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"    : self.VVAKZc(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk"   : self.VVsGoP(path, False)
   elif item == "convertDirToDeb"   : self.VVsGoP(path, True)
   else         : self.close()
 def VVsGoP(self, path, VVZWSD):
  self.session.openWithCallback(self.VV82Tk, BF(CCcPEE, path=path, VVZWSD=VVZWSD))
 def VVAKZc(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FFxBb9(path, True)
  lastPart = FFbSa4(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFC4vV("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFC4vV("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFC4vV("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVU8ll
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFyto6("rm -f '%s'" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFT6nF(failed, VVPUgM))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFT6nF(srcTxt, VVE6YJ))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFT6nF("Output", VVqQXm))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFT6nF(failed, VVwmjQ))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FF3qwl(self, cmd, VV5en0=self.VV82Tk, title=title)
 def VVOmtd(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CCqXgM.VV0VUU(FFxBb9(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CC54zE(self, self, title, BF(self.VVJv42, pathLst))
 def VVJv42(self, pathLst):
  return CC54zE.VV1axl(pathLst)
 def VVNpiw(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VVNyK3, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFZw7B(self, BF(FFlaBE, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFlaBE(self, fnc, title=txt)
  else:
   FFfYN0(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VVNyK3(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, 'w:gz') as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFCxQN(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VV82Tk()
  else:
   FFM75P(tarPath)
   FFfYN0(self, "Error while converting.", title=title)
 def VVTfCM(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVrkDL, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFZw7B(self, BF(FFlaBE, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFlaBE(self, fnc, title=txt)
  else:
   FFfYN0(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVrkDL(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFCxQN(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VV82Tk()
  else:
   FFM75P(zipPath)
   FFfYN0(self, "Error while converting.", title=title)
 def VVAPe4(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FFegwS(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  os.system(FFyto6("rm -f '%s' '%s'" % (m1v, mvi)))
  res = os.system(FFyto6("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)))
  if res == 0 and fileExists(m1v):
   res = os.system(FFyto6("mv -f '%s' '%s'" % (m1v, mvi)))
   self.VV82Tk()
   FF8O6K(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FFfYN0(self, "Cannot convert this file !", title=title)
 @staticmethod
 def VVnUrp(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCKx3s.VVpa1E(SELF.session, enableZapping= False, enableDownloadMenu=False, enableOpenInFMan=False)
  except:
   pass
 @staticmethod
 def VVsA5T(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFegwS(fDir), fName
  return "", "", ""
 @staticmethod
 def VVW9Yx(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVRyP5(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VV4m3L(size, mode=0):
  txt = CCqXgM.VVI2AD(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVI2AD(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VVbo3a(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VV7Hvo(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FFfYN0(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VVduKk():
  tDict = CCGzH5.VVQ3D5()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VV0VUU(path):
  lst = []
  for ext in CCqXgM.VVduKk():
   lst.extend(FFQ9JP(path, "*.%s" % ext))
  return sorted(lst, key=FF0Q8q(FFmcic))
 @staticmethod
 def VV7Sv5(path):
  res = os.system("tar -tzf '%s' >/dev/null" % path)
  return res == 0
 @staticmethod
 def VVwibR(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
class CCGzH5(MenuList):
 VVaURo  = 0
 VVRFRd  = 1
 VVd5SH  = 2
 VVKrsN  = 3
 VVDJ2N  = 4
 VViBqD  = 5
 VVYYBU  = 6
 VV2rjU  = 7
 VVqHWs  = "<List of Storage Devices>"
 VV1U2p = "<Parent Directory>"
 def __init__(self, VVzjtd=False, directory="/", VVlKSN=True, VV5jbE=True, VVXmPK=True, VVIlzS=None, VVjPEV=False, VV2P9Z=False, VVSVkW=False, isTop=False, VVgAUF=None, VVFKGn=1000, VVy2kz=30, VVkXuR=30, VV3GoA="#00000000", pngBGColorSelStr="#06003333"):
  MenuList.__init__(self, list, VVzjtd, eListboxPythonMultiContent)
  self.VVlKSN  = VVlKSN
  self.VV5jbE    = VV5jbE
  self.VVXmPK  = VVXmPK
  self.VVIlzS  = VVIlzS
  self.VVjPEV   = VVjPEV
  self.VV2P9Z   = VV2P9Z or []
  self.VVSVkW   = VVSVkW or []
  self.isTop     = isTop
  self.additional_extensions = VVgAUF
  self.VVFKGn    = VVFKGn
  self.VVy2kz    = VVy2kz
  self.VVkXuR    = VVkXuR
  self.pngBGColor    = FFyhto(VV3GoA)
  self.pngBGColorSel   = FFyhto(pngBGColorSelStr)
  self.EXTENSIONS    = CCGzH5.VVQ3D5()
  self.VVKzVO   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.l.setFont(0, gFont(VVdbIk, self.VVy2kz))
  self.l.setItemHeight(self.VVkXuR)
  self.png_mem   = self.VV89tQ("mem")
  self.png_usb   = self.VV89tQ("usb")
  self.png_fil   = self.VV89tQ("fil")
  self.png_dir   = self.VV89tQ("dir")
  self.png_dirup   = self.VV89tQ("dirup")
  self.png_srv   = self.VV89tQ("srv")
  self.png_slwfil   = self.VV89tQ("slwfil")
  self.png_slbfil   = self.VV89tQ("slbfil")
  self.png_slwdir   = self.VV89tQ("slwdir")
  self.VVxfdv()
  self.VV7Pcy(directory)
 def VV89tQ(self, category):
  return LoadPixmap("%s%s.png" % (VVnEh8, category), getDesktop(0))
 @staticmethod
 def VVQ3D5():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVUE3P(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFFTbs(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFrGgO(" -> " , VVy0iZ) + FFrGgO(os.readlink(path), VVqQXm)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVkXuR + 10, 0, self.VVFKGn, self.VVkXuR, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VV0xHX: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVkXuR-4, self.VVkXuR-4, png, self.pngBGColor, self.pngBGColorSel, VV0xHX))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVkXuR-4, self.VVkXuR-4, png, self.pngBGColor, self.pngBGColorSel))
  return tableRow
 def VVPqql(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVxfdv(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VVngYk(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVbNlH(self, file):
  if os.path.realpath(file) == file:
   return self.VVngYk(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVngYk(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVngYk(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVJSfE(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVKzVO.info(l[0][0]).getEvent(l[0][0])
 def VVST0Z(self):
  return self.list
 def VVMUAc(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VV7Pcy(self, directory, select = None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VVXmPK:
    self.current_mountpoint = self.VVbNlH(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VVXmPK:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVSVkW and not self.VVMUAc(path, self.VV2P9Z):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVUE3P(name=p.description, absolute=path, isDir=True, png=png))
    path = "/"
    if path not in self.VVSVkW and not self.VVMUAc(path, self.VV2P9Z):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVUE3P(name="INTERNAL FLASH", absolute="/", isDir=True, png=self.png_mem))
  elif self.VVjPEV:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVKzVO = eServiceCenter.getInstance()
   list = VVKzVO.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVlKSN and not self.isTop:
   if directory == self.current_mountpoint and self.VVXmPK:
    self.list.append(self.VVUE3P(name=self.VVqHWs, absolute=None, isDir=True, png=self.png_dirup))
   elif (directory != "/") and not (self.VVSVkW and self.VVngYk(directory) in self.VVSVkW):
    self.list.append(self.VVUE3P(name=self.VV1U2p, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, png=self.png_dirup))
  if self.VVlKSN:
   for x in directories:
    if not (self.VVSVkW and self.VVngYk(x) in self.VVSVkW) and not self.VVMUAc(x, self.VV2P9Z):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVUE3P(name=name, absolute=x, isDir=True, png=png))
  if self.VV5jbE:
   for x in files:
    if self.VVjPEV:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFrGgO(" -> " , VVy0iZ) + FFrGgO(target, VVqQXm)
       else:
        png = self.png_slbfil
        name += FFrGgO(" -> " , VVy0iZ) + FFrGgO(target, VVwmjQ)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVPqql(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVnEh8, category))
    if (self.VVIlzS is None) or iCompile(self.VVIlzS).search(path):
     self.list.append(self.VVUE3P(name=name, absolute=x , isDir=False, png=png))
  if self.VVXmPK and len(self.list) == 0:
   self.list.append(self.VVUE3P(name=FFrGgO("No USB connected", VVyLoh), absolute=None, isDir=False, png=self.png_usb))
  self.l.setList(self.list)
  self.VV844P()
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVWQbR(self):
  return self.current_directory
 def VVE1SB(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VVnyHl(self):
  return self.VVFt8E() and self.VVWQbR()
 def VVFt8E(self):
  return self.list[0][1][7] in (self.VVqHWs, self.VV1U2p)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VV7Pcy(self.getSelection()[0], select = self.current_directory)
 def VVYRgy(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVzZnG(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVARVf)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVARVf)
 def refresh(self):
  self.VV7Pcy(self.current_directory, self.VVYRgy())
 def VVARVf(self, action, device):
  self.VVxfdv()
  if self.current_directory is None:
   self.refresh()
 def VVAy2T(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVaURo : nameAlpMode, nameAlpTxt = self.VVRFRd, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVaURo, sAZ
  if mode == self.VVd5SH : nameNumMode, nameNumTxt = self.VVKrsN, s90
  else       : nameNumMode, nameNumTxt = self.VVd5SH, s09
  if mode == self.VVDJ2N : dateMode, dateTxt = self.VViBqD, sON
  else       : dateMode, dateTxt = self.VVDJ2N, sNO
  if mode == self.VVYYBU : typeMode, typeTxt = self.VV2rjU, sZA
  else       : typeMode, typeTxt = self.VVYYBU, sAZ
  if   mode in (self.VVaURo, self.VVRFRd): txt = "Name (%s)" % (sAZ if mode == self.VVaURo else sZA)
  elif mode in (self.VVd5SH, self.VVKrsN): txt = "Name (%s)" % (s09 if mode == self.VVaURo else s90)
  elif mode in (self.VVDJ2N, self.VViBqD): txt = "Date (%s)" % (sNO if mode == self.VVDJ2N else sON)
  elif mode in (self.VVYYBU, self.VV2rjU): txt = "Type (%s)" % (sAZ if mode == self.VVYYBU else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VV844P(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FFu7KK(CFG.browserSortMode, mode)
   FFu7KK(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVFt8E() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVaURo, self.VVRFRd):
    rev = True if mode == self.VVRFRd else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVd5SH, self.VVKrsN):
    rev = True if mode == self.VVKrsN else False
    self.list = sorted(self.list[item0:], key=FF0Q8q(BF(self.VVqbMC, isMix, rev)), reverse=rev)
   elif mode in (self.VVDJ2N, self.VViBqD):
    rev = True if mode == self.VViBqD else False
    self.list = sorted(self.list[item0:], key=FF0Q8q(BF(self.VVXRod, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VV2rjU else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VVqbMC(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FFmcic(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FF1xYR(dir2, dir1) or FFmcic(name1, name2)
 def VVXRod(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FF1xYR(stat2.st_ctime, stat1.st_ctime)
    else : return FF1xYR(dir2, dir1) or FF1xYR(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CCSXlr(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FFNQkv(VViXrc, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVITUl   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVLjv7(defFG, "#00FFFFFF")
  self.defBG   = self.VVLjv7(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFVOCw(self, self.Title)
  self["keyRed"].show()
  FFdufS(self["keyGreen"] , "< > Transp.")
  FFdufS(self["keyYellow"], "Foreground")
  FFdufS(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVdH37     ,
   "green"   : self.VVdH37     ,
   "yellow"  : BF(self.VVoz3Q, False)  ,
   "blue"   : BF(self.VVoz3Q, True)  ,
   "up"   : self.VVcoOu       ,
   "down"   : self.VV153S      ,
   "left"   : self.VVsfLd      ,
   "right"   : self.VVB1TT      ,
   "last"   : BF(self.VVnPme, -5) ,
   "next"   : BF(self.VVnPme, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VV47vn)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFg8wK(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFg8wK(self["keyRed"] , c)
  FFg8wK(self["keyGreen"] , c)
  self.VViFfG()
  self.VVuCY6()
  FFq6y3(self["myColorTst"], self.defFG)
  FFg8wK(self["myColorTst"], self.defBG)
 def VVLjv7(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVuCY6(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVpqR2(0, 0)
     return
 def VVdH37(self):
  self.close(self.defFG, self.defBG)
 def VVcoOu(self): self.VVpqR2(-1, 0)
 def VV153S(self): self.VVpqR2(1, 0)
 def VVsfLd(self): self.VVpqR2(0, -1)
 def VVB1TT(self): self.VVpqR2(0, 1)
 def VVpqR2(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVFmOF()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVcP8d()
 def VViFfG(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVcP8d(self):
  color = self.VVFmOF()
  if self.isBgMode: FFg8wK(self["myColorTst"], color)
  else   : FFq6y3(self["myColorTst"], color)
 def VVoz3Q(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VViFfG()
   self.VVuCY6()
 def VVnPme(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVpqR2(0, 0)
 def VVloyL(self):
  return hex(self.transp)[2:].zfill(2)
 def VVFmOF(self):
  return ("#%s%s" % (self.VVloyL(), self.colors[self.curRow][self.curCol])).upper()
class CCaiob(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFNQkv(VVXKIb, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FFVOCw(self, title="%s%s%s" % (self.Title, " " * 10, FFrGgO("Change values with Up , Down, < , 0 , >", VVyLoh)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVfFPM      ,
   "cancel" : self.VVTRM1      ,
   "info"  : self.VVC4Nc    ,
   "red"  : self.VV3Ug9  ,
   "green"  : self.VVAqCj   ,
   "yellow" : BF(self.VVZPRu, 0)  ,
   "blue"  : self.VVdaH6    ,
   "menu"  : self.VVYCMq      ,
   "left"  : self.VVsfLd      ,
   "right"  : self.VVB1TT      ,
   "last"  : self.VVguaW     ,
   "next"  : self.VV11Rv     ,
   "0"   : self.VVBbX0    ,
   "up"  : self.VVcoOu       ,
   "down"  : self.VV153S      ,
   "pageUp" : BF(self.VVbAzu, True) ,
   "pageDown" : BF(self.VVbAzu, False) ,
   "chanUp" : BF(self.VVbAzu, True) ,
   "chanDown" : BF(self.VVbAzu, False) ,
   "play"  : BF(self.VVHmpn, "pause")  ,
   "pause"  : BF(self.VVHmpn, "pause")  ,
   "playPause" : BF(self.VVHmpn, "pause")  ,
   "stop"  : BF(self.VVHmpn, "pause")  ,
   "audio"  : BF(self.VVHmpn, "audio")  ,
   "subtitle" : BF(self.VVHmpn, "subtitle") ,
   "rewind" : BF(self.VVHmpn, "rewind" ) ,
   "forward" : BF(self.VVHmpn, "forward" ) ,
   "rewindDm" : BF(self.VVHmpn, "rewindDm") ,
   "forwardDm" : BF(self.VVHmpn, "forwardDm")
  }, -1)
  self.VVSx10()
  self.onShown.append(self.VV47vn)
  self.onClose.append(self.VVIpBx)
 def VVSx10(self):
  lst = []
  for fil in FFQ9JP(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VVhadi:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VV47vn(self):
  self.onShown.remove(self.VV47vn)
  FFeAg3(self)
  FFABOX(self)
  for i in range(3):
   self["mySubt%d" % i].instance.setNoWrap(True)
   self["mySubt%d" % i].hide()
  self.VV8P4i()
  self.VVlDfK()
  self.VVABhY()
 def VVIpBx(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VV6LbX(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FFg8wK(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VVD9dk()
 def VV8P4i(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FFg8wK(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VVfFPM(self):
  if self.settingShown:
   confItem = self.VVDuik()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVJ4QS = []
   if isinstance(lst[0], tuple):
    for item in lst: VVJ4QS.append((item[1], item[0]))
   else:
    for item in lst: VVJ4QS.append((item, item))
   menuInstance = FFZP3S(self, self.VVVizx, VVJ4QS=VVJ4QS, width=700, title=title, VV1Y9q="#33221111", VVMnLe="#33110011")
   menuInstance.VVeAOS(confItem.getIndex())
  else:
   self.close("subtExit")
 def VVVizx(self, item=None):
  if item:
   self.VVDuik()[self.CursorPos].setValue(item)
   self.VVD9dk()
   self.VVlDfK()
   self.VVJjqF(True)
 def VVTRM1(self):
  for confItem in self.VVDuik():
   if confItem.isChanged():
    FFZw7B(self, self.VVZ9sN, "Save Changes ?", callBack_No=self.VVbdmQ, title=self.Title)
    break
  else:
   if self.settingShown: self.VV8P4i()
   else    : self.close("subtExit")
 def VVYCMq(self):
  if self.settingShown: self.VVQjbu()
  else    : self.VV6LbX()
 def VVsfLd(self): self.VVpdL2(-1)
 def VVB1TT(self): self.VVpdL2(1)
 def VVpdL2(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VV5wBd()
   if pos == -1: ndx = self.VViI94(posVal)
   else  : ndx = self.VV8Hy0(posVal)
   if   ndx < 0      : FFHbVj(self, "Not found" , 500)
   elif ndx == 0      : FFHbVj(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FFHbVj(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVqgTw(frmSec)
    if allow:
     self.VVZPRu(delay, True)
     self.VVJjqF(force=True)
    else:
     FFHbVj(self, "Delay out of range", 800)
 def VVbAzu(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VVHmpn(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVguaW(self) : self.VVwiFZ(5)
 def VV11Rv(self) : self.VVwiFZ(6)
 def VVBbX0(self) : self.VVwiFZ(-1)
 def VVcoOu(self):
  if self.settingShown: self.VVwiFZ(1)
  else    : self.VVbAzu(True)
 def VV153S(self):
  if self.settingShown: self.VVwiFZ(0)
  else    : self.VVbAzu(False)
 def VVwiFZ(self, direction):
  if self.settingShown:
   confItem = self.VVDuik()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VVD9dk()
   self.VVlDfK()
   self.VVJjqF(True)
 def VVDuik(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VVbdmQ(self):
  for confItem in self.VVDuik(): confItem.cancel()
  self.VVD9dk()
  self.VVlDfK()
  self.VV8P4i()
 def VV3Ug9(self):
  if self.settingShown:
   FFZw7B(self, self.VV7lcZ, "Reset Subtitle Settings to default ?", title=self.Title)
 def VV7lcZ(self):
  for confItem in self.VVDuik(): confItem.setValue(confItem.default)
  self.VVZ9sN()
  self.VVD9dk()
  self.VVlDfK()
 def VVZPRu(self, delay, force=False):
  if self.settingShown or force:
   FFu7KK(CFG.subtDelaySec, delay)
   self.VVc3Yj()
   self.VVD9dk()
   self.VVlDfK()
   if self.settingShown:
    FFHbVj(self, 'Reset to "0"', 800, isGrn=True)
 def VVAqCj(self):
  if self.settingShown:
   self.VVZ9sN()
   self.VV8P4i()
 def VVZ9sN(self):
  for confItem in self.VVDuik(): confItem.save()
  configfile.save()
  self.VVc3Yj()
  FFHbVj(self, "Saved", 1000, isGrn=True)
 def VVD9dk(self):
  cfgLst = self.VVDuik()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VVlDfK(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FFV9L6(path, fnt, isRepl=1)
  else:
   fnt = VVdbIk
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFWAiI(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFq6y3(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FFg8wK(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    inst.setNoWrap(True)
    lineH = FFbwug(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFWAiI(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFerEQ()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  boxFSize = self["myInfoFrame"].instance.size()
  boxSize  = self["myInfoBody"].instance.size()
  self["myInfoFrame"].instance.move(ePoint(int((winW - boxFSize.width()) // 2), int((winH - boxFSize.height()) // 2)))
  self["myInfoBody"].instance.move(ePoint(int((winW - boxSize.width()) // 2) , int((winH - boxSize.height()) // 2)))
 def VVC4Nc(self):
  sp = "    "
  txt  = "%s\n"   % FFrGgO("Subtitle File:", VVtSeQ)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FFrGgO("Subtitle Settings:", VVtSeQ)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VV5wBd()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FFxB2b(frmSec1)
   time2 = FFxB2b(toSec2)
   txt += "\n"
   txt += "%s\n"       % FFrGgO("Timing:", VVtSeQ)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FFxB2b(durVal)
   txt += sp + "Progress\t: %s\n" % FFxB2b(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FFrGgO("Subtitle end reached.", VVPUgM)
  FFCxQN(self, txt, title="Current Subtitle")
 def VVABhY(self, path="", delay=0, enc=""):
  FFlaBE(self, BF(self.VVjCWT, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VVjCWT(self, path="", delay=0, enc=""):
  FFHbVj(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVmksa(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VVD9dk()
     self.VVCi1Q()
   else:
    path, delay, enc = CCaiob.VV4HrE(self)
    if path:
     self.VVABhY(path=path, delay=delay, enc=enc)
    else:
     self.VVQjbu()
  except:
   pass
 def VVCi1Q(self):
  posVal, durVal = self.VV5wBd()
  if self.VV589U(posVal):
   return
  CCaiob.VVkDWo(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVJjqF)
  except:
   self.timerUpdate.callback.append(self.VVJjqF)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVEW6p)
  except:
   self.timerEndText.callback.append(self.VVEW6p)
  FFHbVj(self, "Subtitle started", 700, isGrn=True)
 def VV589U(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CCaiob.VVIXoE(self)
   FFM75P(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VVQjbu(self):
  c1, c2, c3, c4, c5 = "", VVtSeQ, VVxpap, VV61Yf, VVPUgM
  VVJ4QS = []
  VVJ4QS.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVJ4QS.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVJ4QS.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVJ4QS.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVJ4QS.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append(("Help (Keys)"        , "help"  ))
  FFZP3S(self, self.VVtcWU, VVJ4QS=VVJ4QS, width=700, title='Find Subtitle ".srt" File', VV1Y9q="#33221111", VVMnLe="#33110011")
 def VVtcWU(self, item=None):
  if item:
   if   item == "allSrt"   : self.VVlFxF(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VVlFxF(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    dir1 = CFG.lastFileManFindSrt.getValue()
    dir2 = CFG.MovieDownloadPath.getValue()
    sDir = "/"
    for path in (dir1, dir2, "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VVn4vi, BF(CCqXgM, mode=CCqXgM.VVRct7, VVjq2g=sDir))
   elif item.startswith("sugSrt") : self.VVlFxF(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FFlaBE(self, BF(CC7qa7.VVkIl0, self, self.lastSubtFile, self.VVc4ev, defEnc=self.lastSubtEnc), title="Loading Codecs ...", clearMsg=False)
    else             : FFHbVj(self, "SRT File error", 1000)
   elif item == "disab":
    FFM75P(CCaiob.VVIXoE(self))
    self.close("subtExit")
   elif item == "help"    : FFrc1O(self, VVnEh8 + "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VVc4ev(self, item=None):
  if item:
   FFlaBE(self, BF(self.VVABhY, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VVn4vi(self, path):
  if path:
   FFu7KK(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VVABhY(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VVlFxF(self, defSrt="", mode=0, coeff=0.25):
  FFlaBE(self, BF(self.VVW1lA, defSrt, mode=mode, coeff=coeff), title="Searching for srt files", clearMsg=False)
 def VVW1lA(self, defSrt="", mode=0, coeff=0.25):
  FFHbVj(self)
  if mode == 1:
   srtList = CCaiob.VVkqar(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FFz7l2('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFRjyr(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVSkPB(srtList, coeff)
     if err:
      if self.settingShown: FFHbVj(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVjhh4 = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FFegwS(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVjhh4.append((fName, Dir))
   VVHFFO  = ("Select"    , self.VVy6r7     , [])
   VVzffX = self.VVKo2H
   VVXuip = (""     , self.VVdlcc       , [])
   VVcwgo = (""     , BF(self.VVHNfx, defSrt, False) , [])
   VV7wPX = ("Find Current File" , BF(self.VVHNfx, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FFA1pv(self, None, title=title, header=header, VVITUl=VVjhh4, VV7ux5=widths, VVy2kz=28, VVHFFO=VVHFFO, VVzffX=VVzffX, VVXuip=VVXuip, VVcwgo=VVcwgo, VV7wPX=VV7wPX, lastFindConfigObj=CFG.lastFindSubtitle
     , VV1Y9q="#11002222", VVMnLe="#33001111", VVop6p="#33001111", VVZZ2X="#11ffff00", VViLdG="#11445544", VVmDPu="#22222222", VV15Y9="#11002233")
  elif self.settingShown : FFHbVj(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVKo2H(self, VVToDv):
  VVToDv.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VVdlcc(self, VVToDv, title, txt, colList):
  fName, Dir = colList
  FFCxQN(VVToDv, "%s\n\n%s%s" % (FFrGgO("Path:", VVtSeQ), Dir, fName), title=title)
 def VVHNfx(self, path, VVdnur, VVToDv, title, txt, colList):
  for ndx, row in enumerate(VVToDv.VVF8iU()):
   if path == row[1].strip() + row[0].strip():
    VVToDv.VVeb2k(ndx)
    break
  else:
   if VVdnur:
    FFHbVj(VVToDv, "Not in list !", 1000)
 def VVy6r7(self, VVToDv, title, txt, colList):
  VVToDv.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VVABhY(path=path)
 def VVSkPB(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCy52I.VVHl3M(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName and not CFG.epgLanguage.getValue() == "off":
   evName = CCy52I.VVsHvI(evName)
  if evName:
   lst, err = CCaiob.VVZbMC(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVmksa(self, path, enc=None):
  if not fileExists(path):
   return [], "File not found"
  if (FF2Omp(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FFup4P(path, encLst=enc if enc else None)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVJ0aa(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VV5H5B(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVc3Yj()
  return subtList, ""
 def VV5H5B(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VVJ0aa(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVc3Yj(self):
  path = CCaiob.VVIXoE(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVJjqF(self, force=False):
  posVal, durVal = self.VV5wBd()
  if self.VV589U(posVal):
   return
  curIndex = self.VVFeXB(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVEW6p()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFq6y3(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VV5wBd(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCKx3s.VVlGvH(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCy52I.VVHl3M(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VVFeXB(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VViI94(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VV8Hy0(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVEW6p(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFq6y3(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVdaH6(self):
  FFlaBE(self, self.VV1lsQ, title="Loading Lines ...", clearMsg=False)
 def VV1lsQ(self):
  FFHbVj(self)
  VVjhh4 = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVjhh4.append((cap, FFxB2b(frm), str(frm), firstLine))
  if VVjhh4:
   title = "Select Current Subtitle Line"
   VV597P  = self.VVmkIF
   VVzffX = self.VVKDCO
   VVHFFO  = ("Select"   , self.VVT9G1 , [title])
   VV7wPX = ("Current Line" , self.VVnVGZ , [True])
   VVbdhP = ("Reset Delay" , self.VVtEHm , [])
   VVUB3Q = ("New Delay"  , self.VVeKUR   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VVavJp  = (CENTER , CENTER, CENTER , LEFT    )
   VVToDv = FFA1pv(self, None, title=title, header=header, VVITUl=VVjhh4, VVavJp=VVavJp, VV7ux5=widths, VVy2kz=28, VV597P=VV597P, VVzffX=VVzffX, VVHFFO=VVHFFO, VV7wPX=VV7wPX, VVbdhP=VVbdhP, VVUB3Q=VVUB3Q
          , VV1Y9q="#33002222", VVMnLe="#33001111", VVop6p="#33110011", VVZZ2X="#11ffff00", VViLdG="#0a334455", VVmDPu="#22222222", VV15Y9="#33002233")
  else:
   FFHbVj(self, "Cannot read lines !", 2000)
 def VVmkIF(self, VVToDv):
  self.subtLinesTable = VVToDv
  if CFG.subtDelaySec.getValue():
   VVToDv["keyYellow"].show()
   VVToDv["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVToDv["keyYellow"].hide()
  VVToDv["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FFg8wK(VVToDv["keyBlue"], "#22222222")
  VVToDv.VV2DNR(BF(self.VVgJai, VVToDv))
  self.VVnVGZ(VVToDv, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVrcl9)
  except:
   self.timerSubtLines.callback.append(self.VVrcl9)
  self.timerSubtLines.start(1000, False)
 def VVKDCO(self, VVToDv):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVToDv.cancel()
 def VVrcl9(self):
  if self.subtLinesTable:
   VVToDv = self.subtLinesTable
   posVal, durVal = self.VV5wBd()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVFeXB(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVToDv.VVy7pl(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVToDv.VVlgEJ(self.subtLinesTableNdx, row)
     row = VVToDv.VVy7pl(curIndex)
     row[0] = color + row[0]
     VVToDv.VVlgEJ(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VVT9G1(self, VVToDv, Title):
  delay, color, allow = self.VVljG0(VVToDv)
  if allow:
   self.VVKDCO(VVToDv)
   self.VVZPRu(delay, True)
  else:
   FFHbVj(VVToDv, "Delay out of range", 1500)
 def VVnVGZ(self, VVToDv, VVdnur, onlyColor=False):
  if VVToDv:
   posVal, durVal = self.VV5wBd()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVFeXB(posVal)
    if curIndex > -1:
     VVToDv.VVeb2k(curIndex)
    else:
     ndx = self.VViI94(posVal)
     if ndx > -1:
      VVToDv.VVeb2k(ndx)
 def VVtEHm(self, VVToDv, title, txt, colList):
  if VVToDv["keyYellow"].getVisible():
   self.VVZPRu(0, True)
   VVToDv["keyYellow"].hide()
   self.VVnVGZ(VVToDv, False)
 def VVgJai(self, VVToDv):
  delay, color, allow = self.VVljG0(VVToDv)
  VVToDv["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VVljG0(self, VVToDv):
  lineTime = float(VVToDv.VVKPIF()[2].strip())
  return self.VVqgTw(lineTime)
 def VVqgTw(self, lineTime):
  posVal, durVal = self.VV5wBd()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VV6svy
   else     : allow, color = False, VVPUgM
   delay = FFle5S(val, -600, 600)
  return delay, color, allow
 def VVeKUR(self, VVToDv, title, txt, colList):
  pass
 @staticmethod
 def VVHYEx(SELF):
  path, delay, enc = CCaiob.VV4HrE(SELF)
  return True if path else False
 @staticmethod
 def VV4HrE(SELF):
  path, delay, enc = CCaiob.VVviBW(SELF)
  if not path:
   path = CCaiob.VVP8S4(SELF)
  return path, delay, enc
 @staticmethod
 def VVviBW(SELF):
  srtCfgPath = CCaiob.VVIXoE(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FFup4P(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVIXoE(SELF):
  fPath, fDir, fName = CCqXgM.VVsA5T(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCy52I.VVHl3M(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF6soe(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VVP8S4(SELF):
  bestRatio = 0
  fPath, fDir, fName = CCqXgM.VVsA5T(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CCaiob.VVkqar(SELF)
    bLst, err = CCaiob.VVZbMC(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVkqar(SELF):
  fPath, fDir, fName = CCqXgM.VVsA5T(SELF)
  if pathExists(fDir):
   files = FFQ9JP(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VVZbMC(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVjNU3():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVkDWo(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CCaiob.VVkqWQ()
 @staticmethod
 def VVkqWQ():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CCqCpD(ScrollLabel):
 def __init__(self, parentSELF, text="", VV5WU4=True):
  ScrollLabel.__init__(self, text)
  self.VV5WU4   = VV5WU4
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VVGmAA  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVy2kz    = None
  self.parentW    = None
  self.parentH    = None
  self.firstTime    = True
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VV8Q1M ,
   "green"   : self.VVF9J6 ,
   "yellow"  : self.VVmwnQ ,
   "blue"   : self.VV7Twt ,
   "up"   : self.pageUp   ,
   "down"   : self.pageDown   ,
   "left"   : self.pageUp   ,
   "right"   : self.pageDown   ,
   "last"   : BF(self.VVdVXZ, 0) ,
   "0"    : BF(self.VVdVXZ, 1) ,
   "next"   : BF(self.VVdVXZ, 2) ,
   "pageUp"  : self.VVII5H   ,
   "chanUp"  : self.VVII5H   ,
   "pageDown"  : self.VVrNRN   ,
   "chanDown"  : self.VVrNRN
  }, -1)
 def VVYtUm(self, isResizable=True, VVLMX6=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFq6y3(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFg8wK(self.parentSELF["keyRedTop"], "#113A5365")
  FFeAg3(self.parentSELF, True)
  self.isResizable = isResizable
  if VVLMX6:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVy2kz  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFg8wK(self, color)
 def VVgnWb(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  lineheight  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  lines   = int(self.long_text.size().height() / lineheight)
  margin   = int(lineheight / 6)
  self.pageHeight = int(lines * lineheight)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  self.setText(self.message)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVGmAA - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVHfsT()
 def pageUp(self):
  if self.VVGmAA > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVGmAA > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVII5H(self):
  self.setPos(0)
 def VVrNRN(self):
  self.setPos(self.VVGmAA-self.pageHeight)
 def VVIq87(self):
  return self.VVGmAA <= self.pageHeight or self.curPos == self.VVGmAA - self.pageHeight
 def getText(self):
  return self.message
 def VVHfsT(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVGmAA, 3))
   start = int((100 - vis) * self.curPos / (self.VVGmAA - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVbIg5=VVBuVN):
  old_VVIq87 = self.VVIq87()
  self.message = str(text)
  if self.pageHeight:
   self.long_text.setText(self.message)
   h = self.parentSELF.skinParam["bodyLineH"] * (len(self.message.splitlines()) + 1) - self.parentSELF.skinParam["marginTop"]
   h = max(h, self.long_text.calculateSize().height())
   self.VVGmAA = h if h > 0 else self.pageHeight
   if self.VV5WU4 and self.VVGmAA > self.pageHeight:
    self.scrollbar.show()
    self.VVHfsT()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVGmAA))
   if   VVbIg5 == VVmDB2: self.setPos(0)
   elif VVbIg5 == VV08OK : self.VVrNRN()
   elif old_VVIq87    : self.VVrNRN()
   if self.firstTime and len(self.message) > 0:
    self.firstTime = False
    self.setText(self.message, VVbIg5=VVbIg5)
 def appendText(self, text, VVbIg5=VV08OK):
  self.setText(self.message + str(text), VVbIg5=VVbIg5)
 def VVmwnQ(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVU2KX(size)
 def VV7Twt(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVU2KX(size)
 def VVF9J6(self):
  self.VVU2KX(self.VVy2kz)
 def VVU2KX(self, VVy2kz):
  self.long_text.setFont(gFont(self.fontFamily, VVy2kz))
  self.setText(self.message, VVbIg5=VVBuVN)
  self.VVy8Bm(calledFromFontSizer=True)
 def VVdVXZ(self, align):
  self.long_text.setHAlign(align)
 def VV8Q1M(self):
  VVJ4QS = []
  VVJ4QS.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Align Left"  , "left" ))
  VVJ4QS.append(("Align Center"  , "center" ))
  VVJ4QS.append(("Align Right"  , "right" ))
  if self.outputFileToSave:
   VVJ4QS.append(VV4c5n)
   VVJ4QS.append((FFrGgO("Save to File", VVtSeQ), "save" ))
  VVJ4QS.append(VV4c5n)
  VVJ4QS.append(("Keys (Shortcuts)" , "help" ))
  FFZP3S(self.parentSELF, self.VVYaWf, VVJ4QS=VVJ4QS, title="Text Option", width=500)
 def VVYaWf(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VVdVXZ(0)
   elif item == "center" : self.VVdVXZ(1)
   elif item == "right" : self.VVdVXZ(2)
   elif item == "save"  : self.VVCmXZ()
   elif item == "help"  : FFrc1O(self.parentSELF, VVnEh8 + "_help_txt", "Text Viewer (Keys)")
 def VVCmXZ(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FFegwS(expPath), self.outputFileToSave, FFSZ6D())
   with open(outF, "w") as f:
    f.write(FFVK2H(self.message))
   FF8O6K(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFfYN0(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVy8Bm(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVGmAA > 0 and self.pageHeight > 0:
   if self.VVGmAA < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVGmAA
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
