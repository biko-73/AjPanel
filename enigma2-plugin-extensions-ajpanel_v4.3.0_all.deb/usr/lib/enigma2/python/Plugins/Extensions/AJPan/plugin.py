import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigInteger
from Components.config   import ConfigSubList
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVwyo7   = "v4.3.0"
VVl3xf    = "21-03-2022"
EASY_MODE    = 0
VVClv6   = 0
VVjGni   = 0
VV1Enj  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVuisN  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVVPVZ    = "/media/usb/"
VVMhCM    = "/usr/share/enigma2/picon/"
VVHfFQ = "/etc/enigma2/blacklist"
VVeXaf   = "/etc/enigma2/"
VVKjcY  = "ajpanel_update_url"
VVMQqB   = "AJPan"
VVDWGF    = "AUTO FIND"
VV8X9G    = ""
VVVLsX    = "Regular"
VVjUYT      = "-" * 80
VVudpG    = ("-" * 100, )
VVWjbN    = ""
VVyW8b   = " && echo 'Successful' || echo 'Failed!'"
VVWwwb    = []
VVLbL3  = "Cannot continue (No Enough Memory) !"
VV27he   = (None, "utf-8", "ISO8859-15", "ISO8859-7", "ISO8859-5", "ISO6937", "windows-1250", "windows-1252", "unicode_escape")
VV8Rhz  = False
VVU5WU  = False
VVsfqS = False
VV1H0A     = 0
VViB1h    = 1
VVjHqq    = 2
VV4uZS   = 3
VVs3oq    = 4
VVmaS6    = 5
VVvq1J = 6
VV2pOX = 7
VVsz0j  = 8
VVJuEs   = 9
VVQGGh   = 10
VVEjiq   = 11
VVUXcx  = 12
VVIc3l  = 13
VVBqhV    = 14
VVxj6t   = 15
VV117v   = 16
VV26YX    = 17
VVAkiN  = 18
VVEsx3  = 15
VVw7OV   = 0
VVoH3m   = 1
VVCIY6   = 2
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices = [ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices = [ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices = [ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices = [ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=False)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsPath    = ConfigDirectory(default=VVDWGF, visible_width=51)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=51)
CFG.PIconsPath     = ConfigDirectory(default=VVMhCM, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVVPVZ, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
def FFzTvP():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVo2zv  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVixCe = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVo2zv  : return 0
  elif VVixCe : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVqtWu = FFzTvP()
VVpXnW = VVIgRq = VVxd7c = VV8tYH = VVHaNU = VVULex = VV3SOs = VVSfxg = COLOR_CONS_BRIGHT_YELLOW = VV9YfT = VVMcHq = VVZ7zN = VVTIP5 = ""
def FFrbz9()  : return FFNabU()
def FFTdFd(*args) : FF4oGK(True , *args)
def FFwsMh(*args): FF4oGK(False, *args)
def FF4oGK(addSep=True, *args):
 if VVClv6:
  txt  = (">>>> %s\n" % VVjUYT) if addSep else ""
  txt += ">>>> %s" % " , ".join(map(str, args))
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFKONI(txt, isAppend=True, ignoreErr=False):
 if VVClv6:
  tm = FF6KFK()
  err = ""
  if not ignoreErr:
   err = FFNabU()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFTdFd(err)
  FFTdFd("Output Log File : %s" % fileName)
def FFNabU():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FF6KFK()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except Exception as e:
  return "Cannot Trace !"
def FFYx7Y():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVWwwb = []
def FFhKEa(win):
 global VVWwwb
 if not win in VVWwwb:
  VVWwwb.append(win)
def FF19xV(*args):
 global VVWwwb
 for win in VVWwwb:
  try:
   win.close()
  except:
   pass
 VVWwwb = []
def FFbPfE():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVkxLj = FFbPfE()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFFRdu()     : return PluginDescriptor(fnc=FFol3U, where=[PluginDescriptor.WHERE_SESSIONSTART] , needsRestart=True   , description="AJPanel Startup")
def FFA3ma()      : return getDescriptor(FF288m   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFceNC()       : return getDescriptor(FFml03  , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFRm48()   : return getDescriptor(FFuyAo , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FF2aKZ(): return getDescriptor(FFj4Bo , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player"  , descr="Signal Monitor / Player")
def FFqzOl()  : return getDescriptor(FFt0tb  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV"     , descr="IPTV Menu")
def FFBFW9()     : return getDescriptor(FFFRPG , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info."    , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFA3ma() , FFceNC() , FFFRdu() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFRm48())
  result.append(FF2aKZ())
  result.append(FFqzOl())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFBFW9())
 return result
def FFol3U(reason, **kwargs):
 if reason == 0:
  FF8eP5()
  if "session" in kwargs:
   session = kwargs["session"]
   FFPJNw(session)
   CCkh0e(session)
def FFml03(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FF288m, PLUGIN_NAME, 45)]
 else:
  return []
def FF288m(session, **kwargs):
 session.open(Main_Menu)
def FFuyAo(session, **kwargs):
 session.open(CCQ7If)
def FFj4Bo(session, **kwargs):
 FFJDYM(session, isFromSession=True)
def FFt0tb(session, **kwargs):
 session.open(CCkpQY)
def FFFRPG(session, **kwargs):
 session.open(CCA5BL, fncMode=CCA5BL.VVagZT)
def FF3t2j():
 FFWtb8(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFRm48(), FF2aKZ(), FFqzOl() ])
 FFWtb8(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFBFW9() ])
def FFWtb8(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VV1qBm = None
def FF8eP5():
 try:
  global VV1qBm
  if VV1qBm is None:
   VV1qBm    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFXwX9
  ChannelContextMenu.FFU1u0 = FFU1u0
 except:
  pass
def FFXwX9(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VV1qBm(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFU1u0, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFU1u0, title1, csel, isFind=True))))
def FFU1u0(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFQogO(refCode)
 except:
  pass
 self.session.open(boundFunction(CCKU6X, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFPJNw(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFsqvI, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFsqvI, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFsqvI, session, "lred")
def FFsqvI(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFJDYM(session, isFromSession=True)
def FF4zOZ(SELF, title="", addLabel=False, addScrollLabel=False, VVSAYi=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFsbex()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCvS8Y(SELF)
 if VVSAYi:
  SELF["myMenu"] = MenuList(VVSAYi)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVjzC3        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFfgo9(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FF3bhQ, SELF, "0") ,
  "1"    : boundFunction(FF3bhQ, SELF, "1") ,
  "2"    : boundFunction(FF3bhQ, SELF, "2") ,
  "3"    : boundFunction(FF3bhQ, SELF, "3") ,
  "4"    : boundFunction(FF3bhQ, SELF, "4") ,
  "5"    : boundFunction(FF3bhQ, SELF, "5") ,
  "6"    : boundFunction(FF3bhQ, SELF, "6") ,
  "7"    : boundFunction(FF3bhQ, SELF, "7") ,
  "8"    : boundFunction(FF3bhQ, SELF, "8") ,
  "9"    : boundFunction(FF3bhQ, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFFBkO, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FF3bhQ(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVTIP5:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVTIP5 + SELF.keyPressed + VVIgRq)
    txt = VVIgRq + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFlFRp(SELF, txt)
def FFFBkO(SELF, tableObj, colNum):
 FFlFRp(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VVdPXQ(i)
     break
 except:
  pass
def FFRn36(SELF, setMenuAction=True):
 if setMenuAction:
  global VVWjbN
  VVWjbN = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFsbex():
 return ("  %s" % VVWjbN)
def FF313P(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFxdkh(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFX7ku(color):
 return parseColor(color).argb()
def FFxuhv(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFv4ZZ(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFf7Xr(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFA6Lm(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVTIP5)
 else:
  return ""
def FF5oB0(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVjUYT, word, VVjUYT, VVTIP5)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVjUYT, word, VVjUYT)
def FFxKI9(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVTIP5
def FFMEmL(color):
 if color: return "echo -e '%s' %s;" % (VVjUYT, FFA6Lm(VVjUYT, VVSfxg))
 else : return "echo -e '%s';" % VVjUYT
def FF81Uc(title, color):
 title = "%s\n%s\n%s\n" % (VVjUYT, title, VVjUYT)
 return FFxKI9(title, color)
def FF5gi1(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFPj7y(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFYJiO(callBackFunction):
 tCons = CC4384()
 tCons.ePopen("echo", boundFunction(FFl5nU, callBackFunction))
def FFl5nU(callBackFunction, result, retval):
 callBackFunction()
def FF8MfV(SELF, fnc, title="Processing ...", clearMsg=True):
 FFlFRp(SELF, title)
 tCons = CC4384()
 tCons.ePopen("echo", boundFunction(FFInwh, SELF, fnc, clearMsg))
def FFInwh(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFlFRp(SELF)
def FFhEkf(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVLbL3
  else       : return ""
def FFs4zJ(cmd):
 txt = FFhEkf(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFw9Nl(cmd):
 lines = FFs4zJ(cmd)
 if lines: return lines[0]
 else : return ""
def FFPkUh(SELF, cmd):
 lines = FFs4zJ(cmd)
 VVprUT = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVprUT.append((key, val))
  elif line:
   VVprUT.append((line, ""))
 if VVprUT:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFEtMz(SELF, None, header=header, VV06zW=VVprUT, VVTS0u=widths, VVp74Q=28)
 else:
  FFkZIr(SELF, cmd)
def FFkZIr(    SELF, cmd, **kwargs): SELF.session.open(CCCeh9, VVgPsE=cmd, VVbE34=True, VVTzbD=VVoH3m, **kwargs)
def FFar6j(  SELF, cmd, **kwargs): SELF.session.open(CCCeh9, VVgPsE=cmd, **kwargs)
def FFRgi8(   SELF, cmd, **kwargs): SELF.session.open(CCCeh9, VVgPsE=cmd, VV3wNV=True, VVxIY0=True, VVTzbD=VVoH3m, **kwargs)
def FFsHJ2(  SELF, cmd, **kwargs): SELF.session.open(CCCeh9, VVgPsE=cmd, VV3wNV=True, VVxIY0=True, VVTzbD=VVCIY6, **kwargs)
def FFl3Il(  SELF, cmd, **kwargs): SELF.session.open(CCCeh9, VVgPsE=cmd, VVUmDA=True , **kwargs)
def FFtziJ( SELF, cmd, **kwargs): SELF.session.open(CCCeh9, VVgPsE=cmd, VV5FhL=True   , **kwargs)
def FFDnwG( SELF, cmd, **kwargs): SELF.session.open(CCCeh9, VVgPsE=cmd, VVCQnL=True  , **kwargs)
def FFMugq(cmd):
 return cmd + " > /dev/null 2>&1"
def FFgrHS():
 return " > /dev/null 2>&1"
def FFtJ8E(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFfLcR(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFUpZG():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFw9Nl(cmd)
VVzgKA     = 0
VVD6iv      = 1
VVTn9i   = 2
VVRoHT      = 3
VVHM4T      = 4
VVF0kb     = 5
VVaBvq     = 6
VVi2Z7 = 7
VVWDTt = 8
VVPoBH = 9
VVmeGz  = 10
VVDFgV     = 11
VVWHml  = 12
VVN6V0  = 13
def FFyxGo(parmNum, grepTxt):
 if   parmNum == VVzgKA  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVD6iv   : param = ["list"   , "apt list" ]
 elif parmNum == VVTn9i: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFUpZG()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFyov6(parmNum, package):
 if   parmNum == VVRoHT      : param = ["info"      , "apt show"         ]
 elif parmNum == VVHM4T      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVF0kb     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVaBvq     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVi2Z7 : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVWDTt : param = ["install --force-overwrite" , "dpkg -i --force-overwrite -y"    ]
 elif parmNum == VVPoBH : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVmeGz  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVDFgV     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVWHml  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVN6V0  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFUpZG()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFpwIl():
 result = FFw9Nl("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFyov6(VVaBvq , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFMugq("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFMugq("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFA6Lm(failed1, VVSfxg))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFA6Lm(failed2, VVSfxg))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFA6Lm(failed3, VVxd7c))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFS6QL(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFyov6(VVaBvq , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFMugq("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFA6Lm(failed1, VVSfxg))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFA6Lm(failed2, VVxd7c))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFStZp(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFMugq('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFMugq("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFqhNI(path, maxSize=-1):
 txt = ""
 for enc in VV27he:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FF66GF(path, keepends=False, maxSize=-1):
 lines = FFqhNI(path, maxSize)
 return lines.splitlines(keepends)
def FFJRme(SELF, path):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFpeIy(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FF66GF(path, maxSize=maxSize)
  if lines: FFGdNj(SELF, lines, title=title, VVTzbD=VVoH3m)
  else : FFrHkO(SELF, path, title=title)
 else:
  FF7BRF(SELF, path, title)
def FF2UCb(SELF, path, title):
 if fileExists(path):
  txt = FFqhNI(path)
  txt = txt.replace("#W#", VVTIP5)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVIgRq)
  txt = txt.replace("#C#", VV9YfT)
  txt = txt.replace("#P#", VV8tYH)
  FFGdNj(SELF, txt, title=title)
 else:
  FF7BRF(SELF, path, title)
def FFJDeD(path, SELF=None):
 txt = ""
 for enc in VV27he:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return enc
  except:
   pass
 if SELF:
  FFv5WO(SELF, "Cannot detect file encoding for:\n\n%s" % path)
 return -1
def FFNvpA(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FF5NSf(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFqLVd(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFhBEj(parent)
 else    : return FFm91m(parent)
def FFpeIy(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFhBEj(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFm91m(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFHmYP():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VV1Enj)
 paths.append(VV1Enj.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FF5NSf(ba)
 for p in list:
  p = ba + p + VV1Enj
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVMQqB, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VV1Enj, VVMQqB , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVDCEs, VVrF44 = FFHmYP()
def FFZuwO():
 def VVWxux(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 iPath = CFG.iptvHostsPath.getValue()
 if not iPath == VVDWGF and not pathExists(iPath):
  CFG.iptvHostsPath.setValue(VVDWGF)
  CFG.iptvHostsPath.save()
  oldIptvHostsPath = VVDWGF
 else:
  oldIptvHostsPath = ""
 oldMovieDownloadPath = VVWxux(CFG.MovieDownloadPath, CCGsij.VVnJek())
 VVTKyC   = VVWxux(CFG.backupPath, CCBngL.VVo6Vg())
 VVFt53   = VVWxux(CFG.downloadedPackagesPath, t)
 VVtncw  = VVWxux(CFG.exportedTablesPath, t)
 VV01xZ  = VVWxux(CFG.exportedPIconsPath, t)
 VVdhPq   = VVWxux(CFG.packageOutputPath, t)
 global VVVPVZ
 VVVPVZ = FFhBEj(CFG.backupPath.getValue())
 if VVTKyC or VVdhPq or VVFt53 or VVtncw or VV01xZ or oldIptvHostsPath or oldMovieDownloadPath:
  configfile.save()
 return VVTKyC, VVdhPq, VVFt53, VVtncw, VV01xZ, oldIptvHostsPath, oldMovieDownloadPath
def FFpDBp(path):
 path = FFm91m(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFbT0Q(SELF, pathList, tarFileName, addTimeStamp=True):
 VV06zW = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VV06zW.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VV06zW.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VV06zW.append(path)
 if not VV06zW:
  FFv5WO(SELF, "Files not found!")
 elif not pathExists(VVVPVZ):
  FFv5WO(SELF, "Path not found!\n\n%s" % VVVPVZ)
 else:
  VVHoUo = FFhBEj(VVVPVZ)
  tarFileName = "%s%s" % (VVHoUo, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFS6oF())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VV06zW:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVjUYT
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFA6Lm(tarFileName, VV3SOs))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFA6Lm(failed, VV3SOs))
  cmd += "fi;"
  cmd +=  sep
  FFar6j(SELF, cmd)
def FFoZqi(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFIXh7(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFIXh7(SELF["keyInfo"], "info")
def FFIXh7(barObj, fName):
 path = "%s%s%s" % (VVrF44, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FF7GAb(SELF, title, VVWSPo, showGrnMsg=""):
 SELF.session.open(boundFunction(CC823A, title=title, VVWSPo=VVWSPo, showGrnMsg=showGrnMsg))
def FF95wO(labelObj, VVWSPo):
 if VVWSPo and fileExists(VVWSPo):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VVJwsY(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VVJwsY)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VVWSPo)
   return True
  except:
   pass
 return False
def FFknK4(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFNUup(satNum)
  return satName
def FFNUup(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFITp0(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFknK4(val)
  else  : sat = FFNUup(val)
 return sat
def FF6tzg(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFknK4(num)
 except:
  pass
 return sat
def FFlP4Z(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FF45eg(SELF, isFromSession=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFWEVh(info, iServiceInformation.sServiceref)
   prov = FFWEVh(info, iServiceInformation.sProvider)
   state = str(FFWEVh(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFpq6y(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FF7eR2(refCode)
 return info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFWEVh(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFGsMp(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFQogO(refCode):
 info = FF9U73(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFBg35(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FF0UE0(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FF9U73(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVBcIx = eServiceCenter.getInstance()
  if VVBcIx:
   info = VVBcIx.info(service)
 return info
def FFY7Np(SELF, refCode, VV4NU5=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  FF6JIs(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VV4NU5:
   FFJDYM(SELF, isFromSession)
 try:
  VV26oo = InfoBar.instance
  if VV26oo:
   VVhsPd = VV26oo.servicelist
   if VVhsPd:
    servRef = eServiceReference(refCode)
    VVhsPd.saveChannel(servRef)
 except:
  pass
def FF6JIs(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CC69K0()
    if pr.VVgTKV(refCode, chName, decodedUrl, iptvRef):
     pr.VVM9yX(SELF, isFromSession)
def FFpq6y(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFGCwp(url): return any(x in url for x in ("/movie/", "/series/", "mode=vod", "mode=series"))
def FFfkEY(url)  : return any(x in url for x in ("/movie/", "mode=vod"))
def FFFH1k(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FF7eR2(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFeUdo(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFk8Yi(userBfile):
 txt = ""
 bFile = VVeXaf + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVeXaf + userBfile):
  fTxt = FFqhNI(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFw9Nl('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
def FFeUdo(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FFXZWp(url):
 if iQuote : return iQuote(url)
 else  : return url
def FFNJSY(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFlFvV(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFOezn(txt):
 try:
  return FFNJSY(FFlFvV(txt)) == txt
 except:
  return False
def FFJDYM(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(SELF, isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCewzF, isFromExternal=isFromSession)
 else      : FFZZRQ(session, reopen=True, isFromExternal=isFromSession)
def FFZZRQ(session, reopen=False, isFromExternal=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFZZRQ, session, isFromExternal=isFromExternal), boundFunction(CC54uT, isFromExternal=isFromExternal))
  except:
   try:
    FFPQNs(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFJPAH(refCode):
 tp = CCJR3E()
 if tp.VVbuYV(refCode) : return True
 else        : return False
def FFrRU9(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FF7jBe():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FFQRnQ():
 VV26oo = InfoBar.instance
 if VV26oo:
  VVhsPd = VV26oo.servicelist
  if VVhsPd:
   return VVhsPd.getBouquetList()
 return None
def FFdjsr():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFueaG():
 path = FFdjsr()
 if path:
  txt = FFqhNI(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFByrM():
 return FF04X5(InfoBar.instance.servicelist.getRoot())
def FF04X5(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVBcIx = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVBcIx.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FFtCwD():
 VVPj0m = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVrl4a = list(VVPj0m)
 return VVrl4a, VVPj0m
def FF13j6():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFcckN(session, VVCVoH):
 VVfDmQ, VVpd60, VV3AQf, camCommand = FFMVjr()
 if VVpd60:
  runLog = False
  if   VVCVoH == CCqqKN.VVbydf : runLog = True
  elif VVCVoH == CCqqKN.VV7cZH : runLog = True
  elif not VV3AQf          : FFPQNs(session, message="SoftCam not started yet!")
  elif fileExists(VV3AQf)        : runLog = True
  else             : FFPQNs(session, message="File not found !\n\n%s" % VV3AQf)
  if runLog:
   session.open(boundFunction(CCqqKN, VVfDmQ=VVfDmQ, VVpd60=VVpd60, VV3AQf=VV3AQf, VVCVoH=VVCVoH))
 else:
  FFPQNs(session, message="No active OSCam/NCam found !", title="Live Log")
def FFMVjr():
 VVfDmQ = "/etc/tuxbox/config/"
 VVpd60 = None
 VV3AQf  = None
 camCommand = FFw9Nl("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVpd60 = "oscam"
 elif "ncam"  in camCommand : VVpd60 = "ncam"
 if VVpd60:
  path = FFw9Nl(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFhBEj(path)
  if pathExists(path):
   VVfDmQ = path
  tFile = VVfDmQ + VVpd60 + ".conf"
  tFile = FFw9Nl("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VV3AQf = tFile
 return VVfDmQ, VVpd60, VV3AQf, camCommand
def FFt8n3(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFEuaP():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFS6oF():
 return FFEuaP().replace(" ", "_").replace("-", "").replace(":", "")
def FFK79w(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FF6KFK():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFzKLB(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCkpQY.VV6xjj(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCkpQY.VViR57_forBouquet(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFMugq("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFmy2q(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFnMuZ(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
VVfJ2S = 0
def FFZrJU():
 global VVfJ2S
 VVfJ2S = iTime()
def FFCtr1():
 FFTdFd(">>>>>> Elapsed\t: {:.6f} seconds".format(iTime() - VVfJ2S).rstrip("0").rstrip("."))
def FFLnSq(SELF, message, title=""):
 SELF.session.open(boundFunction(CCbNLL, title=title, message=message, VV1Ai8=True))
def FFGdNj(SELF, message, title="", VVTzbD=VVoH3m, **kwargs):
 SELF.session.open(boundFunction(CCbNLL, title=title, message=message, VVTzbD=VVTzbD, **kwargs))
def FFv5WO(SELF, message, title="")  : FFPQNs(SELF.session, message, title)
def FF7BRF(SELF, path, title="") : FFPQNs(SELF.session, "File not found !\n\n%s" % path, title)
def FFrHkO(SELF, path, title="") : FFPQNs(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFXixL(SELF, title="")  : FFPQNs(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFPQNs(session, message, title="") : session.open(boundFunction(CCdgYU, title=title, message=message))
def FFMKq2(SELF, VVCoUZ, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVCoUZ, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVCoUZ, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVCoUZ, boundFunction(CCNLE9, title=title, message=message, VVCC3L=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFv5WO(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFhdnr(SELF, callBack_Yes, VVlC3v, callBack_No=None, title="", VVD4Yr=False, VV7EBj=True):
 SELF.session.openWithCallback(boundFunction(FFVaaq, callBack_Yes, callBack_No)
        , boundFunction(CCgFUs, title=title, VVlC3v=VVlC3v, VV7EBj=VV7EBj, VVD4Yr=VVD4Yr))
def FFVaaq(callBack_Yes, callBack_No, FFhdnred):
 if FFhdnred : callBack_Yes()
 elif callBack_No: callBack_No()
def FFlFRp(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFv4ZZ(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFZeD6(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FF60YR(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVgGIM = eTimer()
def FFZeD6(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FF7wMC, SELF))
 fnc = boundFunction(FF7wMC, SELF)
 try:
  t = VVgGIM.timeout.connect(fnc)
 except:
  VVgGIM.callback.append(fnc)
 VVgGIM.start(milliSeconds, 1)
def FF7wMC(SELF):
 VVgGIM.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFEtMz(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCaZwA, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCaZwA, **kwargs))
  FFhKEa(win)
  return win
 except:
  return None
def FF3fIR(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCjXwl, **kwargs))
 FFhKEa(win)
 return win
def FFlYRO(SELF, **kwargs):
 SELF.session.open(CCA5BL, **kwargs)
def FFZe3q(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFMKwf(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVVLsX, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFfRto(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFMKwf(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FF21gA():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFs3iW(VVp74Q):
 screenSize  = FF21gA()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVp74Q)
 return bodyFontSize
def FF6fS8(VVp74Q, extraSpace):
 font = gFont(VVVLsX, VVp74Q)
 VVLeZ7 = fontRenderClass.getInstance().getLineHeight(font) or (VVp74Q * 1.25)
 return int(VVLeZ7 + VVLeZ7 * extraSpace)
def FFnshG(fontName):
 fList = None
 try:
  from enigma import getFontFaces
  fList = getFontFaces()
 except:
  try:
   from skin import getFontFaces
   fList = getFontFaces()
  except:
   pass
 if fList and fontName in fList : return fontName
 else       : return VVVLsX
def FFrBKf(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FF21gA()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * VVEsx3)
 bodyFontStr  = 'font="%s;%d"' % (VVVLsX, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FF6fS8(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVVLsX, titleFontSize, alignLeftCenter)
 if winType == VV1H0A or winType == VViB1h:
  if winType == VViB1h : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVAkiN:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == VVBqhV:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FFLnSqL = b2Left2 + timeW + marginLeft
  FFLnSqW = b2Left3 - marginLeft - FFLnSqL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FFLnSqL  , b2Top, FFLnSqW , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="1000" alphatest="blend" />' % (0, top, sz, sz)
 elif winType == VVxj6t:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVs3oq:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVjHqq:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VV4uZS:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVVLsX, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVVLsX, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVQGGh:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFLnSqH = int(bodyH * 0.5)
  inpTop = bodyTop + FFLnSqH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFLnSqH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVVLsX, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVVLsX, mapF, alignCenter)
 elif winType == VVEjiq:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVUXcx:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVVLsX, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VV117v:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVVLsX, fontH, alignCenter)
 elif winType == VVIc3l:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVVLsX, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVVLsX, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVVLsX, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VV26YX:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 else:
  if   winType == VV2pOX : align = alignLeftCenter
  elif winType == VVvq1J : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVJuEs:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VVmaS6:
   moreParams = ""
  else:
   fontStr = bodyFontStr
   if usefixedFont and winType == VVvq1J:
    fontStr = 'font="%s;%d"' % (FFnshG("Fixed"), bodyFontSize)
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" %s %s ' % (bodyColor, fontStr, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVp74Q = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVVLsX, VVp74Q, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVehrL = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVVLsX, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVehrL[i], VVVLsX, barFont, alignCenter)
   left += btnW + gap
 if winType == VVvq1J:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVehrL = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVehrL[i], VVVLsX, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFrBKf(VV1H0A, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.hiddenMenuPass = ""
  self.themsList  = []
  VVSAYi = []
  if VVjGni:
   VVSAYi.append(("-- MY TEST --"    , "myTest"   ))
  VVSAYi.append(("  File Manager"     , "FileManager"  ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("  Services/Channels"    , "ChannelsTools" ))
  VVSAYi.append(("  IPTV"       , "IptvTools"  ))
  VVSAYi.append(("  PIcons"       , "PIconsTools"  ))
  VVSAYi.append(("  SoftCam"      , "SoftCam"   ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("  Plugins"      , "PluginsTools" ))
  VVSAYi.append(("  Terminal"      , "Terminal"  ))
  VVSAYi.append(("  Backup & Restore"    , "BackupRestore" ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("  Date/Time"      , "Date_Time"  ))
  VVSAYi.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVSAYi)
  FF4zOZ(self, VVSAYi=VVSAYi)
  FF313P(self["keyRed"] , "Exit")
  FF313P(self["keyGreen"] , "Settings")
  FF313P(self["keyYellow"], "Dev. Info.")
  FF313P(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVRiIP       ,
   "yellow"  : self.VVlQ5e       ,
   "blue"   : self.VVaWUY       ,
   "info"   : self.VVaWUY       ,
   "last"   : self.VVf3kk      ,
   "next"   : self.VVjZQQ       ,
   "menu"   : self.VV53BK     ,
   "0"    : boundFunction(self.VVpeB3, 0) ,
   "1"    : boundFunction(self.VVJT5R, 1)   ,
   "2"    : boundFunction(self.VVJT5R, 2)   ,
   "3"    : boundFunction(self.VVJT5R, 3)   ,
   "4"    : boundFunction(self.VVJT5R, 4)   ,
   "5"    : boundFunction(self.VVJT5R, 5)   ,
   "6"    : boundFunction(self.VVJT5R, 6)   ,
   "7"    : boundFunction(self.VVJT5R, 7)   ,
   "8"    : boundFunction(self.VVJT5R, 8)   ,
   "9"    : boundFunction(self.VVJT5R, 9)
  })
  self.onShown.append(self.VVAJmk)
  self.onClose.append(self.onExit)
  global VV8Rhz, VVU5WU, VVsfqS
  VV8Rhz = VVU5WU = VVsfqS = False
 def VVjzC3(self):
  item = FFRn36(self)
  self.VVJT5R(item)
 def VVJT5R(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVHHs7()
   elif item in ("FileManager"  , 1) : self.session.open(CCQ7If)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCHa4g)
   elif item in ("IptvTools"  , 3) : self.session.open(CCkpQY)
   elif item in ("PIconsTools"  , 4) : self.VVYIt8()
   elif item in ("SoftCam"   , 5) : self.session.open(CC4wfx)
   elif item in ("PluginsTools" , 6) : self.session.open(CCGCq6)
   elif item in ("Terminal"  , 7) : self.session.open(CCfJsk)
   elif item in ("BackupRestore" , 8) : self.session.open(CCJEvi)
   elif item in ("Date_Time"  , 9) : self.session.open(CCNGLM)
   elif item in ("CheckInternet" , 10) : self.session.open(CCYUet)
   else         : self.close()
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FF5gi1(self["myMenu"])
  FFfRto(self)
  FFZe3q(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVwyo7)
  self["myTitle"].setText(title)
  VVTKyC, VVdhPq, VVFt53, VVtncw, VV01xZ, oldIptvHostsPath, oldMovieDownloadPath = FFZuwO()
  self.VVhoGI()
  if VVTKyC or VVdhPq or VVFt53 or VVtncw or VV01xZ or oldIptvHostsPath or oldMovieDownloadPath:
   VVCE8s = lambda path, subj: "%s:\n%s\n\n" % (subj, FFxKI9(path, VVxd7c)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVCE8s(oldIptvHostsPath  , "IPTV Hosts Files Path"   )
   txt += VVCE8s(VVTKyC   , "Backup/Restore Path"    )
   txt += VVCE8s(VVdhPq  , "Created Package Files (IPK/DEB)" )
   txt += VVCE8s(VVFt53  , "Download Packages (from feeds)" )
   txt += VVCE8s(VVtncw , "Exported Tables"     )
   txt += VVCE8s(VV01xZ , "Exported PIcons"     )
   txt += VVCE8s(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFGdNj(self, txt, title="Settings Paths")
  if (EASY_MODE or VVClv6 or VVjGni):
   FFv4ZZ(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFlFRp(self, "Welcome", 300)
  FFYJiO(boundFunction(self.VVGUeN, title))
 def VVGUeN(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCBngL.VVZdEb()
   if url:
    newWebVer = CCBngL.VVOfgS(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFMugq("rm /tmp/ajpanel*"))
  global VV8Rhz, VVU5WU, VVsfqS
  VV8Rhz = VVU5WU = VVsfqS = False
 def VVpeB3(self, digit):
  self.hiddenMenuPass += str(digit)
  ln = len(self.hiddenMenuPass)
  global VV8Rhz, VVsfqS
  if ln == 4:
   if self.hiddenMenuPass == "0" * ln:
    VV8Rhz = True
    FFv4ZZ(self["myTitle"], "#800080")
   else:
    self.hiddenMenuPass = "x"
  elif self.hiddenMenuPass == "0" * ln:
   VVsfqS = True
 def VVjZQQ(self):
  self.hiddenMenuPass += ">"
  if self.hiddenMenuPass == "0" * 4 + ">" * 2:
   global VVU5WU
   VVU5WU = True
   FFv4ZZ(self["myTitle"], "#dd5588")
 def VVf3kk(self):
  self.hiddenMenuPass += "<"
  if self.hiddenMenuPass == "0" * 4 + "<" * 2:
   ok = False
   fnt = "ae_AlMateen.ttf"
   fontFile = "/usr/share/fonts/%s" % fnt
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    try:
     addFont(fontFile, fontName, 100, True)
     ok = True
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      ok = True
     except:
      pass
   if ok: txt = 'Added Font: "%s"' % fnt
   else : txt = '"%s" Not Found' % fnt
   FFlFRp(self, txt, 2000, isGrn=ok)
 def VVYIt8(self):
  found = False
  pPath = CCOmM2.VVQ8DK()
  if pathExists(pPath):
   for fName, fType in CCOmM2.VVT956(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCOmM2)
  else:
   VVSAYi = []
   VVSAYi.append(("PIcons Manager" , "CCOmM2" ))
   VVSAYi.append(VVudpG)
   VVSAYi.append(CCOmM2.VVuFsO())
   VVSAYi.append(VVudpG)
   VVSAYi += CCOmM2.VV2tPb()
   FF3fIR(self, self.VVerX7, VVSAYi=VVSAYi)
 def VVerX7(self, item=None):
  if item:
   if   item == "CCOmM2"   : self.session.open(CCOmM2)
   elif item == "VVixzJ"  : CCOmM2.VVixzJ(self)
   elif item == "VVUlRF"  : CCOmM2.VVUlRF(self)
   elif item == "findPiconBrokenSymLinks" : CCOmM2.VV5p7f(self, True)
   elif item == "FindAllBrokenSymLinks" : CCOmM2.VV5p7f(self, False)
 def VVRiIP(self):
  self.session.open(CCBngL)
 def VVlQ5e(self):
  self.session.open(CCU83h)
 def VVaWUY(self):
  changeLogFile = VVrF44 + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FF66GF(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFxKI9("\n%s\n%s\n%s" % (VVjUYT, line, VVjUYT), VV8tYH, VVTIP5)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FFxKI9(line, VVIgRq, VVTIP5)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFGdNj(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVwyo7), VVp74Q=26)
 def VV53BK(self):
  VVSAYi = []
  VVSAYi.append(("Title Colors"   , "title" ))
  VVSAYi.append(("Menu Area Colors"  , "body" ))
  VVSAYi.append(("Menu Pointer Colors" , "cursor" ))
  VVSAYi.append(("Bottom Bar Colors" , "bar"  ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Reset Colors"   , "reset" ))
  title = "Main Menu Colors"
  FF3fIR(self, boundFunction(self.VVbnWU, title), VVSAYi=VVSAYi, width=500, title=title)
 def VVbnWU(self, title, item=None):
  if item:
   if item == "reset":
    FFhdnr(self, self.VVdbwH, "Reset to default colors ?", title=title)
   else:
    tDict = self.VVXq3t()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VVNkMZ, tDict, item), CCS98E, defFG=fg, defBG=bg)
 def VVfVDM(self):
  return VVVPVZ + "ajpanel_colors"
 def VVXq3t(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVfVDM()
  if fileExists(p):
   txt = FFqhNI(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVNkMZ(self, tDict, item, fg, bg):
  if fg:
   self.VVglhR(item, fg)
   self.VVsU2S(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VV6bP6(tDict)
 def VV6bP6(self, tDict):
   p = self.VVfVDM()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVglhR(self, item, fg):
  if   item == "title" : FFxuhv(self["myTitle"], fg)
  elif item == "body"  :
   FFxuhv(self["myMenu"], fg)
   FFxuhv(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFv4ZZ(self["myBar"], fg)
   FFxuhv(self["keyRed"], fg)
   FFxuhv(self["keyGreen"], fg)
   FFxuhv(self["keyYellow"], fg)
   FFxuhv(self["keyBlue"], fg)
 def VVsU2S(self, item, bg):
  if   item == "title" : FFv4ZZ(self["myTitle"], bg)
  elif item == "body"  :
   FFv4ZZ(self["myMenu"], bg)
   FFv4ZZ(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFv4ZZ(self["myBar"], bg)
 def VVdbwH(self):
  os.system(FFMugq("rm %s" % self.VVfVDM()))
  self.close()
 def VVhoGI(self):
  tDict = self.VVXq3t()
  self.VVbpA0(tDict, "title")
  self.VVbpA0(tDict, "body")
  self.VVbpA0(tDict, "cursor")
  self.VVbpA0(tDict, "bar")
 def VVbpA0(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVglhR(name, fg)
  if bg: self.VVsU2S(name, bg)
 def VVHHs7(self):
  FFJDYM(self)
class CCU83h(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFrBKf(VV1H0A, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVSAYi = []
  VVSAYi.append(("Settings File"        , "SettingsFile"   ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Box Info"          , "VV4H1v"    ))
  VVSAYi.append(("Tuners Info"         , "VVlKrU"   ))
  VVSAYi.append(("Python Version"        , "VVdOGT"   ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Screen Size"         , "ScreenSize"    ))
  VVSAYi.append(("Locale"          , "Locale"     ))
  VVSAYi.append(("Processor"         , "Processor"    ))
  VVSAYi.append(("Operating System"        , "OperatingSystem"   ))
  VVSAYi.append(("Drivers"          , "drivers"     ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("System Users"         , "SystemUsers"    ))
  VVSAYi.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVSAYi.append(("Uptime"          , "Uptime"     ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Host Name"         , "HostName"    ))
  VVSAYi.append(("MAC Address"         , "MACAddress"    ))
  VVSAYi.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVSAYi.append(("Network Status"        , "NetworkStatus"   ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Disk Usage"         , "VVeSgY"    ))
  VVSAYi.append(("Mount Points"         , "MountPoints"    ))
  VVSAYi.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVSAYi.append(("USB Devices"         , "USB_Devices"    ))
  VVSAYi.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVSAYi.append(("Directory Size"        , "DirectorySize"   ))
  VVSAYi.append(("Memory"          , "Memory"     ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVSAYi.append(("Running Processes"       , "RunningProcesses"  ))
  VVSAYi.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FF4zOZ(self, VVSAYi=VVSAYi, title="Device Information")
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FF5gi1(self["myMenu"])
  FFfRto(self)
 def VVjzC3(self):
  global VVWjbN
  VVWjbN = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCNHSH)
   elif item == "VV4H1v"    : self.VV4H1v()
   elif item == "VVlKrU"   : self.VVlKrU()
   elif item == "VVdOGT"   : self.VVdOGT()
   elif item == "ScreenSize"    : FFGdNj(self, "Width\t: %s\nHeight\t: %s" % (FF21gA()[0], FF21gA()[1]))
   elif item == "Locale"     : self.VVSmOC()
   elif item == "Processor"    : self.VV6jh1()
   elif item == "OperatingSystem"   : FFkZIr(self, "uname -a"        )
   elif item == "drivers"     : self.VVRfdo()
   elif item == "SystemUsers"    : FFkZIr(self, "id"          )
   elif item == "LoggedInUsers"   : FFkZIr(self, "who -a"         )
   elif item == "Uptime"     : FFkZIr(self, "uptime"         )
   elif item == "HostName"     : FFkZIr(self, "hostname"        )
   elif item == "MACAddress"    : self.VVUIax()
   elif item == "NetworkConfiguration"  : FFkZIr(self, "ifconfig %s %s" % (FFA6Lm("HWaddr", VVZ7zN), FFA6Lm("addr:", VVSfxg)))
   elif item == "NetworkStatus"   : FFkZIr(self, "netstat -tulpn"       )
   elif item == "VVeSgY"    : self.VVeSgY()
   elif item == "MountPoints"    : FFkZIr(self, "mount %s" % (FFA6Lm(" on ", VVSfxg)))
   elif item == "FileSystemTable"   : FFkZIr(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFkZIr(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFkZIr(self, "blkid"         )
   elif item == "DirectorySize"   : FFkZIr(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVdUs5="Reading size ...")
   elif item == "Memory"     : FFkZIr(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVXynM()
   elif item == "RunningProcesses"   : FFkZIr(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFkZIr(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVdHZ1()
   else         : self.close()
 def VVUIax(self):
  res = FFhEkf("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFGdNj(self, txt)
  else:
   FFkZIr(self, "ip link")
 def VVu0Hw(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFs4zJ(cmd)
  return lines
 def VVpG03(self, lines, headerRepl, widths, VVDKYV):
  VVprUT = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVprUT.append(parts)
  if VVprUT and len(header) == len(widths):
   VVprUT.sort(key=lambda x: x[0].lower())
   FFEtMz(self, None, header=header, VV06zW=VVprUT, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=28, VVJcAq=True)
   return True
  else:
   return False
 def VVeSgY(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VVu0Hw(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVDKYV = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVpG03(lines, headerRepl, widths, VVDKYV)
  if not allOK:
   lines = FFs4zJ(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFm91m(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VV3SOs:
     note = "\n%s" % FFxKI9("Green = Mounted Partitions", VV3SOs)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVSfxg
     elif line.endswith(mountList) : color = VV3SOs
     else       : color = VVIgRq
     txt += FFxKI9(line, color) + "\n"
    FFGdNj(self, txt + note)
   else:
    FFv5WO(self, "Not data from system !")
 def VVXynM(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVu0Hw(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVDKYV = (LEFT , CENTER, LEFT )
  allOK = self.VVpG03(lines, headerRepl, widths, VVDKYV)
  if not allOK:
   FFkZIr(self, cmd)
 def VVSmOC(self):
  from locale import getdefaultlocale
  loc = getdefaultlocale()
  FFGdNj(self, "Language\t: %s\nEncoding\t: %s" % (loc[0], loc[1]))
 def VVRfdo(self):
  cmd = FFyxGo(VVTn9i, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFkZIr(self, cmd)
  else : FFXixL(self)
 def VV6jh1(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFkZIr(self, cmd)
 def VVdHZ1(self):
  cmd = FFyxGo(VVD6iv, "| grep secondstage")
  if cmd : FFkZIr(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFXixL(self)
 def VV4H1v(self):
  c = VV3SOs
  VV06zW = []
  VV06zW.append((FFxKI9("Box Type"  , c), FFxKI9(self.VVGFTn("boxtype").upper(), c)))
  VV06zW.append((FFxKI9("Board Version", c), FFxKI9(self.VVGFTn("board_revision") , c)))
  VV06zW.append((FFxKI9("Chipset"  , c), FFxKI9(self.VVGFTn("chipset")  , c)))
  VV06zW.append((FFxKI9("S/N"   , c), FFxKI9(self.VVGFTn("sn")    , c)))
  VV06zW.append((FFxKI9("Version"  , c), FFxKI9(self.VVGFTn("version")  , c)))
  VVak1k   = []
  VVjeUk = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVjeUk = SystemInfo[key]
     else:
      VVak1k.append((FFxKI9(str(key), VV9YfT), FFxKI9(str(SystemInfo[key]), VV9YfT)))
  except:
   pass
  if VVjeUk:
   VVrnYJ = self.VV4kjx(VVjeUk)
   if VVrnYJ:
    VVrnYJ.sort(key=lambda x: x[0].lower())
    VV06zW += VVrnYJ
  if VVak1k:
   VVak1k.sort(key=lambda x: x[0].lower())
   VV06zW += VVak1k
  if VV06zW:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFEtMz(self, None, header=header, VV06zW=VV06zW, VVTS0u=widths, VVp74Q=28, VVJcAq=True)
  else:
   FFGdNj(self, "Could not read info!")
 def VVGFTn(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FF66GF(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VV4kjx(self, mbDict):
  try:
   mbList = list(mbDict)
   VV06zW = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VV06zW.append((FFxKI9(subject, VVSfxg), FFxKI9(value, VVSfxg)))
  except:
   pass
  return VV06zW
 def VVlKrU(self):
  txt = self.VVUZIr("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVUZIr("/proc/bus/nim_sockets")
  if not txt: txt = self.VVGgJA()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFGdNj(self, txt)
 def VVGgJA(self):
  txt = ""
  VVCE8s = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVCE8s("Slot Name" , slot.getSlotName())
     txt += FFxKI9(slotName, VVSfxg)
     txt += VVCE8s("Description"  , slot.getFullDescription())
     txt += VVCE8s("Frontend ID"  , slot.frontend_id)
     txt += VVCE8s("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVUZIr(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FF66GF(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFxKI9(line, VVSfxg)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVdOGT(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFGdNj(self, txt)
class CCNHSH(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFrBKf(VV1H0A, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVSAYi = []
  VVSAYi.append(("Settings (All)"   , "Settings_All"   ))
  VVSAYi.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  if VVU5WU:
   VVSAYi.append(("Settings (FHDG-17)" , "Settings_FHDG_17"  ))
  VVSAYi.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVSAYi.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVSAYi.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVSAYi.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVSAYi.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FF4zOZ(self, VVSAYi=VVSAYi)
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FF5gi1(self["myMenu"])
  FFfRto(self)
 def VVjzC3(self):
  global VVWjbN
  VVWjbN = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFkZIr(self, cmd                )
   elif item == "Settings_HotKeys"   : FFkZIr(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFkZIr(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFkZIr(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFkZIr(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFkZIr(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFkZIr(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFkZIr(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CC4wfx(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFrBKf(VV1H0A, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVfDmQ, VVpd60, VV3AQf, camCommand = FFMVjr()
  self.VVpd60 = VVpd60
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVSAYi = []
  VVSAYi.append(("OSCam Files"        , "OSCamFiles"  ))
  VVSAYi.append(("NCam Files"        , "NCamFiles"  ))
  VVSAYi.append(("CCcam Files"        , "CCcamFiles"  ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVSAYi.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVSAYi.append(VVudpG)
  if VVpd60:
   if   "oscam" in VVpd60 : camName = "OSCam"
   elif "ncam"  in VVpd60 : camName = "NCam"
   VVSAYi.append((camName + " Info."      , "camInfo"   ))
   VVSAYi.append((camName + " Live Status"    , "camLiveStatus" ))
   VVSAYi.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVSAYi.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVSAYi.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FF4zOZ(self, VVSAYi=VVSAYi)
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FF5gi1(self["myMenu"])
  FFfRto(self)
 def VVjzC3(self):
  global VVWjbN
  VVWjbN = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCulTQ, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCulTQ, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCulTQ, "cccam"))
   elif item == "OSCamReaders"  : self.VV7cad("os")
   elif item == "NSCamReaders"  : self.VV7cad("n")
   elif item == "camInfo"   : FFPkUh(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFcckN(self.session, CCqqKN.VVbydf)
   elif item == "camLiveReaders" : FFcckN(self.session, CCqqKN.VV7cZH)
   elif item == "camLiveLog"  : FFcckN(self.session, CCqqKN.VVTqXc)
   else       : self.close()
 def VV7cad(self, camPrefix):
  VVprUT = self.VVTXVo(camPrefix)
  if VVprUT:
   VVprUT.sort(key=lambda x: int(x[0]))
   if self.VVpd60 and self.VVpd60.startswith(camPrefix):
    VVJD06 = ("Toggle State", self.VVj5Xn, [camPrefix], "Changing State ...")
   else:
    VVJD06 = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVDKYV  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFEtMz(self, None, header=header, VV06zW=VVprUT, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=26, VVJD06=VVJD06, VVgpgw=True)
 def VVTXVo(self, camPrefix):
  readersFile = self.VVfDmQ + camPrefix + "cam.server"
  VVprUT = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FF66GF(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVprUT.append((str(len(VVprUT) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVprUT:
    FFv5WO(self, "No readers found !")
  else:
   FF7BRF(self, readersFile)
  return VVprUT
 def VVj5Xn(self, VVwuhl, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVfDmQ, camPrefix)
  readerState  = VVwuhl.VVuoNu(1)
  readerLabel  = VVwuhl.VVuoNu(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CC4wfx.VVi9xc(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVwuhl.VVEHtU()
    FFv5WO(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVprUT = self.VVTXVo(camPrefix)
   if VVprUT:
    VVwuhl.VVJs1i(VVprUT)
 @staticmethod
 def VVi9xc(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FF66GF(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFv5WO(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFv5WO(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FF7BRF(SELF, confFile)
   return None
  if not iRequest:
   FFv5WO(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFv5WO(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFv5WO(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCulTQ(Screen):
 def __init__(self, VVTnSR, session, args=0):
  self.skin, self.skinParam = FFrBKf(VV1H0A, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVfDmQ, VVpd60, VV3AQf, camCommand = FFMVjr()
  if   VVTnSR == "ncam" : self.prefix = "n"
  elif VVTnSR == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVSAYi = []
  if self.prefix == "":
   VVSAYi.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVSAYi.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVSAYi.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVSAYi.append(("constant.cw"         , "x_constant_cw" ))
   VVSAYi.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVSAYi.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVSAYi.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVSAYi.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVSAYi.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVSAYi.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVSAYi.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVSAYi.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVSAYi.append(VVudpG)
   VVSAYi.append(("SoftCam.Key"         , "x_SoftCam_Key" ))
   VVSAYi.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVSAYi.append(VVudpG)
   VVSAYi.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVSAYi.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVSAYi.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FF4zOZ(self, VVSAYi=VVSAYi)
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FF5gi1(self["myMenu"])
  FFfRto(self)
 def VVjzC3(self):
  global VVWjbN
  VVWjbN = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFJRme(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFJRme(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFJRme(self, self.VVfDmQ + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFJRme(self, self.VVfDmQ + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVMOcj("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVMOcj("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVMOcj("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVMOcj("cam.provid"        )
   elif item == "x_cam_server"  : self.VVMOcj("cam.server"        )
   elif item == "x_cam_services" : self.VVMOcj("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVMOcj("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVMOcj("cam.user"        )
   elif item == "x_VVjUYT"   : pass
   elif item == "x_SoftCam_Key" : FFJRme(self, self.VVfDmQ + "SoftCam.Key"   )
   elif item == "x_CCcam_cfg"  : FFJRme(self, self.VVfDmQ + "CCcam.cfg"    )
   elif item == "x_VVjUYT"   : pass
   elif item == "x_cam_log"  : FFJRme(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFJRme(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFJRme(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVMOcj(self, fileName):
  FFJRme(self, self.VVfDmQ + self.prefix + fileName)
class CCqqKN(Screen):
 VVbydf  = 0
 VV7cZH = 1
 VVTqXc = 2
 def __init__(self, session, VVfDmQ="", VVpd60="", VV3AQf="", VVCVoH=VVbydf):
  self.skin, self.skinParam = FFrBKf(VVvq1J, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VV3AQf   = VV3AQf
  self.VVCVoH  = VVCVoH
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVfDmQ + VVpd60 + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVpd60 : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVfDmQ, self.camPrefix)
  if self.VVCVoH == self.VVbydf:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVCVoH == self.VV7cZH:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FF4zOZ(self, self.Title, addScrollLabel=True)
  FF313P(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVz5so
  self.onShown.append(self.VVAJmk)
  self.onClose.append(self.onExit)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  self["myLabel"].VVC5L2(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFZe3q(self)
  self.VVz5so()
 def onExit(self):
  self.timer.stop()
 def VVATYB(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV9nNM)
  except:
   self.timer.callback.append(self.VV9nNM)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFlFRp(self, "Started", 1000)
 def VVthVZ(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VV9nNM)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFlFRp(self, "Stopped", 1000)
 def VVz5so(self):
  if self.timerRunning:
   self.VVthVZ()
  else:
   self.VVATYB()
   if self.VVCVoH == self.VVbydf or self.VVCVoH == self.VV7cZH:
    if self.VVCVoH == self.VVbydf : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CC4wfx.VVi9xc(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFYJiO(self.VVRBqc)
    else:
     self.close()
   else:
    self.VVqYp4()
 def VV9nNM(self):
  if self.timerRunning:
   if   self.VVCVoH == self.VVbydf : self.VVDMuf()
   elif self.VVCVoH == self.VV7cZH : self.VVDMuf()
   else            : self.VVqYp4()
 def VVqYp4(self):
  if fileExists(self.VV3AQf):
   fTime = FFt8n3(os.path.getmtime(self.VV3AQf))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVRDEs(), VVTzbD=VVCIY6)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VV3AQf)
 def VVRBqc(self):
  self.VVDMuf()
 def VVDMuf(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFxKI9("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VV8tYH))
   self.camWebIfErrorFound = True
   self.VVthVZ()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVCVoH == self.VVbydf : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFxKI9("Error while parsing data elements !\n\nError = %s" % str(e), VVxd7c)
   self.camWebIfErrorFound = True
   self.VVthVZ()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVrmg3(root)
  self["myLabel"].setText(txt, VVTzbD=VVCIY6)
  self["myBar"].setText("Last Update : %s" % FFEuaP())
 def VVrmg3(self, rootElement):
  def VVCE8s(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVCVoH == self.VVbydf:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFxKI9(status, VV3SOs)
    else          : status = FFxKI9(status, VVxd7c)
    txt += VVjUYT + "\n"
    txt += VVCE8s("Name"  , name)
    txt += VVCE8s("Description" , desc)
    txt += VVCE8s("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVCE8s("Protocol" , protocol)
    txt += VVCE8s("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFxKI9("Yes", VV3SOs)
    else    : enabTxt = FFxKI9("No", VVxd7c)
    txt += VVjUYT + "\n"
    txt += VVCE8s("Label"  , label)
    txt += VVCE8s("Protocol" , protocol)
    txt += VVCE8s("Enabled" , enabTxt)
  return txt
 def VVRDEs(self):
  wordsDict = self.VVL6hH()
  color = [ VVSfxg, VVZ7zN, VV3SOs, VVxd7c, VV9YfT, VVHaNU]
  lines = FFs4zJ("tail -n %d %s" % (100, self.VV3AQf))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VV8tYH + line[:19] + VVIgRq + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVTIP5 + line[ndx + 3:] + VVIgRq
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVSfxg + line[ndx + 8 : ndx1 + 4] + VVIgRq + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVIgRq)
   elif line.startswith("----") or ">>" in line:
    line = FFxKI9(line, VVSfxg)
   txt += line + "\n"
  return txt
 def VVL6hH(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FF66GF(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCJEvi(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFrBKf(VV1H0A, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVSAYi = []
  VVSAYi.append(("Backup Channels"    , "VVI9tM"   ))
  VVSAYi.append(("Restore Channels"    , "Restore_Channels"  ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Backup SoftCAM Files"   , "VVNlPe" ))
  VVSAYi.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVSAYi.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVSAYi.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Backup Network Settings"  , "VV6k3U"   ))
  VVSAYi.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVU5WU:
   VVSAYi.append(VVudpG)
   VVSAYi.append((VV8tYH + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VVtRyh"   ))
   VVSAYi.append((VV3SOs + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVl3xf) , "createMyIpk"   ))
   VVSAYi.append((VV3SOs + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVl3xf) , "createMyDeb"   ))
   VVSAYi.append((VV9YfT + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVSAYi.append((VV9YfT + "Decode %s Crash Report"   % PLUGIN_NAME     , "VV4cVw" ))
  FF4zOZ(self, VVSAYi=VVSAYi)
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FF5gi1(self["myMenu"])
  FFfRto(self)
 def VVjzC3(self):
  global VVWjbN
  VVWjbN = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVI9tM"    : self.VVI9tM()
   elif item == "Restore_Channels"    : self.VVC7hW("channels_backup*.tar.gz", self.VVS1hq)
   elif item == "VVNlPe"   : self.VVNlPe()
   elif item == "Restore_SoftCAM_Files"  : self.VVC7hW("softcam_backup*.tar.gz", self.VV5X28)
   elif item == "Backup_TunerDiSEqC"   : self.VVcmyj("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVC7hW("tuner_backup*.backup", boundFunction(self.VVa61F, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVcmyj("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVC7hW("hotkey_*backup*.backup", boundFunction(self.VVa61F, "misc"))
   elif item == "VV6k3U"    : self.VV6k3U()
   elif item == "Restore_Network"    : self.VVC7hW("network_backup*.tar.gz", self.VVDp8A)
   elif item == "VVtRyh"     : FFhdnr(self, boundFunction(FF8MfV, self, boundFunction(CCJEvi.VVtRyh, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVgZxb(False)
   elif item == "createMyDeb"     : self.VVgZxb(True)
   elif item == "createMyTar"     : self.VVAvbU()
   elif item == "VV4cVw"   : self.VV4cVw()
 @staticmethod
 def VVtRyh(SELF):
  OBF_Path = VVDCEs + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVDCEs, VVwyo7, VVl3xf)
   if err : FFv5WO(SELF, err)
   else : FFGdNj(SELF, txt)
  else:
   FF7BRF(SELF, OBF_Path)
 def VVgZxb(self, VVLjgp):
  OBF_Path = VVDCEs + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFv5WO(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVDCEs)
  os.system("mv -f %s %s" % (VVDCEs + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVDCEs + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVDCEs + "plugin.py"))
  self.session.openWithCallback(self.VVgZxb1, boundFunction(CCiCs1, path=VVDCEs, VVLjgp=VVLjgp))
 def VVgZxb1(self):
  os.system("mv -f %s %s" % (VVDCEs + "OBF/main.py"  , VVDCEs))
  os.system("mv -f %s %s" % (VVDCEs + "OBF/plugin.py" , VVDCEs))
 def VV4cVw(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFv5WO(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFv5WO(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVjwiS("%s*.list" % path)
  if err:
   FF7BRF(self, path + "*.list")
   return
  srcF, err = self.VVjwiS("%s*main_final.py" % path)
  if err:
   FF7BRF(self, path + "*.final.py")
   return
  VV06zW = []
  for f in files:
   f = os.path.basename(f)
   VV06zW.append((f, f))
  FF3fIR(self, boundFunction(self.VVnwwP, path, codF, srcF), VVSAYi=VV06zW)
 def VVnwwP(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FF7BRF(self, logF)
   else     : FF8MfV(self, boundFunction(self.VVXJ7l, logF, codF, srcF))
 def VVXJ7l(self, logF, codF, srcF):
  lst  = []
  lines = FF66GF(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFv5WO(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVNp2k(lst, logF, newLogF)
  totSrc  = self.VVNp2k(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFGdNj(self, txt)
 def VVjwiS(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVNp2k(self, lst, f1, f2):
  txt = FFqhNI(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVAvbU(self):
  VV06zW = []
  VV06zW.append("%s%s" % (VVDCEs, "*.py"))
  VV06zW.append("%s%s" % (VVDCEs, "*.png"))
  VV06zW.append("%s%s" % (VVDCEs, "*.xml"))
  VV06zW.append("%s"  % (VVrF44))
  FFbT0Q(self, VV06zW, "%s_%s" % (PLUGIN_NAME, VVwyo7), addTimeStamp=False)
 def VVI9tM(self):
  path1 = VVeXaf
  path2 = "/etc/tuxbox/"
  VV06zW = []
  VV06zW.append("%s%s" % (path1, "*.tv"))
  VV06zW.append("%s%s" % (path1, "*.radio"))
  VV06zW.append("%s%s" % (path1, "*list"))
  VV06zW.append("%s%s" % (path1, "lamedb*"))
  VV06zW.append("%s%s" % (path2, "*.xml"))
  FFbT0Q(self, VV06zW, "channels_backup", addTimeStamp=True)
 def VVNlPe(self):
  VV06zW = []
  VV06zW.append("/etc/tuxbox/config/")
  VV06zW.append("/usr/keys/")
  VV06zW.append("/usr/scam/")
  VV06zW.append("/etc/CCcam.cfg")
  FFbT0Q(self, VV06zW, "softcam_backup", addTimeStamp=True)
 def VV6k3U(self):
  VV06zW = []
  VV06zW.append("/etc/hostname")
  VV06zW.append("/etc/default_gw")
  VV06zW.append("/etc/resolv.conf")
  VV06zW.append("/etc/wpa_supplicant*.conf")
  VV06zW.append("/etc/network/interfaces")
  VV06zW.append("/etc/enigma2/nameserversdns.conf")
  FFbT0Q(self, VV06zW, "network_backup", addTimeStamp=True)
 def VVS1hq(self, fileName):
  if fileName:
   FFhdnr(self, boundFunction(self.VVMURU, fileName), "Overwrite current channels ?")
 def VVMURU(self, fileName):
  path = "%s%s" % (VVVPVZ, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCHa4g.VVVEGg()
   lamedb5File, diabled5File = CCHa4g.VVQQI5()
   cmd = ""
   cmd += FFMugq("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFMugq("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FF7jBe()
   if res == 0 : FFLnSq(self, "Channels Restored.")
   else  : FFv5WO(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FF7BRF(self, path)
 def VV5X28(self, fileName):
  if fileName:
   FFhdnr(self, boundFunction(self.VVNKEj, fileName), "Overwrite SoftCAM files ?")
 def VVNKEj(self, fileName):
  fileName = "%s%s" % (VVVPVZ, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVjUYT
   note = "You may need to restart your SoftCAM."
   FFsHJ2(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFA6Lm(note, VVSfxg), sep))
  else:
   FF7BRF(self, fileName)
 def VVDp8A(self, fileName):
  if fileName:
   FFhdnr(self, boundFunction(self.VVlz1v, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVlz1v(self, fileName):
  fileName = "%s%s" % (VVVPVZ, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFl3Il(self,  cmd)
  else:
   FF7BRF(self, fileName)
 def VVC7hW(self, pattern, callBackFunction, isTuner=False):
  title = FFsbex()
  if pathExists(VVVPVZ):
   myFiles = iGlob("%s%s" % (VVVPVZ, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VV06zW = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VV06zW.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VViqfZ = ("Sat. List", self.VVM1sx)
    else  : VViqfZ = None
    VVEbC5 = ("Delete File", boundFunction(self.VVUAKz, boundFunction(self.VVC7hW, pattern, callBackFunction, isTuner)))
    FF3fIR(self, callBackFunction, title=title, VVSAYi=VV06zW, VViqfZ=VViqfZ, VVEbC5=VVEbC5)
   else:
    FFv5WO(self, "No files found in:\n\n%s" % VVVPVZ, title)
  else:
   FFv5WO(self, "Path not found:\n\n%s" % VVVPVZ, title)
 def VVUAKz(self, cbFnc, VVMsOjObj, path):
  FFhdnr(self, boundFunction(self.VVKdbn, cbFnc, VVMsOjObj, path), "Delete this file ?\n\n%s" % path)
 def VVKdbn(self, cbFnc, VVMsOjObj, path):
  os.system(FFMugq("rm -f '%s%s'" % (VVVPVZ, path)))
  cbFnc()
  VVMsOjObj.cancel()
 def VVcmyj(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CC4384()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVw4XQ, filePrefix))
 def VVw4XQ(self, filePrefix, result, retval):
  title = FFsbex()
  if pathExists(VVVPVZ):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFv5WO(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVVPVZ, filePrefix, FFS6oF())
    try:
     VV06zW = str(result.strip()).split()
     if VV06zW:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VV06zW:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVjUYT, FFxKI9(fName, VVSfxg), VVjUYT)
       FFGdNj(self, txt, title=title, VVTzbD=VVCIY6)
      else:
       FFv5WO(self, "File creation failed!", title)
     else:
      FFv5WO(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFMugq("rm %s" % fName))
     FFv5WO(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFMugq("rm %s" % fName))
     FFv5WO(self, "Error while writing file.")
  else:
   FFv5WO(self, "Path not found:\n\n%s" % VVVPVZ, title)
 def VVa61F(self, mode, path):
  if path:
   path = "%s%s" % (VVVPVZ, path)
   if fileExists(path):
    lines = FF66GF(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFhdnr(self, boundFunction(self.VVO4kN, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFrHkO(self, path, title=FFsbex())
   else:
    FF7BRF(self, path)
 def VVO4kN(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVgPsE = []
  VVgPsE.append("echo -e 'Reading current settings ...'")
  VVgPsE.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVgPsE.append("echo -e 'Preparing new settings ...'")
  VVgPsE.append(settingsLines)
  VVgPsE.append("echo -e 'Applying new settings ...'")
  VVgPsE.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFDnwG(self, VVgPsE)
 def VVM1sx(self, VVMsOjObj, path):
  if not path:
   return
  path = VVVPVZ + path
  if not fileExists(path):
   FF7BRF(self, path)
   return
  txt = FFqhNI(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VV06zW  = []
   for item in satList:
    VV06zW.append("%s\t%s" % (item[0], FFknK4(item[1])))
   FFGdNj(self, VV06zW, title="  Satellites List")
  else:
   FFv5WO(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCGCq6(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFrBKf(VV1H0A, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVSAYi = []
  VVSAYi.append(("Plugins Browser List"       , "VVLpyJ"   ))
  VVSAYi.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVSAYi.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVSAYi.append(("Remove Packages (show all)"     , "VVHEahsAll"   ))
  VVSAYi.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Update List of Available Packages"   , "VVeSZU"   ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Packaging Tool"        , "VVK5Wp"    ))
  VVSAYi.append(("Packages Feeds"        , "packagesFeeds"    ))
  FF4zOZ(self, VVSAYi=VVSAYi)
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FF5gi1(self["myMenu"])
  FFfRto(self)
 def VVjzC3(self):
  global VVWjbN
  VVWjbN = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVLpyJ"   : self.VVLpyJ()
   elif item == "pluginsMenus"     : self.VVK80i(0)
   elif item == "pluginsStartup"    : self.VVK80i(1)
   elif item == "pluginsDirList"    : self.VVyrGo()
   elif item == "downloadInstallPackages"  : FF8MfV(self, boundFunction(self.VVpwnb, 0, ""))
   elif item == "VVHEahsAll"   : FF8MfV(self, boundFunction(self.VVpwnb, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FF8MfV(self, boundFunction(self.VVpwnb, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVeSZU"   : self.VVeSZU()
   elif item == "VVK5Wp"    : self.VVK5Wp()
   elif item == "packagesFeeds"    : self.VV4TRY()
   else          : self.close()
 def VVyrGo(self):
  extDirs  = FF5NSf(VV1Enj)
  sysDirs  = FF5NSf(VVuisN)
  VV06zW  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VV06zW.append((item, VV1Enj + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VV06zW.append((item, VVuisN + item))
  if VV06zW:
   VV06zW = sorted(VV06zW, key=lambda x: x[0].lower())
   VV8khl = ("Package Info.", self.VVRicF, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFEtMz(self, None, header=header, VV06zW=VV06zW, VVTS0u=widths, VVp74Q=28, VV8khl=VV8khl)
  else:
   FFv5WO(self, "Nothing found!")
 def VVRicF(self, VVwuhl, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VV1Enj) : loc = "extensions"
  elif path.startswith(VVuisN) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVvmHH(package)
  else:
   FFv5WO(self, "No info!")
 def VV4TRY(self):
  pkg = FFUpZG()
  if pkg : FFkZIr(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFXixL(self)
 def VVLpyJ(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVCE8s(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVjUYT + "\n"
    txt += VVCE8s("Number"   , str(c))
    txt += VVCE8s("Name"   , FFxKI9(str(p.name), VVSfxg))
    txt += VVCE8s("Path"  , p.path  )
    txt += VVCE8s("Description" , p.description )
    txt += VVCE8s("Icon"  , p.iconstr  )
    txt += VVCE8s("Wakeup Fnc" , p.wakeupfnc )
    txt += VVCE8s("NeedsRestart", p.needsRestart)
    txt += VVCE8s("Internal" , p.internal )
    txt += VVCE8s("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFGdNj(self, txt)
 def VVK80i(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VV06zW = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VV06zW.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VV06zW:
   VV06zW.sort(key=lambda x: x[0].lower())
   header  = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths  = (19  , 25 , 20  , 27   , 9  )
   FFEtMz(self, None, title=title, header=header, VV06zW=VV06zW, VVTS0u=widths, VVp74Q=26)
  else:
   FFv5WO(self, "Nothing Found", title=title)
 def VVeSZU(self):
  cmd = FFyxGo(VVzgKA, "")
  if cmd : FFl3Il(self, cmd, checkNetAccess=True)
  else : FFXixL(self)
 def VVK5Wp(self):
  pkg = FFUpZG()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFLnSq(self, txt)
 def VVpwnb(self, mode, grep, VVwuhl=None, title=""):
  if   mode == 0: cmd = FFyxGo(VVD6iv    , grep)
  elif mode == 1: cmd = FFyxGo(VVTn9i , grep)
  elif mode == 2: cmd = FFyxGo(VVTn9i , grep)
  if not cmd:
   FFXixL(self)
   return
  VVprUT = FFs4zJ(cmd)
  if not VVprUT:
   if VVwuhl: VVwuhl.VVEHtU()
   FFv5WO(self, "No packages found!")
   return
  elif len(VVprUT) == 1 and VVprUT[0] == VVLbL3:
   FFv5WO(self, VVLbL3)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VV06zW  = []
  for item in VVprUT:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VV06zW.append((name, package, version))
  if mode > 0:
   extensions = FFs4zJ("ls %s -l | grep '^d' | awk '{print $9}'" % VV1Enj)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VV06zW:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VV06zW.append((name, VV1Enj + item, "-"))
   systemPlugins = FFs4zJ("ls %s -l | grep '^d' | awk '{print $9}'" % VVuisN)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VV06zW:
      if item.lower() == row[0].lower():
       break
     else:
      VV06zW.append((item, VVuisN + item, "-"))
  if not VV06zW:
   FFv5WO(self, "No packages found!")
   return
  if VVwuhl:
   VV06zW.sort(key=lambda x: x[0].lower())
   VVwuhl.VVJs1i(VV06zW, title)
  else:
   widths = (20, 50, 30)
   VVJD06 = None
   VVulZM = None
   if mode == 0:
    VVSxFV = ("Install" , self.VVBi1V   , [])
    VVJD06 = ("Download" , self.VV1DgK   , [])
    VVulZM = ("Filter"  , self.VV8WJ2 , [])
   elif mode == 1:
    VVSxFV = ("Uninstall", self.VVHEah, [])
   elif mode == 2:
    VVSxFV = ("Uninstall", self.VVHEah, [])
    widths= (18, 57, 25)
   VV06zW = sorted(VV06zW, key=lambda x: x[0].lower())
   VV8khl = ("Package Info.", self.VVsmxk, [])
   header   = ("Name" ,"Package" , "Version" )
   FFEtMz(self, None, header=header, VV06zW=VV06zW, VVTS0u=widths, VVp74Q=28, VVSxFV=VVSxFV, VVJD06=VVJD06, VV8khl=VV8khl, VVulZM=VVulZM, VVBa4S=self.lastSelectedRow
     , VVM7V1="#22110011", VVUL9C="#22191111", VVehrL="#22191111", VVTG9d="#00003030", VVCgV5="#00333333")
 def VVsmxk(self, VVwuhl, title, txt, colList):
  package = colList[1]
  self.VVvmHH(package)
 def VV8WJ2(self, VVwuhl, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVSAYi = []
  VVSAYi.append(("All Packages", "all"))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVSAYi.append(VVudpG)
  for word in words:
   VVSAYi.append((word, word))
  FF3fIR(self, boundFunction(self.VV9s0Q, VVwuhl), VVSAYi=VVSAYi, title="Select Filter")
 def VV9s0Q(self, VVwuhl, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FF8MfV(VVwuhl, boundFunction(self.VVpwnb, 0, grep, VVwuhl, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVHEah(self, VVwuhl, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VV1Enj, VVuisN)):
   FFhdnr(self, boundFunction(self.VVBfN1, VVwuhl, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVSAYi = []
   VVSAYi.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVSAYi.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVSAYi.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FF3fIR(self, boundFunction(self.VVvXra, VVwuhl, package), VVSAYi=VVSAYi)
 def VVBfN1(self, VVwuhl, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVyW8b)
  FFl3Il(self, cmd, VVhQIf=boundFunction(self.VV8FoP, VVwuhl))
 def VVvXra(self, VVwuhl, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVDFgV
   elif item == "remove_ForceRemove"  : cmdOpt = VVWHml
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVN6V0
   FFhdnr(self, boundFunction(self.VVCMQZ, VVwuhl, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVCMQZ(self, VVwuhl, package, cmdOpt):
  self.lastSelectedRow = VVwuhl.VVZMuy()
  cmd = FFyov6(cmdOpt, package)
  if cmd : FFl3Il(self, cmd, VVhQIf=boundFunction(self.VV8FoP, VVwuhl))
  else : FFXixL(self)
 def VV8FoP(self, VVwuhl):
  VVwuhl.cancel()
  FF13j6()
 def VVBi1V(self, VVwuhl, title, txt, colList):
  package  = colList[1]
  VVSAYi = []
  VVSAYi.append(("Install Package"         , "install_CheckVersion" ))
  VVSAYi.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVSAYi.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VVSAYi.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVSAYi.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FF3fIR(self, boundFunction(self.VVOIOv, package), VVSAYi=VVSAYi)
 def VVOIOv(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVaBvq
   elif item == "install_ForceReinstall" : cmdOpt = VVi2Z7
   elif item == "install_ForceOverwrite" : cmdOpt = VVWDTt
   elif item == "install_ForceDowngrade" : cmdOpt = VVPoBH
   elif item == "install_IgnoreDepends" : cmdOpt = VVmeGz
   FFhdnr(self, boundFunction(self.VVQ7fd, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVQ7fd(self, package, cmdOpt):
  cmd = FFyov6(cmdOpt, package)
  if cmd : FFl3Il(self, cmd, VVhQIf=FF13j6, checkNetAccess=True)
  else : FFXixL(self)
 def VV1DgK(self, VVwuhl, title, txt, colList):
  package  = colList[1]
  FFhdnr(self, boundFunction(self.VVFrvx, package), "Download Package ?\n\n%s" % package)
 def VVFrvx(self, package):
  if FFStZp():
   cmd = FFyov6(VVF0kb, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFA6Lm(success, VV3SOs))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFA6Lm(fail, VVxd7c))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFl3Il(self, cmd, VVZ6QB=[VVxd7c, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFXixL(self)
  else:
   FFv5WO(self, "No internet connection !")
 def VVvmHH(self, package):
  infoCmd  = FFyov6(VVRoHT, package)
  filesCmd = FFyov6(VVHM4T, package)
  listInstCmd = FFyxGo(VVTn9i, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFMEmL(VVSfxg)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFA6Lm(notInst, VV8tYH))
   cmd += "else "
   cmd +=   FF5oB0("System Info", VVSfxg)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FF5oB0("Related Files", VVSfxg)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFRgi8(self, cmd)
  else:
   FFXixL(self)
class CCHa4g(Screen):
 VVf6mN  = 0
 VVuxXg = 1
 VVc92X  = 2
 VV3fUK  = 3
 VVOkEr = 4
 VV7MRV = 5
 VVU8sI = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFrBKf(VV1H0A, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVyyZ2 = None
  self.lastfilterUsed  = None
  VVSAYi = self.VVycO4()
  FF4zOZ(self, VVSAYi=VVSAYi, title="Services/Channels")
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self["myMenu"].setList(self.VVycO4())
  FF5gi1(self["myMenu"])
  FFfRto(self)
 def VVycO4(self):
  VVSAYi = []
  VVSAYi.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVSAYi.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Services (Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVSAYi.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVSAYi.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVSAYi.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVSAYi.append(("Services with PIcons for the System"  , "VVIboV"     ))
  VVSAYi.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVSAYi.append(VVudpG)
  lamedbFile, disabledFile = CCHa4g.VVVEGg()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVSAYi.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVSAYi.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVSAYi.append(("Reset Parental Control Settings"   , "VVlaK7"    ))
  VVSAYi.append(("Delete Channels with no names"   , "VVy27K"    ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Reload Channels and Bouquets"    , "VVuhrG"      ))
  return VVSAYi
 def VVjzC3(self):
  global VVWjbN
  VVWjbN = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFJDYM(self)
   elif item == "currentServiceInfo"     : FFlYRO(self, fncMode=CCA5BL.VVagZT)
   elif item == "TranspondersStats"     : FF8MfV(self, self.VV3Ztf     )
   elif item == "lameDB_allChannels_with_refCode"  : FF8MfV(self, self.VVB9aZ )
   elif item == "lameDB_allChannels_with_tranaponder" : FF8MfV(self, self.VVrZ21)
   elif item == "lameDB_allChannels_with_details"  : FF8MfV(self, self.VVnLO8 )
   elif item == "parentalControlChannels"    : FF8MfV(self, self.VVjfvW   )
   elif item == "showHiddenChannels"     : FF8MfV(self, self.VVqRI2     )
   elif item == "VVIboV"     : FF8MfV(self, self.VVyVAu     )
   elif item == "servicesWithMissingPIcons"   : FF8MfV(self, self.VVlXhc   )
   elif item == "enableHiddenChannels"     : self.VVj1Lk(True)
   elif item == "disableHiddenChannels"    : self.VVj1Lk(False)
   elif item == "VVlaK7"    : FFhdnr(self, self.VVlaK7, "Reset and Restart ?" )
   elif item == "VVy27K"    : FF8MfV(self, self.VVy27K)
   elif item == "VVuhrG"      : FF8MfV(self, boundFunction(CCHa4g.VVuhrG, self))
   else            : self.close()
 @staticmethod
 def VVuhrG(SELF):
  FF7jBe()
  FFLnSq(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVB9aZ(self):
  self.VVyyZ2 = None
  self.lastfilterUsed  = None
  self.filterObj   = CCWTeq(self)
  VVprUT = CCHa4g.VVzJJ1(self, self.VVf6mN)
  if VVprUT:
   VVprUT.sort(key=lambda x: x[0].lower())
   VVd2cp  = ("Zap"   , self.VVYz1i     , [])
   VVvxfu = (""    , self.VVKbyL   , [])
   VV8khl = ("Options"  , self.VVRW6a , [])
   VVJD06 = ("Current Service", self.VVsIZS , [])
   VVulZM = ("Filter"   , self.VVWfOQ  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVDKYV  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFEtMz(self, None, header=header, VV06zW=VVprUT, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=26, VVd2cp=VVd2cp, VVvxfu=VVvxfu, VVJD06=VVJD06, VV8khl=VV8khl, VVulZM=VVulZM)
 def VVrZ21(self):
  self.VVyyZ2 = None
  self.lastfilterUsed  = None
  self.filterObj   = CCWTeq(self)
  VVprUT = CCHa4g.VVzJJ1(self, self.VVuxXg)
  if VVprUT:
   VVprUT.sort(key=lambda x: x[0].lower())
   VVd2cp  = ("Zap"   , self.VVYz1i      , [])
   VVvxfu = (""    , self.VVKbyL    , [])
   VVJD06 = ("Current Service", self.VVsIZS  , [])
   VV8khl = ("Options"  , self.VVI29p , [])
   VVulZM = ("Filter"   , self.VVsp0o  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVDKYV  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFEtMz(self, None, header=header, VV06zW=VVprUT, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=26, VVd2cp=VVd2cp, VVvxfu=VVvxfu, VVJD06=VVJD06, VV8khl=VV8khl, VVulZM=VVulZM)
 def VVRW6a(self, VVwuhl, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel  = CC34Ma(self, VVwuhl, 3)
  mSel.VV90IY(servName, refCode, pcState, hidState)
 def VVI29p(self, VVwuhl, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CC34Ma(self, VVwuhl, 3)
  mSel.VVDKO1(servName, refCode)
 def VVkGaB(self, VVwuhl, refCode, isAddToBlackList):
  VVwuhl.VVs3je("Processing ...")
  FFYJiO(boundFunction(self.VVID4c, VVwuhl, [refCode], isAddToBlackList))
 def VVn0I1(self, VVwuhl, isAddToBlackList):
  refCodeList = VVwuhl.VVVZHF(3)
  if not refCodeList:
   FFv5WO(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVwuhl.VVs3je("Processing ...")
  FFYJiO(boundFunction(self.VVID4c, VVwuhl, refCodeList, isAddToBlackList))
 def VVID4c(self, VVwuhl, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVHfFQ, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVHfFQ):
   lines = FF66GF(VVHfFQ)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVHfFQ, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVwuhl.VVugpB
   if isMulti:
    self.VVQe1Z(VVwuhl, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VV7yqS(VVwuhl, refCode)
    VVwuhl.VVEHtU()
  else:
   VVwuhl.VVT6LE("No changes")
 def VVkO6A(self, VVwuhl, refCode, isHide):
  title = "Change Hidden State"
  if FFJPAH(refCode):
   VVwuhl.VVs3je("Processing ...")
   ret = FFrRU9(refCode, isHide)
   if ret : FF8MfV(self, boundFunction(self.VV7yqS, VVwuhl, refCode))
   else : FFv5WO(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFv5WO(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VV7yqS(self, VVwuhl, refCode):
  VVprUT = CCHa4g.VVzJJ1(self, self.VVf6mN, VVGrol=[3, [refCode], False])
  done = False
  if VVprUT:
   data = VVprUT[0]
   if data[3] == refCode:
    done = VVwuhl.VVVSNs(data)
  if not done:
   self.VVyoP5(VVwuhl, VVwuhl.VVsOzc(), self.VVf6mN)
  VVwuhl.VVEHtU()
 def VVQe1Z(self, VVwuhl, totRefCodes):
  VVprUT = CCHa4g.VVzJJ1(self, self.VVf6mN, VVGrol=self.VVyyZ2)
  VVwuhl.VVJs1i(VVprUT)
  VVwuhl.VVIY29(False)
  VVwuhl.VVT6LE("%d Processed" % totRefCodes)
 def VVUSxJ(self, VVwuhl, isHide):
  refCodeList = VVwuhl.VVVZHF(3)
  if not refCodeList:
   FFv5WO(self, "Nothing selected", title="Change Hidden State")
   return
  VVwuhl.VVs3je("Processing ...")
  FFYJiO(boundFunction(self.VVOEJh, VVwuhl, refCodeList, isHide))
 def VVOEJh(self, VVwuhl, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFrRU9(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   db = eDVBDB.getInstance()
   if db:
    db.saveServicelist()
    db.reloadServicelist()
    db.reloadBouquets()
   self.VVQe1Z(VVwuhl, len(refCodeList))
  else:
   VVwuhl.VVT6LE("No changes")
 def VVWfOQ(self, VVwuhl, title, txt, colList):
  self.filterObj.VVp2Zw(1, VVwuhl, 2, boundFunction(self.VVGNNJ, VVwuhl))
 def VVGNNJ(self, VVwuhl, item):
  self.VVTypG(VVwuhl, item, 2, self.VVf6mN)
 def VVsp0o(self, VVwuhl, title, txt, colList):
  self.filterObj.VVp2Zw(2, VVwuhl, 4, boundFunction(self.VVXDLm, VVwuhl))
 def VVXDLm(self, VVwuhl, item):
  self.VVTypG(VVwuhl, item, 4, self.VVuxXg)
 def VVYVL6(self, VVwuhl, title, txt, colList):
  self.filterObj.VVp2Zw(0, VVwuhl, 4, boundFunction(self.VVFdlL, VVwuhl))
 def VVFdlL(self, VVwuhl, item):
  self.VVTypG(VVwuhl, item, 4, self.VVc92X)
 def VVTypG(self, VVwuhl, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVwuhl.VVuoNu(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVyyZ2 = None
  else:
   words, asPrefix = CCWTeq.VV6DTY(words)
   self.VVyyZ2 = [col, words, asPrefix]
  if words: FF8MfV(self, boundFunction(self.VVyoP5, VVwuhl, title, mode), title="Reading Services ...")
  else : FFlFRp(VVwuhl, "Incorrect filter", 2000)
 def VVyoP5(self, VVwuhl, title, mode):
  VVprUT = CCHa4g.VVzJJ1(self, mode, VVGrol=self.VVyyZ2, VV2EYo=False)
  if VVprUT:
   VVprUT.sort(key=lambda x: x[0].lower())
   VVwuhl.VVJs1i(VVprUT, title)
  else:
   VVwuhl.VVEHtU()
   FFlFRp(VVwuhl, "Not found!", 1500)
 def VVuTBM(self, VV06zW, VVd2cp=None, VVvxfu=None, VVSxFV=None, VVJD06=None, VV8khl=None, VVulZM=None):
  VVJD06 = ("Current Service", self.VVsIZS, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVDKYV = (LEFT  , LEFT  , CENTER, LEFT    )
  FFEtMz(self, None, header=header, VV06zW=VV06zW, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=26, VVd2cp=VVd2cp, VVvxfu=VVvxfu, VVSxFV=VVSxFV, VVJD06=VVJD06, VV8khl=VV8khl, VVulZM=VVulZM)
 def VVsIZS(self, VVwuhl, title, txt, colList):
  self.VVXYMQ(VVwuhl)
 def VVnxMZ(self, VVwuhl, title, txt, colList):
  self.VVXYMQ(VVwuhl, True)
 def VVXYMQ(self, VVwuhl, isFromDetails=False):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
  if refCode:
   if isFromDetails:
    chName  = info.getName()
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVwuhl.VVycrI(colDict, VV6xfF=True)
   else:
    VVwuhl.VV5o1g(3, refCode, True)
   return
  FFv5WO(self, "Colud not read current Reference Code !")
 def VVnLO8(self):
  self.VVyyZ2 = None
  self.lastfilterUsed  = None
  self.filterObj   = CCWTeq(self)
  VVprUT = CCHa4g.VVzJJ1(self, self.VVc92X)
  if VVprUT:
   VVprUT.sort(key=lambda x: x[0].lower())
   VVvxfu = (""    , self.VVEsN8 , []      )
   VVJD06 = ("Current Service", self.VVnxMZ  , []      )
   VVulZM = ("Filter"   , self.VVYVL6   , [], "Loading Filters ..." )
   VVd2cp  = ("Zap"   , self.VVdzVp      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVDKYV  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFEtMz(self, None, header=header, VV06zW=VVprUT, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=26, VVd2cp=VVd2cp, VVvxfu=VVvxfu, VVJD06=VVJD06, VVulZM=VVulZM)
 def VVEsN8(self, VVwuhl, title, txt, colList):
  refCode  = self.VV5jKX(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFlYRO(self, fncMode=CCA5BL.VVCY9I, refCode=refCode, chName=chName, text=txt)
 def VVdzVp(self, VVwuhl, title, txt, colList):
  refCode = self.VV5jKX(colList)
  FFY7Np(self, refCode)
 def VVYz1i(self, VVwuhl, title, txt, colList):
  FFY7Np(self, colList[3])
 def VV5jKX(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVzJJ1(SELF, mode, VVGrol=None, VV2EYo=True, VVGuAm=True):
  lamedbFile, disabledFile = CCHa4g.VVVEGg()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVGrol:
    filterCol = VVGrol[0]
    filterWords = VVGrol[1]
    asPrefix = VVGrol[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCHa4g.VVf6mN:
    blackList = None
    if fileExists(VVHfFQ):
     blackList = FF66GF(VVHfFQ)
     if blackList:
      blackList = set(blackList)
   elif mode == CCHa4g.VVuxXg:
    tp = CCJR3E()
   VVrl4a, VVPj0m = FFtCwD()
   tagFound  = False
   if mode in (CCHa4g.VV7MRV, CCHa4g.VVU8sI):
    VVprUT = {}
   else:
    VVprUT = []
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFNUup(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CCHa4g.VVc92X:
        if sTypeInt in VVrl4a:
         STYPE = VVPj0m[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVprUT.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVprUT.append(tRow)
        else:
         VVprUT.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCHa4g.VV7MRV:
         VVprUT[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCHa4g.VVU8sI:
         VVprUT[chName] = refCode
        elif mode == CCHa4g.VVf6mN:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVprUT.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVprUT.append(tRow)
         else:
          VVprUT.append(tRow)
        elif mode == CCHa4g.VVuxXg:
         if sTypeInt in VVrl4a:
          STYPE = VVPj0m[sTypeInt]
         freq, pol, fec, sr, syst = tp.VV1fjX(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVprUT.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVprUT.append(tRow)
         else:
          VVprUT.append(tRow)
        elif mode == CCHa4g.VV3fUK:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VVprUT.append((chName, chProv, sat, refCode))
        elif mode == CCHa4g.VVOkEr:
         VVprUT.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VVprUT and VV2EYo:
    FFv5WO(SELF, "No services found!")
   return VVprUT
  else:
   if VVGuAm:
    FF7BRF(SELF, lamedbFile)
   return None
 def VVjfvW(self):
  if fileExists(VVHfFQ):
   lines = FF66GF(VVHfFQ)
   if lines:
    newRows  = []
    VVprUT = CCHa4g.VVzJJ1(self, self.VVOkEr)
    if VVprUT:
     lines = set(lines)
     for item in VVprUT:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVprUT = newRows
      VVprUT.sort(key=lambda x: x[0].lower())
      VVvxfu = ("", self.VVKbyL, [])
      VVd2cp = ("Zap", self.VVYz1i, [])
      self.VVuTBM(VV06zW=VVprUT, VVd2cp=VVd2cp, VVvxfu=VVvxfu)
     else:
      FFGdNj(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVprUT)))
   else:
    FFLnSq(self, "No active Parental Control services.", FFsbex())
  else:
   FF7BRF(self, VVHfFQ)
 def VVqRI2(self):
  VVprUT = CCHa4g.VVzJJ1(self, self.VV3fUK)
  if VVprUT:
   VVprUT.sort(key=lambda x: x[0].lower())
   VVvxfu = ("" , self.VVKbyL, [])
   VVd2cp  = ("Zap", self.VVYz1i, [])
   self.VVuTBM(VV06zW=VVprUT, VVd2cp=VVd2cp, VVvxfu=VVvxfu)
  else:
   FFLnSq(self, "No hidden services.", FFsbex())
 def VV3Ztf(self):
  totT, totC, totA, totS, totS2, satList = self.VVLZSU()
  txt = FFxKI9("Total Transponders:\n\n", VV9YfT)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFxKI9("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VV9YfT)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFlP4Z(item), satList.count(item))
  FFGdNj(self, txt)
 def VVLZSU(self):
  lamedbFile, disabledFile = CCHa4g.VVVEGg()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FF7BRF(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VVyVAu(self)   : self.VVIboV(True)
 def VVlXhc(self) : self.VVIboV(False)
 def VVIboV(self, isWithPIcons):
  piconsPath = CCOmM2.VVQ8DK()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCOmM2.VVT956(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVprUT = CCHa4g.VVzJJ1(self, self.VVOkEr)
    if VVprUT:
     channels = []
     for (chName, chProv, sat, refCode) in VVprUT:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FF0UE0(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVprUT)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVCE8s(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVCE8s("PIcons Path"  , piconsPath)
     txt += VVCE8s("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVCE8s("Total services" , totalServices)
     txt += VVCE8s("With PIcons"  , totalWithPIcons)
     txt += VVCE8s("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFGdNj(self, txt)
     else:
      VVvxfu     = (""      , self.VVKbyL , [])
      if isWithPIcons : VVulZM = ("Export Current PIcon", self.VVSt5w  , [])
      else   : VVulZM = None
      VV8khl     = ("Statistics", FFGdNj, [txt])
      VVd2cp      = ("Zap", self.VVYz1i, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVuTBM(VV06zW=channels, VVd2cp=VVd2cp, VVvxfu=VVvxfu, VV8khl=VV8khl, VVulZM=VVulZM)
   else:
    FFv5WO(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFv5WO(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVKbyL(self, VVwuhl, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFlYRO(self, fncMode=CCA5BL.VVCY9I, refCode=refCode, chName=chName, text=txt)
 def VVSt5w(self, VVwuhl, title, txt, colList):
  png, path = CCOmM2.VVoEAv(colList[3], colList[0])
  if path:
   CCOmM2.VVZf6h(self, png, path)
 @staticmethod
 def VVVEGg():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVQQI5():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVj1Lk(self, isEnable):
  lamedbFile, disabledFile = CCHa4g.VVVEGg()
  if isEnable and not fileExists(disabledFile):
   FFLnSq(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FFv5WO(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFhdnr(self, boundFunction(self.VVYLjQ, isEnable), "%s Hidden Channels ?" % word)
 def VVYLjQ(self, isEnable):
  lamedbFile , disabledFile = CCHa4g.VVVEGg()
  lamedb5File, diabled5File = CCHa4g.VVQQI5()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FF7jBe()
  if res == 0 : FFLnSq(self, "Hidden List %s" % word)
  else  : FFv5WO(self, "Error while restoring:\n\n%s" % fileName)
 def VVlaK7(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFDnwG(self, cmd)
 def VVy27K(self):
  lamedbFile, disabledFile = CCHa4g.VVVEGg()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFMugq("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FF66GF(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFMugq("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FF7jBe()
   FFGdNj(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FF7BRF(self, lamedbFile)
class CCA5BL(Screen):
 VVagZT  = 0
 VVDqnf   = 1
 VV6Ro8   = 2
 VVCY9I    = 3
 VVKunJ    = 4
 VVyNgJ   = 5
 VVaUTH   = 6
 VVpEO3    = 7
 VVADD0   = 8
 VViiw6   = 9
 VVF3tX   = 10
 VVdUwz   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFrBKf(VVvq1J, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVagZT)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFxKI9("%s\n", VVpXnW) % VVjUYT
  FF4zOZ(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVegjp })
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  self["myLabel"].VVC5L2(textOutFile="chann_info")
  if   self.fncMode == self.VVagZT : fnc = self.VVPEtt_VVagZT
  elif self.fncMode == self.VVDqnf  : fnc = self.VVPEtt_VVagZT
  elif self.fncMode == self.VV6Ro8  : fnc = self.VVPEtt_VVagZT
  elif self.fncMode == self.VVCY9I  : fnc = self.VVPEtt_VVCY9I
  elif self.fncMode == self.VVKunJ  : fnc = self.VVPEtt_VVKunJ
  elif self.fncMode == self.VVyNgJ  : fnc = self.VVPEtt_VVyNgJ
  elif self.fncMode == self.VVaUTH  : fnc = self.VVPEtt_VVaUTH
  elif self.fncMode == self.VVpEO3  : fnc = self.VVPEtt_VVpEO3
  elif self.fncMode == self.VVADD0  : fnc = self.VVPEtt_VVADD0
  elif self.fncMode == self.VViiw6 : fnc = self.VVPEtt_VViiw6
  elif self.fncMode == self.VVF3tX  : fnc = self.VVPEtt_VVF3tX
  elif self.fncMode == self.VVdUwz : fnc = self.VVPEtt_VVdUwz
  self["myLabel"].setText("\n   Reading Info ...")
  FFYJiO(fnc)
 def VV6gQ5(self, err):
  self["myLabel"].setText(err)
  FFv4ZZ(self["myTitle"], "#22200000")
  FFv4ZZ(self["myBody"], "#22200000")
  self["myLabel"].FFv4ZZColor("#22200000")
  self["myLabel"].VVLOqo()
 def VVPEtt_VVagZT(self):
  try:
   dum = self.session
  except:
   return
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
  self.refCode = refCode
  self.VVZHQ6(chName)
 def VVPEtt_VVCY9I(self):
  self.VVZHQ6(self.chName)
 def VVPEtt_VVKunJ(self):
  self.VVZHQ6(self.chName)
 def VVPEtt_VVyNgJ(self):
  self.VVZHQ6(self.chName)
 def VVPEtt_VVaUTH(self):
  self.VVZHQ6("Picon Info")
 def VVPEtt_VVpEO3(self):
  self.VVZHQ6(self.chName)
 def VVPEtt_VVADD0(self):
  self.VVZHQ6(self.chName)
 def VVPEtt_VViiw6(self):
  self.VVZHQ6(self.chName)
 def VVPEtt_VVF3tX(self):
  self.chUrl = self.refCode + self.callingSELF.VVEbJO(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVZHQ6(self.chName)
 def VVPEtt_VVdUwz(self):
  self.VVZHQ6(self.chName)
 def VVZHQ6(self, title):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVBA3H(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFxKI9(self.VVNYzl(tUrl), VVIgRq)
  if not self.epg:
   epg = self.VVO6GL(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VV0XTk(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCOmM2.VVoEAv(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VV0XTk(path)
  self.VV86x7()
  self.VVjRlk()
  self["myLabel"].setText(self.text, VVTzbD=VVoH3m)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVLOqo(minHeight=minH)
 def VVjRlk(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFpq6y(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVKP1Y(FFeUdo(url))
  if epg:
   self.text += "\n" + FF81Uc("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VV86x7()
 def VV86x7(self):
  if not self.piconShown and self.picUrl:
   path, err = FFzKLB(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VV0XTk(path)
    if self.piconShown and self.refCode:
     self.VV4Ekz(path, self.refCode)
 def VV4Ekz(self, path, refCode):
  if path and fileExists(path) and os.system(FFMugq("which ffmpeg")) == 0:
   pPath = CCOmM2.VVQ8DK()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
    cmd += FFMugq("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VV0XTk(self, path):
  if path and fileExists(path):
   err, w, h = self.VVZK7f(path)
   if not err:
    if h > w:
     self.VV0szg(self["myPicF"], w, h, True)
     self.VV0szg(self["myPic"] , w, h, False)
   allOK = FF95wO(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VV0szg(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVZK7f(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFw9Nl(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVBA3H(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFxKI9(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVCE8s(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFxKI9(state, VV8tYH)
   txt += "State\t: %s\n" % state
  w = FFWEVh(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFWEVh(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VV6sO4(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVCE8s(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVCE8s(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVCE8s(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVfNHx()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVIFHM()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCA5BL.VVsetP(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFxKI9("IPTV", VV9YfT)
   txt += self.VVxq4U(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVqeEY(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCJR3E()
    tpTxt, namespace = tp.VVKdcB(refCode)
    del tp
    if tpTxt:
     txt += FFxKI9("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFxKI9("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVCE8s(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVCE8s(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVCE8s(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVCE8s(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVCE8s(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVCE8s(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVCE8s(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVCE8s(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVCE8s(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VV6sO4(info):
  if info:
   aspect = FFWEVh(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVCE8s(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFWEVh(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVH0Cr(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVH0Cr(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVfNHx(self):
  try:
   service = self.session.nav.getCurrentService()
   audio = service and service.audioTracks()
   return audio and audio.getNumberOfTracks() or 0
  except:
   pass
  return -1
 def VVIFHM(self):
  try:
   service   = self.session.nav.getCurrentService()
   subtitle  = service and service.subtitle()
   subtitlelist = subtitle and subtitle.getSubtitleList()
   return len(subtitlelist)
  except:
   pass
  return -1
 def VVqeEY(self, refCode, iptvRef, chName):
  refCode = FFGsMp(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFqhNI(VVeXaf + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFqhNI(VVeXaf + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VV06zW = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVeXaf + item
   if fileExists(path):
    txt = FFqhNI(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VV06zW.append(bName)
  txt = self.Sep
  if VV06zW:
   if len(VV06zW) == 1:
    txt += "%s\t: %s\n" % (FFxKI9("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VV06zW[0])
   else:
    txt += FFxKI9("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VV06zW):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVO6GL(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVxPil(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVxPil(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVxPil(event, 0)
     except:
      pass
  return epg
 def VVxPil(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName().strip()    or ""
   evTime = event.getBeginTime()      or ""
   evDur = event.getDuration()      or ""
   evShort = event.getShortDescription() .strip() or ""
   evDesc = event.getExtendedDescription().strip() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = self.VV4qiR(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FFxKI9(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FFxKI9(evNameTransl, COLOR_CONS_BRIGHT_YELLOW))
    if evTime           : txt += "Start Time\t: %s\n" % FFt8n3(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFt8n3(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFK79w(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFK79w(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFK79w(evTime - now)
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFxKI9(evShort, VVMcHq)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFxKI9(evDesc , VVMcHq)
    if txt:
     txt = FFxKI9("\n%s\n%s Event:\n%s\n" % (VVjUYT, ("Current", "Next")[evNum], VVjUYT), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVxq4U(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FF7eR2(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCjeUi()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVpcri(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFxKI9("URL:", VV9YfT) + "\n%s\n" % self.VVNYzl(decodedUrl)
  else:
   txt = "\n"
   txt += FFxKI9("Reference:", VV9YfT) + "\n%s\n" % refCode
  return txt
 def VVNYzl(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVU5WU:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VVKP1Y(self, decodedUrl):
  if not FFStZp():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCkpQY.VV6xjj(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCkpQY.VVXTOQ(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVt1Gy(tDict)
   elif uType == "movie" : epg, picUrl = self.VVBLeP(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVt1Gy(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCkpQY.VVHt2d(item, "title"    , is_base64=True )
     lang    = CCkpQY.VVHt2d(item, "lang"         ).upper()
     description   = CCkpQY.VVHt2d(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCkpQY.VVHt2d(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCkpQY.VVHt2d(item, "start_timestamp"      )
     stop_timestamp  = CCkpQY.VVHt2d(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCkpQY.VVHt2d(item, "stop_timestamp"       )
     now_playing   = CCkpQY.VVHt2d(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVTIP5, ""
      else     : color, txt = VV8tYH , "    (CURRENT EVENT)"
      epg += FFxKI9("_" * 32 + "\n", VVpXnW)
      epg += FFxKI9("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFxKI9(description, VVIgRq)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVJqa9(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVBLeP(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCkpQY.VVHt2d(item, "movie_image" )
    genre  = CCkpQY.VVHt2d(item, "genre"   ) or "-"
    plot  = CCkpQY.VVHt2d(item, "plot"   ) or "-"
    cast  = CCkpQY.VVHt2d(item, "cast"   ) or "-"
    rating  = CCkpQY.VVHt2d(item, "rating"   ) or "-"
    director = CCkpQY.VVHt2d(item, "director"  ) or "-"
    releasedate = CCkpQY.VVHt2d(item, "releasedate" ) or "-"
    duration = CCkpQY.VVHt2d(item, "duration"  ) or "-"
    try:
     lang = CCkpQY.VVHt2d(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFxKI9(cast, VVIgRq)
    epg += "Plot:\n%s"    % FFxKI9(self.VV4qiR(plot), VVIgRq)
   except:
    pass
  return epg, movie_image
 def VV4qiR(self, evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = self.VV3dJj(evTxt, lang)
   return CCA5BL.VV0eFN(txt).strip() or evTxt
 @staticmethod
 def VV0eFN(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VV3dJj(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFXZWp(txt))
   txt, err = CCkpQY.VVXTOQ(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFeUdo(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVJqa9(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VV60QP(SELF):
  if not CCIF1R.VVcQFb(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(SELF)
  err = url =  fSize = resumable = ""
  if FFGCwp(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCjeUi.VVaUH5(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCjeUi.VVUkecHeader(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFv5WO(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCQ7If.VVmZaL(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFxKI9(" (M3U/M3U8 File)", VVIgRq)
    else:
     fSize = "No info. from server. Try again later."
    hResume = resp.headers.get("Accept-Ranges" , "")
    if hResume:
     if not hResume == "none": resumable = "Yes"
     else     : resumable = "No"
   except requests.Timeout as e     : err = "Connection Timeout"
   except Exception as e       : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVJsq5(subj, val):
   return "%s\n%s\n\n" % (FFxKI9("%s:" % subj, COLOR_CONS_BRIGHT_YELLOW), val)
  title = "File Size"
  txt  = VVJsq5(title , fSize or "?")
  txt += VVJsq5("Name" , chName)
  txt += VVJsq5("URL" , url)
  if resumable: txt += VVJsq5("Supports Download-Resume", resumable)
  if err  : txt += FFxKI9("Error:\n", VV8tYH) + err
  FFGdNj(SELF, txt, title=title)
 @staticmethod
 def VVsetP(SELF):
  fPath, fDir, fName = CCQ7If.VVMlYP(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg", "mvi"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 def VVegjp(self):
  if VVU5WU:
   def VVCE8s(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
   n = ("info" , "refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (info , refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVCE8s(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCjeUi()
    valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVpcri(decodedUrl)
    n = ("valid", "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVCE8s(n[i], v[i])
   with open("/tmp/ajp_channel_details", "a") as f:
    f.write("%s\n%s\n" % (VVjUYT, txt))
   FFlFRp(self, "Saved to:", 1000)
class CCjeUi():
 def __init__(self):
  self.VVb1Ge  = ""
  self.VVvwzd   = ""
  self.VVYdvy  = ""
  self.portal_rand  = ""
  self.portal_moreAuth = False
  self.colored_user  = "#f#11ffffaa#User"
  self.colored_server  = "#f#11aaffff#Server"
 def VVcINC(self, url, mac, VV6xfF=True):
  self.VVb1Ge  = ""
  self.VVvwzd   = ""
  self.VVYdvy  = ""
  self.portal_rand  = ""
  self.portal_moreAuth = False
  host = self.VVqcLR(url)
  if not host:
   if VV6xfF:
    self.VV6xfFor("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVTUY6(mac)
  if not host:
   if VV6xfF:
    self.VV6xfFor("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVb1Ge = host
  self.VVvwzd  = mac
  return True
 def VVqcLR(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVTUY6(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVnv7L(self, VV6xfF=True):
  err = blkMsg = FFLnSqTxt = ""
  try:
   token, rand, err = self.VVEhlv()
   if token:
    self.VVYdvy = token
    self.portal_rand  = rand
    prof = self.VViEll()
    if prof:
     word = "m" + "sg"
     blkMsg = CCkpQY.VVHt2d(prof["js"], "block_%s" % word)
     FFLnSqTxt = CCkpQY.VVHt2d(prof["js"], word)
     if blkMsg or FFLnSqTxt:
      self.portal_moreAuth = True
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFLnSqTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFLnSqTxt: tErr += "\n%s" % FFLnSqTxt
  if VV6xfF:
   self.VV6xfFor(tErr)
  return "", "", tErr
 def VVEhlv(self):
  res, err = self.VVktYD(self.VVjg4J())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VVb1Ge:
   self.VVb1Ge = self.VVb1Ge.replace(urlPath, "")
   res, err = self.VVktYD(self.VVjg4J())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCkpQY.VVHt2d(tDict["js"], "token")
    rand  = CCkpQY.VVHt2d(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VViEll(self):
  res, err = self.VVktYD(self.VVUHO3())
  if not err:
   try:
    profJson = jLoads(res.text)
    return profJson
   except:
    pass
  return ""
 def VVKtTW(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVTGWn()
  if len(rows) < 10:
   rows = self.VVIETV()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVb1Ge ))
   rows.append(("MAC (from URL)" , self.VVvwzd ))
   rows.append(("Token"   , self.VVYdvy ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VVvwzd ))
   rows.append(("2", self.colored_server, "Host" , self.VVb1Ge ))
   rows.append(("2", self.colored_server, "Token" , self.VVYdvy ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVRqGU(self, isPhp=True, VV6xfF=False):
  token, profile, tErr = self.VVnv7L(VV6xfF)
  if not token:
   return "", tErr
  m3u_Url = ""
  url = self.VVlXhQ()
  res, err = self.VVktYD(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCkpQY.VVHt2d(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFXZWp(span.group(2))
     pass1 = FFXZWp(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, err
 def VVTGWn(self):
  m3u_Url, err = self.VVRqGU()
  rows = []
  if m3u_Url:
   res, err = self.VVktYD(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFt8n3(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFt8n3(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVIETV(self):
  token, profile, tErr = self.VVnv7L()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFOezn(val): val = FFlFvV(val.decode("UTF-8"))
     else     : val = self.VVvwzd
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFt8n3(int(parts[1]))
      if parts[2] : ends = FFt8n3(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFt8n3(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVEbJO(self, mode, chCm, epNum, epId):
  crLinkUrl = self.VVKjLB(mode, chCm, epNum, epId)
  token, profile, tErr = self.VVnv7L(VV6xfF=False)
  if not token:
   return ""
  res, err = self.VVktYD(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCkpQY.VVHt2d(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  return chUrl
 def VVaqaQ(self):
  return self.VVb1Ge + "/server/load.php?"
 def VVjg4J(self):
  return self.VVaqaQ() + "type=stb&action=handshake&token=&mac=%s" % self.VVvwzd
 def VVUHO3(self):
  if self.portal_moreAuth:
   import hashlib
   sn    = hashlib.md5(self.VVvwzd).hexdigest().upper()[:13]
   param  = ""
   param += "&sn=%s"   % sn
   param += "&device_id=%s" % hashlib.sha256(sn).hexdigest().upper()
   param += "&device_id2=%s" % hashlib.sha256(self.VVvwzd).hexdigest().upper()
   param += "&signature=%s" % hashlib.sha256(sn + self.VVvwzd).hexdigest().upper()
   param += '&auth_second_step=1'
   param += '&hw_version=2.17-IB-00&hw_version_2=62'
   param += '&metrics={"mac":"%s","sn":"%s","type":"STB","model":"MAG250","random":"%s"}' % (self.VVvwzd, sn, self.portal_rand)
  else:
   param = ""
  return self.VVaqaQ() + "type=stb&action=get_profile" + param
 def VVsuyn(self, mode):
  url = self.VVaqaQ() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVg8IO(self, catID):
  return self.VVaqaQ() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVzMiO(self, mode, catID, page):
  url = self.VVaqaQ() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "series" : url += "category=%s" % catID
  else    : url += "genre=%s&force_ch_link_check=" % catID
  return url
 def VVFrRN(self, mode, searchName, page):
  return self.VVaqaQ() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VV5d3v(self, mode, catID):
  return self.VVaqaQ() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVKjLB(self, mode, chCm, serCode, serId):
  url = self.VVaqaQ() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVlXhQ(self):
  return self.VVaqaQ() + "type=itv&action=create_link"
 def VVbKkR(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVOUlP(catID, stID, chNum)
  query = self.VVa0ls(mode, FFNJSY(host), FFNJSY(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVa0ls(self, mode, host, mac, serCode, serId, chCm):
  query = "mode=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVpcri(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVa0ls(mode, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFlFvV(host)
  mac   = FFlFvV(mac)
  valid = False
  if self.VVqcLR(playHost) and self.VVqcLR(host) and self.VVqcLR(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVktYD(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCjeUi.VVUkecHeader()
   if self.VVYdvy:
    headers["Authorization"] = "Bearer %s" % self.VVYdvy
   if useCookies : cookies = {"mac": self.VVvwzd, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok : return res, ""
   else  : err = "Err-%d : %s" % (res.status_code, res.reason or "Unknown")
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVDXXh(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCjeUi.VVUkecHeader(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVUkecHeader():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVHT1K(host, mac, tType, action, keysList=[]):
  myPortal = CCjeUi()
  ok = myPortal.VVcINC(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVnv7L(VV6xfF=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VVktYD(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VV8sX8(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VV8sX8(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VV6xfFor(self, err, title="Portal Browser"):
  FFv5WO(self, str(err), title=title)
 def VVeHee(self, mode):
  if   mode in ("itv"  , CCkpQY.VVR1iH , CCkpQY.VV2qmD)  : return "Live"
  elif mode in ("vod"  , CCkpQY.VVInrt , CCkpQY.VVM1dn)  : return "VOD"
  elif mode in ("series" , CCkpQY.VVvO8v , CCkpQY.VVkh8k) : return "Series"
  else                          : return "IPTV"
 def VVbNSB(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVeHee(mode), searchName)
 def VVEcv3(self, catchup=False):
  VVSAYi = []
  VVSAYi.append(("Live"    , "live"  ))
  VVSAYi.append(("VOD"    , "vod"   ))
  VVSAYi.append(("Series"   , "series"  ))
  if catchup:
   VVSAYi.append(VVudpG)
   VVSAYi.append(("Catchup TV" , "catchup"  ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Account Info." , "accountInfo" ))
  return VVSAYi
 @staticmethod
 def VVPkhR(decodedUrl):
  m3u_Url = ""
  p = CCjeUi()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVpcri(decodedUrl)
  if valid:
   ok = p.VVcINC(host, mac, VV6xfF=False)
   if ok:
    m3u_Url, err = p.VVRqGU(isPhp=False, VV6xfF=False)
    span = iSearch(r".+ch\/(.+)_", decodedUrl, IGNORECASE)
    if span:
     m3u_Url += span.group(1)
  return m3u_Url
 @staticmethod
 def VVaUH5(decodedUrl):
  p = CCjeUi()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVpcri(decodedUrl)
  if valid:
   ok = p.VVcINC(host, mac, VV6xfF=False)
   if ok:
    try:
     chUrl = p.VVEbJO(mode, chCm, epNum, epId)
     return FFeUdo(chUrl)
    except Exception as e:
     pass
  return ""
class CC69K0(CCjeUi):
 def __init__(self):
  CCjeUi.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVgTKV(self, refCode, chName, decodedUrl, iptvRef):
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVpcri(decodedUrl)
  if valid:
   if self.VVcINC(host, mac, VV6xfF=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVM9yX(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVEbJO(self.mode, self.chCm, self.epNum, self.epId)
  except:
   pass
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = self.refCode + chUrl.strip() + ":" + self.chName
  newIptvRef = self.VVt3X1(chUrl)
  if newIptvRef:
   success = self.VVXemT(self.iptvRef, newIptvRef)
   if passedSELF:
    FFY7Np(passedSELF, newIptvRef, VV4NU5=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFY7Np(self, newIptvRef, VV4NU5=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVt3X1(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVXemT(self, oldCode, newCode):
  bPath = FFdjsr()
  if bPath:
   txt = FFqhNI(bPath)
   if oldCode in txt:
    txt = txt.replace(oldCode, newCode)
    with open(bPath, "w") as f:
     f.write(txt)
    FF7jBe()
    return True
  return False
class CCkh0e(CC69K0):
 def __init__(self, passedSession):
  CC69K0.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.starttime  = iTime()
  self.timer1   = eTimer()
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VV4FOd, iPlayableService.evEOF: self.VVlF8S, iPlayableService.evEnd: self.VVtxue})
  except:
   pass
 def VV4FOd(self):
  self.starttime = iTime()
 def VVlF8S(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.starttime) > 2:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self.passedSession, isFromSession=True)
    if iptvRef and not FFGCwp(decodedUrl):
     CCMMUH(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
 def VVtxue(self):
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVqUq8)
  except:
   self.timer1.callback.append(self.VVqUq8)
  self.timer1.start(100, True)
 def VVqUq8(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self.passedSession, isFromSession=True)
  valid = False
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if not ref == self.lastRef:
     valid = self.VVgTKV(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if not CCewzF.VVLlLV:
       self.VVM9yX(self.passedSession, isFromSession=True)
class CCBlS0():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.nameTagPatt = r"\s*[\[(|:].*[\])|:](.+)|\s*(?:[^a-z]+:)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
 def VVFsz2(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCkpQY.VVkpae(name):
   return CCkpQY.VVPD4c(name)
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    name = span.group(1) or span.group(2)
  return name.strip() or name
 def VVBjce(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  span = iSearch(self.nameTagPatt, name)
  if span:
   name = span.group(1) or span.group(2)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVIPY9(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  else:
   return name.strip()
 def VVgLOv(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVeuS5(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCIF1R(CCjeUi):
 def __init__(self):
  CCjeUi.__init__(self)
 def VVWaV1(self):
  if CCIF1R.VVcQFb(self):
   FF8MfV(self, self.VVjtek, title="Searching ...")
 def VV8eUh(self, winSession, url, mac):
  if CCIF1R.VVcQFb(self):
   if self.VVcINC(url, mac):
    FF8MfV(winSession, self.VVWeKZ, title="Checking Server ...")
   else:
    FFv5WO(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVjtek(self):
  path = CCkpQY.VVrMGU()
  lines = FFs4zJ('find %s %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % (path, FFfLcR(1)))
  if lines:
   lines.sort()
   VVSAYi = []
   for line in lines:
    VVSAYi.append((line, line))
   OKBtnFnc = self.VV7GBZ
   VVEbC5 = ("Delete File", boundFunction(self.VVh2d2, boundFunction(FF8MfV, self, self.VVjtek, title="Searching ...")))
   FF3fIR(self, None, title="Select Portals File", VVSAYi=VVSAYi, width=1200, OKBtnFnc=OKBtnFnc, VVEbC5=VVEbC5)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFv5WO(self, 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt)
 def VVh2d2(self, cbFnc, VVMsOjObj, path):
  FFhdnr(self, boundFunction(self.VVl5An, cbFnc, VVMsOjObj, path), "Delete this file ?\n\n%s" % path)
 def VVl5An(self, cbFnc, VVMsOjObj, path):
  os.system(FFMugq("rm -f '%s'" % path))
  VVMsOjObj.cancel()
  FFYJiO(cbFnc)
 def VV7GBZ(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = FFJDeD(path, self)
   if enc == -1:
    return
   self.session.open(CCHSPO, barTheme=CCHSPO.VVSU2X
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVxrlz, path, enc)
       , VVCoUZ = boundFunction(self.VVmRPu, menuInstance, path))
 def VVxrlz(self, path, enc, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  progBarObj.VVKFmP(totLines)
  progBarObj.VVGy5N = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVWBRz(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVqcLR(url)
     mac  = self.VVTUY6(mac)
     if host and mac and progBarObj:
      progBarObj.VVGy5N.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVqcLR(url)
      mac  = self.VVTUY6(mac)
      if host and mac and not mac.startswith("AC") and progBarObj:
       progBarObj.VVGy5N.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVmRPu(self, menuInstance, path, VV73UU, VVGy5N, threadCounter, threadTotal, threadErr):
  title = "Portals List File"
  if VVGy5N:
   VVSxFV  = ("Home Menu", FF19xV, [])
   VVulZM  = None #("Check & Filter" , boundFunction(self.filterPortalAuthorizedServers, path), [])
   VV8khl = ("Edit File" , boundFunction(self.VV2hg7, path) , [])
   VVJD06 = ("Open as M3U", self.VVOKzX     , [])
   VVd2cp  = ("Select"  , self.VV8eUh_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVDKYV  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVwuhl = FFEtMz(self, None, title=title, header=header, VV06zW=VVGy5N, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=26, VVd2cp=VVd2cp, VVSxFV=VVSxFV, VVJD06=VVJD06, VV8khl=VV8khl, VVulZM=VVulZM, VVM7V1="#0a001122", VVUL9C="#0a001122", VVehrL="#0a001122", VVTG9d="#00004455", VVCgV5="#0a333333", VVoitp="#11331100", VVgpgw=True, searchCol=1)
   if not VV73UU:
    FFlFRp(VVwuhl, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VV73UU:
    FFv5WO(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVOKzX(self, VVwuhl, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  FF8MfV(VVwuhl, boundFunction(self.VV3N5k, VVwuhl, host, mac), title="Checking Server ...")
 def VV3N5k(self, VVwuhl, host, mac):
  p = CCjeUi()
  m3u_Url = ""
  ok = p.VVcINC(host, mac, VV6xfF=False)
  err = ""
  if ok:
   m3u_Url, err = p.VVRqGU(VV6xfF=False)
  title = "Browsing M3U Server from Portal Data"
  if m3u_Url:
   self.VV29xH(title, m3u_Url)
  else:
   FFv5WO(self, err or "No response from Server !", title=title)
 def VV8eUh_fromMacFiles(self, VVwuhl, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VV8eUh(VVwuhl, url, mac)
 def VV2hg7(self, path, VVwuhl, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCVYVr(self, path, VVCoUZ=boundFunction(self.VVkh56, VVwuhl), curRowNum=rowNum)
  else    : FF7BRF(self, path)
 def VVgFqL(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFlFvV(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVWeKZ(self):
  token, profile, tErr = self.VVnv7L()
  if token:
   VVSAYi  = self.VVEcv3()
   OKBtnFnc = self.VVnFA1
   VV9Wtd = ("Home Menu", FF19xV)
   VVJtpI = ("Bookmark Server", boundFunction(CCkpQY.VVJpek, self, True, self.VVb1Ge + "\t" + self.VVvwzd))
   authMore = ".." if self.portal_moreAuth else ""
   FF3fIR(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVvwzd, authMore), VVSAYi=VVSAYi, OKBtnFnc=OKBtnFnc, VV9Wtd=VV9Wtd, VVJtpI=VVJtpI)
 def VVnFA1(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FF8MfV(menuInstance, boundFunction(self.VV4fqt, mode), title="Reading Categories ...")
   else : FF8MfV(menuInstance, boundFunction(self.VVVj3h, menuInstance, title), title="Reading Account ...")
 def VVVj3h(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVKtTW(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVvwzd)
  VVSxFV  = ("Home Menu" , FF19xV, [])
  if totCols == 2:
   VVulZM = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
   VVulZM = ("More Info.", boundFunction(self.VV1Sbr, menuInstance) , [])
  FFEtMz(self, None, title=title, width=1200, header=header, VV06zW=rows, VVTS0u=widths, VVp74Q=26, VVSxFV=VVSxFV, VVulZM=VVulZM, VVM7V1="#0a00292B", VVUL9C="#0a002126", VVehrL="#0a002126", VVTG9d="#00000000", searchCol=searchCol)
 def VV1Sbr(self, menuInstance, VVwuhl, title, txt, colList):
  VVwuhl.cancel()
  FF8MfV(menuInstance, boundFunction(self.VVVj3h, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VV4fqt(self, mode):
  token, profile, tErr = self.VVnv7L()
  if not token:
   return
  res, err = self.VVktYD(self.VVsuyn(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CCBlS0()
     chList = tDict["js"]
     for item in chList:
      Id   = CCkpQY.VVHt2d(item, "id"       )
      Title  = CCkpQY.VVHt2d(item, "title"      )
      censored = CCkpQY.VVHt2d(item, "censored"     )
      Title = processChanName.VVIPY9(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VV8Rhz:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVeHee(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVM7V1, VVUL9C, VVehrL, VVTG9d = self.VVNW5M(mode)
   mName = self.VVeHee(mode)
   VVd2cp   = ("Show List"   , boundFunction(self.VVd1ZP, mode) , [])
   VVSxFV  = ("Home Menu"   , FF19xV         , [])
   if mode in ("vod", "series"):
    VV8khl = ("Find in %s" % mName , boundFunction(self.VVg1bv, mode), [])
   else:
    VV8khl = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFEtMz(self, None, title=title, width=1200, header=header, VV06zW=list, VVTS0u=widths, VVp74Q=30, VVSxFV=VVSxFV, VV8khl=VV8khl, VVd2cp=VVd2cp, VVM7V1=VVM7V1, VVUL9C=VVUL9C, VVehrL=VVehrL, VVTG9d=VVTG9d)
  else:
   s = "Authorization failed"
   if err    : txt = err
   elif s in res.text : txt = s
   else    : txt = "Could not get Categories from server!"
   FFv5WO(self, txt, title=title)
 def VVRdEu(self, mode, VVwuhl, title, txt, colList):
  FF8MfV(VVwuhl, boundFunction(self.VVcrX0, mode, VVwuhl, title, txt, colList), title="Downloading ...")
 def VVcrX0(self, mode, VVwuhl, title, txt, colList):
  token, profile, tErr = self.VVnv7L()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVktYD(self.VVg8IO(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCkpQY.VVHt2d(item, "id"    )
      actors   = CCkpQY.VVHt2d(item, "actors"   )
      added   = CCkpQY.VVHt2d(item, "added"   )
      age    = CCkpQY.VVHt2d(item, "age"   )
      category_id  = CCkpQY.VVHt2d(item, "category_id" )
      description  = CCkpQY.VVHt2d(item, "description" )
      director  = CCkpQY.VVHt2d(item, "director"  )
      genres_str  = CCkpQY.VVHt2d(item, "genres_str"  )
      name   = CCkpQY.VVHt2d(item, "name"   )
      path   = CCkpQY.VVHt2d(item, "path"   )
      screenshot_uri = CCkpQY.VVHt2d(item, "screenshot_uri" )
      series   = CCkpQY.VVHt2d(item, "series"   )
      cmd    = CCkpQY.VVHt2d(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VVd2cp  = ("Play"    , boundFunction(self.VV6Yih, mode)       , [])
   VVvxfu = (""     , boundFunction(self.VVpNdQ, mode)     , [])
   VVSxFV = ("Home Menu"   , FF19xV               , [])
   VVJD06 = ("Download Options" , boundFunction(self.VV536O, mode, "sp", seriesName) , [])
   VV8khl = ("Add ALL to Bouquet" , boundFunction(self.VVnroN, mode, seriesName)  , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVDKYV  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFEtMz(self, None, title=seriesName, width=1200, header=header, VV06zW=list, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=26, VVSxFV=VVSxFV, VVJD06=VVJD06, VV8khl=VV8khl, VVd2cp=VVd2cp, VVvxfu=VVvxfu, VVM7V1="#0a00292B", VVUL9C="#0a002126", VVehrL="#0a002126", VVTG9d="#00000000")
  else:
   FFv5WO(self, "Could not get Episodes from server!", title=seriesName)
 def VVg1bv(self, mode, VVwuhl, title, txt, colList):
  VVSAYi = []
  VVSAYi.append(("Keyboard"  , "manualEntry"))
  VVSAYi.append(("From Filter" , "fromFilter"))
  FF3fIR(self, boundFunction(self.VVsBJy, VVwuhl, mode), title="Input Type", VVSAYi=VVSAYi, width=400)
 def VVsBJy(self, VVwuhl, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFMKq2(self, boundFunction(self.VV3eka, VVwuhl, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCWTeq(self)
    filterObj.VV1ymy(boundFunction(self.VV3eka, VVwuhl, mode))
 def VV3eka(self, VVwuhl, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VVbNSB(mode, searchName)
   if len(searchName) < 3:
    FFv5WO(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CCBlS0()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVgLOv([searchName]):
     FFv5WO(self, processChanName.VVeuS5(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVHXbk(mode, searchName, "", searchName)
 def VVd1ZP(self, mode, VVwuhl, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVHXbk(mode, bName, catID, "")
 def VVHXbk(self, mode, bName, catID, searchName):
  self.session.open(CCHSPO, barTheme=CCHSPO.VVSU2X
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VV07xV, mode, bName, catID, searchName)
      , VVCoUZ = boundFunction(self.VVcSOF, mode, bName, catID, searchName))
 def VVcSOF(self, mode, bName, catID, searchName, VV73UU, VVGy5N, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVbNSB(mode, searchName)
  else   : title = "%s : %s" % (self.VVeHee(mode), bName)
  if VVGy5N:
   VVJD06 = None
   VV8khl = None
   if mode == "series":
    VVM7V1, VVUL9C, VVehrL, VVTG9d = self.VVNW5M("series2")
    VVd2cp  = ("Episodes", boundFunction(self.VVRdEu, mode) , [])
   else:
    VVM7V1, VVUL9C, VVehrL, VVTG9d = self.VVNW5M("")
    VVd2cp  = ("Play"    , boundFunction(self.VV6Yih, mode)           , [])
    VV8khl = ("Add ALL to Bouquet" , boundFunction(self.VVnroN, mode, bName)       , [])
    VVJD06 = ("Download Options" , boundFunction(self.VV536O, mode, "vp" if mode == "vod" else "", "") , [])
   VVvxfu = (""      , boundFunction(self.VVA7DL, mode)          , [])
   VVSxFV = ("Home Menu"    , FF19xV                   , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVDKYV  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT )
   VVwuhl = FFEtMz(self, None, title=title, header=header, VV06zW=VVGy5N, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=26, VVSxFV=VVSxFV, VVJD06=VVJD06, VV8khl=VV8khl, VVd2cp=VVd2cp, VVvxfu=VVvxfu, VVM7V1=VVM7V1, VVUL9C=VVUL9C, VVehrL=VVehrL, VVTG9d=VVTG9d, VVgpgw=True, searchCol=1)
   if not VV73UU:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVwuhl.VVs63l(VVwuhl.VVsOzc() + tot)
    if threadErr: FFlFRp(VVwuhl, "Error while reading !", 2000)
    else  : FFlFRp(VVwuhl, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFv5WO(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFv5WO(self, "Could not get list from server !", title=title)
 def VVA7DL(self, mode, VVwuhl, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFlYRO(self, fncMode=CCA5BL.VVdUwz, portalHost=self.VVb1Ge, portalMac=self.VVvwzd, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VV5mCa(mode, VVwuhl, title, txt, colList)
 def VVpNdQ(self, mode, VVwuhl, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFxKI9(colList[10], VVIgRq)
  txt += "Description:\n%s" % FFxKI9(colList[11], VVIgRq)
  self.VV5mCa(mode, VVwuhl, title, txt, colList)
 def VV5mCa(self, mode, VVwuhl, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVBFL6(mode, colList)
  refCode, chUrl = self.VVbKkR(self.VVb1Ge, self.VVvwzd, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFlYRO(self, fncMode=CCA5BL.VVF3tX, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VV07xV(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile, tErr = self.VVnv7L()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVGy5N, total_items, max_page_items, err = self.VVVUrG(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVGy5N and total_items > -1 and max_page_items > -1:
    progBarObj.VVKFmP(total_items)
    progBarObj.VVWBRz(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVVUrG(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VV4tHd()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVGy5N += list
      progBarObj.VVWBRz(len(list), True)
  except:
   pass
 def VVVUrG(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVFrRN(mode, searchName, page)
  else   : url = self.VVzMiO(mode, catID, page)
  res, err = self.VVktYD(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVQUtv(CCkpQY.VVHt2d(item, "total_items" ))
     max_page_items = self.VVQUtv(CCkpQY.VVHt2d(item, "max_page_items" ))
     processChanName = CCBlS0()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCkpQY.VVHt2d(item, "id"    )
      name   = CCkpQY.VVHt2d(item, "name"   )
      tv_genre_id  = CCkpQY.VVHt2d(item, "tv_genre_id" )
      number   = CCkpQY.VVHt2d(item, "number"   ) or str(counter)
      logo   = CCkpQY.VVHt2d(item, "logo"   )
      screenshot_uri = CCkpQY.VVHt2d(item, "screenshot_uri" )
      cmd    = CCkpQY.VVHt2d(item, "cmd"   )
      cmd = cmd.replace("ffmpeg ", "")
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8"):
       span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      counter += 1
      name = processChanName.VVFsz2(name)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVnroN(self, mode, bName, VVwuhl, title, txt, colList):
  FF8MfV(VVwuhl, boundFunction(self.VVHDI9, mode, bName, VVwuhl, title, txt, colList), title="Adding Channels ...")
 def VVHDI9(self, mode, bName, VVwuhl, title, txt, colList):
  bNameFile = CCkpQY.VViR57_forBouquet(bName)
  num  = 0
  path = VVeXaf + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVeXaf + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVwuhl.VV37Hy():
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVBFL6(mode, row)
    refCode, chUrl = self.VVbKkR(self.VVb1Ge, self.VVvwzd, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FFk8Yi(os.path.basename(path))
  self.VVoW0O(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVQUtv(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VV6Yih(self, mode, VVwuhl, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVBFL6(mode, colList)
  refCode, chUrl = self.VVbKkR(self.VVb1Ge, self.VVvwzd, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVkpae(chName):
   FFlFRp(VVwuhl, "This is a marker!", 300)
  else:
   FF8MfV(VVwuhl, boundFunction(self.VVu7D3, mode, VVwuhl, chUrl), title="Playing ...")
 def VVu7D3(self, mode, VVwuhl, chUrl):
  FFY7Np(self, chUrl, VV4NU5=False)
  self.session.open(CCewzF, portalTableParam=(self, VVwuhl, mode))
 def VVunZt(self, mode, VVwuhl, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVBFL6(mode, colList)
  refCode, chUrl = self.VVbKkR(self.VVb1Ge, self.VVvwzd, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVBFL6(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVcQFb(SELF):
  try:
   import requests
   return True
  except:
   FFhdnr(SELF, boundFunction(CCIF1R.VVQSeq, SELF), 'This requires the library "Requests".\n\nInstall it now ?')
   return False
 @staticmethod
 def VVQSeq(SELF):
  from sys import version_info
  cmdUpd = FFyxGo(VVzgKA, "")
  if cmdUpd:
   cmdInst = FFyov6(VVaBvq, "python-requests")
   if version_info[0] >= 3:
    cmdInst = cmdInst.replace("python-", "python3-")
   cmd = cmdUpd + " && " + cmdInst
   FFl3Il(SELF, cmd, checkNetAccess=True, title="Installing Requests Library")
  else:
   FFXixL(SELF)
class CCkpQY(Screen, CCIF1R):
 VVuLIF    = 0
 VVrhMj    = 1
 VVNu5F    = 2
 VVNkrf    = 3
 VVcfSd     = 4
 VVtXTk     = 5
 VVcn7c     = 6
 VVQwJ6     = 7
 VVP0V1      = 8
 VVO5Cj     = 9
 VVfUcY     = 10
 VVz4Ez     = 11
 VVM6Ps     = 12
 VVT33r      = 13
 VVcBKW      = 14
 VV7lgh      = 15
 VV5Zt0      = 16
 VVkQTW      = 17
 VVwLGj    = 0
 VVR1iH   = 1
 VVInrt   = 2
 VVvO8v   = 3
 VVQibI  = 4
 VVw1KM  = 5
 VV2qmD   = 6
 VVM1dn   = 7
 VVkh8k  = 8
 VVYTkQ  = 9
 VVkLf6  = 10
 VVtvjO = 0
 VVgT0X = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFrBKf(VV1H0A, 1000, 1000, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.m3uOrM3u8File  = m3uOrM3u8File
  self.m3uOrM3u8BName  = ""
  self.VVwuhl  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVmDIOData  = {}
  self.lastFindIptvName = ""
  CCIF1R.__init__(self)
  VVSAYi= self.VVitf7()
  FF4zOZ(self, title="IPTV", VVSAYi=VVSAYi)
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FF5gi1(self["myMenu"])
  FFfRto(self)
  FFhKEa(self)
  if self.m3uOrM3u8File:
   self.VVQ3PC(self.m3uOrM3u8File)
 def VVitf7(self):
  files = self.VVoYfr()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"        , "VVmDIO_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal List)"        , "VVmDIO_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)"    , "VVmDIO_fromM3u"  ))
  qUrl, iptvRef = self.VV6Tb7()
  if qUrl:
   tList.append(("IPTV Server Browser (from Current Channel)"      , "VVmDIO_fromCurrChan" ))
  VVSAYi = []
  if files:
   if self.VVwuhl:
    VVSAYi.append(("Add Current List to a New Bouquet"      , "VVN0pw"  ))
    VVSAYi.append(VVudpG)
    VVSAYi.append(("Change Current List References to Unique Codes"   , "VV8FV0"))
    VVSAYi.append(("Change Current List References to Identical Codes"  , "VVSXFD_rows" ))
    VVSAYi.append(VVudpG)
    VVSAYi.append(("Share Reference with Satellite/C/T Service (manual entry)", "VVRFeu"   ))
    VVSAYi.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VVGHE8"   ))
   else:
    VVSAYi += tList
    VVSAYi.append(VVudpG)
    VVSAYi.append(("M3U/M3U8 Channels Browser"        , "VVELxm"   ))
    VVSAYi.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    if qUrl:
     VVSAYi.append(VVudpG)
     VVSAYi.append(("Update Current Bouquet EPG (from IPTV Server)"  , "refreshIptvEPG"   ))
    VVSAYi.append(VVudpG)
    VVSAYi.append(("Count Available IPTV Channels"       , "VVomsR"    ))
    VVSAYi.append(("Check Reference Codes Format"        , "VVbMJj"   ))
    VVSAYi.append(("Check System Acceptable Reference Types"     , "VVvAVf"   ))
    VVSAYi.append(VVudpG)
    VVSAYi.append(("Share Reference with Sat./C/T (Only Matching Names)"  , "VVtvvl" ))
    VVSAYi.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VV9u92"  ))
    VVSAYi.append(("Change ALL References to Unique Codes"     , "VVwOjm" ))
    VVSAYi.append(("Change ALL References to Identical Codes"     , "VVSXFD_all" ))
  if not self.VVwuhl:
   if not files:
    VVSAYi += tList
   if not CCGsij.VVbz6c():
    VVSAYi.append(VVudpG)
    VVSAYi.append(("Download Manager"           , "dload_stat"    ))
  return VVSAYi
 def VVJT5R(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVN0pw"   : FFMKq2(self, self.VVN0pw, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VV8FV0" : FFhdnr(self, boundFunction(FF8MfV, self.VVwuhl, self.VV8FV0 ), "Change Current List References to Unique Codes ?")
   elif item == "VVSXFD_rows" : FFhdnr(self, boundFunction(FF8MfV, self.VVwuhl, self.VVSXFD   ), "Change Current List References to Identical Codes ?")
   elif item == "VVRFeu"   : self.VVRFeu(tTitle)
   elif item == "VVGHE8"   : self.VVGHE8(tTitle)
   elif item == "VVmDIO_fromPlayList" : FF8MfV(self, self.VVIEFz, title=title)
   elif item == "VVmDIO_fromM3u"  : FF8MfV(self, boundFunction(self.VV4bNW, 0), title=title)
   elif item == "VVmDIO_fromMac"  : self.VVWaV1()
   elif item == "VVmDIO_fromCurrChan" : self.VV8eUh_fromCurrChan()
   elif item == "VVELxm"   : self.VVELxm()
   elif item == "iptvTable_live"   : FF8MfV(self, boundFunction(self.VVpRP1, self.VVQwJ6 ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FF8MfV(self, boundFunction(self.VVpRP1, self.VVuLIF) , title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VVt0AQ()
   elif item == "VVomsR"    : FF8MfV(self, self.VVomsR)
   elif item == "VVbMJj"    : FF8MfV(self, self.VVbMJj)
   elif item == "VVvAVf"   : FF8MfV(self, self.VVvAVf)
   elif item == "VVtvvl"  : FFhdnr(self, boundFunction(FF8MfV, self, self.VVtvvl ), "Continue ?")
   elif item == "VV9u92"  : self.VV9u92()
   elif item == "VVwOjm" : FFhdnr(self, boundFunction(FF8MfV, self, self.VVwOjm ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVSXFD_all" : FFhdnr(self, boundFunction(FF8MfV, self, self.VVSXFD  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "dload_stat"    : CCGsij.VVcFjY(self)
   elif item == "VVuhrG"   : FF8MfV(self, boundFunction(CCHa4g.VVuhrG, self))
 def VVELxm(self):
  if CCIF1R.VVcQFb(self):
   FF8MfV(self, boundFunction(self.VV4bNW, 1), title="Searching ...")
 def VVjzC3(self):
  global VVWjbN
  VVWjbN = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVJT5R(item)
 def VVpRP1(self, mode):
  VVprUT = self.VVSHyM(mode)
  if VVprUT:
   VVJD06 = ("Current Service", self.VVZ6el  , [])
   VV8khl = ("Options"  , self.VVQtjm    , [])
   VVulZM = ("Filter"   , self.VVg0Rj    , [])
   VVd2cp  = ("Play"   , boundFunction(self.VVRlcJ) , [])
   VVvxfu = (""    , self.VVrOUZ     , [])
   VVomiS = (""    , self.VVP746      , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVDKYV  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFEtMz(self, None, header=header, VV06zW=VVprUT, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=26
     , VVd2cp=VVd2cp, VVJD06=VVJD06, VV8khl=VV8khl, VVulZM=VVulZM, VVvxfu=VVvxfu, VVomiS=VVomiS
     , VVM7V1="#0a00292B", VVUL9C="#0a002126", VVehrL="#0a002126", VVTG9d="#00000000", VVgpgw=True, searchCol=1)
  else:
   if mode == self.VVQwJ6: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFv5WO(self, err)
 def VVP746(self, VVwuhl, title, txt, colList):
  self.VVwuhl = VVwuhl
 def VVQtjm(self, VVwuhl, title, txt, colList):
  VVSAYi= self.VVitf7()
  FF3fIR(self, self.VVJT5R, title="IPTV Tools", VVSAYi=VVSAYi)
 def VVg0Rj(self, VVwuhl, title, txt, colList):
  VVSAYi = []
  VVSAYi.append(("All"         , "all"   ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Prefix of Selected Channel"   , "sameName" ))
  VVSAYi.append(("Suggest Words from Selected Channel" , "partName" ))
  VVSAYi.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Live TV"        , "live"  ))
  VVSAYi.append(("VOD"         , "vod"   ))
  VVSAYi.append(("Series"        , "series"  ))
  VVSAYi.append(("Uncategorised"      , "uncat"  ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Video"        , "video"  ))
  VVSAYi.append(("Audio"        , "audio"  ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("MKV"         , "MKV"   ))
  VVSAYi.append(("MP4"         , "MP4"   ))
  VVSAYi.append(("MP3"         , "MP3"   ))
  VVSAYi.append(("AVI"         , "AVI"   ))
  VVSAYi.append(("FLV"         , "FLV"   ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVx2nt()
  if bNames:
   bNames.sort()
   VVSAYi.append(VVudpG)
   for item in bNames:
    VVSAYi.append((item, "__b__" + item))
  filterObj = CCWTeq(self)
  filterObj.VVSTwS(VVSAYi, VVSAYi, boundFunction(self.VVfEvn, VVwuhl))
 def VVfEvn(self, VVwuhl, item=None):
  prefix = VVwuhl.VVuoNu(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVuLIF, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVrhMj , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVNu5F , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVNkrf , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVQwJ6  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVP0V1   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVO5Cj  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVfUcY  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVz4Ez  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVM6Ps  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVT33r   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVcBKW   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VV7lgh   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VV5Zt0   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVkQTW   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVcn7c  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVcfSd  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVtXTk  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVNu5F:
   VVSAYi = []
   chName = VVwuhl.VVuoNu(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVSAYi.append((item, item))
    if not VVSAYi and chName:
     VVSAYi.append((chName, chName))
    FF3fIR(self, boundFunction(self.VVUOp3_partOfName, title), title="Words from Current Selection", VVSAYi=VVSAYi)
   else:
    VVwuhl.VVT6LE("Invalid Channel Name")
  else:
   words, asPrefix = CCWTeq.VV6DTY(words)
   if not words and mode in (self.VVcfSd, self.VVtXTk):
    FFlFRp(self.VVwuhl, "Incorrect filter", 2000)
   else:
    FF8MfV(self.VVwuhl, boundFunction(self.VVP8r3, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVUOp3_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FF8MfV(self.VVwuhl, boundFunction(self.VVP8r3, self.VVNu5F, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVPD4c(txt):
  return "#f#11ffff00#" + txt
 def VVP8r3(self, mode, words, asPrefix, title):
  VVprUT = self.VVSHyM(mode=mode, words=words, asPrefix=asPrefix)
  if VVprUT : self.VVwuhl.VVJs1i(VVprUT, title)
  else  : self.VVwuhl.VVT6LE("Not found")
 def VVSHyM(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVprUT = []
  files  = self.VVoYfr()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFqhNI(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVqOZ0 = span.group(1)
    else : VVqOZ0 = ""
    VVqOZ0_lCase = VVqOZ0.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVkpae(chName): chNameMod = self.VVPD4c(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVqOZ0, chType, refCode, url)
     ok = False
     tUrl = FFeUdo(url).lower()
     if mode == self.VVuLIF       : ok = True
     elif mode == self.VVcn7c       : ok = True
     elif mode == self.VVz4Ez:
      if CCkpQY.VV6xjj(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVM6Ps:
      if CCkpQY.VV6xjj(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVQwJ6:
      if CCkpQY.VV6xjj(tUrl, compareType="live")  : ok = True
     elif mode == self.VVP0V1:
      if CCkpQY.VV6xjj(tUrl, compareType="movie") : ok = True
     elif mode == self.VVO5Cj:
      if CCkpQY.VV6xjj(tUrl, compareType="series") : ok = True
     elif mode == self.VVfUcY:
      if CCkpQY.VV6xjj(tUrl, compareType="")   : ok = True
     elif mode == self.VVT33r:
      if CCkpQY.VV6xjj(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVcBKW:
      if CCkpQY.VV6xjj(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VV7lgh:
      if CCkpQY.VV6xjj(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VV5Zt0:
      if CCkpQY.VV6xjj(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVkQTW:
      if CCkpQY.VV6xjj(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVrhMj:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVNu5F:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVNkrf:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVcfSd:
      if words[0] == VVqOZ0_lCase:
       ok = True
     elif mode == self.VVtXTk:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VVprUT.append(row)
      chNum += 1
  if VVprUT and mode == self.VVcn7c:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VVprUT)
   for item in VVprUT:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VVprUT = newRows
  return VVprUT
 def VVN0pw(self, bName):
  if bName:
   FF8MfV(self.VVwuhl, boundFunction(self.VVkYpj, bName), title="Adding Channels ...")
 def VVkYpj(self, bName):
  num = 0
  path = VVeXaf + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVeXaf + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVwuhl.VV37Hy():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFxdkh(row[1]))
    totChange += 1
  FFk8Yi(os.path.basename(path))
  self.VVoW0O(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VV9u92(self):
  txt = "Stream Type "
  VVSAYi = []
  VVSAYi.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVSAYi.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVSAYi.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVSAYi.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVSAYi.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVSAYi.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FF3fIR(self, self.VVHI5V, title="Change Reference Types to:", VVSAYi=VVSAYi)
 def VVHI5V(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVziML("1"   )
   elif item == "RT_4097" : self.VVziML("4097")
   elif item == "RT_5001" : self.VVziML("5001")
   elif item == "RT_5002" : self.VVziML("5002")
   elif item == "RT_8192" : self.VVziML("8192")
   elif item == "RT_8193" : self.VVziML("8193")
 def VVziML(self, rType):
  FFhdnr(self, boundFunction(FF8MfV, self, boundFunction(self.VVPecL, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVPecL(self, refType):
  totChange = 0
  files  = self.VVoYfr()
  if files:
   for path in files:
    txt = FFqhNI(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFk8Yi(os.path.basename(path))
  self.VVoW0O(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVomsR(self):
  totFiles = 0
  files  = self.VVoYfr()
  if files:
   totFiles = len(files)
  totChans = 0
  VVprUT = self.VVSHyM()
  if VVprUT:
   totChans = len(VVprUT)
  FFGdNj(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVbMJj(self):
  files  = self.VVoYfr()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFqhNI(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VV3SOs
   else    : color = VV8tYH
   totInvalid = FFxKI9(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFxKI9("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFGdNj(self, txt, title="Check IPTV References")
 def VVvAVf(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVeXaf + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFk8Yi(os.path.basename(path))
  FF7jBe()
  acceptedList = []
  VV58PA = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VV58PA:
   VVMoqN = FF04X5(VV58PA)
   if VVMoqN:
    for service in VVMoqN:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVeXaf + userBName
  bFile = VVeXaf + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFMugq("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFMugq("rm -f '%s'" % path)
  os.system(cmd)
  FF7jBe()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VV3SOs
    else     : res, color = "No" , VV8tYH
    txt += "    %s\t: %s\n" % (item, FFxKI9(res, color))
   FFGdNj(self, txt, title=title)
  else:
   txt = FFv5WO(self, "Could not complete the test on your system!", title=title)
 def VVtvvl(self):
  lameDbChans = CCHa4g.VVzJJ1(self, CCHa4g.VVU8sI)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVoYfr():
    toSave = False
    txt = FFqhNI(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVoW0O(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFv5WO(self, 'No channels in "lamedb" !')
 def VVwOjm(self):
  files  = self.VVoYfr()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FF66GF(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VV32Eh(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVoW0O(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VV8FV0(self):
  iptvRefList = []
  files  = self.VVoYfr()
  if files:
   for path in files:
    txt = FFqhNI(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVwuhl.VV0wLx(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VV32Eh(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVoYfr()
  if files:
   for path in files:
    lines = FF66GF(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVoW0O(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VV32Eh(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVSXFD(self):
  list = None
  if self.VVwuhl:
   list = []
   for row in self.VVwuhl.VV37Hy():
    list.append(row[4] + row[5])
  files  = self.VVoYfr()
  totChange = 0
  if files:
   for path in files:
    lines = FF66GF(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVoW0O(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVoW0O(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FF7jBe()
   if refreshTable and self.VVwuhl:
    VVprUT = self.VVSHyM()
    if VVprUT and self.VVwuhl:
     self.VVwuhl.VVJs1i(VVprUT, self.tableTitle)
     self.VVwuhl.VVT6LE(txt)
   FFGdNj(self, txt, title=title)
  else:
   FFLnSq(self, "No changes.")
 def VVx2nt(self):
  files = self.VVoYfr()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with open(path, "r") as f:
     span = iSearch(r"#NAME\s+(.*)", f.readline(), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VVRfxd = FFQRnQ()
    if VVRfxd:
     for b in VVRfxd:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVoYfr(self):
  return CCkpQY.VVkcul(self)
 @staticmethod
 def VVkcul(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVeXaf + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFqhNI(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVrOUZ(self, VVwuhl, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFeUdo(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFlYRO(self, fncMode=CCA5BL.VVpEO3, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVGxWA(self, VVwuhl, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVRlcJ(self, VVwuhl, title, txt, colList):
  chName, chUrl = self.VVGxWA(VVwuhl, colList)
  self.VVQlk4(VVwuhl, chName, chUrl, "localIptv")
 def VVa64e(self, mode, VVwuhl, colList):
  chName, chUrl, picUrl, refCode = self.VVDTAE(mode, colList)
  return chName, chUrl
 def VV0mhd(self, mode, VVwuhl, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVDTAE(mode, colList)
  self.VVQlk4(VVwuhl, chName, chUrl, mode)
 def VVQlk4(self, VVwuhl, chName, chUrl, playerFlag):
  chName = FFxdkh(chName)
  if self.VVkpae(chName):
   FFlFRp(VVwuhl, "This is a marker!", 300)
  else:
   FF8MfV(VVwuhl, boundFunction(self.VVKmGi, VVwuhl, chUrl, playerFlag), title="Playing ...")
 def VVKmGi(self, VVwuhl, chUrl, playerFlag):
  FFY7Np(self, chUrl, VV4NU5=False)
  self.session.open(CCewzF, portalTableParam=(self, VVwuhl, playerFlag))
 @staticmethod
 def VVkpae(chName):
  mark = ("--", "__", "==", "##", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVZ6el(self, VVwuhl, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
  if refCode:
   bName = FFueaG()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFGsMp(refCode, origUrl, chName) }
   VVwuhl.VVycrI_partial(colDict, VV6xfF=True)
 def VV4bNW(self, m3uMode):
  path = CCkpQY.VVrMGU()
  lines = FFs4zJ("find %s %s -iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'" % (path, FFfLcR(1)))
  if lines:
   lines.sort()
   VVSAYi = []
   for line in lines:
    VVSAYi.append((line, line))
   if m3uMode == self.VVtvjO:
    title = "Browse Server from M3U URLs"
    VVJtpI = ("All to Playlist", self.VVytE2)
   else:
    title = "M3U/M3U8 Channels Browser"
    VVJtpI = None
   OKBtnFnc = boundFunction(self.VV8TMz, m3uMode, title)
   VViqfZ = ("Show Full Path", self.VVQGYH)
   VVEbC5 = ("Delete File", boundFunction(self.VVh2d2, boundFunction(FF8MfV, self, boundFunction(self.VV4bNW, m3uMode), title="Searching ...")))
   FF3fIR(self, None, title=title, VVSAYi=VVSAYi, width=1200, OKBtnFnc=OKBtnFnc, VViqfZ=VViqfZ, VVEbC5=VVEbC5, VVJtpI=VVJtpI)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n\n%s" % path
   FFv5WO(self, 'No ".m3u" files found %s' % txt)
 def VVQGYH(self, VVMsOjObj, url):
  FFGdNj(self, url, title="Full Path")
 def VV8TMz(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == self.VVtvjO:
    FF8MfV(menuInstance, boundFunction(self.VVReI4, title, path))
   else:
    FF8MfV(menuInstance, boundFunction(self.VVQ3PC, path))
 def VVQ3PC(self, srcPath):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFqhNI(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  processChanName = CCBlS0()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVB12I(propLine, "group-title") or "-"
   if not group == "-" and processChanName.VVFsz2(group):
    groups.add(group)
  VVprUT = []
  if len(groups) > 0:
   title = "Groups"
   for group in groups:
    VVprUT.append((group, group))
   VVprUT.append(("ALL", ""))
   VVprUT.sort(key=lambda x: x[0].lower())
   VVAIMO = self.VVIOAu
   VVd2cp  = ("Select" , boundFunction(self.VVj2Z8, srcPath), [])
   widths   = (100  , 0)
   VVDKYV  = (LEFT  , LEFT)
   FFEtMz(self, None, title=title, width= 800, header=None, VV06zW=VVprUT, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=30, VVd2cp=VVd2cp, VVAIMO=VVAIMO
     , VVM7V1="#11110022", VVUL9C="#11110022", VVehrL="#11110022", VVTG9d="#00444400")
  else:
   txt = FFqhNI(srcPath)
   self.VVO6Cx(txt, filterGroup="")
 def VVj2Z8(self, srcPath, VVwuhl, title, txt, colList):
  group = colList[1]
  txt = FFqhNI(srcPath)
  self.VVO6Cx(txt, filterGroup=group)
 def VVO6Cx(self, txt, filterGroup=""):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = "Group : %s" % (filterGroup or "ALL")
  if lst:
   self.session.open(CCHSPO, barTheme=CCHSPO.VVSU2X
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VVu5We, lst, filterGroup)
       , VVCoUZ = boundFunction(self.VVtOcN, title, bName))
  else:
   self.VVBEVi("No valid lines found !", title)
 def VVu5We(self, lst, filterGroup, progBarObj):
  progBarObj.VVGy5N = []
  progBarObj.VVKFmP(len(lst))
  processChanName = CCBlS0()
  num = 0
  for cols in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVWBRz(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVB12I(propLine, "tvg-logo")
   group = self.VVB12I(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if group and not processChanName.VVFsz2(group) : skip = True
    if chName and not processChanName.VVFsz2(chName): skip = True
    if not skip and progBarObj:
     num += 1
     progBarObj.VVGy5N.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if progBarObj:
   progBarObj.VVAESW_forcedUpdate("Loading %d Channels" % len(progBarObj.VVGy5N))
 def VVtOcN(self, title, bName, VV73UU, VVGy5N, threadCounter, threadTotal, threadErr):
  if VVGy5N:
   VVAIMO = self.VVIOAu
   VVd2cp  = ("Select"    , boundFunction(self.VVAghP, title) , [])
   VVvxfu = (""     , self.VVH1bc         , [])
   VVJD06 = ("Download PIcons" , self.VVcbtH        , [])
   VV8khl = ("Add ALL to Bouquet" , boundFunction(self.VVqke9, bName) , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVDKYV  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFEtMz(self, None, title=title, header=header, VV06zW=VVGy5N, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=28, VVd2cp=VVd2cp, VVAIMO=VVAIMO, VVvxfu=VVvxfu, VVJD06=VVJD06, VV8khl=VV8khl, VVgpgw=True, searchCol=1
     , VVM7V1="#0a00192B", VVUL9C="#0a00192B", VVehrL="#0a00192B", VVTG9d="#00000000")
  else:
   self.VVBEVi("No valid lines found !", title)
 def VVcbtH(self, VVwuhl, title, txt, colList):
  self.VV0DAx(VVwuhl, "m3u/m3u8")
 def VVqke9(self, bName, VVwuhl, title, txt, colList):
  FF8MfV(VVwuhl, boundFunction(self.VV98pQ, bName, VVwuhl), title="Adding Channels ...")
 def VV98pQ(self, bName, VVwuhl):
  bNameFile = CCkpQY.VViR57_forBouquet(bName)
  num  = 0
  path = VVeXaf + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVeXaf + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   catID = "33"
   rowNum = 0
   for row in VVwuhl.VV37Hy():
    chName = row[1].strip()
    url  = row[3].strip()
    chUrl = self.VVeWAZ(rowNum, url, chName)
    rowNum += 1
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FFk8Yi(os.path.basename(path))
  self.VVoW0O(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVeWAZ(self, rowNum, url, chName):
  refCode = self.VVaqae(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFXZWp(url), chName)
  return chUrl
 def VVaqae(self, rowNum, url, chName):
  span = iSearch(r"\/(\d{2,})", url, IGNORECASE)
  if span : stID = span.group(1)
  else : stID = "444"
  catID = "333"
  chNum = str(rowNum + 1)
  refCode = self.VVOUlP(catID, stID, chNum)
  return refCode
 def VVB12I(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVAghP(self, Title, VVwuhl, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FF8MfV(VVwuhl, boundFunction(self.VVpAx9, Title, VVwuhl, colList), title="Checking Server ...")
  else:
   self.VV72EH(VVwuhl, url, chName)
 def VVpAx9(self, title, VVwuhl, colList):
  if not CCIF1R.VVcQFb(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCjeUi.VVDXXh(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVSAYi = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCkpQY.VVgqkU(url, fPath)
     VVSAYi.append((resol, fullUrl))
    if VVSAYi:
     if len(VVSAYi) > 1:
      FF3fIR(self, boundFunction(self.VVoUKu, VVwuhl, chName), VVSAYi=VVSAYi, title="Resolution", VVdU6y=True, VVBISI=True)
     else:
      self.VV72EH(VVwuhl, VVSAYi[0][1], chName)
    else:
     self.VV6xfFor("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVO6Cx(txt, filterGroup="")
      return
    self.VV72EH(VVwuhl, url, chName)
   else:
    self.VVBEVi("Cannot process this channel !", title)
  else:
   self.VVBEVi(err, title)
 def VVoUKu(self, VVwuhl, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VV72EH(VVwuhl, resolUrl, chName)
 def VV72EH(self, VVwuhl, url, chName):
  FF8MfV(VVwuhl, boundFunction(self.VVAALs, VVwuhl, url, chName), title="Playing ...")
 def VVAALs(self, VVwuhl, url, chName):
  chUrl = self.VVeWAZ(VVwuhl.VVZMuy(), url, chName)
  FFY7Np(self, chUrl, VV4NU5=False)
  self.session.open(CCewzF, portalTableParam=(self, VVwuhl, "m3u/m3u8"))
 def VV8IPC(self, VVwuhl, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVeWAZ(VVwuhl.VVZMuy(), url, chName)
  return chName, chUrl
 def VVH1bc(self, VVwuhl, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFlYRO(self, fncMode=CCA5BL.VVpEO3, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVBEVi(self, err, title):
  FFv5WO(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVIOAu(self, VVwuhl):
  if self.m3uOrM3u8File:
   self.close()
  VVwuhl.cancel()
 def VVytE2(self, VVMsOjObj, item=None):
  FF8MfV(VVMsOjObj, boundFunction(self.VVH8s9, VVMsOjObj, item))
 def VVH8s9(self, VVMsOjObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVMsOjObj.VVSAYi):
    path = item[1]
    if fileExists(path):
     enc = FFJDeD(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VVTPzT(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCkpQY.VVrMGU(orExportPath=True)
    pListF = "%sPlaylist_%s.txt" % (path, FFS6oF())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVMsOjObj.VVSAYi)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFGdNj(self, txt, title=title)
   else:
    FFv5WO(self, "Could not obtain URLs from this file list !", title=title)
 def VVIEFz(self):
  path = CCkpQY.VVrMGU()
  lines = FFs4zJ('find %s %s -iname "*playlist*" | grep -i ".txt"' % (path, FFfLcR(1)))
  if lines:
   lines.sort()
   VVSAYi = []
   for line in lines:
    VVSAYi.append((line, line))
   OKBtnFnc = self.VVhbDE
   VVEbC5 = ("Delete File", boundFunction(self.VVh2d2, boundFunction(FF8MfV, self, self.VVIEFz, title="Searching ...")))
   FF3fIR(self, None, title="Select Playlist File", VVSAYi=VVSAYi, width=1200, OKBtnFnc=OKBtnFnc, VVEbC5=VVEbC5)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFv5WO(self, 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt)
 def VVhbDE(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FF8MfV(menuInstance, boundFunction(self.VVX5Rm, menuInstance, path), title="Processing File ...")
 def VVX5Rm(self, fileMenuInstance, path):
  enc = FFJDeD(path, self)
  if enc == -1:
   return
  VVprUT = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0]
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFhBEj(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCkpQY.VVkPMJ(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVprUT:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(filter(None, [item[5], item[0]]))
     num += 1
     VVprUT.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVprUT:
   title = "Playlist File"
   VVd2cp  = ("Start"    , boundFunction(self.VVTxFy, title)  , [])
   VVSxFV = ("Home Menu"   , FF19xV         , [])
   VVJD06 = ("Download M3U File" , self.VV5uEq     , [])
   VV8khl = ("Edit File"   , boundFunction(self.VV8tyu, path) , [])
   VVulZM = ("Check & Filter"  , boundFunction(self.VVtmfw, fileMenuInstance, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVDKYV  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFEtMz(self, None, title=title, header=header, VV06zW=VVprUT, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=26, VVd2cp=VVd2cp, VVSxFV=VVSxFV, VVulZM=VVulZM, VVJD06=VVJD06, VV8khl=VV8khl, VVM7V1="#11001116", VVUL9C="#11001116", VVehrL="#11001116", VVTG9d="#00003635", VVCgV5="#0a333333", VVoitp="#11331100", VVgpgw=True)
  else:
   FFv5WO(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VV5uEq(self, VVwuhl, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFhdnr(self, boundFunction(FF8MfV, VVwuhl, boundFunction(self.VVWRkd, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVWRkd(self, title, url):
  path, err = FFzKLB(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFv5WO(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFqhNI(path)
   if '{"user_info":{"auth":0}}' in txt:
    os.system(FFMugq("rm -f '%s'" % path))
    FFv5WO(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    os.system(FFMugq("rm -f '%s'" % path))
    FFv5WO(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCkpQY.VVrMGU(orExportPath=True) + fName
    os.system(FFMugq("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FFLnSq(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFv5WO(self, "Could not download the M3U file!", title=errTitle)
 def VVTxFy(self, Title, VVwuhl, title, txt, colList):
  url = colList[6]
  FF8MfV(VVwuhl, boundFunction(self.VV29xH, Title, url), title="Checking Server ...")
 def VV8tyu(self, path, VVwuhl, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCVYVr(self, path, VVCoUZ=boundFunction(self.VVkh56, VVwuhl), curRowNum=rowNum)
  else    : FF7BRF(self, path)
 def VVkh56(self, VVwuhl, fileChanged):
  if fileChanged:
   VVwuhl.cancel()
 def VVRFeu(self, title):
  curChName = self.VVwuhl.VVuoNu(1)
  FFMKq2(self, boundFunction(self.VVnDTo, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVnDTo(self, title, name):
  if name:
   lameDbChans = CCHa4g.VVzJJ1(self, CCHa4g.VVOkEr, VV2EYo=False, VVGuAm=False)
   list = []
   if lameDbChans:
    processChanName = CCBlS0()
    name = processChanName.VVBjce(name)
    ratio = "1"
    for item in lameDbChans:
     if name in item[0].lower():
      list.append((item[0], FF6tzg(item[2]), item[3], ratio))
   if list : self.VV3Wvr(list, title)
   else : FFv5WO(self, "Not found:\n\n%s" % name, title=title)
 def VVGHE8(self, title):
  curChName = self.VVwuhl.VVuoNu(1)
  self.session.open(CCHSPO, barTheme=CCHSPO.VVSU2X
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVlGpg
      , VVCoUZ = boundFunction(self.VVpfDC, title, curChName))
 def VVlGpg(self, progBarObj):
  curChName = self.VVwuhl.VVuoNu(1)
  lameDbChans = CCHa4g.VVzJJ1(self, CCHa4g.VV7MRV, VV2EYo=False, VVGuAm=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVGy5N = []
  progBarObj.VVKFmP(len(lameDbChans))
  processChanName = CCBlS0()
  curCh = processChanName.VVBjce(curChName)
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CCOmM2.VVPrOe(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVWBRz(1, True)
   if progBarObj and ratio > 50:
    progBarObj.VVGy5N.append((chName, FF6tzg(sat), refCode.replace("_", ":"), str(ratio)))
 def VVpfDC(self, title, curChName, VV73UU, VVGy5N, threadCounter, threadTotal, threadErr):
  if VVGy5N: self.VV3Wvr(VVGy5N, title)
  elif VV73UU: FFv5WO(self, "No similar names found for:\n\n%s" % curChName, title)
 def VV3Wvr(self, VVprUT, title):
  curChName = self.VVwuhl.VVuoNu(1)
  curRefCode = self.VVwuhl.VVuoNu(4)
  curUrl  = self.VVwuhl.VVuoNu(5)
  VVprUT = sorted(VVprUT, key=lambda x: (100-int(x[3]), x[0].lower()))
  VVd2cp  = ("Share Sat/C/T Ref.", boundFunction(self.VVRrKJ, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFEtMz(self, None, title=title, header=header, VV06zW=VVprUT, VVTS0u=widths, VVp74Q=26, VVd2cp=VVd2cp, VVM7V1="#0a00112B", VVUL9C="#0a001126", VVehrL="#0a001126", VVTG9d="#00000000")
 def VVRrKJ(self, newtitle, curChName, curRefCode, curUrl, VVwuhl, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFhdnr(self.VVwuhl, boundFunction(FF8MfV, self.VVwuhl, boundFunction(self.VV7o0K, VVwuhl, data)), ques, title=newtitle, VVD4Yr=True)
 def VV7o0K(self, VVwuhl, data):
  VVwuhl.cancel()
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVoYfr():
    txt = FFqhNI(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FF7jBe()
    newRow = []
    for i in range(6):
     newRow.append(self.VVwuhl.VVuoNu(i))
    newRow[4] = newRefCode
    done = self.VVwuhl.VVVSNs(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFYJiO(boundFunction(FFLnSq , self, resTxt, title=title))
  elif resErr: FFYJiO(boundFunction(FFv5WO , self, resErr, title=title))
 def VVtmfw(self, fileMenuInstance, path, VVwuhl, title, txt, colList):
  self.session.open(CCHSPO, barTheme=CCHSPO.VVSU2X
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVbjB0, VVwuhl)
      , VVCoUZ = boundFunction(self.VVJAoL, fileMenuInstance, path, VVwuhl))
 def VVbjB0(self, VVwuhl, progBarObj):
  progBarObj.VVKFmP(VVwuhl.VV7zcM())
  progBarObj.VVGy5N = []
  for row in VVwuhl.VV37Hy():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVWBRz(1, True)
   qUrl = self.VVBnRW(self.VVwLGj, row[6])
   txt, err = self.VVXTOQ(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVHt2d(item, "auth") == "0":
       progBarObj.VVGy5N.append(qUrl)
    except:
     pass
 def VVJAoL(self, fileMenuInstance, path, VVwuhl, VV73UU, VVGy5N, threadCounter, threadTotal, threadErr):
  if VV73UU:
   list = VVGy5N
   title = "Authorized Servers"
   if list:
    totChk = VVwuhl.VV7zcM()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFS6oF()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVIEFz()
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFxKI9(str(totAuth), VV3SOs)
     txt += "%s\n\n%s"    %  (FFxKI9("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFGdNj(self, txt, title=title)
     VVwuhl.close()
     fileMenuInstance.close()
    else:
     FFLnSq(self, "All URLs are authorized.", title=title)
   else:
    FFv5WO(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVXTOQ(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   cont = res.headers.get("Content-Type")
   if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
    return "", "Unexpected server data type ( %s )" % cont
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVkPMJ(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VV6xjj(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVBnRW(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVkPMJ(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVwLGj   : return "%s"            % url
  elif mode == self.VVR1iH   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVInrt   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVvO8v  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVQibI  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVw1KM : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VV2qmD   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVM1dn    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVkh8k  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVkLf6 : return "%s&action=get_live_streams"      % url
  elif mode == self.VVYTkQ  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVHt2d(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFt8n3(int(val))
    elif is_base64 : val = FFlFvV(val)
    elif isToHHMMSS : val = FFK79w(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVReI4(self, title, path):
  if fileExists(path):
   enc = FFJDeD(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VVTPzT(line)
     if qUrl:
      break
   if qUrl : self.VV29xH(title, qUrl)
   else : FFv5WO(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFv5WO(self, "Cannot open file :\n\n%s" % path, title=title)
 def VV8eUh_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VV6Tb7()
  if qUrl:
   host, mac, isPortalUrl = self.VVgFqL(iptvRef)
   if isPortalUrl:
    if host and mac : self.VV8eUh(self, host, mac)
    else   : FFv5WO(self, "Error in current channel URL/MAC !", title=title)
   else:
    FF8MfV(self, boundFunction(self.VV29xH, title, qUrl), title="Checking Server ...")
  else:
   FFv5WO(self, "Error in current channel URL !", title=title)
 def VV6Tb7(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
  qUrl = self.VVTPzT(decodedUrl)
  return qUrl, iptvRef
 def VVTPzT(self, url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 : return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else    : return ""
 def VV29xH(self, title, url):
  self.VVmDIOData = {}
  qUrl = self.VVBnRW(self.VVwLGj, url)
  txt, err = self.VVXTOQ(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVmDIOData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVmDIOData["username"    ] = self.VVHt2d(item, "username"        )
    self.VVmDIOData["password"    ] = self.VVHt2d(item, "password"        )
    self.VVmDIOData["message"    ] = self.VVHt2d(item, "message"        )
    self.VVmDIOData["auth"     ] = self.VVHt2d(item, "auth"         )
    self.VVmDIOData["status"    ] = self.VVHt2d(item, "status"        )
    self.VVmDIOData["exp_date"    ] = self.VVHt2d(item, "exp_date"    , isDate=True )
    self.VVmDIOData["is_trial"    ] = self.VVHt2d(item, "is_trial"        )
    self.VVmDIOData["active_cons"   ] = self.VVHt2d(item, "active_cons"       )
    self.VVmDIOData["created_at"   ] = self.VVHt2d(item, "created_at"   , isDate=True )
    self.VVmDIOData["max_connections"  ] = self.VVHt2d(item, "max_connections"      )
    self.VVmDIOData["allowed_output_formats"] = self.VVHt2d(item, "allowed_output_formats"    )
    lst = []
    key = "allowed_output_formats"
    if key in item:
     for item in item[key]:
      lst.append(str(item))
     self.VVmDIOData[key] = lst
    item = tDict["server_info"]
    self.VVmDIOData["url"    ] = self.VVHt2d(item, "url"        )
    self.VVmDIOData["port"    ] = self.VVHt2d(item, "port"        )
    self.VVmDIOData["https_port"  ] = self.VVHt2d(item, "https_port"      )
    self.VVmDIOData["server_protocol" ] = self.VVHt2d(item, "server_protocol"     )
    self.VVmDIOData["rtmp_port"   ] = self.VVHt2d(item, "rtmp_port"       )
    self.VVmDIOData["timezone"   ] = self.VVHt2d(item, "timezone"       )
    self.VVmDIOData["timestamp_now"  ] = self.VVHt2d(item, "timestamp_now"  , isDate=True )
    self.VVmDIOData["time_now"   ] = self.VVHt2d(item, "time_now"       )
    VVSAYi  = self.VVEcv3(True)
    OKBtnFnc = self.VVmDIOOptions
    VV9Wtd = ("Home Menu", FF19xV)
    VVJtpI = ("Bookmark Server", boundFunction(CCkpQY.VVJpek, self, False, self.VVmDIOData["playListURL"]))
    FF3fIR(self, None, title="IPTV Server Resources", VVSAYi=VVSAYi, OKBtnFnc=OKBtnFnc, VV9Wtd=VV9Wtd, VVJtpI=VVJtpI)
   else:
    err = "Could not get data from server !"
  if err:
   FFv5WO(self, err, title=title)
  FFlFRp(self)
 def VVmDIOOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FF8MfV(menuInstance, boundFunction(self.VVOLPR, self.VVR1iH  , title=title), title=wTxt)
   elif ref == "vod"   : FF8MfV(menuInstance, boundFunction(self.VVOLPR, self.VVInrt  , title=title), title=wTxt)
   elif ref == "series"  : FF8MfV(menuInstance, boundFunction(self.VVOLPR, self.VVvO8v , title=title), title=wTxt)
   elif ref == "catchup"  : FF8MfV(menuInstance, boundFunction(self.VVOLPR, self.VVQibI , title=title), title=wTxt)
   elif ref == "accountInfo" : FF8MfV(menuInstance, boundFunction(self.VVTCTj           , title=title), title=wTxt)
 def VVTCTj(self, title):
  rows = []
  for key, val in self.VVmDIOData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VVSxFV = ("Home Menu", FF19xV, [])
  header   = ("Num", "User/Server" , "Subject" , "Value" )
  widths   = (0 , 15   , 35  , 50  )
  FFEtMz(self, None, title=title, width=1200, header=header, VV06zW=rows, VVTS0u=widths, VVp74Q=26, VVSxFV=VVSxFV, VVM7V1="#0a00292B", VVUL9C="#0a002126", VVehrL="#0a002126", VVTG9d="#00000000", searchCol=2)
 def VVWQNA(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CCBlS0()
    if mode in (self.VV2qmD, self.VVYTkQ):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVHt2d(item, "num"         )
      name     = self.VVHt2d(item, "name"        )
      stream_id    = self.VVHt2d(item, "stream_id"       )
      stream_icon    = self.VVHt2d(item, "stream_icon"       )
      epg_channel_id   = self.VVHt2d(item, "epg_channel_id"      )
      added     = self.VVHt2d(item, "added"    , isDate=True )
      is_adult    = self.VVHt2d(item, "is_adult"       )
      category_id    = self.VVHt2d(item, "category_id"       )
      tv_archive    = self.VVHt2d(item, "tv_archive"       )
      name = processChanName.VVFsz2(name)
      if name:
       if mode == self.VV2qmD or mode == self.VVYTkQ and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVM1dn:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVHt2d(item, "num"         )
      name    = self.VVHt2d(item, "name"        )
      stream_id   = self.VVHt2d(item, "stream_id"       )
      stream_icon   = self.VVHt2d(item, "stream_icon"       )
      added    = self.VVHt2d(item, "added"    , isDate=True )
      is_adult   = self.VVHt2d(item, "is_adult"       )
      category_id   = self.VVHt2d(item, "category_id"       )
      container_extension = self.VVHt2d(item, "container_extension"     ) or "mp4"
      name = processChanName.VVFsz2(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVkh8k:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVHt2d(item, "num"        )
      name    = self.VVHt2d(item, "name"       )
      series_id   = self.VVHt2d(item, "series_id"      )
      cover    = self.VVHt2d(item, "cover"       )
      genre    = self.VVHt2d(item, "genre"       )
      episode_run_time = self.VVHt2d(item, "episode_run_time"    )
      category_id   = self.VVHt2d(item, "category_id"      )
      container_extension = self.VVHt2d(item, "container_extension"    ) or "mp4"
      name = processChanName.VVFsz2(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVOLPR(self, mode, title):
  cList, err = self.VVZCqh(mode)
  if cList and mode == self.VVQibI:
   cList = self.VVaLdZ(cList)
  if err:
   FFv5WO(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVM7V1, VVUL9C, VVehrL, VVTG9d = self.VVNW5M(mode)
   mName = self.VVeHee(mode)
   if   mode == self.VVR1iH  : fMode = self.VV2qmD
   elif mode == self.VVInrt  : fMode = self.VVM1dn
   elif mode == self.VVvO8v : fMode = self.VVkh8k
   elif mode == self.VVQibI : fMode = self.VVYTkQ
   if mode == self.VVQibI:
    VV8khl = None
   else:
    VV8khl = ("Find in %s" % mName , boundFunction(self.VVvnEJ, fMode) , [])
   VVd2cp   = ("Show List"   , boundFunction(self.VVjoKB, mode) , [])
   VVSxFV  = ("Home Menu"   , FF19xV          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFEtMz(self, None, title=title, width=1200, header=header, VV06zW=cList, VVTS0u=widths, VVp74Q=30, VVSxFV=VVSxFV, VV8khl=VV8khl, VVd2cp=VVd2cp, VVM7V1=VVM7V1, VVUL9C=VVUL9C, VVehrL=VVehrL, VVTG9d=VVTG9d)
  else:
   FFv5WO(self, "No list from server !", title=title)
  FFlFRp(self)
 def VVZCqh(self, mode):
  qUrl  = self.VVBnRW(mode, self.VVmDIOData["playListURL"])
  txt, err = self.VVXTOQ(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    processChanName = CCBlS0()
    for item in tDict:
     category_id  = self.VVHt2d(item, "category_id"  )
     category_name = self.VVHt2d(item, "category_name" )
     parent_id  = self.VVHt2d(item, "parent_id"  )
     category_name = processChanName.VVIPY9(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVaLdZ(self, catList):
  mode  = self.VVYTkQ
  qUrl  = self.VVBnRW(mode, self.VVmDIOData["playListURL"])
  txt, err = self.VVXTOQ(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVWQNA(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVjoKB(self, mode, VVwuhl, title, txt, colList):
  title = colList[1]
  FF8MfV(VVwuhl, boundFunction(self.VVWSJD, mode, VVwuhl, title, txt, colList), title="Downloading ...")
 def VVWSJD(self, mode, VVwuhl, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVeHee(mode) + " : "+ bName
  if   mode == self.VVR1iH  : mode = self.VV2qmD
  elif mode == self.VVInrt  : mode = self.VVM1dn
  elif mode == self.VVvO8v : mode = self.VVkh8k
  elif mode == self.VVQibI : mode = self.VVYTkQ
  qUrl  = self.VVBnRW(mode, self.VVmDIOData["playListURL"], catID)
  txt, err = self.VVXTOQ(qUrl)
  list  = []
  if not err and mode in (self.VV2qmD, self.VVM1dn, self.VVkh8k, self.VVYTkQ):
   list, err = self.VVWQNA(mode, txt)
  if err:
   FFv5WO(self, err, title=title)
  elif list:
   VVSxFV  = ("Home Menu"   , FF19xV             , [])
   if mode in (self.VV2qmD, self.VVYTkQ):
    VVM7V1, VVUL9C, VVehrL, VVTG9d = self.VVNW5M(mode)
    VVvxfu = (""     , boundFunction(self.VVhspf, mode)     , [])
    VVJD06 = ("Download Options" , boundFunction(self.VV536O, mode, "", "")  , [])
    VV8khl = ("Add ALL to Bouquet" , boundFunction(self.VVwxs0, mode, bName)  , [])
    if mode == self.VV2qmD:
     VVd2cp = ("Play"    , boundFunction(self.VV0mhd, mode)     , [])
    elif mode == self.VVYTkQ:
     VVd2cp  = ("Programs", boundFunction(self.VVj9ui_fromIptvTable, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVDKYV  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVM1dn:
    VVM7V1, VVUL9C, VVehrL, VVTG9d = self.VVNW5M(mode)
    VVd2cp  = ("Play"    , boundFunction(self.VV0mhd, mode)    , [])
    VVvxfu = (""     , boundFunction(self.VVhspf, mode)    , [])
    VVJD06 = ("Download Options" , boundFunction(self.VV536O, mode, "v", ""), [])
    VV8khl = ("Add ALL to Bouquet" , boundFunction(self.VVwxs0, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVDKYV  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVkh8k:
    VVM7V1, VVUL9C, VVehrL, VVTG9d = self.VVNW5M("series2")
    VVd2cp  = ("Show Seasons", boundFunction(self.VVcl8u, mode) , [])
    VVvxfu = ("", boundFunction(self.VVZ2VO, mode)  , [])
    VVJD06 = None
    VV8khl = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVDKYV  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFEtMz(self, None, title=title, header=header, VV06zW=list, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=26, VVd2cp=VVd2cp, VVSxFV=VVSxFV, VVJD06=VVJD06, VV8khl=VV8khl, VVvxfu=VVvxfu, VVM7V1=VVM7V1, VVUL9C=VVUL9C, VVehrL=VVehrL, VVTG9d=VVTG9d, VVgpgw=True, searchCol=1)
  else:
   FFv5WO(self, "No Channels found !", title=title)
  FFlFRp(self)
 def VVj9ui_fromIptvTable(self, mode, bName, VVwuhl, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVmDIOData["playListURL"]
  ok_fnc  = boundFunction(self.VVATCs, hostUrl, chName, catId, streamId)
  FF8MfV(VVwuhl, boundFunction(CCkpQY.VVj9ui, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVATCs(self, chUrl, chName, catId, streamId, VVwuhl, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCkpQY.VVkPMJ(chUrl)
   chNum = "333"
   refCode = CCkpQY.VVOUlP(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFY7Np(self, chUrl, VV4NU5=False)
   self.session.open(CCewzF)
  else:
   FFv5WO(self, "Incorrect Timestamp", pTitle)
 def VVcl8u(self, mode, VVwuhl, title, txt, colList):
  title = colList[1]
  FF8MfV(VVwuhl, boundFunction(self.VVnkJs, mode, VVwuhl, title, txt, colList), title="Downloading ...")
 def VVnkJs(self, mode, VVwuhl, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVBnRW(self.VVw1KM, self.VVmDIOData["playListURL"], series_id)
  txt, err = self.VVXTOQ(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVHt2d(tDict["info"], "name"   )
      category_id = self.VVHt2d(tDict["info"], "category_id" )
      icon  = self.VVHt2d(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVHt2d(EP, "id"     )
        episode_num   = self.VVHt2d(EP, "episode_num"   )
        epTitle    = self.VVHt2d(EP, "title"     )
        container_extension = self.VVHt2d(EP, "container_extension" )
        seasonNum   = self.VVHt2d(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFv5WO(self, err, title=title)
  elif list:
   VVSxFV = ("Home Menu"   , FF19xV             , [])
   VVJD06 = ("Download Options" , boundFunction(self.VV536O, mode, "s", title) , [])
   VV8khl = ("Add ALL to Bouquet" , boundFunction(self.VVwxs0, mode, title)  , [])
   VVvxfu = (""     , boundFunction(self.VVhspf, mode)     , [])
   VVd2cp  = ("Play"    , boundFunction(self.VV0mhd, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVDKYV  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFEtMz(self, None, title=title, header=header, VV06zW=list, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=26, VVSxFV=VVSxFV, VVJD06=VVJD06, VVd2cp=VVd2cp, VVvxfu=VVvxfu, VV8khl=VV8khl, VVM7V1="#0a00292B", VVUL9C="#0a002126", VVehrL="#0a002126", VVTG9d="#00000000")
  else:
   FFv5WO(self, "No Channels found !", title=title)
  FFlFRp(self)
 def VVvnEJ(self, mode, VVwuhl, title, txt, colList):
  VVSAYi = []
  VVSAYi.append(("Keyboard"  , "manualEntry"))
  VVSAYi.append(("From Filter" , "fromFilter"))
  FF3fIR(self, boundFunction(self.VVxMRK, VVwuhl, mode), title="Input Type", VVSAYi=VVSAYi, width=400)
 def VVxMRK(self, VVwuhl, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFMKq2(self, boundFunction(self.VV9w0u, VVwuhl, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCWTeq(self)
    filterObj.VV1ymy(boundFunction(self.VV9w0u, VVwuhl, mode))
 def VV9w0u(self, VVwuhl, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CCBlS0()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVgLOv(words):
     FFv5WO(self, processChanName.VVeuS5(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CCHSPO, barTheme=CCHSPO.VVSU2X
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VVRPRT, VVwuhl, mode, title, words, toFind, asPrefix, processChanName)
         , VVCoUZ = boundFunction(self.VVU6e0, mode, toFind, title))
   else:
    FFv5WO(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVRPRT(self, VVwuhl, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVKFmP(VVwuhl.VVI71A())
  progBarObj.VVGy5N = []
  for row in VVwuhl.VV37Hy():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVWBRz(1)
   progBarObj.VVAESW_fromIptvFind(catName)
   qUrl  = self.VVBnRW(mode, self.VVmDIOData["playListURL"], catID)
   txt, err = self.VVXTOQ(qUrl)
   if not err:
    tList, err = self.VVWQNA(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VVFsz2(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VV2qmD:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VVGy5N.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVM1dn:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VVGy5N.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVkh8k:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VVGy5N.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVU6e0(self, mode, toFind, title, VV73UU, VVGy5N, threadCounter, threadTotal, threadErr):
  if VVGy5N:
   title = self.VVbNSB(mode, toFind)
   if mode == self.VV2qmD or mode == self.VVM1dn:
    if mode == self.VVM1dn : typ = "v"
    else          : typ = ""
    bName   = CCkpQY.VViR57_forBouquet(toFind)
    VVd2cp  = ("Play"     , boundFunction(self.VV0mhd, mode)    , [])
    VVJD06 = ("Download Options" , boundFunction(self.VV536O, mode, typ, ""), [])
    VV8khl = ("Add ALL to Bouquet" , boundFunction(self.VVwxs0, mode, bName) , [])
   elif mode == self.VVkh8k:
    VVd2cp  = ("Show Seasons"  , boundFunction(self.VVcl8u, mode)    , [])
    VV8khl = None
    VVJD06 = None
   VVvxfu  = (""     , boundFunction(self.VVhspf, mode)    , [])
   VVSxFV  = ("Home Menu"   , FF19xV            , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVDKYV  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVwuhl = FFEtMz(self, None, title=title, header=header, VV06zW=VVGy5N, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=26, VVd2cp=VVd2cp, VVSxFV=VVSxFV, VVJD06=VVJD06, VV8khl=VV8khl, VVvxfu=VVvxfu, VVM7V1="#0a00292B", VVUL9C="#0a002126", VVehrL="#0a002126", VVTG9d="#00000000", VVgpgw=True, searchCol=1)
   if not VV73UU:
    FFlFRp(VVwuhl, "Stopped" , 1000)
  else:
   if VV73UU:
    FFv5WO(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVDTAE(self, mode, colList):
  if mode in (self.VV2qmD, self.VVYTkQ):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVM1dn:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFxdkh(chName)
  url = self.VVmDIOData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVkPMJ(url)
  refCode = self.VVOUlP(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVhspf(self, mode, VVwuhl, title, txt, colList):
  FF8MfV(VVwuhl, boundFunction(self.VVUOKE, mode, VVwuhl, title, txt, colList))
 def VVUOKE(self, mode, VVwuhl, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVDTAE(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFlYRO(self, fncMode=CCA5BL.VVADD0, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVZ2VO(self, mode, VVwuhl, title, txt, colList):
  FF8MfV(VVwuhl, boundFunction(self.VVPogc, mode, VVwuhl, title, txt, colList))
 def VVPogc(self, mode, VVwuhl, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFlYRO(self, fncMode=CCA5BL.VViiw6, chName=name, text=txt, picUrl=Cover)
 def VVwxs0(self, mode, bName, VVwuhl, title, txt, colList):
  FF8MfV(VVwuhl, boundFunction(self.VV97WR, mode, bName, VVwuhl, title, txt, colList), title="Adding Channels ...")
 def VV97WR(self, mode, bName, VVwuhl, title, txt, colList):
  url = self.VVmDIOData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVkPMJ(url)
  bNameFile = CCkpQY.VViR57_forBouquet(bName)
  num  = 0
  path = VVeXaf + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVeXaf + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVwuhl.VV37Hy():
    chName, chUrl, picUrl, refCode = self.VVDTAE(mode, row)
    f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
    f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
    totChange += 1
  FFk8Yi(os.path.basename(path))
  self.VVoW0O(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VV536O(self, mode, typ, seriesName, VVwuhl, title, txt, colList):
  VVSAYi = []
  VVSAYi.append(("Download all PIcons"       , "dnldPicons" ))
  if typ:
   VVSAYi.append(VVudpG)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVSAYi.append(("Download Selected %s" % tName    , "dnldSel"  ))
   VVSAYi.append(("Add Selected %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVSAYi.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCGsij.VVbz6c():
    VVSAYi.append(VVudpG)
    VVSAYi.append(("Download Manager"      , "dload_stat" ))
  FF3fIR(self, boundFunction(self.VVJT5R_VVLWMc, VVwuhl, mode, typ, seriesName, colList), title="Download Options", VVSAYi=VVSAYi)
 def VVJT5R_VVLWMc(self, VVwuhl, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VV0DAx(VVwuhl, mode)
   elif item == "dnldSel"  : self.VVdEJE(VVwuhl, mode, typ, colList, True)
   elif item == "addSel"  : self.VVdEJE(VVwuhl, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VV4dWP(VVwuhl, mode, typ, seriesName)
   elif item == "dload_stat" : CCGsij.VVcFjY(self)
 def VVdEJE(self, VVwuhl, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVb6Fk(mode, typ, colList)
  if startDnld:
   CCGsij.VVKBbB_url(self, decodedUrl)
  else:
   self.VVLWMc_FFhdnr(VVwuhl, "Add to Download list", chName, [decodedUrl], startDnld)
 def VV4dWP(self, VVwuhl, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVwuhl.VV37Hy():
   chName, decodedUrl = self.VVb6Fk(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVLWMc_FFhdnr(VVwuhl, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVLWMc_FFhdnr(self, VVwuhl, title, chName, decodedUrl_list, startDnld):
  FFhdnr(self, boundFunction(self.VVdKO0, VVwuhl, decodedUrl_list, startDnld), chName, title=title)
 def VVdKO0(self, VVwuhl, decodedUrl_list, startDnld):
  added, skipped = CCGsij.VV6FLCList(decodedUrl_list)
  FFlFRp(VVwuhl, "Added", 1000)
 def VVb6Fk(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVDTAE(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVBFL6(mode, colList)
   refCode, chUrl = self.VVbKkR(self.VVb1Ge, self.VVvwzd, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FF7eR2(chUrl)
  return chName, decodedUrl
 def VV0DAx(self, VVwuhl, mode):
  if os.system(FFMugq("which ffmpeg")) == 0:
   self.session.open(CCHSPO, barTheme=CCHSPO.VVE3Y6
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VV1Z7D, VVwuhl, mode)
       , VVCoUZ = self.VVZv46)
  else:
   FFhdnr(self, boundFunction(CCkpQY.VV7B4d, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVZv46(self, VV73UU, VVGy5N, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVGy5N["proces"], VVGy5N["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVGy5N["ok"], VVGy5N["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVGy5N["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVGy5N["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVGy5N["badURL"]
  txt += "Download Failure\t: %d\n"   % VVGy5N["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVGy5N["path"]
  if not VV73UU  : color = "#11402000"
  elif VVGy5N["err"]: color = "#11201000"
  else     : color = None
  if VVGy5N["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVGy5N["err"], txt)
  title = "PIcons Download Result"
  if not VV73UU:
   title += "  (cancelled)"
  FFGdNj(self, txt, title=title, VVehrL=color)
 def VV1Z7D(self, VVwuhl, mode, progBarObj):
  totRows = VVwuhl.VVI71A()
  progBarObj.VVKFmP(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CCOmM2.VVQ8DK()
  progBarObj.VVGy5N = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for rowNum, row in enumerate(VVwuhl.VV37Hy()):
    if progBarObj.isCancelled:
     break
    progBarObj.VVGy5N["proces"] += 1
    progBarObj.VVWBRz(1)
    if mode in ("itv", "vod", "series"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVBFL6(mode, row)
     refCode = CCkpQY.VVOUlP(catID, stID, chNum)
    elif mode == "m3u/m3u8":
     chName = row[1].strip()
     url  = row[3].strip()
     picUrl = row[4].strip()
     refCode = self.VVaqae(rowNum, url, chName)
    else:
     chName, chUrl, picUrl, refCode = self.VVDTAE(mode, row)
    if picUrl:
     picon = refCode.replace(":", "_").rstrip("_") + ".png"
     if not fileExists(pPath + picon):
      progBarObj.VVGy5N["attempt"] += 1
      path, err = FFzKLB(picUrl, picon, timeout=1, mustBeImage=True)
      if path:
       progBarObj.VVGy5N["ok"] += 1
       if FFpeIy(path) > 0:
        cmd = ""
        if not mode == CCkpQY.VV2qmD:
         cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
        cmd += FFMugq("mv -f '%s' '%s'" % (path, pPath)) + ";"
        os.system(cmd)
       else:
        progBarObj.VVGy5N["size0"] += 1
        os.system(FFMugq("rm -f '%s'" % path))
      elif err:
       progBarObj.VVGy5N["fail"] += 1
       if any(x in err.lower() for x in ("time-out", "unauthorized")):
        progBarObj.VVGy5N["err"] = err.title()
        break
     else:
      progBarObj.VVGy5N["exist"] += 1
    else:
     progBarObj.VVGy5N["badURL"] += 1
  except:
   pass
 @staticmethod
 def VV7B4d(SELF):
  cmd = FFyov6(VVaBvq, "ffmpeg")
  if cmd : FFl3Il(SELF, cmd, title="Installing FFmpeg")
  else : FFXixL(SELF)
 def VVt0AQ(self):
  self.session.open(CCHSPO, barTheme=CCHSPO.VVE3Y6
      , titlePrefix = ""
      , fncToRun  = self.VVVw55
      , VVCoUZ = self.VVALzO)
 def VVVw55(self, progBarObj):
  bName = FFueaG()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  progBarObj.VVGy5N = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = FFByrM()
  if not progBarObj or progBarObj.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   progBarObj.VVKFmP(totCh)
   for serv in services:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVWBRz(1)
    progBarObj.VVAESW_fromImportEPG(totEpgOK, uChName)
    fullRef  = serv[0]
    if FFpq6y(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FF7eR2(fullRef)
     span = iSearch(r"(mode=.+end=)", fullRef, IGNORECASE)
     if span:
      m3u_Url = CCjeUi.VVPkhR(fullRef)
      uType, uHost, uUser, uPass, uId, uChName  = CCkpQY.VV6xjj(fullRef)
      uType, uHost, uUser, uPass, uId, uChName1 = CCkpQY.VV6xjj(m3u_Url)
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCkpQY.VV6xjj(m3u_Url)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCkpQY.VVHYvV(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCA5BL.VVJqa9(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
      else:
       pass
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if progBarObj:
     progBarObj.VVGy5N = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   progBarObj.VVGy5N = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VVALzO(self, VV73UU, VVGy5N, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVGy5N
  title = "IPTV EPG Import"
  if err:
   FFv5WO(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFxKI9(str(totNotIptv), VV8tYH)
    if totServErr : txt += "Server Errors\t: %s\n" % FFxKI9(str(totServErr) + t1, VV8tYH)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFxKI9(str(totInv), VV8tYH)
   if not VV73UU:
    title += "  (stopped)"
   FFGdNj(self, txt, title=title)
 @staticmethod
 def VVHYvV(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCkpQY.VVkPMJ(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCkpQY.VVXTOQ(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCkpQY.VVHt2d(item, "description" , is_base64=True ).replace("\n", " .. ")
    has_archive   = CCkpQY.VVHt2d(item, "has_archive"      )
    lang    = CCkpQY.VVHt2d(item, "lang"        ).upper()
    now_playing   = CCkpQY.VVHt2d(item, "now_playing"      )
    start    = CCkpQY.VVHt2d(item, "start"        )
    start_timestamp  = CCkpQY.VVHt2d(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCkpQY.VVHt2d(item, "start_timestamp"     )
    stop_timestamp  = CCkpQY.VVHt2d(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCkpQY.VVHt2d(item, "stop_timestamp"      )
    tTitle    = CCkpQY.VVHt2d(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVOUlP(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCkpQY.VVNo5L(catID, MAX_4b)
  TSID = CCkpQY.VVNo5L(chNum, MAX_4b)
  ONID = CCkpQY.VVNo5L(chNum, MAX_4b)
  NS  = CCkpQY.VVNo5L(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVNo5L(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VViR57_forBouquet(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVNW5M(mode):
  if   mode in ("itv"  , CCkpQY.VVR1iH)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCkpQY.VVInrt)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCkpQY.VVvO8v) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCkpQY.VVQibI) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCkpQY.VVYTkQ    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 @staticmethod
 def VVrMGU(orExportPath=False):
  path = CFG.iptvHostsPath.getValue()
  if not pathExists(path) or path == VVDWGF:
   if orExportPath : path = CFG.exportedTablesPath.getValue()
   else   : path ="/"
  return FFhBEj(path)
 @staticmethod
 def VVj9ui(SELF, hostUrl, chName, streamId, ok_fnc):
  title = "Catchup TV Programs"
  pList, err = CCkpQY.VVHYvV(hostUrl, streamId, True)
  if err:
   FFv5WO(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVM7V1, VVUL9C, VVehrL, VVTG9d = CCkpQY.VVNW5M("")
   VVSxFV = ("Home Menu" , FF19xV, [])
   VVd2cp  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVDKYV  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFEtMz(SELF, None, title="Programs for : " + chName, header=header, VV06zW=pList, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=24, VVd2cp=VVd2cp, VVSxFV=VVSxFV, VVM7V1=VVM7V1, VVUL9C=VVUL9C, VVehrL=VVehrL, VVTG9d=VVTG9d)
  else:
   FFv5WO(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVgqkU(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 @staticmethod
 def VVJpek(SELF, isPortal, line, VVMsOjObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCkpQY.VVrMGU(orExportPath=True)
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with open(path, "r") as f:
     for fLine in f:
      if line in fLine:
       FFv5WO(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFLnSq(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFv5WO(SELF, "Error:\n\n%s" % str(e), title=title)
class CCKU6X(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFrBKf(VV1H0A, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVMiwH  = 0
  self.VVBSZi = 1
  self.VVNTpx  = 2
  VVSAYi = []
  VVSAYi.append(("Find in All Service (from filter)" , "VVV7Xa" ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Find in All (Manual Entry)"   , "VVeDe8"    ))
  VVSAYi.append(("Find in TV"       , "VVa4Sa"    ))
  VVSAYi.append(("Find in Radio"      , "VVtFLL"   ))
  if self.VVYo8W():
   VVSAYi.append(VVudpG)
   VVSAYi.append(("Hide Channel: %s" % self.servName , "VVEfJM"   ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Zap History"       , "VVnDls"    ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("IPTV Tools"       , "iptv"      ))
  VVSAYi.append(("PIcons Tools"       , "PIconsTools"     ))
  VVSAYi.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FF4zOZ(self, VVSAYi=VVSAYi, title=title)
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FF5gi1(self["myMenu"])
  FFfRto(self)
  if self.isFindMode:
   self.VVU8Yq(self.VVE1Kh())
 def VVjzC3(self):
  global VVWjbN
  VVWjbN = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVeDe8"    : self.VVeDe8()
   elif item == "VVV7Xa" : self.VVV7Xa()
   elif item == "VVa4Sa"    : self.VVa4Sa()
   elif item == "VVtFLL"   : self.VVtFLL()
   elif item == "VVEfJM"   : self.VVEfJM()
   elif item == "VVnDls"    : self.VVnDls()
   elif item == "iptv"       : self.session.open(CCkpQY)
   elif item == "PIconsTools"     : self.session.open(CCOmM2)
   elif item == "ChannelsTools"    : self.session.open(CCHa4g)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVa4Sa(self) : self.VVU8Yq(self.VVMiwH)
 def VVtFLL(self) : self.VVU8Yq(self.VVBSZi)
 def VVeDe8(self) : self.VVU8Yq(self.VVNTpx)
 def VVU8Yq(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFMKq2(self, boundFunction(self.VVdghd, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVV7Xa(self):
  filterObj = CCWTeq(self)
  filterObj.VV1ymy(self.VVd28Y)
 def VVd28Y(self, item):
  self.VVdghd(self.VVNTpx, item)
 def VVYo8W(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFpq6y(self.refCode)        : return False
  return True
 def VVdghd(self, mode, VVuaaG):
  FF8MfV(self, boundFunction(self.VVATZn, mode, VVuaaG), title="Searching ...")
 def VVATZn(self, mode, VVuaaG):
  if VVuaaG:
   self.findTxt = VVuaaG
   if   mode == self.VVMiwH  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVBSZi : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVuaaG)
   if len(title) > 55:
    title = title[:55] + ".."
   VVprUT = self.VVTmCn(VVuaaG, servTypes)
   if self.isFindMode or mode == self.VVNTpx:
    VVprUT += self.VVPKcY(VVuaaG)
   if VVprUT:
    VVprUT.sort(key=lambda x: x[0].lower())
    VVAIMO = self.VVXiH4
    VVd2cp  = ("Zap"   , self.VVucBO    , [])
    VVJD06 = ("Current Service", self.VVflwL , [])
    VV8khl = ("Options"  , self.VVucO7 , [])
    VVvxfu = (""    , self.VVjQpq , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVDKYV  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFEtMz(self, None, title=title, header=header, VV06zW=VVprUT, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=26, VVd2cp=VVd2cp, VVAIMO=VVAIMO, VVJD06=VVJD06, VV8khl=VV8khl, VVvxfu=VVvxfu)
   else:
    self.VVU8Yq(self.VVE1Kh())
    FFLnSq(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVTmCn(self, VVuaaG, servTypes):
  VVBcIx  = eServiceCenter.getInstance()
  VVmkil   = '%s ORDER BY name' % servTypes
  VVyMI9   = eServiceReference(VVmkil)
  VVBM0o = VVBcIx.list(VVyMI9)
  if VVBM0o: VV06zW = VVBM0o.getContent("CN", False)
  else     : VV06zW = None
  VVprUT = []
  if VV06zW:
   VVrl4a, VVPj0m = FFtCwD()
   tp   = CCJR3E()
   words, asPrefix = CCWTeq.VV6DTY(VVuaaG)
   colorYellow  = CCDNTG.VVRl4D(VVSfxg)
   colorWhite  = CCDNTG.VVRl4D(VVTIP5)
   for s in VV06zW:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFITp0(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVrl4a:
        STYPE = VVPj0m[sTypeInt]
       freq, pol, fec, sr, syst = tp.VV1fjX(refCode)
       if not "-S" in syst:
        sat = syst
       VVprUT.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVprUT
 def VVPKcY(self, VVuaaG):
  VVuaaG = VVuaaG.lower()
  VVRfxd = FFQRnQ()
  VVprUT = []
  colorYellow  = CCDNTG.VVRl4D(VVSfxg)
  colorWhite  = CCDNTG.VVRl4D(VVTIP5)
  if VVRfxd:
   for b in VVRfxd:
    VVqOZ0  = b[0]
    VV1FRD  = b[1].toString()
    VV58PA = eServiceReference(VV1FRD)
    VVMoqN = FF04X5(VV58PA)
    for service in VVMoqN:
     refCode  = service[0]
     if FFpq6y(refCode):
      servName = service[1]
      if VVuaaG in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VVuaaG), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VVprUT.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVprUT
 def VVE1Kh(self):
  VV26oo = InfoBar.instance
  if VV26oo:
   VVhsPd = VV26oo.servicelist
   if VVhsPd:
    return VVhsPd.mode == 1
  return self.VVNTpx
 def VVXiH4(self, VVwuhl):
  self.close()
  VVwuhl.cancel()
 def VVucBO(self, VVwuhl, title, txt, colList):
  FFY7Np(VVwuhl, colList[2], VV4NU5=False, checkParentalControl=True)
 def VVflwL(self, VVwuhl, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(VVwuhl)
  if refCode:
   VVwuhl.VV5o1g(2, FFGsMp(refCode, iptvRef, chName), True)
 def VVucO7(self, VVwuhl, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CC34Ma(self, VVwuhl, 2)
  mSel.VVDKO1(servName, refCode)
 def VVjQpq(self, VVwuhl, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFlYRO(self, fncMode=CCA5BL.VVKunJ, refCode=refCode, chName=chName, text=txt)
 def VVEfJM(self):
  FFhdnr(self, self.VVwIvE, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVwIvE(self):
  ret = FFrRU9(self.refCode, True)
  if ret:
   self.VVE8kw()
   self.close()
  else:
   FFlFRp(self, "Cannot change state" , 1000)
 def VVE8kw(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VV2GUB()
  except:
   self.VV38xT()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FF6JIs(self, serviceRef)
 def VVoauC(self):
  VV26oo = InfoBar.instance
  if VV26oo:
   VVhsPd = VV26oo.servicelist
   if VVhsPd:
    VVhsPd.setMode()
 def VV2GUB(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VV26oo = InfoBar.instance
   if VV26oo:
    VVhsPd = VV26oo.servicelist
    if VVhsPd:
     hList = VVhsPd.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVhsPd.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVhsPd.history  = newList
       VVhsPd.history_pos = pos
 def VV38xT(self):
  VV26oo = InfoBar.instance
  if VV26oo:
   VVhsPd = VV26oo.servicelist
   if VVhsPd:
    VVhsPd.history  = []
    VVhsPd.history_pos = 0
 def VVnDls(self):
  VV26oo = InfoBar.instance
  VVprUT = []
  if VV26oo:
   VVhsPd = VV26oo.servicelist
   if VVhsPd:
    VVrl4a, VVPj0m = FFtCwD()
    for chParams in VVhsPd.history:
     refCode = chParams[-1].toString()
     chName = FFQogO(refCode)
     isIptv = FFpq6y(refCode)
     if isIptv: sat = "-"
     else  : sat = FFITp0(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVrl4a:
       STYPE = VVPj0m[sTypeInt]
     VVprUT.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVprUT:
   VVd2cp  = ("Zap"   , self.VVvHAn   , [])
   VV8khl = ("Clear History" , self.VVmAek   , [])
   VVvxfu = (""    , self.VVPEttFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVDKYV  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFEtMz(self, None, title=title, header=header, VV06zW=VVprUT, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=28, VVd2cp=VVd2cp, VV8khl=VV8khl, VVvxfu=VVvxfu)
  else:
   FFLnSq(self, "Not found", title=title)
 def VVvHAn(self, VVwuhl, title, txt, colList):
  FFY7Np(VVwuhl, colList[3], VV4NU5=False, checkParentalControl=True)
 def VVmAek(self, VVwuhl, title, txt, colList):
  FFhdnr(self, boundFunction(self.VVaev8, VVwuhl), "Clear Zap History ?")
 def VVaev8(self, VVwuhl):
  self.VV38xT()
  VVwuhl.cancel()
 def VVPEttFromZapHistory(self, VVwuhl, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFlYRO(self, fncMode=CCA5BL.VVyNgJ, refCode=refCode, chName=chName, text=txt)
class CCOmM2(Screen):
 VVqOpV   = 0
 VV8Po9  = 1
 VVl00i  = 2
 VVfc9T  = 3
 VVJBDb  = 4
 VVX1vy  = 5
 VVFXc6  = 6
 VVyAxm  = 7
 VV4ILx = 8
 VV6KjS = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFrBKf(VVIc3l, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FF4zOZ(self, self.Title)
  FF313P(self["keyRed"] , "OK = Zap")
  FF313P(self["keyGreen"] , "Current Service")
  FF313P(self["keyYellow"], "Page Options")
  FF313P(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCOmM2.VVQ8DK()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VV06zW    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVLcTY        ,
   "green"   : self.VVu2sF       ,
   "yellow"  : self.VVM0gD        ,
   "blue"   : self.VVuw5c        ,
   "menu"   : self.VVHusD        ,
   "info"   : self.VVPEtt         ,
   "up"   : self.VVt0sY          ,
   "down"   : self.VVEn52         ,
   "left"   : self.VViad8         ,
   "right"   : self.VVepxi         ,
   "pageUp"  : boundFunction(self.VVJtee, True) ,
   "chanUp"  : boundFunction(self.VVJtee, True) ,
   "pageDown"  : boundFunction(self.VVJtee, False) ,
   "chanDown"  : boundFunction(self.VVJtee, False) ,
   "next"   : self.VVpoqP        ,
   "last"   : self.VVKpoJ         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FFoZqi(self)
  FFZe3q(self)
  FFv4ZZ(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FF8MfV(self, boundFunction(self.VVB4Fh, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVHusD(self):
  if not self.isBusy:
   VVSAYi = []
   VVSAYi.append(("Statistics"           , "VV3SXw"    ))
   VVSAYi.append(VVudpG)
   VVSAYi.append(("Suggest PIcons for Current Channel"     , "VVnBUR"   ))
   VVSAYi.append(("Set to Current Channel (copy file)"     , "VVqnE7_file"  ))
   VVSAYi.append(("Set to Current Channel (as SymLink)"     , "VVqnE7_link"  ))
   VVSAYi.append(VVudpG)
   VVSAYi.append(CCOmM2.VVuFsO())
   VVSAYi.append(VVudpG)
   if self.filterTitle == "PIcons without Channels":
    c = VV8tYH
    VVSAYi.append((FFxKI9("Move Unused PIcons to a Directory", c) , "VV6Q1l"  ))
    VVSAYi.append((FFxKI9("DELETE Unused PIcons", c)    , "VVk2Ow" ))
    VVSAYi.append(VVudpG)
   VVSAYi.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVRCoU"  ))
   VVSAYi.append(VVudpG)
   VVSAYi += CCOmM2.VV2tPb()
   VVSAYi.append(VVudpG)
   VVSAYi.append(("RCU Keys Help"          , "VVUNcl"    ))
   FF3fIR(self, self.VVJT5R, title=self.Title, VVSAYi=VVSAYi)
 def VVJT5R(self, item=None):
  if item is not None:
   if   item == "VV3SXw"     : self.VV3SXw()
   elif item == "VVnBUR"    : self.VVnBUR()
   elif item == "VVqnE7_file"   : self.VVqnE7(0)
   elif item == "VVqnE7_link"   : self.VVqnE7(1)
   elif item == "VVzuDb_file"  : self.VVzuDb(0)
   elif item == "VVzuDb_link"  : self.VVzuDb(1)
   elif item == "VVF0Tn"   : self.VVF0Tn()
   elif item == "VVjc46"  : self.VVjc46()
   elif item == "VV6Q1l"    : self.VV6Q1l()
   elif item == "VVk2Ow"   : self.VVk2Ow()
   elif item == "VVRCoU"   : self.VVRCoU()
   elif item == "VVixzJ"   : CCOmM2.VVixzJ(self)
   elif item == "VVUlRF"   : CCOmM2.VVUlRF(self)
   elif item == "findPiconBrokenSymLinks"  : CCOmM2.VV5p7f(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCOmM2.VV5p7f(self, False)
   elif item == "VVUNcl"      : self.VVUNcl()
 def VVM0gD(self):
  if not self.isBusy:
   VVSAYi = []
   VVSAYi.append(("Go to First PIcon"  , "VVKze9"  ))
   VVSAYi.append(("Go to Last PIcon"   , "VVKEad"  ))
   VVSAYi.append(VVudpG)
   VVSAYi.append(("Sort by Channel Name"     , "sortByChan" ))
   VVSAYi.append(("Sort by File Name"  , "sortByFile" ))
   VVSAYi.append(VVudpG)
   VVSAYi.append(("Find from File List .." , "VVCZlA" ))
   FF3fIR(self, self.VVDCLA, title=self.Title, VVSAYi=VVSAYi)
 def VVDCLA(self, item=None):
  if item is not None:
   if   item == "VVKze9"   : self.VVKze9()
   elif item == "VVKEad"   : self.VVKEad()
   elif item == "sortByChan"  : self.VVJcDw(2)
   elif item == "sortByFile"  : self.VVJcDw(0)
   elif item == "VVCZlA"  : self.VVCZlA()
 def VVUNcl(self):
  FF2UCb(self, VVrF44 + "_help_picons", "PIcons Manager (Keys Help)")
 def VVt0sY(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVKEad()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVKXnv()
 def VVEn52(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVKze9()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVKXnv()
 def VViad8(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVKEad()
  else:
   self.curCol -= 1
   self.VVKXnv()
 def VVepxi(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVKze9()
  else:
   self.curCol += 1
   self.VVKXnv()
 def VVKpoJ(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVKXnv(True)
 def VVpoqP(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVKXnv(True)
 def VVKze9(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVKXnv(True)
 def VVKEad(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVKXnv(True)
 def VVCZlA(self):
  VVSAYi = []
  for item in self.VV06zW:
   VVSAYi.append((item[0], item[0]))
  FF3fIR(self, self.VVdz4b, title='PIcons ".png" Files', VVSAYi=VVSAYi, VVdU6y=True)
 def VVdz4b(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVrRez(ndx)
 def VVLcTY(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VV5gvB()
   if refCode:
    FFY7Np(self, refCode)
    self.VVmOqE()
    self.VVv8sA()
 def VVJtee(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVmOqE()
   self.VVv8sA()
  except:
   pass
 def VVu2sF(self):
  if self["keyGreen"].getVisible():
   self.VVrRez(self.curChanIndex)
 def VVrRez(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVKXnv(True)
  else:
   FFlFRp(self, "Not found", 1000)
 def VVJcDw(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FF8MfV(self, boundFunction(self.VVB4Fh, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVqnE7(self, mode):
  title = "Change Current Channel PIcon"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VV5gvB()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVSAYi = []
     VVSAYi.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVSAYi.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FF3fIR(self, boundFunction(self.VVo9pI, mode, curChF, selPiconF), VVSAYi=VVSAYi, title="Current Channel PIcon (already exists)")
    else:
     self.VVo9pI(mode, curChF, selPiconF, "overwrite")
   else:
    FFv5WO(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFv5WO(self, "Could not read current channel info. !", title=title)
 def VVo9pI(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FF8MfV(self, boundFunction(self.VVB4Fh, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVzuDb(self, mode):
  pass
 def VVF0Tn(self):
  pass
 def VVjc46(self):
  pass
 def VV6Q1l(self):
  defDir = FFhBEj(CCOmM2.VVQ8DK() + "picons_backup")
  os.system(FFMugq("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(boundFunction(self.VV942h, defDir), boundFunction(CCQ7If
         , mode=CCQ7If.VVevyr, VVBz5n=CCOmM2.VVQ8DK()))
 def VV942h(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCOmM2.VVQ8DK():
    FFv5WO(self, "Cannot move to same directory !", title=title)
   else:
    if not FFhBEj(path) == FFhBEj(defDir):
     self.VV23Rj(defDir)
    FFhdnr(self, boundFunction(FF8MfV, self, boundFunction(self.VVdWvc, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VV06zW), path), title=title)
  else:
   self.VV23Rj(defDir)
 def VVdWvc(self, title, defDir, toPath):
  try:
   from shutil import move as iMove
  except:
   self.VV23Rj(defDir)
   FFv5WO(self, 'Could not load "shutil" module !', title=title)
   return
  toPath = FFhBEj(toPath)
  pPath = CCOmM2.VVQ8DK()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VV06zW:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VV06zW)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFGdNj(self, txt, title=title, VVehrL="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVUOp3("all")
 def VV23Rj(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVk2Ow(self):
  title = "Delete Unused PIcons"
  tot = len(self.VV06zW)
  s = "s" if tot > 1 else ""
  FFhdnr(self, boundFunction(FF8MfV, self, boundFunction(self.VV99T9, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, s), title=title)
 def VV99T9(self, title):
  pPath = CCOmM2.VVQ8DK()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VV06zW:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VV06zW)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFxKI9(str(totErr), VV8tYH)
  FFGdNj(self, txt, title=title)
 def VVRCoU(self):
  lines = FFs4zJ("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFhdnr(self, boundFunction(self.VVOwvc, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVD4Yr=True)
  else:
   FFLnSq(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVOwvc(self, fList):
  os.system(FFMugq("find -L '%s' -type l -delete" % self.pPath))
  FFLnSq(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVPEtt(self):
  FF8MfV(self, self.VValLm)
 def VValLm(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VV5gvB()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFxKI9("PIcon Directory:\n", VV9YfT)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFpDBp(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFpDBp(path)
   txt += FFxKI9("PIcon File:\n", VV9YfT)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFs4zJ(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFxKI9("Found %d SymLink%s to this file from:\n" % (tot, s), VV9YfT)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFQogO(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFxKI9(tChName, VV3SOs)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFxKI9(line, VVIgRq), tChName)
    txt += "\n"
   if chName:
    txt += FFxKI9("Channel:\n", VV9YfT)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFxKI9(chName, VV3SOs)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFxKI9("Remarks:\n", VV9YfT)
    txt += "  %s\n" % FFxKI9("Unused", VV8tYH)
  else:
   txt = "No info found"
  FFlYRO(self, fncMode=CCA5BL.VVaUTH, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VV5gvB(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VV06zW[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FF6tzg(sat)
  return fName, refCode, chName, sat, inDB
 def VVmOqE(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VV06zW):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVv8sA(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VV5gvB()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFxKI9("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VV9YfT))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VV5gvB()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFxKI9(self.curChanName, VVSfxg)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VV3SXw(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VV06zW:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFw9Nl("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFGdNj(self, txt, title=self.Title)
 def VVuw5c(self):
  if not self.isBusy:
   VVSAYi = []
   VVSAYi.append(("All"         , "all"   ))
   VVSAYi.append(VVudpG)
   VVSAYi.append(("Used by Channels"      , "used"  ))
   VVSAYi.append(("Unused PIcons"      , "unused"  ))
   VVSAYi.append(VVudpG)
   VVSAYi.append(("PIcons Files"       , "pFiles"  ))
   VVSAYi.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVSAYi.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVSAYi.append(VVudpG)
   VVSAYi.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVSAYi.append(VVudpG)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFNUup(val)
      VVSAYi.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCWTeq(self)
   filterObj.VVSTwS(VVSAYi, self.nsList, self.VVhc4a)
 def VVhc4a(self, item=None):
  if item is not None:
   self.VVUOp3(item)
 def VVUOp3(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVqOpV   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VV8Po9   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVl00i  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVfc9T  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVJBDb  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVX1vy  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVFXc6   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVyAxm   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VV4ILx , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVX1vy:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFs4zJ("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFlFRp(self, "Not found", 1000)
     return
   elif mode == self.VV6KjS:
    return
   else:
    words, asPrefix = CCWTeq.VV6DTY(words)
   if not words and mode in (self.VVyAxm, self.VV4ILx):
    FFlFRp(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FF8MfV(self, boundFunction(self.VVB4Fh, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVnBUR(self):
  self.session.open(CCHSPO, barTheme=CCHSPO.VVSU2X
      , titlePrefix = ""
      , fncToRun  = self.VVyBxN
      , VVCoUZ = self.VV8m3Y)
 def VVyBxN(self, progBarObj):
  lameDbChans = CCHa4g.VVzJJ1(self, CCHa4g.VV7MRV, VV2EYo=False, VVGuAm=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVGy5N = []
  progBarObj.VVKFmP(len(lameDbChans))
  if lameDbChans:
   processChanName = CCBlS0()
   curCh = processChanName.VVBjce(self.curChanName)
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVWBRz(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCOmM2.VVPrOe(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCOmM2.VVjufE(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VVGy5N.append(f.replace(".png", ""))
 def VV8m3Y(self, VV73UU, VVGy5N, threadCounter, threadTotal, threadErr):
  if VVGy5N:
   self.timer = eTimer()
   fnc = boundFunction(FF8MfV, self, boundFunction(self.VVB4Fh, mode=self.VV6KjS, words=VVGy5N), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FFlFRp(self, "Not found", 2000)
 def VVB4Fh(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVphL3(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCHa4g.VVzJJ1(self, CCHa4g.VV7MRV, VV2EYo=False, VVGuAm=False)
  iptvRefList = self.VVpjly()
  tList = []
  for fName, fType in CCOmM2.VVT956(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVqOpV:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VV8Po9  and chName         : isAdd = True
   elif mode == self.VVl00i and not chName        : isAdd = True
   elif mode == self.VVfc9T  and fType == 0        : isAdd = True
   elif mode == self.VVJBDb  and fType == 1        : isAdd = True
   elif mode == self.VVX1vy  and fName in words       : isAdd = True
   elif mode == self.VV6KjS and fName in words       : isAdd = True
   elif mode == self.VVFXc6  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVyAxm  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VV4ILx:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VV06zW   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFlFRp(self)
  else:
   self.isBusy = False
   FFlFRp(self, "Not found", 1000)
   return
  self.VV06zW.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVmOqE()
  self.totalPIcons = len(self.VV06zW)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVKXnv(True)
 def VVphL3(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCOmM2.VVT956(self.pPath):
    if fName:
     return True
   if isFirstTime : FFv5WO(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFlFRp(self, "Not found", 1000)
  else:
   FFv5WO(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVpjly(self):
  VVprUT = {}
  files  = CCkpQY.VVkcul(self)
  if files:
   for path in files:
    txt = FFqhNI(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVprUT[refCode] = item[1]
  return VVprUT
 def VVKXnv(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VV9Wik = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VV9Wik: self.curPage = VV9Wik
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVSasa()
  if self.curPage == VV9Wik:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVv8sA()
  filName, refCode, chName, sat, inDB = self.VV5gvB()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVSasa(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VV06zW[ndx]
   fName = self.VV06zW[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFxKI9(chName, VV3SOs))
    else : lbl.setText("-")
   except:
    lbl.setText(FFxKI9(chName, VVZ7zN))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVPrOe(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVuFsO():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVixzJ"   )
 @staticmethod
 def VV2tPb():
  VVSAYi = []
  VVSAYi.append(("Find SymLinks (to PIcon Directory)"   , "VVUlRF"   ))
  VVSAYi.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVSAYi.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVSAYi
 @staticmethod
 def VVixzJ(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(SELF)
  png, path = CCOmM2.VVoEAv(refCode)
  if path : CCOmM2.VVZf6h(SELF, png, path)
  else : FFv5WO(SELF, "No PIcon found for current channel in:\n\n%s" % CCOmM2.VVQ8DK())
 @staticmethod
 def VVUlRF(SELF):
  if VVSfxg:
   sed1 = FFA6Lm("->", VVSfxg)
   sed2 = FFA6Lm("picon", VV8tYH)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVZ7zN, VVTIP5)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFRgi8(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFfLcR(), grep, sed1, sed2, sed3))
 @staticmethod
 def VV5p7f(SELF, isPIcon):
  sed1 = FFA6Lm("->", VVZ7zN)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFA6Lm("picon", VV8tYH)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFRgi8(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFfLcR(), grep, sed1, sed2))
 @staticmethod
 def VVT956(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVQ8DK():
  path = CFG.PIconsPath.getValue()
  return FFhBEj(path)
 @staticmethod
 def VVoEAv(refCode, chName=None):
  if FFpq6y(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FF7eR2(refCode)
  allPath, fName, refCodeFile, pList = CCOmM2.VVjufE(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVZf6h(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFA6Lm("%s%s" % (dest, png), VV3SOs))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFA6Lm(errTxt, VVxd7c))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFkZIr(SELF, cmd)
 @staticmethod
 def VVjufE(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCOmM2.VVQ8DK()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFxdkh(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCKv3V():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVknyr  = None
  self.VVSNpR = ""
  self.VVd2bJ  = noService
  self.VVbquF = 0
  self.VVEGLw  = noService
  self.VViiNr = 0
  self.VV5MEZ  = "-"
  self.VVcjz8 = 0
  self.VVyKDs  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVrIfL(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVknyr = frontEndStatus
     self.VVJUyr()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVJUyr(self):
  if self.VVknyr:
   val = self.VVknyr.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVSNpR = "%3.02f dB" % (val / 100.0)
   else         : self.VVSNpR = ""
   val = self.VVknyr.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVbquF = int(val)
   self.VVd2bJ  = "%d%%" % val
   val = self.VVknyr.get("tuner_signal_power" , 0) * 100 / 65536
   self.VViiNr = int(val)
   self.VVEGLw  = "%d%%" % val
   val = self.VVknyr.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VV5MEZ  = "%d" % val
   val = int(val * 100 / 500)
   self.VVcjz8 = min(500, val)
   val = self.VVknyr.get("tuner_locked", 0)
   if val == 1 : self.VVyKDs = "Locked"
   else  : self.VVyKDs = "Not locked"
 def VVabzR(self)   : return self.VVSNpR
 def VVAgFZ(self)   : return self.VVd2bJ
 def VVh2gf(self)  : return self.VVbquF
 def VVkpAa(self)   : return self.VVEGLw
 def VVKMOf(self)  : return self.VViiNr
 def VVXpfm(self)   : return self.VV5MEZ
 def VVNy7n(self)  : return self.VVcjz8
 def VVegvf(self)   : return self.VVyKDs
 def VVIx0t(self) : return self.serviceName
class CCJR3E():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVvlUU(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFBg35(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVzStZ(self.ORPOS  , mod=1   )
      self.sat2  = self.VVzStZ(self.ORPOS  , mod=2   )
      self.freq  = self.VVzStZ(self.FREQ  , mod=3   )
      self.sr   = self.VVzStZ(self.SR   , mod=4   )
      self.inv  = self.VVzStZ(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVzStZ(self.POL  , self.D_POL )
      self.fec  = self.VVzStZ(self.FEC  , self.D_FEC )
      self.syst  = self.VVzStZ(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVzStZ("modulation" , self.D_MOD )
       self.rolof = self.VVzStZ("rolloff"  , self.D_ROLOF )
       self.pil = self.VVzStZ("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVzStZ("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVzStZ("pls_code"  )
       self.iStId = self.VVzStZ("is_id"   )
       self.t2PlId = self.VVzStZ("t2mi_plp_id" )
       self.t2PId = self.VVzStZ("t2mi_pid"  )
 def VVzStZ(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFNUup(val)
  elif mod == 2   : return FFknK4(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVKdcB(self, refCode):
  txt = ""
  self.VVvlUU(refCode)
  if self.data:
   def VVCE8s(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVCE8s("System"   , self.syst)
    txt += VVCE8s("Satellite"  , self.sat2)
    txt += VVCE8s("Frequency"  , self.freq)
    txt += VVCE8s("Inversion"  , self.inv)
    txt += VVCE8s("Symbol Rate"  , self.sr)
    txt += VVCE8s("Polarization" , self.pol)
    txt += VVCE8s("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVCE8s("Modulation" , self.mod)
     txt += VVCE8s("Roll-Off" , self.rolof)
     txt += VVCE8s("Pilot"  , self.pil)
     txt += VVCE8s("Input Stream", self.iStId)
     txt += VVCE8s("T2MI PLP ID" , self.t2PlId)
     txt += VVCE8s("T2MI PID" , self.t2PId)
     txt += VVCE8s("PLS Mode" , self.plsMod)
     txt += VVCE8s("PLS Code" , self.plsCod)
   else:
    txt += VVCE8s("System"   , self.txMedia)
    txt += VVCE8s("Frequency"  , self.freq)
  return txt, self.namespace
 def VVjWAG(self, refCode):
  txt = "Transpoder : ?"
  self.VVvlUU(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VV9YfT + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VV1fjX(self, refCode):
  self.data = None
  servRef = eServiceReference(refCode)
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFBg35(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVzStZ(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVzStZ(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVzStZ(self.SYST, self.D_SYS_S)
     freq = self.VVzStZ(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVzStZ(self.POL , self.D_POL)
      fec = self.VVzStZ(self.FEC , self.D_FEC)
      sr = self.VVzStZ(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVbuYV(self, refCode):
  self.data = None
  self.VVvlUU(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCVYVr():
 def __init__(self, VVwcED, path, VVCoUZ=None, curRowNum=-1):
  self.VVwcED  = VVwcED
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVCoUZ  = VVCoUZ
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFMugq("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVb1ix(curRowNum)
  else:
   FFv5WO(self.VVwcED, "Error while preparing edit!")
 def VVb1ix(self, curRowNum):
  VVprUT = self.VVOkBZ()
  VVSxFV = None #("Delete Line" , self.deleteLine  , [])
  VVJD06 = ("Save Changes" , self.VVgVTB   , [])
  VVd2cp  = ("Edit Line"  , self.VVBReC    , [])
  VVulZM = ("Line Options" , self.VVIZJZ   , [])
  VVomiS = (""    , self.VVZ2ha , [])
  VVAIMO = self.VVAPdf
  VVHOsw  = self.VVkTZd
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVDKYV  = (CENTER  , LEFT  )
  VVwuhl = FFEtMz(self.VVwcED, None, title=self.Title, header=header, VV06zW=VVprUT, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=26, VVSxFV=VVSxFV, VVJD06=VVJD06, VVd2cp=VVd2cp, VVulZM=VVulZM, VVAIMO=VVAIMO, VVHOsw=VVHOsw, VVomiS=VVomiS, VVgpgw=True
    , VVM7V1   = "#11001111"
    , VVUL9C   = "#11001111"
    , VVehrL   = "#11001111"
    , VVTG9d  = "#05333333"
    , VVCgV5  = "#00222222"
    , VVoitp  = "#11331133"
    )
  VVwuhl.VVr9OJ(curRowNum)
 def VVIZJZ(self, VVwuhl, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVwuhl.VV7zcM()
  VVSAYi = []
  VVSAYi.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVSAYi.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVAU8W"  ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VV8X9G:
   VVSAYi.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(  ("Delete Line"         , "deleteLine"   ))
  FF3fIR(self.VVwcED, boundFunction(self.VV6QLh, VVwuhl, lineNum), VVSAYi=VVSAYi, title="Line Options")
 def VV6QLh(self, VVwuhl, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVg3AV("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVwuhl)
   elif item == "VVAU8W"  : self.VVAU8W(VVwuhl, lineNum)
   elif item == "copyToClipboard"  : self.VVrTqf(VVwuhl, lineNum)
   elif item == "pasteFromClipboard" : self.VVZKBh(VVwuhl, lineNum)
   elif item == "deleteLine"   : self.VVg3AV("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVwuhl)
 def VVkTZd(self, VVwuhl):
  VVwuhl.VVFwf0()
 def VVZ2ha(self, VVwuhl, title, txt, colList):
  if   self.insertMode == 1: VVwuhl.VVKBQR()
  elif self.insertMode == 2: VVwuhl.VVjVSo()
  self.insertMode = 0
 def VVAU8W(self, VVwuhl, lineNum):
  if lineNum == VVwuhl.VV7zcM():
   self.insertMode = 1
   self.VVg3AV("echo '' >> '%s'" % self.tmpFile, VVwuhl)
  else:
   self.insertMode = 2
   self.VVg3AV("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVwuhl)
 def VVrTqf(self, VVwuhl, lineNum):
  global VV8X9G
  VV8X9G = FFw9Nl("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVwuhl.VVT6LE("Copied to clipboard")
 def VVgVTB(self, VVwuhl, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFMugq("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFMugq("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVwuhl.VVT6LE("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVwuhl.VVFwf0()
    else:
     FFv5WO(self.VVwcED, "Cannot save file!")
   else:
    FFv5WO(self.VVwcED, "Cannot create backup copy of original file!")
 def VVAPdf(self, VVwuhl):
  if self.fileChanged:
   FFhdnr(self.VVwcED, boundFunction(self.VVZcxo, VVwuhl), "Cancel changes ?")
  else:
   finalOK = os.system(FFMugq("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVZcxo(VVwuhl)
 def VVZcxo(self, VVwuhl):
  VVwuhl.cancel()
  os.system(FFMugq("rm -f '%s'" % self.tmpFile))
  if self.VVCoUZ:
   self.VVCoUZ(self.fileSaved)
 def VVBReC(self, VVwuhl, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVTIP5 + "ORIGINAL TEXT:\n" + VVIgRq + lineTxt
  FFMKq2(self.VVwcED, boundFunction(self.VVyl43, lineNum, VVwuhl), title="File Line", defaultText=lineTxt, message=message)
 def VVyl43(self, lineNum, VVwuhl, VVCC3L):
  if not VVCC3L is None:
   if VVwuhl.VV7zcM() <= 1:
    self.VVg3AV("echo %s > '%s'" % (VVCC3L, self.tmpFile), VVwuhl)
   else:
    self.VVSUmt(VVwuhl, lineNum, VVCC3L)
 def VVZKBh(self, VVwuhl, lineNum):
  if lineNum == VVwuhl.VV7zcM() and VVwuhl.VV7zcM() == 1:
   self.VVg3AV("echo %s >> '%s'" % (VV8X9G, self.tmpFile), VVwuhl)
  else:
   self.VVSUmt(VVwuhl, lineNum, VV8X9G)
 def VVSUmt(self, VVwuhl, lineNum, newTxt):
  VVwuhl.VVs3je("Saving ...")
  lines = FF66GF(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVwuhl.VV58kR()
  VVprUT = self.VVOkBZ()
  VVwuhl.VVJs1i(VVprUT)
 def VVg3AV(self, cmd, VVwuhl):
  tCons = CC4384()
  tCons.ePopen(cmd, boundFunction(self.VVMkLL, VVwuhl))
  self.fileChanged = True
  VVwuhl.VV58kR()
 def VVMkLL(self, VVwuhl, result, retval):
  VVprUT = self.VVOkBZ()
  VVwuhl.VVJs1i(VVprUT)
 def VVOkBZ(self):
  if fileExists(self.tmpFile):
   lines = FF66GF(self.tmpFile)
   VVprUT = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVprUT.append((str(ndx), line.strip()))
   if not VVprUT:
    VVprUT.append((str(1), ""))
   return VVprUT
  else:
   FF7BRF(self.VVwcED, self.tmpFile)
class CCWTeq():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVSAYi   = []
  self.satList   = []
 def VV1ymy(self, VVCoUZ):
  self.VVSAYi = []
  VVSAYi, VViXXt = self.VVfZap(False, True)
  if VVSAYi:
   self.VVSAYi += VVSAYi
   self.VVmr4i(VVCoUZ, VViXXt)
 def VVp2Zw(self, mode, VVwuhl, satCol, VVCoUZ):
  VVwuhl.VVs3je("Loading Filters ...")
  self.VVSAYi = []
  self.VVSAYi.append(("All Services" , "all"))
  if mode == 1:
   self.VVSAYi.append(VVudpG)
   self.VVSAYi.append(("Parental Control", "parentalControl"))
   self.VVSAYi.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVSAYi.append(VVudpG)
   self.VVSAYi.append(("Selected Transponder"   , "selectedTP" ))
   self.VVSAYi.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVilz8(VVwuhl, satCol)
  VVSAYi, VViXXt = self.VVfZap(True, False)
  if VVSAYi:
   VVSAYi.insert(0, VVudpG)
   self.VVSAYi += VVSAYi
  VVwuhl.VVEHtU()
  self.VVmr4i(VVCoUZ, VViXXt)
 def VVSTwS(self, VVSAYi, sats, VVCoUZ):
  self.VVSAYi = VVSAYi
  VVSAYi, VViXXt = self.VVfZap(True, False)
  if VVSAYi:
   self.VVSAYi.append(VVudpG)
   self.VVSAYi += VVSAYi
  self.VVmr4i(VVCoUZ, VViXXt)
 def VVmr4i(self, VVCoUZ, VViXXt):
  VVEbC5 = ("Edit Filter", boundFunction(self.VVQLNP, VViXXt))
  VVJtpI  = ("Filter Help", boundFunction(self.VVkwIg, VViXXt))
  FF3fIR(self.callingSELF, boundFunction(self.VVKCIA, VVCoUZ), VVSAYi=self.VVSAYi, title="Select Filter", VVEbC5=VVEbC5, VVJtpI=VVJtpI)
 def VVKCIA(self, VVCoUZ, item):
  if item:
   VVCoUZ(item)
 def VVQLNP(self, VViXXt, VVMsOjObj, sel):
  if fileExists(VViXXt) : CCVYVr(self.callingSELF, VViXXt, VVCoUZ=None)
  else       : FF7BRF(self.callingSELF, VViXXt)
  VVMsOjObj.cancel()
 def VVkwIg(self, VViXXt, VVMsOjObj, sel):
  FF2UCb(self.callingSELF, VVrF44 + "_help_service_filter", "Service Filter")
 def VVilz8(self, VVwuhl, satColNum):
  if not self.satList:
   satList = VVwuhl.VV0wLx(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FF6tzg(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVudpG)
  if self.VVSAYi:
   self.VVSAYi += self.satList
 def VVfZap(self, addTag, VV6xfF):
  FFZuwO()
  fileName  = "ajpanel_services_filter"
  VViXXt = VVVPVZ + fileName
  VVSAYi  = []
  if not fileExists(VViXXt):
   os.system(FFMugq("cp -f '%s' '%s'" % (VVrF44 + fileName, VViXXt)))
  fileFound = False
  if fileExists(VViXXt):
   fileFound = True
   lines = FF66GF(VViXXt)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVSAYi.append((line, "__w__" + line))
       else  : VVSAYi.append((line, line))
  if VV6xfF:
   if   not fileFound : FF7BRF(self.callingSELF , VViXXt)
   elif not VVSAYi : FFrHkO(self.callingSELF , VViXXt)
  return VVSAYi, VViXXt
 @staticmethod
 def VV6DTY(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CC34Ma():
 def __init__(self, callingSELF, VVwuhl, refCodeColNum):
  self.callingSELF = callingSELF
  self.VVwuhl = VVwuhl
  self.refCodeColNum = refCodeColNum
  self.VVSAYi = []
  iMulSel = self.VVwuhl.VVeFMD()
  if iMulSel : self.VVSAYi.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVSAYi.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVwuhl.VVgQRE()
  self.VVSAYi.append(    ("Select all"    , "selectAll"  ))
  if tot > 0:
   self.VVSAYi.append(   ("Unselect all"    , "unselectAll"  ))
  self.VVSAYi.append(VVudpG)
 def VVDKO1(self, servName, refCode):
  tot = self.VVwuhl.VVgQRE()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVSAYi.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVxxR5_multi" ))
  else    : self.VVSAYi.append( ("Add to Bouquet : %s"      % servName , "VVxxR5_one" ))
  self.VVwtG7(servName, refCode)
 def VV90IY(self, servName, refCode, pcState, hidState):
  isMulti = self.VVwuhl.VVugpB
  if isMulti:
   refCodeList = self.VVwuhl.VVVZHF(3)
   if refCodeList:
    self.VVSAYi.append(("Add Selection to Parental Control"  , "parentalControl_sel_add"  ))
    self.VVSAYi.append(("Remove Selection from Parental Control" , "parentalControl_sel_remove" ))
    self.VVSAYi.append(VVudpG)
    self.VVSAYi.append(("Add Selection to Hidden Services"  , "hiddenServices_sel_add"  ))
    self.VVSAYi.append(("Remove Selection from Hidden Services" , "hiddenServices_sel_remove" ))
   else:
    self.VVSAYi.pop(len(self.VVSAYi) - 1)
  else:
   if pcState == "No" : self.VVSAYi.append(("Add to Parental Control"  , "parentalControl_add"  ))
   else    : self.VVSAYi.append(("Remove from Parental Control" , "parentalControl_remove" ))
   self.VVSAYi.append(VVudpG)
   if hidState == "No" : self.VVSAYi.append(("Add to Hidden Services"  , "hiddenServices_add"  ))
   else    : self.VVSAYi.append(("Remove from Hidden Services" , "hiddenServices_remove" ))
  self.VVwtG7(servName, refCode)
 def VVwtG7(self, servName, refCode):
  FF3fIR(self.callingSELF, boundFunction(self.VVGJ8H, servName, refCode), title="Options", VVSAYi=self.VVSAYi)
 def VVGJ8H(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"     : self.VVwuhl.VVIY29(True)
   elif item == "MultSelDisab"     : self.VVwuhl.VVIY29(False)
   elif item == "selectAll"     : self.VVwuhl.VVYLne()
   elif item == "unselectAll"     : self.VVwuhl.VVZ17W()
   elif item == "parentalControl_add"   : self.callingSELF.VVkGaB(self.VVwuhl, refCode, True)
   elif item == "parentalControl_remove"  : self.callingSELF.VVkGaB(self.VVwuhl, refCode, False)
   elif item == "hiddenServices_add"   : self.callingSELF.VVkO6A(self.VVwuhl, refCode, True)
   elif item == "hiddenServices_remove"  : self.callingSELF.VVkO6A(self.VVwuhl, refCode, False)
   elif item == "parentalControl_sel_add"  : self.callingSELF.VVn0I1(self.VVwuhl, True)
   elif item == "parentalControl_sel_remove" : self.callingSELF.VVn0I1(self.VVwuhl, False)
   elif item == "hiddenServices_sel_add"  : self.callingSELF.VVUSxJ(self.VVwuhl, True)
   elif item == "hiddenServices_sel_remove" : self.callingSELF.VVUSxJ(self.VVwuhl, False)
   elif item == "VVxxR5_multi"  : self.VVxxR5(refCode, True)
   elif item == "VVxxR5_one"  : self.VVxxR5(refCode, False)
 def VVxxR5(self, refCode, isMulti):
  bouquets = FFQRnQ()
  if bouquets:
   VVSAYi = []
   for item in bouquets:
    VVSAYi.append((item[0], item[1].toString()))
   VVEbC5 = ("Create New", boundFunction(self.VVx2GX, refCode, isMulti))
   FF3fIR(self.callingSELF, boundFunction(self.VVoTBh, refCode, isMulti), VVSAYi=VVSAYi, title="Add to Bouquet", VVEbC5=VVEbC5, VVdU6y=True, VVBISI=True)
  else:
   FFhdnr(self.callingSELF, boundFunction(self.VVHigz, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVoTBh(self, refCode, isMulti, bName=None):
  if bName:
   FF8MfV(self.VVwuhl, boundFunction(self.VVOTOG, refCode, isMulti, bName), title="Adding Channels ...")
 def VVOTOG(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVXdjH(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VV26oo = InfoBar.instance
    if VV26oo:
     VVhsPd = VV26oo.servicelist
     if VVhsPd:
      mutableList = VVhsPd.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVwuhl.VVEHtU()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFLnSq(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFv5WO(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVXdjH(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVwuhl.VVVZHF(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVx2GX(self, refCode, isMulti, VVMsOjObj, path):
  self.VVHigz(refCode, isMulti)
 def VVHigz(self, refCode, isMulti):
  FFMKq2(self.callingSELF, boundFunction(self.VVA8mq, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVA8mq(self, refCode, isMulti, name):
  if name:
   FF8MfV(self.VVwuhl, boundFunction(self.VVsVaS, refCode, isMulti, name), title="Adding Channels ...")
 def VVsVaS(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVXdjH(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VV26oo = InfoBar.instance
    if VV26oo:
     VVhsPd = VV26oo.servicelist
     if VVhsPd:
      try:
       VVhsPd.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVhsPd.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVwuhl.VVEHtU()
   title = "Add to Bouquet"
   if allOK: FFLnSq(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFv5WO(self.callingSELF, "Nothing added!", title=title)
class CCNGLM(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFrBKf(VV4uZS, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF4zOZ(self)
  FF313P(self["keyRed"]  , "Exit")
  FF313P(self["keyGreen"]  , "Save")
  FF313P(self["keyYellow"] , "Refresh")
  FF313P(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVQiTU  ,
   "green"   : self.VVZ0xa ,
   "yellow"  : self.VVQT8O  ,
   "blue"   : self.VVE5gl   ,
   "up"   : self.VVt0sY    ,
   "down"   : self.VVEn52   ,
   "left"   : self.VViad8   ,
   "right"   : self.VVepxi   ,
   "cancel"  : self.VVQiTU
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVQT8O()
  self.VV9k3c()
  FFZe3q(self)
 def VVQiTU(self) : self.close(True)
 def VVm491(self) : self.close(False)
 def VVE5gl(self):
  self.session.openWithCallback(self.VVXVHZ, boundFunction(CCzPl4))
 def VVXVHZ(self, closeAll):
  if closeAll:
   self.close()
 def VVt0sY(self):
  self.VVuAbw(1)
 def VVEn52(self):
  self.VVuAbw(-1)
 def VViad8(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VV9k3c()
 def VVepxi(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VV9k3c()
 def VVuAbw(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVc4tL(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVc4tL(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVc4tL(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVP2Oe(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVP2Oe(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VV9k3c(self):
  for obj in self.list:
   FFv4ZZ(obj, "#11404040")
  FFv4ZZ(self.list[self.index], "#11ff8000")
 def VVQT8O(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVZ0xa(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CC4384()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVWrNF)
 def VVWrNF(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFLnSq(self, "Nothing returned from the system!")
  else:
   FFLnSq(self, str(result))
class CCzPl4(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFrBKf(VV2pOX, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF4zOZ(self, addLabel=True)
  FF313P(self["keyRed"]  , "Exit")
  FF313P(self["keyGreen"]  , "Sync")
  FF313P(self["keyYellow"] , "Refresh")
  FF313P(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVQiTU   ,
   "green"   : self.VV23sU  ,
   "yellow"  : self.VVpzQD ,
   "blue"   : self.VVGsTP  ,
   "cancel"  : self.VVQiTU
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVXeNE()
  self.onShow.append(self.start)
 def start(self):
  FFYJiO(self.refresh)
  FFZe3q(self)
 def refresh(self):
  self.VVL9sm()
  self.VVkKGN(False)
 def VVQiTU(self)  : self.close(True)
 def VVGsTP(self) : self.close(False)
 def VVXeNE(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVL9sm(self):
  self.VV3ase()
  self.VV5TRw()
  self.VVMidJ()
  self.VV486o()
 def VVpzQD(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVXeNE()
   self.VVL9sm()
   FFYJiO(self.refresh)
 def VV23sU(self):
  if len(self["keyGreen"].getText()) > 0:
   FFhdnr(self, self.VVnfhS, "Synchronize with Internet Date/Time ?")
 def VVnfhS(self):
  self.VVL9sm()
  FFYJiO(boundFunction(self.VVkKGN, True))
 def VV3ase(self)  : self["keyRed"].show()
 def VV4twG(self)  : self["keyGreen"].show()
 def VV0ZOc(self) : self["keyYellow"].show()
 def VV3Z3b(self)  : self["keyBlue"].show()
 def VV5TRw(self)  : self["keyGreen"].hide()
 def VVMidJ(self) : self["keyYellow"].hide()
 def VV486o(self)  : self["keyBlue"].hide()
 def VVkKGN(self, sync):
  localTime = FFEuaP()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVC2lD(server)
   if epoch_time is not None:
    ntpTime = FFt8n3(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CC4384()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVWrNF, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VV0ZOc()
  self.VV3Z3b()
  if ok:
   self.VV4twG()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVWrNF(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVkKGN(False)
  except:
   pass
 def VVC2lD(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFStZp():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCYUet(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFrBKf(VVsz0j, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FF4zOZ(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FFYJiO(self.VV7LrM)
 def VV7LrM(self):
  if FFStZp(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFv4ZZ(self["myBody"], color)
   FFv4ZZ(self["myLabel"], color)
  except:
   pass
class CC54uT(Screen):
 def __init__(self, session, isFromExternal=False):
  size = CFG.signalSize.getValue()
  screenW = FF21gA()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFrBKf(VVUXcx, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self.isFromExternal  = isFromExternal
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCBA7d(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCBA7d(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCBA7d(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCKv3V()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FF4zOZ(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVt0sY          ,
   "down"  : self.VVEn52         ,
   "left"  : self.VViad8         ,
   "right"  : self.VVepxi         ,
   "info"  : self.VVVkE2        ,
   "epg"  : self.VVVkE2        ,
   "menu"  : self.VVUNcl         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "blue"  : self.VVFRQm       ,
   "last"  : boundFunction(self.VVQhb3, -1)  ,
   "next"  : boundFunction(self.VVQhb3, 1)  ,
   "pageUp" : boundFunction(self.VVpfV7, True) ,
   "chanUp" : boundFunction(self.VVpfV7, True) ,
   "pageDown" : boundFunction(self.VVpfV7, False) ,
   "chanDown" : boundFunction(self.VVpfV7, False) ,
   "0"   : boundFunction(self.VVQhb3, 0)  ,
   "1"   : boundFunction(self.VVEkRi, pos=1) ,
   "2"   : boundFunction(self.VVEkRi, pos=2) ,
   "3"   : boundFunction(self.VVEkRi, pos=3) ,
   "4"   : boundFunction(self.VVEkRi, pos=4) ,
   "5"   : boundFunction(self.VVEkRi, pos=5) ,
   "6"   : boundFunction(self.VVEkRi, pos=6) ,
   "7"   : boundFunction(self.VVEkRi, pos=7) ,
   "8"   : boundFunction(self.VVEkRi, pos=8) ,
   "9"   : boundFunction(self.VVEkRi, pos=9) ,
  }, -1)
  self.onShown.append(self.VVAJmk)
  self.onClose.append(self.onExit)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  self.sliderSNR.VVsaGS()
  self.sliderAGC.VVsaGS()
  self.sliderBER.VVsaGS(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVEkRi()
  self.VVcplGInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVcplG)
  except:
   self.timer.callback.append(self.VVcplG)
  self.timer.start(500, False)
 def VVcplGInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVrIfL(service)
  serviceName = self.tunerInfo.VVIx0t()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
  tp = CCJR3E()
  txt = tp.VVjWAG(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVcplG(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVrIfL(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVabzR())
   self["mySNR"].setText(self.tunerInfo.VVAgFZ())
   self["myAGC"].setText(self.tunerInfo.VVkpAa())
   self["myBER"].setText(self.tunerInfo.VVXpfm())
   self.sliderSNR.VVVJcQ(self.tunerInfo.VVh2gf())
   self.sliderAGC.VVVJcQ(self.tunerInfo.VVKMOf())
   self.sliderBER.VVVJcQ(self.tunerInfo.VVNy7n())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVVJcQ(0)
   self.sliderAGC.VVVJcQ(0)
   self.sliderBER.VVVJcQ(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
    if state and not state == "Tuned":
     FFlFRp(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVVkE2(self):
  FFlYRO(self, fncMode=CCA5BL.VVDqnf)
 def VVUNcl(self):
  FF2UCb(self, VVrF44 + "_help_signal", "Signal Monitor (Keys)")
 def VVFRQm(self):
  self.session.open(CCewzF, isFromExternal=self.isFromExternal)
  self.close()
 def VVt0sY(self)  : self.VVEkRi(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVEn52(self) : self.VVEkRi(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VViad8(self) : self.VVEkRi(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVepxi(self) : self.VVEkRi(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVEkRi(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVQhb3(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFmy2q(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VVpfV7(self, isUp):
  FFlFRp(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVcplGInfo()
  except:
   pass
class CCBA7d(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVsaGS(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFv4ZZ(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVrF44 +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFv4ZZ(self.covObj, self.covColor)
   else:
    FFv4ZZ(self.covObj, "#00006688")
    self.isColormode = True
  self.VVVJcQ(0)
 def VVVJcQ(self, val):
  val  = FFmy2q(val, self.minN, self.maxN)
  width = int(FFnMuZ(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFmy2q(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCHSPO(Screen):
 VVSU2X    = 0
 VVE3Y6 = 1
 VVADEX = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVCoUZ=None, barTheme=VVSU2X):
  ratio = self.VVjsyJ(barTheme)
  self.skin, self.skinParam = FFrBKf(VV117v, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVCoUZ = VVCoUZ
  self.isCancelled = False
  self.isError  = False
  self.curValue  = 0
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVGy5N = None
  self.timer   = eTimer()
  self.myThread  = None
  FF4zOZ(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVAJmk)
  self.onClose.append(self.onExit)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  self.VVmsoC()
  self["myProgBarVal"].setText("0%")
  FFv4ZZ(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVTP5G()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVTP5G)
  except:
   self.timer.callback.append(self.VVTP5G)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def VVKFmP(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVAESW_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVGy5N), self.counter, self.maxValue, catName)
 def VVAESW_fromImportEPG(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVAESW_forcedUpdate(self, title):
  self.newTitle = title
  try:
   self.VVTP5G()
  except:
   pass
 def VVWBRz(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VVGy5N), self.counter, self.maxValue)
  except:
   pass
 def VVZXEw(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVRc4J(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VV4tHd(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFlFRp(self, "Cancelling ...")
  self.isCancelled = True
  self.VVXDYh(False)
 def VVXDYh(self, isDone):
  if self.VVCoUZ:
   self.VVCoUZ(isDone, self.VVGy5N, self.counter, self.maxValue, self.isError)
  self.close()
 def VVTP5G(self):
  val = FFmy2q(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFnMuZ(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VVXDYh(True)
 def VVmsoC(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVE3Y6, self.VVADEX):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVjsyJ(self, barTheme):
  if   barTheme == self.VVE3Y6 : return 0.7
  if   barTheme == self.VVADEX : return 0.5
  else             : return 1
class CC4384(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVCoUZ = {}
  self.commandRunning = False
  self.VVLjgp  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVCoUZ, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVCoUZ[name] = VVCoUZ
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVLjgp:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVEVLE, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVcPAa , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVEVLE, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVcPAa , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVcPAa(name, retval)
  return True
 def VVEVLE(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVcPAa(self, name, retval):
  if not self.VVLjgp:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVCoUZ[name]:
   self.VVCoUZ[name](self.appResults[name], retval)
  del self.VVCoUZ[name]
 def VVBpOH(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCCeh9(Screen):
 def __init__(self, session, title="", VVgPsE=None, VVbE34=False, VVxIY0=False, VV5FhL=False, VVCQnL=False, VV3wNV=False, VVUmDA=False, VVTzbD=VVw7OV, VVhQIf=None, VVwbZs=False, VVZ6QB=None, VVdUs5="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFrBKf(VVvq1J, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FF4zOZ(self, addScrollLabel=True)
  if not VVdUs5:
   VVdUs5 = "Processing ..."
  self["myLabel"].setText("   %s" % VVdUs5)
  self.VVbE34   = VVbE34
  self.VVxIY0   = VVxIY0
  self.VV5FhL   = VV5FhL
  self.VVCQnL  = VVCQnL
  self.VV3wNV = VV3wNV
  self.VVUmDA = VVUmDA
  self.VVTzbD   = VVTzbD
  self.VVhQIf = VVhQIf
  self.VVwbZs  = VVwbZs
  self.VVZ6QB  = VVZ6QB
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CC4384()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFsbex()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVgPsE, str):
   self.VVgPsE = [VVgPsE]
  else:
   self.VVgPsE = VVgPsE
  if self.VV5FhL or self.VVCQnL:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVjUYT, VVjUYT)
   self.VVgPsE.append("echo -e '\n%s\n' %s" % (restartNote, FFA6Lm(restartNote, VVSfxg)))
   if self.VV5FhL:
    self.VVgPsE.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVgPsE.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VV3wNV:
   FFlFRp(self, "Processing ...")
  self.onLayoutFinish.append(self.VVx5eX)
  self.onClose.append(self.VVfL1Z)
 def VVx5eX(self):
  self["myLabel"].VVC5L2(textOutFile="console" if self.enableSaveRes else "")
  if self.VVbE34:
   self["myLabel"].VVLOqo()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVCevh()
  else:
   self.VVJ3aV()
 def VVCevh(self):
  if FFStZp():
   self["myLabel"].setText("Processing ...")
   self.VVJ3aV()
  else:
   self["myLabel"].setText(FFxKI9("\n   No connection to internet!", VV8tYH))
 def VVJ3aV(self):
  allOK = self.container.ePopen(self.VVgPsE[0], self.VV6kdD, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VV6kdD("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVUmDA or self.VV5FhL or self.VVCQnL:
    self["myLabel"].setText(FF81Uc("STARTED", VVSfxg) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVZ6QB:
   colorWhite = CCDNTG.VVRl4D(VVTIP5)
   color  = CCDNTG.VVRl4D(self.VVZ6QB[0])
   words  = self.VVZ6QB[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVTzbD=self.VVTzbD)
 def VV6kdD(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVgPsE):
   allOK = self.container.ePopen(self.VVgPsE[self.cmdNum], self.VV6kdD, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VV6kdD("Cannot connect to Console!", -1)
  else:
   if self.VV3wNV and FF60YR(self):
    FFlFRp(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVUmDA:
    self["myLabel"].appendText("\n" + FF81Uc("FINISHED", VVSfxg), self.VVTzbD)
   if self.VVbE34 or self.VVxIY0:
    self["myLabel"].VVLOqo()
   if self.VVhQIf is not None:
    self.VVhQIf()
   if not retval and self.VVwbZs:
    self.VVfL1Z()
 def VVfL1Z(self):
  if self.container.VVBpOH():
   self.container.killAll()
class CCfJsk(Screen):
 def __init__(self, session, VVgPsE=None, VV3wNV=False):
  self.skin, self.skinParam = FFrBKf(VVvq1J, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVVPVZ + "ajpanel_terminal.history"
  self.customCommandsFile = VVVPVZ + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFw9Nl("pwd") or "/home/root"
  self.container   = CC4384()
  FF4zOZ(self, addScrollLabel=True)
  FF313P(self["keyRed"] , "Exit = Stop Command")
  FF313P(self["keyGreen"] , "OK = History")
  FF313P(self["keyYellow"], "Menu = Custom Cmds")
  FF313P(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVRG31 ,
   "cancel" : self.VV4XoZ  ,
   "menu"  : self.VVIfw4 ,
   "last"  : self.VVzklk  ,
   "next"  : self.VVzklk  ,
   "1"   : self.VVzklk  ,
   "2"   : self.VVzklk  ,
   "3"   : self.VVzklk  ,
   "4"   : self.VVzklk  ,
   "5"   : self.VVzklk  ,
   "6"   : self.VVzklk  ,
   "7"   : self.VVzklk  ,
   "8"   : self.VVzklk  ,
   "9"   : self.VVzklk  ,
   "0"   : self.VVzklk
  })
  self.onLayoutFinish.append(self.VVAJmk)
  self.onClose.append(self.VVaQGp)
 def VVAJmk(self):
  self["myLabel"].VVC5L2(isResizable=False, textOutFile="terminal")
  FFxuhv(self["keyRed"]  , "#00ff8000")
  FFv4ZZ(self["keyRed"]  , self.skinParam["titleColor"])
  FFv4ZZ(self["keyGreen"]  , self.skinParam["titleColor"])
  FFv4ZZ(self["keyYellow"] , self.skinParam["titleColor"])
  FFv4ZZ(self["keyBlue"] , self.skinParam["titleColor"])
  self.VV2ApH(FFw9Nl("date"), 5)
  result = FFw9Nl("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVuoQh()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVrF44 + "LinuxCommands.lst"
   newTemplate = VVrF44 + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFMugq("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFMugq("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVaQGp(self):
  if self.container.VVBpOH():
   self.container.killAll()
   self.VV2ApH("Process killed\n", 4)
   self.VVuoQh()
 def VV4XoZ(self):
  if self.container.VVBpOH():
   self.VVaQGp()
  else:
   FFhdnr(self, self.close, "Exit ?", VV7EBj=False)
 def VVuoQh(self):
  self.VV2ApH(self.prompt, 1)
  self["keyRed"].hide()
 def VV2ApH(self, txt, mode):
  if   mode == 1 : color = VVSfxg
  elif mode == 2 : color = VV9YfT
  elif mode == 3 : color = VVTIP5
  elif mode == 4 : color = VV8tYH
  elif mode == 5 : color = VVIgRq
  elif mode == 6 : color = VVpXnW
  else   : color = VVTIP5
  try:
   self["myLabel"].appendText(FFxKI9(txt, color))
  except:
   pass
 def VV8ums(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VV2ApH(cmd, 2)
   self.VV2ApH("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VV2ApH(ch, 0)
   self.VV2ApH("\nor\n", 4)
   self.VV2ApH("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVuoQh()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFxKI9(parts[0].strip(), VV9YfT)
    right = FFxKI9("#" + parts[1].strip(), VVpXnW)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VV2ApH(txt, 2)
   lastLine = self.VVYJgu()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VV6abJ(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VV6kdD, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFv5WO(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VV2ApH(data, 3)
 def VV6kdD(self, data, retval):
  if not retval == 0:
   self.VV2ApH("Exit Code : %d\n" % retval, 4)
  self.VVuoQh()
 def VVRG31(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVYJgu() == "":
   self.VV6abJ("cd /tmp")
   self.VV6abJ("ls")
  VVprUT = []
  if fileExists(self.commandHistoryFile):
   lines  = FF66GF(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVprUT.append((str(c), line, str(lNum)))
   self.VVr9xD(VVprUT, title, self.commandHistoryFile, isHistory=True)
  else:
   FF7BRF(self, self.commandHistoryFile, title=title)
 def VVYJgu(self):
  lastLine = FFw9Nl("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VV6abJ(self, cmd):
  os.system("echo '%s' >> %s" % (cmd, self.commandHistoryFile))
 def VVIfw4(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FF66GF(self.customCommandsFile)
   lastLineIsSep = False
   VVprUT = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVprUT.append((str(c), line, str(lNum)))
   self.VVr9xD(VVprUT, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FF7BRF(self, self.customCommandsFile, title=title)
 def VVr9xD(self, VVprUT, title, filePath=None, isHistory=False):
  if VVprUT:
   VVTG9d = "#05333333"
   if isHistory: VVM7V1 = VVUL9C = VVehrL = "#11000020"
   else  : VVM7V1 = VVUL9C = VVehrL = "#06002020"
   VV8khl = VVulZM = None
   VVd2cp   = ("Send"   , self.VVxTEZ        , [])
   VVJD06  = ("Modify & Send" , self.VVSYFK        , [])
   if isHistory:
    VV8khl = ("Clear History" , self.VV0xp1        , [])
   elif filePath:
    VVulZM = ("Edit File"  , boundFunction(self.VVvChe, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVDKYV     = (CENTER  , LEFT   , CENTER )
   FFEtMz(self, None, title=title, header=header, VV06zW=VVprUT, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=26, VVd2cp=VVd2cp, VVJD06=VVJD06, VV8khl=VV8khl, VVulZM=VVulZM, VVgpgw=True
     , VVM7V1   = VVM7V1
     , VVUL9C   = VVUL9C
     , VVehrL   = VVehrL
     , VVVl6L  = "#05ffff00"
     , VVTG9d  = VVTG9d
    )
  else:
   FFrHkO(self, filePath, title=title)
 def VVxTEZ(self, VVwuhl, title, txt, colList):
  cmd = colList[1].strip()
  VVwuhl.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VV2ApH("\n%s\n" % cmd, 6)
   self.VV2ApH(self.prompt, 1)
  else:
   self.VV8ums(cmd)
 def VVSYFK(self, VVwuhl, title, txt, colList):
  cmd = colList[1]
  self.VV11Bk(VVwuhl, cmd)
 def VV0xp1(self, VVwuhl, title, txt, colList):
  FFhdnr(self, boundFunction(self.VVfnIk, VVwuhl), "Reset History File ?", title="Command History")
 def VVfnIk(self, VVwuhl):
  os.system(FFMugq("echo '' > %s" % self.commandHistoryFile))
  VVwuhl.cancel()
 def VVvChe(self, filePath, VVwuhl, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCVYVr(self, filePath, VVCoUZ=boundFunction(self.VVfVek, VVwuhl), curRowNum=rowNum)
  else     : FF7BRF(self, filePath)
 def VVfVek(self, VVwuhl, fileChanged):
  if fileChanged:
   VVwuhl.cancel()
   FFYJiO(self.VVIfw4)
 def VVzklk(self):
  self.VV11Bk(None, self.lastCommand)
 def VV11Bk(self, VVwuhl, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFMKq2(self, boundFunction(self.VVwRHV, VVwuhl), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVwRHV(self, VVwuhl, cmd):
  if cmd and len(cmd) > 0:
   self.VV8ums(cmd)
   if VVwuhl:
    VVwuhl.cancel()
class CCNLE9(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVCC3L="", VVNzPk=False, VVd3dQ=False, isTrimEnds=True):
  self.skin, self.skinParam = FFrBKf(VVQGGh, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FF4zOZ(self, title, addLabel=True)
  FF313P(self["keyRed"] , "Up/Down = Change")
  FF313P(self["keyGreen"] , "Overwrite")
  FF313P(self["keyYellow"], "Pick Key Map")
  FF313P(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVd3dQ   = VVd3dQ
  self.VVNzPk  = VVNzPk
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVCC3L, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVb73c      ,
   "green"    : self.VVJpKU    ,
   "yellow"   : self.VV27hx      ,
   "blue"    : self.VVRzeN     ,
   "menu"    : self.VVJYqr     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVsOW7, True) ,
   "down"    : boundFunction(self.VVsOW7, False) ,
   "left"    : self.VVi5Gs       ,
   "right"    : self.VVPgqK       ,
   "home"    : self.VVAmPf       ,
   "end"    : self.VVL5SL       ,
   "next"    : self.VVg5dW      ,
   "last"    : self.VV6JLs      ,
   "deleteForward"  : self.VVg5dW      ,
   "deleteBackward" : self.VV6JLs      ,
   "tab"    : self.VVoi3Y       ,
   "toggleOverwrite" : self.VVJpKU    ,
   "0"     : self.VV9hCb     ,
   "1"     : self.VV9hCb     ,
   "2"     : self.VV9hCb     ,
   "3"     : self.VV9hCb     ,
   "4"     : self.VV9hCb     ,
   "5"     : self.VV9hCb     ,
   "6"     : self.VV9hCb     ,
   "7"     : self.VV9hCb     ,
   "8"     : self.VV9hCb     ,
   "9"     : self.VV9hCb
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVjYvm()
  self.onShown.append(self.VVAJmk)
  self.onClose.append(self.onExit)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FFoZqi(self)
  self["myLabel"].setText(self.message)
  self.VVSjEn()
  if self.VVNzPk : self.VVJpKU()
  else    : self.VVCpPQ()
  FFZe3q(self)
  FFv4ZZ(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVO1TK)
  except:
   self.timer.callback.append(self.VVO1TK)
 def onExit(self):
  self.timer.stop()
 def VVb73c(self):
  self.VV76tc()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VV76tc()
  self.close(None)
 def VVJYqr(self):
  VVSAYi = []
  VVSAYi.append(("Home"         , "home"    ))
  VVSAYi.append(("End"         , "end"     ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Clear All"       , "clearAll"   ))
  VVSAYi.append(("Clear To Home"      , "clearToHome"   ))
  VVSAYi.append(("Clear To End"       , "clearToEnd"   ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VV8X9G:
   VVSAYi.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("To Capital Letters"     , "toCapital"   ))
  VVSAYi.append(("To Small Letters"      , "toSmall"    ))
  FF3fIR(self, self.VVX5Gx, title="Edit Options", VVSAYi=VVSAYi)
 def VVX5Gx(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVAmPf()
   elif item == "end"     : self.VVL5SL()
   elif item == "clearAll"    : self.VVEyfI()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVAmPf()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VV8X9G
    VV8X9G = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VV8X9G)
    self.VVAmPf()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVO1TK(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVJpKU(self):
  self["myInput"].toggleOverwrite()
  self.VVCpPQ()
 def VV27hx(self):
  self.session.openWithCallback(self.VVnzsa, boundFunction(CC0mpJ, mode=self.charMode, VVd3dQ=self.VVd3dQ))
 def VVnzsa(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVSjEn()
 def VVCpPQ(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVjYvm(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VV76tc(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVQoAE(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVi5Gs(self)     : self.VVbjwm(self["myInput"].left)
 def VVPgqK(self)     : self.VVbjwm(self["myInput"].right)
 def VVg5dW(self)     : self.VVbjwm(self["myInput"].delete)
 def VVAmPf(self)     : self.VVbjwm(self["myInput"].home)
 def VVL5SL(self)     : self.VVbjwm(self["myInput"].end)
 def VV6JLs(self)    : self.VVbjwm(self["myInput"].deleteBackward)
 def VVoi3Y(self)     : self.VVbjwm(self["myInput"].tab)
 def VVEyfI(self)     : self["myInput"].setText("")
 def VVbjwm(self, fnc):
  fnc()
  self.VVO1TK()
 def VV9hCb(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVQoAE(newChar, overwrite)
   self.VV8tSy(newChar, self["myInput"].mapping[number])
 def VVsOW7(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CC0mpJ.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CC0mpJ.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVQoAE(newChar, True)
   for group in groups:
    if newChar in group:
     self.VV8tSy(newChar, group)
     break
 def VV8tSy(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVTIP5:
    group = VVIgRq + group.replace(newChar, FFxKI9(newChar, VVTIP5, VVIgRq))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVRzeN(self):
  if self.VVd3dQ : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVSjEn()
 def VVSjEn(self):
  self["myInput"].mapping = CC0mpJ.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CC0mpJ.RCU_MAP_TITLES[self.charMode])
class CC0mpJ(Screen):
 VVfy0w  = 0
 VVXIKM  = 1
 VVDndc  = 2
 VV6hAw  = 3
 VVpN5X = 4
 VVJSZ0 = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols, arabic_nums1, arabic1)
       , ( symbols, arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A" , u"\u0628")
       , (u"\u0647" , u"\u062A")
       )
 def __init__(self, session, mode=VVfy0w, VVd3dQ=False):
  self.skin, self.skinParam = FFrBKf(VVEjiq, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVd3dQ  = VVd3dQ
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FF4zOZ(self, title=self.Title)
  FF313P(self["keyRed"] ,"OK = Select")
  FF313P(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVmjQR     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVItXM, -1) ,
   "next"  : boundFunction(self.VVItXM, +1) ,
   "left"  : boundFunction(self.VVItXM, -1) ,
   "right"  : boundFunction(self.VVItXM, +1) ,
  }, -1)
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FFv4ZZ(self["keyRed"], "#11222222")
  FFv4ZZ(self["keyGreen"], "#11222222")
  self.VVTvcA()
 def VVTvcA(self):
  self.VV9sUI()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VV9sUI(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVItXM(self, direction):
  if self.VVd3dQ : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVTvcA()
 def VVmjQR(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCbNLL(Screen):
 def __init__(self, session, title="", message="", VVTzbD=VVw7OV, VV1Ai8=False, VVehrL=None, VVp74Q=30, canSaveToFile=""):
  self.skin, self.skinParam = FFrBKf(VVvq1J, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVp74Q)
  self.session   = session
  FF4zOZ(self, title, addScrollLabel=True)
  self.VVTzbD   = VVTzbD
  self.VV1Ai8   = VV1Ai8
  self.VVehrL   = VVehrL
  self.canSaveToFile  = canSaveToFile
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  self["myLabel"].VVC5L2(VV1Ai8=self.VV1Ai8, textOutFile=self.canSaveToFile)
  self["myLabel"].setText(self.message, self.VVTzbD)
  if self.VVehrL:
   FFv4ZZ(self["myBody"], self.VVehrL)
   FFv4ZZ(self["myLabel"], self.VVehrL)
   FFf7Xr(self["myLabel"], self.VVehrL)
  self["myLabel"].VVLOqo()
class CCdgYU(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFrBKf(VVJuEs, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FF4zOZ(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FFIXh7(self["errPic"], "err")
class CCsrS3(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FFrBKf(VVAkiN, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", 20)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FF4zOZ(self, " ", addCloser=True)
class CCMMUH():
 def __init__(self, tSession, txt):
  self.win = tSession.instantiateDialog(CCsrS3, txt)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  self.timer   = eTimer()
  self.timerCounter = 0
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVWyM7)
  except:
   self.timer.callback.append(self.VVWyM7)
  self.timer.start(100, False)
 def VVWyM7(self):
  self.timerCounter += 1
  if self.timerCounter > 15:
   self.timer.stop()
   self.win.hide()
class CCGsij():
 VVjPSn    = 0
 VVP04s  = 1
 VVNbMM   = ""
 VVxwSQ    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVwuhl   = None
  self.timer     = eTimer()
  self.VVqoCi   = 0
  self.VV5ZWv  = 1
  self.VVWVYT  = 2
  self.VV0uqG   = 3
  self.VVmgEB   = 4
  VVprUT = self.VVK90l()
  if VVprUT:
   self.VVwuhl = self.VVB5z8(VVprUT)
  if not VVprUT and mode == self.VVjPSn:
   self.VV6xfFor("Download list is empty !")
   self.cancel()
  if mode == self.VVP04s:
   FF8MfV(self.VVwuhl or self.SELF, boundFunction(self.VVfnBa, startDnld, decodedUrl), title="Checking Server ...")
  self.VVuNpN(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVuNpN)
  except:
   self.timer.callback.append(self.VVuNpN)
  self.timer.start(1000, False)
 def VVB5z8(self, VVprUT):
  VVprUT.sort(key=lambda x: int(x[0]))
  VVAIMO = self.VVvzDL
  VVd2cp  = ("Play"  , self.VVJtxl , [])
  VVvxfu = (""   , self.VVM4Yo  , [])
  VVSxFV = ("Stop"  , self.VVyIq4  , [])
  VVJD06 = ("Resume"  , self.VVV4qy , [])
  VV8khl = ("Options" , self.VVHusD  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVDKYV  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFEtMz(self.SELF, None, title=self.Title, header=header, VV06zW=VVprUT, VVDKYV=VVDKYV, VVTS0u=widths, VVp74Q=26, VVd2cp=VVd2cp, VVvxfu=VVvxfu, VVAIMO=VVAIMO, VVSxFV=VVSxFV, VVJD06=VVJD06, VV8khl=VV8khl, VVUL9C="#11110011", VVM7V1="#11220022", VVehrL="#11110011", VVVl6L="#00ffff00", VVTG9d="#00223025", VVCgV5="#0a333333", VVoitp="#0a400040", VVgpgw=True, searchCol=1)
 def VVK90l(self):
  lines = CCGsij.VVPvBy()
  VVprUT = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",")
     left  = parts[0].strip()
     decodedUrl = ",".join(parts[1:]).strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVIgzA(decodedUrl)
      if fName:
       if   FFfkEY(decodedUrl) : sType = "Movie"
       elif FFFH1k(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VV66jq(decodedUrl, fName)
       if size > -1: sizeTxt = CCQ7If.VVmZaL(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVprUT.append((str(len(VVprUT) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVprUT
 def VVVDXI(self):
  VVprUT = self.VVK90l()
  if VVprUT:
   if self.VVwuhl : self.VVwuhl.VVJs1i(VVprUT, VVXeNEMsg=False)
   else     : self.VVwuhl = self.VVB5z8(VVprUT)
  else:
   self.cancel()
 def VVuNpN(self, force=False):
  if self.VVwuhl:
   thrList = self.VVEfy5()
   VVprUT = []
   changed = False
   for ndx, row in enumerate(self.VVwuhl.VV37Hy()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVqoCi
    if m3u8Log:
     percent = self.VVQo5d(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VV0uqG , "%.2f %%" % percent
      else   : flag, progr = self.VVmgEB , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFpeIy(mPath)
     if curSize > -1:
      fSize = CCQ7If.VVmZaL(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCQ7If.VVmZaL(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFpeIy(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VV0uqG , "%.2f %%" % percent
       else   : flag, progr = self.VVmgEB , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCQ7If.VVmZaL(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrList:
     flag = self.VVWVYT
     if m3u8Log :
      if not speed and not force : flag = self.VV5ZWv
      elif curSize == -1   : self.VVPLnn(False)
    elif flag == self.VVqoCi  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVqoCi  : color2 = "#f#00555555#"
    elif flag == self.VV5ZWv : color2 = "#f#0000FFFF#"
    elif flag == self.VVWVYT : color2 = "#f#0000FFFF#"
    elif flag == self.VV0uqG  : color2 = "#f#00FF8000#"
    elif flag == self.VVmgEB  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VV1dqF(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVprUT.append(row)
   if changed or force:
    self.VVwuhl.VVJs1i(VVprUT, VVXeNEMsg=False)
 def VV1dqF(self, flag):
  tDict = self.VVXMRA()
  return tDict.get(flag, "?")
 def VV2tTV(self, state):
  for flag, txt in self.VVXMRA().items():
   if txt == state:
    return flag
  return -1
 def VVXMRA(self):
  return { self.VVqoCi: "Not started", self.VV5ZWv: "Connecting", self.VVWVYT: "Downloading", self.VV0uqG: "Stopped", self.VVmgEB: "Completed" }
 def VVS3xP(self, title):
  colList = self.VVwuhl.VVFplU()
  path = colList[6]
  url  = colList[8]
  if self.VV4sHe() : self.VV6xfFor("Cannot delete !\n\nFile is downloading.")
  else      : FFhdnr(self.SELF, boundFunction(self.VVKfDQ, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVKfDQ(self, path, url):
  m3u8Log = self.VVwuhl.VVFplU()[12].strip()
  if m3u8Log : os.system(FFMugq("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFMugq("rm -r '%s'" % path))
  self.VVgpgq()
  self.VVVDXI()
 def VVgpgq(self):
  if self.VV4sHe():
   FFlFRp(self.VVwuhl, self.VV1dqF(self.VVWVYT), 500)
  else:
   colList  = self.VVwuhl.VVFplU()
   state  = colList[4].strip()
   decodedUrl = colList[9].strip()
   if self.VV2tTV(state) in (self.VVqoCi, self.VVmgEB):
    lines = CCGsij.VVPvBy()
    newLines = []
    found = False
    for line in lines:
     if CCGsij.VVwPqT(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVjGHl(newLines)
     self.VVVDXI()
     FFlFRp(self.VVwuhl, "Removed.", 1000)
    else:
     FFlFRp(self.VVwuhl, "Not found.", 1000)
   else:
    self.VV6xfFor("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VV62at(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFhdnr(self.SELF, boundFunction(self.VVpGYQ, flag), ques, title=title)
 def VVpGYQ(self, flag):
  list = []
  for ndx, row in enumerate(self.VVwuhl.VV37Hy()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VV2tTV(state)
   if   flag == flagVal == self.VVmgEB: list.append(decodedUrl)
   elif flag == flagVal == self.VVqoCi : list.append(decodedUrl)
  lines = CCGsij.VVPvBy()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVjGHl(newLines)
   self.VVVDXI()
   FFlFRp(self.VVwuhl, "%d removed." % totRem, 1000)
  else:
   FFlFRp(self.VVwuhl, "Not found.", 1000)
 def VVhTT4(self):
  colList  = self.VVwuhl.VVFplU()
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFlFRp(self.VVwuhl, "Poster exists", 1500)
  else    : FF8MfV(self.VVwuhl, boundFunction(self.VV3Hlx, decodedUrl, path, png), title="Checking Server ...")
 def VV3Hlx(self, decodedUrl, path, png):
  err = self.VVWKWD(decodedUrl, path, png)
  if err:
   FFv5WO(self.SELF, err, title="Poster Download")
 def VVWKWD(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCjeUi.VVaUH5(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCkpQY.VV6xjj(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCkpQY.VVXTOQ(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCkpQY.VVHt2d(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if pUrl:
   ext = os.path.splitext(pUrl)[1] or ".png"
   tPath, err = FFzKLB(pUrl, "ajpanel_tmp%s", timeout=2, mustBeImage=True)
   if err:
    return "Cannot download poster !\n\n%s" % err
   else:
    png = "%s%s" % (os.path.splitext(path)[0], ext)
    os.system(FFMugq("mv -f '%s' '%s'" % (tPath, png)))
    FF7GAb(self.SELF, title=os.path.basename(png), VVWSPo=png, showGrnMsg="Downloaded")
  else:
   return "Cannot get Poster URL !\n\n%s" % err
  return ""
 def VVM4Yo(self, VVwuhl, title, txt, colList):
  def VVJsq5(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVCE8s(key, val) : return "\n%s:\n%s\n" % (FFxKI9(key, COLOR_CONS_BRIGHT_YELLOW), val.strip())
  heads  = self.VVwuhl.VVex0L()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVJsq5(heads[i]  , CCQ7If.VVmZaL(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVJsq5("Downloaded" , CCQ7If.VVmZaL(int(curSize), mode=0))
   else:
    txt += VVJsq5(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVCE8s(heads[i], colList[i])
  FFGdNj(self.SELF, txt, title=title)
 def VVJtxl(self, VVwuhl, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCQ7If.VVQHnP(self.SELF, path)
  else    : FFlFRp(self.VVwuhl, "File not found", 1000)
 def VVvzDL(self, VVwuhl):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVwuhl:
   self.VVwuhl.cancel()
  del self
 def VVHusD(self, VVwuhl, title, txt, colList):
  decodedUrl = colList[9].strip()
  if CFG.downloadAutoResume.getValue(): resumeTxt = "Disable"
  else        : resumeTxt = "Enable"
  VVSAYi = []
  VVSAYi.append(("Remove current row"      , "VVgpgq"  ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(('Remove all "Completed"'     , "remFinished"    ))
  VVSAYi.append(('Remove all "Not started"'     , "remPending"    ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Delete the file (and remove from list)" , "VVS3xP" ))
  if FFfkEY(decodedUrl):
   VVSAYi.append(VVudpG)
   VVSAYi.append(("Download Movie Poster (from server)" , "VVhTT4"   ))
  VVSAYi.append(VVudpG)
  VVSAYi.append((resumeTxt + " Auto Resume"     , "VVqNWr"  ))
  FF3fIR(self.SELF, self.VVESdK, VVSAYi=VVSAYi, title=self.Title, VVdU6y=True, VVBISI=True)
 def VVESdK(self, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVgpgq"  : self.VVgpgq()
   elif ref == "remFinished"   : self.VV62at(self.VVmgEB, txt)
   elif ref == "remPending"   : self.VV62at(self.VVqoCi, txt)
   elif ref == "VVS3xP" : self.VVS3xP(txt)
   elif ref == "VVhTT4"  : self.VVhTT4()
   elif ref == "VVqNWr"  : self.VVqNWr()
 def VVfnBa(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCjeUi.VVaUH5(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VV6xfFor("Could not get download link !\n\nTry again later.")
     return
  for line in CCGsij.VVPvBy():
   if CCGsij.VVwPqT(decodedUrl, line):
    self.VVWyiu(decodedUrl)
    FFYJiO(boundFunction(FFlFRp, self.VVwuhl, "Already listed !", 2000))
    break
  else:
   params = self.VV7MZI(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VV6xfFor(params[0])
   elif len(params) == 2:
    self.VVKesl(params[0], decodedUrl)
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCQ7If.VVmZaL(fSize)
    FFhdnr(self.SELF, boundFunction(self.VVeu6g, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVeu6g(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCGsij.VVXrDC(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVVDXI()
  if self.VVwuhl:
   self.VVwuhl.VVjVSo()
  if startDnld:
   threadName = self.VVxwSQ + decodedUrl
   self.VVFplZ(threadName, url, decodedUrl, path, resp)
 def VVWyiu(self, decodedUrl):
  for ndx, row in enumerate(self.VVwuhl.VV37Hy()):
   decodedUrl2 = row[9].strip()
   if decodedUrl == decodedUrl2 and self.VVwuhl:
    self.VVwuhl.VVdPXQ(ndx)
    break
 def VV7MZI(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVIgzA(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VV66jq(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCjeUi.VVaUH5(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCjeUi.VVUkecHeader()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head["Content-Length"]
   cType = head["Content-Type"]
   if not "video" in cType:
    if resp.url.endswith(".m3u8"):
     return [resp, 1]
    else:
     return ["Cannot download this video !\n\nNot allowed by server."]
   if "Accept-Ranges" in head:
    resume = head["Accept-Ranges"]
    if not resume == "none":
     resumable = True
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  err = CCGsij.VVC1gT(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVKesl(self, resp, decodedUrl):
  if not os.system(FFMugq("which ffmpeg")) == 0:
   FFhdnr(self.SELF, boundFunction(CCkpQY.VV7B4d, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVIgzA(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVl1iE(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFhdnr(self.SELF, boundFunction(self.VV70PB, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VV70PB(rTxt, rUrl)
  else:
   self.VV6xfFor("Cannot process m3u8 file !")
 def VVl1iE(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVSAYi = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCkpQY.VVgqkU(rUrl, fPath)
   VVSAYi.append((resol, fullUrl))
  if VVSAYi:
   FF3fIR(self.SELF, self.VVoqw3, VVSAYi=VVSAYi, title="Resolution", VVdU6y=True, VVBISI=True)
  else:
   self.VV6xfFor("Cannot get Resolutions list from server !")
 def VVoqw3(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFhdnr(self.SELF, boundFunction(FFYJiO, boundFunction(self.VVbaA9, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFYJiO(boundFunction(self.VVbaA9, resolUrl))
 def VVbaA9(self, resolUrl):
  txt, err = CCjeUi.VVDXXh(resolUrl)
  if err : self.VV6xfFor(err)
  else : self.VV70PB(txt, resolUrl)
 def VVe6ca(self, logF, decodedUrl):
  found = False
  lines = CCGsij.VVPvBy()
  with open(CCGsij.VVXrDC(), "w") as f:
   for line in lines:
    if CCGsij.VVwPqT(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCGsij.VVXrDC(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVVDXI()
 def VV70PB(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCkpQY.VVgqkU(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VV6xfFor("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVe6ca(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFMugq("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = self.VVxwSQ + decodedUrl
  myThread = iThread(name=threadName, target=boundFunction(os.system, cmd))
  myThread.start()
 def VVQo5d(self, dnldLog):
  if fileExists(dnldLog):
   dur = self.VVPNNO(dnldLog)
   if dur > -1:
    tim = self.VVWdDO(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 def VVPNNO(self, dnldLog):
  lines = FFs4zJ("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVWdDO(self, dnldLog):
  lines = FFs4zJ("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VV66jq(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFFH1k(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFMugq("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVFplZ(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVwuhl.VVFplU()[7].strip())
  myThread = iThread(name=threadName, target=boundFunction(self.VVkSW4, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVkSW4(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if CCGsij.VVNbMM == path:
       break
     else:
      break
  except:
   return
  if CCGsij.VVNbMM:
   CCGsij.VVNbMM = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFpeIy(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VV7MZI(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVkSW4(url, decodedUrl, path, resp, totFileSize, True)
 def VVyIq4(self, VVwuhl, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VV0IKq() : FFlFRp(self.VVwuhl, self.VV1dqF(self.VVmgEB), 500)
  elif not self.VV4sHe() : FFlFRp(self.VVwuhl, self.VV1dqF(self.VV0uqG), 500)
  elif m3u8Log      : FFhdnr(self.SELF, self.VVPLnn, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVEfy5():
    CCGsij.VVNbMM = colList[6]
    FFlFRp(self.VVwuhl, "Stopping ...", 1000)
   else:
    FFlFRp(self.VVwuhl, "Stopped", 500)
 def VVPLnn(self, withMsg=True):
  if withMsg:
   FFlFRp(self.VVwuhl, "Stopping ...", 1000)
  os.system(FFMugq("killall -INT ffmpeg"))
 def VVqNWr(self):
  CFG.downloadAutoResume.setValue(not CFG.downloadAutoResume.getValue())
  CFG.downloadAutoResume.save()
  configfile.save()
 def VVV4qy(self, *args):
  if   self.VV0IKq() : FFlFRp(self.VVwuhl, self.VV1dqF(self.VVmgEB) , 500)
  elif self.VV4sHe() : FFlFRp(self.VVwuhl, self.VV1dqF(self.VVWVYT), 500)
  else:
   resume = False
   m3u8Log = self.VVwuhl.VVFplU()[12].strip()
   if m3u8Log:
    if fileExists(m3u8Log) : FFhdnr(self.SELF, boundFunction(self.VVIKb9, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVfnSu():
    resume = True
   if resume: FF8MfV(self.VVwuhl, boundFunction(self.VVHc3k), title="Checking Server ...")
   else  : FFlFRp(self.VVwuhl, "Cannot resume !", 500)
 def VVIKb9(self, m3u8Log):
  os.system(FFMugq("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FF8MfV(self.VVwuhl, boundFunction(self.VVHc3k), title="Checking Server ...")
 def VVHc3k(self):
  colList  = self.VVwuhl.VVFplU()
  path  = colList[6].strip()
  size  = colList[7].strip()
  decodedUrl = colList[9].strip()
  if "j.php" in decodedUrl:
   url = CCjeUi.VVaUH5(decodedUrl)
   if url:
    decodedUrl = self.VV2cLF(decodedUrl, url)
   else:
    self.VV6xfFor("Could not get download link !\n\nTry again later.")
    return
  curSize = FFpeIy(path)
  params = self.VV7MZI(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VV6xfFor(params[0])
   return
  elif len(params) == 2:
   self.VVKesl(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VV2cLF(decodedUrl, url, fSize)
  threadName = self.VVxwSQ + decodedUrl
  if resumable: self.VVFplZ(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VV6xfFor("Cannot resume from server !")
 def VVIgzA(self, decodedUrl):
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(http:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   x = decodedUrl.find("&mode")
   if x > -1: url = decodedUrl[:x]
   fName = ".mp4"
   x = decodedUrl.find("&end=")
   if x > -1: chName = decodedUrl[x+5:]
  if url and fName and chName:
   mix  = fName + chName
   fName =  mix.split(":")[0]
   chName = ":".join(mix.split(":")[1:])
   fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
   url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VV6xfFor(self, txt):
  FFv5WO(self.SELF, txt, title=self.Title)
 def VVEfy5(self):
  thrList = []
  for thr in iEnumerate():
   if self.VVxwSQ in thr.name:
    thrList.append(thr.name.replace(self.VVxwSQ, ""))
  return thrList
 def VV4sHe(self):
  decodedUrl = self.VVwuhl.VVFplU()[9].strip()
  return decodedUrl in self.VVEfy5()
 def VV0IKq(self):
  colList = self.VVwuhl.VVFplU()
  path = colList[6].strip()
  size = colList[7].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFpeIy(path)) == size
 def VVfnSu(self):
  colList = self.VVwuhl.VVFplU()
  path = colList[6].strip()
  size = int(colList[7].strip())
  curSize = FFpeIy(path)
  if curSize > -1:
   size -= curSize
  err = CCGsij.VVC1gT(size)
  if err:
   FFv5WO(self.SELF, err, title=self.Title)
   return False
  return True
 def VVjGHl(self, list):
  with open(CCGsij.VVXrDC(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VV2cLF(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCGsij.VVPvBy()
  url = decodedUrl
  with open(CCGsij.VVXrDC(), "w") as f:
   for line in lines:
    if CCGsij.VVwPqT(decodedUrl, line):
     parts = line.split(",")
     oldUrl = ",".join(parts[1:]).strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVVDXI()
  return url
 @staticmethod
 def VVPvBy():
  list = []
  if fileExists(CCGsij.VVXrDC()):
   for line in FF66GF(CCGsij.VVXrDC()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVwPqT(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVC1gT(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCQ7If.VVs88J(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCQ7If.VVmZaL(size), CCQ7If.VVmZaL(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVUQqm(SELF):
  tot = CCGsij.VV1Rex()
  if tot:
   FFv5WO(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VV1Rex():
  c = 0
  for thread in iEnumerate():
   if thread.name.startswith(CCGsij.VVxwSQ):
    c += 1
  return c
 @staticmethod
 def VVbz6c():
  return len(CCGsij.VVPvBy()) == 0
 @staticmethod
 def VVmAWR():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVnJek():
  mPoints = CCGsij.VVmAWR()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFMugq("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVXrDC():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVcFjY(SELF):
  CCGsij.VVqvTL(SELF, CCGsij.VVjPSn)
 @staticmethod
 def VVKBbB_cur(SELF):
  CCGsij.VVqvTL(SELF, CCGsij.VVP04s, startDnld=True)
 @staticmethod
 def VVKBbB_url(SELF, url):
  CCGsij.VVqvTL(SELF, CCGsij.VVP04s, startDnld=True, decodedUrl=url)
 @staticmethod
 def VV6FLCCurrent(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(SELF)
  added, skipped = CCGsij.VV6FLCList([decodedUrl])
  FFlFRp(SELF, "Added", 1000)
 @staticmethod
 def VV6FLCList(list):
  added = skipped = 0
  for line in CCGsij.VVPvBy():
   for ndx, url in enumerate(list):
    if url and CCGsij.VVwPqT(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCGsij.VVXrDC(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVqvTL(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCIF1R.VVcQFb(SELF):
   return
  if mode == CCGsij.VVjPSn and CCGsij.VVbz6c():
   FFv5WO(SELF, "Download list is empty !", title=title)
  else:
   inst = CCGsij(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
class CCewzF(Screen, CC69K0):
 VVLlLV = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False, enableDownloadMenu=True):
  self.skin, self.skinParam = FFrBKf(VVBqhV, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CC69K0.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  FF4zOZ(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVV6Kc())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayDnld"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVjzC3         ,
   "info"  : self.VVVkE2        ,
   "epg"  : self.VVVkE2        ,
   "menu"  : self.VV3Oke       ,
   "cancel" : self.cancel         ,
   "blue"  : self.VVacjE        ,
   "green"  : self.VViqdK    ,
   "yellow" : self.VVxw4D   ,
   "left"  : boundFunction(self.VVbwV3, -1)   ,
   "right"  : boundFunction(self.VVbwV3,  1)   ,
   "play"  : self.VVjMB1        ,
   "pause"  : self.VVjMB1        ,
   "playPause" : self.VVjMB1        ,
   "stop"  : self.VVjMB1        ,
   "rewind" : self.VVAxRz        ,
   "forward" : self.VVGxNa        ,
   "rewindDm" : self.VVAxRz        ,
   "forwardDm" : self.VVGxNa        ,
   "last"  : boundFunction(self.VV9D05, 0)    ,
   "next"  : self.VVizBE        ,
   "pageUp" : boundFunction(self.VVqGAY, True) ,
   "pageDown" : boundFunction(self.VVqGAY, False) ,
   "chanUp" : boundFunction(self.VVqGAY, True) ,
   "chanDown" : boundFunction(self.VVqGAY, False) ,
   "up"  : boundFunction(self.VVqGAY, True) ,
   "down"  : boundFunction(self.VVqGAY, False) ,
   "audio"  : boundFunction(self.VV96RN, True) ,
   "subtitle" : boundFunction(self.VV96RN, False) ,
   "0"   : boundFunction(self.VVzrUS , 10)  ,
   "1"   : boundFunction(self.VVzrUS , 1)  ,
   "2"   : boundFunction(self.VVzrUS , 2)  ,
   "3"   : boundFunction(self.VVzrUS , 3)  ,
   "4"   : boundFunction(self.VVzrUS , 4)  ,
   "5"   : boundFunction(self.VVzrUS , 5)  ,
   "6"   : boundFunction(self.VVzrUS , 6)  ,
   "7"   : boundFunction(self.VVzrUS , 7)  ,
   "8"   : boundFunction(self.VVzrUS , 8)  ,
   "9"   : boundFunction(self.VVzrUS , 9)
  }, -1)
  self.onShown.append(self.VVAJmk)
  self.onClose.append(self.onExit)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FFoZqi(self)
  if not CCewzF.VVLlLV:
   CCewzF.VVLlLV = self
  else:
   self.close()
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  self["myPlayDnld"].instance.move(ePoint(int(left - self.skinParam["titleH"]), int(top)))
  self["myPlayDnld"].hide()
  FFIXh7(self["myPlayDnld"], "dnld")
  self.VVRPn9()
  self.instance.move(ePoint(40, 40))
  self.VV3B03(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVxSkn)
  except:
   self.timer.callback.append(self.VVxSkn)
  self.timer.start(250, False)
  self.VVxSkn("Checking ...")
  self.VVVYU9()
 def VViqdK(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
  if "chCode" in iptvRef:
   if CCIF1R.VVcQFb(self):
    self.VVVYU9(True)
 def VVRPn9(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FFv4ZZ(self["myTitle"], color)
 def VV3Oke(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
  VVSAYi = []
  if self.isFromExternal:
   VVSAYi.append(("IPTV Menu"     , "iptv"  ))
   VVSAYi.append(VVudpG)
  if FFpq6y(iptvRef) and not "&end=" in decodedUrl and not FFGCwp(decodedUrl):
   uType, uHost, uUser, uPass, uId, uChName = CCkpQY.VV6xjj(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVSAYi.append(("Catchup Programs"   , "catchup"  ))
    VVSAYi.append(VVudpG)
  VVSAYi.append(("Stop Current Service"    , "stop"  ))
  VVSAYi.append(("Restart Current Service"   , "restart"  ))
  VVSAYi.append(VVudpG)
  FFfkEYSeries = FFGCwp(decodedUrl)
  if FFfkEYSeries:
   VVSAYi.append(("File Size"     , "fileSize" ))
   VVSAYi.append(VVudpG)
  if self.enableDownloadMenu:
   addSep = False
   if FFpq6y(iptvRef) and FFfkEYSeries:
    VVSAYi.append(("Start Download"   , "dload_cur" ))
    VVSAYi.append(("Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCGsij.VVbz6c():
    VVSAYi.append(("Download Manager"   , "dload_stat" ))
    addSep = True
   if addSep:
    VVSAYi.append(VVudpG)
  addSep = False
  fPath, fDir, fName = CCQ7If.VVMlYP(self)
  if not CCQ7If.VVfbVU and fPath:
   VVSAYi.append((VVSfxg + "Open path in File Manager" , "VVlpBq"))
   addSep = True
  if fPath:
   VVSAYi.append((VVSfxg + "Add to Movies Bouquet"  , "VV7g0c"))
   addSep = True
  if addSep:
   VVSAYi.append(VVudpG)
  VVSAYi.append(("Move to Top"      , "top"   ))
  VVSAYi.append(("Move to Bottom"     , "botm"  ))
  VVSAYi.append(("Help"        , "help"  ))
  FF3fIR(self, self.VVgv05, VVSAYi=VVSAYi, width=550, title="Options")
 def VVgv05(self, item=None):
  if item:
   if item == "iptv"     : self.VVJmg5()
   elif item == "catchup"    : self.VVxw4D()
   elif item == "stop"     : self.VVD16T(0)
   elif item == "restart"    : self.VVD16T(1)
   elif item == "fileSize"    : FF8MfV(self, boundFunction(CCA5BL.VV60QP, self), title="Checking Server")
   elif item == "dload_cur"   : CCGsij.VVKBbB_cur(self)
   elif item == "addToDload"   : CCGsij.VV6FLCCurrent(self)
   elif item == "dload_stat"   : CCGsij.VVcFjY(self)
   elif item == "VVlpBq" : self.VVlpBq()
   elif item == "VV7g0c" : FF8MfV(self, self.VV7g0c)
   elif item == "botm"     : self.VV3B03(0)
   elif item == "top"     : self.VV3B03(1)
   elif item == "help"     : FF2UCb(self, VVrF44 + "_help_player", "Player Controller (Keys)")
 def onExit(self):
  self.timer.stop()
  CCewzF.VVLlLV = None
 def VVWSCi(self):
  if CCewzF.VVLlLV:
   self.session.open(CCewzF, enableZapping= False, enableDownloadMenu=False)
  self.close()
 def VVlpBq(self):
  self.session.open(CCQ7If, gotoMovie=True)
  self.VVWSCi()
 def VVJmg5(self):
  self.session.open(CCkpQY)
  self.VVWSCi()
 def VVD16T(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.close()
   elif typ == 1:
    self.VVxSkn("Restarting Service ...")
    FFYJiO(boundFunction(self.VV5eqE, serv))
 def VV5eqE(self, serv):
  self.session.nav.stopService()
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
  if "&end=" in decodedUrl: boundFunction(self.VVVYU9, True)
  else     : self.session.nav.playService(serv)
 def VV7g0c(self):
  title = "Add Movie to Bouquet"
  bName = "My Movies"
  path  = VVeXaf + "userbouquet.my_local_movies.tv"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
  fPath, fDir, fName = CCQ7If.VVMlYP(self)
  if not fPath or not chName:
   FFv5WO(self, "Cannot read Path or Channel Name", title=title)
   return
  isNew = False
  if not fileExists(path):
   isNew = True
   with open(path, "w") as f:
    f.write("#NAME %s\n" % bName)
  catID, stID, chNum = "1638", "6", "6"
  refCode = CCkpQY.VVOUlP(catID, stID, chNum)
  if not isNew:
   fTxt = FFqhNI(path)
   chUrl_noRef = "%s:%s" % (fPath, chName)
   if chUrl_noRef in fTxt:
    FFv5WO(self, "Already added to bouquet:\n\n%s" % bName, title=title)
    return
   for ns in range(1, 65535 - 1):
    catID, stID, chNum = "1638", str(ns), "6"
    refCode = CCkpQY.VVOUlP(catID, stID, chNum)
    if not refCode in fTxt:
     break
   else:
    FFv5WO(self, "Cannot create a unique Reference Code", title=title)
    return
  if refCode and fPath and chName:
   chUrl = "%s%s:%s" % (refCode, fPath, chName)
   with open(path, "a") as f:
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
   piconOk = self.VV5aIE(refCode)
   FFk8Yi(os.path.basename(path))
   FF7jBe()
   FFLnSq(self, "Added to bouquet:\n\n%s" % bName, title=title + (" (with PIcon)" if piconOk else ""))
  else:
   FFv5WO(self, "Cannot create a unique Reference Code", title=title)
   return
 def VV5aIE(self, refCode):
  fPath, fDir, fName, picFile = CCA5BL.VVsetP(self)
  pPath = CCOmM2.VVQ8DK()
  if fileExists(pPath) and pathExists(picFile):
   pFile = refCode.replace(":", "_").strip("_") + ".png"
   dest = os.path.join(pPath, pFile)
   os.system(FFMugq("cp -f '%s' '%s'" % (picFile, dest)))
   os.system(FFMugq("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (dest, dest)))
   return True
  return False
 def VV3B03(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VVjzC3(self):
  if self.isManualSeek:
   self.VVGJM7()
   self.VV9D05(self.manualSeekPts)
  else:
   if self.shown: self.hide()
   else   : self.show()
 def cancel(self):
  if self.isManualSeek:
   self.VVGJM7()
  else:
   self.close()
 def VVVkE2(self):
  FFlYRO(self, fncMode=CCA5BL.VV6Ro8)
 def VVjMB1(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except Exception as e:
   pass
  self.VVxSkn("Toggling Play/Pause ...")
 def VVGJM7(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVbwV3(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVNDw8()
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.jumpMinutes * 60.0
   else:
    self.manualSeekSec += direc * self.jumpMinutes * 60.0
    self.manualSeekSec = FFmy2q(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFnMuZ(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFK79w(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVzrUS(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   FF313P(self["myPlayJmp"], self.VVV6Kc())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVxSkn("Changed Jump Minutes to : %d" % val)
 def VVV6Kc(self):
  return "Jump:%dm" % self.jumpMinutes
 def VVxSkn(self, stateTxt="", highlight=False):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
  fr = res = ""
  if info:
   w = FFWEVh(info, iServiceInformation.sVideoWidth) or -1
   h = FFWEVh(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFWEVh(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CCA5BL.VV6sO4(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVNDw8()
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FFmy2q(percVal, 0, 100)
    width = int(FFnMuZ(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not posTxt: self["myPlayPos"].setText("")
  if not remTxt: self["myPlayRem"].setText("")
  if not durTxt:
   if   prov : txt = prov
   elif posTxt : txt = ">>>>"
   else  : txt = "...."
   self["myPlayVal"].setText(txt)
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText("")
   FFv4ZZ(self["myPlayBarBG"], "#1100202a")
   self["myPlayBarF"].hide()
  else:
   FFv4ZZ(self["myPlayBarBG"], "#11000000")
   self["myPlayBarF"].show()
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VVGqsq() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   if highlight: FFxuhv(self["myPlayMsg"], "#0000ffff")
   else  : FFxuhv(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   self["myPlayMsg"].setText("-" if decodedUrl else FFITp0(refCode, True))
   FFxuhv(self["myPlayMsg"], "#00ff8066")
  tot = CCGsij.VV1Rex()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVGAKb()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VV9D05(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
  state = self.VVuWdx()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFxuhv(self["myPlayMsg"], "#0000ff00")
  else     : FFxuhv(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVNDw8(self):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = self.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFK79w(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFK79w(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal
      remTxt = FFK79w(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVGAKb(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVacjE(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVGqsq()
   if cList:
    VVSAYi = []
    for pts, what in cList:
     txt = FFK79w(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVSAYi.append((txt, pts))
    FF3fIR(self, self.VV4EP3, VVSAYi=VVSAYi, title="Cut List")
   else:
    self.VVxSkn("No Cut-List for this channel !")
 def VV4EP3(self, item=None):
  if item:
   self.VV9D05(item)
 def VVGqsq(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVGxNa(self) : self.VV87GI(self.jumpMinutes)
 def VVAxRz(self) : self.VV87GI(-self.jumpMinutes)
 def VV87GI(self, mins):
  try:
   inst = InfoBar.instance
   inst.doSeekRelative(mins * 60 * 90000)
   inst.hide()
   if   mins > 0 : self.VVxSkn("Forawrd (%d min) ..." % self.jumpMinutes)
   elif mins < 0 : self.VVxSkn("Rewind (%d min) ..." % self.jumpMinutes)
  except:
   self.VVxSkn("Cannot jump")
 def VVbo3w(self):
  InfoBar.instance.VVbo3w()
 def VV9D05(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVxSkn("Changing Time ...")
 def VVizBE(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVNDw8()
   if durVal > 0:
    pts = int(durVal * 60 * 90000)
    InfoBar.instance.doSeek(pts)
    self.VVxSkn("Jumping to end ...")
  except:
   pass
 def VVuWdx(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVqGAY(self, isUp):
  if self.enableZapping:
   self.VVxSkn("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVGJM7()
   if self.portalTableParam:
    FFYJiO(boundFunction(self.VV7LGE, isUp))
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
    if "/timeshift/" in decodedUrl:
     self.VVxSkn("Cannot Zap Catcup TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVy22I()
 def VVy22I(self):
  self.lastPlayPos = 0
  self.VVRPn9()
  self.VVVYU9()
 def VV7LGE(self, isUp):
  CCkpQY_inatance, VVwuhl, mode = self.portalTableParam
  if isUp : VVwuhl.VVAtqW()
  else : VVwuhl.VVgaqD()
  colList = VVwuhl.VVFplU()
  if mode == "localIptv":
   chName, chUrl = CCkpQY_inatance.VVGxWA(VVwuhl, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCkpQY_inatance.VV8IPC(VVwuhl, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCkpQY_inatance.VVa64e(mode, VVwuhl, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCkpQY_inatance.VVunZt(mode, VVwuhl, colList)
  else:
   self.VVxSkn("Cannot Zap")
   return
  FFY7Np(self, chUrl, VV4NU5=False)
  self.VVy22I()
 def VVVYU9(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVNDw8()
    if posTxt:
     return
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
   if not self.VVgTKV(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVxSkn("Refreshing Portal")
   FFYJiO(self.VVN6zL)
  except:
   pass
 def VVN6zL(self):
  self.restoreLastPlayPos = self.VVM9yX()
 def VVxw4D(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF45eg(self)
  if not decodedUrl or FFGCwp(decodedUrl):
   self.VVxSkn("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCkpQY.VV6xjj(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVxSkn("Reading Program List ...")
   ok_fnc = boundFunction(self.VVOvpc, refCode, chName, streamId, uHost, uUser, uPass)
   FFYJiO(boundFunction(CCkpQY.VVj9ui, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVxSkn("Cannot process this channel")
 def VVOvpc(self, refCode, chName, streamId, uHost, uUser, uPass, VVwuhl, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVwuhl.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVxSkn("Changing Program ...")
   FFYJiO(boundFunction(self.VV3rRH, chUrl))
  else:
   self.VVxSkn("Incorrect Timestamp !")
 def VV3rRH(self, chUrl):
   FFY7Np(self, chUrl, VV4NU5=False)
   self.lastPlayPos = 0
   self.VVRPn9()
 def VV96RN(self, isAudio):
  try:
   VV26oo = InfoBar.instance
   if VV26oo:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VV26oo)
    else  : self.session.open(SubtitleSelection, VV26oo)
  except:
   pass
class CCgFUs(Screen):
 def __init__(self, session, title="", VVlC3v="Continue?", VV7EBj=True, VVD4Yr=False):
  self.skin, self.skinParam = FFrBKf(VVs3oq, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVlC3v = VVlC3v
  self.VVD4Yr = VVD4Yr
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VV7EBj : VVSAYi = [no , yes]
  else   : VVSAYi = [yes, no ]
  FF4zOZ(self, title, VVSAYi=VVSAYi, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVjzC3 ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVlC3v)
  if self.VVD4Yr:
   self["myLabel"].instance.setHAlign(0)
  self.VVjGd2()
  FF5gi1(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFPj7y(self["myMenu"])
  FFMKwf(self, self["myMenu"])
 def VVjzC3(self):
  item = FFRn36(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVjGd2(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCjXwl(Screen):
 def __init__(self, session, title="", VVSAYi=None, width=1000, OKBtnFnc=None, VV9Wtd=None, VViqfZ=None, VVEbC5=None, VVJtpI=None, VVdU6y=False, VVBISI=False):
  self.skin, self.skinParam = FFrBKf(VV1H0A, width, 850, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVSAYi   = VVSAYi
  self.OKBtnFnc   = OKBtnFnc
  self.VV9Wtd   = VV9Wtd
  self.VViqfZ  = VViqfZ
  self.VVEbC5  = VVEbC5
  self.VVJtpI   = VVJtpI
  self.VVdU6y  = VVdU6y
  self.VVBISI  = VVBISI
  FF4zOZ(self, title, VVSAYi=VVSAYi)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVjzC3          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVDwln         ,
   "green"  : self.VV67uN         ,
   "yellow" : self.VVS74C         ,
   "blue"  : self.VV698A         ,
   "pageUp" : self.VVlTmx       ,
   "chanUp" : self.VVlTmx       ,
   "pageDown" : self.VVifd6        ,
   "chanDown" : self.VVifd6
  }, -1)
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FF5gi1(self["myMenu"])
  FFfRto(self)
  self.VVp0mg(self["keyRed"]  , self.VV9Wtd )
  self.VVp0mg(self["keyGreen"] , self.VViqfZ )
  self.VVp0mg(self["keyYellow"] , self.VVEbC5 )
  self.VVp0mg(self["keyBlue"]  , self.VVJtpI )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFZe3q(self)
 def VVp0mg(self, btnObj, btnFnc):
  if btnFnc:
   FF313P(btnObj, btnFnc[0])
 def VVjzC3(self):
  item = FFRn36(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVdU6y: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVDwln(self)  : self.VVbjwm(self.VV9Wtd)
 def VV67uN(self) : self.VVbjwm(self.VViqfZ)
 def VVS74C(self) : self.VVbjwm(self.VVEbC5)
 def VV698A(self) : self.VVbjwm(self.VVJtpI)
 def VVbjwm(self, btnFnc):
  if btnFnc:
   item = FFRn36(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVBISI:
    self.cancel()
 def VVBKQY(self, VVSAYi):
  if len(VVSAYi) > 0:
   newList = []
   for item in VVSAYi:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVklMb(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVlTmx(self):
  self["myMenu"].moveToIndex(0)
 def VVifd6(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCaZwA(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VV06zW=None, VVDKYV=None, VVTS0u=None, VVp74Q=26, VVgpgw=False, VVd2cp=None, VVvxfu=None, VVSxFV=None, VVJD06=None, VV8khl=None, VVulZM=None, VVHOsw=None, VVomiS=None, VVAIMO=None, VVBa4S=-1, VVJcAq=False, searchCol=0, VVM7V1=None, VVUL9C=None, VVnfio="#00dddddd", VVehrL="#11002233", VVVl6L="#00ff8833", VVTG9d="#11111111", VVCgV5="#0a555555", VVnxUW="#0affffff", VVoitp="#11552200", VVdSmb="#0055ff55"):
  self.skin, self.skinParam = FFrBKf(VVjHqq, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FF4zOZ(self, title)
  self.header     = header
  self.VV06zW     = VV06zW
  self.totalCols    = len(VV06zW[0])
  self.VVsXIb   = 0
  self.lastSortModeIsReverese = False
  self.VVgpgw   = VVgpgw
  self.VVen7K   = 0.01
  self.VV7c7O   = 0.02
  self.VV5OQq = 0.03
  self.VVM3kv  = 1
  self.VVTS0u = VVTS0u
  self.colWidthPixels   = []
  self.VVd2cp   = VVd2cp
  self.OKButtonObj   = None
  self.VVvxfu   = VVvxfu
  self.VVSxFV   = VVSxFV
  self.VVJD06   = VVJD06
  self.VV8khl  = VV8khl
  self.VVulZM   = VVulZM
  self.VVHOsw    = VVHOsw
  self.VVomiS   = VVomiS
  self.VVAIMO  = VVAIMO
  self.VVBa4S    = VVBa4S
  self.VVJcAq   = VVJcAq
  self.searchCol    = searchCol
  self.VVDKYV    = VVDKYV
  self.keyPressed    = -1
  self.VVp74Q    = FFs3iW(VVp74Q)
  self.VVLeZ7    = FF6fS8(self.VVp74Q, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVM7V1    = VVM7V1
  self.VVUL9C      = VVUL9C
  self.VVnfio    = FFX7ku(VVnfio)
  self.VVehrL    = FFX7ku(VVehrL)
  self.VVVl6L    = FFX7ku(VVVl6L)
  self.VVTG9d    = FFX7ku(VVTG9d)
  self.VVCgV5   = FFX7ku(VVCgV5)
  self.VVnxUW    = FFX7ku(VVnxUW)
  self.VVoitp    = FFX7ku(VVoitp)
  self.VVdSmb   = FFX7ku(VVdSmb)
  self.VVugpB  = False
  self.selectedItems   = 0
  self.VVl0PS   = FFX7ku("#01fefe01")
  self.VVi3Jr   = FFX7ku("#11400040")
  self.VVIUon  = self.VVl0PS
  self.VVJIF5  = self.VVTG9d
  if self.VVJcAq:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVHIyx  ,
   "red"   : self.VVwA7n  ,
   "green"   : self.VVO5vP ,
   "yellow"  : self.VVhGKi ,
   "blue"   : self.VVFunj  ,
   "menu"   : self.VVfzVU ,
   "info"   : self.VVmFLL  ,
   "cancel"  : self.VVJKNv  ,
   "up"   : self.VVgaqD    ,
   "down"   : self.VVAtqW  ,
   "left"   : self.VVKpoJ   ,
   "right"   : self.VVpoqP  ,
   "pageUp"  : self.VVEC1P  ,
   "chanUp"  : self.VVEC1P  ,
   "pageDown"  : self.VVjVSo  ,
   "chanDown"  : self.VVjVSo
  }, -1)
  FFfgo9(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FFoZqi(self)
  try:
   self.VVySub()
  except Exception as err:
   FFv5WO(self, str(err))
   self.close(None)
 def VVySub(self):
  FFZe3q(self)
  if self.VVM7V1:
   FFv4ZZ(self["myTitle"], self.VVM7V1)
  if self.VVUL9C:
   FFv4ZZ(self["myBody"] , self.VVUL9C)
   FFv4ZZ(self["myTableH"] , self.VVUL9C)
   FFv4ZZ(self["myTable"] , self.VVUL9C)
   FFv4ZZ(self["myBar"]  , self.VVUL9C)
  self.VVp0mg(self.VVSxFV  , self["keyRed"])
  self.VVp0mg(self.VVJD06  , self["keyGreen"])
  self.VVp0mg(self.VV8khl , self["keyYellow"])
  self.VVp0mg(self.VVulZM  , self["keyBlue"])
  if self.VVd2cp:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVd2cp[0])
    FFv4ZZ(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVLeZ7)
  self["myTableH"].l.setFont(0, gFont(VVVLsX, self.VVp74Q))
  self["myTable"].l.setItemHeight(self.VVLeZ7)
  self["myTable"].l.setFont(0, gFont(VVVLsX, self.VVp74Q))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVLeZ7)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVLeZ7))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVLeZ7)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVLeZ7
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVLeZ7 * len(self.VV06zW) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVTS0u:
   self.VVTS0u = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVTS0u)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVDKYV:
   self.VVDKYV = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVDKYV
   self.VVDKYV = []
   for item in tmpList:
    self.VVDKYV.append(item | RT_VALIGN_CENTER)
  self.VVC3bb()
  if self.VVHOsw:
   self.VVHOsw(self)
 def VVp0mg(self, btnFnc, btn):
  if btnFnc : FF313P(btn, btnFnc[0])
  else  : FF313P(btn, "")
 def VVqZId(self, waitTxt):
  FF8MfV(self, self.VVC3bb, title=waitTxt)
 def VVC3bb(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVdJCo(0, self.header, self.VVnxUW, self.VVoitp, self.VVnxUW, self.VVoitp, self.VVdSmb)])
   rows = []
   for c, row in enumerate(self.VV06zW):
    rows.append(self.VVdJCo(c, row, self.VVnfio, self.VVehrL, self.VVVl6L, self.VVTG9d, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVBa4S > -1:
    self["myTable"].moveToIndex(self.VVBa4S )
   self.VVj4GZ()
   if self.VVJcAq:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVLeZ7 * len(self.VV06zW)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVomiS:
    self.VVbjwm(self.VVomiS, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFv5WO(self, str(err))
    self.close()
   except:
    pass
 def VVdJCo(self, keyIndex, columns, VVnfio, VVehrL, VVVl6L, VVTG9d, VVdSmb):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVdSmb and ndx == self.VVsXIb : textColor = VVdSmb
   else           : textColor = VVnfio
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFX7ku(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVehrL = c
    entry = span.group(3)
   if self.VVDKYV[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVLeZ7)
           , font   = 0
           , flags   = self.VVDKYV[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVehrL
           , color_sel  = VVVl6L
           , backcolor_sel = VVTG9d
           , border_width = 1
           , border_color = self.VVCgV5
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVmFLL(self):
  rowData = self.VVpkoB()
  if rowData:
   title, txt, colList = rowData
   if self.VVvxfu:
    fnc  = self.VVvxfu[1]
    params = self.VVvxfu[2]
    fnc(self, title, txt, colList)
   else:
    FFGdNj(self, txt, title)
 def VVHIyx(self):
  if   self.VVugpB : self.VVafzq(self.VVZMuy(), mode=2)
  elif self.VVd2cp  : self.VVbjwm(self.VVd2cp, None)
  else      : self.VVmFLL()
 def VVwA7n(self) : self.VVbjwm(self.VVSxFV , self["keyRed"])
 def VVO5vP(self) : self.VVbjwm(self.VVJD06 , self["keyGreen"])
 def VVhGKi(self): self.VVbjwm(self.VV8khl , self["keyYellow"])
 def VVFunj(self) : self.VVbjwm(self.VVulZM , self["keyBlue"])
 def VVbjwm(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFlFRp(self, buttonFnc[3])
    FFYJiO(boundFunction(self.VVq9a4, buttonFnc))
   else:
    self.VVq9a4(buttonFnc)
 def VVq9a4(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVpkoB()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVafzq(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VV06zW[ndx]
   isSelected = row[1][9] == self.VVl0PS
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVdJCo(ndx, item, self.VVnfio, self.VVehrL, self.VVVl6L, self.VVTG9d, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVdJCo(ndx, item, self.VVl0PS, self.VVi3Jr, self.VVIUon, self.VVJIF5, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVj4GZ()
 def VVYLne(self):
  FF8MfV(self, self.VVOqAQ, title="Selecting all ...")
 def VVOqAQ(self):
  self.VVIY29(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVl0PS
   if not isSelected:
    item = self.VV06zW[ndx]
    newRow = self.VVdJCo(ndx, item, self.VVl0PS, self.VVi3Jr, self.VVIUon, self.VVJIF5, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVj4GZ()
  self.VVWdvB()
 def VVZ17W(self):
  FF8MfV(self, self.VVMBbc, title="Unselecting all ...")
 def VVMBbc(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVl0PS:
    item = self.VV06zW[ndx]
    newRow = self.VVdJCo(ndx, item, self.VVnfio, self.VVehrL, self.VVVl6L, self.VVTG9d, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVj4GZ()
  self.VVWdvB()
 def VVWdvB(self):
  self.hide()
  self.show()
 def VVpkoB(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVTS0u[i] > 1 or self.VVTS0u[i] == self.VVen7K or self.VVTS0u[i] == self.VV5OQq:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VV06zW))
   return rowNum, txt, colList
  else:
   return None
 def VVJKNv(self):
  if self.VVAIMO : self.VVAIMO(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVsOzc(self):
  return self["myTitle"].getText().strip()
 def VVex0L(self):
  return self.header
 def VVs63l(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVs3je(self, txt):
  FFlFRp(self, txt)
 def VVT6LE(self, txt):
  FFlFRp(self, txt, 1000)
 def VVEHtU(self):
  FFlFRp(self)
 def VV7zcM(self):
  return len(self.VV06zW)
 def VV58kR(self): self["keyGreen"].show()
 def VVFwf0(self): self["keyGreen"].hide()
 def VVZMuy(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVI71A(self):
  return len(self["myTable"].list)
 def VVIY29(self, isOn):
  self.VVugpB = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu"].hide()
   if self.VVulZM: self["keyBlue"].hide()
   if self.VVd2cp and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVulZM: self["keyBlue"].show()
   if self.VVd2cp and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVd2cp[0])
   self.VVZ17W()
  FFv4ZZ(self["myTitle"], color)
  FFv4ZZ(self["myBar"]  , color)
 def VVeFMD(self):
  return self.VVugpB
 def VVgQRE(self):
  return self.selectedItems
 def VVr9OJ(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVj4GZ()
 def VVKBQR(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVj4GZ()
 def VVxGgX(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VV06zW:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVoc4W(self):
  txt  = "Total Rows\t: %d\n\n" % self.VV7zcM()
  txt += FF81Uc("Total Unique Items", VV8tYH)
  for i in range(self.totalCols):
   if self.VVTS0u[i - 1] > 1 or self.VVTS0u[i - 1] == self.VVen7K or self.VVTS0u[i - 1] == self.VV5OQq:
    name, tot = self.VVxGgX(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFGdNj(self, txt)
 def VVuoNu(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVFplU(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVJs1i(self, newList, newTitle="", VVXeNEMsg=True):
  if newList:
   self.VV06zW = newList
   if self.VVgpgw and self.VVsXIb == 0:
    self.VV06zW = sorted(self.VV06zW, key=lambda x: int(x[self.VVsXIb])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VV06zW = sorted(self.VV06zW, key=lambda x: x[self.VVsXIb].lower(), reverse=self.lastSortModeIsReverese)
   if VVXeNEMsg : self.VVqZId("Refreshing ...")
   else   : self.VVC3bb()
   if newTitle:
    self.VVs63l(newTitle)
  else:
   FFv5WO(self, "Cannot refresh list")
   self.cancel()
 def VVVSNs(self, data):
  ndx = self.VVZMuy()
  newRow = self.VVdJCo(ndx, data, self.VVnfio, self.VVehrL, self.VVVl6L, self.VVTG9d, None)
  if newRow:
   self.VV06zW[ndx] = data
   self["myTable"].list[ndx] = newRow
   self.VVj4GZ()
   return True
  else:
   return False
 def VV5o1g(self, colNum, textToFind, VV6xfF=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVj4GZ()
    break
  else:
   if VV6xfF:
    FFlFRp(self, "Not found", 1000)
 def VVycrI(self, colDict, VV6xfF=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVj4GZ()
    return
  if VV6xfF:
   FFlFRp(self, "Not found", 1000)
 def VVycrI_partial(self, colDict, VV6xfF=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVj4GZ()
    return
  if VV6xfF:
   FFlFRp(self, "Not found", 1000)
 def VV0wLx(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVVZHF(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVl0PS:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VV37Hy(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVfzVU(self):
  if not self["keyMenu"].getVisible() or self.VVJcAq:
   return
  VVSAYi = []
  VVSAYi.append(("Table Statistcis"             , "tableStat"  ))
  VVSAYi.append(VVudpG)
  VVSAYi.append((FFxKI9("Export Table to .html"     , VV8tYH) , "VVsJaC" ))
  VVSAYi.append((FFxKI9("Export Table to .csv"     , VV8tYH) , "VVlf8S" ))
  VVSAYi.append((FFxKI9("Export Table to .txt (Tab Separated)", VV8tYH) , "VVsk8N" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVTS0u[i] > 1 or self.VVTS0u[i] == self.VV7c7O:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVSAYi.append(VVudpG)
   if tot == 1 : VVSAYi.append(("Sort", sList[0][1]))
   else  : VVSAYi += sList
  FF3fIR(self, self.VVa9FE, VVSAYi=VVSAYi, title=self.VVsOzc())
 def VVa9FE(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVoc4W()
   elif item == "VVsJaC": FF8MfV(self, self.VVsJaC, title=title)
   elif item == "VVlf8S" : FF8MfV(self, self.VVlf8S , title=title)
   elif item == "VVsk8N" : FF8MfV(self, self.VVsk8N , title=title)
   else:
    isReversed = False
    if self.VVsXIb == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVgpgw and item == 0:
     self.VV06zW = sorted(self.VV06zW, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VV06zW = sorted(self.VV06zW, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVsXIb = item
    self.VVqZId("Sorting ...")
 def VVgaqD(self):
  self["myTable"].up()
  self.VVj4GZ()
 def VVAtqW(self):
  self["myTable"].down()
  self.VVj4GZ()
 def VVKpoJ(self):
  self["myTable"].pageUp()
  self.VVj4GZ()
 def VVpoqP(self):
  self["myTable"].pageDown()
  self.VVj4GZ()
 def VVEC1P(self):
  self["myTable"].moveToIndex(0)
  self.VVj4GZ()
 def VVjVSo(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVj4GZ()
 def VVdPXQ(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVj4GZ()
 def VVsk8N(self):
  expFile = self.VV2Kat() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVhkEZ()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VV06zW:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVTS0u[ndx] > self.VVM3kv or self.VVTS0u[ndx] == self.VV5OQq:
      col = self.VVIYzf(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVVBq1(expFile)
 def VVlf8S(self):
  expFile = self.VV2Kat() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVhkEZ()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VV06zW:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVTS0u[ndx] > self.VVM3kv or self.VVTS0u[ndx] == self.VV5OQq:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVIYzf(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVVBq1(expFile)
 def VVsJaC(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVsOzc(), PLUGIN_NAME, VVwyo7)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVsOzc()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVhkEZ()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVTS0u:
   colgroup += '   <colgroup>'
   for w in self.VVTS0u:
    if w > self.VVM3kv or w == self.VV5OQq:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VV2Kat() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VV06zW:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVTS0u[ndx] > self.VVM3kv or self.VVTS0u[ndx] == self.VV5OQq:
      col = self.VVIYzf(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVVBq1(expFile)
 def VVhkEZ(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVTS0u[ndx] > self.VVM3kv or self.VVTS0u[ndx] == self.VV5OQq:
     newRow.append(col.strip())
  return newRow
 def VVIYzf(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFxdkh(col)
 def VV2Kat(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVsOzc())
  fileName = fileName.replace("__", "_")
  path  = FFhBEj(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFS6oF()
  return expFile
 def VVVBq1(self, expFile):
  FFLnSq(self, "File exported to:\n\n%s" % expFile, title=self.VVsOzc())
 def VVj4GZ(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CC823A(Screen):
 def __init__(self, session, title="", VVWSPo=None, showGrnMsg=""):
  self.skin, self.skinParam = FFrBKf(VVmaS6, 1400, 800, 30, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FF4zOZ(self, title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VVWSPo = VVWSPo
  self.showGrnMsg  = showGrnMsg
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  allOK = FF95wO(self["myLabel"], self.VVWSPo)
  if allOK:
   if self.showGrnMsg:
    FFlFRp(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFv5WO(self, "Cannot view picture file:\n\n%s" % self.VVWSPo)
   self.close()
class CCBngL(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFrBKf(VViB1h, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  FF4zOZ(self)
  FF313P(self["keyGreen"], "Save")
  self.VV06zW = []
  self.VV06zW.append(getConfigListEntry("Show in Main Menu"          , CFG.showInMainMenu   ))
  self.VV06zW.append(getConfigListEntry("Show in Extensions Menu"         , CFG.showInExtensionMenu  ))
  self.VV06zW.append(getConfigListEntry("Show in Channel List Context Menu"      , CFG.showInChannelListMenu  ))
  self.VV06zW.append(getConfigListEntry("Show in Events Info Menu"        , CFG.EventsInfoMenu   ))
  self.VV06zW.append(getConfigListEntry("Input Type"            , CFG.keyboard     ))
  self.VV06zW.append(getConfigListEntry("Signal & Player Cotroller Hotkey"      , CFG.hotkey_signal    ))
  if VVsfqS:
   self.VV06zW.append(getConfigListEntry("EPG Translation Language"       , CFG.epgLanguage    ))
  self.VV06zW.append(getConfigListEntry(VVjUYT *2             ,         ))
  self.VV06zW.append(getConfigListEntry("Default IPTV Reference Type"        , CFG.iptvAddToBouquetRefType ))
  self.VV06zW.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"  , CFG.autoResetFrozenIptvChan ))
  self.VV06zW.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"     , CFG.hideIptvServerAdultWords ))
  self.VV06zW.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"  , CFG.hideIptvServerChannPrefix ))
  self.VV06zW.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"   , CFG.iptvHostsPath    ))
  self.VV06zW.append(getConfigListEntry("Movie/Series Download Path"        , CFG.MovieDownloadPath   ))
  self.VV06zW.append(getConfigListEntry(VVjUYT *2             ,         ))
  self.VV06zW.append(getConfigListEntry("PIcons Path"            , CFG.PIconsPath    ))
  self.VV06zW.append(getConfigListEntry(VVjUYT *2             ,         ))
  self.VV06zW.append(getConfigListEntry("Backup/Restore Path"          , CFG.backupPath    ))
  self.VV06zW.append(getConfigListEntry("Created Package Files (IPK/DEB)"       , CFG.packageOutputPath   ))
  self.VV06zW.append(getConfigListEntry("Downloaded Packages (from feeds)"      , CFG.downloadedPackagesPath ))
  self.VV06zW.append(getConfigListEntry("Exported Tables"           , CFG.exportedTablesPath  ))
  self.VV06zW.append(getConfigListEntry("Exported PIcons"           , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, self.VV06zW, session)
  self.VVQdGK()
  self.titleText = "  Settings"
  self["myTitle"].setText(self.titleText)
  self.onShown.append(self.VVAJmk)
 def VVQdGK(self):
  kList = {
    "ok"  : self.VVjzC3    ,
    "green"  : self.VVr6iB   ,
    "menu"  : self.VVilQn  ,
    "cancel" : self.VVtgkJ  ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"]  = boundFunction(self["config"].handleKey, kLeft)
   kList["right"]  = boundFunction(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = boundFunction(self["config"].setCurrentIndex, 0)
     kList["chanDown"] = boundFunction(self["config"].setCurrentIndex, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FFoZqi(self)
  FF5gi1(self["config"])
  FFfRto(self, self["config"])
  FFZe3q(self)
 def VVjzC3(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsPath   : self.VVk5As()
   elif item == CFG.MovieDownloadPath   : self.VV2iDT(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VVbiil(item)
   elif item == CFG.backupPath    : self.VVbiil(item)
   elif item == CFG.packageOutputPath  : self.VVbiil(item)
   elif item == CFG.downloadedPackagesPath : self.VVbiil(item)
   elif item == CFG.exportedTablesPath  : self.VVbiil(item)
   elif item == CFG.exportedPIconsPath  : self.VVbiil(item)
 def VV2iDT(self, item, title):
  tot = CCGsij.VV1Rex()
  if tot : FFv5WO(self, "Cannot change while downloading.", title=title)
  else : self.VVbiil(item)
 def VVk5As(self):
  VVSAYi = []
  VVSAYi.append(("Auto Find" , "auto"))
  VVSAYi.append(("Custom Path" , "path"))
  FF3fIR(self, self.VVIJgp, VVSAYi=VVSAYi, title="IPTV Hosts Files Path")
 def VVIJgp(self, item=None):
  if item:
   if   item == "auto": CFG.iptvHostsPath.setValue(VVDWGF)
   elif item == "path": self.VVbiil(CFG.iptvHostsPath)
 def VVbiil(self, configObj):
  sDir = configObj.getValue()
  if sDir == VVDWGF:
   sDir = "/"
  self.session.openWithCallback(boundFunction(self.VVCtpb, configObj)
         , boundFunction(CCQ7If, mode=CCQ7If.VVevyr, VVBz5n=sDir))
 def VVCtpb(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVtgkJ(self):
  if CFG.showInMainMenu.isChanged()    or \
   CFG.showInExtensionMenu.isChanged()   or \
   CFG.showInChannelListMenu.isChanged()  or \
   CFG.EventsInfoMenu.isChanged()    or \
   CFG.keyboard.isChanged()     or \
   CFG.hotkey_signal.isChanged()    or \
   CFG.epgLanguage.isChanged()     or \
   CFG.iptvAddToBouquetRefType.isChanged()  or \
   CFG.autoResetFrozenIptvChan.isChanged()  or \
   CFG.hideIptvServerAdultWords.isChanged() or \
   CFG.hideIptvServerChannPrefix.isChanged() or \
   CFG.iptvHostsPath.isChanged()    or \
   CFG.MovieDownloadPath.isChanged()   or \
   CFG.PIconsPath.isChanged()     or \
   CFG.backupPath.isChanged()     or \
   CFG.packageOutputPath.isChanged()   or \
   CFG.downloadedPackagesPath.isChanged()  or \
   CFG.exportedTablesPath.isChanged()   or \
   CFG.exportedPIconsPath.isChanged():
    FFhdnr(self, self.VVr6iB, "Save Changes ?", callBack_No=self.cancel)
  else:
   self.cancel()
 def VVr6iB(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVAW5P()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVilQn(self):
  VVSAYi = []
  VVSAYi.append(("Use Backup directory in all other paths"      , "VVuVl6"   ))
  VVSAYi.append(("Reset all to default (including File Manager bookmarks)"  , "VVJRBj"   ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Backup %s Settings" % PLUGIN_NAME        , "VV28nG"  ))
  VVSAYi.append(("Restore %s Settings" % PLUGIN_NAME       , "VV8bm6"  ))
  if fileExists(VVVPVZ + VVKjcY):
   VVSAYi.append(VVudpG)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVSAYi.append(('%s Checking for Update' % txt1       , txt2     ))
   VVSAYi.append(("Reinstall %s" % PLUGIN_NAME        , "VVKicJ"  ))
   VVSAYi.append(("Update %s" % PLUGIN_NAME        , "VVvyC6"   ))
  FF3fIR(self, self.VV5vS2, VVSAYi=VVSAYi, title="Config. Options")
 def VV5vS2(self, item=None):
  if item:
   if   item == "VVuVl6"  : FFhdnr(self, self.VVuVl6 , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVJRBj"  : FFhdnr(self, self.VVJRBj, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCDNTG)
   elif item == "VV28nG" : self.VV28nG()
   elif item == "VV8bm6" : FF8MfV(self, self.VV8bm6, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VV7bLX(True)
   elif item == "disableChkUpdate" : self.VV7bLX(False)
   elif item == "VVKicJ" : FF8MfV(self, self.VVKicJ , "Checking Server ...")
   elif item == "VVvyC6"  : FF8MfV(self, self.VVvyC6  , "Checking Server ...")
 def VV28nG(self):
  path = "%sajpanel_settings_%s" % (VVVPVZ, FFS6oF())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFLnSq(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VV8bm6(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFs4zJ("find / %s -iname '%s*' | grep %s" % (FFfLcR(1), name, name))
  if lines:
   lines.sort()
   VVSAYi = []
   for line in lines:
    VVSAYi.append((line, line))
   FF3fIR(self, boundFunction(self.VVEzmq, title), title=title, VVSAYi=VVSAYi, width=1200)
  else:
   FFv5WO(self, "No settings files found !", title=title)
 def VVEzmq(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FF66GF(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVAW5P()
    FFZuwO()
   else:
    FF7BRF(SELF, path, title=title)
 def VV7bLX(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVuVl6(self):
  newPath = FFhBEj(VVVPVZ)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVAW5P()
 @staticmethod
 def VVo6Vg():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVJRBj(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.EventsInfoMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.epgLanguage.setValue("off")
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.autoResetFrozenIptvChan.setValue(False)
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.iptvHostsPath.setValue(VVDWGF)
  CFG.MovieDownloadPath.setValue(CCGsij.VVnJek())
  CFG.PIconsPath.setValue(VVMhCM)
  CFG.backupPath.setValue(CCBngL.VVo6Vg())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  CFG.showInMainMenu.save()
  CFG.showInExtensionMenu.save()
  CFG.showInChannelListMenu.save()
  CFG.EventsInfoMenu.save()
  CFG.keyboard.save()
  CFG.hotkey_signal.save()
  CFG.epgLanguage.save()
  CFG.iptvAddToBouquetRefType.save()
  CFG.autoResetFrozenIptvChan.save()
  CFG.hideIptvServerAdultWords.save()
  CFG.hideIptvServerChannPrefix.save()
  CFG.iptvHostsPath.save()
  CFG.MovieDownloadPath.save()
  CFG.PIconsPath.save()
  CFG.backupPath.save()
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  CFG.browserStartPath.save()
  CFG.browserBookmarks.save()
  self.VVAW5P()
  self.close()
 def VVAW5P(self):
  configfile.save()
  global VVVPVZ
  VVVPVZ = CFG.backupPath.getValue()
  FF3t2j()
 def VVvyC6(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVToSw(title)
  if webVer:
   FFhdnr(self, boundFunction(FF8MfV, self, boundFunction(self.VVfNrv, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVKicJ(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVToSw(title, True)
  if webVer:
   FFhdnr(self, boundFunction(FF8MfV, self, boundFunction(self.VVfNrv, webVer, title)), "Install and Restart ?", title=title)
 def VVfNrv(self, webVer, title):
  url = self.VVZdEb(self, title)
  if url:
   VVLjgp = FFUpZG() == "dpkg"
   if VVLjgp == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVLjgp else "ipk")
   path, err = FFzKLB(url + fName, fName, timeout=2)
   if path:
    cmd = FFyov6(VVi2Z7, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFl3Il(self, cmd)
    else:
     FFXixL(self, title=title)
   else:
    FFv5WO(self, err, title=title)
 def VVToSw(self, title, anyVer=False):
  url = self.VVZdEb(self, title)
  if not url:
   return ""
  path, err = FFzKLB(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFv5WO(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFqhNI(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFv5WO(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVwyo7.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFs4zJ(cmd)
   if list and curVer == list[0]:
    return webVer
  FFLnSq(self, FFxKI9("No update required.", VV3SOs) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVZdEb(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVVPVZ + VVKjcY
  if fileExists(path):
   span = iSearch(r"(http.+)", FFqhNI(path), IGNORECASE)
   if span : url = FFhBEj(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFv5WO(SELF, err, title)
  return url
 @staticmethod
 def VVOfgS(url):
  path, err = FFzKLB(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFqhNI(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVwyo7.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFs4zJ(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCDNTG(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFrBKf(VVxj6t, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVqtWu
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FF4zOZ(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVOHKE("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVOHKE("\c00888888", i) + sp + "GREY\n"
   txt += self.VVOHKE("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVOHKE("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVOHKE("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVOHKE("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVOHKE("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVOHKE("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVOHKE("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVOHKE("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVOHKE("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVOHKE("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVjzC3 ,
   "green"   : self.VVjzC3 ,
   "left"   : self.VViad8 ,
   "right"   : self.VVepxi ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  self.VV0xpd()
 def VVjzC3(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFhdnr(self, self.VVlhQ2, "Change to : %s" % txt, title=self.Title)
 def VVlhQ2(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVqtWu
  VVqtWu = self.cursorPos
  self.VVSmvH()
  self.close()
 def VViad8(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VV0xpd()
 def VVepxi(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VV0xpd()
 def VV0xpd(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVOHKE(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVRl4D(color):
  if VVSfxg: return "\\" + color
  else    : return ""
 @staticmethod
 def VVSmvH():
  global VVpXnW, VVIgRq, VVxd7c, VV8tYH, VVHaNU, VVULex, VV3SOs, VVSfxg, COLOR_CONS_BRIGHT_YELLOW, VV9YfT, VVMcHq, VVZ7zN, VVTIP5
  VVTIP5   = CCDNTG.VVOHKE("\c00FFFFFF", VVqtWu)
  VVIgRq    = CCDNTG.VVOHKE("\c00888888", VVqtWu)
  VVpXnW  = CCDNTG.VVOHKE("\c005A5A5A", VVqtWu)
  VVULex    = CCDNTG.VVOHKE("\c00FF0000", VVqtWu)
  VVxd7c   = CCDNTG.VVOHKE("\c00FF5000", VVqtWu)
  VVSfxg   = CCDNTG.VVOHKE("\c00FFFF00", VVqtWu)
  COLOR_CONS_BRIGHT_YELLOW = CCDNTG.VVOHKE("\c00FFFFAA", VVqtWu)
  VV3SOs   = CCDNTG.VVOHKE("\c0000FF00", VVqtWu)
  VVHaNU    = CCDNTG.VVOHKE("\c000066FF", VVqtWu)
  VV9YfT    = CCDNTG.VVOHKE("\c0000FFFF", VVqtWu)
  VVMcHq  = CCDNTG.VVOHKE("\c00DSFFFF", VVqtWu)  #
  VVZ7zN   = CCDNTG.VVOHKE("\c00FA55E7", VVqtWu)
  VV8tYH    = CCDNTG.VVOHKE("\c00FF8F5F", VVqtWu)
CCDNTG.VVSmvH()
class CCiCs1(Screen):
 def __init__(self, session, path, VVLjgp):
  self.skin, self.skinParam = FFrBKf(VV2pOX, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVB4IN   = path
  self.VV9YJp   = ""
  self.VV69Fa   = ""
  self.VVLjgp    = VVLjgp
  self.VV5PI2    = ""
  self.VVgbAa  = ""
  self.VV1fKo    = False
  self.VVKo0v  = False
  self.postInstAcion   = 0
  self.VVL69Y  = "enigma2-plugin-extensions"
  self.VVMOQ8  = "enigma2-plugin-systemplugins"
  self.VVM80J = "enigma2"
  self.VVPagk  = 0
  self.VVuHU5  = 1
  self.VV97eR  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVEL0A = "DEBIAN"
  else        : self.VVEL0A = "CONTROL"
  self.controlPath = self.Path + self.VVEL0A
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVLjgp:
   self.packageExt  = ".deb"
   self.VVehrL  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVehrL  = "#11001020"
  FF4zOZ(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FF313P(self["keyRed"] , "Create")
  FF313P(self["keyGreen"] , "Post Install")
  FF313P(self["keyYellow"], "Installation Path")
  FF313P(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VViyvz  ,
   "green"   : self.VVcBF5 ,
   "yellow"  : self.VVQpUe  ,
   "blue"   : self.VVBB8c  ,
   "cancel"  : self.VVQiTU
  }, -1)
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  FFZe3q(self)
  if self.VVehrL:
   FFv4ZZ(self["myBody"], self.VVehrL)
   FFv4ZZ(self["myLabel"], self.VVehrL)
  self.VVOWyD(True)
  self.VVPEtt(True)
 def VVPEtt(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVmT1B()
  if isFirstTime:
   if   package.startswith(self.VVL69Y) : self.VVB4IN = VV1Enj + self.VV5PI2 + "/"
   elif package.startswith(self.VVMOQ8) : self.VVB4IN = VVuisN + self.VV5PI2 + "/"
   else            : self.VVB4IN = self.Path
  if self.VV1fKo : myColor = VV8tYH
  else    : myColor = VVTIP5
  txt  = ""
  txt += "Source Path\t: %s\n" % FFxKI9(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFxKI9(self.VVB4IN, VVSfxg)
  if self.VV69Fa : txt += "Package File\t: %s\n" % FFxKI9(self.VV69Fa, VVIgRq)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFxKI9("Check Control File fields : %s" % errTxt, VVxd7c)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFxKI9("Restart GUI", VV8tYH)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFxKI9("Reboot Device", VV8tYH)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFxKI9("Post Install", VV3SOs), act)
  if not errTxt and VVxd7c in controlInfo:
   txt += "Warning\t: %s\n" % FFxKI9("Errors in control file may affect the result package.", VVxd7c)
  txt += "\nControl File\t: %s\n" % FFxKI9(self.controlFile, VVIgRq)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVcBF5(self):
  VVSAYi = []
  VVSAYi.append(("No Action"    , "noAction"  ))
  VVSAYi.append(("Restart GUI"    , "VV5FhL"  ))
  VVSAYi.append(("Reboot Device"   , "rebootDev"  ))
  FF3fIR(self, self.VVy5d9, title="Package Installation Option (after completing installation)", VVSAYi=VVSAYi)
 def VVy5d9(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VV5FhL"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVOWyD(False)
   self.VVPEtt()
 def VVQpUe(self):
  rootPath = FFxKI9("/%s/" % self.VV5PI2, VVpXnW)
  VVSAYi = []
  VVSAYi.append(("Current Path"        , "toCurrent"  ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Extension Path"       , "toExtensions" ))
  VVSAYi.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVSAYi.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FF3fIR(self, self.VVuHI9, title="Installation Path", VVSAYi=VVSAYi)
 def VVuHI9(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVMzuy(FFqLVd(self.Path, True))
   elif item == "toExtensions"  : self.VVMzuy(VV1Enj)
   elif item == "toSystemPlugins" : self.VVMzuy(VVuisN)
   elif item == "toRootPath"  : self.VVMzuy("/")
   elif item == "toRoot"   : self.VVMzuy("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVTo2s, boundFunction(CCQ7If, mode=CCQ7If.VVevyr, VVBz5n=VVVPVZ))
 def VVTo2s(self, path):
  if len(path) > 0:
   self.VVMzuy(path)
 def VVMzuy(self, parent, withPackageName=True):
  if withPackageName : self.VVB4IN = parent + self.VV5PI2 + "/"
  else    : self.VVB4IN = "/"
  mode = self.VVYpL7()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVzjLK(mode), self.controlFile))
  self.VVPEtt()
 def VVBB8c(self):
  if fileExists(self.controlFile):
   lines = FF66GF(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFMKq2(self, self.VVYlNv, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFv5WO(self, "Version not found or incorrectly set !")
  else:
   FF7BRF(self, self.controlFile)
 def VVYlNv(self, VVCC3L):
  if VVCC3L:
   version, color = self.VVT03t(VVCC3L, False)
   if color == VV9YfT:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVCC3L, self.controlFile))
    self.VVPEtt()
   else:
    FFv5WO(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVQiTU(self):
  if self.newControlPath:
   if self.VV1fKo:
    self.VVlYAG()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFxKI9(self.newControlPath, VVIgRq)
    txt += FFxKI9("Do you want to keep these files ?", VVSfxg)
    FFhdnr(self, self.close, txt, callBack_No=self.VVlYAG, title="Create Package", VVD4Yr=True)
  else:
   self.close()
 def VVlYAG(self):
  os.system(FFMugq("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVzjLK(self, mode):
  if   mode == self.VVuHU5 : prefix = self.VVL69Y
  elif mode == self.VV97eR : prefix = self.VVMOQ8
  else        : prefix = self.VVM80J
  return prefix + "-" + self.VVgbAa
 def VVYpL7(self):
  if   self.VVB4IN.startswith(VV1Enj) : return self.VVuHU5
  elif self.VVB4IN.startswith(VVuisN) : return self.VV97eR
  else            : return self.VVPagk
 def VVOWyD(self, isFirstTime):
  self.VV5PI2   = os.path.basename(os.path.normpath(self.Path))
  self.VV5PI2   = "_".join(self.VV5PI2.split())
  self.VVgbAa = self.VV5PI2.lower()
  self.VV1fKo = self.VVgbAa == VVMQqB.lower()
  if self.VV1fKo and self.VVgbAa.endswith("ajpan"):
   self.VVgbAa += "el"
  if self.VV1fKo : self.VV9YJp = VVVPVZ
  else    : self.VV9YJp = CFG.packageOutputPath.getValue()
  self.VV9YJp = FFhBEj(self.VV9YJp)
  if not pathExists(self.controlPath):
   os.system(FFMugq("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VV1fKo : t = PLUGIN_NAME
  else    : t = self.VV5PI2
  self.VV2aKs(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVDCEs.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VV1fKo : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VV2aKs(self.postrmFile, txt)
  if self.VV1fKo:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVwyo7)
   self.VV2aKs(self.preinstFile, txt)
  else:
   self.VV2aKs(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VV5PI2)
  mode = self.VVYpL7()
  if isFirstTime and not mode == self.VVPagk:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVjUYT
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VV2aKs(self.postinstFile, txt, VVNzPk=True)
  os.system(FFMugq("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VV1fKo : version, descripton, maintainer = VVwyo7 , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VV5PI2 , self.VV5PI2
   txt = ""
   txt += "Package: %s\n"  % self.VVzjLK(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VV2aKs(self, path, lines, VVNzPk=False):
  if not fileExists(path) or VVNzPk:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVmT1B(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FF66GF(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFxKI9(line, VVxd7c)
     elif not line.startswith(" ")    : line = FFxKI9(line, VVxd7c)
     else          : line = FFxKI9(line, VV9YfT)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VV9YfT
   else   : color = VVxd7c
   descr = FFxKI9(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVxd7c
     elif line.startswith((" ", "\t")) : color = VVxd7c
     elif line.startswith("#")   : color = VVIgRq
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVT03t(val, True)
      elif key == "Version"  : version, color = self.VVT03t(val, False)
      elif key == "Maintainer" : maint  , color = val, VV9YfT
      elif key == "Architecture" : arch  , color = val, VV9YfT
      else:
       color = VV9YfT
      if not key == "OE" and not key.istitle():
       color = VVxd7c
     else:
      color = VV8tYH
     txt += FFxKI9(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VV69Fa = self.VV9YJp + packageName
   self.VVKo0v = True
   errTxt = ""
  else:
   self.VV69Fa  = ""
   self.VVKo0v = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVT03t(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VV9YfT
  else          : return val, VVxd7c
 def VViyvz(self):
  if not self.VVKo0v:
   FFv5WO(self, "Please fix Control File errors first.")
   return
  if self.VVLjgp: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFqLVd(self.VVB4IN, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VV5PI2
  symlinkTo  = FFm91m(self.Path)
  dataDir   = self.VVB4IN.rstrip("/")
  removePorjDir = FFMugq("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFMugq("rm -f '%s'" % self.VV69Fa) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFpwIl()
  if self.VVLjgp:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFS6QL("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VV1fKo:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVB4IN == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVEL0A)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VV69Fa, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VV69Fa
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VV69Fa, FFA6Lm(result  , VV3SOs))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVB4IN, FFA6Lm(instPath, VV9YfT))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFA6Lm(failed, VVxd7c))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFl3Il(self, cmd)
class CCQ7If(Screen):
 VVYMxF   = 0
 VVevyr  = 1
 VVACh0 = 20
 VVfbVU  = None
 def __init__(self, session, VVBz5n="/", mode=VVYMxF, VVl3AH="Select", VVp74Q=30, gotoMovie=False):
  self.skin, self.skinParam = FFrBKf(VV1H0A, 1400, 920, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FF4zOZ(self)
  FF313P(self["keyRed"] , "Exit")
  FF313P(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVl3AH = VVl3AH
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  CCQ7If.VVfbVU = self
  if   self.gotoMovie        : VVkE6c, self.VVBz5n = True , CCQ7If.VVMlYP(self)[1] or "/"
  elif self.mode == self.VVYMxF  : VVkE6c, self.VVBz5n = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVevyr : VVkE6c, self.VVBz5n = False, VVBz5n
  else           : VVkE6c, self.VVBz5n = True , VVBz5n
  self.VVBz5n = FFhBEj(self.VVBz5n)
  self["myMenu"] = CC1Tcm(  directory   = "/"
         , VVkE6c   = VVkE6c
         , VVHmUc = True
         , VV0gKj   = self.skinParam["width"]
         , VVp74Q   = self.skinParam["bodyFontSize"]
         , VVLeZ7  = self.skinParam["bodyLineH"]
         , VVkVry  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVjzC3      ,
   "red"    : self.VVsQ7o     ,
   "green"    : self.VVv05k    ,
   "yellow"   : self.VVkh7w   ,
   "blue"    : self.VVsorB   ,
   "menu"    : self.VVT43I    ,
   "info"    : self.VVSsTn    ,
   "cancel"   : self.VVq67S     ,
   "pageUp"   : self.VVq67S     ,
   "chanUp"   : self.VVq67S
  }, -1)
  FFfgo9(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VV9k3c)
 def onExit(self):
  CCQ7If.VVfbVU = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VV9k3c)
  FFoZqi(self)
  FF5gi1(self["myMenu"], bg="#06003333")
  FFZe3q(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode == self.VVevyr:
   FF313P(self["keyGreen"], self.VVl3AH)
   color = "#22000022"
   FFv4ZZ(self["myBody"], color)
   FFv4ZZ(self["myMenu"], color)
   color = "#22220000"
   FFv4ZZ(self["myTitle"], color)
   FFv4ZZ(self["myBar"], color)
  self.VV9k3c()
  if self.VVJxde(self.VVBz5n) > self.bigDirSize:
   FFlFRp(self, "Changing directory...")
   FFYJiO(self.VVVmGr)
  else:
   self.VVVmGr()
 def VVVmGr(self):
  self["myMenu"].VVcrmY(self.VVBz5n)
  if self.gotoMovie:
   self.VVfKWt(chDir=False)
 def VVdPXQ(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVTHYQ(self):
  self["myMenu"].refresh()
  FF13j6()
 def VVJxde(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VVjzC3(self):
  if self["myMenu"].VVusBL():
   path = self.VVZw27(self.VVMsOj())
   if self.VVJxde(path) > self.bigDirSize:
    FFlFRp(self, "Changing directory...")
    FFYJiO(self.VV2xxi)
   else:
    self.VV2xxi()
  else:
   self.VVPwFu()
 def VV2xxi(self):
  self["myMenu"].descent()
  self.VV9k3c()
 def VVq67S(self):
  if self["myMenu"].VVopHq():
   self["myMenu"].moveToIndex(0)
   self.VV2xxi()
 def VVsQ7o(self):
  if not FF60YR(self):
   self.close("")
 def VVv05k(self):
  if self.mode == self.VVevyr:
   path = self.VVZw27(self.VVMsOj())
   self.close(path)
 def VVSsTn(self):
  FF8MfV(self, self.VVD9YA, title="Calculating size ...")
 def VVD9YA(self):
  path = self.VVZw27(self.VVMsOj())
  param = self.VVrrkj(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFw9Nl("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCQ7If.VVxQId(path)
     freeSize = CCQ7If.VVs88J(path)
     size = totSize - freeSize
     totSize  = CCQ7If.VVmZaL(totSize)
     freeSize = CCQ7If.VVmZaL(freeSize)
    else:
     size = FFw9Nl("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CCQ7If.VVmZaL(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFxKI9(pathTxt, VV8tYH) + "\n"
   if slBroken : fileTime = self.VVC7bl(path)
   else  : fileTime = self.VVIwP2(path)
   def VVJsq5(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVJsq5("Path"    , pathTxt)
   txt += VVJsq5("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVJsq5("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVJsq5("Total Size"   , "%s" % totSize)
    txt += VVJsq5("Used Size"   , "%s" % usedSize)
    txt += VVJsq5("Free Size"   , "%s" % freeSize)
   else:
    txt += VVJsq5("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVJsq5("Owner"    , owner)
   txt += VVJsq5("Group"    , group)
   txt += VVJsq5("Perm. (User)"  , permUser)
   txt += VVJsq5("Perm. (Group)"  , permGroup)
   txt += VVJsq5("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVJsq5("Perm. (Ext.)" , permExtra)
   txt += VVJsq5("iNode"    , iNode)
   txt += VVJsq5("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVjUYT, VVjUYT)
    txt += hLinkedFiles
   txt += self.VVQygI(path)
  else:
   FFv5WO(self, "Cannot access information !")
  if len(txt) > 0:
   FFGdNj(self, txt)
 def VVrrkj(self, path):
  path = path.strip()
  path = FFm91m(path)
  result = FFw9Nl("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVShUK(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVShUK(perm, 1, 4)
   permGroup = VVShUK(perm, 4, 7)
   permOther = VVShUK(perm, 7, 10)
   permExtra = VVShUK(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFhEkf("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVQygI(self, path):
  txt  = ""
  res  = FFw9Nl("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFxKI9("File Attributes:", VVZ7zN), txt)
  return txt
 def VVIwP2(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFt8n3(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFt8n3(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFt8n3(os.path.getctime(path))
  return txt
 def VVC7bl(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFw9Nl("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFw9Nl("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFw9Nl("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVZw27(self, currentSel):
  currentDir  = self["myMenu"].VVopHq()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVusBL():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVMsOj(self):
  return self["myMenu"].getSelection()[0]
 def VV9k3c(self):
  FFlFRp(self)
  path = self.VVZw27(self.VVMsOj())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VV06zW = self.VV8vq5()
  if VV06zW and len(VV06zW) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VVo3lR(path)
  if self.mode == self.VVYMxF and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
 def VVo3lR(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VViCUu(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVT43I(self):
  if self.mode == self.VVYMxF:
   path  = self.VVZw27(self.VVMsOj())
   isDir  = os.path.isdir(path)
   VVSAYi = []
   VVSAYi.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVfsPi(path):
     sepShown = True
     VVSAYi.append(VVudpG)
     VVSAYi.append( (VV8tYH + "Archiving / Packaging"      , "VVXqr8"  ))
    if self.VVVXwZ(path):
     if not sepShown:
      VVSAYi.append(VVudpG)
     VVSAYi.append( (VV8tYH + "Read Backup information"     , "VVFfYU"  ))
     VVSAYi.append( (VV8tYH + "Compress Octagon Image (to zip File)"  , "VVC99A" ))
   elif os.path.isfile(path):
    selFile = self.VVMsOj()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar")) : VVSAYi.extend(self.VVBCSo(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVSAYi.extend(self.VV8hkt(True))
    elif selFile.endswith(".m3u")              : VVSAYi.extend(self.VVKAQy(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FFNvpA(path):
     VVSAYi.append(VVudpG)
     VVSAYi.append((VV8tYH + "View" , "text_View" ))
     VVSAYi.append((VV8tYH + "Edit" , "text_Edit" ))
    if len(txt) > 0:
     VVSAYi.append(VVudpG)
     VVSAYi.append(   (VV8tYH + txt      , "VVPwFu"  ))
   VVSAYi.append(VVudpG)
   VVSAYi.append(     ("Create SymLink"       , "VV3hPS" ))
   if not self.VVfsPi(path):
    VVSAYi.append(   ("Rename"          , "VVaFiL" ))
    VVSAYi.append(   ("Copy"           , "copyFileOrDir" ))
    VVSAYi.append(   ("Move"           , "moveFileOrDir" ))
    VVSAYi.append(   ("DELETE"          , "VVdLpf" ))
    if fileExists(path):
     VVSAYi.append(VVudpG)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVSAYi.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVSAYi.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVSAYi.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVSAYi.append(VVudpG)
   VVSAYi.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVSAYi.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCQ7If.VVMlYP(self)
   if fPath:
    VVSAYi.append(VVudpG)
    VVSAYi.append(   (VVSfxg + "Go to current movie"  , "VVfKWt"))
   VVSAYi.append(VVudpG)
   VVSAYi.append(    ("Set current directory as \"Startup Path\"" , "VVycMi" ))
   FF3fIR(self, self.VVLbgN, title="Options", VVSAYi=VVSAYi)
 def VVLbgN(self, item=None):
  if self.mode == self.VVYMxF:
   if item is not None:
    path = self.VVZw27(self.VVMsOj())
    selFile = self.VVMsOj()
    if   item == "properties"    : self.VVSsTn()
    elif item == "VVXqr8"  : self.VVXqr8(path)
    elif item == "VVFfYU"  : self.VVFfYU(path)
    elif item == "VVC99A" : self.VVC99A(path)
    elif item.startswith("extract_")  : self.VVMr3w(path, selFile, item)
    elif item.startswith("script_")   : self.VV1xfj(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVJT5RItem_m3u(path, selFile, item)
    elif item.startswith("text_View")  : FFJRme(self, path)
    elif item.startswith("text_Edit")  : CCVYVr(self, path)
    elif item == "chmod644"     : self.VVb7mm(path, selFile, "644")
    elif item == "chmod755"     : self.VVb7mm(path, selFile, "755")
    elif item == "chmod777"     : self.VVb7mm(path, selFile, "777")
    elif item == "VV3hPS"   : self.VV3hPS(path, selFile)
    elif item == "VVaFiL"   : self.VVaFiL(path, selFile)
    elif item == "copyFileOrDir"   : self.VVHP9T(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVHP9T(path, selFile, True)
    elif item == "VVdLpf"   : self.VVdLpf(path, selFile)
    elif item == "createNewFile"   : self.VVu7DV(path, True)
    elif item == "createNewDir"    : self.VVu7DV(path, False)
    elif item == "VVfKWt"   : self.VVfKWt()
    elif item == "VVycMi"   : self.VVycMi(path)
    elif item == "VVPwFu"    : self.VVPwFu()
    else         : self.close()
 def VVPwFu(self):
  selFile = self.VVMsOj()
  path  = self.VVZw27(selFile)
  if os.path.isfile(path):
   VVgPsE = []
   category = self["myMenu"].VVvKtC(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVZ1lX(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FF7GAb(self, selFile, path)
   elif category == "txt"         : FFJRme(self, path)
   elif category in ("tar", "zip", "rar")     : self.VVbHEk(path, selFile)
   elif category == "scr"         : self.VVEL3J(path, selFile)
   elif category == "m3u"         : self.VVNiGR(path, selFile)
   elif category in ("ipk", "deb")       : self.VV2mVp(path, selFile)
   elif category == "mus"         : self.VVQHnP(self, path)
   elif category == "mov"         : self.VVQHnP(self, path)
   elif not FFNvpA(path)        : FFJRme(self, path)
 def VVkh7w(self):
  path = self.VVZw27(self.VVMsOj())
  action = self.VVo3lR(path)
  if action == 1:
   self.VVBFyf(path)
   FFlFRp(self, "Added", 500)
  elif action == -1:
   self.VVwlsa(path)
   FFlFRp(self, "Removed", 500)
  self.VVo3lR(path)
 def VVBFyf(self, path):
  VV06zW = self.VV8vq5()
  if not VV06zW:
   VV06zW = []
  if len(VV06zW) >= self.VVACh0:
   FFv5WO(SELF, "Max bookmarks reached (max=%d)." % self.VVACh0)
  elif not path in VV06zW:
   VV06zW = [path] + VV06zW
   self.VVvIYt(VV06zW)
 def VVsorB(self):
  VV06zW = self.VV8vq5()
  if VV06zW:
   newList = []
   for line in VV06zW:
    newList.append((line, line))
   VV9Wtd  = ("Delete"  , self.VVWEqO )
   VVEbC5 = ("Move Up"   , self.VVbo43 )
   VVJtpI  = ("Move Down" , self.VVVCmc )
   self.bookmarkMenu = FF3fIR(self, self.VVW2Un, title="Bookmarks", VVSAYi=newList, VV9Wtd=VV9Wtd, VVEbC5=VVEbC5, VVJtpI=VVJtpI)
 def VVWEqO(self, VVMsOjObj, path):
  if self.bookmarkMenu:
   VV06zW = self.VVwlsa(path)
   self.bookmarkMenu.VVBKQY(VV06zW)
 def VVbo43(self, VVMsOjObj, path):
  if self.bookmarkMenu:
   VV06zW = self.bookmarkMenu.VVklMb(True)
   if VV06zW:
    self.VVvIYt(VV06zW)
 def VVVCmc(self, VVMsOjObj, path):
  if self.bookmarkMenu:
   VV06zW = self.bookmarkMenu.VVklMb(False)
   if VV06zW:
    self.VVvIYt(VV06zW)
 def VVW2Un(self, folder=None):
  if folder:
   folder = FFhBEj(folder)
   self["myMenu"].VVcrmY(folder)
   self["myMenu"].moveToIndex(0)
  self.VV9k3c()
 def VV8vq5(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VViCUu(self, path):
  VV06zW = self.VV8vq5()
  if VV06zW and path in VV06zW:
   return True
  else:
   return False
 def VVG7qQ(self):
  if VV8vq5():
   return True
  else:
   return False
 def VVvIYt(self, VV06zW):
  line = ",".join(VV06zW)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVwlsa(self, path):
  VV06zW = self.VV8vq5()
  if VV06zW:
   while path in VV06zW:
    VV06zW.remove(path)
   self.VVvIYt(VV06zW)
   return VV06zW
 def VVfKWt(self, chDir=True):
  fPath, fDir, fName = CCQ7If.VVMlYP(self)
  if fPath:
   if chDir:
    self["myMenu"].VVcrmY(fDir)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFlFRp(self, "Not found", 1000)
 def VVycMi(self, path):
  if not os.path.isdir(path):
   path = FFqLVd(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVZ1lX(self, selFile, VVlC3v, command):
  FFhdnr(self, boundFunction(FFl3Il, self, command, VVhQIf=self.VVTHYQ), "%s\n\n%s" % (VVlC3v, selFile))
 def VVBCSo(self, path, calledFromMenu):
  destPath = self.VVfQT5(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVSAYi = []
  if calledFromMenu:
   VVSAYi.append(VVudpG)
   color = VV8tYH
  else:
   color = ""
  VVSAYi.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVSAYi.append(VVudpG)
  VVSAYi.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVSAYi.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVSAYi.append((color + "Extract Here"            , "extract_here"  ))
  if VVU5WU and path.endswith(".tar.gz"):
   VVSAYi.append(VVudpG)
   VVSAYi.append((color + 'Convert to ".ipk" Package' , "VVKvG6"  ))
   VVSAYi.append((color + 'Convert to ".deb" Package' , "VVYob6"  ))
  return VVSAYi
 def VVbHEk(self, path, selFile):
  FF3fIR(self, boundFunction(self.VVMr3w, path, selFile), title="Compressed File Options", VVSAYi=self.VVBCSo(path, False))
 def VVMr3w(self, path, selFile, item=None):
  if item is not None:
   parent  = FFqLVd(path, False)
   destPath = self.VVfQT5(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVjUYT
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFS6QL("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFS6QL("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVjUYT, VVjUYT)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFRgi8(self, cmd)
   elif path.endswith(".zip"):
    self.VV6vOz(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif path.endswith(".rar"):
    self.VVu3sE(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFMugq("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVZ1lX(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVZ1lX(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFqLVd(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVZ1lX(selFile, "Extract Here ?"      , cmd)
   elif item == "VVKvG6" : self.VVKvG6(path)
   elif item == "VVYob6" : self.VVYob6(path)
 def VVfQT5(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VV6vOz(self, item, path, parent, destPath, VVlC3v):
  FFhdnr(self, boundFunction(self.VVIdq3, item, path, parent, destPath), VVlC3v)
 def VVIdq3(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVjUYT
  cmd  = FFS6QL("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFA6Lm(destPath, VV3SOs))
  cmd +=   sep
  cmd += "fi;"
  FFsHJ2(self, cmd, VVhQIf=self.VVTHYQ)
 def VVu3sE(self, item, path, parent, destPath, VVlC3v):
  FFhdnr(self, boundFunction(self.VVvTIn, item, path, parent, destPath), VVlC3v)
 def VVvTIn(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFhBEj(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVjUYT
  cmd  = FFS6QL("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFA6Lm(destPath, VV3SOs))
  cmd +=   sep
  cmd += "fi;"
  FFsHJ2(self, cmd, VVhQIf=self.VVTHYQ)
 def VV8hkt(self, addSep=False):
  VVSAYi = []
  if addSep:
   VVSAYi.append(VVudpG)
  VVSAYi.append((VV8tYH + "View Script File"  , "script_View"  ))
  VVSAYi.append((VV8tYH + "Execute Script File" , "script_Execute" ))
  VVSAYi.append((VV8tYH + "Edit"     , "script_Edit" ))
  return VVSAYi
 def VVEL3J(self, path, selFile):
  FF3fIR(self, boundFunction(self.VV1xfj, path, selFile), title="Script File Options", VVSAYi=self.VV8hkt())
 def VV1xfj(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFJRme(self, path)
   elif item == "script_Execute" : self.VVZ1lX(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCVYVr(self, path)
 def VVKAQy(self, addSep=False):
  VVSAYi = []
  if addSep:
   VVSAYi.append(VVudpG)
  VVSAYi.append((VV8tYH + "Browse IPTV Channels"  , "m3u_Browse" ))
  VVSAYi.append((VV8tYH + "Edit"      , "m3u_Edit" ))
  VVSAYi.append((VV8tYH + "View"      , "m3u_View" ))
  return VVSAYi
 def VVNiGR(self, path, selFile):
  FF3fIR(self, boundFunction(self.VVJT5RItem_m3u, path, selFile), title="M3U/M3U8 File Options", VVSAYi=self.VVKAQy())
 def VVJT5RItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FF8MfV(self, boundFunction(self.session.open, CCkpQY, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCVYVr(self, path)
   elif item == "m3u_View"  : FFJRme(self, path)
 def VVb7mm(self, path, selFile, newChmod):
  FFhdnr(self, boundFunction(self.VVA9uC, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVA9uC(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVyW8b)
  result = FFw9Nl(cmd)
  if result == "Successful" : FFLnSq(self, result)
  else      : FFv5WO(self, result)
 def VV3hPS(self, path, selFile):
  parent = FFqLVd(path, False)
  self.session.openWithCallback(self.VVM6bv, boundFunction(CCQ7If, mode=CCQ7If.VVevyr, VVBz5n=parent, VVl3AH="Create Symlink here"))
 def VVM6bv(self, newPath):
  if len(newPath) > 0:
   target = self.VVZw27(self.VVMsOj())
   target = FFm91m(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFhBEj(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFv5WO(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFhdnr(self, boundFunction(self.VVohw0, target, link), "Create Soft Link ?\n\n%s" % txt, VVD4Yr=True)
 def VVohw0(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVyW8b)
  result = FFw9Nl(cmd)
  if result == "Successful" : FFLnSq(self, result)
  else      : FFv5WO(self, result)
 def VVaFiL(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFMKq2(self, boundFunction(self.VVRPp6, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVRPp6(self, path, selFile, VVCC3L):
  if VVCC3L:
   parent = FFqLVd(path, True)
   if os.path.isdir(path):
    path = FFm91m(path)
   newName = parent + VVCC3L
   cmd = "mv '%s' '%s' %s" % (path, newName, VVyW8b)
   if VVCC3L:
    if selFile != VVCC3L:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFhdnr(self, boundFunction(self.VVReMR, cmd), message, title="Rename file?")
    else:
     FFv5WO(self, "Cannot use same name!", title="Rename")
 def VVReMR(self, cmd):
  result = FFw9Nl(cmd)
  if "Fail" in result:
   FFv5WO(self, result)
  self.VVTHYQ()
 def VVHP9T(self, path, selFile, isMove):
  if isMove : VVl3AH = "Move to here"
  else  : VVl3AH = "Copy to here"
  parent = FFqLVd(path, False)
  self.session.openWithCallback(boundFunction(self.VVUTRX, isMove, path, selFile)
         , boundFunction(CCQ7If, mode=CCQ7If.VVevyr, VVBz5n=parent, VVl3AH=VVl3AH))
 def VVUTRX(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFm91m(path)
   newPath = FFhBEj(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFhdnr(self, boundFunction(FFkZIr, self, cmd, VVhQIf=self.VVTHYQ), txt, VVD4Yr=True)
   else:
    FFv5WO(self, "Cannot %s to same directory !" % action.lower())
 def VVdLpf(self, path, fileName):
  path = FFm91m(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFhdnr(self, boundFunction(self.VVKmfB, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVKmfB(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VVTHYQ()
 def VVfsPi(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VV8Rhz and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVu7DV(self, path, isFile):
  dirName = FFhBEj(os.path.dirname(path))
  if isFile : objName, VVCC3L = "File"  , self.edited_newFile
  else  : objName, VVCC3L = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFMKq2(self, boundFunction(self.VV59s1, dirName, isFile, title), title=title, defaultText=VVCC3L, message="Enter %s Name:" % objName)
 def VV59s1(self, dirName, isFile, title, VVCC3L):
  if VVCC3L:
   if isFile : self.edited_newFile = VVCC3L
   else  : self.edited_newDir  = VVCC3L
   path = dirName + VVCC3L
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVyW8b)
    else  : cmd = "mkdir '%s' %s" % (path, VVyW8b)
    result = FFw9Nl(cmd)
    if "Fail" in result:
     FFv5WO(self, result)
    self.VVTHYQ()
   else:
    FFv5WO(self, "Name already exists !\n\n%s" % path, title)
 def VV2mVp(self, path, selFile):
  VVSAYi = []
  VVSAYi.append(("List Package Files"          , "VVd5Go"     ))
  VVSAYi.append(("Package Information"          , "VVDxW8"     ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Install Package"           , "VV2MLH_CheckVersion" ))
  VVSAYi.append(("Install Package (force reinstall)"      , "VV2MLH_ForceReinstall" ))
  VVSAYi.append(("Install Package (force overwrite)"      , "VV2MLH_ForceOverwrite" ))
  VVSAYi.append(("Install Package (force downgrade)"      , "VV2MLH_ForceDowngrade" ))
  VVSAYi.append(("Install Package (ignore failed dependencies)"    , "VV2MLH_IgnoreDepends" ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Remove Related Package"         , "VVQqlB_ExistingPackage" ))
  VVSAYi.append(("Remove Related Package (force remove)"     , "VVQqlB_ForceRemove"  ))
  VVSAYi.append(("Remove Related Package (ignore failed dependencies)"  , "VVQqlB_IgnoreDepends" ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("Extract Files"           , "VVO4wA"     ))
  VVSAYi.append(("Unbuild Package"           , "VVR17L"     ))
  FF3fIR(self, boundFunction(self.VVnkK2, path, selFile), VVSAYi=VVSAYi)
 def VVnkK2(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVd5Go"      : self.VVd5Go(path, selFile)
   elif item == "VVDxW8"      : self.VVDxW8(path)
   elif item == "VV2MLH_CheckVersion"  : self.VV2MLH(path, selFile, VVaBvq     )
   elif item == "VV2MLH_ForceReinstall" : self.VV2MLH(path, selFile, VVi2Z7 )
   elif item == "VV2MLH_ForceOverwrite" : self.VV2MLH(path, selFile, VVWDTt )
   elif item == "VV2MLH_ForceDowngrade" : self.VV2MLH(path, selFile, VVPoBH )
   elif item == "VV2MLH_IgnoreDepends" : self.VV2MLH(path, selFile, VVmeGz )
   elif item == "VVQqlB_ExistingPackage" : self.VVQqlB(path, selFile, VVDFgV     )
   elif item == "VVQqlB_ForceRemove"  : self.VVQqlB(path, selFile, VVWHml  )
   elif item == "VVQqlB_IgnoreDepends"  : self.VVQqlB(path, selFile, VVN6V0 )
   elif item == "VVO4wA"     : self.VVO4wA(path, selFile)
   elif item == "VVR17L"     : self.VVR17L(path, selFile)
   else           : self.close()
 def VVd5Go(self, path, selFile):
  if FFtJ8E("ar") : cmd = "allOK='1';"
  else    : cmd  = FFpwIl()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVjUYT, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVjUYT, VVjUYT)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFar6j(self, cmd, VVhQIf=self.VVTHYQ)
 def VVO4wA(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFqLVd(path, True) + selFile[:-4]
  cmd  =  FFpwIl()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFMugq("mkdir '%s'" % dest) + ";"
  cmd +=    FFMugq("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFA6Lm(dest, VV3SOs))
  cmd += "fi;"
  FFl3Il(self, cmd, VVhQIf=self.VVTHYQ)
 def VVR17L(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVHoUo = os.path.splitext(path)[0]
  else        : VVHoUo = path + "_"
  if path.endswith(".deb")   : VVEL0A = "DEBIAN"
  else        : VVEL0A = "CONTROL"
  cmd  = FFpwIl()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVHoUo, FFgrHS())
  cmd += "  mkdir '%s';"    % VVHoUo
  cmd += "  CONTPATH='%s/%s';"  % (VVHoUo, VVEL0A)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVHoUo
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVHoUo, VVHoUo)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVHoUo
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVHoUo, VVHoUo)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVHoUo
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVHoUo
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVHoUo, FFA6Lm(VVHoUo, VV3SOs))
  cmd += "fi;"
  FFl3Il(self, cmd, VVhQIf=self.VVTHYQ)
 def VVDxW8(self, path):
  listCmd  = FFyxGo(VVTn9i, "")
  infoCmd  = FFyov6(VVRoHT , "")
  filesCmd = FFyov6(VVHM4T, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFMEmL(VVSfxg)
   notInst = "Package not installed."
   cmd  = FF5oB0("File Info", VVSfxg)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FF5oB0("System Info", VVSfxg)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFA6Lm(notInst, VV8tYH))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FF5oB0("Related Files", VVSfxg)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFRgi8(self, cmd)
  else:
   FFXixL(self)
 def VV2MLH(self, path, selFile, cmdOpt):
  cmd = FFyov6(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFhdnr(self, boundFunction(FFl3Il, self, cmd, VVhQIf=FF13j6), "Install Package ?\n\n%s" % selFile)
  else:
   FFXixL(self)
 def VVQqlB(self, path, selFile, cmdOpt):
  listCmd  = FFyxGo(VVTn9i, "")
  infoCmd  = FFyov6(VVRoHT, "")
  instRemCmd = FFyov6(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFA6Lm(errTxt, VV8tYH))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFA6Lm(cannotTxt, VV8tYH))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFA6Lm(tryTxt, VV8tYH))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFhdnr(self, boundFunction(FFl3Il, self, cmd, VVhQIf=FF13j6), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFXixL(self)
 def VVQujd(self, path):
  hostName = FFw9Nl("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVVXwZ(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVQujd(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVXqr8(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVSAYi = []
  VVSAYi.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVSAYi.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVSAYi.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVSAYi.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVSAYi.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVSAYi.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVSAYi.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVSAYi.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVSAYi.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVSAYi.append(VVudpG)
  VVSAYi.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVSAYi.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FF3fIR(self, boundFunction(self.VVVv3m, path), VVSAYi=VVSAYi)
 def VVVv3m(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVegQ3(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVegQ3(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVegQ3(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVegQ3(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVegQ3(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVegQ3(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVegQ3(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVegQ3(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVegQ3(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVegQ3(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VV8ELS(path, False)
   elif item == "convertDirToDeb"   : self.VV8ELS(path, True)
   else         : self.close()
 def VV8ELS(self, path, VVLjgp):
  self.session.openWithCallback(self.VVTHYQ, boundFunction(CCiCs1, path=path, VVLjgp=VVLjgp))
 def VVegQ3(self, path, fileExt, preserveDirStruct):
  parent  = FFqLVd(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFS6QL("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFS6QL("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFS6QL("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVjUYT
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFMugq("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FFA6Lm(resultFile, VV3SOs))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FFA6Lm(failed, VVxd7c))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFar6j(self, cmd, VVhQIf=self.VVTHYQ)
 def VVFfYU(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFJRme(self, versionFile)
 def VVC99A(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVQujd(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFv5WO(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FF66GF(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFqLVd(path, False)
  VVHoUo = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FFA6Lm(errCmd, VVxd7c))
  installCmd = FFyov6(VVaBvq , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVHoUo, VVHoUo)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVHoUo
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVHoUo
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVHoUo, VVHoUo)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFl3Il(self, cmd, VVhQIf=self.VVTHYQ)
 def VVKvG6(self, path):
  FFv5WO(self, "Under Construction.")
 def VVYob6(self, path):
  FFv5WO(self, "Under Construction.")
 @staticmethod
 def VVQHnP(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   SELF.session.open(CCewzF, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVMlYP(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFhBEj(fDir), fName
  return "", "", ""
 @staticmethod
 def VVxQId(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVs88J(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVmZaL(size, mode=0):
  txt = CCQ7If.VVFucf(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVFucf(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
class CC1Tcm(MenuList):
 def __init__(self, VVHmUc=False, directory="/", VVe9Ak=True, VVkE6c=True, VVc6PI=True, VVyPAK=None, VVBRBr=False, VVZk5o=False, VVkm5z=False, isTop=False, VV1VSU=None, VV0gKj=1000, VVp74Q=30, VVLeZ7=30, VVkVry="#00000000"):
  MenuList.__init__(self, list, VVHmUc, eListboxPythonMultiContent)
  self.VVe9Ak  = VVe9Ak
  self.VVkE6c    = VVkE6c
  self.VVc6PI  = VVc6PI
  self.VVyPAK  = VVyPAK
  self.VVBRBr   = VVBRBr
  self.VVZk5o   = VVZk5o or []
  self.VVkm5z   = VVkm5z or []
  self.isTop     = isTop
  self.additional_extensions = VV1VSU
  self.VV0gKj    = VV0gKj
  self.VVp74Q    = VVp74Q
  self.VVLeZ7    = VVLeZ7
  self.pngBGColor    = FFX7ku(VVkVry)
  self.EXTENSIONS    = self.VVFPlm()
  self.VVBcIx   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVVLsX, self.VVp74Q))
  self.l.setItemHeight(self.VVLeZ7)
  self.png_mem   = self.VVSGRt("mem")
  self.png_usb   = self.VVSGRt("usb")
  self.png_fil   = self.VVSGRt("fil")
  self.png_dir   = self.VVSGRt("dir")
  self.png_dirup   = self.VVSGRt("dirup")
  self.png_srv   = self.VVSGRt("srv")
  self.png_slwfil   = self.VVSGRt("slwfil")
  self.png_slbfil   = self.VVSGRt("slbfil")
  self.png_slwdir   = self.VVSGRt("slwdir")
  self.VVeBcA()
  self.VVcrmY(directory)
 def VVSGRt(self, category):
  return LoadPixmap("%s%s.png" % (VVrF44, category), getDesktop(0))
 def VVFPlm(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "rar" : "rar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u" ,
   "m3u8" : "m3u"
  }
 def VVG6mr(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFm91m(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFxKI9(" -> " , VVSfxg) + FFxKI9(os.readlink(path), VV3SOs)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVLeZ7 + 10, 0, self.VV0gKj, self.VVLeZ7, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVkxLj: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVLeZ7-4, self.VVLeZ7-4, png, self.pngBGColor, self.pngBGColor, VVkxLj))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVLeZ7-4, self.VVLeZ7-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVvKtC(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVeBcA(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVRPBp(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVy2se(self, file):
  if os.path.realpath(file) == file:
   return self.VVRPBp(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVRPBp(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVRPBp(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVObZa(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVBcIx.info(l[0][0]).getEvent(l[0][0])
 def VVxZko(self):
  return self.list
 def VVdnTT(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVcrmY(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVc6PI:
    self.current_mountpoint = self.VVy2se(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVc6PI:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVkm5z and not self.VVdnTT(path, self.VVZk5o):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVG6mr(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVBRBr:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVBcIx = eServiceCenter.getInstance()
   list = VVBcIx.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVe9Ak and not self.isTop:
   if directory == self.current_mountpoint and self.VVc6PI:
    self.list.append(self.VVG6mr(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVkm5z and self.VVRPBp(directory) in self.VVkm5z):
    self.list.append(self.VVG6mr(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVe9Ak:
   for x in directories:
    if not (self.VVkm5z and self.VVRPBp(x) in self.VVkm5z) and not self.VVdnTT(x, self.VVZk5o):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVG6mr(name = name, absolute = x, isDir = True, png = png))
  if self.VVkE6c:
   for x in files:
    if self.VVBRBr:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFxKI9(" -> " , VVSfxg) + FFxKI9(target, VV3SOs)
       else:
        png = self.png_slbfil
        name += FFxKI9(" -> " , VVSfxg) + FFxKI9(target, VVxd7c)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVvKtC(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVrF44, category))
    if (self.VVyPAK is None) or iCompile(self.VVyPAK).search(path):
     self.list.append(self.VVG6mr(name = name, absolute = x , isDir = False, png = png))
  if self.VVc6PI and len(self.list) == 0:
   self.list.append(self.VVG6mr(name = FFxKI9("No USB connected", VVIgRq), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVopHq(self):
  return self.current_directory
 def VVusBL(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVcrmY(self.getSelection()[0], select = self.current_directory)
 def VVpubw(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VV77kj(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVjZYD)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVjZYD)
 def refresh(self):
  self.VVcrmY(self.current_directory, self.VVpubw())
 def VVjZYD(self, action, device):
  self.VVeBcA()
  if self.current_directory is None:
   self.refresh()
class CCS98E(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFrBKf(VV26YX, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VV06zW   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVOKAC(defFG, "#00FFFFFF")
  self.defBG   = self.VVOKAC(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FF4zOZ(self, self.Title)
  self["keyRed"].show()
  FF313P(self["keyGreen"] , "< > Transp.")
  FF313P(self["keyYellow"], "Foreground")
  FF313P(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVQkEV        ,
   "yellow"   : boundFunction(self.VVi9I8, False)  ,
   "blue"   : boundFunction(self.VVi9I8, True)  ,
   "up"   : self.VVt0sY          ,
   "down"   : self.VVEn52         ,
   "left"   : self.VViad8         ,
   "right"   : self.VVepxi         ,
   "last"   : boundFunction(self.VVQVWY, -5) ,
   "next"   : boundFunction(self.VVQVWY, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVAJmk)
 def VVAJmk(self):
  self.onShown.remove(self.VVAJmk)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFv4ZZ(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFv4ZZ(self["keyRed"] , c)
  FFv4ZZ(self["keyGreen"] , c)
  self.VVeGmx()
  self.VVWuSN()
  FFxuhv(self["myColorTst"], self.defFG)
  FFv4ZZ(self["myColorTst"], self.defBG)
 def VVOKAC(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVWuSN(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVKwmI(0, 0)
     return
 def VVQkEV(self):
  self.close(self.defFG, self.defBG)
 def VVt0sY(self): self.VVKwmI(-1, 0)
 def VVEn52(self): self.VVKwmI(1, 0)
 def VViad8(self): self.VVKwmI(0, -1)
 def VVepxi(self): self.VVKwmI(0, 1)
 def VVKwmI(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VV755C()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVr7uw()
 def VVeGmx(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVr7uw(self):
  color = self.VV755C()
  if self.isBgMode: FFv4ZZ(self["myColorTst"], color)
  else   : FFxuhv(self["myColorTst"], color)
 def VVi9I8(self, isBg):
  self.isBgMode = isBg
  self.VVeGmx()
  self.VVWuSN()
 def VVQVWY(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVKwmI(0, 0)
 def VV7lQx(self):
  return hex(self.transp)[2:].zfill(2)
 def VV755C(self):
  return ("#%s%s" % (self.VV7lQx(), self.colors[self.curRow][self.curCol])).upper()
class CCvS8Y(ScrollLabel):
 def __init__(self, parentSELF, text="", VVfAf3=True):
  ScrollLabel.__init__(self, text)
  self.VVfAf3=VVfAf3
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVogAA  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVp74Q    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close   ,
   "cancel"  : parentSELF.close   ,
   "red"   : self.VV7Atm   ,
   "green"   : self.VVm7EK  ,
   "yellow"  : self.VVGKBU  ,
   "blue"   : self.VVM6J4  ,
   "up"   : self.pageUp    ,
   "down"   : self.pageDown    ,
   "left"   : self.pageUp    ,
   "right"   : self.pageDown    ,
   "pageUp"  : self.VVH1CK    ,
   "chanUp"  : self.VVH1CK    ,
   "pageDown"  : self.VV9Wik    ,
   "chanDown"  : self.VV9Wik
  }, -1)
 def VVC5L2(self, isResizable=True, VV1Ai8=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFZe3q(self.parentSELF, True)
  self.isResizable = isResizable
  if VV1Ai8:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVp74Q  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFv4ZZ(self, color)
 def FFv4ZZColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVogAA - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVFJkS()
 def pageUp(self):
  if self.VVogAA > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVogAA > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVH1CK(self):
  self.setPos(0)
 def VV9Wik(self):
  self.setPos(self.VVogAA-self.pageHeight)
 def VVVZba(self):
  return self.VVogAA <= self.pageHeight or self.curPos == self.VVogAA - self.pageHeight
 def VVFJkS(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVogAA, 3))
   start = int((100 - vis) * self.curPos / (self.VVogAA - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVTzbD=VVw7OV):
  old_VVVZba = self.VVVZba()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VVogAA = self.long_text.calculateSize().height()
   if self.VVfAf3 and self.VVogAA > self.pageHeight:
    self.scrollbar.show()
    self.VVFJkS()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVogAA))
   if   VVTzbD == VVoH3m: self.setPos(0)
   elif VVTzbD == VVCIY6 : self.VV9Wik()
   elif old_VVVZba    : self.VV9Wik()
 def appendText(self, text, VVTzbD=VVCIY6):
  self.setText(self.message + str(text), VVTzbD)
 def VVGKBU(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VV1LGF(size)
 def VVM6J4(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VV1LGF(size)
 def VVm7EK(self):
  self.VV1LGF(self.VVp74Q)
 def VV1LGF(self, VVp74Q):
  self.long_text.setFont(gFont(self.fontFamily, VVp74Q))
  self.setText(self.message, VVTzbD=VVw7OV)
  self.VVLOqo(calledFromFontSizer=True)
 def VV7Atm(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FFhBEj(expPath), self.textOutFile, FFS6oF())
    with open(outF, "w") as f:
     f.write(FFxdkh(self.message))
    FFLnSq(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FFv5WO(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVLOqo(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVogAA > 0 and self.pageHeight > 0:
   if self.VVogAA < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVogAA
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
