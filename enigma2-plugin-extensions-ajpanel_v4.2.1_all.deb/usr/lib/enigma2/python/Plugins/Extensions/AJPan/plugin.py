import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigInteger
from Components.config   import ConfigSubList
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVVxCA   = "v4.2.1"
VVzOUg    = "18-03-2022"
EASY_MODE    = 0
VVDWC2   = 0
VVf0A5   = 0
VVXgRS  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVqP7G  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVA6fc    = "/media/usb/"
VVcwd0    = "/usr/share/enigma2/picon/"
VVV3TR   = "/etc/enigma2/"
VVFOBg  = "ajpanel_update_url"
VVZO7B   = "AJPan"
VVDUxq    = "AUTO FIND"
VVakf1    = ""
VV9SQC    = "Regular"
VVyYSf      = "-" * 80
VV32Zp    = ("-" * 100, )
VVIzPF    = ""
VVNzYd   = " && echo 'Successful' || echo 'Failed!'"
VVogN0    = []
VVlBSU  = "Cannot continue (No Enough Memory) !"
VV29ZD   = (None, "utf-8", "ISO8859-15", "ISO8859-7", "ISO8859-5", "ISO6937", "windows-1250", "windows-1252", "unicode_escape")
VV6vw4  = False
VVsYt6  = False
VVodYT = False
VVbnJN     = 0
VVzdp7    = 1
VVgCbm    = 2
VVxeiM   = 3
VV8YT4    = 4
VVAObh    = 5
VVq7g2 = 6
VVYQha = 7
VVWc9r  = 8
VVv9qr   = 9
VVrFIk   = 10
VViV0B   = 11
VVmTzD  = 12
VVLePB  = 13
VVkGUL    = 14
VV070d   = 15
VVHtD3   = 16
VVkTZL    = 17
VVMzZT  = 18
VVDxIt  = 15
VVGsh0   = 0
VVY6j5   = 1
VVOCNl   = 2
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices = [ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices = [ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices = [ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices = [ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=False)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsPath    = ConfigDirectory(default=VVDUxq, visible_width=51)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=51)
CFG.PIconsPath     = ConfigDirectory(default=VVcwd0, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVA6fc, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
def FFklvV():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVtWZP  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVVIuH = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVtWZP  : return 0
  elif VVVIuH : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVVJdd = FFklvV()
VVLXD9 = VVKXn9 = VVMioC = VVGMgi = VVeWfa = VVeNUb = VVG7vV = VVyveI = COLOR_CONS_BRIGHT_YELLOW = VVNRRl = VVx5R4 = VV9edY = VVO6Kg = ""
def FFNFre()  : return FFRl9i()
def FF7xGZ(*args) : FFtemU(True , *args)
def FFG8ts(*args): FFtemU(False, *args)
def FFtemU(addSep=True, *args):
 if VVDWC2:
  txt  = (">>>> %s\n" % VVyYSf) if addSep else ""
  txt += ">>>> %s" % " , ".join(map(str, args))
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFL8aQ(txt, isAppend=True, ignoreErr=False):
 if VVDWC2:
  tm = FFHBjP()
  err = ""
  if not ignoreErr:
   err = FFRl9i()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FF7xGZ(err)
  FF7xGZ("Output Log File : %s" % fileName)
def FFRl9i():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFHBjP()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except Exception as e:
  return "Cannot Trace !"
def FFBsnF():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVogN0 = []
def FFYdRn(win):
 global VVogN0
 if not win in VVogN0:
  VVogN0.append(win)
def FFCjjG(*args):
 global VVogN0
 for win in VVogN0:
  try:
   win.close()
  except:
   pass
 VVogN0 = []
def FFcwVd():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVVenG = FFcwVd()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FF9vJF()     : return PluginDescriptor(fnc=FFSCAx, where=[PluginDescriptor.WHERE_SESSIONSTART] , needsRestart=True   , description="AJPanel Startup")
def FFaMjz()      : return getDescriptor(FFKmP1   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFowhq()       : return getDescriptor(FF8ZOf  , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFyd1c()   : return getDescriptor(FFwdhr , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFNpPD(): return getDescriptor(FFsO1I , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player"  , descr="Signal Monitor / Player")
def FFbDHa()  : return getDescriptor(FF5CZE  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV"     , descr="IPTV Menu")
def FFrmvE()     : return getDescriptor(FFMl3T , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info."    , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFaMjz() , FFowhq() , FF9vJF() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFyd1c())
  result.append(FFNpPD())
  result.append(FFbDHa())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFrmvE())
 return result
def FFSCAx(reason, **kwargs):
 if reason == 0:
  FF5Z3K()
  if "session" in kwargs:
   session = kwargs["session"]
   FFa7cy(session)
   CCHiBh(session)
def FF8ZOf(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFKmP1, PLUGIN_NAME, 45)]
 else:
  return []
def FFKmP1(session, **kwargs):
 session.open(Main_Menu)
def FFwdhr(session, **kwargs):
 session.open(CC5T3l)
def FFsO1I(session, **kwargs):
 FFwieQ(session, isFromSession=True)
def FF5CZE(session, **kwargs):
 session.open(CCdgmH)
def FFMl3T(session, **kwargs):
 session.open(CClBuf, fncMode=CClBuf.VVdrg2)
def FFiA6t():
 FF1Dsh(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFyd1c(), FFNpPD(), FFbDHa() ])
 FF1Dsh(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFrmvE() ])
def FF1Dsh(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VVDAsE = None
def FF5Z3K():
 try:
  global VVDAsE
  if VVDAsE is None:
   VVDAsE    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFhRMa
  ChannelContextMenu.FFLXmm = FFLXmm
 except:
  pass
def FFhRMa(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVDAsE(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFLXmm, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFLXmm, title1, csel, isFind=True))))
def FFLXmm(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFCCrt(refCode)
 except:
  pass
 self.session.open(boundFunction(CCHgAO, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFa7cy(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FF0gVw, session, "lok")
 hk.actions['longCancel'] = boundFunction(FF0gVw, session, "lesc")
 hk.actions['longRed']  = boundFunction(FF0gVw, session, "lred")
def FF0gVw(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFwieQ(session, isFromSession=True)
def FFC1qE(SELF, title="", addLabel=False, addScrollLabel=False, VV4YjP=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFevP0()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCzpvL(SELF)
 if VV4YjP:
  SELF["myMenu"] = MenuList(VV4YjP)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVyEiI        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFbkDu(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FFIx6p, SELF, "0") ,
  "1"    : boundFunction(FFIx6p, SELF, "1") ,
  "2"    : boundFunction(FFIx6p, SELF, "2") ,
  "3"    : boundFunction(FFIx6p, SELF, "3") ,
  "4"    : boundFunction(FFIx6p, SELF, "4") ,
  "5"    : boundFunction(FFIx6p, SELF, "5") ,
  "6"    : boundFunction(FFIx6p, SELF, "6") ,
  "7"    : boundFunction(FFIx6p, SELF, "7") ,
  "8"    : boundFunction(FFIx6p, SELF, "8") ,
  "9"    : boundFunction(FFIx6p, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFsPIs, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFIx6p(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVO6Kg:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVO6Kg + SELF.keyPressed + VVKXn9)
    txt = VVKXn9 + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFuCKD(SELF, txt)
def FFsPIs(SELF, tableObj, colNum):
 FFuCKD(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VVNAqK(i)
     break
 except:
  pass
def FFau55(SELF, setMenuAction=True):
 if setMenuAction:
  global VVIzPF
  VVIzPF = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFevP0():
 return ("  %s" % VVIzPF)
def FF3fcb(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFrQie(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFHCHO(color):
 return parseColor(color).argb()
def FFXws7(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFc3QD(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFrMe3(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FF8EkF(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVO6Kg)
 else:
  return ""
def FF92Aw(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVyYSf, word, VVyYSf, VVO6Kg)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVyYSf, word, VVyYSf)
def FFu1AK(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVO6Kg
def FF8zAJ(color):
 if color: return "echo -e '%s' %s;" % (VVyYSf, FF8EkF(VVyYSf, VVyveI))
 else : return "echo -e '%s';" % VVyYSf
def FFWpRC(title, color):
 title = "%s\n%s\n%s\n" % (VVyYSf, title, VVyYSf)
 return FFu1AK(title, color)
def FF0PjP(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFtv1E(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FF4knh(callBackFunction):
 tCons = CCJC8z()
 tCons.ePopen("echo", boundFunction(FFY4zq, callBackFunction))
def FFY4zq(callBackFunction, result, retval):
 callBackFunction()
def FFxBTP(SELF, fnc, title="Processing ...", clearMsg=True):
 FFuCKD(SELF, title)
 tCons = CCJC8z()
 tCons.ePopen("echo", boundFunction(FFbLRN, SELF, fnc, clearMsg))
def FFbLRN(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFuCKD(SELF)
def FFrjhl(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVlBSU
  else       : return ""
def FFwhw7(cmd):
 txt = FFrjhl(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFoABH(cmd):
 lines = FFwhw7(cmd)
 if lines: return lines[0]
 else : return ""
def FFzCqC(SELF, cmd):
 lines = FFwhw7(cmd)
 VVaXgj = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVaXgj.append((key, val))
  elif line:
   VVaXgj.append((line, ""))
 if VVaXgj:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFlZ9Z(SELF, None, header=header, VVplFV=VVaXgj, VVbohG=widths, VVIUEO=28)
 else:
  FFb4nu(SELF, cmd)
def FFb4nu(    SELF, cmd, **kwargs): SELF.session.open(CCMzbw, VVC2Uz=cmd, VVy6mg=True, VV66pN=VVY6j5, **kwargs)
def FFUQFp(  SELF, cmd, **kwargs): SELF.session.open(CCMzbw, VVC2Uz=cmd, **kwargs)
def FFRkbo(   SELF, cmd, **kwargs): SELF.session.open(CCMzbw, VVC2Uz=cmd, VV9bDV=True, VVtwuY=True, VV66pN=VVY6j5, **kwargs)
def FFJGAU(  SELF, cmd, **kwargs): SELF.session.open(CCMzbw, VVC2Uz=cmd, VV9bDV=True, VVtwuY=True, VV66pN=VVOCNl, **kwargs)
def FFO3om(  SELF, cmd, **kwargs): SELF.session.open(CCMzbw, VVC2Uz=cmd, VVwdV9=True , **kwargs)
def FFvBxu( SELF, cmd, **kwargs): SELF.session.open(CCMzbw, VVC2Uz=cmd, VV5pky=True   , **kwargs)
def FFSndt( SELF, cmd, **kwargs): SELF.session.open(CCMzbw, VVC2Uz=cmd, VVtOh4=True  , **kwargs)
def FFxZhj(cmd):
 return cmd + " > /dev/null 2>&1"
def FFjCF2():
 return " > /dev/null 2>&1"
def FFpLPM(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFomXb(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFCc49():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFoABH(cmd)
VVnivp     = 0
VVYxH0      = 1
VVc8pZ   = 2
VVlJ3S      = 3
VVJ6I7      = 4
VV21xv     = 5
VVlw3T     = 6
VVTA1J = 7
VVuYZI = 8
VVOctN = 9
VVmBvd  = 10
VVSstK     = 11
VVepO0  = 12
VVfG69  = 13
def FFZIC7(parmNum, grepTxt):
 if   parmNum == VVnivp  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVYxH0   : param = ["list"   , "apt list" ]
 elif parmNum == VVc8pZ: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFCc49()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FF8XlR(parmNum, package):
 if   parmNum == VVlJ3S      : param = ["info"      , "apt show"         ]
 elif parmNum == VVJ6I7      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VV21xv     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVlw3T     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVTA1J : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVuYZI : param = ["install --force-overwrite" , "dpkg -i --force-overwrite -y"    ]
 elif parmNum == VVOctN : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVmBvd  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVSstK     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVepO0  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVfG69  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFCc49()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFYBb8():
 result = FFoABH("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FF8XlR(VVlw3T , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFxZhj("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFxZhj("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FF8EkF(failed1, VVyveI))
   cmd += "  echo -e '%s' %s;"  % (failed2, FF8EkF(failed2, VVyveI))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FF8EkF(failed3, VVMioC))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFGJDB(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FF8XlR(VVlw3T , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFxZhj("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FF8EkF(failed1, VVyveI))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FF8EkF(failed2, VVMioC))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFDqwf(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFxZhj('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFxZhj("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFQiI5(path, maxSize=-1):
 txt = ""
 for enc in VV29ZD:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFghv7(path, keepends=False, maxSize=-1):
 lines = FFQiI5(path, maxSize)
 return lines.splitlines(keepends)
def FFr7JP(SELF, path):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFkJoP(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFghv7(path, maxSize=maxSize)
  if lines: FFXXd4(SELF, lines, title=title, VV66pN=VVY6j5)
  else : FF4o1U(SELF, path, title=title)
 else:
  FFLxgb(SELF, path, title)
def FFKyDS(SELF, path, title):
 if fileExists(path):
  txt = FFQiI5(path)
  txt = txt.replace("#W#", VVO6Kg)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVKXn9)
  txt = txt.replace("#C#", VVNRRl)
  txt = txt.replace("#P#", VVGMgi)
  FFXXd4(SELF, txt, title=title)
 else:
  FFLxgb(SELF, path, title)
def FFEprZ(path, SELF=None):
 txt = ""
 for enc in VV29ZD:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return enc
  except:
   pass
 if SELF:
  FFkZTy(SELF, "Cannot detect file encoding for:\n\n%s" % path)
 return -1
def FFLiCQ(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFfYhl(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FF4tyU(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFk4Wy(parent)
 else    : return FFqenw(parent)
def FFkJoP(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFk4Wy(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFqenw(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFvQDC():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVXgRS)
 paths.append(VVXgRS.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFfYhl(ba)
 for p in list:
  p = ba + p + VVXgRS
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVZO7B, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVXgRS, VVZO7B , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVKauo, VVII1V = FFvQDC()
def FFO8k9():
 def VVa1Yh(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 iPath = CFG.iptvHostsPath.getValue()
 if not iPath == VVDUxq and not pathExists(iPath):
  CFG.iptvHostsPath.setValue(VVDUxq)
  CFG.iptvHostsPath.save()
  oldIptvHostsPath = VVDUxq
 else:
  oldIptvHostsPath = ""
 oldMovieDownloadPath = VVa1Yh(CFG.MovieDownloadPath, CCL88j.VVNv3p())
 VVB3eW   = VVa1Yh(CFG.backupPath, CCljBV.VVNJ0N())
 VVMyUF   = VVa1Yh(CFG.downloadedPackagesPath, t)
 VVIryX  = VVa1Yh(CFG.exportedTablesPath, t)
 VVABdj  = VVa1Yh(CFG.exportedPIconsPath, t)
 VVdOKY   = VVa1Yh(CFG.packageOutputPath, t)
 global VVA6fc
 VVA6fc = FFk4Wy(CFG.backupPath.getValue())
 if VVB3eW or VVdOKY or VVMyUF or VVIryX or VVABdj or oldIptvHostsPath or oldMovieDownloadPath:
  configfile.save()
 return VVB3eW, VVdOKY, VVMyUF, VVIryX, VVABdj, oldIptvHostsPath, oldMovieDownloadPath
def FFVuf4(path):
 path = FFqenw(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFFf2d(SELF, pathList, tarFileName, addTimeStamp=True):
 VVplFV = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVplFV.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVplFV.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVplFV.append(path)
 if not VVplFV:
  FFkZTy(SELF, "Files not found!")
 elif not pathExists(VVA6fc):
  FFkZTy(SELF, "Path not found!\n\n%s" % VVA6fc)
 else:
  VVkbje = FFk4Wy(VVA6fc)
  tarFileName = "%s%s" % (VVkbje, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFKsmN())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVplFV:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVyYSf
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FF8EkF(tarFileName, VVG7vV))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FF8EkF(failed, VVG7vV))
  cmd += "fi;"
  cmd +=  sep
  FFUQFp(SELF, cmd)
def FFhBiL(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFh916(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFh916(SELF["keyInfo"], "info")
def FFh916(barObj, fName):
 path = "%s%s%s" % (VVII1V, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFoFhU(SELF, title, VV8s1L, showGrnMsg=""):
 SELF.session.open(boundFunction(CCOg0y, title=title, VV8s1L=VV8s1L, showGrnMsg=showGrnMsg))
def FFg5SC(labelObj, VV8s1L):
 if VV8s1L and fileExists(VV8s1L):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VVYtKo(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VVYtKo)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VV8s1L)
   return True
  except:
   pass
 return False
def FFsxV0(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFciDZ(satNum)
  return satName
def FFciDZ(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFouUf(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFsxV0(val)
  else  : sat = FFciDZ(val)
 return sat
def FFLu71(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFsxV0(num)
 except:
  pass
 return sat
def FF3mUD(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFtkuU(SELF, isFromSession=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFY7OE(info, iServiceInformation.sServiceref)
   prov = FFY7OE(info, iServiceInformation.sProvider)
   state = str(FFY7OE(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFj0hS(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFmuAP(refCode)
 return info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFY7OE(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFskjD(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFCCrt(refCode):
 info = FFF5id(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFjwxs(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFNjmV(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFF5id(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVT0Y4 = eServiceCenter.getInstance()
  if VVT0Y4:
   info = VVT0Y4.info(service)
 return info
def FFyH61(SELF, refCode, VVuGQM=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  FFFeUZ(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVuGQM:
   FFwieQ(SELF, isFromSession)
 try:
  VVuOoM = InfoBar.instance
  if VVuOoM:
   VVdQqo = VVuOoM.servicelist
   if VVdQqo:
    servRef = eServiceReference(refCode)
    VVdQqo.saveChannel(servRef)
 except:
  pass
def FFFeUZ(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CC8eJk()
    if pr.VVUOih(refCode, chName, decodedUrl, iptvRef):
     pr.VVBR98(SELF, isFromSession)
def FFj0hS(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFYXBV(url): return any(x in url for x in ("/movie/", "/series/", "mode=vod", "mode=series"))
def FFrEnh(url)  : return any(x in url for x in ("/movie/", "mode=vod"))
def FFkweZ(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFmuAP(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFwWRV(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FF7fKJ(userBfile):
 txt = ""
 bFile = VVV3TR + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVV3TR + userBfile):
  fTxt = FFQiI5(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFoABH('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
def FFwWRV(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FFk7NU(url):
 if iQuote : return iQuote(url)
 else  : return url
def FFt6Xa(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFxsRA(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FF5uxe(txt):
 try:
  return FFt6Xa(FFxsRA(txt)) == txt
 except:
  return False
def FFwieQ(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(SELF, isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCnyHZ, isFromExternal=isFromSession)
 else      : FFfBNQ(session, reopen=True, isFromExternal=isFromSession)
def FFfBNQ(session, reopen=False, isFromExternal=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFfBNQ, session, isFromExternal=isFromExternal), boundFunction(CCDFlM, isFromExternal=isFromExternal))
  except:
   try:
    FFZt54(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FF2cx1(refCode):
 tp = CCs7Me()
 if tp.VVArtb(refCode) : return True
 else        : return False
def FFkMqo(refCode, isHide):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFXgo1():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FFDRSE():
 VVuOoM = InfoBar.instance
 if VVuOoM:
  VVdQqo = VVuOoM.servicelist
  if VVdQqo:
   return VVdQqo.getBouquetList()
 return None
def FFsS4k():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFLFiD():
 path = FFsS4k()
 if path:
  txt = FFQiI5(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFrAku():
 return FFDOQH(InfoBar.instance.servicelist.getRoot())
def FFDOQH(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVT0Y4 = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVT0Y4.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FFBt2Q():
 VV66Bz = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VViiKj = list(VV66Bz)
 return VViiKj, VV66Bz
def FF71De():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFRwsU(session, VVaBDS):
 VVVeIM, VV11gI, VVBcf3, camCommand = FFlBFk()
 if VV11gI:
  runLog = False
  if   VVaBDS == CCP71Z.VVberq : runLog = True
  elif VVaBDS == CCP71Z.VV9jF2 : runLog = True
  elif not VVBcf3          : FFZt54(session, message="SoftCam not started yet!")
  elif fileExists(VVBcf3)        : runLog = True
  else             : FFZt54(session, message="File not found !\n\n%s" % VVBcf3)
  if runLog:
   session.open(boundFunction(CCP71Z, VVVeIM=VVVeIM, VV11gI=VV11gI, VVBcf3=VVBcf3, VVaBDS=VVaBDS))
 else:
  FFZt54(session, message="No active OSCam/NCam found !", title="Live Log")
def FFlBFk():
 VVVeIM = "/etc/tuxbox/config/"
 VV11gI = None
 VVBcf3  = None
 camCommand = FFoABH("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VV11gI = "oscam"
 elif "ncam"  in camCommand : VV11gI = "ncam"
 if VV11gI:
  path = FFoABH(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFk4Wy(path)
  if pathExists(path):
   VVVeIM = path
  tFile = VVVeIM + VV11gI + ".conf"
  tFile = FFoABH("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVBcf3 = tFile
 return VVVeIM, VV11gI, VVBcf3, camCommand
def FFNSik(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFVTa3():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFKsmN():
 return FFVTa3().replace(" ", "_").replace("-", "").replace(":", "")
def FFRxqD(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFHBjP():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFPMCM(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCdgmH.VVinaS(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCdgmH.VVDdNq_forBouquet(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFxZhj("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFTftb(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FF6Fzh(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
VVZIDI = 0
def FFc4pg():
 global VVZIDI
 VVZIDI = iTime()
def FFcghv():
 FF7xGZ(">>>>>> Elapsed\t: {:.6f} seconds".format(iTime() - VVZIDI).rstrip("0").rstrip("."))
def FFUwJf(SELF, message, title=""):
 SELF.session.open(boundFunction(CCrCIF, title=title, message=message, VV2L7a=True))
def FFXXd4(SELF, message, title="", VV66pN=VVY6j5, **kwargs):
 SELF.session.open(boundFunction(CCrCIF, title=title, message=message, VV66pN=VV66pN, **kwargs))
def FFkZTy(SELF, message, title="")  : FFZt54(SELF.session, message, title)
def FFLxgb(SELF, path, title="") : FFZt54(SELF.session, "File not found !\n\n%s" % path, title)
def FF4o1U(SELF, path, title="") : FFZt54(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFmzPi(SELF, title="")  : FFZt54(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFZt54(session, message, title="") : session.open(boundFunction(CCFxYV, title=title, message=message))
def FFmIMB(SELF, VVnyfB, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVnyfB, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVnyfB, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVnyfB, boundFunction(CCF7U0, title=title, message=message, VV1tLf=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFkZTy(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFsJwx(SELF, callBack_Yes, VVR8iK, callBack_No=None, title="", VVEGkV=False, VVYmNt=True):
 SELF.session.openWithCallback(boundFunction(FFU60b, callBack_Yes, callBack_No)
        , boundFunction(CC6NFD, title=title, VVR8iK=VVR8iK, VVYmNt=VVYmNt, VVEGkV=VVEGkV))
def FFU60b(callBack_Yes, callBack_No, FFsJwxed):
 if FFsJwxed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFuCKD(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFc3QD(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFMEyz(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFcn9Z(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVhhTH = eTimer()
def FFMEyz(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFqFQq, SELF))
 fnc = boundFunction(FFqFQq, SELF)
 try:
  t = VVhhTH.timeout.connect(fnc)
 except:
  VVhhTH.callback.append(fnc)
 VVhhTH.start(milliSeconds, 1)
def FFqFQq(SELF):
 VVhhTH.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFlZ9Z(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCqgup, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCqgup, **kwargs))
  FFYdRn(win)
  return win
 except:
  return None
def FF2oO5(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCyFM8, **kwargs))
 FFYdRn(win)
 return win
def FFgCFv(SELF, **kwargs):
 SELF.session.open(CClBuf, **kwargs)
def FF7qhl(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FF9g2V(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VV9SQC, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFahFV(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FF9g2V(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FF3btT():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFc5Qc(VVIUEO):
 screenSize  = FF3btT()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVIUEO)
 return bodyFontSize
def FFIQs2(VVIUEO, extraSpace):
 font = gFont(VV9SQC, VVIUEO)
 VV1IUN = fontRenderClass.getInstance().getLineHeight(font) or (VVIUEO * 1.25)
 return int(VV1IUN + VV1IUN * extraSpace)
def FFedCH(fontName):
 fList = None
 try:
  from enigma import getFontFaces
  fList = getFontFaces()
 except:
  try:
   from skin import getFontFaces
   fList = getFontFaces()
  except:
   pass
 if fList and fontName in fList : return fontName
 else       : return VV9SQC
def FF65g3(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FF3btT()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * VVDxIt)
 bodyFontStr  = 'font="%s;%d"' % (VV9SQC, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFIQs2(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VV9SQC, titleFontSize, alignLeftCenter)
 if winType == VVbnJN or winType == VVzdp7:
  if winType == VVzdp7 : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVMzZT:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == VVkGUL:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FFUwJfL = b2Left2 + timeW + marginLeft
  FFUwJfW = b2Left3 - marginLeft - FFUwJfL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FFUwJfL  , b2Top, FFUwJfW , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="1000" alphatest="blend" />' % (0, top, sz, sz)
 elif winType == VV070d:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VV8YT4:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVgCbm:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVxeiM:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VV9SQC, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VV9SQC, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVrFIk:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFUwJfH = int(bodyH * 0.5)
  inpTop = bodyTop + FFUwJfH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFUwJfH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VV9SQC, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VV9SQC, mapF, alignCenter)
 elif winType == VViV0B:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVmTzD:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VV9SQC, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVHtD3:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VV9SQC, fontH, alignCenter)
 elif winType == VVLePB:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VV9SQC, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VV9SQC, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VV9SQC, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVkTZL:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 else:
  if   winType == VVYQha : align = alignLeftCenter
  elif winType == VVq7g2 : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVv9qr:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VVAObh:
   moreParams = ""
  else:
   fontStr = bodyFontStr
   if usefixedFont and winType == VVq7g2:
    fontStr = 'font="%s;%d"' % (FFedCH("Fixed"), bodyFontSize)
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" %s %s ' % (bodyColor, fontStr, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVIUEO = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VV9SQC, VVIUEO, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVQfS4 = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VV9SQC, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVQfS4[i], VV9SQC, barFont, alignCenter)
   left += btnW + gap
 if winType == VVq7g2:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVQfS4 = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVQfS4[i], VV9SQC, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF65g3(VVbnJN, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.hiddenMenuPass = ""
  self.themsList  = []
  VV4YjP = []
  if VVf0A5:
   VV4YjP.append(("-- MY TEST --"    , "myTest"   ))
  VV4YjP.append(("  File Manager"     , "FileManager"  ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("  Services/Channels"    , "ChannelsTools" ))
  VV4YjP.append(("  IPTV"       , "IptvTools"  ))
  VV4YjP.append(("  PIcons"       , "PIconsTools"  ))
  VV4YjP.append(("  SoftCam"      , "SoftCam"   ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("  Plugins"      , "PluginsTools" ))
  VV4YjP.append(("  Terminal"      , "Terminal"  ))
  VV4YjP.append(("  Backup & Restore"    , "BackupRestore" ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("  Date/Time"      , "Date_Time"  ))
  VV4YjP.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VV4YjP)
  FFC1qE(self, VV4YjP=VV4YjP)
  FF3fcb(self["keyRed"] , "Exit")
  FF3fcb(self["keyGreen"] , "Settings")
  FF3fcb(self["keyYellow"], "Dev. Info.")
  FF3fcb(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVbnhZ       ,
   "yellow"  : self.VVesRo       ,
   "blue"   : self.VV7vzq       ,
   "info"   : self.VV7vzq       ,
   "last"   : self.VVgNg9      ,
   "next"   : self.VV2JkQ       ,
   "menu"   : self.VVZkzO     ,
   "0"    : boundFunction(self.VVABMo, 0) ,
   "1"    : boundFunction(self.VVBO8S, 1)   ,
   "2"    : boundFunction(self.VVBO8S, 2)   ,
   "3"    : boundFunction(self.VVBO8S, 3)   ,
   "4"    : boundFunction(self.VVBO8S, 4)   ,
   "5"    : boundFunction(self.VVBO8S, 5)   ,
   "6"    : boundFunction(self.VVBO8S, 6)   ,
   "7"    : boundFunction(self.VVBO8S, 7)   ,
   "8"    : boundFunction(self.VVBO8S, 8)   ,
   "9"    : boundFunction(self.VVBO8S, 9)
  })
  self.onShown.append(self.VV2xXB)
  self.onClose.append(self.onExit)
  global VV6vw4, VVsYt6, VVodYT
  VV6vw4 = VVsYt6 = VVodYT = False
 def VVyEiI(self):
  item = FFau55(self)
  self.VVBO8S(item)
 def VVBO8S(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVajVk()
   elif item in ("FileManager"  , 1) : self.session.open(CC5T3l)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCLdzJ)
   elif item in ("IptvTools"  , 3) : self.session.open(CCdgmH)
   elif item in ("PIconsTools"  , 4) : self.VVGhQk()
   elif item in ("SoftCam"   , 5) : self.session.open(CCUtps)
   elif item in ("PluginsTools" , 6) : self.session.open(CCC7Ed)
   elif item in ("Terminal"  , 7) : self.session.open(CC1svu)
   elif item in ("BackupRestore" , 8) : self.session.open(CCndfq)
   elif item in ("Date_Time"  , 9) : self.session.open(CC2sbR)
   elif item in ("CheckInternet" , 10) : self.session.open(CC7eRu)
   else         : self.close()
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FF0PjP(self["myMenu"])
  FFahFV(self)
  FF7qhl(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVVxCA)
  self["myTitle"].setText(title)
  VVB3eW, VVdOKY, VVMyUF, VVIryX, VVABdj, oldIptvHostsPath, oldMovieDownloadPath = FFO8k9()
  self.VVy3O5()
  if VVB3eW or VVdOKY or VVMyUF or VVIryX or VVABdj or oldIptvHostsPath or oldMovieDownloadPath:
   VV4FHA = lambda path, subj: "%s:\n%s\n\n" % (subj, FFu1AK(path, VVMioC)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VV4FHA(oldIptvHostsPath  , "IPTV Hosts Files Path"   )
   txt += VV4FHA(VVB3eW   , "Backup/Restore Path"    )
   txt += VV4FHA(VVdOKY  , "Created Package Files (IPK/DEB)" )
   txt += VV4FHA(VVMyUF  , "Download Packages (from feeds)" )
   txt += VV4FHA(VVIryX , "Exported Tables"     )
   txt += VV4FHA(VVABdj , "Exported PIcons"     )
   txt += VV4FHA(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFXXd4(self, txt, title="Settings Paths")
  if (EASY_MODE or VVDWC2 or VVf0A5):
   FFc3QD(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFuCKD(self, "Welcome", 300)
  FF4knh(boundFunction(self.VVqZI4, title))
 def VVqZI4(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCljBV.VVcUzk()
   if url:
    newWebVer = CCljBV.VVU9Jm(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFxZhj("rm /tmp/ajpanel*"))
  global VV6vw4, VVsYt6, VVodYT
  VV6vw4 = VVsYt6 = VVodYT = False
 def VVABMo(self, digit):
  self.hiddenMenuPass += str(digit)
  ln = len(self.hiddenMenuPass)
  global VV6vw4, VVodYT
  if ln == 4:
   if self.hiddenMenuPass == "0" * ln:
    VV6vw4 = True
    FFc3QD(self["myTitle"], "#800080")
   else:
    self.hiddenMenuPass = "x"
  elif self.hiddenMenuPass == "0" * ln:
   VVodYT = True
 def VV2JkQ(self):
  self.hiddenMenuPass += ">"
  if self.hiddenMenuPass == "0" * 4 + ">" * 2:
   global VVsYt6
   VVsYt6 = True
   FFc3QD(self["myTitle"], "#dd5588")
 def VVgNg9(self):
  self.hiddenMenuPass += "<"
  if self.hiddenMenuPass == "0" * 4 + "<" * 2:
   ok = False
   fnt = "ae_AlMateen.ttf"
   fontFile = "/usr/share/fonts/%s" % fnt
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    try:
     addFont(fontFile, fontName, 100, True)
     ok = True
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      ok = True
     except:
      pass
   if ok: txt = 'Added Font: "%s"' % fnt
   else : txt = '"%s" Not Found' % fnt
   FFuCKD(self, txt, 2000, isGrn=ok)
 def VVGhQk(self):
  found = False
  pPath = CCczfG.VVpOjs()
  if pathExists(pPath):
   for fName, fType in CCczfG.VVVvYS(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCczfG)
  else:
   VV4YjP = []
   VV4YjP.append(("PIcons Manager" , "CCczfG" ))
   VV4YjP.append(VV32Zp)
   VV4YjP.append(CCczfG.VVu3xL())
   VV4YjP.append(VV32Zp)
   VV4YjP += CCczfG.VVGvzo()
   FF2oO5(self, self.VVQ7dw, VV4YjP=VV4YjP)
 def VVQ7dw(self, item=None):
  if item:
   if   item == "CCczfG"   : self.session.open(CCczfG)
   elif item == "VVAXvZ"  : CCczfG.VVAXvZ(self)
   elif item == "VVkqn2"  : CCczfG.VVkqn2(self)
   elif item == "findPiconBrokenSymLinks" : CCczfG.VV5uyo(self, True)
   elif item == "FindAllBrokenSymLinks" : CCczfG.VV5uyo(self, False)
 def VVbnhZ(self):
  self.session.open(CCljBV)
 def VVesRo(self):
  self.session.open(CCrIVm)
 def VV7vzq(self):
  changeLogFile = VVII1V + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FFghv7(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFu1AK("\n%s\n%s\n%s" % (VVyYSf, line, VVyYSf), VVGMgi, VVO6Kg)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FFu1AK(line, VVKXn9, VVO6Kg)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFXXd4(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVVxCA), VVIUEO=26)
 def VVZkzO(self):
  VV4YjP = []
  VV4YjP.append(("Title Colors"   , "title" ))
  VV4YjP.append(("Menu Area Colors"  , "body" ))
  VV4YjP.append(("Menu Pointer Colors" , "cursor" ))
  VV4YjP.append(("Bottom Bar Colors" , "bar"  ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Reset Colors"   , "reset" ))
  title = "Main Menu Colors"
  FF2oO5(self, boundFunction(self.VVh1B5, title), VV4YjP=VV4YjP, width=500, title=title)
 def VVh1B5(self, title, item=None):
  if item:
   if item == "reset":
    FFsJwx(self, self.VVUBhw, "Reset to default colors ?", title=title)
   else:
    tDict = self.VV285g()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VVTtYC, tDict, item), CC30RM, defFG=fg, defBG=bg)
 def VVW1wj(self):
  return VVA6fc + "ajpanel_colors"
 def VV285g(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVW1wj()
  if fileExists(p):
   txt = FFQiI5(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVTtYC(self, tDict, item, fg, bg):
  if fg:
   self.VVHkS6(item, fg)
   self.VV7OHP(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVB5dS(tDict)
 def VVB5dS(self, tDict):
   p = self.VVW1wj()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVHkS6(self, item, fg):
  if   item == "title" : FFXws7(self["myTitle"], fg)
  elif item == "body"  :
   FFXws7(self["myMenu"], fg)
   FFXws7(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFc3QD(self["myBar"], fg)
   FFXws7(self["keyRed"], fg)
   FFXws7(self["keyGreen"], fg)
   FFXws7(self["keyYellow"], fg)
   FFXws7(self["keyBlue"], fg)
 def VV7OHP(self, item, bg):
  if   item == "title" : FFc3QD(self["myTitle"], bg)
  elif item == "body"  :
   FFc3QD(self["myMenu"], bg)
   FFc3QD(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFc3QD(self["myBar"], bg)
 def VVUBhw(self):
  os.system(FFxZhj("rm %s" % self.VVW1wj()))
  self.close()
 def VVy3O5(self):
  tDict = self.VV285g()
  self.VVwA3e(tDict, "title")
  self.VVwA3e(tDict, "body")
  self.VVwA3e(tDict, "cursor")
  self.VVwA3e(tDict, "bar")
 def VVwA3e(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVHkS6(name, fg)
  if bg: self.VV7OHP(name, bg)
 def VVajVk(self):
  FFwieQ(self)
class CCrIVm(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF65g3(VVbnJN, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VV4YjP = []
  VV4YjP.append(("Settings File"        , "SettingsFile"   ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Box Info"          , "VVvWJh"    ))
  VV4YjP.append(("Tuners Info"         , "VVhx6C"   ))
  VV4YjP.append(("Python Version"        , "VV8FMh"   ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Screen Size"         , "ScreenSize"    ))
  VV4YjP.append(("Locale"          , "Locale"     ))
  VV4YjP.append(("Processor"         , "Processor"    ))
  VV4YjP.append(("Operating System"        , "OperatingSystem"   ))
  VV4YjP.append(("Drivers"          , "drivers"     ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("System Users"         , "SystemUsers"    ))
  VV4YjP.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VV4YjP.append(("Uptime"          , "Uptime"     ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Host Name"         , "HostName"    ))
  VV4YjP.append(("MAC Address"         , "MACAddress"    ))
  VV4YjP.append(("Network Configuration"      , "NetworkConfiguration" ))
  VV4YjP.append(("Network Status"        , "NetworkStatus"   ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Disk Usage"         , "VV26wO"    ))
  VV4YjP.append(("Mount Points"         , "MountPoints"    ))
  VV4YjP.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VV4YjP.append(("USB Devices"         , "USB_Devices"    ))
  VV4YjP.append(("List Block-Devices"       , "listBlockDevices"  ))
  VV4YjP.append(("Directory Size"        , "DirectorySize"   ))
  VV4YjP.append(("Memory"          , "Memory"     ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VV4YjP.append(("Running Processes"       , "RunningProcesses"  ))
  VV4YjP.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFC1qE(self, VV4YjP=VV4YjP, title="Device Information")
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FF0PjP(self["myMenu"])
  FFahFV(self)
 def VVyEiI(self):
  global VVIzPF
  VVIzPF = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCM1kY)
   elif item == "VVvWJh"    : self.VVvWJh()
   elif item == "VVhx6C"   : self.VVhx6C()
   elif item == "VV8FMh"   : self.VV8FMh()
   elif item == "ScreenSize"    : FFXXd4(self, "Width\t: %s\nHeight\t: %s" % (FF3btT()[0], FF3btT()[1]))
   elif item == "Locale"     : self.VVEc2m()
   elif item == "Processor"    : self.VVDOgk()
   elif item == "OperatingSystem"   : FFb4nu(self, "uname -a"        )
   elif item == "drivers"     : self.VVBkNK()
   elif item == "SystemUsers"    : FFb4nu(self, "id"          )
   elif item == "LoggedInUsers"   : FFb4nu(self, "who -a"         )
   elif item == "Uptime"     : FFb4nu(self, "uptime"         )
   elif item == "HostName"     : FFb4nu(self, "hostname"        )
   elif item == "MACAddress"    : self.VVOEb5()
   elif item == "NetworkConfiguration"  : FFb4nu(self, "ifconfig %s %s" % (FF8EkF("HWaddr", VV9edY), FF8EkF("addr:", VVyveI)))
   elif item == "NetworkStatus"   : FFb4nu(self, "netstat -tulpn"       )
   elif item == "VV26wO"    : self.VV26wO()
   elif item == "MountPoints"    : FFb4nu(self, "mount %s" % (FF8EkF(" on ", VVyveI)))
   elif item == "FileSystemTable"   : FFb4nu(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFb4nu(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFb4nu(self, "blkid"         )
   elif item == "DirectorySize"   : FFb4nu(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVn21l="Reading size ...")
   elif item == "Memory"     : FFb4nu(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VV7JIm()
   elif item == "RunningProcesses"   : FFb4nu(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFb4nu(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVjOzL()
   else         : self.close()
 def VVOEb5(self):
  res = FFrjhl("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFXXd4(self, txt)
  else:
   FFb4nu(self, "ip link")
 def VVD83g(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFwhw7(cmd)
  return lines
 def VVnd0T(self, lines, headerRepl, widths, VVdQl9):
  VVaXgj = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVaXgj.append(parts)
  if VVaXgj and len(header) == len(widths):
   VVaXgj.sort(key=lambda x: x[0].lower())
   FFlZ9Z(self, None, header=header, VVplFV=VVaXgj, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=28, VVligN=True)
   return True
  else:
   return False
 def VV26wO(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VVD83g(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVdQl9 = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVnd0T(lines, headerRepl, widths, VVdQl9)
  if not allOK:
   lines = FFwhw7(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFqenw(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVG7vV:
     note = "\n%s" % FFu1AK("Green = Mounted Partitions", VVG7vV)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVyveI
     elif line.endswith(mountList) : color = VVG7vV
     else       : color = VVKXn9
     txt += FFu1AK(line, color) + "\n"
    FFXXd4(self, txt + note)
   else:
    FFkZTy(self, "Not data from system !")
 def VV7JIm(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVD83g(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVdQl9 = (LEFT , CENTER, LEFT )
  allOK = self.VVnd0T(lines, headerRepl, widths, VVdQl9)
  if not allOK:
   FFb4nu(self, cmd)
 def VVEc2m(self):
  from locale import getdefaultlocale
  loc = getdefaultlocale()
  FFXXd4(self, "Language\t: %s\nEncoding\t: %s" % (loc[0], loc[1]))
 def VVBkNK(self):
  cmd = FFZIC7(VVc8pZ, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFb4nu(self, cmd)
  else : FFmzPi(self)
 def VVDOgk(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFb4nu(self, cmd)
 def VVjOzL(self):
  cmd = FFZIC7(VVYxH0, "| grep secondstage")
  if cmd : FFb4nu(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFmzPi(self)
 def VVvWJh(self):
  c = VVG7vV
  VVplFV = []
  VVplFV.append((FFu1AK("Box Type"  , c), FFu1AK(self.VVq6Ad("boxtype").upper(), c)))
  VVplFV.append((FFu1AK("Board Version", c), FFu1AK(self.VVq6Ad("board_revision") , c)))
  VVplFV.append((FFu1AK("Chipset"  , c), FFu1AK(self.VVq6Ad("chipset")  , c)))
  VVplFV.append((FFu1AK("S/N"   , c), FFu1AK(self.VVq6Ad("sn")    , c)))
  VVplFV.append((FFu1AK("Version"  , c), FFu1AK(self.VVq6Ad("version")  , c)))
  VVSUZg   = []
  VV5n5h = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VV5n5h = SystemInfo[key]
     else:
      VVSUZg.append((FFu1AK(str(key), VVNRRl), FFu1AK(str(SystemInfo[key]), VVNRRl)))
  except:
   pass
  if VV5n5h:
   VV9Rnr = self.VVNY0U(VV5n5h)
   if VV9Rnr:
    VV9Rnr.sort(key=lambda x: x[0].lower())
    VVplFV += VV9Rnr
  if VVSUZg:
   VVSUZg.sort(key=lambda x: x[0].lower())
   VVplFV += VVSUZg
  if VVplFV:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFlZ9Z(self, None, header=header, VVplFV=VVplFV, VVbohG=widths, VVIUEO=28, VVligN=True)
  else:
   FFXXd4(self, "Could not read info!")
 def VVq6Ad(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFghv7(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVNY0U(self, mbDict):
  try:
   mbList = list(mbDict)
   VVplFV = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVplFV.append((FFu1AK(subject, VVyveI), FFu1AK(value, VVyveI)))
  except:
   pass
  return VVplFV
 def VVhx6C(self):
  txt = self.VVgnpe("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVgnpe("/proc/bus/nim_sockets")
  if not txt: txt = self.VVLZvD()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFXXd4(self, txt)
 def VVLZvD(self):
  txt = ""
  VV4FHA = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VV4FHA("Slot Name" , slot.getSlotName())
     txt += FFu1AK(slotName, VVyveI)
     txt += VV4FHA("Description"  , slot.getFullDescription())
     txt += VV4FHA("Frontend ID"  , slot.frontend_id)
     txt += VV4FHA("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVgnpe(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFghv7(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFu1AK(line, VVyveI)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VV8FMh(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFXXd4(self, txt)
class CCM1kY(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF65g3(VVbnJN, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VV4YjP = []
  VV4YjP.append(("Settings (All)"   , "Settings_All"   ))
  VV4YjP.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  if VVsYt6:
   VV4YjP.append(("Settings (FHDG-17)" , "Settings_FHDG_17"  ))
  VV4YjP.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VV4YjP.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VV4YjP.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VV4YjP.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VV4YjP.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFC1qE(self, VV4YjP=VV4YjP)
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FF0PjP(self["myMenu"])
  FFahFV(self)
 def VVyEiI(self):
  global VVIzPF
  VVIzPF = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFb4nu(self, cmd                )
   elif item == "Settings_HotKeys"   : FFb4nu(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFb4nu(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFb4nu(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFb4nu(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFb4nu(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFb4nu(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFb4nu(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCUtps(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF65g3(VVbnJN, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVVeIM, VV11gI, VVBcf3, camCommand = FFlBFk()
  self.VV11gI = VV11gI
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VV4YjP = []
  VV4YjP.append(("OSCam Files"        , "OSCamFiles"  ))
  VV4YjP.append(("NCam Files"        , "NCamFiles"  ))
  VV4YjP.append(("CCcam Files"        , "CCcamFiles"  ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VV4YjP.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VV4YjP.append(VV32Zp)
  if VV11gI:
   if   "oscam" in VV11gI : camName = "OSCam"
   elif "ncam"  in VV11gI : camName = "NCam"
   VV4YjP.append((camName + " Info."      , "camInfo"   ))
   VV4YjP.append((camName + " Live Status"    , "camLiveStatus" ))
   VV4YjP.append((camName + " Live Readers"    , "camLiveReaders" ))
   VV4YjP.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VV4YjP.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFC1qE(self, VV4YjP=VV4YjP)
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FF0PjP(self["myMenu"])
  FFahFV(self)
 def VVyEiI(self):
  global VVIzPF
  VVIzPF = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CC03cy, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CC03cy, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CC03cy, "cccam"))
   elif item == "OSCamReaders"  : self.VV3rKu("os")
   elif item == "NSCamReaders"  : self.VV3rKu("n")
   elif item == "camInfo"   : FFzCqC(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFRwsU(self.session, CCP71Z.VVberq)
   elif item == "camLiveReaders" : FFRwsU(self.session, CCP71Z.VV9jF2)
   elif item == "camLiveLog"  : FFRwsU(self.session, CCP71Z.VVtAHN)
   else       : self.close()
 def VV3rKu(self, camPrefix):
  VVaXgj = self.VVVEFi(camPrefix)
  if VVaXgj:
   VVaXgj.sort(key=lambda x: int(x[0]))
   if self.VV11gI and self.VV11gI.startswith(camPrefix):
    VV5ydd = ("Toggle State", self.VVXiPy, [camPrefix], "Changing State ...")
   else:
    VV5ydd = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVdQl9  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFlZ9Z(self, None, header=header, VVplFV=VVaXgj, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=26, VV5ydd=VV5ydd, VVwbEy=True)
 def VVVEFi(self, camPrefix):
  readersFile = self.VVVeIM + camPrefix + "cam.server"
  VVaXgj = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFghv7(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVaXgj.append((str(len(VVaXgj) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVaXgj:
    FFkZTy(self, "No readers found !")
  else:
   FFLxgb(self, readersFile)
  return VVaXgj
 def VVXiPy(self, VVv5LU, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVVeIM, camPrefix)
  readerState  = VVv5LU.VVaisE(1)
  readerLabel  = VVv5LU.VVaisE(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCUtps.VVd8EI(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVv5LU.VVczFt()
    FFkZTy(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVaXgj = self.VVVEFi(camPrefix)
   if VVaXgj:
    VVv5LU.VVFYEc(VVaXgj)
 @staticmethod
 def VVd8EI(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFghv7(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFkZTy(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFkZTy(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFLxgb(SELF, confFile)
   return None
  if not iRequest:
   FFkZTy(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFkZTy(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFkZTy(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CC03cy(Screen):
 def __init__(self, VVuKDn, session, args=0):
  self.skin, self.skinParam = FF65g3(VVbnJN, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVVeIM, VV11gI, VVBcf3, camCommand = FFlBFk()
  if   VVuKDn == "ncam" : self.prefix = "n"
  elif VVuKDn == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VV4YjP = []
  if self.prefix == "":
   VV4YjP.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VV4YjP.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VV4YjP.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VV4YjP.append(("constant.cw"         , "x_constant_cw" ))
   VV4YjP.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VV4YjP.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VV4YjP.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VV4YjP.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VV4YjP.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VV4YjP.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VV4YjP.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VV4YjP.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VV4YjP.append(VV32Zp)
   VV4YjP.append(("SoftCam.Key"         , "x_SoftCam_Key" ))
   VV4YjP.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VV4YjP.append(VV32Zp)
   VV4YjP.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VV4YjP.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VV4YjP.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFC1qE(self, VV4YjP=VV4YjP)
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FF0PjP(self["myMenu"])
  FFahFV(self)
 def VVyEiI(self):
  global VVIzPF
  VVIzPF = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFr7JP(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFr7JP(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFr7JP(self, self.VVVeIM + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFr7JP(self, self.VVVeIM + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVpCGP("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVpCGP("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVpCGP("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVpCGP("cam.provid"        )
   elif item == "x_cam_server"  : self.VVpCGP("cam.server"        )
   elif item == "x_cam_services" : self.VVpCGP("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVpCGP("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVpCGP("cam.user"        )
   elif item == "x_VVyYSf"   : pass
   elif item == "x_SoftCam_Key" : FFr7JP(self, self.VVVeIM + "SoftCam.Key"   )
   elif item == "x_CCcam_cfg"  : FFr7JP(self, self.VVVeIM + "CCcam.cfg"    )
   elif item == "x_VVyYSf"   : pass
   elif item == "x_cam_log"  : FFr7JP(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFr7JP(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFr7JP(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVpCGP(self, fileName):
  FFr7JP(self, self.VVVeIM + self.prefix + fileName)
class CCP71Z(Screen):
 VVberq  = 0
 VV9jF2 = 1
 VVtAHN = 2
 def __init__(self, session, VVVeIM="", VV11gI="", VVBcf3="", VVaBDS=VVberq):
  self.skin, self.skinParam = FF65g3(VVq7g2, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVBcf3   = VVBcf3
  self.VVaBDS  = VVaBDS
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVVeIM + VV11gI + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VV11gI : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVVeIM, self.camPrefix)
  if self.VVaBDS == self.VVberq:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVaBDS == self.VV9jF2:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFC1qE(self, self.Title, addScrollLabel=True)
  FF3fcb(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVjK4R
  self.onShown.append(self.VV2xXB)
  self.onClose.append(self.onExit)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  self["myLabel"].VVWjn0(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FF7qhl(self)
  self.VVjK4R()
 def onExit(self):
  self.timer.stop()
 def VVgvzm(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVZE2g)
  except:
   self.timer.callback.append(self.VVZE2g)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFuCKD(self, "Started", 1000)
 def VVoDbo(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVZE2g)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFuCKD(self, "Stopped", 1000)
 def VVjK4R(self):
  if self.timerRunning:
   self.VVoDbo()
  else:
   self.VVgvzm()
   if self.VVaBDS == self.VVberq or self.VVaBDS == self.VV9jF2:
    if self.VVaBDS == self.VVberq : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCUtps.VVd8EI(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FF4knh(self.VVYt6N)
    else:
     self.close()
   else:
    self.VVQbfH()
 def VVZE2g(self):
  if self.timerRunning:
   if   self.VVaBDS == self.VVberq : self.VVaOFu()
   elif self.VVaBDS == self.VV9jF2 : self.VVaOFu()
   else            : self.VVQbfH()
 def VVQbfH(self):
  if fileExists(self.VVBcf3):
   fTime = FFNSik(os.path.getmtime(self.VVBcf3))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VV55Ta(), VV66pN=VVOCNl)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVBcf3)
 def VVYt6N(self):
  self.VVaOFu()
 def VVaOFu(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFu1AK("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVGMgi))
   self.camWebIfErrorFound = True
   self.VVoDbo()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVaBDS == self.VVberq : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFu1AK("Error while parsing data elements !\n\nError = %s" % str(e), VVMioC)
   self.camWebIfErrorFound = True
   self.VVoDbo()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVKR8P(root)
  self["myLabel"].setText(txt, VV66pN=VVOCNl)
  self["myBar"].setText("Last Update : %s" % FFVTa3())
 def VVKR8P(self, rootElement):
  def VV4FHA(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVaBDS == self.VVberq:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFu1AK(status, VVG7vV)
    else          : status = FFu1AK(status, VVMioC)
    txt += VVyYSf + "\n"
    txt += VV4FHA("Name"  , name)
    txt += VV4FHA("Description" , desc)
    txt += VV4FHA("IP/Port"  , "%s : %s" % (ip, port))
    txt += VV4FHA("Protocol" , protocol)
    txt += VV4FHA("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFu1AK("Yes", VVG7vV)
    else    : enabTxt = FFu1AK("No", VVMioC)
    txt += VVyYSf + "\n"
    txt += VV4FHA("Label"  , label)
    txt += VV4FHA("Protocol" , protocol)
    txt += VV4FHA("Enabled" , enabTxt)
  return txt
 def VV55Ta(self):
  wordsDict = self.VVkVId()
  color = [ VVyveI, VV9edY, VVG7vV, VVMioC, VVNRRl, VVeWfa]
  lines = FFwhw7("tail -n %d %s" % (100, self.VVBcf3))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVGMgi + line[:19] + VVKXn9 + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVO6Kg + line[ndx + 3:] + VVKXn9
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVyveI + line[ndx + 8 : ndx1 + 4] + VVKXn9 + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVKXn9)
   elif line.startswith("----") or ">>" in line:
    line = FFu1AK(line, VVyveI)
   txt += line + "\n"
  return txt
 def VVkVId(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFghv7(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCndfq(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF65g3(VVbnJN, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VV4YjP = []
  VV4YjP.append(("Backup Channels"    , "VVCipL"   ))
  VV4YjP.append(("Restore Channels"    , "Restore_Channels"  ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Backup SoftCAM Files"   , "VVXcrX" ))
  VV4YjP.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VV4YjP.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VV4YjP.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Backup Network Settings"  , "VV9A75"   ))
  VV4YjP.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVsYt6:
   VV4YjP.append(VV32Zp)
   VV4YjP.append((VVGMgi + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VVfsPP"   ))
   VV4YjP.append((VVG7vV + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVzOUg) , "createMyIpk"   ))
   VV4YjP.append((VVG7vV + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVzOUg) , "createMyDeb"   ))
   VV4YjP.append((VVNRRl + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VV4YjP.append((VVNRRl + "Decode %s Crash Report"   % PLUGIN_NAME     , "VV99tN" ))
  FFC1qE(self, VV4YjP=VV4YjP)
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FF0PjP(self["myMenu"])
  FFahFV(self)
 def VVyEiI(self):
  global VVIzPF
  VVIzPF = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVCipL"    : self.VVCipL()
   elif item == "Restore_Channels"    : self.VV60A2("channels_backup*.tar.gz", self.VVUzRt)
   elif item == "VVXcrX"   : self.VVXcrX()
   elif item == "Restore_SoftCAM_Files"  : self.VV60A2("softcam_backup*.tar.gz", self.VVs8qK)
   elif item == "Backup_TunerDiSEqC"   : self.VV7TpV("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VV60A2("tuner_backup*.backup", boundFunction(self.VVfJXc, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VV7TpV("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VV60A2("hotkey_*backup*.backup", boundFunction(self.VVfJXc, "misc"))
   elif item == "VV9A75"    : self.VV9A75()
   elif item == "Restore_Network"    : self.VV60A2("network_backup*.tar.gz", self.VVOfRT)
   elif item == "VVfsPP"     : FFsJwx(self, boundFunction(FFxBTP, self, boundFunction(CCndfq.VVfsPP, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVYy8D(False)
   elif item == "createMyDeb"     : self.VVYy8D(True)
   elif item == "createMyTar"     : self.VVTsfr()
   elif item == "VV99tN"   : self.VV99tN()
 @staticmethod
 def VVfsPP(SELF):
  OBF_Path = VVKauo + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVKauo, VVVxCA, VVzOUg)
   if err : FFkZTy(SELF, err)
   else : FFXXd4(SELF, txt)
  else:
   FFLxgb(SELF, OBF_Path)
 def VVYy8D(self, VVgVej):
  OBF_Path = VVKauo + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFkZTy(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVKauo)
  os.system("mv -f %s %s" % (VVKauo + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVKauo + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVKauo + "plugin.py"))
  self.session.openWithCallback(self.VVYy8D1, boundFunction(CC81kT, path=VVKauo, VVgVej=VVgVej))
 def VVYy8D1(self):
  os.system("mv -f %s %s" % (VVKauo + "OBF/main.py"  , VVKauo))
  os.system("mv -f %s %s" % (VVKauo + "OBF/plugin.py" , VVKauo))
 def VV99tN(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFkZTy(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFkZTy(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVYDru("%s*.list" % path)
  if err:
   FFLxgb(self, path + "*.list")
   return
  srcF, err = self.VVYDru("%s*main_final.py" % path)
  if err:
   FFLxgb(self, path + "*.final.py")
   return
  VVplFV = []
  for f in files:
   f = os.path.basename(f)
   VVplFV.append((f, f))
  FF2oO5(self, boundFunction(self.VV9q5y, path, codF, srcF), VV4YjP=VVplFV)
 def VV9q5y(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFLxgb(self, logF)
   else     : FFxBTP(self, boundFunction(self.VV3baz, logF, codF, srcF))
 def VV3baz(self, logF, codF, srcF):
  lst  = []
  lines = FFghv7(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFkZTy(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVCrgY(lst, logF, newLogF)
  totSrc  = self.VVCrgY(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFXXd4(self, txt)
 def VVYDru(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVCrgY(self, lst, f1, f2):
  txt = FFQiI5(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVTsfr(self):
  VVplFV = []
  VVplFV.append("%s%s" % (VVKauo, "*.py"))
  VVplFV.append("%s%s" % (VVKauo, "*.png"))
  VVplFV.append("%s%s" % (VVKauo, "*.xml"))
  VVplFV.append("%s"  % (VVII1V))
  FFFf2d(self, VVplFV, "%s_%s" % (PLUGIN_NAME, VVVxCA), addTimeStamp=False)
 def VVCipL(self):
  path1 = VVV3TR
  path2 = "/etc/tuxbox/"
  VVplFV = []
  VVplFV.append("%s%s" % (path1, "*.tv"))
  VVplFV.append("%s%s" % (path1, "*.radio"))
  VVplFV.append("%s%s" % (path1, "*list"))
  VVplFV.append("%s%s" % (path1, "lamedb*"))
  VVplFV.append("%s%s" % (path2, "*.xml"))
  FFFf2d(self, VVplFV, "channels_backup", addTimeStamp=True)
 def VVXcrX(self):
  VVplFV = []
  VVplFV.append("/etc/tuxbox/config/")
  VVplFV.append("/usr/keys/")
  VVplFV.append("/usr/scam/")
  VVplFV.append("/etc/CCcam.cfg")
  FFFf2d(self, VVplFV, "softcam_backup", addTimeStamp=True)
 def VV9A75(self):
  VVplFV = []
  VVplFV.append("/etc/hostname")
  VVplFV.append("/etc/default_gw")
  VVplFV.append("/etc/resolv.conf")
  VVplFV.append("/etc/wpa_supplicant*.conf")
  VVplFV.append("/etc/network/interfaces")
  VVplFV.append("/etc/enigma2/nameserversdns.conf")
  FFFf2d(self, VVplFV, "network_backup", addTimeStamp=True)
 def VVUzRt(self, fileName):
  if fileName:
   FFsJwx(self, boundFunction(self.VV0bHU, fileName), "Overwrite current channels ?")
 def VV0bHU(self, fileName):
  path = "%s%s" % (VVA6fc, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCLdzJ.VVUlwt()
   lamedb5File, diabled5File = CCLdzJ.VVf5gZ()
   cmd = ""
   cmd += FFxZhj("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFxZhj("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFXgo1()
   if res == 0 : FFUwJf(self, "Channels Restored.")
   else  : FFkZTy(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFLxgb(self, path)
 def VVs8qK(self, fileName):
  if fileName:
   FFsJwx(self, boundFunction(self.VVBQd1, fileName), "Overwrite SoftCAM files ?")
 def VVBQd1(self, fileName):
  fileName = "%s%s" % (VVA6fc, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVyYSf
   note = "You may need to restart your SoftCAM."
   FFJGAU(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FF8EkF(note, VVyveI), sep))
  else:
   FFLxgb(self, fileName)
 def VVOfRT(self, fileName):
  if fileName:
   FFsJwx(self, boundFunction(self.VVLpk7, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVLpk7(self, fileName):
  fileName = "%s%s" % (VVA6fc, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFO3om(self,  cmd)
  else:
   FFLxgb(self, fileName)
 def VV60A2(self, pattern, callBackFunction, isTuner=False):
  title = FFevP0()
  if pathExists(VVA6fc):
   myFiles = iGlob("%s%s" % (VVA6fc, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVplFV = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVplFV.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVXcP7 = ("Sat. List", self.VVfJAV)
    else  : VVXcP7 = None
    VVRGLF = ("Delete File", boundFunction(self.VVwbWD, boundFunction(self.VV60A2, pattern, callBackFunction, isTuner)))
    FF2oO5(self, callBackFunction, title=title, VV4YjP=VVplFV, VVXcP7=VVXcP7, VVRGLF=VVRGLF)
   else:
    FFkZTy(self, "No files found in:\n\n%s" % VVA6fc, title)
  else:
   FFkZTy(self, "Path not found:\n\n%s" % VVA6fc, title)
 def VVwbWD(self, cbFnc, VV0IKZObj, path):
  FFsJwx(self, boundFunction(self.VV4t7R, cbFnc, VV0IKZObj, path), "Delete this file ?\n\n%s" % path)
 def VV4t7R(self, cbFnc, VV0IKZObj, path):
  os.system(FFxZhj("rm -f '%s%s'" % (VVA6fc, path)))
  cbFnc()
  VV0IKZObj.cancel()
 def VV7TpV(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCJC8z()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVpHOd, filePrefix))
 def VVpHOd(self, filePrefix, result, retval):
  title = FFevP0()
  if pathExists(VVA6fc):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFkZTy(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVA6fc, filePrefix, FFKsmN())
    try:
     VVplFV = str(result.strip()).split()
     if VVplFV:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVplFV:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVyYSf, FFu1AK(fName, VVyveI), VVyYSf)
       FFXXd4(self, txt, title=title, VV66pN=VVOCNl)
      else:
       FFkZTy(self, "File creation failed!", title)
     else:
      FFkZTy(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFxZhj("rm %s" % fName))
     FFkZTy(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFxZhj("rm %s" % fName))
     FFkZTy(self, "Error while writing file.")
  else:
   FFkZTy(self, "Path not found:\n\n%s" % VVA6fc, title)
 def VVfJXc(self, mode, path):
  if path:
   path = "%s%s" % (VVA6fc, path)
   if fileExists(path):
    lines = FFghv7(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFsJwx(self, boundFunction(self.VVXZgY, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FF4o1U(self, path, title=FFevP0())
   else:
    FFLxgb(self, path)
 def VVXZgY(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVC2Uz = []
  VVC2Uz.append("echo -e 'Reading current settings ...'")
  VVC2Uz.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVC2Uz.append("echo -e 'Preparing new settings ...'")
  VVC2Uz.append(settingsLines)
  VVC2Uz.append("echo -e 'Applying new settings ...'")
  VVC2Uz.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFSndt(self, VVC2Uz)
 def VVfJAV(self, VV0IKZObj, path):
  if not path:
   return
  path = VVA6fc + path
  if not fileExists(path):
   FFLxgb(self, path)
   return
  txt = FFQiI5(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVplFV  = []
   for item in satList:
    VVplFV.append("%s\t%s" % (item[0], FFsxV0(item[1])))
   FFXXd4(self, VVplFV, title="  Satellites List")
  else:
   FFkZTy(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCC7Ed(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF65g3(VVbnJN, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VV4YjP = []
  VV4YjP.append(("Plugins Browser List"       , "VVNNkg"   ))
  VV4YjP.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VV4YjP.append(("Startup Plugins"        , "pluginsStartup"    ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VV4YjP.append(("Remove Packages (show all)"     , "VVWUlrsAll"   ))
  VV4YjP.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Update List of Available Packages"   , "VVvHbi"   ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Packaging Tool"        , "VVGnIy"    ))
  VV4YjP.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFC1qE(self, VV4YjP=VV4YjP)
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FF0PjP(self["myMenu"])
  FFahFV(self)
 def VVyEiI(self):
  global VVIzPF
  VVIzPF = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVNNkg"   : self.VVNNkg()
   elif item == "pluginsMenus"     : self.VVPF55(0)
   elif item == "pluginsStartup"    : self.VVPF55(1)
   elif item == "pluginsDirList"    : self.VV0xpC()
   elif item == "downloadInstallPackages"  : FFxBTP(self, boundFunction(self.VVFvkz, 0, ""))
   elif item == "VVWUlrsAll"   : FFxBTP(self, boundFunction(self.VVFvkz, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFxBTP(self, boundFunction(self.VVFvkz, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVvHbi"   : self.VVvHbi()
   elif item == "VVGnIy"    : self.VVGnIy()
   elif item == "packagesFeeds"    : self.VVBASb()
   else          : self.close()
 def VV0xpC(self):
  extDirs  = FFfYhl(VVXgRS)
  sysDirs  = FFfYhl(VVqP7G)
  VVplFV  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVplFV.append((item, VVXgRS + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVplFV.append((item, VVqP7G + item))
  if VVplFV:
   VVplFV = sorted(VVplFV, key=lambda x: x[0].lower())
   VVxHB1 = ("Package Info.", self.VVWyQx, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFlZ9Z(self, None, header=header, VVplFV=VVplFV, VVbohG=widths, VVIUEO=28, VVxHB1=VVxHB1)
  else:
   FFkZTy(self, "Nothing found!")
 def VVWyQx(self, VVv5LU, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVXgRS) : loc = "extensions"
  elif path.startswith(VVqP7G) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVMBzv(package)
  else:
   FFkZTy(self, "No info!")
 def VVBASb(self):
  pkg = FFCc49()
  if pkg : FFb4nu(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFmzPi(self)
 def VVNNkg(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VV4FHA(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVyYSf + "\n"
    txt += VV4FHA("Number"   , str(c))
    txt += VV4FHA("Name"   , FFu1AK(str(p.name), VVyveI))
    txt += VV4FHA("Path"  , p.path  )
    txt += VV4FHA("Description" , p.description )
    txt += VV4FHA("Icon"  , p.iconstr  )
    txt += VV4FHA("Wakeup Fnc" , p.wakeupfnc )
    txt += VV4FHA("NeedsRestart", p.needsRestart)
    txt += VV4FHA("Internal" , p.internal )
    txt += VV4FHA("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFXXd4(self, txt)
 def VVPF55(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVplFV = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVplFV.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVplFV:
   VVplFV.sort(key=lambda x: x[0].lower())
   header  = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths  = (19  , 25 , 20  , 27   , 9  )
   FFlZ9Z(self, None, title=title, header=header, VVplFV=VVplFV, VVbohG=widths, VVIUEO=26)
  else:
   FFkZTy(self, "Nothing Found", title=title)
 def VVvHbi(self):
  cmd = FFZIC7(VVnivp, "")
  if cmd : FFO3om(self, cmd, checkNetAccess=True)
  else : FFmzPi(self)
 def VVGnIy(self):
  pkg = FFCc49()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFUwJf(self, txt)
 def VVFvkz(self, mode, grep, VVv5LU=None, title=""):
  if   mode == 0: cmd = FFZIC7(VVYxH0    , grep)
  elif mode == 1: cmd = FFZIC7(VVc8pZ , grep)
  elif mode == 2: cmd = FFZIC7(VVc8pZ , grep)
  if not cmd:
   FFmzPi(self)
   return
  VVaXgj = FFwhw7(cmd)
  if not VVaXgj:
   if VVv5LU: VVv5LU.VVczFt()
   FFkZTy(self, "No packages found!")
   return
  elif len(VVaXgj) == 1 and VVaXgj[0] == VVlBSU:
   FFkZTy(self, VVlBSU)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVplFV  = []
  for item in VVaXgj:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVplFV.append((name, package, version))
  if mode > 0:
   extensions = FFwhw7("ls %s -l | grep '^d' | awk '{print $9}'" % VVXgRS)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVplFV:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVplFV.append((name, VVXgRS + item, "-"))
   systemPlugins = FFwhw7("ls %s -l | grep '^d' | awk '{print $9}'" % VVqP7G)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVplFV:
      if item.lower() == row[0].lower():
       break
     else:
      VVplFV.append((item, VVqP7G + item, "-"))
  if not VVplFV:
   FFkZTy(self, "No packages found!")
   return
  if VVv5LU:
   VVplFV.sort(key=lambda x: x[0].lower())
   VVv5LU.VVFYEc(VVplFV, title)
  else:
   widths = (20, 50, 30)
   VV5ydd = None
   VV487W = None
   if mode == 0:
    VVyT4T = ("Install" , self.VVyxNF   , [])
    VV5ydd = ("Download" , self.VV1Usd   , [])
    VV487W = ("Filter"  , self.VVNasu , [])
   elif mode == 1:
    VVyT4T = ("Uninstall", self.VVWUlr, [])
   elif mode == 2:
    VVyT4T = ("Uninstall", self.VVWUlr, [])
    widths= (18, 57, 25)
   VVplFV = sorted(VVplFV, key=lambda x: x[0].lower())
   VVxHB1 = ("Package Info.", self.VVMnao, [])
   header   = ("Name" ,"Package" , "Version" )
   FFlZ9Z(self, None, header=header, VVplFV=VVplFV, VVbohG=widths, VVIUEO=28, VVyT4T=VVyT4T, VV5ydd=VV5ydd, VVxHB1=VVxHB1, VV487W=VV487W, VVSSrD=self.lastSelectedRow
     , VVZidB="#22110011", VVCOuJ="#22191111", VVQfS4="#22191111", VVJk0D="#00003030", VVJSW4="#00333333")
 def VVMnao(self, VVv5LU, title, txt, colList):
  package = colList[1]
  self.VVMBzv(package)
 def VVNasu(self, VVv5LU, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VV4YjP = []
  VV4YjP.append(("All Packages", "all"))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Plugin/SoftCAM/Skin", "plugins"))
  VV4YjP.append(VV32Zp)
  for word in words:
   VV4YjP.append((word, word))
  FF2oO5(self, boundFunction(self.VVn2hf, VVv5LU), VV4YjP=VV4YjP, title="Select Filter")
 def VVn2hf(self, VVv5LU, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFxBTP(VVv5LU, boundFunction(self.VVFvkz, 0, grep, VVv5LU, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVWUlr(self, VVv5LU, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVXgRS, VVqP7G)):
   FFsJwx(self, boundFunction(self.VVnqSP, VVv5LU, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VV4YjP = []
   VV4YjP.append(("Remove Package"         , "remove_ExistingPackage" ))
   VV4YjP.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VV4YjP.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FF2oO5(self, boundFunction(self.VViIje, VVv5LU, package), VV4YjP=VV4YjP)
 def VVnqSP(self, VVv5LU, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVNzYd)
  FFO3om(self, cmd, VVm8DP=boundFunction(self.VVAb0K, VVv5LU))
 def VViIje(self, VVv5LU, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVSstK
   elif item == "remove_ForceRemove"  : cmdOpt = VVepO0
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVfG69
   FFsJwx(self, boundFunction(self.VVf2WZ, VVv5LU, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVf2WZ(self, VVv5LU, package, cmdOpt):
  self.lastSelectedRow = VVv5LU.VVGAHI()
  cmd = FF8XlR(cmdOpt, package)
  if cmd : FFO3om(self, cmd, VVm8DP=boundFunction(self.VVAb0K, VVv5LU))
  else : FFmzPi(self)
 def VVAb0K(self, VVv5LU):
  VVv5LU.cancel()
  FF71De()
 def VVyxNF(self, VVv5LU, title, txt, colList):
  package  = colList[1]
  VV4YjP = []
  VV4YjP.append(("Install Package"         , "install_CheckVersion" ))
  VV4YjP.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VV4YjP.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VV4YjP.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VV4YjP.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FF2oO5(self, boundFunction(self.VV77bl, package), VV4YjP=VV4YjP)
 def VV77bl(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVlw3T
   elif item == "install_ForceReinstall" : cmdOpt = VVTA1J
   elif item == "install_ForceOverwrite" : cmdOpt = VVuYZI
   elif item == "install_ForceDowngrade" : cmdOpt = VVOctN
   elif item == "install_IgnoreDepends" : cmdOpt = VVmBvd
   FFsJwx(self, boundFunction(self.VVUocn, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVUocn(self, package, cmdOpt):
  cmd = FF8XlR(cmdOpt, package)
  if cmd : FFO3om(self, cmd, VVm8DP=FF71De, checkNetAccess=True)
  else : FFmzPi(self)
 def VV1Usd(self, VVv5LU, title, txt, colList):
  package  = colList[1]
  FFsJwx(self, boundFunction(self.VVZ0aJ, package), "Download Package ?\n\n%s" % package)
 def VVZ0aJ(self, package):
  if FFDqwf():
   cmd = FF8XlR(VV21xv, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FF8EkF(success, VVG7vV))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FF8EkF(fail, VVMioC))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFO3om(self, cmd, VVHZm7=[VVMioC, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFmzPi(self)
  else:
   FFkZTy(self, "No internet connection !")
 def VVMBzv(self, package):
  infoCmd  = FF8XlR(VVlJ3S, package)
  filesCmd = FF8XlR(VVJ6I7, package)
  listInstCmd = FFZIC7(VVc8pZ, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FF8zAJ(VVyveI)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FF8EkF(notInst, VVGMgi))
   cmd += "else "
   cmd +=   FF92Aw("System Info", VVyveI)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FF92Aw("Related Files", VVyveI)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFRkbo(self, cmd)
  else:
   FFmzPi(self)
class CCLdzJ(Screen):
 VVgJzx  = 0
 VV2pbh = 1
 VVDAlG  = 2
 VVKEUK  = 3
 VVDcPa = 4
 VV4nmj = 5
 VVQwO2 = 6
 def __init__(self, session):
  self.skin, self.skinParam = FF65g3(VVbnJN, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVF2FG = None
  self.lastfilterUsed  = None
  VV4YjP = self.VViiVu()
  FFC1qE(self, VV4YjP=VV4YjP, title="Services/Channels")
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self["myMenu"].setList(self.VViiVu())
  FF0PjP(self["myMenu"])
  FFahFV(self)
 def VViiVu(self):
  VV4YjP = []
  VV4YjP.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VV4YjP.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Services (Reference)"      , "lameDB_allChannels_with_refCode"  ))
  VV4YjP.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VV4YjP.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VV4YjP.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VV4YjP.append(("Services with PIcons for the System"  , "VVlgzX"     ))
  VV4YjP.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VV4YjP.append(VV32Zp)
  lamedbFile, disabledFile = CCLdzJ.VVUlwt()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VV4YjP.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VV4YjP.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VV4YjP.append(("Reset Parental Control Settings"   , "VVGcB0"    ))
  VV4YjP.append(("Delete Channels with no names"   , "VVUGqH"    ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Reload Channels and Bouquets"    , "VVkx61"      ))
  return VV4YjP
 def VVyEiI(self):
  global VVIzPF
  VVIzPF = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFwieQ(self)
   elif item == "currentServiceInfo"     : FFgCFv(self, fncMode=CClBuf.VVdrg2)
   elif item == "TranspondersStats"     : FFxBTP(self, self.VVRA6c     )
   elif item == "lameDB_allChannels_with_refCode"  : FFxBTP(self, self.VVIwco )
   elif item == "lameDB_allChannels_with_tranaponder" : FFxBTP(self, self.VV0fhj)
   elif item == "lameDB_allChannels_with_details"  : FFxBTP(self, self.VVZJ7Y )
   elif item == "parentalControlChannels"    : FFxBTP(self, self.VVdLX3   )
   elif item == "showHiddenChannels"     : FFxBTP(self, self.VVGH6h     )
   elif item == "VVlgzX"     : FFxBTP(self, self.VVuBre     )
   elif item == "servicesWithMissingPIcons"   : FFxBTP(self, self.VVWxSe   )
   elif item == "enableHiddenChannels"     : self.VVHJYZ(True)
   elif item == "disableHiddenChannels"    : self.VVHJYZ(False)
   elif item == "VVGcB0"    : FFsJwx(self, self.VVGcB0, "Reset and Restart ?" )
   elif item == "VVUGqH"    : FFxBTP(self, self.VVUGqH)
   elif item == "VVkx61"      : FFxBTP(self, boundFunction(CCLdzJ.VVkx61, self))
   else            : self.close()
 @staticmethod
 def VVkx61(SELF):
  FFXgo1()
  FFUwJf(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVIwco(self):
  self.VVF2FG = None
  self.lastfilterUsed  = None
  self.filterObj   = CCHLQj(self)
  VVaXgj = CCLdzJ.VVj0Np(self, self.VVgJzx)
  if VVaXgj:
   VVaXgj.sort(key=lambda x: x[0].lower())
   VVnutX  = ("Zap"   , self.VVbu6D     , [])
   VVmtel = (""    , self.VVhZMc   , [])
   VVxHB1 = ("Options"  , self.VVcaow , [])
   VV5ydd = ("Current Service", self.VVgUPe , [])
   VV487W = ("Filter"   , self.VVdsVJ  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVdQl9  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFlZ9Z(self, None, header=header, VVplFV=VVaXgj, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=26, VVnutX=VVnutX, VVmtel=VVmtel, VV5ydd=VV5ydd, VVxHB1=VVxHB1, VV487W=VV487W)
 def VV0fhj(self):
  self.VVF2FG = None
  self.lastfilterUsed  = None
  self.filterObj   = CCHLQj(self)
  VVaXgj = CCLdzJ.VVj0Np(self, self.VV2pbh)
  if VVaXgj:
   VVaXgj.sort(key=lambda x: x[0].lower())
   VVnutX  = ("Zap"   , self.VVbu6D      , [])
   VVmtel = (""    , self.VVhZMc    , [])
   VV5ydd = ("Current Service", self.VVgUPe  , [])
   VVxHB1 = ("Options"  , self.VV5BP3 , [])
   VV487W = ("Filter"   , self.VV2xVP  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVdQl9  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFlZ9Z(self, None, header=header, VVplFV=VVaXgj, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=26, VVnutX=VVnutX, VVmtel=VVmtel, VV5ydd=VV5ydd, VVxHB1=VVxHB1, VV487W=VV487W)
 def VVcaow(self, VVv5LU, title, txt, colList):
  servName = colList[0]
  refCode  = colList[3]
  pcState  = colList[4]
  hidState = colList[5]
  mSel  = CClyEH(self, VVv5LU, 3)
  mSel.VVuKsr(servName, refCode, pcState, hidState)
 def VV5BP3(self, VVv5LU, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CClyEH(self, VVv5LU, 3)
  mSel.VVYalA(servName, refCode)
 def VVD5zP(self, VVv5LU, refCode, isAddToBlackList):
  self.VVF2FG = None
  self.lastfilterUsed  = None
  VVv5LU.VVNe8y("Changing state ...")
  path = "/etc/enigma2/blacklist"
  if not fileExists(path):
   os.system("echo '' > %s" % path)
  if fileExists(path):
   if not refCode.endswith(":"):
    refCode += ":"
   if isAddToBlackList :
    os.system("sed -i '/%s/d' %s" % (refCode, path))
    os.system("echo '%s' >> %s" % (refCode, path))
   else:
    os.system("sed -i '/%s/d' %s" % (refCode, path))
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   if refCode.endswith(":"):
    refCode = refCode[:-1]
   FFxBTP(self, boundFunction(self.VVKt2L, VVv5LU, refCode))
  else:
   FFLxgb(self, path)
 def VVeMlh(self, VVv5LU, refCode, isHide):
  self.VVF2FG = None
  self.lastfilterUsed  = None
  VVv5LU.VVNe8y("Changing state ...")
  if FF2cx1(refCode):
   ret = FFkMqo(refCode, isHide)
   if ret : FFxBTP(self, boundFunction(self.VVKt2L, VVv5LU, refCode))
   else : FFkZTy(self, "Cannot Hide/Unhide this channel.")
  else:
   FFkZTy(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)")
 def VVKt2L(self, VVv5LU, refCode):
  VVaXgj = CCLdzJ.VVj0Np(self, self.VVgJzx, VV35ot=[3, [refCode], False])
  done = False
  if VVaXgj:
   data = VVaXgj[0]
   if data[3] == refCode:
    done = VVv5LU.VVoUPy(data)
  if not done:
   self.VVyKO6(VVv5LU, VVv5LU.VVTGuP(), self.VVgJzx)
  VVv5LU.VVczFt()
 def VVdsVJ(self, VVv5LU, title, txt, colList):
  self.filterObj.VV1am9(1, VVv5LU, 2, boundFunction(self.VVOdUO, VVv5LU))
 def VVOdUO(self, VVv5LU, item):
  self.VVu1nc(VVv5LU, item, 2, self.VVgJzx)
 def VV2xVP(self, VVv5LU, title, txt, colList):
  self.filterObj.VV1am9(2, VVv5LU, 4, boundFunction(self.VVmgkR, VVv5LU))
 def VVmgkR(self, VVv5LU, item):
  self.VVu1nc(VVv5LU, item, 4, self.VV2pbh)
 def VVkAxy(self, VVv5LU, title, txt, colList):
  self.filterObj.VV1am9(0, VVv5LU, 4, boundFunction(self.VVGxDt, VVv5LU))
 def VVGxDt(self, VVv5LU, item):
  self.VVu1nc(VVv5LU, item, 4, self.VVDAlG)
 def VVu1nc(self, VVv5LU, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVv5LU.VVaisE(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVF2FG = None
  else:
   words, asPrefix = CCHLQj.VVfQLS(words)
   self.VVF2FG = [col, words, asPrefix]
  if words: FFxBTP(self, boundFunction(self.VVyKO6, VVv5LU, title, mode), title="Reading Services ...")
  else : FFuCKD(VVv5LU, "Incorrect filter", 2000)
 def VVyKO6(self, VVv5LU, title, mode):
  VVaXgj = CCLdzJ.VVj0Np(self, mode, VV35ot=self.VVF2FG, VVs2Hw=False)
  if VVaXgj:
   VVaXgj.sort(key=lambda x: x[0].lower())
   VVv5LU.VVFYEc(VVaXgj, title)
  else:
   VVv5LU.VVczFt()
   FFuCKD(VVv5LU, "Not found!", 1500)
 def VVvpws(self, VVplFV, VVnutX=None, VVmtel=None, VVyT4T=None, VV5ydd=None, VVxHB1=None, VV487W=None):
  VV5ydd = ("Current Service", self.VVgUPe, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVdQl9 = (LEFT  , LEFT  , CENTER, LEFT    )
  FFlZ9Z(self, None, header=header, VVplFV=VVplFV, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=26, VVnutX=VVnutX, VVmtel=VVmtel, VVyT4T=VVyT4T, VV5ydd=VV5ydd, VVxHB1=VVxHB1, VV487W=VV487W)
 def VVgUPe(self, VVv5LU, title, txt, colList):
  self.VVlFlu(VVv5LU)
 def VVSnqr(self, VVv5LU, title, txt, colList):
  self.VVlFlu(VVv5LU, True)
 def VVlFlu(self, VVv5LU, isFromDetails=False):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
  if refCode:
   if isFromDetails:
    chName  = info.getName()
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVv5LU.VVfZXt(colDict, VVKlD3=True)
   else:
    VVv5LU.VVmn28(3, refCode, True)
   return
  FFkZTy(self, "Colud not read current Reference Code !")
 def VVZJ7Y(self):
  self.VVF2FG = None
  self.lastfilterUsed  = None
  self.filterObj   = CCHLQj(self)
  VVaXgj = CCLdzJ.VVj0Np(self, self.VVDAlG)
  if VVaXgj:
   VVaXgj.sort(key=lambda x: x[0].lower())
   VVmtel = (""    , self.VVrSCn , []      )
   VV5ydd = ("Current Service", self.VVSnqr  , []      )
   VV487W = ("Filter"   , self.VVkAxy   , [], "Loading Filters ..." )
   VVnutX  = ("Zap"   , self.VVmvoU      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVdQl9  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFlZ9Z(self, None, header=header, VVplFV=VVaXgj, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=26, VVnutX=VVnutX, VVmtel=VVmtel, VV5ydd=VV5ydd, VV487W=VV487W)
 def VVrSCn(self, VVv5LU, title, txt, colList):
  refCode  = self.VV7lzP(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFgCFv(self, fncMode=CClBuf.VVUJPy, refCode=refCode, chName=chName, text=txt)
 def VVmvoU(self, VVv5LU, title, txt, colList):
  refCode = self.VV7lzP(colList)
  FFyH61(self, refCode)
 def VVbu6D(self, VVv5LU, title, txt, colList):
  FFyH61(self, colList[3])
 def VV7lzP(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVj0Np(SELF, mode, VV35ot=None, VVs2Hw=True, VVC4JZ=True):
  lamedbFile, disabledFile = CCLdzJ.VVUlwt()
  if fileExists(lamedbFile):
   asPrefix = False
   if VV35ot:
    filterCol = VV35ot[0]
    filterWords = VV35ot[1]
    asPrefix = VV35ot[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCLdzJ.VVgJzx:
    blackList = None
    path = "/etc/enigma2/blacklist"
    if fileExists(path):
     blackList = FFghv7(path)
     if blackList:
      blackList = set(blackList)
   elif mode == CCLdzJ.VV2pbh:
    tp = CCs7Me()
   VViiKj, VV66Bz = FFBt2Q()
   tagFound  = False
   if mode in (CCLdzJ.VV4nmj, CCLdzJ.VVQwO2):
    VVaXgj = {}
   else:
    VVaXgj = []
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFciDZ(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CCLdzJ.VVDAlG:
        if sTypeInt in VViiKj:
         STYPE = VV66Bz[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVaXgj.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVaXgj.append(tRow)
        else:
         VVaXgj.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCLdzJ.VV4nmj:
         VVaXgj[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCLdzJ.VVQwO2:
         VVaXgj[chName] = refCode
        elif mode == CCLdzJ.VVgJzx:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVaXgj.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVaXgj.append(tRow)
         else:
          VVaXgj.append(tRow)
        elif mode == CCLdzJ.VV2pbh:
         if sTypeInt in VViiKj:
          STYPE = VV66Bz[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVC53J(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVaXgj.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVaXgj.append(tRow)
         else:
          VVaXgj.append(tRow)
        elif mode == CCLdzJ.VVKEUK:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VVaXgj.append((chName, chProv, sat, refCode))
        elif mode == CCLdzJ.VVDcPa:
         VVaXgj.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VVaXgj and VVs2Hw:
    FFkZTy(SELF, "No services found!")
   return VVaXgj
  else:
   if VVC4JZ:
    FFLxgb(SELF, lamedbFile)
   return None
 def VVdLX3(self):
  path = "/etc/enigma2/blacklist"
  if fileExists(path):
   lines = FFghv7(path)
   if lines:
    newRows  = []
    VVaXgj = CCLdzJ.VVj0Np(self, self.VVDcPa)
    if VVaXgj:
     lines = set(lines)
     for item in VVaXgj:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVaXgj = newRows
      VVaXgj.sort(key=lambda x: x[0].lower())
      VVmtel = ("", self.VVhZMc, [])
      VVnutX = ("Zap", self.VVbu6D, [])
      self.VVvpws(VVplFV=VVaXgj, VVnutX=VVnutX, VVmtel=VVmtel)
     else:
      FFXXd4(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVaXgj)))
   else:
    FFUwJf(self, "No active Parental Control services.", FFevP0())
  else:
   FFLxgb(self, path)
 def VVGH6h(self):
  VVaXgj = CCLdzJ.VVj0Np(self, self.VVKEUK)
  if VVaXgj:
   VVaXgj.sort(key=lambda x: x[0].lower())
   VVmtel = ("" , self.VVhZMc, [])
   VVnutX  = ("Zap", self.VVbu6D, [])
   self.VVvpws(VVplFV=VVaXgj, VVnutX=VVnutX, VVmtel=VVmtel)
  else:
   FFUwJf(self, "No hidden services.", FFevP0())
 def VVRA6c(self):
  totT, totC, totA, totS, totS2, satList = self.VV6Izo()
  txt = FFu1AK("Total Transponders:\n\n", VVNRRl)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFu1AK("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVNRRl)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FF3mUD(item), satList.count(item))
  FFXXd4(self, txt)
 def VV6Izo(self):
  lamedbFile, disabledFile = CCLdzJ.VVUlwt()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFLxgb(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VVuBre(self)   : self.VVlgzX(True)
 def VVWxSe(self) : self.VVlgzX(False)
 def VVlgzX(self, isWithPIcons):
  piconsPath = CCczfG.VVpOjs()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCczfG.VVVvYS(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVaXgj = CCLdzJ.VVj0Np(self, self.VVDcPa)
    if VVaXgj:
     channels = []
     for (chName, chProv, sat, refCode) in VVaXgj:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFNjmV(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVaXgj)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VV4FHA(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VV4FHA("PIcons Path"  , piconsPath)
     txt += VV4FHA("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VV4FHA("Total services" , totalServices)
     txt += VV4FHA("With PIcons"  , totalWithPIcons)
     txt += VV4FHA("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFXXd4(self, txt)
     else:
      VVmtel     = (""      , self.VVhZMc , [])
      if isWithPIcons : VV487W = ("Export Current PIcon", self.VVFz2H  , [])
      else   : VV487W = None
      VVxHB1     = ("Statistics", FFXXd4, [txt])
      VVnutX      = ("Zap", self.VVbu6D, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVvpws(VVplFV=channels, VVnutX=VVnutX, VVmtel=VVmtel, VVxHB1=VVxHB1, VV487W=VV487W)
   else:
    FFkZTy(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFkZTy(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVhZMc(self, VVv5LU, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFgCFv(self, fncMode=CClBuf.VVUJPy, refCode=refCode, chName=chName, text=txt)
 def VVFz2H(self, VVv5LU, title, txt, colList):
  png, path = CCczfG.VVSBo0(colList[3], colList[0])
  if path:
   CCczfG.VVOCcE(self, png, path)
 @staticmethod
 def VVUlwt():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVf5gZ():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVHJYZ(self, isEnable):
  lamedbFile, disabledFile = CCLdzJ.VVUlwt()
  if isEnable and not fileExists(disabledFile):
   FFUwJf(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FFkZTy(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFsJwx(self, boundFunction(self.VV3bdr, isEnable), "%s Hidden Channels ?" % word)
 def VV3bdr(self, isEnable):
  lamedbFile , disabledFile = CCLdzJ.VVUlwt()
  lamedb5File, diabled5File = CCLdzJ.VVf5gZ()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFXgo1()
  if res == 0 : FFUwJf(self, "Hidden List %s" % word)
  else  : FFkZTy(self, "Error while restoring:\n\n%s" % fileName)
 def VVGcB0(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFSndt(self, cmd)
 def VVUGqH(self):
  lamedbFile, disabledFile = CCLdzJ.VVUlwt()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFxZhj("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFghv7(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFxZhj("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFXgo1()
   FFXXd4(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFLxgb(self, lamedbFile)
class CClBuf(Screen):
 VVdrg2  = 0
 VVk2Nt   = 1
 VV7FwT   = 2
 VVUJPy    = 3
 VVVEIi    = 4
 VVKZcD   = 5
 VVvA7r   = 6
 VVYIMG    = 7
 VVJ5BI   = 8
 VVt81y   = 9
 VVmbei   = 10
 VVwWYF   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FF65g3(VVq7g2, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVdrg2)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFu1AK("%s\n", VVLXD9) % VVyYSf
  FFC1qE(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVtxAy })
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  self["myLabel"].VVWjn0(textOutFile="chann_info")
  if   self.fncMode == self.VVdrg2 : fnc = self.VV3LHU_VVdrg2
  elif self.fncMode == self.VVk2Nt  : fnc = self.VV3LHU_VVdrg2
  elif self.fncMode == self.VV7FwT  : fnc = self.VV3LHU_VVdrg2
  elif self.fncMode == self.VVUJPy  : fnc = self.VV3LHU_VVUJPy
  elif self.fncMode == self.VVVEIi  : fnc = self.VV3LHU_VVVEIi
  elif self.fncMode == self.VVKZcD  : fnc = self.VV3LHU_VVKZcD
  elif self.fncMode == self.VVvA7r  : fnc = self.VV3LHU_VVvA7r
  elif self.fncMode == self.VVYIMG  : fnc = self.VV3LHU_VVYIMG
  elif self.fncMode == self.VVJ5BI  : fnc = self.VV3LHU_VVJ5BI
  elif self.fncMode == self.VVt81y : fnc = self.VV3LHU_VVt81y
  elif self.fncMode == self.VVmbei  : fnc = self.VV3LHU_VVmbei
  elif self.fncMode == self.VVwWYF : fnc = self.VV3LHU_VVwWYF
  self["myLabel"].setText("\n   Reading Info ...")
  FF4knh(fnc)
 def VVRuu3(self, err):
  self["myLabel"].setText(err)
  FFc3QD(self["myTitle"], "#22200000")
  FFc3QD(self["myBody"], "#22200000")
  self["myLabel"].FFc3QDColor("#22200000")
  self["myLabel"].VVtJrC()
 def VV3LHU_VVdrg2(self):
  try:
   dum = self.session
  except:
   return
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
  self.refCode = refCode
  self.VVQCyT(chName)
 def VV3LHU_VVUJPy(self):
  self.VVQCyT(self.chName)
 def VV3LHU_VVVEIi(self):
  self.VVQCyT(self.chName)
 def VV3LHU_VVKZcD(self):
  self.VVQCyT(self.chName)
 def VV3LHU_VVvA7r(self):
  self.VVQCyT("Picon Info")
 def VV3LHU_VVYIMG(self):
  self.VVQCyT(self.chName)
 def VV3LHU_VVJ5BI(self):
  self.VVQCyT(self.chName)
 def VV3LHU_VVt81y(self):
  self.VVQCyT(self.chName)
 def VV3LHU_VVmbei(self):
  self.chUrl = self.refCode + self.callingSELF.VVoYbJ(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVQCyT(self.chName)
 def VV3LHU_VVwWYF(self):
  self.VVQCyT(self.chName)
 def VVQCyT(self, title):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVgiW9(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFu1AK(self.VVqrT6(tUrl), VVKXn9)
  if not self.epg:
   epg = self.VV6FbQ(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVVwpi(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCczfG.VVSBo0(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVVwpi(path)
  self.VVGxvR()
  self.VV0QNO()
  self["myLabel"].setText(self.text, VV66pN=VVY6j5)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVtJrC(minHeight=minH)
 def VV0QNO(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFj0hS(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VV1dpa(FFwWRV(url))
  if epg:
   self.text += "\n" + FFWpRC("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVGxvR()
 def VVGxvR(self):
  if not self.piconShown and self.picUrl:
   path, err = FFPMCM(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVVwpi(path)
    if self.piconShown and self.refCode:
     self.VVWphG(path, self.refCode)
 def VVWphG(self, path, refCode):
  if path and fileExists(path) and os.system(FFxZhj("which ffmpeg")) == 0:
   pPath = CCczfG.VVpOjs()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
    cmd += FFxZhj("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVVwpi(self, path):
  if path and fileExists(path):
   err, w, h = self.VVBwAp(path)
   if not err:
    if h > w:
     self.VVnel3(self["myPicF"], w, h, True)
     self.VVnel3(self["myPic"] , w, h, False)
   allOK = FFg5SC(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVnel3(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVBwAp(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFoABH(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVgiW9(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFu1AK(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VV4FHA(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFu1AK(state, VVGMgi)
   txt += "State\t: %s\n" % state
  w = FFY7OE(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFY7OE(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VV3gcV(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VV4FHA(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VV4FHA(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VV4FHA(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVWHK8()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VV03BK()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CClBuf.VVl6cG(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFu1AK("IPTV", VVNRRl)
   txt += self.VVmoJN(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVS3js(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCs7Me()
    tpTxt, namespace = tp.VVm0i2(refCode)
    del tp
    if tpTxt:
     txt += FFu1AK("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFu1AK("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VV4FHA(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VV4FHA(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VV4FHA(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VV4FHA(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VV4FHA(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VV4FHA(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VV4FHA(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VV4FHA(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VV4FHA(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VV3gcV(info):
  if info:
   aspect = FFY7OE(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VV4FHA(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFY7OE(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVlgN6(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVlgN6(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVWHK8(self):
  try:
   service = self.session.nav.getCurrentService()
   audio = service and service.audioTracks()
   return audio and audio.getNumberOfTracks() or 0
  except:
   pass
  return -1
 def VV03BK(self):
  try:
   service   = self.session.nav.getCurrentService()
   subtitle  = service and service.subtitle()
   subtitlelist = subtitle and subtitle.getSubtitleList()
   return len(subtitlelist)
  except:
   pass
  return -1
 def VVS3js(self, refCode, iptvRef, chName):
  refCode = FFskjD(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFQiI5(VVV3TR + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFQiI5(VVV3TR + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVplFV = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVV3TR + item
   if fileExists(path):
    txt = FFQiI5(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVplFV.append(bName)
  txt = self.Sep
  if VVplFV:
   if len(VVplFV) == 1:
    txt += "%s\t: %s\n" % (FFu1AK("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VVplFV[0])
   else:
    txt += FFu1AK("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VVplFV):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VV6FbQ(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVkVW5(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVkVW5(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVkVW5(event, 0)
     except:
      pass
  return epg
 def VVkVW5(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName().strip()    or ""
   evTime = event.getBeginTime()      or ""
   evDur = event.getDuration()      or ""
   evShort = event.getShortDescription() .strip() or ""
   evDesc = event.getExtendedDescription().strip() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = self.VVko3P(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FFu1AK(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FFu1AK(evNameTransl, COLOR_CONS_BRIGHT_YELLOW))
    if evTime           : txt += "Start Time\t: %s\n" % FFNSik(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFNSik(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFRxqD(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFRxqD(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFRxqD(evTime - now)
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFu1AK(evShort, VVx5R4)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFu1AK(evDesc , VVx5R4)
    if txt:
     txt = FFu1AK("\n%s\n%s Event:\n%s\n" % (VVyYSf, ("Current", "Next")[evNum], VVyYSf), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVmoJN(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFmuAP(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCOmmp()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVaXSD(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFu1AK("URL:", VVNRRl) + "\n%s\n" % self.VVqrT6(decodedUrl)
  else:
   txt = "\n"
   txt += FFu1AK("Reference:", VVNRRl) + "\n%s\n" % refCode
  return txt
 def VVqrT6(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVsYt6:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VV1dpa(self, decodedUrl):
  if not FFDqwf():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCdgmH.VVinaS(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCdgmH.VVkFgl(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVYQM2(tDict)
   elif uType == "movie" : epg, picUrl = self.VVYPKR(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVYQM2(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCdgmH.VVq4cU(item, "title"    , is_base64=True )
     lang    = CCdgmH.VVq4cU(item, "lang"         ).upper()
     description   = CCdgmH.VVq4cU(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCdgmH.VVq4cU(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCdgmH.VVq4cU(item, "start_timestamp"      )
     stop_timestamp  = CCdgmH.VVq4cU(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCdgmH.VVq4cU(item, "stop_timestamp"       )
     now_playing   = CCdgmH.VVq4cU(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVO6Kg, ""
      else     : color, txt = VVGMgi , "    (CURRENT EVENT)"
      epg += FFu1AK("_" * 32 + "\n", VVLXD9)
      epg += FFu1AK("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFu1AK(description, VVKXn9)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVyZuo(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVYPKR(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCdgmH.VVq4cU(item, "movie_image" )
    genre  = CCdgmH.VVq4cU(item, "genre"   ) or "-"
    plot  = CCdgmH.VVq4cU(item, "plot"   ) or "-"
    cast  = CCdgmH.VVq4cU(item, "cast"   ) or "-"
    rating  = CCdgmH.VVq4cU(item, "rating"   ) or "-"
    director = CCdgmH.VVq4cU(item, "director"  ) or "-"
    releasedate = CCdgmH.VVq4cU(item, "releasedate" ) or "-"
    duration = CCdgmH.VVq4cU(item, "duration"  ) or "-"
    try:
     lang = CCdgmH.VVq4cU(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFu1AK(cast, VVKXn9)
    epg += "Plot:\n%s"    % FFu1AK(self.VVko3P(plot), VVKXn9)
   except:
    pass
  return epg, movie_image
 def VVko3P(self, evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = self.VV4Nvy(evTxt, lang)
   return CClBuf.VV9XhS(txt).strip() or evTxt
 @staticmethod
 def VV9XhS(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VV4Nvy(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFk7NU(txt))
   txt, err = CCdgmH.VVkFgl(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFwWRV(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVyZuo(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VVORra(SELF):
  if not CCiels.VVqslP(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(SELF)
  err = url =  fSize = resumable = ""
  if FFYXBV(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCOmmp.VVy51Q(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCOmmp.VVMHUJHeader(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFkZTy(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CC5T3l.VVfT2w(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFu1AK(" (M3U/M3U8 File)", VVKXn9)
    else:
     fSize = "No info. from server. Try again later."
    hResume = resp.headers.get("Accept-Ranges" , "")
    if hResume:
     if not hResume == "none": resumable = "Yes"
     else     : resumable = "No"
   except requests.Timeout as e     : err = "Connection Timeout"
   except Exception as e       : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVjO6x(subj, val):
   return "%s\n%s\n\n" % (FFu1AK("%s:" % subj, COLOR_CONS_BRIGHT_YELLOW), val)
  title = "File Size"
  txt  = VVjO6x(title , fSize or "?")
  txt += VVjO6x("Name" , chName)
  txt += VVjO6x("URL" , url)
  if resumable: txt += VVjO6x("Supports Download-Resume", resumable)
  if err  : txt += FFu1AK("Error:\n", VVGMgi) + err
  FFXXd4(SELF, txt, title=title)
 @staticmethod
 def VVl6cG(SELF):
  fPath, fDir, fName = CC5T3l.VV31dK(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg", "mvi"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 def VVtxAy(self):
  if VVsYt6:
   def VV4FHA(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
   n = ("info" , "refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (info , refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VV4FHA(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCOmmp()
    valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVaXSD(decodedUrl)
    n = ("valid", "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VV4FHA(n[i], v[i])
   with open("/tmp/ajp_channel_details", "a") as f:
    f.write("%s\n%s\n" % (VVyYSf, txt))
   FFuCKD(self, "Saved to:", 1000)
class CCOmmp():
 def __init__(self):
  self.VVTLwE  = ""
  self.VVyXB0   = ""
  self.VVOzSO  = ""
  self.portal_rand  = ""
  self.portal_moreAuth = False
  self.colored_user  = "#f#11ffffaa#User"
  self.colored_server  = "#f#11aaffff#Server"
 def VVpMzG(self, url, mac, VVKlD3=True):
  self.VVTLwE  = ""
  self.VVyXB0   = ""
  self.VVOzSO  = ""
  self.portal_rand  = ""
  self.portal_moreAuth = False
  host = self.VVJMvr(url)
  if not host:
   if VVKlD3:
    self.VVKlD3or("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVTxHH(mac)
  if not host:
   if VVKlD3:
    self.VVKlD3or("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVTLwE = host
  self.VVyXB0  = mac
  return True
 def VVJMvr(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVTxHH(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVpPt4(self, VVKlD3=True):
  err = blkMsg = FFUwJfTxt = ""
  try:
   token, rand, err = self.VVVbN0()
   if token:
    self.VVOzSO = token
    self.portal_rand  = rand
    prof = self.VVwkRX()
    if prof:
     word = "m" + "sg"
     blkMsg = CCdgmH.VVq4cU(prof["js"], "block_%s" % word)
     FFUwJfTxt = CCdgmH.VVq4cU(prof["js"], word)
     if blkMsg or FFUwJfTxt:
      self.portal_moreAuth = True
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFUwJfTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFUwJfTxt: tErr += "\n%s" % FFUwJfTxt
  if VVKlD3:
   self.VVKlD3or(tErr)
  return "", "", tErr
 def VVVbN0(self):
  res, err = self.VVo8yg(self.VVpNGF())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VVTLwE:
   self.VVTLwE = self.VVTLwE.replace(urlPath, "")
   res, err = self.VVo8yg(self.VVpNGF())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCdgmH.VVq4cU(tDict["js"], "token")
    rand  = CCdgmH.VVq4cU(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVwkRX(self):
  res, err = self.VVo8yg(self.VVlTGu())
  if not err:
   try:
    profJson = jLoads(res.text)
    return profJson
   except:
    pass
  return ""
 def VVSWCM(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVZp6t()
  if len(rows) < 10:
   rows = self.VV0ari()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVTLwE ))
   rows.append(("MAC (from URL)" , self.VVyXB0 ))
   rows.append(("Token"   , self.VVOzSO ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VVyXB0 ))
   rows.append(("2", self.colored_server, "Host" , self.VVTLwE ))
   rows.append(("2", self.colored_server, "Token" , self.VVOzSO ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VV6Yxm(self, isPhp=True, VVKlD3=False):
  token, profile, tErr = self.VVpPt4(VVKlD3)
  if not token:
   return "", tErr
  m3u_Url = ""
  url = self.VV1H6k()
  res, err = self.VVo8yg(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCdgmH.VVq4cU(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFk7NU(span.group(2))
     pass1 = FFk7NU(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, err
 def VVZp6t(self):
  m3u_Url, err = self.VV6Yxm()
  rows = []
  if m3u_Url:
   res, err = self.VVo8yg(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFNSik(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFNSik(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VV0ari(self):
  token, profile, tErr = self.VVpPt4()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FF5uxe(val): val = FFxsRA(val.decode("UTF-8"))
     else     : val = self.VVyXB0
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFNSik(int(parts[1]))
      if parts[2] : ends = FFNSik(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFNSik(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVoYbJ(self, mode, chCm, epNum, epId):
  crLinkUrl = self.VVZo1G(mode, chCm, epNum, epId)
  token, profile, tErr = self.VVpPt4(VVKlD3=False)
  if not token:
   return ""
  res, err = self.VVo8yg(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCdgmH.VVq4cU(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  return chUrl
 def VVct0h(self):
  return self.VVTLwE + "/server/load.php?"
 def VVpNGF(self):
  return self.VVct0h() + "type=stb&action=handshake&token=&mac=%s" % self.VVyXB0
 def VVlTGu(self):
  if self.portal_moreAuth:
   import hashlib
   sn    = hashlib.md5(self.VVyXB0).hexdigest().upper()[:13]
   param  = ""
   param += "&sn=%s"   % sn
   param += "&device_id=%s" % hashlib.sha256(sn).hexdigest().upper()
   param += "&device_id2=%s" % hashlib.sha256(self.VVyXB0).hexdigest().upper()
   param += "&signature=%s" % hashlib.sha256(sn + self.VVyXB0).hexdigest().upper()
   param += '&auth_second_step=1'
   param += '&hw_version=2.17-IB-00&hw_version_2=62'
   param += '&metrics={"mac":"%s","sn":"%s","type":"STB","model":"MAG250","random":"%s"}' % (self.VVyXB0, sn, self.portal_rand)
  else:
   param = ""
  return self.VVct0h() + "type=stb&action=get_profile" + param
 def VVTZgG(self, mode):
  url = self.VVct0h() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVN6MR(self, catID):
  return self.VVct0h() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVj2xu(self, mode, catID, page):
  url = self.VVct0h() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "series" : url += "category=%s" % catID
  else    : url += "genre=%s&force_ch_link_check=" % catID
  return url
 def VVYbTi(self, mode, searchName, page):
  return self.VVct0h() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VV5FJ4(self, mode, catID):
  return self.VVct0h() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVZo1G(self, mode, chCm, serCode, serId):
  url = self.VVct0h() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VV1H6k(self):
  return self.VVct0h() + "type=itv&action=create_link"
 def VVmZyF(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVgfbn(catID, stID, chNum)
  query = self.VV8fVB(mode, FFt6Xa(host), FFt6Xa(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VV8fVB(self, mode, host, mac, serCode, serId, chCm):
  query = "mode=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVaXSD(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VV8fVB(mode, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFxsRA(host)
  mac   = FFxsRA(mac)
  valid = False
  if self.VVJMvr(playHost) and self.VVJMvr(host) and self.VVJMvr(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVo8yg(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCOmmp.VVMHUJHeader()
   if self.VVOzSO:
    headers["Authorization"] = "Bearer %s" % self.VVOzSO
   if useCookies : cookies = {"mac": self.VVyXB0, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok : return res, ""
   else  : err = "Err-%d : %s" % (res.status_code, res.reason or "Unknown")
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVEWTz(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCOmmp.VVMHUJHeader(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVMHUJHeader():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVOybm(host, mac, tType, action, keysList=[]):
  myPortal = CCOmmp()
  ok = myPortal.VVpMzG(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVpPt4(VVKlD3=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VVo8yg(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVfOo8(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVfOo8(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVKlD3or(self, err, title="Portal Browser"):
  FFkZTy(self, str(err), title=title)
 def VVDFNv(self, mode):
  if   mode in ("itv"  , CCdgmH.VVgaS0 , CCdgmH.VVHZdq)  : return "Live"
  elif mode in ("vod"  , CCdgmH.VVJow5 , CCdgmH.VVaL7U)  : return "VOD"
  elif mode in ("series" , CCdgmH.VVISom , CCdgmH.VVYuEm) : return "Series"
  else                          : return "IPTV"
 def VVV1JZ(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVDFNv(mode), searchName)
 def VVYVM8(self, catchup=False):
  VV4YjP = []
  VV4YjP.append(("Live"    , "live"  ))
  VV4YjP.append(("VOD"    , "vod"   ))
  VV4YjP.append(("Series"   , "series"  ))
  if catchup:
   VV4YjP.append(VV32Zp)
   VV4YjP.append(("Catchup TV" , "catchup"  ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Account Info." , "accountInfo" ))
  return VV4YjP
 @staticmethod
 def VVwFeJ(decodedUrl):
  m3u_Url = ""
  p = CCOmmp()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVaXSD(decodedUrl)
  if valid:
   ok = p.VVpMzG(host, mac, VVKlD3=False)
   if ok:
    m3u_Url, err = p.VV6Yxm(isPhp=False, VVKlD3=False)
    span = iSearch(r".+ch\/(.+)_", decodedUrl, IGNORECASE)
    if span:
     m3u_Url += span.group(1)
  return m3u_Url
 @staticmethod
 def VVy51Q(decodedUrl):
  p = CCOmmp()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVaXSD(decodedUrl)
  if valid:
   ok = p.VVpMzG(host, mac, VVKlD3=False)
   if ok:
    try:
     chUrl = p.VVoYbJ(mode, chCm, epNum, epId)
     return FFwWRV(chUrl)
    except Exception as e:
     pass
  return ""
class CC8eJk(CCOmmp):
 def __init__(self):
  CCOmmp.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVUOih(self, refCode, chName, decodedUrl, iptvRef):
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVaXSD(decodedUrl)
  if valid:
   if self.VVpMzG(host, mac, VVKlD3=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVBR98(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVoYbJ(self.mode, self.chCm, self.epNum, self.epId)
  except:
   pass
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = self.refCode + chUrl.strip() + ":" + self.chName
  newIptvRef = self.VV274Z(chUrl)
  if newIptvRef:
   success = self.VVJeeo(self.iptvRef, newIptvRef)
   if passedSELF:
    FFyH61(passedSELF, newIptvRef, VVuGQM=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFyH61(self, newIptvRef, VVuGQM=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VV274Z(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVJeeo(self, oldCode, newCode):
  bPath = FFsS4k()
  if bPath:
   txt = FFQiI5(bPath)
   if oldCode in txt:
    txt = txt.replace(oldCode, newCode)
    with open(bPath, "w") as f:
     f.write(txt)
    FFXgo1()
    return True
  return False
class CCHiBh(CC8eJk):
 def __init__(self, passedSession):
  CC8eJk.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.starttime  = iTime()
  self.timer1   = eTimer()
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVRG4I, iPlayableService.evEOF: self.VVVjW9, iPlayableService.evEnd: self.VVmTue})
  except:
   pass
 def VVRG4I(self):
  self.starttime = iTime()
 def VVVjW9(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.starttime) > 2:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self.passedSession, isFromSession=True)
    if iptvRef and not FFYXBV(decodedUrl):
     CCLFbh(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
 def VVmTue(self):
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VV8b3H)
  except:
   self.timer1.callback.append(self.VV8b3H)
  self.timer1.start(100, True)
 def VV8b3H(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self.passedSession, isFromSession=True)
  valid = False
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if not ref == self.lastRef:
     valid = self.VVUOih(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if not CCnyHZ.VV7Kcw:
       self.VVBR98(self.passedSession, isFromSession=True)
class CCdnf7():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.nameTagPatt = r"\s*[\[(|:].*[\])|:](.+)|\s*(?:[^a-z]+:)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
 def VVqM1G(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCdgmH.VVbIyV(name):
   return CCdgmH.VVLgN9(name)
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    name = span.group(1) or span.group(2)
  return name.strip() or name
 def VVVUxR(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  span = iSearch(self.nameTagPatt, name)
  if span:
   name = span.group(1) or span.group(2)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVlP34(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  else:
   return name.strip()
 def VVg5gs(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VV8DWM(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCiels(CCOmmp):
 def __init__(self):
  CCOmmp.__init__(self)
 def VV2mW1(self):
  if CCiels.VVqslP(self):
   FFxBTP(self, self.VVkmsC, title="Searching ...")
 def VVAgES(self, winSession, url, mac):
  if CCiels.VVqslP(self):
   if self.VVpMzG(url, mac):
    FFxBTP(winSession, self.VV5Ray, title="Checking Server ...")
   else:
    FFkZTy(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVkmsC(self):
  path = CCdgmH.VViKUI()
  lines = FFwhw7('find %s %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % (path, FFomXb(1)))
  if lines:
   lines.sort()
   VV4YjP = []
   for line in lines:
    VV4YjP.append((line, line))
   OKBtnFnc = self.VVjRz6
   VVRGLF = ("Delete File", boundFunction(self.VVDBFK, boundFunction(FFxBTP, self, self.VVkmsC, title="Searching ...")))
   FF2oO5(self, None, title="Select Portals File", VV4YjP=VV4YjP, width=1200, OKBtnFnc=OKBtnFnc, VVRGLF=VVRGLF)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFkZTy(self, 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt)
 def VVDBFK(self, cbFnc, VV0IKZObj, path):
  FFsJwx(self, boundFunction(self.VV7lB5, cbFnc, VV0IKZObj, path), "Delete this file ?\n\n%s" % path)
 def VV7lB5(self, cbFnc, VV0IKZObj, path):
  os.system(FFxZhj("rm -f '%s'" % path))
  VV0IKZObj.cancel()
  FF4knh(cbFnc)
 def VVjRz6(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = FFEprZ(path, self)
   if enc == -1:
    return
   self.session.open(CC1Mzj, barTheme=CC1Mzj.VVEZCt
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVvf22, path, enc)
       , VVnyfB = boundFunction(self.VVcuIp, menuInstance, path))
 def VVvf22(self, path, enc, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  progBarObj.VVR6pW(totLines)
  progBarObj.VVCGmK = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVZ46l(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVJMvr(url)
     mac  = self.VVTxHH(mac)
     if host and mac and progBarObj:
      progBarObj.VVCGmK.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVJMvr(url)
      mac  = self.VVTxHH(mac)
      if host and mac and not mac.startswith("AC") and progBarObj:
       progBarObj.VVCGmK.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVcuIp(self, menuInstance, path, VVj61p, VVCGmK, threadCounter, threadTotal, threadErr):
  title = "Portals List File"
  if VVCGmK:
   VVyT4T  = ("Home Menu", FFCjjG, [])
   VV487W  = None #("Check & Filter" , boundFunction(self.filterPortalAuthorizedServers, path), [])
   VVxHB1 = ("Edit File" , boundFunction(self.VVYyBP, path) , [])
   VV5ydd = ("Open as M3U", self.VVmkbd     , [])
   VVnutX  = ("Select"  , self.VVAgES_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVdQl9  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVv5LU = FFlZ9Z(self, None, title=title, header=header, VVplFV=VVCGmK, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=26, VVnutX=VVnutX, VVyT4T=VVyT4T, VV5ydd=VV5ydd, VVxHB1=VVxHB1, VV487W=VV487W, VVZidB="#0a001122", VVCOuJ="#0a001122", VVQfS4="#0a001122", VVJk0D="#00004455", VVJSW4="#0a333333", VVpNa2="#11331100", VVwbEy=True, searchCol=1)
   if not VVj61p:
    FFuCKD(VVv5LU, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVj61p:
    FFkZTy(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVmkbd(self, VVv5LU, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  FFxBTP(VVv5LU, boundFunction(self.VV2neu, VVv5LU, host, mac), title="Checking Server ...")
 def VV2neu(self, VVv5LU, host, mac):
  p = CCOmmp()
  m3u_Url = ""
  ok = p.VVpMzG(host, mac, VVKlD3=False)
  err = ""
  if ok:
   m3u_Url, err = p.VV6Yxm(VVKlD3=False)
  title = "Browsing M3U Server from Portal Data"
  if m3u_Url:
   self.VVLlzO(title, m3u_Url)
  else:
   FFkZTy(self, err or "No response from Server !", title=title)
 def VVAgES_fromMacFiles(self, VVv5LU, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVAgES(VVv5LU, url, mac)
 def VVYyBP(self, path, VVv5LU, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCU5Qm(self, path, VVnyfB=boundFunction(self.VV5ixj, VVv5LU), curRowNum=rowNum)
  else    : FFLxgb(self, path)
 def VV3YqT(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFxsRA(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VV5Ray(self):
  token, profile, tErr = self.VVpPt4()
  if token:
   VV4YjP  = self.VVYVM8()
   OKBtnFnc = self.VVfhYz
   VVUWK6 = ("Home Menu", FFCjjG)
   VVlEXM = ("Bookmark Server", boundFunction(CCdgmH.VViEnd, self, True, self.VVTLwE + "\t" + self.VVyXB0))
   authMore = ".." if self.portal_moreAuth else ""
   FF2oO5(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVyXB0, authMore), VV4YjP=VV4YjP, OKBtnFnc=OKBtnFnc, VVUWK6=VVUWK6, VVlEXM=VVlEXM)
 def VVfhYz(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFxBTP(menuInstance, boundFunction(self.VVPFMP, mode), title="Reading Categories ...")
   else : FFxBTP(menuInstance, boundFunction(self.VVQd9L, menuInstance, title), title="Reading Account ...")
 def VVQd9L(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVSWCM(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVyXB0)
  VVyT4T  = ("Home Menu" , FFCjjG, [])
  if totCols == 2:
   VV487W = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
   VV487W = ("More Info.", boundFunction(self.VVunpi, menuInstance) , [])
  FFlZ9Z(self, None, title=title, width=1200, header=header, VVplFV=rows, VVbohG=widths, VVIUEO=26, VVyT4T=VVyT4T, VV487W=VV487W, VVZidB="#0a00292B", VVCOuJ="#0a002126", VVQfS4="#0a002126", VVJk0D="#00000000", searchCol=searchCol)
 def VVunpi(self, menuInstance, VVv5LU, title, txt, colList):
  VVv5LU.cancel()
  FFxBTP(menuInstance, boundFunction(self.VVQd9L, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVPFMP(self, mode):
  token, profile, tErr = self.VVpPt4()
  if not token:
   return
  res, err = self.VVo8yg(self.VVTZgG(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CCdnf7()
     chList = tDict["js"]
     for item in chList:
      Id   = CCdgmH.VVq4cU(item, "id"       )
      Title  = CCdgmH.VVq4cU(item, "title"      )
      censored = CCdgmH.VVq4cU(item, "censored"     )
      Title = processChanName.VVlP34(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VV6vw4:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVDFNv(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVZidB, VVCOuJ, VVQfS4, VVJk0D = self.VV9Ys0(mode)
   mName = self.VVDFNv(mode)
   VVnutX   = ("Show List"   , boundFunction(self.VVB4LP, mode) , [])
   VVyT4T  = ("Home Menu"   , FFCjjG         , [])
   if mode in ("vod", "series"):
    VVxHB1 = ("Find in %s" % mName , boundFunction(self.VVVfbY, mode), [])
   else:
    VVxHB1 = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFlZ9Z(self, None, title=title, width=1200, header=header, VVplFV=list, VVbohG=widths, VVIUEO=30, VVyT4T=VVyT4T, VVxHB1=VVxHB1, VVnutX=VVnutX, VVZidB=VVZidB, VVCOuJ=VVCOuJ, VVQfS4=VVQfS4, VVJk0D=VVJk0D)
  else:
   s = "Authorization failed"
   if err    : txt = err
   elif s in res.text : txt = s
   else    : txt = "Could not get Categories from server!"
   FFkZTy(self, txt, title=title)
 def VVKbt9(self, mode, VVv5LU, title, txt, colList):
  FFxBTP(VVv5LU, boundFunction(self.VVdDQu, mode, VVv5LU, title, txt, colList), title="Downloading ...")
 def VVdDQu(self, mode, VVv5LU, title, txt, colList):
  token, profile, tErr = self.VVpPt4()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVo8yg(self.VVN6MR(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCdgmH.VVq4cU(item, "id"    )
      actors   = CCdgmH.VVq4cU(item, "actors"   )
      added   = CCdgmH.VVq4cU(item, "added"   )
      age    = CCdgmH.VVq4cU(item, "age"   )
      category_id  = CCdgmH.VVq4cU(item, "category_id" )
      description  = CCdgmH.VVq4cU(item, "description" )
      director  = CCdgmH.VVq4cU(item, "director"  )
      genres_str  = CCdgmH.VVq4cU(item, "genres_str"  )
      name   = CCdgmH.VVq4cU(item, "name"   )
      path   = CCdgmH.VVq4cU(item, "path"   )
      screenshot_uri = CCdgmH.VVq4cU(item, "screenshot_uri" )
      series   = CCdgmH.VVq4cU(item, "series"   )
      cmd    = CCdgmH.VVq4cU(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VVnutX  = ("Play"    , boundFunction(self.VV2ziI, mode)       , [])
   VVmtel = (""     , boundFunction(self.VVOhsA, mode)     , [])
   VVyT4T = ("Home Menu"   , FFCjjG               , [])
   VV5ydd = ("Download Options" , boundFunction(self.VVLzfo, mode, "sp", seriesName) , [])
   VVxHB1 = ("Add ALL to Bouquet" , boundFunction(self.VV2NM5, mode, seriesName)  , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVdQl9  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFlZ9Z(self, None, title=seriesName, width=1200, header=header, VVplFV=list, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=26, VVyT4T=VVyT4T, VV5ydd=VV5ydd, VVxHB1=VVxHB1, VVnutX=VVnutX, VVmtel=VVmtel, VVZidB="#0a00292B", VVCOuJ="#0a002126", VVQfS4="#0a002126", VVJk0D="#00000000")
  else:
   FFkZTy(self, "Could not get Episodes from server!", title=seriesName)
 def VVVfbY(self, mode, VVv5LU, title, txt, colList):
  VV4YjP = []
  VV4YjP.append(("Keyboard"  , "manualEntry"))
  VV4YjP.append(("From Filter" , "fromFilter"))
  FF2oO5(self, boundFunction(self.VVOpdS, VVv5LU, mode), title="Input Type", VV4YjP=VV4YjP, width=400)
 def VVOpdS(self, VVv5LU, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFmIMB(self, boundFunction(self.VVMutn, VVv5LU, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCHLQj(self)
    filterObj.VV0VYy(boundFunction(self.VVMutn, VVv5LU, mode))
 def VVMutn(self, VVv5LU, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VVV1JZ(mode, searchName)
   if len(searchName) < 3:
    FFkZTy(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CCdnf7()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVg5gs([searchName]):
     FFkZTy(self, processChanName.VV8DWM(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVmYLI(mode, searchName, "", searchName)
 def VVB4LP(self, mode, VVv5LU, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVmYLI(mode, bName, catID, "")
 def VVmYLI(self, mode, bName, catID, searchName):
  self.session.open(CC1Mzj, barTheme=CC1Mzj.VVEZCt
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVRtQb, mode, bName, catID, searchName)
      , VVnyfB = boundFunction(self.VVpyyH, mode, bName, catID, searchName))
 def VVpyyH(self, mode, bName, catID, searchName, VVj61p, VVCGmK, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVV1JZ(mode, searchName)
  else   : title = "%s : %s" % (self.VVDFNv(mode), bName)
  if VVCGmK:
   VV5ydd = None
   VVxHB1 = None
   if mode == "series":
    VVZidB, VVCOuJ, VVQfS4, VVJk0D = self.VV9Ys0("series2")
    VVnutX  = ("Episodes", boundFunction(self.VVKbt9, mode) , [])
   else:
    VVZidB, VVCOuJ, VVQfS4, VVJk0D = self.VV9Ys0("")
    VVnutX  = ("Play"    , boundFunction(self.VV2ziI, mode)           , [])
    VVxHB1 = ("Add ALL to Bouquet" , boundFunction(self.VV2NM5, mode, bName)       , [])
    VV5ydd = ("Download Options" , boundFunction(self.VVLzfo, mode, "vp" if mode == "vod" else "", "") , [])
   VVmtel = (""      , boundFunction(self.VVXAGT, mode)          , [])
   VVyT4T = ("Home Menu"    , FFCjjG                   , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVdQl9  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT )
   VVv5LU = FFlZ9Z(self, None, title=title, header=header, VVplFV=VVCGmK, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=26, VVyT4T=VVyT4T, VV5ydd=VV5ydd, VVxHB1=VVxHB1, VVnutX=VVnutX, VVmtel=VVmtel, VVZidB=VVZidB, VVCOuJ=VVCOuJ, VVQfS4=VVQfS4, VVJk0D=VVJk0D, VVwbEy=True, searchCol=1)
   if not VVj61p:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVv5LU.VVq2QN(VVv5LU.VVTGuP() + tot)
    if threadErr: FFuCKD(VVv5LU, "Error while reading !", 2000)
    else  : FFuCKD(VVv5LU, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFkZTy(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFkZTy(self, "Could not get list from server !", title=title)
 def VVXAGT(self, mode, VVv5LU, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFgCFv(self, fncMode=CClBuf.VVwWYF, portalHost=self.VVTLwE, portalMac=self.VVyXB0, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVCzuw(mode, VVv5LU, title, txt, colList)
 def VVOhsA(self, mode, VVv5LU, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFu1AK(colList[10], VVKXn9)
  txt += "Description:\n%s" % FFu1AK(colList[11], VVKXn9)
  self.VVCzuw(mode, VVv5LU, title, txt, colList)
 def VVCzuw(self, mode, VVv5LU, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVgNoK(mode, colList)
  refCode, chUrl = self.VVmZyF(self.VVTLwE, self.VVyXB0, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFgCFv(self, fncMode=CClBuf.VVmbei, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVRtQb(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile, tErr = self.VVpPt4()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVCGmK, total_items, max_page_items, err = self.VV4bsd(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVCGmK and total_items > -1 and max_page_items > -1:
    progBarObj.VVR6pW(total_items)
    progBarObj.VVZ46l(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VV4bsd(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VVWXKc()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVCGmK += list
      progBarObj.VVZ46l(len(list), True)
  except:
   pass
 def VV4bsd(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVYbTi(mode, searchName, page)
  else   : url = self.VVj2xu(mode, catID, page)
  res, err = self.VVo8yg(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VV0BvR(CCdgmH.VVq4cU(item, "total_items" ))
     max_page_items = self.VV0BvR(CCdgmH.VVq4cU(item, "max_page_items" ))
     processChanName = CCdnf7()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCdgmH.VVq4cU(item, "id"    )
      name   = CCdgmH.VVq4cU(item, "name"   )
      tv_genre_id  = CCdgmH.VVq4cU(item, "tv_genre_id" )
      number   = CCdgmH.VVq4cU(item, "number"   ) or str(counter)
      logo   = CCdgmH.VVq4cU(item, "logo"   )
      screenshot_uri = CCdgmH.VVq4cU(item, "screenshot_uri" )
      cmd    = CCdgmH.VVq4cU(item, "cmd"   )
      cmd = cmd.replace("ffmpeg ", "")
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8"):
       span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      counter += 1
      name = processChanName.VVqM1G(name)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VV2NM5(self, mode, bName, VVv5LU, title, txt, colList):
  FFxBTP(VVv5LU, boundFunction(self.VVobe2, mode, bName, VVv5LU, title, txt, colList), title="Adding Channels ...")
 def VVobe2(self, mode, bName, VVv5LU, title, txt, colList):
  bNameFile = CCdgmH.VVDdNq_forBouquet(bName)
  num  = 0
  path = VVV3TR + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVV3TR + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVv5LU.VVAVTk():
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVgNoK(mode, row)
    refCode, chUrl = self.VVmZyF(self.VVTLwE, self.VVyXB0, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FF7fKJ(os.path.basename(path))
  self.VVT7e5(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VV0BvR(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VV2ziI(self, mode, VVv5LU, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVgNoK(mode, colList)
  refCode, chUrl = self.VVmZyF(self.VVTLwE, self.VVyXB0, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVbIyV(chName):
   FFuCKD(VVv5LU, "This is a marker!", 300)
  else:
   FFxBTP(VVv5LU, boundFunction(self.VVzFO5, mode, VVv5LU, chUrl), title="Playing ...")
 def VVzFO5(self, mode, VVv5LU, chUrl):
  FFyH61(self, chUrl, VVuGQM=False)
  self.session.open(CCnyHZ, portalTableParam=(self, VVv5LU, mode))
 def VVnnEo(self, mode, VVv5LU, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVgNoK(mode, colList)
  refCode, chUrl = self.VVmZyF(self.VVTLwE, self.VVyXB0, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVgNoK(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVqslP(SELF):
  try:
   import requests
   return True
  except:
   FFsJwx(SELF, boundFunction(CCiels.VV46j9, SELF), 'This requires the library "Requests".\n\nInstall it now ?')
   return False
 @staticmethod
 def VV46j9(SELF):
  from sys import version_info
  cmdUpd = FFZIC7(VVnivp, "")
  if cmdUpd:
   cmdInst = FF8XlR(VVlw3T, "python-requests")
   if version_info[0] >= 3:
    cmdInst = cmdInst.replace("python-", "python3-")
   cmd = cmdUpd + " && " + cmdInst
   FFO3om(SELF, cmd, checkNetAccess=True, title="Installing Requests Library")
  else:
   FFmzPi(SELF)
class CCdgmH(Screen, CCiels):
 VVKXJO    = 0
 VVrvnk    = 1
 VVrqBO    = 2
 VV9MtP    = 3
 VVxkKu     = 4
 VVoOHT     = 5
 VVb4dO     = 6
 VVRAaT     = 7
 VVUhQ4      = 8
 VVxyVR     = 9
 VVjwhU     = 10
 VVcuB3     = 11
 VV37ty     = 12
 VVn49Z      = 13
 VVsMha      = 14
 VVyH3p      = 15
 VVJFOB      = 16
 VV1a1A      = 17
 VViyHz    = 0
 VVgaS0   = 1
 VVJow5   = 2
 VVISom   = 3
 VVuKHz  = 4
 VVWU8v  = 5
 VVHZdq   = 6
 VVaL7U   = 7
 VVYuEm  = 8
 VVTASE  = 9
 VV6azD  = 10
 VVZVE4 = 0
 VV0pmF = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FF65g3(VVbnJN, 1000, 1000, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.m3uOrM3u8File  = m3uOrM3u8File
  self.m3uOrM3u8BName  = ""
  self.VVv5LU  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVm4L1Data  = {}
  self.lastFindIptvName = ""
  CCiels.__init__(self)
  VV4YjP= self.VVXbew()
  FFC1qE(self, title="IPTV", VV4YjP=VV4YjP)
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FF0PjP(self["myMenu"])
  FFahFV(self)
  FFYdRn(self)
  if self.m3uOrM3u8File:
   self.VVg1SR(self.m3uOrM3u8File)
 def VVXbew(self):
  files = self.VVAhxW()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"        , "VVm4L1_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal List)"        , "VVm4L1_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)"    , "VVm4L1_fromM3u"  ))
  qUrl, iptvRef = self.VV4N4P()
  if qUrl:
   tList.append(("IPTV Server Browser (from Current Channel)"      , "VVm4L1_fromCurrChan" ))
  VV4YjP = []
  if files:
   if self.VVv5LU:
    VV4YjP.append(("Add Current List to a New Bouquet"      , "VVwNJE"  ))
    VV4YjP.append(VV32Zp)
    VV4YjP.append(("Change Current List References to Unique Codes"   , "VVOZ88"))
    VV4YjP.append(("Change Current List References to Identical Codes"  , "VVpSrv_rows" ))
    VV4YjP.append(VV32Zp)
    VV4YjP.append(("Share Reference with Satellite/C/T Service (manual entry)", "VVjrFe"   ))
    VV4YjP.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VVkgpR"   ))
   else:
    VV4YjP += tList
    VV4YjP.append(VV32Zp)
    VV4YjP.append(("M3U/M3U8 Channels Browser"        , "VVoCj1"   ))
    VV4YjP.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    if qUrl:
     VV4YjP.append(VV32Zp)
     VV4YjP.append(("Update Current Bouquet EPG (from IPTV Server)"  , "refreshIptvEPG"   ))
    VV4YjP.append(VV32Zp)
    VV4YjP.append(("Count Available IPTV Channels"       , "VVGWKr"    ))
    VV4YjP.append(("Check Reference Codes Format"        , "VV2c40"   ))
    VV4YjP.append(("Check System Acceptable Reference Types"     , "VVPnW9"   ))
    VV4YjP.append(VV32Zp)
    VV4YjP.append(("Share Reference with Sat./C/T (Only Matching Names)"  , "VVYK1H" ))
    VV4YjP.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVLo0M"  ))
    VV4YjP.append(("Change ALL References to Unique Codes"     , "VVQLmU" ))
    VV4YjP.append(("Change ALL References to Identical Codes"     , "VVpSrv_all" ))
  if not self.VVv5LU:
   if not files:
    VV4YjP += tList
   if not CCL88j.VVp10r():
    VV4YjP.append(VV32Zp)
    VV4YjP.append(("Download Manager"           , "dload_stat"    ))
  return VV4YjP
 def VVBO8S(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVwNJE"   : FFmIMB(self, self.VVwNJE, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVOZ88" : FFsJwx(self, boundFunction(FFxBTP, self.VVv5LU, self.VVOZ88 ), "Change Current List References to Unique Codes ?")
   elif item == "VVpSrv_rows" : FFsJwx(self, boundFunction(FFxBTP, self.VVv5LU, self.VVpSrv   ), "Change Current List References to Identical Codes ?")
   elif item == "VVjrFe"   : self.VVjrFe(tTitle)
   elif item == "VVkgpR"   : self.VVkgpR(tTitle)
   elif item == "VVm4L1_fromPlayList" : FFxBTP(self, self.VVgjMn, title=title)
   elif item == "VVm4L1_fromM3u"  : FFxBTP(self, boundFunction(self.VVit1G, 0), title=title)
   elif item == "VVm4L1_fromMac"  : self.VV2mW1()
   elif item == "VVm4L1_fromCurrChan" : self.VVAgES_fromCurrChan()
   elif item == "VVoCj1"   : self.VVoCj1()
   elif item == "iptvTable_live"   : FFxBTP(self, boundFunction(self.VVL34L, self.VVRAaT ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFxBTP(self, boundFunction(self.VVL34L, self.VVKXJO) , title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VVZz7W()
   elif item == "VVGWKr"    : FFxBTP(self, self.VVGWKr)
   elif item == "VV2c40"    : FFxBTP(self, self.VV2c40)
   elif item == "VVPnW9"   : FFxBTP(self, self.VVPnW9)
   elif item == "VVYK1H"  : FFsJwx(self, boundFunction(FFxBTP, self, self.VVYK1H ), "Continue ?")
   elif item == "VVLo0M"  : self.VVLo0M()
   elif item == "VVQLmU" : FFsJwx(self, boundFunction(FFxBTP, self, self.VVQLmU ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVpSrv_all" : FFsJwx(self, boundFunction(FFxBTP, self, self.VVpSrv  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "dload_stat"    : CCL88j.VVOiCX(self)
   elif item == "VVkx61"   : FFxBTP(self, boundFunction(CCLdzJ.VVkx61, self))
 def VVoCj1(self):
  if CCiels.VVqslP(self):
   FFxBTP(self, boundFunction(self.VVit1G, 1), title="Searching ...")
 def VVyEiI(self):
  global VVIzPF
  VVIzPF = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVBO8S(item)
 def VVL34L(self, mode):
  VVaXgj = self.VVtYsN(mode)
  if VVaXgj:
   VV5ydd = ("Current Service", self.VVnb8K  , [])
   VVxHB1 = ("Options"  , self.VVidzv    , [])
   VV487W = ("Filter"   , self.VVTyML    , [])
   VVnutX  = ("Play"   , boundFunction(self.VVH0Ss) , [])
   VVmtel = (""    , self.VV2CuG     , [])
   VVFSRM = (""    , self.VVwpUh      , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVdQl9  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFlZ9Z(self, None, header=header, VVplFV=VVaXgj, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=26
     , VVnutX=VVnutX, VV5ydd=VV5ydd, VVxHB1=VVxHB1, VV487W=VV487W, VVmtel=VVmtel, VVFSRM=VVFSRM
     , VVZidB="#0a00292B", VVCOuJ="#0a002126", VVQfS4="#0a002126", VVJk0D="#00000000", VVwbEy=True, searchCol=1)
  else:
   if mode == self.VVRAaT: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFkZTy(self, err)
 def VVwpUh(self, VVv5LU, title, txt, colList):
  self.VVv5LU = VVv5LU
 def VVidzv(self, VVv5LU, title, txt, colList):
  VV4YjP= self.VVXbew()
  FF2oO5(self, self.VVBO8S, title="IPTV Tools", VV4YjP=VV4YjP)
 def VVTyML(self, VVv5LU, title, txt, colList):
  VV4YjP = []
  VV4YjP.append(("All"         , "all"   ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Prefix of Selected Channel"   , "sameName" ))
  VV4YjP.append(("Suggest Words from Selected Channel" , "partName" ))
  VV4YjP.append(("Names with Non-English Characters" , "nonEnglish" ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Live TV"        , "live"  ))
  VV4YjP.append(("VOD"         , "vod"   ))
  VV4YjP.append(("Series"        , "series"  ))
  VV4YjP.append(("Uncategorised"      , "uncat"  ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Video"        , "video"  ))
  VV4YjP.append(("Audio"        , "audio"  ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("MKV"         , "MKV"   ))
  VV4YjP.append(("MP4"         , "MP4"   ))
  VV4YjP.append(("MP3"         , "MP3"   ))
  VV4YjP.append(("AVI"         , "AVI"   ))
  VV4YjP.append(("FLV"         , "FLV"   ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVX2d6()
  if bNames:
   bNames.sort()
   VV4YjP.append(VV32Zp)
   for item in bNames:
    VV4YjP.append((item, "__b__" + item))
  filterObj = CCHLQj(self)
  filterObj.VVVKbW(VV4YjP, VV4YjP, boundFunction(self.VVZRUl, VVv5LU))
 def VVZRUl(self, VVv5LU, item=None):
  prefix = VVv5LU.VVaisE(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVKXJO, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVrvnk , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVrqBO , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VV9MtP , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVRAaT  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVUhQ4   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVxyVR  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVjwhU  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVcuB3  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VV37ty  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVn49Z   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVsMha   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVyH3p   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVJFOB   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VV1a1A   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVb4dO  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVxkKu  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVoOHT  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVrqBO:
   VV4YjP = []
   chName = VVv5LU.VVaisE(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VV4YjP.append((item, item))
    if not VV4YjP and chName:
     VV4YjP.append((chName, chName))
    FF2oO5(self, boundFunction(self.VVSvIl_partOfName, title), title="Words from Current Selection", VV4YjP=VV4YjP)
   else:
    VVv5LU.VVd3iE("Invalid Channel Name")
  else:
   words, asPrefix = CCHLQj.VVfQLS(words)
   if not words and mode in (self.VVxkKu, self.VVoOHT):
    FFuCKD(self.VVv5LU, "Incorrect filter", 2000)
   else:
    FFxBTP(self.VVv5LU, boundFunction(self.VVgJ9g, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVSvIl_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFxBTP(self.VVv5LU, boundFunction(self.VVgJ9g, self.VVrqBO, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVLgN9(txt):
  return "#f#11ffff00#" + txt
 def VVgJ9g(self, mode, words, asPrefix, title):
  VVaXgj = self.VVtYsN(mode=mode, words=words, asPrefix=asPrefix)
  if VVaXgj : self.VVv5LU.VVFYEc(VVaXgj, title)
  else  : self.VVv5LU.VVd3iE("Not found")
 def VVtYsN(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVaXgj = []
  files  = self.VVAhxW()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFQiI5(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVjWHk = span.group(1)
    else : VVjWHk = ""
    VVjWHk_lCase = VVjWHk.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVbIyV(chName): chNameMod = self.VVLgN9(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVjWHk, chType, refCode, url)
     ok = False
     tUrl = FFwWRV(url).lower()
     if mode == self.VVKXJO       : ok = True
     elif mode == self.VVb4dO       : ok = True
     elif mode == self.VVcuB3:
      if CCdgmH.VVinaS(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VV37ty:
      if CCdgmH.VVinaS(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVRAaT:
      if CCdgmH.VVinaS(tUrl, compareType="live")  : ok = True
     elif mode == self.VVUhQ4:
      if CCdgmH.VVinaS(tUrl, compareType="movie") : ok = True
     elif mode == self.VVxyVR:
      if CCdgmH.VVinaS(tUrl, compareType="series") : ok = True
     elif mode == self.VVjwhU:
      if CCdgmH.VVinaS(tUrl, compareType="")   : ok = True
     elif mode == self.VVn49Z:
      if CCdgmH.VVinaS(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVsMha:
      if CCdgmH.VVinaS(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVyH3p:
      if CCdgmH.VVinaS(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVJFOB:
      if CCdgmH.VVinaS(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VV1a1A:
      if CCdgmH.VVinaS(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVrvnk:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVrqBO:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VV9MtP:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVxkKu:
      if words[0] == VVjWHk_lCase:
       ok = True
     elif mode == self.VVoOHT:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VVaXgj.append(row)
      chNum += 1
  if VVaXgj and mode == self.VVb4dO:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VVaXgj)
   for item in VVaXgj:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VVaXgj = newRows
  return VVaXgj
 def VVwNJE(self, bName):
  if bName:
   FFxBTP(self.VVv5LU, boundFunction(self.VVudcH, bName), title="Adding Channels ...")
 def VVudcH(self, bName):
  num = 0
  path = VVV3TR + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVV3TR + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVv5LU.VVAVTk():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFrQie(row[1]))
    totChange += 1
  FF7fKJ(os.path.basename(path))
  self.VVT7e5(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVLo0M(self):
  txt = "Stream Type "
  VV4YjP = []
  VV4YjP.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VV4YjP.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VV4YjP.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VV4YjP.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VV4YjP.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VV4YjP.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FF2oO5(self, self.VVnCyS, title="Change Reference Types to:", VV4YjP=VV4YjP)
 def VVnCyS(self, item=None):
  if item:
   if   item == "RT_1"  : self.VV4ke2("1"   )
   elif item == "RT_4097" : self.VV4ke2("4097")
   elif item == "RT_5001" : self.VV4ke2("5001")
   elif item == "RT_5002" : self.VV4ke2("5002")
   elif item == "RT_8192" : self.VV4ke2("8192")
   elif item == "RT_8193" : self.VV4ke2("8193")
 def VV4ke2(self, rType):
  FFsJwx(self, boundFunction(FFxBTP, self, boundFunction(self.VV9FOc, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VV9FOc(self, refType):
  totChange = 0
  files  = self.VVAhxW()
  if files:
   for path in files:
    txt = FFQiI5(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FF7fKJ(os.path.basename(path))
  self.VVT7e5(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVGWKr(self):
  totFiles = 0
  files  = self.VVAhxW()
  if files:
   totFiles = len(files)
  totChans = 0
  VVaXgj = self.VVtYsN()
  if VVaXgj:
   totChans = len(VVaXgj)
  FFXXd4(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VV2c40(self):
  files  = self.VVAhxW()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFQiI5(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVG7vV
   else    : color = VVGMgi
   totInvalid = FFu1AK(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFu1AK("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFXXd4(self, txt, title="Check IPTV References")
 def VVPnW9(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVV3TR + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FF7fKJ(os.path.basename(path))
  FFXgo1()
  acceptedList = []
  VV22w3 = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VV22w3:
   VV2k2X = FFDOQH(VV22w3)
   if VV2k2X:
    for service in VV2k2X:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVV3TR + userBName
  bFile = VVV3TR + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFxZhj("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFxZhj("rm -f '%s'" % path)
  os.system(cmd)
  FFXgo1()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVG7vV
    else     : res, color = "No" , VVGMgi
    txt += "    %s\t: %s\n" % (item, FFu1AK(res, color))
   FFXXd4(self, txt, title=title)
  else:
   txt = FFkZTy(self, "Could not complete the test on your system!", title=title)
 def VVYK1H(self):
  lameDbChans = CCLdzJ.VVj0Np(self, CCLdzJ.VVQwO2)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVAhxW():
    toSave = False
    txt = FFQiI5(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVT7e5(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFkZTy(self, 'No channels in "lamedb" !')
 def VVQLmU(self):
  files  = self.VVAhxW()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFghv7(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVknlB(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVT7e5(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVOZ88(self):
  iptvRefList = []
  files  = self.VVAhxW()
  if files:
   for path in files:
    txt = FFQiI5(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVv5LU.VVDPhr(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVknlB(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVAhxW()
  if files:
   for path in files:
    lines = FFghv7(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVT7e5(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVknlB(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVpSrv(self):
  list = None
  if self.VVv5LU:
   list = []
   for row in self.VVv5LU.VVAVTk():
    list.append(row[4] + row[5])
  files  = self.VVAhxW()
  totChange = 0
  if files:
   for path in files:
    lines = FFghv7(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVT7e5(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVT7e5(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFXgo1()
   if refreshTable and self.VVv5LU:
    VVaXgj = self.VVtYsN()
    if VVaXgj and self.VVv5LU:
     self.VVv5LU.VVFYEc(VVaXgj, self.tableTitle)
     self.VVv5LU.VVd3iE(txt)
   FFXXd4(self, txt, title=title)
  else:
   FFUwJf(self, "No changes.")
 def VVX2d6(self):
  files = self.VVAhxW()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with open(path, "r") as f:
     span = iSearch(r"#NAME\s+(.*)", f.readline(), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VVae8x = FFDRSE()
    if VVae8x:
     for b in VVae8x:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVAhxW(self):
  return CCdgmH.VVxyR1(self)
 @staticmethod
 def VVxyR1(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVV3TR + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFQiI5(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VV2CuG(self, VVv5LU, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFwWRV(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFgCFv(self, fncMode=CClBuf.VVYIMG, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVb0Hh(self, VVv5LU, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVH0Ss(self, VVv5LU, title, txt, colList):
  chName, chUrl = self.VVb0Hh(VVv5LU, colList)
  self.VVApbl(VVv5LU, chName, chUrl, "localIptv")
 def VVfs6U(self, mode, VVv5LU, colList):
  chName, chUrl, picUrl, refCode = self.VVtAYV(mode, colList)
  return chName, chUrl
 def VVCdtE(self, mode, VVv5LU, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVtAYV(mode, colList)
  self.VVApbl(VVv5LU, chName, chUrl, mode)
 def VVApbl(self, VVv5LU, chName, chUrl, playerFlag):
  chName = FFrQie(chName)
  if self.VVbIyV(chName):
   FFuCKD(VVv5LU, "This is a marker!", 300)
  else:
   FFxBTP(VVv5LU, boundFunction(self.VV8vPd, VVv5LU, chUrl, playerFlag), title="Playing ...")
 def VV8vPd(self, VVv5LU, chUrl, playerFlag):
  FFyH61(self, chUrl, VVuGQM=False)
  self.session.open(CCnyHZ, portalTableParam=(self, VVv5LU, playerFlag))
 @staticmethod
 def VVbIyV(chName):
  mark = ("--", "__", "==", "##", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVnb8K(self, VVv5LU, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
  if refCode:
   bName = FFLFiD()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFskjD(refCode, origUrl, chName) }
   VVv5LU.VVfZXt_partial(colDict, VVKlD3=True)
 def VVit1G(self, m3uMode):
  path = CCdgmH.VViKUI()
  lines = FFwhw7("find %s %s -iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'" % (path, FFomXb(1)))
  if lines:
   lines.sort()
   VV4YjP = []
   for line in lines:
    VV4YjP.append((line, line))
   if m3uMode == self.VVZVE4:
    title = "Browse Server from M3U URLs"
    VVlEXM = ("All to Playlist", self.VVcWUw)
   else:
    title = "M3U/M3U8 Channels Browser"
    VVlEXM = None
   OKBtnFnc = boundFunction(self.VV1dfD, m3uMode, title)
   VVXcP7 = ("Show Full Path", self.VVjTzA)
   VVRGLF = ("Delete File", boundFunction(self.VVDBFK, boundFunction(FFxBTP, self, boundFunction(self.VVit1G, m3uMode), title="Searching ...")))
   FF2oO5(self, None, title=title, VV4YjP=VV4YjP, width=1200, OKBtnFnc=OKBtnFnc, VVXcP7=VVXcP7, VVRGLF=VVRGLF, VVlEXM=VVlEXM)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n\n%s" % path
   FFkZTy(self, 'No ".m3u" files found %s' % txt)
 def VVjTzA(self, VV0IKZObj, url):
  FFXXd4(self, url, title="Full Path")
 def VV1dfD(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == self.VVZVE4:
    FFxBTP(menuInstance, boundFunction(self.VVWEOB, title, path))
   else:
    FFxBTP(menuInstance, boundFunction(self.VVg1SR, path))
 def VVg1SR(self, srcPath):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFQiI5(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  processChanName = CCdnf7()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVe9dM(propLine, "group-title") or "-"
   if not group == "-" and processChanName.VVqM1G(group):
    groups.add(group)
  VVaXgj = []
  if len(groups) > 0:
   title = "Groups"
   for group in groups:
    VVaXgj.append((group, group))
   VVaXgj.append(("ALL", ""))
   VVaXgj.sort(key=lambda x: x[0].lower())
   VVDYxQ = self.VVrwG4
   VVnutX  = ("Select" , boundFunction(self.VVKg5H, srcPath), [])
   widths   = (100  , 0)
   VVdQl9  = (LEFT  , LEFT)
   FFlZ9Z(self, None, title=title, width= 800, header=None, VVplFV=VVaXgj, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=30, VVnutX=VVnutX, VVDYxQ=VVDYxQ
     , VVZidB="#11110022", VVCOuJ="#11110022", VVQfS4="#11110022", VVJk0D="#00444400")
  else:
   txt = FFQiI5(srcPath)
   self.VV7UIt(txt, filterGroup="")
 def VVKg5H(self, srcPath, VVv5LU, title, txt, colList):
  group = colList[1]
  txt = FFQiI5(srcPath)
  self.VV7UIt(txt, filterGroup=group)
 def VV7UIt(self, txt, filterGroup=""):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = "Group : %s" % (filterGroup or "ALL")
  if lst:
   self.session.open(CC1Mzj, barTheme=CC1Mzj.VVEZCt
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VV7Wx9, lst, filterGroup)
       , VVnyfB = boundFunction(self.VVhRng, title, bName))
  else:
   self.VVV8Fj("No valid lines found !", title)
 def VV7Wx9(self, lst, filterGroup, progBarObj):
  progBarObj.VVCGmK = []
  progBarObj.VVR6pW(len(lst))
  processChanName = CCdnf7()
  num = 0
  for cols in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVZ46l(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVe9dM(propLine, "tvg-logo")
   group = self.VVe9dM(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if group and not processChanName.VVqM1G(group) : skip = True
    if chName and not processChanName.VVqM1G(chName): skip = True
    if not skip and progBarObj:
     num += 1
     progBarObj.VVCGmK.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if progBarObj:
   progBarObj.VV4hTf_forcedUpdate("Loading %d Channels" % len(progBarObj.VVCGmK))
 def VVhRng(self, title, bName, VVj61p, VVCGmK, threadCounter, threadTotal, threadErr):
  if VVCGmK:
   VVDYxQ = self.VVrwG4
   VVnutX  = ("Select"    , boundFunction(self.VV2wMA, title) , [])
   VVmtel = (""     , self.VVIXEs         , [])
   VV5ydd = ("Download PIcons" , self.VVyCZl        , [])
   VVxHB1 = ("Add ALL to Bouquet" , boundFunction(self.VVIKwO, bName) , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVdQl9  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFlZ9Z(self, None, title=title, header=header, VVplFV=VVCGmK, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=28, VVnutX=VVnutX, VVDYxQ=VVDYxQ, VVmtel=VVmtel, VV5ydd=VV5ydd, VVxHB1=VVxHB1, VVwbEy=True, searchCol=1
     , VVZidB="#0a00192B", VVCOuJ="#0a00192B", VVQfS4="#0a00192B", VVJk0D="#00000000")
  else:
   self.VVV8Fj("No valid lines found !", title)
 def VVyCZl(self, VVv5LU, title, txt, colList):
  self.VVx5wM(VVv5LU, "m3u/m3u8")
 def VVIKwO(self, bName, VVv5LU, title, txt, colList):
  FFxBTP(VVv5LU, boundFunction(self.VVXYzS, bName, VVv5LU), title="Adding Channels ...")
 def VVXYzS(self, bName, VVv5LU):
  bNameFile = CCdgmH.VVDdNq_forBouquet(bName)
  num  = 0
  path = VVV3TR + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVV3TR + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   catID = "33"
   rowNum = 0
   for row in VVv5LU.VVAVTk():
    chName = row[1].strip()
    url  = row[3].strip()
    chUrl = self.VVHBue(rowNum, url, chName)
    rowNum += 1
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FF7fKJ(os.path.basename(path))
  self.VVT7e5(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVHBue(self, rowNum, url, chName):
  refCode = self.VVcuUi(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFk7NU(url), chName)
  return chUrl
 def VVcuUi(self, rowNum, url, chName):
  span = iSearch(r"\/(\d{2,})", url, IGNORECASE)
  if span : stID = span.group(1)
  else : stID = "444"
  catID = "333"
  chNum = str(rowNum + 1)
  refCode = self.VVgfbn(catID, stID, chNum)
  return refCode
 def VVe9dM(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VV2wMA(self, Title, VVv5LU, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFxBTP(VVv5LU, boundFunction(self.VVwgpk, Title, VVv5LU, colList), title="Checking Server ...")
  else:
   self.VVjvdc(VVv5LU, url, chName)
 def VVwgpk(self, title, VVv5LU, colList):
  if not CCiels.VVqslP(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCOmmp.VVEWTz(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VV4YjP = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCdgmH.VVSYRJ(url, fPath)
     VV4YjP.append((resol, fullUrl))
    if VV4YjP:
     if len(VV4YjP) > 1:
      FF2oO5(self, boundFunction(self.VVlvHe, VVv5LU, chName), VV4YjP=VV4YjP, title="Resolution", VVmPdS=True, VVydPQ=True)
     else:
      self.VVjvdc(VVv5LU, VV4YjP[0][1], chName)
    else:
     self.VVKlD3or("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VV7UIt(txt, filterGroup="")
      return
    self.VVjvdc(VVv5LU, url, chName)
   else:
    self.VVV8Fj("Cannot process this channel !", title)
  else:
   self.VVV8Fj(err, title)
 def VVlvHe(self, VVv5LU, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVjvdc(VVv5LU, resolUrl, chName)
 def VVjvdc(self, VVv5LU, url, chName):
  FFxBTP(VVv5LU, boundFunction(self.VVkBlV, VVv5LU, url, chName), title="Playing ...")
 def VVkBlV(self, VVv5LU, url, chName):
  chUrl = self.VVHBue(VVv5LU.VVGAHI(), url, chName)
  FFyH61(self, chUrl, VVuGQM=False)
  self.session.open(CCnyHZ, portalTableParam=(self, VVv5LU, "m3u/m3u8"))
 def VVIAl6(self, VVv5LU, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVHBue(VVv5LU.VVGAHI(), url, chName)
  return chName, chUrl
 def VVIXEs(self, VVv5LU, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFgCFv(self, fncMode=CClBuf.VVYIMG, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVV8Fj(self, err, title):
  FFkZTy(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVrwG4(self, VVv5LU):
  if self.m3uOrM3u8File:
   self.close()
  VVv5LU.cancel()
 def VVcWUw(self, VV0IKZObj, item=None):
  FFxBTP(VV0IKZObj, boundFunction(self.VVgKCN, VV0IKZObj, item))
 def VVgKCN(self, VV0IKZObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VV0IKZObj.VV4YjP):
    path = item[1]
    if fileExists(path):
     enc = FFEprZ(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VVv9kK(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCdgmH.VViKUI(orExportPath=True)
    pListF = "%sPlaylist_%s.txt" % (path, FFKsmN())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VV0IKZObj.VV4YjP)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFXXd4(self, txt, title=title)
   else:
    FFkZTy(self, "Could not obtain URLs from this file list !", title=title)
 def VVgjMn(self):
  path = CCdgmH.VViKUI()
  lines = FFwhw7('find %s %s -iname "*playlist*" | grep -i ".txt"' % (path, FFomXb(1)))
  if lines:
   lines.sort()
   VV4YjP = []
   for line in lines:
    VV4YjP.append((line, line))
   OKBtnFnc = self.VVC4q2
   VVRGLF = ("Delete File", boundFunction(self.VVDBFK, boundFunction(FFxBTP, self, self.VVgjMn, title="Searching ...")))
   FF2oO5(self, None, title="Select Playlist File", VV4YjP=VV4YjP, width=1200, OKBtnFnc=OKBtnFnc, VVRGLF=VVRGLF)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFkZTy(self, 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt)
 def VVC4q2(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFxBTP(menuInstance, boundFunction(self.VVOsYh, menuInstance, path), title="Processing File ...")
 def VVOsYh(self, fileMenuInstance, path):
  enc = FFEprZ(path, self)
  if enc == -1:
   return
  VVaXgj = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0]
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFk4Wy(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCdgmH.VVexD6(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVaXgj:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(filter(None, [item[5], item[0]]))
     num += 1
     VVaXgj.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVaXgj:
   title = "Playlist File"
   VVnutX  = ("Start"    , boundFunction(self.VVtZHS, title)  , [])
   VVyT4T = ("Home Menu"   , FFCjjG         , [])
   VV5ydd = ("Download M3U File" , self.VVxWHN     , [])
   VVxHB1 = ("Edit File"   , boundFunction(self.VVdYAV, path) , [])
   VV487W = ("Check & Filter"  , boundFunction(self.VVCxYf, fileMenuInstance, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVdQl9  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFlZ9Z(self, None, title=title, header=header, VVplFV=VVaXgj, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=26, VVnutX=VVnutX, VVyT4T=VVyT4T, VV487W=VV487W, VV5ydd=VV5ydd, VVxHB1=VVxHB1, VVZidB="#11001116", VVCOuJ="#11001116", VVQfS4="#11001116", VVJk0D="#00003635", VVJSW4="#0a333333", VVpNa2="#11331100", VVwbEy=True)
  else:
   FFkZTy(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVxWHN(self, VVv5LU, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFsJwx(self, boundFunction(FFxBTP, VVv5LU, boundFunction(self.VVqfMt, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVqfMt(self, title, url):
  path, err = FFPMCM(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFkZTy(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFQiI5(path)
   if '{"user_info":{"auth":0}}' in txt:
    os.system(FFxZhj("rm -f '%s'" % path))
    FFkZTy(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    os.system(FFxZhj("rm -f '%s'" % path))
    FFkZTy(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCdgmH.VViKUI(orExportPath=True) + fName
    os.system(FFxZhj("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FFUwJf(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFkZTy(self, "Could not download the M3U file!", title=errTitle)
 def VVtZHS(self, Title, VVv5LU, title, txt, colList):
  url = colList[6]
  FFxBTP(VVv5LU, boundFunction(self.VVLlzO, Title, url), title="Checking Server ...")
 def VVdYAV(self, path, VVv5LU, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCU5Qm(self, path, VVnyfB=boundFunction(self.VV5ixj, VVv5LU), curRowNum=rowNum)
  else    : FFLxgb(self, path)
 def VV5ixj(self, VVv5LU, fileChanged):
  if fileChanged:
   VVv5LU.cancel()
 def VVjrFe(self, title):
  curChName = self.VVv5LU.VVaisE(1)
  FFmIMB(self, boundFunction(self.VVCGor, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVCGor(self, title, name):
  if name:
   lameDbChans = CCLdzJ.VVj0Np(self, CCLdzJ.VVDcPa, VVs2Hw=False, VVC4JZ=False)
   list = []
   if lameDbChans:
    processChanName = CCdnf7()
    name = processChanName.VVVUxR(name)
    ratio = "1"
    for item in lameDbChans:
     if name in item[0].lower():
      list.append((item[0], FFLu71(item[2]), item[3], ratio))
   if list : self.VVYjci(list, title)
   else : FFkZTy(self, "Not found:\n\n%s" % name, title=title)
 def VVkgpR(self, title):
  curChName = self.VVv5LU.VVaisE(1)
  self.session.open(CC1Mzj, barTheme=CC1Mzj.VVEZCt
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVeG3b
      , VVnyfB = boundFunction(self.VVWSvN, title, curChName))
 def VVeG3b(self, progBarObj):
  curChName = self.VVv5LU.VVaisE(1)
  lameDbChans = CCLdzJ.VVj0Np(self, CCLdzJ.VV4nmj, VVs2Hw=False, VVC4JZ=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVCGmK = []
  progBarObj.VVR6pW(len(lameDbChans))
  processChanName = CCdnf7()
  curCh = processChanName.VVVUxR(curChName)
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CCczfG.VVMQzN(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVZ46l(1, True)
   if progBarObj and ratio > 50:
    progBarObj.VVCGmK.append((chName, FFLu71(sat), refCode.replace("_", ":"), str(ratio)))
 def VVWSvN(self, title, curChName, VVj61p, VVCGmK, threadCounter, threadTotal, threadErr):
  if VVCGmK: self.VVYjci(VVCGmK, title)
  elif VVj61p: FFkZTy(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVYjci(self, VVaXgj, title):
  curChName = self.VVv5LU.VVaisE(1)
  curRefCode = self.VVv5LU.VVaisE(4)
  curUrl  = self.VVv5LU.VVaisE(5)
  VVaXgj = sorted(VVaXgj, key=lambda x: (100-int(x[3]), x[0].lower()))
  VVnutX  = ("Share Sat/C/T Ref.", boundFunction(self.VV7NK1, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFlZ9Z(self, None, title=title, header=header, VVplFV=VVaXgj, VVbohG=widths, VVIUEO=26, VVnutX=VVnutX, VVZidB="#0a00112B", VVCOuJ="#0a001126", VVQfS4="#0a001126", VVJk0D="#00000000")
 def VV7NK1(self, newtitle, curChName, curRefCode, curUrl, VVv5LU, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFsJwx(self.VVv5LU, boundFunction(FFxBTP, self.VVv5LU, boundFunction(self.VVKeSo, VVv5LU, data)), ques, title=newtitle, VVEGkV=True)
 def VVKeSo(self, VVv5LU, data):
  VVv5LU.cancel()
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVAhxW():
    txt = FFQiI5(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFXgo1()
    newRow = []
    for i in range(6):
     newRow.append(self.VVv5LU.VVaisE(i))
    newRow[4] = newRefCode
    done = self.VVv5LU.VVoUPy(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FF4knh(boundFunction(FFUwJf , self, resTxt, title=title))
  elif resErr: FF4knh(boundFunction(FFkZTy , self, resErr, title=title))
 def VVCxYf(self, fileMenuInstance, path, VVv5LU, title, txt, colList):
  self.session.open(CC1Mzj, barTheme=CC1Mzj.VVEZCt
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVc1PG, VVv5LU)
      , VVnyfB = boundFunction(self.VVlsUs, fileMenuInstance, path, VVv5LU))
 def VVc1PG(self, VVv5LU, progBarObj):
  progBarObj.VVR6pW(VVv5LU.VVccPf())
  progBarObj.VVCGmK = []
  for row in VVv5LU.VVAVTk():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVZ46l(1, True)
   qUrl = self.VVljs0(self.VViyHz, row[6])
   txt, err = self.VVkFgl(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVq4cU(item, "auth") == "0":
       progBarObj.VVCGmK.append(qUrl)
    except:
     pass
 def VVlsUs(self, fileMenuInstance, path, VVv5LU, VVj61p, VVCGmK, threadCounter, threadTotal, threadErr):
  if VVj61p:
   list = VVCGmK
   title = "Authorized Servers"
   if list:
    totChk = VVv5LU.VVccPf()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFKsmN()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVgjMn()
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFu1AK(str(totAuth), VVG7vV)
     txt += "%s\n\n%s"    %  (FFu1AK("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFXXd4(self, txt, title=title)
     VVv5LU.close()
     fileMenuInstance.close()
    else:
     FFUwJf(self, "All URLs are authorized.", title=title)
   else:
    FFkZTy(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVkFgl(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   cont = res.headers.get("Content-Type")
   if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
    return "", "Unexpected server data type ( %s )" % cont
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVexD6(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVinaS(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVljs0(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVexD6(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VViyHz   : return "%s"            % url
  elif mode == self.VVgaS0   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVJow5   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVISom  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVuKHz  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVWU8v : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVHZdq   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVaL7U    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVYuEm  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VV6azD : return "%s&action=get_live_streams"      % url
  elif mode == self.VVTASE  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVq4cU(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFNSik(int(val))
    elif is_base64 : val = FFxsRA(val)
    elif isToHHMMSS : val = FFRxqD(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVWEOB(self, title, path):
  if fileExists(path):
   enc = FFEprZ(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VVv9kK(line)
     if qUrl:
      break
   if qUrl : self.VVLlzO(title, qUrl)
   else : FFkZTy(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFkZTy(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVAgES_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VV4N4P()
  if qUrl:
   host, mac, isPortalUrl = self.VV3YqT(iptvRef)
   if isPortalUrl:
    if host and mac : self.VVAgES(self, host, mac)
    else   : FFkZTy(self, "Error in current channel URL/MAC !", title=title)
   else:
    FFxBTP(self, boundFunction(self.VVLlzO, title, qUrl), title="Checking Server ...")
  else:
   FFkZTy(self, "Error in current channel URL !", title=title)
 def VV4N4P(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
  qUrl = self.VVv9kK(decodedUrl)
  return qUrl, iptvRef
 def VVv9kK(self, url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 : return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else    : return ""
 def VVLlzO(self, title, url):
  self.VVm4L1Data = {}
  qUrl = self.VVljs0(self.VViyHz, url)
  txt, err = self.VVkFgl(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVm4L1Data = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVm4L1Data["username"    ] = self.VVq4cU(item, "username"        )
    self.VVm4L1Data["password"    ] = self.VVq4cU(item, "password"        )
    self.VVm4L1Data["message"    ] = self.VVq4cU(item, "message"        )
    self.VVm4L1Data["auth"     ] = self.VVq4cU(item, "auth"         )
    self.VVm4L1Data["status"    ] = self.VVq4cU(item, "status"        )
    self.VVm4L1Data["exp_date"    ] = self.VVq4cU(item, "exp_date"    , isDate=True )
    self.VVm4L1Data["is_trial"    ] = self.VVq4cU(item, "is_trial"        )
    self.VVm4L1Data["active_cons"   ] = self.VVq4cU(item, "active_cons"       )
    self.VVm4L1Data["created_at"   ] = self.VVq4cU(item, "created_at"   , isDate=True )
    self.VVm4L1Data["max_connections"  ] = self.VVq4cU(item, "max_connections"      )
    self.VVm4L1Data["allowed_output_formats"] = self.VVq4cU(item, "allowed_output_formats"    )
    lst = []
    key = "allowed_output_formats"
    if key in item:
     for item in item[key]:
      lst.append(str(item))
     self.VVm4L1Data[key] = lst
    item = tDict["server_info"]
    self.VVm4L1Data["url"    ] = self.VVq4cU(item, "url"        )
    self.VVm4L1Data["port"    ] = self.VVq4cU(item, "port"        )
    self.VVm4L1Data["https_port"  ] = self.VVq4cU(item, "https_port"      )
    self.VVm4L1Data["server_protocol" ] = self.VVq4cU(item, "server_protocol"     )
    self.VVm4L1Data["rtmp_port"   ] = self.VVq4cU(item, "rtmp_port"       )
    self.VVm4L1Data["timezone"   ] = self.VVq4cU(item, "timezone"       )
    self.VVm4L1Data["timestamp_now"  ] = self.VVq4cU(item, "timestamp_now"  , isDate=True )
    self.VVm4L1Data["time_now"   ] = self.VVq4cU(item, "time_now"       )
    VV4YjP  = self.VVYVM8(True)
    OKBtnFnc = self.VVm4L1Options
    VVUWK6 = ("Home Menu", FFCjjG)
    VVlEXM = ("Bookmark Server", boundFunction(CCdgmH.VViEnd, self, False, self.VVm4L1Data["playListURL"]))
    FF2oO5(self, None, title="IPTV Server Resources", VV4YjP=VV4YjP, OKBtnFnc=OKBtnFnc, VVUWK6=VVUWK6, VVlEXM=VVlEXM)
   else:
    err = "Could not get data from server !"
  if err:
   FFkZTy(self, err, title=title)
  FFuCKD(self)
 def VVm4L1Options(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFxBTP(menuInstance, boundFunction(self.VVuJpp, self.VVgaS0  , title=title), title=wTxt)
   elif ref == "vod"   : FFxBTP(menuInstance, boundFunction(self.VVuJpp, self.VVJow5  , title=title), title=wTxt)
   elif ref == "series"  : FFxBTP(menuInstance, boundFunction(self.VVuJpp, self.VVISom , title=title), title=wTxt)
   elif ref == "catchup"  : FFxBTP(menuInstance, boundFunction(self.VVuJpp, self.VVuKHz , title=title), title=wTxt)
   elif ref == "accountInfo" : FFxBTP(menuInstance, boundFunction(self.VVxasv           , title=title), title=wTxt)
 def VVxasv(self, title):
  rows = []
  for key, val in self.VVm4L1Data.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VVyT4T = ("Home Menu", FFCjjG, [])
  header   = ("Num", "User/Server" , "Subject" , "Value" )
  widths   = (0 , 15   , 35  , 50  )
  FFlZ9Z(self, None, title=title, width=1200, header=header, VVplFV=rows, VVbohG=widths, VVIUEO=26, VVyT4T=VVyT4T, VVZidB="#0a00292B", VVCOuJ="#0a002126", VVQfS4="#0a002126", VVJk0D="#00000000", searchCol=2)
 def VVr8QS(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CCdnf7()
    if mode in (self.VVHZdq, self.VVTASE):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVq4cU(item, "num"         )
      name     = self.VVq4cU(item, "name"        )
      stream_id    = self.VVq4cU(item, "stream_id"       )
      stream_icon    = self.VVq4cU(item, "stream_icon"       )
      epg_channel_id   = self.VVq4cU(item, "epg_channel_id"      )
      added     = self.VVq4cU(item, "added"    , isDate=True )
      is_adult    = self.VVq4cU(item, "is_adult"       )
      category_id    = self.VVq4cU(item, "category_id"       )
      tv_archive    = self.VVq4cU(item, "tv_archive"       )
      name = processChanName.VVqM1G(name)
      if name:
       if mode == self.VVHZdq or mode == self.VVTASE and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVaL7U:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVq4cU(item, "num"         )
      name    = self.VVq4cU(item, "name"        )
      stream_id   = self.VVq4cU(item, "stream_id"       )
      stream_icon   = self.VVq4cU(item, "stream_icon"       )
      added    = self.VVq4cU(item, "added"    , isDate=True )
      is_adult   = self.VVq4cU(item, "is_adult"       )
      category_id   = self.VVq4cU(item, "category_id"       )
      container_extension = self.VVq4cU(item, "container_extension"     ) or "mp4"
      name = processChanName.VVqM1G(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVYuEm:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVq4cU(item, "num"        )
      name    = self.VVq4cU(item, "name"       )
      series_id   = self.VVq4cU(item, "series_id"      )
      cover    = self.VVq4cU(item, "cover"       )
      genre    = self.VVq4cU(item, "genre"       )
      episode_run_time = self.VVq4cU(item, "episode_run_time"    )
      category_id   = self.VVq4cU(item, "category_id"      )
      container_extension = self.VVq4cU(item, "container_extension"    ) or "mp4"
      name = processChanName.VVqM1G(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVuJpp(self, mode, title):
  cList, err = self.VVkkwN(mode)
  if cList and mode == self.VVuKHz:
   cList = self.VVfFHh(cList)
  if err:
   FFkZTy(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVZidB, VVCOuJ, VVQfS4, VVJk0D = self.VV9Ys0(mode)
   mName = self.VVDFNv(mode)
   if   mode == self.VVgaS0  : fMode = self.VVHZdq
   elif mode == self.VVJow5  : fMode = self.VVaL7U
   elif mode == self.VVISom : fMode = self.VVYuEm
   elif mode == self.VVuKHz : fMode = self.VVTASE
   if mode == self.VVuKHz:
    VVxHB1 = None
   else:
    VVxHB1 = ("Find in %s" % mName , boundFunction(self.VV1SG1, fMode) , [])
   VVnutX   = ("Show List"   , boundFunction(self.VVeRpg, mode) , [])
   VVyT4T  = ("Home Menu"   , FFCjjG          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFlZ9Z(self, None, title=title, width=1200, header=header, VVplFV=cList, VVbohG=widths, VVIUEO=30, VVyT4T=VVyT4T, VVxHB1=VVxHB1, VVnutX=VVnutX, VVZidB=VVZidB, VVCOuJ=VVCOuJ, VVQfS4=VVQfS4, VVJk0D=VVJk0D)
  else:
   FFkZTy(self, "No list from server !", title=title)
  FFuCKD(self)
 def VVkkwN(self, mode):
  qUrl  = self.VVljs0(mode, self.VVm4L1Data["playListURL"])
  txt, err = self.VVkFgl(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    processChanName = CCdnf7()
    for item in tDict:
     category_id  = self.VVq4cU(item, "category_id"  )
     category_name = self.VVq4cU(item, "category_name" )
     parent_id  = self.VVq4cU(item, "parent_id"  )
     category_name = processChanName.VVlP34(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVfFHh(self, catList):
  mode  = self.VVTASE
  qUrl  = self.VVljs0(mode, self.VVm4L1Data["playListURL"])
  txt, err = self.VVkFgl(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVr8QS(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVeRpg(self, mode, VVv5LU, title, txt, colList):
  title = colList[1]
  FFxBTP(VVv5LU, boundFunction(self.VVSKOv, mode, VVv5LU, title, txt, colList), title="Downloading ...")
 def VVSKOv(self, mode, VVv5LU, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVDFNv(mode) + " : "+ bName
  if   mode == self.VVgaS0  : mode = self.VVHZdq
  elif mode == self.VVJow5  : mode = self.VVaL7U
  elif mode == self.VVISom : mode = self.VVYuEm
  elif mode == self.VVuKHz : mode = self.VVTASE
  qUrl  = self.VVljs0(mode, self.VVm4L1Data["playListURL"], catID)
  txt, err = self.VVkFgl(qUrl)
  list  = []
  if not err and mode in (self.VVHZdq, self.VVaL7U, self.VVYuEm, self.VVTASE):
   list, err = self.VVr8QS(mode, txt)
  if err:
   FFkZTy(self, err, title=title)
  elif list:
   VVyT4T  = ("Home Menu"   , FFCjjG             , [])
   if mode in (self.VVHZdq, self.VVTASE):
    VVZidB, VVCOuJ, VVQfS4, VVJk0D = self.VV9Ys0(mode)
    VVmtel = (""     , boundFunction(self.VVSNfo, mode)     , [])
    VV5ydd = ("Download Options" , boundFunction(self.VVLzfo, mode, "", "")  , [])
    VVxHB1 = ("Add ALL to Bouquet" , boundFunction(self.VVJuaz, mode, bName)  , [])
    if mode == self.VVHZdq:
     VVnutX = ("Play"    , boundFunction(self.VVCdtE, mode)     , [])
    elif mode == self.VVTASE:
     VVnutX  = ("Programs", boundFunction(self.VVJB5h_fromIptvTable, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVdQl9  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVaL7U:
    VVZidB, VVCOuJ, VVQfS4, VVJk0D = self.VV9Ys0(mode)
    VVnutX  = ("Play"    , boundFunction(self.VVCdtE, mode)    , [])
    VVmtel = (""     , boundFunction(self.VVSNfo, mode)    , [])
    VV5ydd = ("Download Options" , boundFunction(self.VVLzfo, mode, "v", ""), [])
    VVxHB1 = ("Add ALL to Bouquet" , boundFunction(self.VVJuaz, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVdQl9  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVYuEm:
    VVZidB, VVCOuJ, VVQfS4, VVJk0D = self.VV9Ys0("series2")
    VVnutX  = ("Show Seasons", boundFunction(self.VVKoEL, mode) , [])
    VVmtel = ("", boundFunction(self.VVUm49, mode)  , [])
    VV5ydd = None
    VVxHB1 = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVdQl9  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFlZ9Z(self, None, title=title, header=header, VVplFV=list, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=26, VVnutX=VVnutX, VVyT4T=VVyT4T, VV5ydd=VV5ydd, VVxHB1=VVxHB1, VVmtel=VVmtel, VVZidB=VVZidB, VVCOuJ=VVCOuJ, VVQfS4=VVQfS4, VVJk0D=VVJk0D, VVwbEy=True, searchCol=1)
  else:
   FFkZTy(self, "No Channels found !", title=title)
  FFuCKD(self)
 def VVJB5h_fromIptvTable(self, mode, bName, VVv5LU, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVm4L1Data["playListURL"]
  ok_fnc  = boundFunction(self.VVnDJ9, hostUrl, chName, catId, streamId)
  FFxBTP(VVv5LU, boundFunction(CCdgmH.VVJB5h, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVnDJ9(self, chUrl, chName, catId, streamId, VVv5LU, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCdgmH.VVexD6(chUrl)
   chNum = "333"
   refCode = CCdgmH.VVgfbn(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFyH61(self, chUrl, VVuGQM=False)
   self.session.open(CCnyHZ)
  else:
   FFkZTy(self, "Incorrect Timestamp", pTitle)
 def VVKoEL(self, mode, VVv5LU, title, txt, colList):
  title = colList[1]
  FFxBTP(VVv5LU, boundFunction(self.VVcJLe, mode, VVv5LU, title, txt, colList), title="Downloading ...")
 def VVcJLe(self, mode, VVv5LU, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVljs0(self.VVWU8v, self.VVm4L1Data["playListURL"], series_id)
  txt, err = self.VVkFgl(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVq4cU(tDict["info"], "name"   )
      category_id = self.VVq4cU(tDict["info"], "category_id" )
      icon  = self.VVq4cU(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVq4cU(EP, "id"     )
        episode_num   = self.VVq4cU(EP, "episode_num"   )
        epTitle    = self.VVq4cU(EP, "title"     )
        container_extension = self.VVq4cU(EP, "container_extension" )
        seasonNum   = self.VVq4cU(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFkZTy(self, err, title=title)
  elif list:
   VVyT4T = ("Home Menu"   , FFCjjG             , [])
   VV5ydd = ("Download Options" , boundFunction(self.VVLzfo, mode, "s", title) , [])
   VVxHB1 = ("Add ALL to Bouquet" , boundFunction(self.VVJuaz, mode, title)  , [])
   VVmtel = (""     , boundFunction(self.VVSNfo, mode)     , [])
   VVnutX  = ("Play"    , boundFunction(self.VVCdtE, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVdQl9  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFlZ9Z(self, None, title=title, header=header, VVplFV=list, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=26, VVyT4T=VVyT4T, VV5ydd=VV5ydd, VVnutX=VVnutX, VVmtel=VVmtel, VVxHB1=VVxHB1, VVZidB="#0a00292B", VVCOuJ="#0a002126", VVQfS4="#0a002126", VVJk0D="#00000000")
  else:
   FFkZTy(self, "No Channels found !", title=title)
  FFuCKD(self)
 def VV1SG1(self, mode, VVv5LU, title, txt, colList):
  VV4YjP = []
  VV4YjP.append(("Keyboard"  , "manualEntry"))
  VV4YjP.append(("From Filter" , "fromFilter"))
  FF2oO5(self, boundFunction(self.VVC9kt, VVv5LU, mode), title="Input Type", VV4YjP=VV4YjP, width=400)
 def VVC9kt(self, VVv5LU, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFmIMB(self, boundFunction(self.VVVHwx, VVv5LU, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCHLQj(self)
    filterObj.VV0VYy(boundFunction(self.VVVHwx, VVv5LU, mode))
 def VVVHwx(self, VVv5LU, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CCdnf7()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVg5gs(words):
     FFkZTy(self, processChanName.VV8DWM(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CC1Mzj, barTheme=CC1Mzj.VVEZCt
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VVfsqK, VVv5LU, mode, title, words, toFind, asPrefix, processChanName)
         , VVnyfB = boundFunction(self.VVveQc, mode, toFind, title))
   else:
    FFkZTy(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVfsqK(self, VVv5LU, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVR6pW(VVv5LU.VVZyIO())
  progBarObj.VVCGmK = []
  for row in VVv5LU.VVAVTk():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVZ46l(1)
   progBarObj.VV4hTf_fromIptvFind(catName)
   qUrl  = self.VVljs0(mode, self.VVm4L1Data["playListURL"], catID)
   txt, err = self.VVkFgl(qUrl)
   if not err:
    tList, err = self.VVr8QS(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VVqM1G(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVHZdq:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VVCGmK.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVaL7U:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VVCGmK.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVYuEm:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VVCGmK.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVveQc(self, mode, toFind, title, VVj61p, VVCGmK, threadCounter, threadTotal, threadErr):
  if VVCGmK:
   title = self.VVV1JZ(mode, toFind)
   if mode == self.VVHZdq or mode == self.VVaL7U:
    if mode == self.VVaL7U : typ = "v"
    else          : typ = ""
    bName   = CCdgmH.VVDdNq_forBouquet(toFind)
    VVnutX  = ("Play"     , boundFunction(self.VVCdtE, mode)    , [])
    VV5ydd = ("Download Options" , boundFunction(self.VVLzfo, mode, typ, ""), [])
    VVxHB1 = ("Add ALL to Bouquet" , boundFunction(self.VVJuaz, mode, bName) , [])
   elif mode == self.VVYuEm:
    VVnutX  = ("Show Seasons"  , boundFunction(self.VVKoEL, mode)    , [])
    VVxHB1 = None
    VV5ydd = None
   VVmtel  = (""     , boundFunction(self.VVSNfo, mode)    , [])
   VVyT4T  = ("Home Menu"   , FFCjjG            , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVdQl9  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVv5LU = FFlZ9Z(self, None, title=title, header=header, VVplFV=VVCGmK, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=26, VVnutX=VVnutX, VVyT4T=VVyT4T, VV5ydd=VV5ydd, VVxHB1=VVxHB1, VVmtel=VVmtel, VVZidB="#0a00292B", VVCOuJ="#0a002126", VVQfS4="#0a002126", VVJk0D="#00000000", VVwbEy=True, searchCol=1)
   if not VVj61p:
    FFuCKD(VVv5LU, "Stopped" , 1000)
  else:
   if VVj61p:
    FFkZTy(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVtAYV(self, mode, colList):
  if mode in (self.VVHZdq, self.VVTASE):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVaL7U:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFrQie(chName)
  url = self.VVm4L1Data["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVexD6(url)
  refCode = self.VVgfbn(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVSNfo(self, mode, VVv5LU, title, txt, colList):
  FFxBTP(VVv5LU, boundFunction(self.VVQde6, mode, VVv5LU, title, txt, colList))
 def VVQde6(self, mode, VVv5LU, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVtAYV(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFgCFv(self, fncMode=CClBuf.VVJ5BI, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVUm49(self, mode, VVv5LU, title, txt, colList):
  FFxBTP(VVv5LU, boundFunction(self.VVmW0k, mode, VVv5LU, title, txt, colList))
 def VVmW0k(self, mode, VVv5LU, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFgCFv(self, fncMode=CClBuf.VVt81y, chName=name, text=txt, picUrl=Cover)
 def VVJuaz(self, mode, bName, VVv5LU, title, txt, colList):
  FFxBTP(VVv5LU, boundFunction(self.VVNXGd, mode, bName, VVv5LU, title, txt, colList), title="Adding Channels ...")
 def VVNXGd(self, mode, bName, VVv5LU, title, txt, colList):
  url = self.VVm4L1Data["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVexD6(url)
  bNameFile = CCdgmH.VVDdNq_forBouquet(bName)
  num  = 0
  path = VVV3TR + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVV3TR + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVv5LU.VVAVTk():
    chName, chUrl, picUrl, refCode = self.VVtAYV(mode, row)
    f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
    f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
    totChange += 1
  FF7fKJ(os.path.basename(path))
  self.VVT7e5(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVLzfo(self, mode, typ, seriesName, VVv5LU, title, txt, colList):
  VV4YjP = []
  VV4YjP.append(("Download all PIcons"       , "dnldPicons" ))
  if typ:
   VV4YjP.append(VV32Zp)
   tName = "Movie" if typ.startswith("v") else "Series"
   VV4YjP.append(("Download Selected %s" % tName    , "dnldSel"  ))
   VV4YjP.append(("Add Selected %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VV4YjP.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCL88j.VVp10r():
    VV4YjP.append(VV32Zp)
    VV4YjP.append(("Download Manager"      , "dload_stat" ))
  FF2oO5(self, boundFunction(self.VVBO8S_VVKbtG, VVv5LU, mode, typ, seriesName, colList), title="Download Options", VV4YjP=VV4YjP)
 def VVBO8S_VVKbtG(self, VVv5LU, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVx5wM(VVv5LU, mode)
   elif item == "dnldSel"  : self.VVanun(VVv5LU, mode, typ, colList, True)
   elif item == "addSel"  : self.VVanun(VVv5LU, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVSrS8(VVv5LU, mode, typ, seriesName)
   elif item == "dload_stat" : CCL88j.VVOiCX(self)
 def VVanun(self, VVv5LU, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVMzut(mode, typ, colList)
  if startDnld:
   CCL88j.VVCmai_url(self, decodedUrl)
  else:
   self.VVKbtG_FFsJwx(VVv5LU, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVSrS8(self, VVv5LU, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVv5LU.VVAVTk():
   chName, decodedUrl = self.VVMzut(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVKbtG_FFsJwx(VVv5LU, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVKbtG_FFsJwx(self, VVv5LU, title, chName, decodedUrl_list, startDnld):
  FFsJwx(self, boundFunction(self.VVL0f5, VVv5LU, decodedUrl_list, startDnld), chName, title=title)
 def VVL0f5(self, VVv5LU, decodedUrl_list, startDnld):
  added, skipped = CCL88j.VVns7xList(decodedUrl_list)
  FFuCKD(VVv5LU, "Added", 1000)
 def VVMzut(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVtAYV(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVgNoK(mode, colList)
   refCode, chUrl = self.VVmZyF(self.VVTLwE, self.VVyXB0, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFmuAP(chUrl)
  return chName, decodedUrl
 def VVx5wM(self, VVv5LU, mode):
  if os.system(FFxZhj("which ffmpeg")) == 0:
   self.session.open(CC1Mzj, barTheme=CC1Mzj.VVIi6X
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VVoczP, VVv5LU, mode)
       , VVnyfB = self.VV5hfl)
  else:
   FFsJwx(self, boundFunction(CCdgmH.VVDaN8, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VV5hfl(self, VVj61p, VVCGmK, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVCGmK["proces"], VVCGmK["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVCGmK["ok"], VVCGmK["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVCGmK["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVCGmK["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVCGmK["badURL"]
  txt += "Download Failure\t: %d\n"   % VVCGmK["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVCGmK["path"]
  if not VVj61p  : color = "#11402000"
  elif VVCGmK["err"]: color = "#11201000"
  else     : color = None
  if VVCGmK["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVCGmK["err"], txt)
  title = "PIcons Download Result"
  if not VVj61p:
   title += "  (cancelled)"
  FFXXd4(self, txt, title=title, VVQfS4=color)
 def VVoczP(self, VVv5LU, mode, progBarObj):
  totRows = VVv5LU.VVZyIO()
  progBarObj.VVR6pW(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CCczfG.VVpOjs()
  progBarObj.VVCGmK = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for rowNum, row in enumerate(VVv5LU.VVAVTk()):
    if progBarObj.isCancelled:
     break
    progBarObj.VVCGmK["proces"] += 1
    progBarObj.VVZ46l(1)
    if mode in ("itv", "vod", "series"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVgNoK(mode, row)
     refCode = CCdgmH.VVgfbn(catID, stID, chNum)
    elif mode == "m3u/m3u8":
     chName = row[1].strip()
     url  = row[3].strip()
     picUrl = row[4].strip()
     refCode = self.VVcuUi(rowNum, url, chName)
    else:
     chName, chUrl, picUrl, refCode = self.VVtAYV(mode, row)
    if picUrl:
     picon = refCode.replace(":", "_").rstrip("_") + ".png"
     if not fileExists(pPath + picon):
      progBarObj.VVCGmK["attempt"] += 1
      path, err = FFPMCM(picUrl, picon, timeout=1, mustBeImage=True)
      if path:
       progBarObj.VVCGmK["ok"] += 1
       if FFkJoP(path) > 0:
        cmd = ""
        if not mode == CCdgmH.VVHZdq:
         cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
        cmd += FFxZhj("mv -f '%s' '%s'" % (path, pPath)) + ";"
        os.system(cmd)
       else:
        progBarObj.VVCGmK["size0"] += 1
        os.system(FFxZhj("rm -f '%s'" % path))
      elif err:
       progBarObj.VVCGmK["fail"] += 1
       if any(x in err.lower() for x in ("time-out", "unauthorized")):
        progBarObj.VVCGmK["err"] = err.title()
        break
     else:
      progBarObj.VVCGmK["exist"] += 1
    else:
     progBarObj.VVCGmK["badURL"] += 1
  except:
   pass
 @staticmethod
 def VVDaN8(SELF):
  cmd = FF8XlR(VVlw3T, "ffmpeg")
  if cmd : FFO3om(SELF, cmd, title="Installing FFmpeg")
  else : FFmzPi(SELF)
 def VVZz7W(self):
  self.session.open(CC1Mzj, barTheme=CC1Mzj.VVIi6X
      , titlePrefix = ""
      , fncToRun  = self.VVbSI4
      , VVnyfB = self.VVs83C)
 def VVbSI4(self, progBarObj):
  bName = FFLFiD()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  progBarObj.VVCGmK = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = FFrAku()
  if not progBarObj or progBarObj.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   progBarObj.VVR6pW(totCh)
   for serv in services:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVZ46l(1)
    progBarObj.VV4hTf_fromImportEPG(totEpgOK, uChName)
    fullRef  = serv[0]
    if FFj0hS(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFmuAP(fullRef)
     span = iSearch(r"(mode=.+end=)", fullRef, IGNORECASE)
     if span:
      m3u_Url = CCOmmp.VVwFeJ(fullRef)
      uType, uHost, uUser, uPass, uId, uChName  = CCdgmH.VVinaS(fullRef)
      uType, uHost, uUser, uPass, uId, uChName1 = CCdgmH.VVinaS(m3u_Url)
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCdgmH.VVinaS(m3u_Url)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCdgmH.VVkBQE(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CClBuf.VVyZuo(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
      else:
       pass
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if progBarObj:
     progBarObj.VVCGmK = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   progBarObj.VVCGmK = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VVs83C(self, VVj61p, VVCGmK, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVCGmK
  title = "IPTV EPG Import"
  if err:
   FFkZTy(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFu1AK(str(totNotIptv), VVGMgi)
    if totServErr : txt += "Server Errors\t: %s\n" % FFu1AK(str(totServErr) + t1, VVGMgi)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFu1AK(str(totInv), VVGMgi)
   if not VVj61p:
    title += "  (stopped)"
   FFXXd4(self, txt, title=title)
 @staticmethod
 def VVkBQE(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCdgmH.VVexD6(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCdgmH.VVkFgl(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCdgmH.VVq4cU(item, "description" , is_base64=True ).replace("\n", " .. ")
    has_archive   = CCdgmH.VVq4cU(item, "has_archive"      )
    lang    = CCdgmH.VVq4cU(item, "lang"        ).upper()
    now_playing   = CCdgmH.VVq4cU(item, "now_playing"      )
    start    = CCdgmH.VVq4cU(item, "start"        )
    start_timestamp  = CCdgmH.VVq4cU(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCdgmH.VVq4cU(item, "start_timestamp"     )
    stop_timestamp  = CCdgmH.VVq4cU(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCdgmH.VVq4cU(item, "stop_timestamp"      )
    tTitle    = CCdgmH.VVq4cU(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVgfbn(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCdgmH.VVVGq7(catID, MAX_4b)
  TSID = CCdgmH.VVVGq7(chNum, MAX_4b)
  ONID = CCdgmH.VVVGq7(chNum, MAX_4b)
  NS  = CCdgmH.VVVGq7(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVVGq7(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVDdNq_forBouquet(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VV9Ys0(mode):
  if   mode in ("itv"  , CCdgmH.VVgaS0)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCdgmH.VVJow5)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCdgmH.VVISom) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCdgmH.VVuKHz) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCdgmH.VVTASE    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 @staticmethod
 def VViKUI(orExportPath=False):
  path = CFG.iptvHostsPath.getValue()
  if not pathExists(path) or path == VVDUxq:
   if orExportPath : path = CFG.exportedTablesPath.getValue()
   else   : path ="/"
  return FFk4Wy(path)
 @staticmethod
 def VVJB5h(SELF, hostUrl, chName, streamId, ok_fnc):
  title = "Catchup TV Programs"
  pList, err = CCdgmH.VVkBQE(hostUrl, streamId, True)
  if err:
   FFkZTy(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVZidB, VVCOuJ, VVQfS4, VVJk0D = CCdgmH.VV9Ys0("")
   VVyT4T = ("Home Menu" , FFCjjG, [])
   VVnutX  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVdQl9  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFlZ9Z(SELF, None, title="Programs for : " + chName, header=header, VVplFV=pList, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=24, VVnutX=VVnutX, VVyT4T=VVyT4T, VVZidB=VVZidB, VVCOuJ=VVCOuJ, VVQfS4=VVQfS4, VVJk0D=VVJk0D)
  else:
   FFkZTy(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVSYRJ(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 @staticmethod
 def VViEnd(SELF, isPortal, line, VV0IKZObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCdgmH.VViKUI(orExportPath=True)
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with open(path, "r") as f:
     for fLine in f:
      if line in fLine:
       FFkZTy(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFUwJf(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFkZTy(SELF, "Error:\n\n%s" % str(e), title=title)
class CCHgAO(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FF65g3(VVbnJN, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVn0QI  = 0
  self.VVc6gy = 1
  self.VVmX3L  = 2
  VV4YjP = []
  VV4YjP.append(("Find in All Service (from filter)" , "VVPxTv" ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Find in All (Manual Entry)"   , "VVq1FZ"    ))
  VV4YjP.append(("Find in TV"       , "VVlCTg"    ))
  VV4YjP.append(("Find in Radio"      , "VVfojV"   ))
  if self.VVvE18():
   VV4YjP.append(VV32Zp)
   VV4YjP.append(("Hide Channel: %s" % self.servName , "VVZ9tR"   ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Zap History"       , "VVAXWe"    ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("IPTV Tools"       , "iptv"      ))
  VV4YjP.append(("PIcons Tools"       , "PIconsTools"     ))
  VV4YjP.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FFC1qE(self, VV4YjP=VV4YjP, title=title)
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FF0PjP(self["myMenu"])
  FFahFV(self)
  if self.isFindMode:
   self.VVN0Pl(self.VV2jf0())
 def VVyEiI(self):
  global VVIzPF
  VVIzPF = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVq1FZ"    : self.VVq1FZ()
   elif item == "VVPxTv" : self.VVPxTv()
   elif item == "VVlCTg"    : self.VVlCTg()
   elif item == "VVfojV"   : self.VVfojV()
   elif item == "VVZ9tR"   : self.VVZ9tR()
   elif item == "VVAXWe"    : self.VVAXWe()
   elif item == "iptv"       : self.session.open(CCdgmH)
   elif item == "PIconsTools"     : self.session.open(CCczfG)
   elif item == "ChannelsTools"    : self.session.open(CCLdzJ)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVlCTg(self) : self.VVN0Pl(self.VVn0QI)
 def VVfojV(self) : self.VVN0Pl(self.VVc6gy)
 def VVq1FZ(self) : self.VVN0Pl(self.VVmX3L)
 def VVN0Pl(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFmIMB(self, boundFunction(self.VVHYnp, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVPxTv(self):
  filterObj = CCHLQj(self)
  filterObj.VV0VYy(self.VVKoVW)
 def VVKoVW(self, item):
  self.VVHYnp(self.VVmX3L, item)
 def VVvE18(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFj0hS(self.refCode)        : return False
  return True
 def VVHYnp(self, mode, VV9Wqy):
  FFxBTP(self, boundFunction(self.VVqSba, mode, VV9Wqy), title="Searching ...")
 def VVqSba(self, mode, VV9Wqy):
  if VV9Wqy:
   self.findTxt = VV9Wqy
   if   mode == self.VVn0QI  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVc6gy : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VV9Wqy)
   if len(title) > 55:
    title = title[:55] + ".."
   VVaXgj = self.VVGJty(VV9Wqy, servTypes)
   if self.isFindMode or mode == self.VVmX3L:
    VVaXgj += self.VVxWo6(VV9Wqy)
   if VVaXgj:
    VVaXgj.sort(key=lambda x: x[0].lower())
    VVDYxQ = self.VVJ62m
    VVnutX  = ("Zap"   , self.VV8STN    , [])
    VV5ydd = ("Current Service", self.VVHTiP , [])
    VVxHB1 = ("Options"  , self.VVPjuT , [])
    VVmtel = (""    , self.VVE55D , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVdQl9  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFlZ9Z(self, None, title=title, header=header, VVplFV=VVaXgj, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=26, VVnutX=VVnutX, VVDYxQ=VVDYxQ, VV5ydd=VV5ydd, VVxHB1=VVxHB1, VVmtel=VVmtel)
   else:
    self.VVN0Pl(self.VV2jf0())
    FFUwJf(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVGJty(self, VV9Wqy, servTypes):
  VVT0Y4  = eServiceCenter.getInstance()
  VVXZbC   = '%s ORDER BY name' % servTypes
  VVDDHV   = eServiceReference(VVXZbC)
  VVm9wS = VVT0Y4.list(VVDDHV)
  if VVm9wS: VVplFV = VVm9wS.getContent("CN", False)
  else     : VVplFV = None
  VVaXgj = []
  if VVplFV:
   VViiKj, VV66Bz = FFBt2Q()
   tp   = CCs7Me()
   words, asPrefix = CCHLQj.VVfQLS(VV9Wqy)
   colorYellow  = CC0o49.VVRteb(VVyveI)
   colorWhite  = CC0o49.VVRteb(VVO6Kg)
   for s in VVplFV:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFouUf(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VViiKj:
        STYPE = VV66Bz[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVC53J(refCode)
       if not "-S" in syst:
        sat = syst
       VVaXgj.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVaXgj
 def VVxWo6(self, VV9Wqy):
  VV9Wqy = VV9Wqy.lower()
  VVae8x = FFDRSE()
  VVaXgj = []
  colorYellow  = CC0o49.VVRteb(VVyveI)
  colorWhite  = CC0o49.VVRteb(VVO6Kg)
  if VVae8x:
   for b in VVae8x:
    VVjWHk  = b[0]
    VVS97Y  = b[1].toString()
    VV22w3 = eServiceReference(VVS97Y)
    VV2k2X = FFDOQH(VV22w3)
    for service in VV2k2X:
     refCode  = service[0]
     if FFj0hS(refCode):
      servName = service[1]
      if VV9Wqy in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VV9Wqy), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VVaXgj.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVaXgj
 def VV2jf0(self):
  VVuOoM = InfoBar.instance
  if VVuOoM:
   VVdQqo = VVuOoM.servicelist
   if VVdQqo:
    return VVdQqo.mode == 1
  return self.VVmX3L
 def VVJ62m(self, VVv5LU):
  self.close()
  VVv5LU.cancel()
 def VV8STN(self, VVv5LU, title, txt, colList):
  FFyH61(VVv5LU, colList[2], VVuGQM=False, checkParentalControl=True)
 def VVHTiP(self, VVv5LU, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(VVv5LU)
  if refCode:
   VVv5LU.VVmn28(2, FFskjD(refCode, iptvRef, chName), True)
 def VVPjuT(self, VVv5LU, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CClyEH(self, VVv5LU, 2)
  mSel.VVYalA(servName, refCode)
 def VVE55D(self, VVv5LU, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFgCFv(self, fncMode=CClBuf.VVVEIi, refCode=refCode, chName=chName, text=txt)
 def VVZ9tR(self):
  FFsJwx(self, self.VVotRC, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVotRC(self):
  ret = FFkMqo(self.refCode, True)
  if ret:
   self.VVIq3B()
   self.close()
  else:
   FFuCKD(self, "Cannot change state" , 1000)
 def VVIq3B(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVxpr3()
  except:
   self.VVgFos()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFFeUZ(self, serviceRef)
 def VVNJXp(self):
  VVuOoM = InfoBar.instance
  if VVuOoM:
   VVdQqo = VVuOoM.servicelist
   if VVdQqo:
    VVdQqo.setMode()
 def VVxpr3(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVuOoM = InfoBar.instance
   if VVuOoM:
    VVdQqo = VVuOoM.servicelist
    if VVdQqo:
     hList = VVdQqo.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVdQqo.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVdQqo.history  = newList
       VVdQqo.history_pos = pos
 def VVgFos(self):
  VVuOoM = InfoBar.instance
  if VVuOoM:
   VVdQqo = VVuOoM.servicelist
   if VVdQqo:
    VVdQqo.history  = []
    VVdQqo.history_pos = 0
 def VVAXWe(self):
  VVuOoM = InfoBar.instance
  VVaXgj = []
  if VVuOoM:
   VVdQqo = VVuOoM.servicelist
   if VVdQqo:
    VViiKj, VV66Bz = FFBt2Q()
    for chParams in VVdQqo.history:
     refCode = chParams[-1].toString()
     chName = FFCCrt(refCode)
     isIptv = FFj0hS(refCode)
     if isIptv: sat = "-"
     else  : sat = FFouUf(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VViiKj:
       STYPE = VV66Bz[sTypeInt]
     VVaXgj.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVaXgj:
   VVnutX  = ("Zap"   , self.VV7Dm1   , [])
   VVxHB1 = ("Clear History" , self.VVTOUY   , [])
   VVmtel = (""    , self.VV3LHUFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVdQl9  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFlZ9Z(self, None, title=title, header=header, VVplFV=VVaXgj, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=28, VVnutX=VVnutX, VVxHB1=VVxHB1, VVmtel=VVmtel)
  else:
   FFUwJf(self, "Not found", title=title)
 def VV7Dm1(self, VVv5LU, title, txt, colList):
  FFyH61(VVv5LU, colList[3], VVuGQM=False, checkParentalControl=True)
 def VVTOUY(self, VVv5LU, title, txt, colList):
  FFsJwx(self, boundFunction(self.VVobYb, VVv5LU), "Clear Zap History ?")
 def VVobYb(self, VVv5LU):
  self.VVgFos()
  VVv5LU.cancel()
 def VV3LHUFromZapHistory(self, VVv5LU, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFgCFv(self, fncMode=CClBuf.VVKZcD, refCode=refCode, chName=chName, text=txt)
class CCczfG(Screen):
 VV7qgt   = 0
 VV14eN  = 1
 VV5fEp  = 2
 VVijSN  = 3
 VVtAWj  = 4
 VV1FX8  = 5
 VVHNQ1  = 6
 VVZeKm  = 7
 VVQ7kp = 8
 VVo9kS = 9
 def __init__(self, session):
  self.skin, self.skinParam = FF65g3(VVLePB, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFC1qE(self, self.Title)
  FF3fcb(self["keyRed"] , "OK = Zap")
  FF3fcb(self["keyGreen"] , "Current Service")
  FF3fcb(self["keyYellow"], "Page Options")
  FF3fcb(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCczfG.VVpOjs()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVplFV    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVBJ1u        ,
   "green"   : self.VVD7Zh       ,
   "yellow"  : self.VVjYb9        ,
   "blue"   : self.VV3a07        ,
   "menu"   : self.VVOCkt        ,
   "info"   : self.VV3LHU         ,
   "up"   : self.VVfp4a          ,
   "down"   : self.VVwcmZ         ,
   "left"   : self.VVBx2y         ,
   "right"   : self.VVa5Bb         ,
   "pageUp"  : boundFunction(self.VVwPfL, True) ,
   "chanUp"  : boundFunction(self.VVwPfL, True) ,
   "pageDown"  : boundFunction(self.VVwPfL, False) ,
   "chanDown"  : boundFunction(self.VVwPfL, False) ,
   "next"   : self.VV1fvR        ,
   "last"   : self.VVVscY         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FFhBiL(self)
  FF7qhl(self)
  FFc3QD(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFxBTP(self, boundFunction(self.VV4Gjw, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVOCkt(self):
  if not self.isBusy:
   VV4YjP = []
   VV4YjP.append(("Statistics"           , "VVv9MP"    ))
   VV4YjP.append(VV32Zp)
   VV4YjP.append(("Suggest PIcons for Current Channel"     , "VVmK4Y"   ))
   VV4YjP.append(("Set to Current Channel (copy file)"     , "VVZgNq_file"  ))
   VV4YjP.append(("Set to Current Channel (as SymLink)"     , "VVZgNq_link"  ))
   VV4YjP.append(VV32Zp)
   VV4YjP.append(CCczfG.VVu3xL())
   VV4YjP.append(VV32Zp)
   if self.filterTitle == "PIcons without Channels":
    c = VVGMgi
    VV4YjP.append((FFu1AK("Move Unused PIcons to a Directory", c) , "VVkvpy"  ))
    VV4YjP.append((FFu1AK("DELETE Unused PIcons", c)    , "VV4gAw" ))
    VV4YjP.append(VV32Zp)
   VV4YjP.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVpBfY"  ))
   VV4YjP.append(VV32Zp)
   VV4YjP += CCczfG.VVGvzo()
   VV4YjP.append(VV32Zp)
   VV4YjP.append(("RCU Keys Help"          , "VVHzkB"    ))
   FF2oO5(self, self.VVBO8S, title=self.Title, VV4YjP=VV4YjP)
 def VVBO8S(self, item=None):
  if item is not None:
   if   item == "VVv9MP"     : self.VVv9MP()
   elif item == "VVmK4Y"    : self.VVmK4Y()
   elif item == "VVZgNq_file"   : self.VVZgNq(0)
   elif item == "VVZgNq_link"   : self.VVZgNq(1)
   elif item == "VVIdiF_file"  : self.VVIdiF(0)
   elif item == "VVIdiF_link"  : self.VVIdiF(1)
   elif item == "VVel8V"   : self.VVel8V()
   elif item == "VVAF4k"  : self.VVAF4k()
   elif item == "VVkvpy"    : self.VVkvpy()
   elif item == "VV4gAw"   : self.VV4gAw()
   elif item == "VVpBfY"   : self.VVpBfY()
   elif item == "VVAXvZ"   : CCczfG.VVAXvZ(self)
   elif item == "VVkqn2"   : CCczfG.VVkqn2(self)
   elif item == "findPiconBrokenSymLinks"  : CCczfG.VV5uyo(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCczfG.VV5uyo(self, False)
   elif item == "VVHzkB"      : self.VVHzkB()
 def VVjYb9(self):
  if not self.isBusy:
   VV4YjP = []
   VV4YjP.append(("Go to First PIcon"  , "VVqHkq"  ))
   VV4YjP.append(("Go to Last PIcon"   , "VVNKVj"  ))
   VV4YjP.append(VV32Zp)
   VV4YjP.append(("Sort by Channel Name"     , "sortByChan" ))
   VV4YjP.append(("Sort by File Name"  , "sortByFile" ))
   VV4YjP.append(VV32Zp)
   VV4YjP.append(("Find from File List .." , "VVvGeQ" ))
   FF2oO5(self, self.VVsPfC, title=self.Title, VV4YjP=VV4YjP)
 def VVsPfC(self, item=None):
  if item is not None:
   if   item == "VVqHkq"   : self.VVqHkq()
   elif item == "VVNKVj"   : self.VVNKVj()
   elif item == "sortByChan"  : self.VVV0kT(2)
   elif item == "sortByFile"  : self.VVV0kT(0)
   elif item == "VVvGeQ"  : self.VVvGeQ()
 def VVHzkB(self):
  FFKyDS(self, VVII1V + "_help_picons", "PIcons Manager (Keys Help)")
 def VVfp4a(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVNKVj()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VV9niX()
 def VVwcmZ(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVqHkq()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VV9niX()
 def VVBx2y(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVNKVj()
  else:
   self.curCol -= 1
   self.VV9niX()
 def VVa5Bb(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVqHkq()
  else:
   self.curCol += 1
   self.VV9niX()
 def VVVscY(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VV9niX(True)
 def VV1fvR(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VV9niX(True)
 def VVqHkq(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VV9niX(True)
 def VVNKVj(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VV9niX(True)
 def VVvGeQ(self):
  VV4YjP = []
  for item in self.VVplFV:
   VV4YjP.append((item[0], item[0]))
  FF2oO5(self, self.VVRzEd, title='PIcons ".png" Files', VV4YjP=VV4YjP, VVmPdS=True)
 def VVRzEd(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVhEZN(ndx)
 def VVBJ1u(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVjhjq()
   if refCode:
    FFyH61(self, refCode)
    self.VVfgxL()
    self.VVjx64()
 def VVwPfL(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVfgxL()
   self.VVjx64()
  except:
   pass
 def VVD7Zh(self):
  if self["keyGreen"].getVisible():
   self.VVhEZN(self.curChanIndex)
 def VVhEZN(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VV9niX(True)
  else:
   FFuCKD(self, "Not found", 1000)
 def VVV0kT(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFxBTP(self, boundFunction(self.VV4Gjw, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVZgNq(self, mode):
  title = "Change Current Channel PIcon"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVjhjq()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VV4YjP = []
     VV4YjP.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VV4YjP.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FF2oO5(self, boundFunction(self.VVeZol, mode, curChF, selPiconF), VV4YjP=VV4YjP, title="Current Channel PIcon (already exists)")
    else:
     self.VVeZol(mode, curChF, selPiconF, "overwrite")
   else:
    FFkZTy(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFkZTy(self, "Could not read current channel info. !", title=title)
 def VVeZol(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFxBTP(self, boundFunction(self.VV4Gjw, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVIdiF(self, mode):
  pass
 def VVel8V(self):
  pass
 def VVAF4k(self):
  pass
 def VVkvpy(self):
  defDir = FFk4Wy(CCczfG.VVpOjs() + "picons_backup")
  os.system(FFxZhj("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(boundFunction(self.VVvVBJ, defDir), boundFunction(CC5T3l
         , mode=CC5T3l.VVRWCr, VViCpT=CCczfG.VVpOjs()))
 def VVvVBJ(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCczfG.VVpOjs():
    FFkZTy(self, "Cannot move to same directory !", title=title)
   else:
    if not FFk4Wy(path) == FFk4Wy(defDir):
     self.VVOUjp(defDir)
    FFsJwx(self, boundFunction(FFxBTP, self, boundFunction(self.VVgf0c, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVplFV), path), title=title)
  else:
   self.VVOUjp(defDir)
 def VVgf0c(self, title, defDir, toPath):
  try:
   from shutil import move as iMove
  except:
   self.VVOUjp(defDir)
   FFkZTy(self, 'Could not load "shutil" module !', title=title)
   return
  toPath = FFk4Wy(toPath)
  pPath = CCczfG.VVpOjs()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVplFV:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVplFV)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFXXd4(self, txt, title=title, VVQfS4="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVSvIl("all")
 def VVOUjp(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VV4gAw(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVplFV)
  s = "s" if tot > 1 else ""
  FFsJwx(self, boundFunction(FFxBTP, self, boundFunction(self.VVMUGY, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, s), title=title)
 def VVMUGY(self, title):
  pPath = CCczfG.VVpOjs()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVplFV:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVplFV)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFu1AK(str(totErr), VVGMgi)
  FFXXd4(self, txt, title=title)
 def VVpBfY(self):
  lines = FFwhw7("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFsJwx(self, boundFunction(self.VVGA3g, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVEGkV=True)
  else:
   FFUwJf(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVGA3g(self, fList):
  os.system(FFxZhj("find -L '%s' -type l -delete" % self.pPath))
  FFUwJf(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VV3LHU(self):
  FFxBTP(self, self.VVWzvU)
 def VVWzvU(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVjhjq()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFu1AK("PIcon Directory:\n", VVNRRl)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFVuf4(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFVuf4(path)
   txt += FFu1AK("PIcon File:\n", VVNRRl)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFwhw7(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFu1AK("Found %d SymLink%s to this file from:\n" % (tot, s), VVNRRl)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFCCrt(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFu1AK(tChName, VVG7vV)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFu1AK(line, VVKXn9), tChName)
    txt += "\n"
   if chName:
    txt += FFu1AK("Channel:\n", VVNRRl)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFu1AK(chName, VVG7vV)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFu1AK("Remarks:\n", VVNRRl)
    txt += "  %s\n" % FFu1AK("Unused", VVGMgi)
  else:
   txt = "No info found"
  FFgCFv(self, fncMode=CClBuf.VVvA7r, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVjhjq(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVplFV[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFLu71(sat)
  return fName, refCode, chName, sat, inDB
 def VVfgxL(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVplFV):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVjx64(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVjhjq()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFu1AK("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVNRRl))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVjhjq()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFu1AK(self.curChanName, VVyveI)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVv9MP(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VVplFV:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFoABH("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFXXd4(self, txt, title=self.Title)
 def VV3a07(self):
  if not self.isBusy:
   VV4YjP = []
   VV4YjP.append(("All"         , "all"   ))
   VV4YjP.append(VV32Zp)
   VV4YjP.append(("Used by Channels"      , "used"  ))
   VV4YjP.append(("Unused PIcons"      , "unused"  ))
   VV4YjP.append(VV32Zp)
   VV4YjP.append(("PIcons Files"       , "pFiles"  ))
   VV4YjP.append(("SymLinks to PIcons"     , "pLinks"  ))
   VV4YjP.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VV4YjP.append(VV32Zp)
   VV4YjP.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VV4YjP.append(VV32Zp)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFciDZ(val)
      VV4YjP.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCHLQj(self)
   filterObj.VVVKbW(VV4YjP, self.nsList, self.VVytWj)
 def VVytWj(self, item=None):
  if item is not None:
   self.VVSvIl(item)
 def VVSvIl(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VV7qgt   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VV14eN   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VV5fEp  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVijSN  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVtAWj  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VV1FX8  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVHNQ1   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVZeKm   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVQ7kp , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VV1FX8:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFwhw7("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFuCKD(self, "Not found", 1000)
     return
   elif mode == self.VVo9kS:
    return
   else:
    words, asPrefix = CCHLQj.VVfQLS(words)
   if not words and mode in (self.VVZeKm, self.VVQ7kp):
    FFuCKD(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFxBTP(self, boundFunction(self.VV4Gjw, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVmK4Y(self):
  self.session.open(CC1Mzj, barTheme=CC1Mzj.VVEZCt
      , titlePrefix = ""
      , fncToRun  = self.VVWNt4
      , VVnyfB = self.VVw57Y)
 def VVWNt4(self, progBarObj):
  lameDbChans = CCLdzJ.VVj0Np(self, CCLdzJ.VV4nmj, VVs2Hw=False, VVC4JZ=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVCGmK = []
  progBarObj.VVR6pW(len(lameDbChans))
  if lameDbChans:
   processChanName = CCdnf7()
   curCh = processChanName.VVVUxR(self.curChanName)
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVZ46l(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCczfG.VVMQzN(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCczfG.VVa4zS(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VVCGmK.append(f.replace(".png", ""))
 def VVw57Y(self, VVj61p, VVCGmK, threadCounter, threadTotal, threadErr):
  if VVCGmK:
   self.timer = eTimer()
   fnc = boundFunction(FFxBTP, self, boundFunction(self.VV4Gjw, mode=self.VVo9kS, words=VVCGmK), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FFuCKD(self, "Not found", 2000)
 def VV4Gjw(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VV8WJi(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCLdzJ.VVj0Np(self, CCLdzJ.VV4nmj, VVs2Hw=False, VVC4JZ=False)
  iptvRefList = self.VV8hDC()
  tList = []
  for fName, fType in CCczfG.VVVvYS(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VV7qgt:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VV14eN  and chName         : isAdd = True
   elif mode == self.VV5fEp and not chName        : isAdd = True
   elif mode == self.VVijSN  and fType == 0        : isAdd = True
   elif mode == self.VVtAWj  and fType == 1        : isAdd = True
   elif mode == self.VV1FX8  and fName in words       : isAdd = True
   elif mode == self.VVo9kS and fName in words       : isAdd = True
   elif mode == self.VVHNQ1  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVZeKm  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVQ7kp:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVplFV   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFuCKD(self)
  else:
   self.isBusy = False
   FFuCKD(self, "Not found", 1000)
   return
  self.VVplFV.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVfgxL()
  self.totalPIcons = len(self.VVplFV)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VV9niX(True)
 def VV8WJi(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCczfG.VVVvYS(self.pPath):
    if fName:
     return True
   if isFirstTime : FFkZTy(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFuCKD(self, "Not found", 1000)
  else:
   FFkZTy(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VV8hDC(self):
  VVaXgj = {}
  files  = CCdgmH.VVxyR1(self)
  if files:
   for path in files:
    txt = FFQiI5(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVaXgj[refCode] = item[1]
  return VVaXgj
 def VV9niX(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVUvZl = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVUvZl: self.curPage = VVUvZl
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVy5Hx()
  if self.curPage == VVUvZl:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVjx64()
  filName, refCode, chName, sat, inDB = self.VVjhjq()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVy5Hx(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVplFV[ndx]
   fName = self.VVplFV[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFu1AK(chName, VVG7vV))
    else : lbl.setText("-")
   except:
    lbl.setText(FFu1AK(chName, VV9edY))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVMQzN(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVu3xL():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVAXvZ"   )
 @staticmethod
 def VVGvzo():
  VV4YjP = []
  VV4YjP.append(("Find SymLinks (to PIcon Directory)"   , "VVkqn2"   ))
  VV4YjP.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VV4YjP.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VV4YjP
 @staticmethod
 def VVAXvZ(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(SELF)
  png, path = CCczfG.VVSBo0(refCode)
  if path : CCczfG.VVOCcE(SELF, png, path)
  else : FFkZTy(SELF, "No PIcon found for current channel in:\n\n%s" % CCczfG.VVpOjs())
 @staticmethod
 def VVkqn2(SELF):
  if VVyveI:
   sed1 = FF8EkF("->", VVyveI)
   sed2 = FF8EkF("picon", VVGMgi)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VV9edY, VVO6Kg)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFRkbo(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFomXb(), grep, sed1, sed2, sed3))
 @staticmethod
 def VV5uyo(SELF, isPIcon):
  sed1 = FF8EkF("->", VV9edY)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FF8EkF("picon", VVGMgi)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFRkbo(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFomXb(), grep, sed1, sed2))
 @staticmethod
 def VVVvYS(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVpOjs():
  path = CFG.PIconsPath.getValue()
  return FFk4Wy(path)
 @staticmethod
 def VVSBo0(refCode, chName=None):
  if FFj0hS(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFmuAP(refCode)
  allPath, fName, refCodeFile, pList = CCczfG.VVa4zS(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVOCcE(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FF8EkF("%s%s" % (dest, png), VVG7vV))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FF8EkF(errTxt, VVMioC))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFb4nu(SELF, cmd)
 @staticmethod
 def VVa4zS(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCczfG.VVpOjs()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFrQie(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CC5Has():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVH8O4  = None
  self.VVuAqu = ""
  self.VV4whF  = noService
  self.VVAWkx = 0
  self.VVgAn2  = noService
  self.VVfxNB = 0
  self.VVDIGe  = "-"
  self.VVSio8 = 0
  self.VV1gcz  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVRvmD(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVH8O4 = frontEndStatus
     self.VVFaBx()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVFaBx(self):
  if self.VVH8O4:
   val = self.VVH8O4.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVuAqu = "%3.02f dB" % (val / 100.0)
   else         : self.VVuAqu = ""
   val = self.VVH8O4.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVAWkx = int(val)
   self.VV4whF  = "%d%%" % val
   val = self.VVH8O4.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVfxNB = int(val)
   self.VVgAn2  = "%d%%" % val
   val = self.VVH8O4.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVDIGe  = "%d" % val
   val = int(val * 100 / 500)
   self.VVSio8 = min(500, val)
   val = self.VVH8O4.get("tuner_locked", 0)
   if val == 1 : self.VV1gcz = "Locked"
   else  : self.VV1gcz = "Not locked"
 def VVVxOz(self)   : return self.VVuAqu
 def VV3KGq(self)   : return self.VV4whF
 def VVzzVE(self)  : return self.VVAWkx
 def VVHG4A(self)   : return self.VVgAn2
 def VVWfRn(self)  : return self.VVfxNB
 def VVbaY8(self)   : return self.VVDIGe
 def VV194y(self)  : return self.VVSio8
 def VVu443(self)   : return self.VV1gcz
 def VVO503(self) : return self.serviceName
class CCs7Me():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVyRjK(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFjwxs(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVVyuY(self.ORPOS  , mod=1   )
      self.sat2  = self.VVVyuY(self.ORPOS  , mod=2   )
      self.freq  = self.VVVyuY(self.FREQ  , mod=3   )
      self.sr   = self.VVVyuY(self.SR   , mod=4   )
      self.inv  = self.VVVyuY(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVVyuY(self.POL  , self.D_POL )
      self.fec  = self.VVVyuY(self.FEC  , self.D_FEC )
      self.syst  = self.VVVyuY(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVVyuY("modulation" , self.D_MOD )
       self.rolof = self.VVVyuY("rolloff"  , self.D_ROLOF )
       self.pil = self.VVVyuY("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVVyuY("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVVyuY("pls_code"  )
       self.iStId = self.VVVyuY("is_id"   )
       self.t2PlId = self.VVVyuY("t2mi_plp_id" )
       self.t2PId = self.VVVyuY("t2mi_pid"  )
 def VVVyuY(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFciDZ(val)
  elif mod == 2   : return FFsxV0(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVm0i2(self, refCode):
  txt = ""
  self.VVyRjK(refCode)
  if self.data:
   def VV4FHA(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VV4FHA("System"   , self.syst)
    txt += VV4FHA("Satellite"  , self.sat2)
    txt += VV4FHA("Frequency"  , self.freq)
    txt += VV4FHA("Inversion"  , self.inv)
    txt += VV4FHA("Symbol Rate"  , self.sr)
    txt += VV4FHA("Polarization" , self.pol)
    txt += VV4FHA("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VV4FHA("Modulation" , self.mod)
     txt += VV4FHA("Roll-Off" , self.rolof)
     txt += VV4FHA("Pilot"  , self.pil)
     txt += VV4FHA("Input Stream", self.iStId)
     txt += VV4FHA("T2MI PLP ID" , self.t2PlId)
     txt += VV4FHA("T2MI PID" , self.t2PId)
     txt += VV4FHA("PLS Mode" , self.plsMod)
     txt += VV4FHA("PLS Code" , self.plsCod)
   else:
    txt += VV4FHA("System"   , self.txMedia)
    txt += VV4FHA("Frequency"  , self.freq)
  return txt, self.namespace
 def VV6cX7(self, refCode):
  txt = "Transpoder : ?"
  self.VVyRjK(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVNRRl + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVC53J(self, refCode):
  self.data = None
  servRef = eServiceReference(refCode)
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFjwxs(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVVyuY(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVVyuY(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVVyuY(self.SYST, self.D_SYS_S)
     freq = self.VVVyuY(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVVyuY(self.POL , self.D_POL)
      fec = self.VVVyuY(self.FEC , self.D_FEC)
      sr = self.VVVyuY(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVArtb(self, refCode):
  self.data = None
  self.VVyRjK(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCU5Qm():
 def __init__(self, VVn2fq, path, VVnyfB=None, curRowNum=-1):
  self.VVn2fq  = VVn2fq
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVnyfB  = VVnyfB
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFxZhj("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVwTCI(curRowNum)
  else:
   FFkZTy(self.VVn2fq, "Error while preparing edit!")
 def VVwTCI(self, curRowNum):
  VVaXgj = self.VVtv8K()
  VVyT4T = None #("Delete Line" , self.deleteLine  , [])
  VV5ydd = ("Save Changes" , self.VVRfPk   , [])
  VVnutX  = ("Edit Line"  , self.VVkD5f    , [])
  VV487W = ("Line Options" , self.VVkWMj   , [])
  VVFSRM = (""    , self.VV0kjU , [])
  VVDYxQ = self.VV6AR0
  VVWxNV  = self.VV0LaO
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVdQl9  = (CENTER  , LEFT  )
  VVv5LU = FFlZ9Z(self.VVn2fq, None, title=self.Title, header=header, VVplFV=VVaXgj, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=26, VVyT4T=VVyT4T, VV5ydd=VV5ydd, VVnutX=VVnutX, VV487W=VV487W, VVDYxQ=VVDYxQ, VVWxNV=VVWxNV, VVFSRM=VVFSRM, VVwbEy=True
    , VVZidB   = "#11001111"
    , VVCOuJ   = "#11001111"
    , VVQfS4   = "#11001111"
    , VVJk0D  = "#05333333"
    , VVJSW4  = "#00222222"
    , VVpNa2  = "#11331133"
    )
  VVv5LU.VVuh97(curRowNum)
 def VVkWMj(self, VVv5LU, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVv5LU.VVccPf()
  VV4YjP = []
  VV4YjP.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VV4YjP.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVYCRx"  ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVakf1:
   VV4YjP.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(  ("Delete Line"         , "deleteLine"   ))
  FF2oO5(self.VVn2fq, boundFunction(self.VVYxN7, VVv5LU, lineNum), VV4YjP=VV4YjP, title="Line Options")
 def VVYxN7(self, VVv5LU, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VV46Ew("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVv5LU)
   elif item == "VVYCRx"  : self.VVYCRx(VVv5LU, lineNum)
   elif item == "copyToClipboard"  : self.VVfhhL(VVv5LU, lineNum)
   elif item == "pasteFromClipboard" : self.VVUZHA(VVv5LU, lineNum)
   elif item == "deleteLine"   : self.VV46Ew("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVv5LU)
 def VV0LaO(self, VVv5LU):
  VVv5LU.VV2DL0()
 def VV0kjU(self, VVv5LU, title, txt, colList):
  if   self.insertMode == 1: VVv5LU.VVvTPg()
  elif self.insertMode == 2: VVv5LU.VVCeyG()
  self.insertMode = 0
 def VVYCRx(self, VVv5LU, lineNum):
  if lineNum == VVv5LU.VVccPf():
   self.insertMode = 1
   self.VV46Ew("echo '' >> '%s'" % self.tmpFile, VVv5LU)
  else:
   self.insertMode = 2
   self.VV46Ew("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVv5LU)
 def VVfhhL(self, VVv5LU, lineNum):
  global VVakf1
  VVakf1 = FFoABH("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVv5LU.VVd3iE("Copied to clipboard")
 def VVRfPk(self, VVv5LU, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFxZhj("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFxZhj("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVv5LU.VVd3iE("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVv5LU.VV2DL0()
    else:
     FFkZTy(self.VVn2fq, "Cannot save file!")
   else:
    FFkZTy(self.VVn2fq, "Cannot create backup copy of original file!")
 def VV6AR0(self, VVv5LU):
  if self.fileChanged:
   FFsJwx(self.VVn2fq, boundFunction(self.VVtahP, VVv5LU), "Cancel changes ?")
  else:
   finalOK = os.system(FFxZhj("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVtahP(VVv5LU)
 def VVtahP(self, VVv5LU):
  VVv5LU.cancel()
  os.system(FFxZhj("rm -f '%s'" % self.tmpFile))
  if self.VVnyfB:
   self.VVnyfB(self.fileSaved)
 def VVkD5f(self, VVv5LU, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVO6Kg + "ORIGINAL TEXT:\n" + VVKXn9 + lineTxt
  FFmIMB(self.VVn2fq, boundFunction(self.VV79kB, lineNum, VVv5LU), title="File Line", defaultText=lineTxt, message=message)
 def VV79kB(self, lineNum, VVv5LU, VV1tLf):
  if not VV1tLf is None:
   if VVv5LU.VVccPf() <= 1:
    self.VV46Ew("echo %s > '%s'" % (VV1tLf, self.tmpFile), VVv5LU)
   else:
    self.VVOa3v(VVv5LU, lineNum, VV1tLf)
 def VVUZHA(self, VVv5LU, lineNum):
  if lineNum == VVv5LU.VVccPf() and VVv5LU.VVccPf() == 1:
   self.VV46Ew("echo %s >> '%s'" % (VVakf1, self.tmpFile), VVv5LU)
  else:
   self.VVOa3v(VVv5LU, lineNum, VVakf1)
 def VVOa3v(self, VVv5LU, lineNum, newTxt):
  VVv5LU.VVNe8y("Saving ...")
  lines = FFghv7(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVv5LU.VVwi01()
  VVaXgj = self.VVtv8K()
  VVv5LU.VVFYEc(VVaXgj)
 def VV46Ew(self, cmd, VVv5LU):
  tCons = CCJC8z()
  tCons.ePopen(cmd, boundFunction(self.VVyRRH, VVv5LU))
  self.fileChanged = True
  VVv5LU.VVwi01()
 def VVyRRH(self, VVv5LU, result, retval):
  VVaXgj = self.VVtv8K()
  VVv5LU.VVFYEc(VVaXgj)
 def VVtv8K(self):
  if fileExists(self.tmpFile):
   lines = FFghv7(self.tmpFile)
   VVaXgj = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVaXgj.append((str(ndx), line.strip()))
   if not VVaXgj:
    VVaXgj.append((str(1), ""))
   return VVaXgj
  else:
   FFLxgb(self.VVn2fq, self.tmpFile)
class CCHLQj():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VV4YjP   = []
  self.satList   = []
 def VV0VYy(self, VVnyfB):
  self.VV4YjP = []
  VV4YjP, VVtoZ5 = self.VV2yr1(False, True)
  if VV4YjP:
   self.VV4YjP += VV4YjP
   self.VVw3rK(VVnyfB, VVtoZ5)
 def VV1am9(self, mode, VVv5LU, satCol, VVnyfB):
  VVv5LU.VVNe8y("Loading Filters ...")
  self.VV4YjP = []
  self.VV4YjP.append(("All Services" , "all"))
  if mode == 1:
   self.VV4YjP.append(VV32Zp)
   self.VV4YjP.append(("Parental Control", "parentalControl"))
   self.VV4YjP.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VV4YjP.append(VV32Zp)
   self.VV4YjP.append(("Selected Transponder"   , "selectedTP" ))
   self.VV4YjP.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVM6s3(VVv5LU, satCol)
  VV4YjP, VVtoZ5 = self.VV2yr1(True, False)
  if VV4YjP:
   VV4YjP.insert(0, VV32Zp)
   self.VV4YjP += VV4YjP
  VVv5LU.VVczFt()
  self.VVw3rK(VVnyfB, VVtoZ5)
 def VVVKbW(self, VV4YjP, sats, VVnyfB):
  self.VV4YjP = VV4YjP
  VV4YjP, VVtoZ5 = self.VV2yr1(True, False)
  if VV4YjP:
   self.VV4YjP.append(VV32Zp)
   self.VV4YjP += VV4YjP
  self.VVw3rK(VVnyfB, VVtoZ5)
 def VVw3rK(self, VVnyfB, VVtoZ5):
  VVRGLF = ("Edit Filter", boundFunction(self.VV6upc, VVtoZ5))
  VVlEXM  = ("Filter Help", boundFunction(self.VV7MSX, VVtoZ5))
  FF2oO5(self.callingSELF, boundFunction(self.VV0fge, VVnyfB), VV4YjP=self.VV4YjP, title="Select Filter", VVRGLF=VVRGLF, VVlEXM=VVlEXM)
 def VV0fge(self, VVnyfB, item):
  if item:
   VVnyfB(item)
 def VV6upc(self, VVtoZ5, VV0IKZObj, sel):
  if fileExists(VVtoZ5) : CCU5Qm(self.callingSELF, VVtoZ5, VVnyfB=None)
  else       : FFLxgb(self.callingSELF, VVtoZ5)
  VV0IKZObj.cancel()
 def VV7MSX(self, VVtoZ5, VV0IKZObj, sel):
  FFKyDS(self.callingSELF, VVII1V + "_help_service_filter", "Service Filter")
 def VVM6s3(self, VVv5LU, satColNum):
  if not self.satList:
   satList = VVv5LU.VVDPhr(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFLu71(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VV32Zp)
  if self.VV4YjP:
   self.VV4YjP += self.satList
 def VV2yr1(self, addTag, VVKlD3):
  FFO8k9()
  fileName  = "ajpanel_services_filter"
  VVtoZ5 = VVA6fc + fileName
  VV4YjP  = []
  if not fileExists(VVtoZ5):
   os.system(FFxZhj("cp -f '%s' '%s'" % (VVII1V + fileName, VVtoZ5)))
  fileFound = False
  if fileExists(VVtoZ5):
   fileFound = True
   lines = FFghv7(VVtoZ5)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VV4YjP.append((line, "__w__" + line))
       else  : VV4YjP.append((line, line))
  if VVKlD3:
   if   not fileFound : FFLxgb(self.callingSELF , VVtoZ5)
   elif not VV4YjP : FF4o1U(self.callingSELF , VVtoZ5)
  return VV4YjP, VVtoZ5
 @staticmethod
 def VVfQLS(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CClyEH():
 def __init__(self, callingSELF, VVv5LU, refCodeColNum):
  self.callingSELF = callingSELF
  self.VVv5LU = VVv5LU
  self.refCodeColNum = refCodeColNum
  self.VV4YjP = []
  iMulSel = self.VVv5LU.VVJIVC()
  if iMulSel : self.VV4YjP.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VV4YjP.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVv5LU.VVajbj()
  self.VV4YjP.append(    ("Select all"    , "selectAll"  ))
  if tot > 0:
   self.VV4YjP.append(   ("Unselect all"    , "unselectAll"  ))
  self.VV4YjP.append(VV32Zp)
 def VVYalA(self, servName, refCode):
  tot = self.VVv5LU.VVajbj()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VV4YjP.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVS8Kt_multi" ))
  else    : self.VV4YjP.append( ("Add to Bouquet : %s"      % servName , "VVS8Kt_one" ))
  self.VVbKKY(servName, refCode)
 def VVuKsr(self, servName, refCode, pcState, hidState):
  self.VV4YjP = []
  if pcState == "No" : self.VV4YjP.append(("Add to Parental Control"  , "parentalControl_add"  ))
  else    : self.VV4YjP.append(("Remove from Parental Control" , "parentalControl_remove" ))
  if hidState == "No" : self.VV4YjP.append(("Add to Hidden Services"  , "hiddenServices_add"  ))
  else    : self.VV4YjP.append(("Remove from Hidden Services" , "hiddenServices_remove" ))
  self.VVbKKY(servName, refCode)
 def VVbKKY(self, servName, refCode):
  FF2oO5(self.callingSELF, boundFunction(self.VV2Iex, servName, refCode), title="Options", VV4YjP=self.VV4YjP)
 def VV2Iex(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"    : self.VVv5LU.VV6UOE(True)
   elif item == "MultSelDisab"    : self.VVv5LU.VV6UOE(False)
   elif item == "selectAll"    : self.VVv5LU.VV8R7M()
   elif item == "unselectAll"    : self.VVv5LU.VVAvpE()
   elif item == "parentalControl_add"  : self.callingSELF.VVD5zP(self.VVv5LU, refCode, True)
   elif item == "parentalControl_remove" : self.callingSELF.VVD5zP(self.VVv5LU, refCode, False)
   elif item == "hiddenServices_add"  : self.callingSELF.VVeMlh(self.VVv5LU, refCode, True)
   elif item == "hiddenServices_remove" : self.callingSELF.VVeMlh(self.VVv5LU, refCode, False)
   elif item == "VVS8Kt_multi" : self.VVS8Kt(refCode, True)
   elif item == "VVS8Kt_one" : self.VVS8Kt(refCode, False)
 def VVS8Kt(self, refCode, isMulti):
  bouquets = FFDRSE()
  if bouquets:
   VV4YjP = []
   for item in bouquets:
    VV4YjP.append((item[0], item[1].toString()))
   VVRGLF = ("Create New", boundFunction(self.VVTne4, refCode, isMulti))
   FF2oO5(self.callingSELF, boundFunction(self.VV0Ys9, refCode, isMulti), VV4YjP=VV4YjP, title="Add to Bouquet", VVRGLF=VVRGLF, VVmPdS=True, VVydPQ=True)
  else:
   FFsJwx(self.callingSELF, boundFunction(self.VVNBdo, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VV0Ys9(self, refCode, isMulti, bName=None):
  if bName:
   FFxBTP(self.VVv5LU, boundFunction(self.VVGPrS, refCode, isMulti, bName), title="Adding Channels ...")
 def VVGPrS(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVIMjb(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVuOoM = InfoBar.instance
    if VVuOoM:
     VVdQqo = VVuOoM.servicelist
     if VVdQqo:
      mutableList = VVdQqo.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVv5LU.VVczFt()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFUwJf(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFkZTy(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVIMjb(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVv5LU.VVO0aN(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVTne4(self, refCode, isMulti, VV0IKZObj, path):
  self.VVNBdo(refCode, isMulti)
 def VVNBdo(self, refCode, isMulti):
  FFmIMB(self.callingSELF, boundFunction(self.VVOklr, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVOklr(self, refCode, isMulti, name):
  if name:
   FFxBTP(self.VVv5LU, boundFunction(self.VV2B0E, refCode, isMulti, name), title="Adding Channels ...")
 def VV2B0E(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVIMjb(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVuOoM = InfoBar.instance
    if VVuOoM:
     VVdQqo = VVuOoM.servicelist
     if VVdQqo:
      try:
       VVdQqo.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVdQqo.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVv5LU.VVczFt()
   title = "Add to Bouquet"
   if allOK: FFUwJf(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFkZTy(self.callingSELF, "Nothing added!", title=title)
class CC2sbR(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF65g3(VVxeiM, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFC1qE(self)
  FF3fcb(self["keyRed"]  , "Exit")
  FF3fcb(self["keyGreen"]  , "Save")
  FF3fcb(self["keyYellow"] , "Refresh")
  FF3fcb(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV5NgR  ,
   "green"   : self.VVLq7F ,
   "yellow"  : self.VVUeiS  ,
   "blue"   : self.VVh61d   ,
   "up"   : self.VVfp4a    ,
   "down"   : self.VVwcmZ   ,
   "left"   : self.VVBx2y   ,
   "right"   : self.VVa5Bb   ,
   "cancel"  : self.VV5NgR
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVUeiS()
  self.VV84CM()
  FF7qhl(self)
 def VV5NgR(self) : self.close(True)
 def VVlv4E(self) : self.close(False)
 def VVh61d(self):
  self.session.openWithCallback(self.VV2vlC, boundFunction(CCJmC0))
 def VV2vlC(self, closeAll):
  if closeAll:
   self.close()
 def VVfp4a(self):
  self.VVRMGa(1)
 def VVwcmZ(self):
  self.VVRMGa(-1)
 def VVBx2y(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VV84CM()
 def VVa5Bb(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VV84CM()
 def VVRMGa(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVmJOX(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVmJOX(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVmJOX(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVpd3f(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVpd3f(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VV84CM(self):
  for obj in self.list:
   FFc3QD(obj, "#11404040")
  FFc3QD(self.list[self.index], "#11ff8000")
 def VVUeiS(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVLq7F(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCJC8z()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVyHcD)
 def VVyHcD(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFUwJf(self, "Nothing returned from the system!")
  else:
   FFUwJf(self, str(result))
class CCJmC0(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF65g3(VVYQha, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFC1qE(self, addLabel=True)
  FF3fcb(self["keyRed"]  , "Exit")
  FF3fcb(self["keyGreen"]  , "Sync")
  FF3fcb(self["keyYellow"] , "Refresh")
  FF3fcb(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV5NgR   ,
   "green"   : self.VVZRLr  ,
   "yellow"  : self.VVCPGr ,
   "blue"   : self.VVC54u  ,
   "cancel"  : self.VV5NgR
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVt27O()
  self.onShow.append(self.start)
 def start(self):
  FF4knh(self.refresh)
  FF7qhl(self)
 def refresh(self):
  self.VVsuOx()
  self.VVGw8b(False)
 def VV5NgR(self)  : self.close(True)
 def VVC54u(self) : self.close(False)
 def VVt27O(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVsuOx(self):
  self.VVXfKD()
  self.VVKDUZ()
  self.VVbbSn()
  self.VVo0Wi()
 def VVCPGr(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVt27O()
   self.VVsuOx()
   FF4knh(self.refresh)
 def VVZRLr(self):
  if len(self["keyGreen"].getText()) > 0:
   FFsJwx(self, self.VV9kBc, "Synchronize with Internet Date/Time ?")
 def VV9kBc(self):
  self.VVsuOx()
  FF4knh(boundFunction(self.VVGw8b, True))
 def VVXfKD(self)  : self["keyRed"].show()
 def VVoCoA(self)  : self["keyGreen"].show()
 def VVfna9(self) : self["keyYellow"].show()
 def VVnxZR(self)  : self["keyBlue"].show()
 def VVKDUZ(self)  : self["keyGreen"].hide()
 def VVbbSn(self) : self["keyYellow"].hide()
 def VVo0Wi(self)  : self["keyBlue"].hide()
 def VVGw8b(self, sync):
  localTime = FFVTa3()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVGlRb(server)
   if epoch_time is not None:
    ntpTime = FFNSik(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCJC8z()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVyHcD, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVfna9()
  self.VVnxZR()
  if ok:
   self.VVoCoA()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVyHcD(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVGw8b(False)
  except:
   pass
 def VVGlRb(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFDqwf():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CC7eRu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF65g3(VVWc9r, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFC1qE(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FF4knh(self.VVluuC)
 def VVluuC(self):
  if FFDqwf(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFc3QD(self["myBody"], color)
   FFc3QD(self["myLabel"], color)
  except:
   pass
class CCDFlM(Screen):
 def __init__(self, session, isFromExternal=False):
  size = CFG.signalSize.getValue()
  screenW = FF3btT()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FF65g3(VVmTzD, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self.isFromExternal  = isFromExternal
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CC9r8R(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CC9r8R(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CC9r8R(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CC5Has()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFC1qE(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVfp4a          ,
   "down"  : self.VVwcmZ         ,
   "left"  : self.VVBx2y         ,
   "right"  : self.VVa5Bb         ,
   "info"  : self.VVXwp0        ,
   "epg"  : self.VVXwp0        ,
   "menu"  : self.VVHzkB         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "blue"  : self.VV7d6M       ,
   "last"  : boundFunction(self.VVTEO7, -1)  ,
   "next"  : boundFunction(self.VVTEO7, 1)  ,
   "pageUp" : boundFunction(self.VV9ZK6, True) ,
   "chanUp" : boundFunction(self.VV9ZK6, True) ,
   "pageDown" : boundFunction(self.VV9ZK6, False) ,
   "chanDown" : boundFunction(self.VV9ZK6, False) ,
   "0"   : boundFunction(self.VVTEO7, 0)  ,
   "1"   : boundFunction(self.VV7Tcu, pos=1) ,
   "2"   : boundFunction(self.VV7Tcu, pos=2) ,
   "3"   : boundFunction(self.VV7Tcu, pos=3) ,
   "4"   : boundFunction(self.VV7Tcu, pos=4) ,
   "5"   : boundFunction(self.VV7Tcu, pos=5) ,
   "6"   : boundFunction(self.VV7Tcu, pos=6) ,
   "7"   : boundFunction(self.VV7Tcu, pos=7) ,
   "8"   : boundFunction(self.VV7Tcu, pos=8) ,
   "9"   : boundFunction(self.VV7Tcu, pos=9) ,
  }, -1)
  self.onShown.append(self.VV2xXB)
  self.onClose.append(self.onExit)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  self.sliderSNR.VVA043()
  self.sliderAGC.VVA043()
  self.sliderBER.VVA043(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VV7Tcu()
  self.VVdmODInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVdmOD)
  except:
   self.timer.callback.append(self.VVdmOD)
  self.timer.start(500, False)
 def VVdmODInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVRvmD(service)
  serviceName = self.tunerInfo.VVO503()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
  tp = CCs7Me()
  txt = tp.VV6cX7(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVdmOD(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVRvmD(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVVxOz())
   self["mySNR"].setText(self.tunerInfo.VV3KGq())
   self["myAGC"].setText(self.tunerInfo.VVHG4A())
   self["myBER"].setText(self.tunerInfo.VVbaY8())
   self.sliderSNR.VVwriT(self.tunerInfo.VVzzVE())
   self.sliderAGC.VVwriT(self.tunerInfo.VVWfRn())
   self.sliderBER.VVwriT(self.tunerInfo.VV194y())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVwriT(0)
   self.sliderAGC.VVwriT(0)
   self.sliderBER.VVwriT(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
    if state and not state == "Tuned":
     FFuCKD(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVXwp0(self):
  FFgCFv(self, fncMode=CClBuf.VVk2Nt)
 def VVHzkB(self):
  FFKyDS(self, VVII1V + "_help_signal", "Signal Monitor (Keys)")
 def VV7d6M(self):
  self.session.open(CCnyHZ, isFromExternal=self.isFromExternal)
  self.close()
 def VVfp4a(self)  : self.VV7Tcu(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVwcmZ(self) : self.VV7Tcu(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVBx2y(self) : self.VV7Tcu(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVa5Bb(self) : self.VV7Tcu(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VV7Tcu(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVTEO7(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFTftb(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VV9ZK6(self, isUp):
  FFuCKD(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVdmODInfo()
  except:
   pass
class CC9r8R(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVA043(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFc3QD(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVII1V +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFc3QD(self.covObj, self.covColor)
   else:
    FFc3QD(self.covObj, "#00006688")
    self.isColormode = True
  self.VVwriT(0)
 def VVwriT(self, val):
  val  = FFTftb(val, self.minN, self.maxN)
  width = int(FF6Fzh(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFTftb(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CC1Mzj(Screen):
 VVEZCt    = 0
 VVIi6X = 1
 VVGGku = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVnyfB=None, barTheme=VVEZCt):
  ratio = self.VVbsyj(barTheme)
  self.skin, self.skinParam = FF65g3(VVHtD3, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVnyfB = VVnyfB
  self.isCancelled = False
  self.isError  = False
  self.curValue  = 0
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVCGmK = None
  self.timer   = eTimer()
  self.myThread  = None
  FFC1qE(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VV2xXB)
  self.onClose.append(self.onExit)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  self.VVPAAJ()
  self["myProgBarVal"].setText("0%")
  FFc3QD(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVAzPb()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVAzPb)
  except:
   self.timer.callback.append(self.VVAzPb)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def VVR6pW(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VV4hTf_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVCGmK), self.counter, self.maxValue, catName)
 def VV4hTf_fromImportEPG(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VV4hTf_forcedUpdate(self, title):
  self.newTitle = title
  try:
   self.VVAzPb()
  except:
   pass
 def VVZ46l(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VVCGmK), self.counter, self.maxValue)
  except:
   pass
 def VVnoqp(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVKEHa(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVWXKc(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFuCKD(self, "Cancelling ...")
  self.isCancelled = True
  self.VVCCj0(False)
 def VVCCj0(self, isDone):
  if self.VVnyfB:
   self.VVnyfB(isDone, self.VVCGmK, self.counter, self.maxValue, self.isError)
  self.close()
 def VVAzPb(self):
  val = FFTftb(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FF6Fzh(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VVCCj0(True)
 def VVPAAJ(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVIi6X, self.VVGGku):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVbsyj(self, barTheme):
  if   barTheme == self.VVIi6X : return 0.7
  if   barTheme == self.VVGGku : return 0.5
  else             : return 1
class CCJC8z(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVnyfB = {}
  self.commandRunning = False
  self.VVgVej  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVnyfB, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVnyfB[name] = VVnyfB
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVgVej:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVWBAO, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVRBbh , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVWBAO, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVRBbh , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVRBbh(name, retval)
  return True
 def VVWBAO(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVRBbh(self, name, retval):
  if not self.VVgVej:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVnyfB[name]:
   self.VVnyfB[name](self.appResults[name], retval)
  del self.VVnyfB[name]
 def VVrerc(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCMzbw(Screen):
 def __init__(self, session, title="", VVC2Uz=None, VVy6mg=False, VVtwuY=False, VV5pky=False, VVtOh4=False, VV9bDV=False, VVwdV9=False, VV66pN=VVGsh0, VVm8DP=None, VV3mn8=False, VVHZm7=None, VVn21l="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FF65g3(VVq7g2, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFC1qE(self, addScrollLabel=True)
  if not VVn21l:
   VVn21l = "Processing ..."
  self["myLabel"].setText("   %s" % VVn21l)
  self.VVy6mg   = VVy6mg
  self.VVtwuY   = VVtwuY
  self.VV5pky   = VV5pky
  self.VVtOh4  = VVtOh4
  self.VV9bDV = VV9bDV
  self.VVwdV9 = VVwdV9
  self.VV66pN   = VV66pN
  self.VVm8DP = VVm8DP
  self.VV3mn8  = VV3mn8
  self.VVHZm7  = VVHZm7
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCJC8z()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFevP0()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVC2Uz, str):
   self.VVC2Uz = [VVC2Uz]
  else:
   self.VVC2Uz = VVC2Uz
  if self.VV5pky or self.VVtOh4:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVyYSf, VVyYSf)
   self.VVC2Uz.append("echo -e '\n%s\n' %s" % (restartNote, FF8EkF(restartNote, VVyveI)))
   if self.VV5pky:
    self.VVC2Uz.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVC2Uz.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VV9bDV:
   FFuCKD(self, "Processing ...")
  self.onLayoutFinish.append(self.VViysH)
  self.onClose.append(self.VVdBVs)
 def VViysH(self):
  self["myLabel"].VVWjn0(textOutFile="console" if self.enableSaveRes else "")
  if self.VVy6mg:
   self["myLabel"].VVtJrC()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VV1Txb()
  else:
   self.VV1KcU()
 def VV1Txb(self):
  if FFDqwf():
   self["myLabel"].setText("Processing ...")
   self.VV1KcU()
  else:
   self["myLabel"].setText(FFu1AK("\n   No connection to internet!", VVGMgi))
 def VV1KcU(self):
  allOK = self.container.ePopen(self.VVC2Uz[0], self.VV52en, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VV52en("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVwdV9 or self.VV5pky or self.VVtOh4:
    self["myLabel"].setText(FFWpRC("STARTED", VVyveI) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVHZm7:
   colorWhite = CC0o49.VVRteb(VVO6Kg)
   color  = CC0o49.VVRteb(self.VVHZm7[0])
   words  = self.VVHZm7[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VV66pN=self.VV66pN)
 def VV52en(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVC2Uz):
   allOK = self.container.ePopen(self.VVC2Uz[self.cmdNum], self.VV52en, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VV52en("Cannot connect to Console!", -1)
  else:
   if self.VV9bDV and FFcn9Z(self):
    FFuCKD(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVwdV9:
    self["myLabel"].appendText("\n" + FFWpRC("FINISHED", VVyveI), self.VV66pN)
   if self.VVy6mg or self.VVtwuY:
    self["myLabel"].VVtJrC()
   if self.VVm8DP is not None:
    self.VVm8DP()
   if not retval and self.VV3mn8:
    self.VVdBVs()
 def VVdBVs(self):
  if self.container.VVrerc():
   self.container.killAll()
class CC1svu(Screen):
 def __init__(self, session, VVC2Uz=None, VV9bDV=False):
  self.skin, self.skinParam = FF65g3(VVq7g2, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVA6fc + "ajpanel_terminal.history"
  self.customCommandsFile = VVA6fc + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFoABH("pwd") or "/home/root"
  self.container   = CCJC8z()
  FFC1qE(self, addScrollLabel=True)
  FF3fcb(self["keyRed"] , "Exit = Stop Command")
  FF3fcb(self["keyGreen"] , "OK = History")
  FF3fcb(self["keyYellow"], "Menu = Custom Cmds")
  FF3fcb(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VV0UXa ,
   "cancel" : self.VV6r0g  ,
   "menu"  : self.VV0kMy ,
   "last"  : self.VVH7JK  ,
   "next"  : self.VVH7JK  ,
   "1"   : self.VVH7JK  ,
   "2"   : self.VVH7JK  ,
   "3"   : self.VVH7JK  ,
   "4"   : self.VVH7JK  ,
   "5"   : self.VVH7JK  ,
   "6"   : self.VVH7JK  ,
   "7"   : self.VVH7JK  ,
   "8"   : self.VVH7JK  ,
   "9"   : self.VVH7JK  ,
   "0"   : self.VVH7JK
  })
  self.onLayoutFinish.append(self.VV2xXB)
  self.onClose.append(self.VVdx1L)
 def VV2xXB(self):
  self["myLabel"].VVWjn0(isResizable=False, textOutFile="terminal")
  FFXws7(self["keyRed"]  , "#00ff8000")
  FFc3QD(self["keyRed"]  , self.skinParam["titleColor"])
  FFc3QD(self["keyGreen"]  , self.skinParam["titleColor"])
  FFc3QD(self["keyYellow"] , self.skinParam["titleColor"])
  FFc3QD(self["keyBlue"] , self.skinParam["titleColor"])
  self.VV7qRW(FFoABH("date"), 5)
  result = FFoABH("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVRAnp()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVII1V + "LinuxCommands.lst"
   newTemplate = VVII1V + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFxZhj("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFxZhj("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVdx1L(self):
  if self.container.VVrerc():
   self.container.killAll()
   self.VV7qRW("Process killed\n", 4)
   self.VVRAnp()
 def VV6r0g(self):
  if self.container.VVrerc():
   self.VVdx1L()
  else:
   FFsJwx(self, self.close, "Exit ?", VVYmNt=False)
 def VVRAnp(self):
  self.VV7qRW(self.prompt, 1)
  self["keyRed"].hide()
 def VV7qRW(self, txt, mode):
  if   mode == 1 : color = VVyveI
  elif mode == 2 : color = VVNRRl
  elif mode == 3 : color = VVO6Kg
  elif mode == 4 : color = VVGMgi
  elif mode == 5 : color = VVKXn9
  elif mode == 6 : color = VVLXD9
  else   : color = VVO6Kg
  try:
   self["myLabel"].appendText(FFu1AK(txt, color))
  except:
   pass
 def VVEyPJ(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VV7qRW(cmd, 2)
   self.VV7qRW("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VV7qRW(ch, 0)
   self.VV7qRW("\nor\n", 4)
   self.VV7qRW("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVRAnp()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFu1AK(parts[0].strip(), VVNRRl)
    right = FFu1AK("#" + parts[1].strip(), VVLXD9)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VV7qRW(txt, 2)
   lastLine = self.VVkIJM()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVuq92(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VV52en, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFkZTy(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VV7qRW(data, 3)
 def VV52en(self, data, retval):
  if not retval == 0:
   self.VV7qRW("Exit Code : %d\n" % retval, 4)
  self.VVRAnp()
 def VV0UXa(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVkIJM() == "":
   self.VVuq92("cd /tmp")
   self.VVuq92("ls")
  VVaXgj = []
  if fileExists(self.commandHistoryFile):
   lines  = FFghv7(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVaXgj.append((str(c), line, str(lNum)))
   self.VVGoZ7(VVaXgj, title, self.commandHistoryFile, isHistory=True)
  else:
   FFLxgb(self, self.commandHistoryFile, title=title)
 def VVkIJM(self):
  lastLine = FFoABH("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVuq92(self, cmd):
  os.system("echo '%s' >> %s" % (cmd, self.commandHistoryFile))
 def VV0kMy(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFghv7(self.customCommandsFile)
   lastLineIsSep = False
   VVaXgj = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVaXgj.append((str(c), line, str(lNum)))
   self.VVGoZ7(VVaXgj, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFLxgb(self, self.customCommandsFile, title=title)
 def VVGoZ7(self, VVaXgj, title, filePath=None, isHistory=False):
  if VVaXgj:
   VVJk0D = "#05333333"
   if isHistory: VVZidB = VVCOuJ = VVQfS4 = "#11000020"
   else  : VVZidB = VVCOuJ = VVQfS4 = "#06002020"
   VVxHB1 = VV487W = None
   VVnutX   = ("Send"   , self.VVTfDf        , [])
   VV5ydd  = ("Modify & Send" , self.VVEyvr        , [])
   if isHistory:
    VVxHB1 = ("Clear History" , self.VVghhG        , [])
   elif filePath:
    VV487W = ("Edit File"  , boundFunction(self.VVdsWz, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVdQl9     = (CENTER  , LEFT   , CENTER )
   FFlZ9Z(self, None, title=title, header=header, VVplFV=VVaXgj, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=26, VVnutX=VVnutX, VV5ydd=VV5ydd, VVxHB1=VVxHB1, VV487W=VV487W, VVwbEy=True
     , VVZidB   = VVZidB
     , VVCOuJ   = VVCOuJ
     , VVQfS4   = VVQfS4
     , VVl3OT  = "#05ffff00"
     , VVJk0D  = VVJk0D
    )
  else:
   FF4o1U(self, filePath, title=title)
 def VVTfDf(self, VVv5LU, title, txt, colList):
  cmd = colList[1].strip()
  VVv5LU.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VV7qRW("\n%s\n" % cmd, 6)
   self.VV7qRW(self.prompt, 1)
  else:
   self.VVEyPJ(cmd)
 def VVEyvr(self, VVv5LU, title, txt, colList):
  cmd = colList[1]
  self.VVJAuB(VVv5LU, cmd)
 def VVghhG(self, VVv5LU, title, txt, colList):
  FFsJwx(self, boundFunction(self.VVIjev, VVv5LU), "Reset History File ?", title="Command History")
 def VVIjev(self, VVv5LU):
  os.system(FFxZhj("echo '' > %s" % self.commandHistoryFile))
  VVv5LU.cancel()
 def VVdsWz(self, filePath, VVv5LU, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCU5Qm(self, filePath, VVnyfB=boundFunction(self.VVTCvT, VVv5LU), curRowNum=rowNum)
  else     : FFLxgb(self, filePath)
 def VVTCvT(self, VVv5LU, fileChanged):
  if fileChanged:
   VVv5LU.cancel()
   FF4knh(self.VV0kMy)
 def VVH7JK(self):
  self.VVJAuB(None, self.lastCommand)
 def VVJAuB(self, VVv5LU, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFmIMB(self, boundFunction(self.VVBVSq, VVv5LU), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVBVSq(self, VVv5LU, cmd):
  if cmd and len(cmd) > 0:
   self.VVEyPJ(cmd)
   if VVv5LU:
    VVv5LU.cancel()
class CCF7U0(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VV1tLf="", VVATyh=False, VVAJY2=False, isTrimEnds=True):
  self.skin, self.skinParam = FF65g3(VVrFIk, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFC1qE(self, title, addLabel=True)
  FF3fcb(self["keyRed"] , "Up/Down = Change")
  FF3fcb(self["keyGreen"] , "Overwrite")
  FF3fcb(self["keyYellow"], "Pick Key Map")
  FF3fcb(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVAJY2   = VVAJY2
  self.VVATyh  = VVATyh
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VV1tLf, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVpY7Q      ,
   "green"    : self.VVdTW9    ,
   "yellow"   : self.VVTyN3      ,
   "blue"    : self.VV2N7L     ,
   "menu"    : self.VVQBz5     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VV9iMn, True) ,
   "down"    : boundFunction(self.VV9iMn, False) ,
   "left"    : self.VVPbs3       ,
   "right"    : self.VVPzT6       ,
   "home"    : self.VVXL9d       ,
   "end"    : self.VVH0hW       ,
   "next"    : self.VVsyq3      ,
   "last"    : self.VVizNL      ,
   "deleteForward"  : self.VVsyq3      ,
   "deleteBackward" : self.VVizNL      ,
   "tab"    : self.VVAqaq       ,
   "toggleOverwrite" : self.VVdTW9    ,
   "0"     : self.VVi4vy     ,
   "1"     : self.VVi4vy     ,
   "2"     : self.VVi4vy     ,
   "3"     : self.VVi4vy     ,
   "4"     : self.VVi4vy     ,
   "5"     : self.VVi4vy     ,
   "6"     : self.VVi4vy     ,
   "7"     : self.VVi4vy     ,
   "8"     : self.VVi4vy     ,
   "9"     : self.VVi4vy
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVHWQ9()
  self.onShown.append(self.VV2xXB)
  self.onClose.append(self.onExit)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FFhBiL(self)
  self["myLabel"].setText(self.message)
  self.VVufdv()
  if self.VVATyh : self.VVdTW9()
  else    : self.VVU7Yc()
  FF7qhl(self)
  FFc3QD(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVZxxl)
  except:
   self.timer.callback.append(self.VVZxxl)
 def onExit(self):
  self.timer.stop()
 def VVpY7Q(self):
  self.VVSWlq()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVSWlq()
  self.close(None)
 def VVQBz5(self):
  VV4YjP = []
  VV4YjP.append(("Home"         , "home"    ))
  VV4YjP.append(("End"         , "end"     ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Clear All"       , "clearAll"   ))
  VV4YjP.append(("Clear To Home"      , "clearToHome"   ))
  VV4YjP.append(("Clear To End"       , "clearToEnd"   ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVakf1:
   VV4YjP.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("To Capital Letters"     , "toCapital"   ))
  VV4YjP.append(("To Small Letters"      , "toSmall"    ))
  FF2oO5(self, self.VVjm6W, title="Edit Options", VV4YjP=VV4YjP)
 def VVjm6W(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVXL9d()
   elif item == "end"     : self.VVH0hW()
   elif item == "clearAll"    : self.VVND0C()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVXL9d()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVakf1
    VVakf1 = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVakf1)
    self.VVXL9d()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVZxxl(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVdTW9(self):
  self["myInput"].toggleOverwrite()
  self.VVU7Yc()
 def VVTyN3(self):
  self.session.openWithCallback(self.VVoBGO, boundFunction(CCQylD, mode=self.charMode, VVAJY2=self.VVAJY2))
 def VVoBGO(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVufdv()
 def VVU7Yc(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVHWQ9(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVSWlq(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVcYRU(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVPbs3(self)     : self.VVrQH4(self["myInput"].left)
 def VVPzT6(self)     : self.VVrQH4(self["myInput"].right)
 def VVsyq3(self)     : self.VVrQH4(self["myInput"].delete)
 def VVXL9d(self)     : self.VVrQH4(self["myInput"].home)
 def VVH0hW(self)     : self.VVrQH4(self["myInput"].end)
 def VVizNL(self)    : self.VVrQH4(self["myInput"].deleteBackward)
 def VVAqaq(self)     : self.VVrQH4(self["myInput"].tab)
 def VVND0C(self)     : self["myInput"].setText("")
 def VVrQH4(self, fnc):
  fnc()
  self.VVZxxl()
 def VVi4vy(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVcYRU(newChar, overwrite)
   self.VV2xYd(newChar, self["myInput"].mapping[number])
 def VV9iMn(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCQylD.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCQylD.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVcYRU(newChar, True)
   for group in groups:
    if newChar in group:
     self.VV2xYd(newChar, group)
     break
 def VV2xYd(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVO6Kg:
    group = VVKXn9 + group.replace(newChar, FFu1AK(newChar, VVO6Kg, VVKXn9))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VV2N7L(self):
  if self.VVAJY2 : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVufdv()
 def VVufdv(self):
  self["myInput"].mapping = CCQylD.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCQylD.RCU_MAP_TITLES[self.charMode])
class CCQylD(Screen):
 VVlgIF  = 0
 VVEg0f  = 1
 VVS4Us  = 2
 VVRyk6  = 3
 VVExMU = 4
 VVWQmn = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols, arabic_nums1, arabic1)
       , ( symbols, arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A" , u"\u0628")
       , (u"\u0647" , u"\u062A")
       )
 def __init__(self, session, mode=VVlgIF, VVAJY2=False):
  self.skin, self.skinParam = FF65g3(VViV0B, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVAJY2  = VVAJY2
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFC1qE(self, title=self.Title)
  FF3fcb(self["keyRed"] ,"OK = Select")
  FF3fcb(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV2bRb     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVngNc, -1) ,
   "next"  : boundFunction(self.VVngNc, +1) ,
   "left"  : boundFunction(self.VVngNc, -1) ,
   "right"  : boundFunction(self.VVngNc, +1) ,
  }, -1)
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FFc3QD(self["keyRed"], "#11222222")
  FFc3QD(self["keyGreen"], "#11222222")
  self.VVSsSY()
 def VVSsSY(self):
  self.VVvHUY()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVvHUY(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVngNc(self, direction):
  if self.VVAJY2 : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVSsSY()
 def VV2bRb(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCrCIF(Screen):
 def __init__(self, session, title="", message="", VV66pN=VVGsh0, VV2L7a=False, VVQfS4=None, VVIUEO=30, canSaveToFile=""):
  self.skin, self.skinParam = FF65g3(VVq7g2, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVIUEO)
  self.session   = session
  FFC1qE(self, title, addScrollLabel=True)
  self.VV66pN   = VV66pN
  self.VV2L7a   = VV2L7a
  self.VVQfS4   = VVQfS4
  self.canSaveToFile  = canSaveToFile
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  self["myLabel"].VVWjn0(VV2L7a=self.VV2L7a, textOutFile=self.canSaveToFile)
  self["myLabel"].setText(self.message, self.VV66pN)
  if self.VVQfS4:
   FFc3QD(self["myBody"], self.VVQfS4)
   FFc3QD(self["myLabel"], self.VVQfS4)
   FFrMe3(self["myLabel"], self.VVQfS4)
  self["myLabel"].VVtJrC()
class CCFxYV(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FF65g3(VVv9qr, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFC1qE(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FFh916(self["errPic"], "err")
class CC45PX(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FF65g3(VVMzZT, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", 20)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFC1qE(self, " ", addCloser=True)
class CCLFbh():
 def __init__(self, tSession, txt):
  self.win = tSession.instantiateDialog(CC45PX, txt)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  self.timer   = eTimer()
  self.timerCounter = 0
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVapPr)
  except:
   self.timer.callback.append(self.VVapPr)
  self.timer.start(100, False)
 def VVapPr(self):
  self.timerCounter += 1
  if self.timerCounter > 15:
   self.timer.stop()
   self.win.hide()
class CCL88j():
 VVyVTl    = 0
 VVpC39  = 1
 VV6CY8   = ""
 VVVFXT    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVv5LU   = None
  self.timer     = eTimer()
  self.VV9fpK   = 0
  self.VVf1S4  = 1
  self.VVtV0k  = 2
  self.VVXK2u   = 3
  self.VVtN3Z   = 4
  VVaXgj = self.VVb5Jw()
  if VVaXgj:
   self.VVv5LU = self.VVojjG(VVaXgj)
  if not VVaXgj and mode == self.VVyVTl:
   self.VVKlD3or("Download list is empty !")
   self.cancel()
  if mode == self.VVpC39:
   FFxBTP(self.VVv5LU or self.SELF, boundFunction(self.VVvDvR, startDnld, decodedUrl), title="Checking Server ...")
  self.VVB4fF(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVB4fF)
  except:
   self.timer.callback.append(self.VVB4fF)
  self.timer.start(1000, False)
 def VVojjG(self, VVaXgj):
  VVaXgj.sort(key=lambda x: int(x[0]))
  VVDYxQ = self.VVvVKv
  VVnutX  = ("Play"  , self.VVSIIA , [])
  VVmtel = (""   , self.VVud1H  , [])
  VVyT4T = ("Stop"  , self.VV6Ag4  , [])
  VV5ydd = ("Resume"  , self.VVtLS4 , [])
  VVxHB1 = ("Options" , self.VVOCkt  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVdQl9  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFlZ9Z(self.SELF, None, title=self.Title, header=header, VVplFV=VVaXgj, VVdQl9=VVdQl9, VVbohG=widths, VVIUEO=26, VVnutX=VVnutX, VVmtel=VVmtel, VVDYxQ=VVDYxQ, VVyT4T=VVyT4T, VV5ydd=VV5ydd, VVxHB1=VVxHB1, VVCOuJ="#11110011", VVZidB="#11220022", VVQfS4="#11110011", VVl3OT="#00ffff00", VVJk0D="#00223025", VVJSW4="#0a333333", VVpNa2="#0a400040", VVwbEy=True, searchCol=1)
 def VVb5Jw(self):
  lines = CCL88j.VVmCWm()
  VVaXgj = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",")
     left  = parts[0].strip()
     decodedUrl = ",".join(parts[1:]).strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVQjrF(decodedUrl)
      if fName:
       if   FFrEnh(decodedUrl) : sType = "Movie"
       elif FFkweZ(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VV8VXo(decodedUrl, fName)
       if size > -1: sizeTxt = CC5T3l.VVfT2w(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVaXgj.append((str(len(VVaXgj) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVaXgj
 def VVCjNn(self):
  VVaXgj = self.VVb5Jw()
  if VVaXgj:
   if self.VVv5LU : self.VVv5LU.VVFYEc(VVaXgj, VVt27OMsg=False)
   else     : self.VVv5LU = self.VVojjG(VVaXgj)
  else:
   self.cancel()
 def VVB4fF(self, force=False):
  if self.VVv5LU:
   thrList = self.VVOScI()
   VVaXgj = []
   changed = False
   for ndx, row in enumerate(self.VVv5LU.VVAVTk()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VV9fpK
    if m3u8Log:
     percent = self.VVaSHK(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVXK2u , "%.2f %%" % percent
      else   : flag, progr = self.VVtN3Z , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFkJoP(mPath)
     if curSize > -1:
      fSize = CC5T3l.VVfT2w(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CC5T3l.VVfT2w(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFkJoP(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVXK2u , "%.2f %%" % percent
       else   : flag, progr = self.VVtN3Z , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CC5T3l.VVfT2w(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrList:
     flag = self.VVtV0k
     if m3u8Log :
      if not speed and not force : flag = self.VVf1S4
      elif curSize == -1   : self.VVwlor(False)
    elif flag == self.VV9fpK  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VV9fpK  : color2 = "#f#00555555#"
    elif flag == self.VVf1S4 : color2 = "#f#0000FFFF#"
    elif flag == self.VVtV0k : color2 = "#f#0000FFFF#"
    elif flag == self.VVXK2u  : color2 = "#f#00FF8000#"
    elif flag == self.VVtN3Z  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VV5QFT(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVaXgj.append(row)
   if changed or force:
    self.VVv5LU.VVFYEc(VVaXgj, VVt27OMsg=False)
 def VV5QFT(self, flag):
  tDict = self.VVSnUM()
  return tDict.get(flag, "?")
 def VVzyDk(self, state):
  for flag, txt in self.VVSnUM().items():
   if txt == state:
    return flag
  return -1
 def VVSnUM(self):
  return { self.VV9fpK: "Not started", self.VVf1S4: "Connecting", self.VVtV0k: "Downloading", self.VVXK2u: "Stopped", self.VVtN3Z: "Completed" }
 def VVxQUs(self, title):
  colList = self.VVv5LU.VVcFi1()
  path = colList[6]
  url  = colList[8]
  if self.VVKOpU() : self.VVKlD3or("Cannot delete !\n\nFile is downloading.")
  else      : FFsJwx(self.SELF, boundFunction(self.VVD7BU, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVD7BU(self, path, url):
  m3u8Log = self.VVv5LU.VVcFi1()[12].strip()
  if m3u8Log : os.system(FFxZhj("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFxZhj("rm -r '%s'" % path))
  self.VVAYtw()
  self.VVCjNn()
 def VVAYtw(self):
  if self.VVKOpU():
   FFuCKD(self.VVv5LU, self.VV5QFT(self.VVtV0k), 500)
  else:
   colList  = self.VVv5LU.VVcFi1()
   state  = colList[4].strip()
   decodedUrl = colList[9].strip()
   if self.VVzyDk(state) in (self.VV9fpK, self.VVtN3Z):
    lines = CCL88j.VVmCWm()
    newLines = []
    found = False
    for line in lines:
     if CCL88j.VVtk7h(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVUHX7(newLines)
     self.VVCjNn()
     FFuCKD(self.VVv5LU, "Removed.", 1000)
    else:
     FFuCKD(self.VVv5LU, "Not found.", 1000)
   else:
    self.VVKlD3or("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVVmIN(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFsJwx(self.SELF, boundFunction(self.VVuL9S, flag), ques, title=title)
 def VVuL9S(self, flag):
  list = []
  for ndx, row in enumerate(self.VVv5LU.VVAVTk()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVzyDk(state)
   if   flag == flagVal == self.VVtN3Z: list.append(decodedUrl)
   elif flag == flagVal == self.VV9fpK : list.append(decodedUrl)
  lines = CCL88j.VVmCWm()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVUHX7(newLines)
   self.VVCjNn()
   FFuCKD(self.VVv5LU, "%d removed." % totRem, 1000)
  else:
   FFuCKD(self.VVv5LU, "Not found.", 1000)
 def VVAaki(self):
  colList  = self.VVv5LU.VVcFi1()
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFuCKD(self.VVv5LU, "Poster exists", 1500)
  else    : FFxBTP(self.VVv5LU, boundFunction(self.VVfTEg, decodedUrl, path, png), title="Checking Server ...")
 def VVfTEg(self, decodedUrl, path, png):
  err = self.VVnakW(decodedUrl, path, png)
  if err:
   FFkZTy(self.SELF, err, title="Poster Download")
 def VVnakW(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCOmmp.VVy51Q(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCdgmH.VVinaS(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCdgmH.VVkFgl(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCdgmH.VVq4cU(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if pUrl:
   ext = os.path.splitext(pUrl)[1] or ".png"
   tPath, err = FFPMCM(pUrl, "ajpanel_tmp%s", timeout=2, mustBeImage=True)
   if err:
    return "Cannot download poster !\n\n%s" % err
   else:
    png = "%s%s" % (os.path.splitext(path)[0], ext)
    os.system(FFxZhj("mv -f '%s' '%s'" % (tPath, png)))
    FFoFhU(self.SELF, title=os.path.basename(png), VV8s1L=png, showGrnMsg="Downloaded")
  else:
   return "Cannot get Poster URL !\n\n%s" % err
  return ""
 def VVud1H(self, VVv5LU, title, txt, colList):
  def VVjO6x(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VV4FHA(key, val) : return "\n%s:\n%s\n" % (FFu1AK(key, COLOR_CONS_BRIGHT_YELLOW), val.strip())
  heads  = self.VVv5LU.VVpoQH()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVjO6x(heads[i]  , CC5T3l.VVfT2w(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVjO6x("Downloaded" , CC5T3l.VVfT2w(int(curSize), mode=0))
   else:
    txt += VVjO6x(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VV4FHA(heads[i], colList[i])
  FFXXd4(self.SELF, txt, title=title)
 def VVSIIA(self, VVv5LU, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CC5T3l.VVhoPs(self.SELF, path)
  else    : FFuCKD(self.VVv5LU, "File not found", 1000)
 def VVvVKv(self, VVv5LU):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVv5LU:
   self.VVv5LU.cancel()
  del self
 def VVOCkt(self, VVv5LU, title, txt, colList):
  decodedUrl = colList[9].strip()
  if CFG.downloadAutoResume.getValue(): resumeTxt = "Disable"
  else        : resumeTxt = "Enable"
  VV4YjP = []
  VV4YjP.append(("Remove current row"      , "VVAYtw"  ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(('Remove all "Completed"'     , "remFinished"    ))
  VV4YjP.append(('Remove all "Not started"'     , "remPending"    ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Delete the file (and remove from list)" , "VVxQUs" ))
  if FFrEnh(decodedUrl):
   VV4YjP.append(VV32Zp)
   VV4YjP.append(("Download Movie Poster (from server)" , "VVAaki"   ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append((resumeTxt + " Auto Resume"     , "VVnvIR"  ))
  FF2oO5(self.SELF, self.VVuqRq, VV4YjP=VV4YjP, title=self.Title, VVmPdS=True, VVydPQ=True)
 def VVuqRq(self, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVAYtw"  : self.VVAYtw()
   elif ref == "remFinished"   : self.VVVmIN(self.VVtN3Z, txt)
   elif ref == "remPending"   : self.VVVmIN(self.VV9fpK, txt)
   elif ref == "VVxQUs" : self.VVxQUs(txt)
   elif ref == "VVAaki"  : self.VVAaki()
   elif ref == "VVnvIR"  : self.VVnvIR()
 def VVvDvR(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCOmmp.VVy51Q(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVKlD3or("Could not get download link !\n\nTry again later.")
     return
  for line in CCL88j.VVmCWm():
   if CCL88j.VVtk7h(decodedUrl, line):
    self.VVfQFa(decodedUrl)
    FF4knh(boundFunction(FFuCKD, self.VVv5LU, "Already listed !", 2000))
    break
  else:
   params = self.VVqDeH(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVKlD3or(params[0])
   elif len(params) == 2:
    self.VVQjxj(params[0], decodedUrl)
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CC5T3l.VVfT2w(fSize)
    FFsJwx(self.SELF, boundFunction(self.VV210f, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VV210f(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCL88j.VV9ZoQ(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVCjNn()
  if self.VVv5LU:
   self.VVv5LU.VVCeyG()
  if startDnld:
   threadName = self.VVVFXT + decodedUrl
   self.VVqqct(threadName, url, decodedUrl, path, resp)
 def VVfQFa(self, decodedUrl):
  for ndx, row in enumerate(self.VVv5LU.VVAVTk()):
   decodedUrl2 = row[9].strip()
   if decodedUrl == decodedUrl2 and self.VVv5LU:
    self.VVv5LU.VVNAqK(ndx)
    break
 def VVqDeH(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVQjrF(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VV8VXo(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCOmmp.VVy51Q(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCOmmp.VVMHUJHeader()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head["Content-Length"]
   cType = head["Content-Type"]
   if not "video" in cType:
    if resp.url.endswith(".m3u8"):
     return [resp, 1]
    else:
     return ["Cannot download this video !\n\nNot allowed by server."]
   if "Accept-Ranges" in head:
    resume = head["Accept-Ranges"]
    if not resume == "none":
     resumable = True
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  err = CCL88j.VVeCOb(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVQjxj(self, resp, decodedUrl):
  if not os.system(FFxZhj("which ffmpeg")) == 0:
   FFsJwx(self.SELF, boundFunction(CCdgmH.VVDaN8, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVQjrF(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVEkde(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFsJwx(self.SELF, boundFunction(self.VVb0ki, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVb0ki(rTxt, rUrl)
  else:
   self.VVKlD3or("Cannot process m3u8 file !")
 def VVEkde(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VV4YjP = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCdgmH.VVSYRJ(rUrl, fPath)
   VV4YjP.append((resol, fullUrl))
  if VV4YjP:
   FF2oO5(self.SELF, self.VVuHAR, VV4YjP=VV4YjP, title="Resolution", VVmPdS=True, VVydPQ=True)
  else:
   self.VVKlD3or("Cannot get Resolutions list from server !")
 def VVuHAR(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFsJwx(self.SELF, boundFunction(FF4knh, boundFunction(self.VVcXTW, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FF4knh(boundFunction(self.VVcXTW, resolUrl))
 def VVcXTW(self, resolUrl):
  txt, err = CCOmmp.VVEWTz(resolUrl)
  if err : self.VVKlD3or(err)
  else : self.VVb0ki(txt, resolUrl)
 def VVmY7Q(self, logF, decodedUrl):
  found = False
  lines = CCL88j.VVmCWm()
  with open(CCL88j.VV9ZoQ(), "w") as f:
   for line in lines:
    if CCL88j.VVtk7h(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCL88j.VV9ZoQ(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVCjNn()
 def VVb0ki(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCdgmH.VVSYRJ(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVKlD3or("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVmY7Q(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFxZhj("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = self.VVVFXT + decodedUrl
  myThread = iThread(name=threadName, target=boundFunction(os.system, cmd))
  myThread.start()
 def VVaSHK(self, dnldLog):
  if fileExists(dnldLog):
   dur = self.VVsk4n(dnldLog)
   if dur > -1:
    tim = self.VV7jY0(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 def VVsk4n(self, dnldLog):
  lines = FFwhw7("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VV7jY0(self, dnldLog):
  lines = FFwhw7("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VV8VXo(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFkweZ(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFxZhj("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVqqct(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVv5LU.VVcFi1()[7].strip())
  myThread = iThread(name=threadName, target=boundFunction(self.VV8I1O, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VV8I1O(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if CCL88j.VV6CY8 == path:
       break
     else:
      break
  except:
   return
  if CCL88j.VV6CY8:
   CCL88j.VV6CY8 = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFkJoP(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVqDeH(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VV8I1O(url, decodedUrl, path, resp, totFileSize, True)
 def VV6Ag4(self, VVv5LU, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVRtth() : FFuCKD(self.VVv5LU, self.VV5QFT(self.VVtN3Z), 500)
  elif not self.VVKOpU() : FFuCKD(self.VVv5LU, self.VV5QFT(self.VVXK2u), 500)
  elif m3u8Log      : FFsJwx(self.SELF, self.VVwlor, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVOScI():
    CCL88j.VV6CY8 = colList[6]
    FFuCKD(self.VVv5LU, "Stopping ...", 1000)
   else:
    FFuCKD(self.VVv5LU, "Stopped", 500)
 def VVwlor(self, withMsg=True):
  if withMsg:
   FFuCKD(self.VVv5LU, "Stopping ...", 1000)
  os.system(FFxZhj("killall -INT ffmpeg"))
 def VVnvIR(self):
  CFG.downloadAutoResume.setValue(not CFG.downloadAutoResume.getValue())
  CFG.downloadAutoResume.save()
  configfile.save()
 def VVtLS4(self, *args):
  if   self.VVRtth() : FFuCKD(self.VVv5LU, self.VV5QFT(self.VVtN3Z) , 500)
  elif self.VVKOpU() : FFuCKD(self.VVv5LU, self.VV5QFT(self.VVtV0k), 500)
  else:
   resume = False
   m3u8Log = self.VVv5LU.VVcFi1()[12].strip()
   if m3u8Log:
    if fileExists(m3u8Log) : FFsJwx(self.SELF, boundFunction(self.VVq0la, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VV9sWZ():
    resume = True
   if resume: FFxBTP(self.VVv5LU, boundFunction(self.VVjHR9), title="Checking Server ...")
   else  : FFuCKD(self.VVv5LU, "Cannot resume !", 500)
 def VVq0la(self, m3u8Log):
  os.system(FFxZhj("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFxBTP(self.VVv5LU, boundFunction(self.VVjHR9), title="Checking Server ...")
 def VVjHR9(self):
  colList  = self.VVv5LU.VVcFi1()
  path  = colList[6].strip()
  size  = colList[7].strip()
  decodedUrl = colList[9].strip()
  if "j.php" in decodedUrl:
   url = CCOmmp.VVy51Q(decodedUrl)
   if url:
    decodedUrl = self.VVee3f(decodedUrl, url)
   else:
    self.VVKlD3or("Could not get download link !\n\nTry again later.")
    return
  curSize = FFkJoP(path)
  params = self.VVqDeH(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVKlD3or(params[0])
   return
  elif len(params) == 2:
   self.VVQjxj(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVee3f(decodedUrl, url, fSize)
  threadName = self.VVVFXT + decodedUrl
  if resumable: self.VVqqct(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVKlD3or("Cannot resume from server !")
 def VVQjrF(self, decodedUrl):
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(http:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   x = decodedUrl.find("&mode")
   if x > -1: url = decodedUrl[:x]
   fName = ".mp4"
   x = decodedUrl.find("&end=")
   if x > -1: chName = decodedUrl[x+5:]
  if url and fName and chName:
   mix  = fName + chName
   fName =  mix.split(":")[0]
   chName = ":".join(mix.split(":")[1:])
   fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
   url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVKlD3or(self, txt):
  FFkZTy(self.SELF, txt, title=self.Title)
 def VVOScI(self):
  thrList = []
  for thr in iEnumerate():
   if self.VVVFXT in thr.name:
    thrList.append(thr.name.replace(self.VVVFXT, ""))
  return thrList
 def VVKOpU(self):
  decodedUrl = self.VVv5LU.VVcFi1()[9].strip()
  return decodedUrl in self.VVOScI()
 def VVRtth(self):
  colList = self.VVv5LU.VVcFi1()
  path = colList[6].strip()
  size = colList[7].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFkJoP(path)) == size
 def VV9sWZ(self):
  colList = self.VVv5LU.VVcFi1()
  path = colList[6].strip()
  size = int(colList[7].strip())
  curSize = FFkJoP(path)
  if curSize > -1:
   size -= curSize
  err = CCL88j.VVeCOb(size)
  if err:
   FFkZTy(self.SELF, err, title=self.Title)
   return False
  return True
 def VVUHX7(self, list):
  with open(CCL88j.VV9ZoQ(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVee3f(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCL88j.VVmCWm()
  url = decodedUrl
  with open(CCL88j.VV9ZoQ(), "w") as f:
   for line in lines:
    if CCL88j.VVtk7h(decodedUrl, line):
     parts = line.split(",")
     oldUrl = ",".join(parts[1:]).strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVCjNn()
  return url
 @staticmethod
 def VVmCWm():
  list = []
  if fileExists(CCL88j.VV9ZoQ()):
   for line in FFghv7(CCL88j.VV9ZoQ()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVtk7h(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVeCOb(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CC5T3l.VV7D2I(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CC5T3l.VVfT2w(size), CC5T3l.VVfT2w(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVao0k(SELF):
  tot = CCL88j.VVNbt7()
  if tot:
   FFkZTy(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVNbt7():
  c = 0
  for thread in iEnumerate():
   if thread.name.startswith(CCL88j.VVVFXT):
    c += 1
  return c
 @staticmethod
 def VVp10r():
  return len(CCL88j.VVmCWm()) == 0
 @staticmethod
 def VVx7AV():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVNv3p():
  mPoints = CCL88j.VVx7AV()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFxZhj("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VV9ZoQ():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVOiCX(SELF):
  CCL88j.VVhsre(SELF, CCL88j.VVyVTl)
 @staticmethod
 def VVCmai_cur(SELF):
  CCL88j.VVhsre(SELF, CCL88j.VVpC39, startDnld=True)
 @staticmethod
 def VVCmai_url(SELF, url):
  CCL88j.VVhsre(SELF, CCL88j.VVpC39, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVns7xCurrent(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(SELF)
  added, skipped = CCL88j.VVns7xList([decodedUrl])
  FFuCKD(SELF, "Added", 1000)
 @staticmethod
 def VVns7xList(list):
  added = skipped = 0
  for line in CCL88j.VVmCWm():
   for ndx, url in enumerate(list):
    if url and CCL88j.VVtk7h(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCL88j.VV9ZoQ(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVhsre(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCiels.VVqslP(SELF):
   return
  if mode == CCL88j.VVyVTl and CCL88j.VVp10r():
   FFkZTy(SELF, "Download list is empty !", title=title)
  else:
   inst = CCL88j(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
class CCnyHZ(Screen, CC8eJk):
 VV7Kcw = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False, enableDownloadMenu=True):
  self.skin, self.skinParam = FF65g3(VVkGUL, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CC8eJk.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  FFC1qE(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVkUji())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayDnld"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVyEiI         ,
   "info"  : self.VVXwp0        ,
   "epg"  : self.VVXwp0        ,
   "menu"  : self.VVxTBZ       ,
   "cancel" : self.cancel         ,
   "blue"  : self.VV9h0v        ,
   "green"  : self.VVJdi0    ,
   "yellow" : self.VV3Pyz   ,
   "left"  : boundFunction(self.VVGRab, -1)   ,
   "right"  : boundFunction(self.VVGRab,  1)   ,
   "play"  : self.VVCweR        ,
   "pause"  : self.VVCweR        ,
   "playPause" : self.VVCweR        ,
   "stop"  : self.VVCweR        ,
   "rewind" : self.VVjuSN        ,
   "forward" : self.VV2JP9        ,
   "rewindDm" : self.VVjuSN        ,
   "forwardDm" : self.VV2JP9        ,
   "last"  : boundFunction(self.VVhclQ, 0)    ,
   "next"  : self.VVAIrt        ,
   "pageUp" : boundFunction(self.VViPv9, True) ,
   "pageDown" : boundFunction(self.VViPv9, False) ,
   "chanUp" : boundFunction(self.VViPv9, True) ,
   "chanDown" : boundFunction(self.VViPv9, False) ,
   "up"  : boundFunction(self.VViPv9, True) ,
   "down"  : boundFunction(self.VViPv9, False) ,
   "audio"  : boundFunction(self.VVSIkP, True) ,
   "subtitle" : boundFunction(self.VVSIkP, False) ,
   "0"   : boundFunction(self.VVN76N , 10)  ,
   "1"   : boundFunction(self.VVN76N , 1)  ,
   "2"   : boundFunction(self.VVN76N , 2)  ,
   "3"   : boundFunction(self.VVN76N , 3)  ,
   "4"   : boundFunction(self.VVN76N , 4)  ,
   "5"   : boundFunction(self.VVN76N , 5)  ,
   "6"   : boundFunction(self.VVN76N , 6)  ,
   "7"   : boundFunction(self.VVN76N , 7)  ,
   "8"   : boundFunction(self.VVN76N , 8)  ,
   "9"   : boundFunction(self.VVN76N , 9)
  }, -1)
  self.onShown.append(self.VV2xXB)
  self.onClose.append(self.onExit)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FFhBiL(self)
  if not CCnyHZ.VV7Kcw:
   CCnyHZ.VV7Kcw = self
  else:
   self.close()
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  self["myPlayDnld"].instance.move(ePoint(int(left - self.skinParam["titleH"]), int(top)))
  self["myPlayDnld"].hide()
  FFh916(self["myPlayDnld"], "dnld")
  self.VVIV2E()
  self.instance.move(ePoint(40, 40))
  self.VVNIrr(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVlO3U)
  except:
   self.timer.callback.append(self.VVlO3U)
  self.timer.start(250, False)
  self.VVlO3U("Checking ...")
  self.VV78PU()
 def VVJdi0(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
  if "chCode" in iptvRef:
   if CCiels.VVqslP(self):
    self.VV78PU(True)
 def VVIV2E(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FFc3QD(self["myTitle"], color)
 def VVxTBZ(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
  VV4YjP = []
  if self.isFromExternal:
   VV4YjP.append(("IPTV Menu"     , "iptv"  ))
   VV4YjP.append(VV32Zp)
  if FFj0hS(iptvRef) and not "&end=" in decodedUrl and not FFYXBV(decodedUrl):
   uType, uHost, uUser, uPass, uId, uChName = CCdgmH.VVinaS(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VV4YjP.append(("Catchup Programs"   , "catchup"  ))
    VV4YjP.append(VV32Zp)
  VV4YjP.append(("Stop Current Service"    , "stop"  ))
  VV4YjP.append(("Restart Current Service"   , "restart"  ))
  VV4YjP.append(VV32Zp)
  FFrEnhSeries = FFYXBV(decodedUrl)
  if FFrEnhSeries:
   VV4YjP.append(("File Size"     , "fileSize" ))
   VV4YjP.append(VV32Zp)
  if self.enableDownloadMenu:
   addSep = False
   if FFj0hS(iptvRef) and FFrEnhSeries:
    VV4YjP.append(("Start Download"   , "dload_cur" ))
    VV4YjP.append(("Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCL88j.VVp10r():
    VV4YjP.append(("Download Manager"   , "dload_stat" ))
    addSep = True
   if addSep:
    VV4YjP.append(VV32Zp)
  addSep = False
  fPath, fDir, fName = CC5T3l.VV31dK(self)
  if not CC5T3l.VVXqOd and fPath:
   VV4YjP.append((VVyveI + "Open path in File Manager" , "VViiOv"))
   addSep = True
  if fPath:
   VV4YjP.append((VVyveI + "Add to Movies Bouquet"  , "VVSvA7"))
   addSep = True
  if addSep:
   VV4YjP.append(VV32Zp)
  VV4YjP.append(("Move to Top"      , "top"   ))
  VV4YjP.append(("Move to Bottom"     , "botm"  ))
  VV4YjP.append(("Help"        , "help"  ))
  FF2oO5(self, self.VVqDkN, VV4YjP=VV4YjP, width=550, title="Options")
 def VVqDkN(self, item=None):
  if item:
   if item == "iptv"     : self.VVZtVE()
   elif item == "catchup"    : self.VV3Pyz()
   elif item == "stop"     : self.VVj9t1(0)
   elif item == "restart"    : self.VVj9t1(1)
   elif item == "fileSize"    : FFxBTP(self, boundFunction(CClBuf.VVORra, self), title="Checking Server")
   elif item == "dload_cur"   : CCL88j.VVCmai_cur(self)
   elif item == "addToDload"   : CCL88j.VVns7xCurrent(self)
   elif item == "dload_stat"   : CCL88j.VVOiCX(self)
   elif item == "VViiOv" : self.VViiOv()
   elif item == "VVSvA7" : FFxBTP(self, self.VVSvA7)
   elif item == "botm"     : self.VVNIrr(0)
   elif item == "top"     : self.VVNIrr(1)
   elif item == "help"     : FFKyDS(self, VVII1V + "_help_player", "Player Controller (Keys)")
 def onExit(self):
  self.timer.stop()
  CCnyHZ.VV7Kcw = None
 def VV84Sv(self):
  if CCnyHZ.VV7Kcw:
   self.session.open(CCnyHZ, enableZapping= False, enableDownloadMenu=False)
  self.close()
 def VViiOv(self):
  self.session.open(CC5T3l, gotoMovie=True)
  self.VV84Sv()
 def VVZtVE(self):
  self.session.open(CCdgmH)
  self.VV84Sv()
 def VVj9t1(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.close()
   elif typ == 1:
    self.VVlO3U("Restarting Service ...")
    FF4knh(boundFunction(self.VVUyt3, serv))
 def VVUyt3(self, serv):
  self.session.nav.stopService()
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
  if "&end=" in decodedUrl: boundFunction(self.VV78PU, True)
  else     : self.session.nav.playService(serv)
 def VVSvA7(self):
  title = "Add Movie to Bouquet"
  bName = "My Movies"
  path  = VVV3TR + "userbouquet.my_local_movies.tv"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
  fPath, fDir, fName = CC5T3l.VV31dK(self)
  if not fPath or not chName:
   FFkZTy(self, "Cannot read Path or Channel Name", title=title)
   return
  isNew = False
  if not fileExists(path):
   isNew = True
   with open(path, "w") as f:
    f.write("#NAME %s\n" % bName)
  catID, stID, chNum = "1638", "6", "6"
  refCode = CCdgmH.VVgfbn(catID, stID, chNum)
  if not isNew:
   fTxt = FFQiI5(path)
   chUrl_noRef = "%s:%s" % (fPath, chName)
   if chUrl_noRef in fTxt:
    FFkZTy(self, "Already added to bouquet:\n\n%s" % bName, title=title)
    return
   for ns in range(1, 65535 - 1):
    catID, stID, chNum = "1638", str(ns), "6"
    refCode = CCdgmH.VVgfbn(catID, stID, chNum)
    if not refCode in fTxt:
     break
   else:
    FFkZTy(self, "Cannot create a unique Reference Code", title=title)
    return
  if refCode and fPath and chName:
   chUrl = "%s%s:%s" % (refCode, fPath, chName)
   with open(path, "a") as f:
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
   piconOk = self.VVVHcq(refCode)
   FF7fKJ(os.path.basename(path))
   FFXgo1()
   FFUwJf(self, "Added to bouquet:\n\n%s" % bName, title=title + (" (with PIcon)" if piconOk else ""))
  else:
   FFkZTy(self, "Cannot create a unique Reference Code", title=title)
   return
 def VVVHcq(self, refCode):
  fPath, fDir, fName, picFile = CClBuf.VVl6cG(self)
  pPath = CCczfG.VVpOjs()
  if fileExists(pPath) and pathExists(picFile):
   pFile = refCode.replace(":", "_").strip("_") + ".png"
   dest = os.path.join(pPath, pFile)
   os.system(FFxZhj("cp -f '%s' '%s'" % (picFile, dest)))
   os.system(FFxZhj("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (dest, dest)))
   return True
  return False
 def VVNIrr(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VVyEiI(self):
  if self.isManualSeek:
   self.VVEpCL()
   self.VVhclQ(self.manualSeekPts)
  else:
   if self.shown: self.hide()
   else   : self.show()
 def cancel(self):
  if self.isManualSeek:
   self.VVEpCL()
  else:
   self.close()
 def VVXwp0(self):
  FFgCFv(self, fncMode=CClBuf.VV7FwT)
 def VVCweR(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except Exception as e:
   pass
  self.VVlO3U("Toggling Play/Pause ...")
 def VVEpCL(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVGRab(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVXTSC()
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.jumpMinutes * 60.0
   else:
    self.manualSeekSec += direc * self.jumpMinutes * 60.0
    self.manualSeekSec = FFTftb(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FF6Fzh(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFRxqD(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVN76N(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   FF3fcb(self["myPlayJmp"], self.VVkUji())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVlO3U("Changed Jump Minutes to : %d" % val)
 def VVkUji(self):
  return "Jump:%dm" % self.jumpMinutes
 def VVlO3U(self, stateTxt="", highlight=False):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
  fr = res = ""
  if info:
   w = FFY7OE(info, iServiceInformation.sVideoWidth) or -1
   h = FFY7OE(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFY7OE(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CClBuf.VV3gcV(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVXTSC()
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FFTftb(percVal, 0, 100)
    width = int(FF6Fzh(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not posTxt: self["myPlayPos"].setText("")
  if not remTxt: self["myPlayRem"].setText("")
  if not durTxt:
   if   prov : txt = prov
   elif posTxt : txt = ">>>>"
   else  : txt = "...."
   self["myPlayVal"].setText(txt)
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText("")
   FFc3QD(self["myPlayBarBG"], "#1100202a")
   self["myPlayBarF"].hide()
  else:
   FFc3QD(self["myPlayBarBG"], "#11000000")
   self["myPlayBarF"].show()
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VVvyC8() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   if highlight: FFXws7(self["myPlayMsg"], "#0000ffff")
   else  : FFXws7(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   self["myPlayMsg"].setText("-" if decodedUrl else FFouUf(refCode, True))
   FFXws7(self["myPlayMsg"], "#00ff8066")
  tot = CCL88j.VVNbt7()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVlvwW()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VVhclQ(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
  state = self.VVP23g()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFXws7(self["myPlayMsg"], "#0000ff00")
  else     : FFXws7(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVXTSC(self):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = self.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFRxqD(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFRxqD(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal
      remTxt = FFRxqD(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVlvwW(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VV9h0v(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVvyC8()
   if cList:
    VV4YjP = []
    for pts, what in cList:
     txt = FFRxqD(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VV4YjP.append((txt, pts))
    FF2oO5(self, self.VVOobW, VV4YjP=VV4YjP, title="Cut List")
   else:
    self.VVlO3U("No Cut-List for this channel !")
 def VVOobW(self, item=None):
  if item:
   self.VVhclQ(item)
 def VVvyC8(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VV2JP9(self) : self.VVdbmT(self.jumpMinutes)
 def VVjuSN(self) : self.VVdbmT(-self.jumpMinutes)
 def VVdbmT(self, mins):
  try:
   inst = InfoBar.instance
   inst.doSeekRelative(mins * 60 * 90000)
   inst.hide()
   if   mins > 0 : self.VVlO3U("Forawrd (%d min) ..." % self.jumpMinutes)
   elif mins < 0 : self.VVlO3U("Rewind (%d min) ..." % self.jumpMinutes)
  except:
   self.VVlO3U("Cannot jump")
 def VVXnKl(self):
  InfoBar.instance.VVXnKl()
 def VVhclQ(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVlO3U("Changing Time ...")
 def VVAIrt(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVXTSC()
   if durVal > 0:
    pts = int(durVal * 60 * 90000)
    InfoBar.instance.doSeek(pts)
    self.VVlO3U("Jumping to end ...")
  except:
   pass
 def VVP23g(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VViPv9(self, isUp):
  if self.enableZapping:
   self.VVlO3U("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVEpCL()
   if self.portalTableParam:
    FF4knh(boundFunction(self.VVVchx, isUp))
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
    if "/timeshift/" in decodedUrl:
     self.VVlO3U("Cannot Zap Catcup TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVn6xQ()
 def VVn6xQ(self):
  self.lastPlayPos = 0
  self.VVIV2E()
  self.VV78PU()
 def VVVchx(self, isUp):
  CCdgmH_inatance, VVv5LU, mode = self.portalTableParam
  if isUp : VVv5LU.VVP9wy()
  else : VVv5LU.VV6Rof()
  colList = VVv5LU.VVcFi1()
  if mode == "localIptv":
   chName, chUrl = CCdgmH_inatance.VVb0Hh(VVv5LU, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCdgmH_inatance.VVIAl6(VVv5LU, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCdgmH_inatance.VVfs6U(mode, VVv5LU, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCdgmH_inatance.VVnnEo(mode, VVv5LU, colList)
  else:
   self.VVlO3U("Cannot Zap")
   return
  FFyH61(self, chUrl, VVuGQM=False)
  self.VVn6xQ()
 def VV78PU(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVXTSC()
    if posTxt:
     return
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
   if not self.VVUOih(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVlO3U("Refreshing Portal")
   FF4knh(self.VVQcZh)
  except:
   pass
 def VVQcZh(self):
  self.restoreLastPlayPos = self.VVBR98()
 def VV3Pyz(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFtkuU(self)
  if not decodedUrl or FFYXBV(decodedUrl):
   self.VVlO3U("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCdgmH.VVinaS(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVlO3U("Reading Program List ...")
   ok_fnc = boundFunction(self.VVxyxr, refCode, chName, streamId, uHost, uUser, uPass)
   FF4knh(boundFunction(CCdgmH.VVJB5h, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVlO3U("Cannot process this channel")
 def VVxyxr(self, refCode, chName, streamId, uHost, uUser, uPass, VVv5LU, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVv5LU.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVlO3U("Changing Program ...")
   FF4knh(boundFunction(self.VVgHoF, chUrl))
  else:
   self.VVlO3U("Incorrect Timestamp !")
 def VVgHoF(self, chUrl):
   FFyH61(self, chUrl, VVuGQM=False)
   self.lastPlayPos = 0
   self.VVIV2E()
 def VVSIkP(self, isAudio):
  try:
   VVuOoM = InfoBar.instance
   if VVuOoM:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVuOoM)
    else  : self.session.open(SubtitleSelection, VVuOoM)
  except:
   pass
class CC6NFD(Screen):
 def __init__(self, session, title="", VVR8iK="Continue?", VVYmNt=True, VVEGkV=False):
  self.skin, self.skinParam = FF65g3(VV8YT4, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVR8iK = VVR8iK
  self.VVEGkV = VVEGkV
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVYmNt : VV4YjP = [no , yes]
  else   : VV4YjP = [yes, no ]
  FFC1qE(self, title, VV4YjP=VV4YjP, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVyEiI ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVR8iK)
  if self.VVEGkV:
   self["myLabel"].instance.setHAlign(0)
  self.VVxXd0()
  FF0PjP(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFtv1E(self["myMenu"])
  FF9g2V(self, self["myMenu"])
 def VVyEiI(self):
  item = FFau55(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVxXd0(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCyFM8(Screen):
 def __init__(self, session, title="", VV4YjP=None, width=1000, OKBtnFnc=None, VVUWK6=None, VVXcP7=None, VVRGLF=None, VVlEXM=None, VVmPdS=False, VVydPQ=False):
  self.skin, self.skinParam = FF65g3(VVbnJN, width, 850, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VV4YjP   = VV4YjP
  self.OKBtnFnc   = OKBtnFnc
  self.VVUWK6   = VVUWK6
  self.VVXcP7  = VVXcP7
  self.VVRGLF  = VVRGLF
  self.VVlEXM   = VVlEXM
  self.VVmPdS  = VVmPdS
  self.VVydPQ  = VVydPQ
  FFC1qE(self, title, VV4YjP=VV4YjP)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVyEiI          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVzVLm         ,
   "green"  : self.VVdlXr         ,
   "yellow" : self.VV3CAg         ,
   "blue"  : self.VVjBZE         ,
   "pageUp" : self.VVT41r       ,
   "chanUp" : self.VVT41r       ,
   "pageDown" : self.VVddpv        ,
   "chanDown" : self.VVddpv
  }, -1)
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FF0PjP(self["myMenu"])
  FFahFV(self)
  self.VV8GOQ(self["keyRed"]  , self.VVUWK6 )
  self.VV8GOQ(self["keyGreen"] , self.VVXcP7 )
  self.VV8GOQ(self["keyYellow"] , self.VVRGLF )
  self.VV8GOQ(self["keyBlue"]  , self.VVlEXM )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FF7qhl(self)
 def VV8GOQ(self, btnObj, btnFnc):
  if btnFnc:
   FF3fcb(btnObj, btnFnc[0])
 def VVyEiI(self):
  item = FFau55(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVmPdS: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVzVLm(self)  : self.VVrQH4(self.VVUWK6)
 def VVdlXr(self) : self.VVrQH4(self.VVXcP7)
 def VV3CAg(self) : self.VVrQH4(self.VVRGLF)
 def VVjBZE(self) : self.VVrQH4(self.VVlEXM)
 def VVrQH4(self, btnFnc):
  if btnFnc:
   item = FFau55(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVydPQ:
    self.cancel()
 def VVdpBe(self, VV4YjP):
  if len(VV4YjP) > 0:
   newList = []
   for item in VV4YjP:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVuDwO(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVT41r(self):
  self["myMenu"].moveToIndex(0)
 def VVddpv(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCqgup(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VVplFV=None, VVdQl9=None, VVbohG=None, VVIUEO=26, VVwbEy=False, VVnutX=None, VVmtel=None, VVyT4T=None, VV5ydd=None, VVxHB1=None, VV487W=None, VVWxNV=None, VVFSRM=None, VVDYxQ=None, VVSSrD=-1, VVligN=False, searchCol=0, VVZidB=None, VVCOuJ=None, VVZYrl="#00dddddd", VVQfS4="#11002233", VVl3OT="#00ff8833", VVJk0D="#11111111", VVJSW4="#0a555555", VV5c3k="#0affffff", VVpNa2="#11552200", VVdj7z="#0055ff55"):
  self.skin, self.skinParam = FF65g3(VVgCbm, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFC1qE(self, title)
  self.header     = header
  self.VVplFV     = VVplFV
  self.totalCols    = len(VVplFV[0])
  self.VVGvbb   = 0
  self.lastSortModeIsReverese = False
  self.VVwbEy   = VVwbEy
  self.VVvw1c   = 0.01
  self.VVNGRp   = 0.02
  self.VV9fAf = 0.03
  self.VV4Rxx  = 1
  self.VVbohG = VVbohG
  self.colWidthPixels   = []
  self.VVnutX   = VVnutX
  self.OKButtonObj   = None
  self.VVmtel   = VVmtel
  self.VVyT4T   = VVyT4T
  self.VV5ydd   = VV5ydd
  self.VVxHB1  = VVxHB1
  self.VV487W   = VV487W
  self.VVWxNV    = VVWxNV
  self.VVFSRM   = VVFSRM
  self.VVDYxQ  = VVDYxQ
  self.VVSSrD    = VVSSrD
  self.VVligN   = VVligN
  self.searchCol    = searchCol
  self.VVdQl9    = VVdQl9
  self.keyPressed    = -1
  self.VVIUEO    = FFc5Qc(VVIUEO)
  self.VV1IUN    = FFIQs2(self.VVIUEO, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVZidB    = VVZidB
  self.VVCOuJ      = VVCOuJ
  self.VVZYrl    = FFHCHO(VVZYrl)
  self.VVQfS4    = FFHCHO(VVQfS4)
  self.VVl3OT    = FFHCHO(VVl3OT)
  self.VVJk0D    = FFHCHO(VVJk0D)
  self.VVJSW4   = FFHCHO(VVJSW4)
  self.VV5c3k    = FFHCHO(VV5c3k)
  self.VVpNa2    = FFHCHO(VVpNa2)
  self.VVdj7z   = FFHCHO(VVdj7z)
  self.VVsbgz  = False
  self.selectedItems   = 0
  self.VVQdBF   = FFHCHO("#01fefe01")
  self.VVY8wv   = FFHCHO("#11400040")
  self.VVzSKL  = self.VVQdBF
  self.VVg1d2  = self.VVJk0D
  if self.VVligN:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVml04  ,
   "red"   : self.VVhAQE  ,
   "green"   : self.VV93o8 ,
   "yellow"  : self.VV56Js ,
   "blue"   : self.VVh3Sm  ,
   "menu"   : self.VVdya5 ,
   "info"   : self.VVbMQo  ,
   "cancel"  : self.VV8SMx  ,
   "up"   : self.VV6Rof    ,
   "down"   : self.VVP9wy  ,
   "left"   : self.VVVscY   ,
   "right"   : self.VV1fvR  ,
   "pageUp"  : self.VVSnME  ,
   "chanUp"  : self.VVSnME  ,
   "pageDown"  : self.VVCeyG  ,
   "chanDown"  : self.VVCeyG
  }, -1)
  FFbkDu(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FFhBiL(self)
  try:
   self.VV6uaN()
  except Exception as err:
   FFkZTy(self, str(err))
   self.close(None)
 def VV6uaN(self):
  FF7qhl(self)
  if self.VVZidB:
   FFc3QD(self["myTitle"], self.VVZidB)
  if self.VVCOuJ:
   FFc3QD(self["myBody"] , self.VVCOuJ)
   FFc3QD(self["myTableH"] , self.VVCOuJ)
   FFc3QD(self["myTable"] , self.VVCOuJ)
   FFc3QD(self["myBar"]  , self.VVCOuJ)
  self.VV8GOQ(self.VVyT4T  , self["keyRed"])
  self.VV8GOQ(self.VV5ydd  , self["keyGreen"])
  self.VV8GOQ(self.VVxHB1 , self["keyYellow"])
  self.VV8GOQ(self.VV487W  , self["keyBlue"])
  if self.VVnutX:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVnutX[0])
    FFc3QD(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VV1IUN)
  self["myTableH"].l.setFont(0, gFont(VV9SQC, self.VVIUEO))
  self["myTable"].l.setItemHeight(self.VV1IUN)
  self["myTable"].l.setFont(0, gFont(VV9SQC, self.VVIUEO))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VV1IUN)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VV1IUN))
   self["myTable"].instance.resize(eSize(*(w, h - self.VV1IUN)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VV1IUN
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VV1IUN * len(self.VVplFV) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVbohG:
   self.VVbohG = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVbohG)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVdQl9:
   self.VVdQl9 = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVdQl9
   self.VVdQl9 = []
   for item in tmpList:
    self.VVdQl9.append(item | RT_VALIGN_CENTER)
  self.VVlJRl()
  if self.VVWxNV:
   self.VVWxNV(self)
 def VV8GOQ(self, btnFnc, btn):
  if btnFnc : FF3fcb(btn, btnFnc[0])
  else  : FF3fcb(btn, "")
 def VV8Zwj(self, waitTxt):
  FFxBTP(self, self.VVlJRl, title=waitTxt)
 def VVlJRl(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVo56y(0, self.header, self.VV5c3k, self.VVpNa2, self.VV5c3k, self.VVpNa2, self.VVdj7z)])
   rows = []
   for c, row in enumerate(self.VVplFV):
    rows.append(self.VVo56y(c, row, self.VVZYrl, self.VVQfS4, self.VVl3OT, self.VVJk0D, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVSSrD > -1:
    self["myTable"].moveToIndex(self.VVSSrD )
   self.VVycMK()
   if self.VVligN:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VV1IUN * len(self.VVplFV)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVFSRM:
    self.VVrQH4(self.VVFSRM, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFkZTy(self, str(err))
    self.close()
   except:
    pass
 def VVo56y(self, keyIndex, columns, VVZYrl, VVQfS4, VVl3OT, VVJk0D, VVdj7z):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVdj7z and ndx == self.VVGvbb : textColor = VVdj7z
   else           : textColor = VVZYrl
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFHCHO(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVQfS4 = c
    entry = span.group(3)
   if self.VVdQl9[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VV1IUN)
           , font   = 0
           , flags   = self.VVdQl9[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVQfS4
           , color_sel  = VVl3OT
           , backcolor_sel = VVJk0D
           , border_width = 1
           , border_color = self.VVJSW4
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVbMQo(self):
  rowData = self.VVObWx()
  if rowData:
   title, txt, colList = rowData
   if self.VVmtel:
    fnc  = self.VVmtel[1]
    params = self.VVmtel[2]
    fnc(self, title, txt, colList)
   else:
    FFXXd4(self, txt, title)
 def VVml04(self):
  if   self.VVsbgz : self.VV1lO3(self.VVGAHI(), mode=2)
  elif self.VVnutX  : self.VVrQH4(self.VVnutX, None)
  else      : self.VVbMQo()
 def VVhAQE(self) : self.VVrQH4(self.VVyT4T , self["keyRed"])
 def VV93o8(self) : self.VVrQH4(self.VV5ydd , self["keyGreen"])
 def VV56Js(self): self.VVrQH4(self.VVxHB1 , self["keyYellow"])
 def VVh3Sm(self) : self.VVrQH4(self.VV487W , self["keyBlue"])
 def VVrQH4(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFuCKD(self, buttonFnc[3])
    FF4knh(boundFunction(self.VVUHTA, buttonFnc))
   else:
    self.VVUHTA(buttonFnc)
 def VVUHTA(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVObWx()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VV1lO3(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VVplFV[ndx]
   isSelected = row[1][9] == self.VVQdBF
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVo56y(ndx, item, self.VVZYrl, self.VVQfS4, self.VVl3OT, self.VVJk0D, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVo56y(ndx, item, self.VVQdBF, self.VVY8wv, self.VVzSKL, self.VVg1d2, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVycMK()
 def VV8R7M(self):
  FFxBTP(self, self.VVQM1B, title="Selecting all ...")
 def VVQM1B(self):
  self.VV6UOE(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVQdBF
   if not isSelected:
    item = self.VVplFV[ndx]
    newRow = self.VVo56y(ndx, item, self.VVQdBF, self.VVY8wv, self.VVzSKL, self.VVg1d2, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVycMK()
  self.VVviNC()
 def VVAvpE(self):
  FFxBTP(self, self.VVeEQ0, title="Unselecting all ...")
 def VVeEQ0(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVQdBF:
    item = self.VVplFV[ndx]
    newRow = self.VVo56y(ndx, item, self.VVZYrl, self.VVQfS4, self.VVl3OT, self.VVJk0D, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVycMK()
  self.VVviNC()
 def VVviNC(self):
  self.hide()
  self.show()
 def VVObWx(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVbohG[i] > 1 or self.VVbohG[i] == self.VVvw1c or self.VVbohG[i] == self.VV9fAf:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VVplFV))
   return rowNum, txt, colList
  else:
   return None
 def VV8SMx(self):
  if self.VVDYxQ : self.VVDYxQ(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVTGuP(self):
  return self["myTitle"].getText().strip()
 def VVpoQH(self):
  return self.header
 def VVq2QN(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVNe8y(self, txt):
  FFuCKD(self, txt)
 def VVd3iE(self, txt):
  FFuCKD(self, txt, 1000)
 def VVczFt(self):
  FFuCKD(self)
 def VVccPf(self):
  return len(self.VVplFV)
 def VVwi01(self): self["keyGreen"].show()
 def VV2DL0(self): self["keyGreen"].hide()
 def VVGAHI(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVZyIO(self):
  return len(self["myTable"].list)
 def VV6UOE(self, isOn):
  self.VVsbgz = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu"].hide()
   if self.VV487W: self["keyBlue"].hide()
   if self.VVnutX and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VV487W: self["keyBlue"].show()
   if self.VVnutX and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVnutX[0])
   self.VVAvpE()
  FFc3QD(self["myTitle"], color)
  FFc3QD(self["myBar"]  , color)
 def VVJIVC(self):
  return self.VVsbgz
 def VVajbj(self):
  return self.selectedItems
 def VVuh97(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVycMK()
 def VVvTPg(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVycMK()
 def VVloeA(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VVplFV:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVIY4G(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVccPf()
  txt += FFWpRC("Total Unique Items", VVGMgi)
  for i in range(self.totalCols):
   if self.VVbohG[i - 1] > 1 or self.VVbohG[i - 1] == self.VVvw1c or self.VVbohG[i - 1] == self.VV9fAf:
    name, tot = self.VVloeA(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFXXd4(self, txt)
 def VVaisE(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVcFi1(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVFYEc(self, newList, newTitle="", VVt27OMsg=True):
  if newList:
   self.VVplFV = newList
   if self.VVwbEy and self.VVGvbb == 0:
    self.VVplFV = sorted(self.VVplFV, key=lambda x: int(x[self.VVGvbb])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VVplFV = sorted(self.VVplFV, key=lambda x: x[self.VVGvbb].lower(), reverse=self.lastSortModeIsReverese)
   if VVt27OMsg : self.VV8Zwj("Refreshing ...")
   else   : self.VVlJRl()
   if newTitle:
    self.VVq2QN(newTitle)
  else:
   FFkZTy(self, "Cannot refresh list")
   self.cancel()
 def VVoUPy(self, data):
  ndx = self.VVGAHI()
  newRow = self.VVo56y(ndx, data, self.VVZYrl, self.VVQfS4, self.VVl3OT, self.VVJk0D, None)
  if newRow:
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVycMK()
   return True
  else:
   return False
 def VVmn28(self, colNum, textToFind, VVKlD3=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVycMK()
    break
  else:
   if VVKlD3:
    FFuCKD(self, "Not found", 1000)
 def VVfZXt(self, colDict, VVKlD3=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVycMK()
    return
  if VVKlD3:
   FFuCKD(self, "Not found", 1000)
 def VVfZXt_partial(self, colDict, VVKlD3=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVycMK()
    return
  if VVKlD3:
   FFuCKD(self, "Not found", 1000)
 def VVDPhr(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVO0aN(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVQdBF:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVAVTk(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVdya5(self):
  if not self["keyMenu"].getVisible() or self.VVligN:
   return
  VV4YjP = []
  VV4YjP.append(("Table Statistcis"             , "tableStat"  ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append((FFu1AK("Export Table to .html"     , VVGMgi) , "VVnjNJ" ))
  VV4YjP.append((FFu1AK("Export Table to .csv"     , VVGMgi) , "VVbQDs" ))
  VV4YjP.append((FFu1AK("Export Table to .txt (Tab Separated)", VVGMgi) , "VVIAJQ" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVbohG[i] > 1 or self.VVbohG[i] == self.VVNGRp:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VV4YjP.append(VV32Zp)
   if tot == 1 : VV4YjP.append(("Sort", sList[0][1]))
   else  : VV4YjP += sList
  FF2oO5(self, self.VVaCHH, VV4YjP=VV4YjP, title=self.VVTGuP())
 def VVaCHH(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVIY4G()
   elif item == "VVnjNJ": FFxBTP(self, self.VVnjNJ, title=title)
   elif item == "VVbQDs" : FFxBTP(self, self.VVbQDs , title=title)
   elif item == "VVIAJQ" : FFxBTP(self, self.VVIAJQ , title=title)
   else:
    isReversed = False
    if self.VVGvbb == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVwbEy and item == 0:
     self.VVplFV = sorted(self.VVplFV, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VVplFV = sorted(self.VVplFV, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVGvbb = item
    self.VV8Zwj("Sorting ...")
 def VV6Rof(self):
  self["myTable"].up()
  self.VVycMK()
 def VVP9wy(self):
  self["myTable"].down()
  self.VVycMK()
 def VVVscY(self):
  self["myTable"].pageUp()
  self.VVycMK()
 def VV1fvR(self):
  self["myTable"].pageDown()
  self.VVycMK()
 def VVSnME(self):
  self["myTable"].moveToIndex(0)
  self.VVycMK()
 def VVCeyG(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVycMK()
 def VVNAqK(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVycMK()
 def VVIAJQ(self):
  expFile = self.VVSN3C() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VV2v6l()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VVplFV:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVbohG[ndx] > self.VV4Rxx or self.VVbohG[ndx] == self.VV9fAf:
      col = self.VVizHq(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VV6UPb(expFile)
 def VVbQDs(self):
  expFile = self.VVSN3C() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VV2v6l()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VVplFV:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVbohG[ndx] > self.VV4Rxx or self.VVbohG[ndx] == self.VV9fAf:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVizHq(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VV6UPb(expFile)
 def VVnjNJ(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVTGuP(), PLUGIN_NAME, VVVxCA)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVTGuP()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VV2v6l()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVbohG:
   colgroup += '   <colgroup>'
   for w in self.VVbohG:
    if w > self.VV4Rxx or w == self.VV9fAf:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVSN3C() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VVplFV:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVbohG[ndx] > self.VV4Rxx or self.VVbohG[ndx] == self.VV9fAf:
      col = self.VVizHq(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VV6UPb(expFile)
 def VV2v6l(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVbohG[ndx] > self.VV4Rxx or self.VVbohG[ndx] == self.VV9fAf:
     newRow.append(col.strip())
  return newRow
 def VVizHq(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFrQie(col)
 def VVSN3C(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVTGuP())
  fileName = fileName.replace("__", "_")
  path  = FFk4Wy(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFKsmN()
  return expFile
 def VV6UPb(self, expFile):
  FFUwJf(self, "File exported to:\n\n%s" % expFile, title=self.VVTGuP())
 def VVycMK(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCOg0y(Screen):
 def __init__(self, session, title="", VV8s1L=None, showGrnMsg=""):
  self.skin, self.skinParam = FF65g3(VVAObh, 1400, 800, 30, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FFC1qE(self, title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VV8s1L = VV8s1L
  self.showGrnMsg  = showGrnMsg
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  allOK = FFg5SC(self["myLabel"], self.VV8s1L)
  if allOK:
   if self.showGrnMsg:
    FFuCKD(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFkZTy(self, "Cannot view picture file:\n\n%s" % self.VV8s1L)
   self.close()
class CCljBV(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FF65g3(VVzdp7, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  FFC1qE(self)
  FF3fcb(self["keyGreen"], "Save")
  self.VVplFV = []
  self.VVplFV.append(getConfigListEntry("Show in Main Menu"          , CFG.showInMainMenu   ))
  self.VVplFV.append(getConfigListEntry("Show in Extensions Menu"         , CFG.showInExtensionMenu  ))
  self.VVplFV.append(getConfigListEntry("Show in Channel List Context Menu"      , CFG.showInChannelListMenu  ))
  self.VVplFV.append(getConfigListEntry("Show in Events Info Menu"        , CFG.EventsInfoMenu   ))
  self.VVplFV.append(getConfigListEntry("Input Type"            , CFG.keyboard     ))
  self.VVplFV.append(getConfigListEntry("Signal & Player Cotroller Hotkey"      , CFG.hotkey_signal    ))
  if VVodYT:
   self.VVplFV.append(getConfigListEntry("EPG Translation Language"       , CFG.epgLanguage    ))
  self.VVplFV.append(getConfigListEntry(VVyYSf *2             ,         ))
  self.VVplFV.append(getConfigListEntry("Default IPTV Reference Type"        , CFG.iptvAddToBouquetRefType ))
  self.VVplFV.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"  , CFG.autoResetFrozenIptvChan ))
  self.VVplFV.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"     , CFG.hideIptvServerAdultWords ))
  self.VVplFV.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"  , CFG.hideIptvServerChannPrefix ))
  self.VVplFV.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"   , CFG.iptvHostsPath    ))
  self.VVplFV.append(getConfigListEntry("Movie/Series Download Path"        , CFG.MovieDownloadPath   ))
  self.VVplFV.append(getConfigListEntry(VVyYSf *2             ,         ))
  self.VVplFV.append(getConfigListEntry("PIcons Path"            , CFG.PIconsPath    ))
  self.VVplFV.append(getConfigListEntry(VVyYSf *2             ,         ))
  self.VVplFV.append(getConfigListEntry("Backup/Restore Path"          , CFG.backupPath    ))
  self.VVplFV.append(getConfigListEntry("Created Package Files (IPK/DEB)"       , CFG.packageOutputPath   ))
  self.VVplFV.append(getConfigListEntry("Downloaded Packages (from feeds)"      , CFG.downloadedPackagesPath ))
  self.VVplFV.append(getConfigListEntry("Exported Tables"           , CFG.exportedTablesPath  ))
  self.VVplFV.append(getConfigListEntry("Exported PIcons"           , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, self.VVplFV, session)
  self.VVZUx6()
  self.titleText = "  Settings"
  self["myTitle"].setText(self.titleText)
  self.onShown.append(self.VV2xXB)
 def VVZUx6(self):
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  kList = {
    "ok"  : self.VVyEiI    ,
    "green"  : self.VV4sNR   ,
    "menu"  : self.VVLTkB  ,
    "cancel" : self.VVFMmD  ,
    }
  if not (kLeft == kRight == None):
   kList["left"]  = boundFunction(self["config"].handleKey, kLeft)
   kList["right"]  = boundFunction(self["config"].handleKey, kRight)
   kList["chanUp"]  = self["config"].pageUp
   kList["chanDown"] = self["config"].pageDown
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FFhBiL(self)
  FF0PjP(self["config"])
  FFahFV(self, self["config"])
  FF7qhl(self)
 def VVyEiI(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsPath   : self.VVOwdh()
   elif item == CFG.MovieDownloadPath   : self.VV48mw(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VVMBgT(item)
   elif item == CFG.backupPath    : self.VVMBgT(item)
   elif item == CFG.packageOutputPath  : self.VVMBgT(item)
   elif item == CFG.downloadedPackagesPath : self.VVMBgT(item)
   elif item == CFG.exportedTablesPath  : self.VVMBgT(item)
   elif item == CFG.exportedPIconsPath  : self.VVMBgT(item)
 def VV48mw(self, item, title):
  tot = CCL88j.VVNbt7()
  if tot : FFkZTy(self, "Cannot change while downloading.", title=title)
  else : self.VVMBgT(item)
 def VVOwdh(self):
  VV4YjP = []
  VV4YjP.append(("Auto Find" , "auto"))
  VV4YjP.append(("Custom Path" , "path"))
  FF2oO5(self, self.VVVn5I, VV4YjP=VV4YjP, title="IPTV Hosts Files Path")
 def VVVn5I(self, item=None):
  if item:
   if   item == "auto": CFG.iptvHostsPath.setValue(VVDUxq)
   elif item == "path": self.VVMBgT(CFG.iptvHostsPath)
 def VVMBgT(self, configObj):
  sDir = configObj.getValue()
  if sDir == VVDUxq:
   sDir = "/"
  self.session.openWithCallback(boundFunction(self.VVPh6b, configObj)
         , boundFunction(CC5T3l, mode=CC5T3l.VVRWCr, VViCpT=sDir))
 def VVPh6b(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVFMmD(self):
  if CFG.showInMainMenu.isChanged()    or \
   CFG.showInExtensionMenu.isChanged()   or \
   CFG.showInChannelListMenu.isChanged()  or \
   CFG.EventsInfoMenu.isChanged()    or \
   CFG.keyboard.isChanged()     or \
   CFG.hotkey_signal.isChanged()    or \
   CFG.epgLanguage.isChanged()     or \
   CFG.iptvAddToBouquetRefType.isChanged()  or \
   CFG.autoResetFrozenIptvChan.isChanged()  or \
   CFG.hideIptvServerAdultWords.isChanged() or \
   CFG.hideIptvServerChannPrefix.isChanged() or \
   CFG.iptvHostsPath.isChanged()    or \
   CFG.MovieDownloadPath.isChanged()   or \
   CFG.PIconsPath.isChanged()     or \
   CFG.backupPath.isChanged()     or \
   CFG.packageOutputPath.isChanged()   or \
   CFG.downloadedPackagesPath.isChanged()  or \
   CFG.exportedTablesPath.isChanged()   or \
   CFG.exportedPIconsPath.isChanged():
    FFsJwx(self, self.VV4sNR, "Save Changes ?", callBack_No=self.cancel)
  else:
   self.cancel()
 def VV4sNR(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVzwWF()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVLTkB(self):
  VV4YjP = []
  VV4YjP.append(("Use Backup directory in all other paths"      , "VVfOS8"   ))
  VV4YjP.append(("Reset all to default (including File Manager bookmarks)"  , "VVJJNE"   ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Backup %s Settings" % PLUGIN_NAME        , "VVYpXT"  ))
  VV4YjP.append(("Restore %s Settings" % PLUGIN_NAME       , "VVjMCo"  ))
  if fileExists(VVA6fc + VVFOBg):
   VV4YjP.append(VV32Zp)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VV4YjP.append(('%s Checking for Update' % txt1       , txt2     ))
   VV4YjP.append(("Reinstall %s" % PLUGIN_NAME        , "VVgXl3"  ))
   VV4YjP.append(("Update %s" % PLUGIN_NAME        , "VVZdEP"   ))
  FF2oO5(self, self.VVfa0G, VV4YjP=VV4YjP, title="Config. Options")
 def VVfa0G(self, item=None):
  if item:
   if   item == "VVfOS8"  : FFsJwx(self, self.VVfOS8 , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVJJNE"  : FFsJwx(self, self.VVJJNE, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CC0o49)
   elif item == "VVYpXT" : self.VVYpXT()
   elif item == "VVjMCo" : FFxBTP(self, self.VVjMCo, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVOh4J(True)
   elif item == "disableChkUpdate" : self.VVOh4J(False)
   elif item == "VVgXl3" : FFxBTP(self, self.VVgXl3 , "Checking Server ...")
   elif item == "VVZdEP"  : FFxBTP(self, self.VVZdEP  , "Checking Server ...")
 def VVYpXT(self):
  path = "%sajpanel_settings_%s" % (VVA6fc, FFKsmN())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFUwJf(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVjMCo(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFwhw7("find / %s -iname '%s*' | grep %s" % (FFomXb(1), name, name))
  if lines:
   lines.sort()
   VV4YjP = []
   for line in lines:
    VV4YjP.append((line, line))
   FF2oO5(self, boundFunction(self.VVoIzw, title), title=title, VV4YjP=VV4YjP, width=1200)
  else:
   FFkZTy(self, "No settings files found !", title=title)
 def VVoIzw(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFghv7(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVzwWF()
    FFO8k9()
   else:
    FFLxgb(SELF, path, title=title)
 def VVOh4J(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVfOS8(self):
  newPath = FFk4Wy(VVA6fc)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVzwWF()
 @staticmethod
 def VVNJ0N():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVJJNE(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.EventsInfoMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.epgLanguage.setValue("off")
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.autoResetFrozenIptvChan.setValue(False)
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.iptvHostsPath.setValue(VVDUxq)
  CFG.MovieDownloadPath.setValue(CCL88j.VVNv3p())
  CFG.PIconsPath.setValue(VVcwd0)
  CFG.backupPath.setValue(CCljBV.VVNJ0N())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  CFG.showInMainMenu.save()
  CFG.showInExtensionMenu.save()
  CFG.showInChannelListMenu.save()
  CFG.EventsInfoMenu.save()
  CFG.keyboard.save()
  CFG.hotkey_signal.save()
  CFG.epgLanguage.save()
  CFG.iptvAddToBouquetRefType.save()
  CFG.autoResetFrozenIptvChan.save()
  CFG.hideIptvServerAdultWords.save()
  CFG.hideIptvServerChannPrefix.save()
  CFG.iptvHostsPath.save()
  CFG.MovieDownloadPath.save()
  CFG.PIconsPath.save()
  CFG.backupPath.save()
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  CFG.browserStartPath.save()
  CFG.browserBookmarks.save()
  self.VVzwWF()
  self.close()
 def VVzwWF(self):
  configfile.save()
  global VVA6fc
  VVA6fc = CFG.backupPath.getValue()
  FFiA6t()
 def VVZdEP(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVGnMi(title)
  if webVer:
   FFsJwx(self, boundFunction(FFxBTP, self, boundFunction(self.VV42wz, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVgXl3(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVGnMi(title, True)
  if webVer:
   FFsJwx(self, boundFunction(FFxBTP, self, boundFunction(self.VV42wz, webVer, title)), "Install and Restart ?", title=title)
 def VV42wz(self, webVer, title):
  url = self.VVcUzk(self, title)
  if url:
   VVgVej = FFCc49() == "dpkg"
   if VVgVej == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVgVej else "ipk")
   path, err = FFPMCM(url + fName, fName, timeout=2)
   if path:
    cmd = FF8XlR(VVTA1J, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFO3om(self, cmd)
    else:
     FFmzPi(self, title=title)
   else:
    FFkZTy(self, err, title=title)
 def VVGnMi(self, title, anyVer=False):
  url = self.VVcUzk(self, title)
  if not url:
   return ""
  path, err = FFPMCM(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFkZTy(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFQiI5(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFkZTy(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVVxCA.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFwhw7(cmd)
   if list and curVer == list[0]:
    return webVer
  FFUwJf(self, FFu1AK("No update required.", VVG7vV) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVcUzk(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVA6fc + VVFOBg
  if fileExists(path):
   span = iSearch(r"(http.+)", FFQiI5(path), IGNORECASE)
   if span : url = FFk4Wy(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFkZTy(SELF, err, title)
  return url
 @staticmethod
 def VVU9Jm(url):
  path, err = FFPMCM(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFQiI5(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVVxCA.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFwhw7(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CC0o49(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FF65g3(VV070d, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVVJdd
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFC1qE(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVtsIq("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVtsIq("\c00888888", i) + sp + "GREY\n"
   txt += self.VVtsIq("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVtsIq("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVtsIq("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVtsIq("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVtsIq("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVtsIq("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVtsIq("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVtsIq("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVtsIq("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVtsIq("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVyEiI ,
   "green"   : self.VVyEiI ,
   "left"   : self.VVBx2y ,
   "right"   : self.VVa5Bb ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  self.VVFZrs()
 def VVyEiI(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFsJwx(self, self.VVdl49, "Change to : %s" % txt, title=self.Title)
 def VVdl49(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVVJdd
  VVVJdd = self.cursorPos
  self.VVR1mu()
  self.close()
 def VVBx2y(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVFZrs()
 def VVa5Bb(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVFZrs()
 def VVFZrs(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVtsIq(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVRteb(color):
  if VVyveI: return "\\" + color
  else    : return ""
 @staticmethod
 def VVR1mu():
  global VVLXD9, VVKXn9, VVMioC, VVGMgi, VVeWfa, VVeNUb, VVG7vV, VVyveI, COLOR_CONS_BRIGHT_YELLOW, VVNRRl, VVx5R4, VV9edY, VVO6Kg
  VVO6Kg   = CC0o49.VVtsIq("\c00FFFFFF", VVVJdd)
  VVKXn9    = CC0o49.VVtsIq("\c00888888", VVVJdd)
  VVLXD9  = CC0o49.VVtsIq("\c005A5A5A", VVVJdd)
  VVeNUb    = CC0o49.VVtsIq("\c00FF0000", VVVJdd)
  VVMioC   = CC0o49.VVtsIq("\c00FF5000", VVVJdd)
  VVyveI   = CC0o49.VVtsIq("\c00FFFF00", VVVJdd)
  COLOR_CONS_BRIGHT_YELLOW = CC0o49.VVtsIq("\c00FFFFAA", VVVJdd)
  VVG7vV   = CC0o49.VVtsIq("\c0000FF00", VVVJdd)
  VVeWfa    = CC0o49.VVtsIq("\c000066FF", VVVJdd)
  VVNRRl    = CC0o49.VVtsIq("\c0000FFFF", VVVJdd)
  VVx5R4  = CC0o49.VVtsIq("\c00DSFFFF", VVVJdd)  #
  VV9edY   = CC0o49.VVtsIq("\c00FA55E7", VVVJdd)
  VVGMgi    = CC0o49.VVtsIq("\c00FF8F5F", VVVJdd)
CC0o49.VVR1mu()
class CC81kT(Screen):
 def __init__(self, session, path, VVgVej):
  self.skin, self.skinParam = FF65g3(VVYQha, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VV3gZa   = path
  self.VVK05w   = ""
  self.VVORR3   = ""
  self.VVgVej    = VVgVej
  self.VVCXZB    = ""
  self.VV1zm3  = ""
  self.VVPqb1    = False
  self.VV97TV  = False
  self.postInstAcion   = 0
  self.VVlJrY  = "enigma2-plugin-extensions"
  self.VVTNsJ  = "enigma2-plugin-systemplugins"
  self.VVJNmk = "enigma2"
  self.VVXSJI  = 0
  self.VV5quZ  = 1
  self.VVQlr7  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVGwjZ = "DEBIAN"
  else        : self.VVGwjZ = "CONTROL"
  self.controlPath = self.Path + self.VVGwjZ
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVgVej:
   self.packageExt  = ".deb"
   self.VVQfS4  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVQfS4  = "#11001020"
  FFC1qE(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FF3fcb(self["keyRed"] , "Create")
  FF3fcb(self["keyGreen"] , "Post Install")
  FF3fcb(self["keyYellow"], "Installation Path")
  FF3fcb(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVxkAq  ,
   "green"   : self.VV7qHm ,
   "yellow"  : self.VV69X5  ,
   "blue"   : self.VV6aRh  ,
   "cancel"  : self.VV5NgR
  }, -1)
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  FF7qhl(self)
  if self.VVQfS4:
   FFc3QD(self["myBody"], self.VVQfS4)
   FFc3QD(self["myLabel"], self.VVQfS4)
  self.VV85H9(True)
  self.VV3LHU(True)
 def VV3LHU(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVjQoc()
  if isFirstTime:
   if   package.startswith(self.VVlJrY) : self.VV3gZa = VVXgRS + self.VVCXZB + "/"
   elif package.startswith(self.VVTNsJ) : self.VV3gZa = VVqP7G + self.VVCXZB + "/"
   else            : self.VV3gZa = self.Path
  if self.VVPqb1 : myColor = VVGMgi
  else    : myColor = VVO6Kg
  txt  = ""
  txt += "Source Path\t: %s\n" % FFu1AK(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFu1AK(self.VV3gZa, VVyveI)
  if self.VVORR3 : txt += "Package File\t: %s\n" % FFu1AK(self.VVORR3, VVKXn9)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFu1AK("Check Control File fields : %s" % errTxt, VVMioC)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFu1AK("Restart GUI", VVGMgi)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFu1AK("Reboot Device", VVGMgi)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFu1AK("Post Install", VVG7vV), act)
  if not errTxt and VVMioC in controlInfo:
   txt += "Warning\t: %s\n" % FFu1AK("Errors in control file may affect the result package.", VVMioC)
  txt += "\nControl File\t: %s\n" % FFu1AK(self.controlFile, VVKXn9)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VV7qHm(self):
  VV4YjP = []
  VV4YjP.append(("No Action"    , "noAction"  ))
  VV4YjP.append(("Restart GUI"    , "VV5pky"  ))
  VV4YjP.append(("Reboot Device"   , "rebootDev"  ))
  FF2oO5(self, self.VVceOZ, title="Package Installation Option (after completing installation)", VV4YjP=VV4YjP)
 def VVceOZ(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VV5pky"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VV85H9(False)
   self.VV3LHU()
 def VV69X5(self):
  rootPath = FFu1AK("/%s/" % self.VVCXZB, VVLXD9)
  VV4YjP = []
  VV4YjP.append(("Current Path"        , "toCurrent"  ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Extension Path"       , "toExtensions" ))
  VV4YjP.append(("System Plugins Path"      , "toSystemPlugins" ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VV4YjP.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FF2oO5(self, self.VVjGJv, title="Installation Path", VV4YjP=VV4YjP)
 def VVjGJv(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVoqKl(FF4tyU(self.Path, True))
   elif item == "toExtensions"  : self.VVoqKl(VVXgRS)
   elif item == "toSystemPlugins" : self.VVoqKl(VVqP7G)
   elif item == "toRootPath"  : self.VVoqKl("/")
   elif item == "toRoot"   : self.VVoqKl("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVgns3, boundFunction(CC5T3l, mode=CC5T3l.VVRWCr, VViCpT=VVA6fc))
 def VVgns3(self, path):
  if len(path) > 0:
   self.VVoqKl(path)
 def VVoqKl(self, parent, withPackageName=True):
  if withPackageName : self.VV3gZa = parent + self.VVCXZB + "/"
  else    : self.VV3gZa = "/"
  mode = self.VVYKS7()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VV5AAI(mode), self.controlFile))
  self.VV3LHU()
 def VV6aRh(self):
  if fileExists(self.controlFile):
   lines = FFghv7(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFmIMB(self, self.VVqf6p, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFkZTy(self, "Version not found or incorrectly set !")
  else:
   FFLxgb(self, self.controlFile)
 def VVqf6p(self, VV1tLf):
  if VV1tLf:
   version, color = self.VVGHB3(VV1tLf, False)
   if color == VVNRRl:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VV1tLf, self.controlFile))
    self.VV3LHU()
   else:
    FFkZTy(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VV5NgR(self):
  if self.newControlPath:
   if self.VVPqb1:
    self.VV0SFW()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFu1AK(self.newControlPath, VVKXn9)
    txt += FFu1AK("Do you want to keep these files ?", VVyveI)
    FFsJwx(self, self.close, txt, callBack_No=self.VV0SFW, title="Create Package", VVEGkV=True)
  else:
   self.close()
 def VV0SFW(self):
  os.system(FFxZhj("rm -r '%s'" % self.newControlPath))
  self.close()
 def VV5AAI(self, mode):
  if   mode == self.VV5quZ : prefix = self.VVlJrY
  elif mode == self.VVQlr7 : prefix = self.VVTNsJ
  else        : prefix = self.VVJNmk
  return prefix + "-" + self.VV1zm3
 def VVYKS7(self):
  if   self.VV3gZa.startswith(VVXgRS) : return self.VV5quZ
  elif self.VV3gZa.startswith(VVqP7G) : return self.VVQlr7
  else            : return self.VVXSJI
 def VV85H9(self, isFirstTime):
  self.VVCXZB   = os.path.basename(os.path.normpath(self.Path))
  self.VVCXZB   = "_".join(self.VVCXZB.split())
  self.VV1zm3 = self.VVCXZB.lower()
  self.VVPqb1 = self.VV1zm3 == VVZO7B.lower()
  if self.VVPqb1 and self.VV1zm3.endswith("ajpan"):
   self.VV1zm3 += "el"
  if self.VVPqb1 : self.VVK05w = VVA6fc
  else    : self.VVK05w = CFG.packageOutputPath.getValue()
  self.VVK05w = FFk4Wy(self.VVK05w)
  if not pathExists(self.controlPath):
   os.system(FFxZhj("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVPqb1 : t = PLUGIN_NAME
  else    : t = self.VVCXZB
  self.VVM6hW(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVKauo.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVPqb1 : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVM6hW(self.postrmFile, txt)
  if self.VVPqb1:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVVxCA)
   self.VVM6hW(self.preinstFile, txt)
  else:
   self.VVM6hW(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVCXZB)
  mode = self.VVYKS7()
  if isFirstTime and not mode == self.VVXSJI:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVyYSf
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVM6hW(self.postinstFile, txt, VVATyh=True)
  os.system(FFxZhj("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVPqb1 : version, descripton, maintainer = VVVxCA , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVCXZB , self.VVCXZB
   txt = ""
   txt += "Package: %s\n"  % self.VV5AAI(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVM6hW(self, path, lines, VVATyh=False):
  if not fileExists(path) or VVATyh:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVjQoc(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFghv7(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFu1AK(line, VVMioC)
     elif not line.startswith(" ")    : line = FFu1AK(line, VVMioC)
     else          : line = FFu1AK(line, VVNRRl)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVNRRl
   else   : color = VVMioC
   descr = FFu1AK(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVMioC
     elif line.startswith((" ", "\t")) : color = VVMioC
     elif line.startswith("#")   : color = VVKXn9
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVGHB3(val, True)
      elif key == "Version"  : version, color = self.VVGHB3(val, False)
      elif key == "Maintainer" : maint  , color = val, VVNRRl
      elif key == "Architecture" : arch  , color = val, VVNRRl
      else:
       color = VVNRRl
      if not key == "OE" and not key.istitle():
       color = VVMioC
     else:
      color = VVGMgi
     txt += FFu1AK(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVORR3 = self.VVK05w + packageName
   self.VV97TV = True
   errTxt = ""
  else:
   self.VVORR3  = ""
   self.VV97TV = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVGHB3(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVNRRl
  else          : return val, VVMioC
 def VVxkAq(self):
  if not self.VV97TV:
   FFkZTy(self, "Please fix Control File errors first.")
   return
  if self.VVgVej: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FF4tyU(self.VV3gZa, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVCXZB
  symlinkTo  = FFqenw(self.Path)
  dataDir   = self.VV3gZa.rstrip("/")
  removePorjDir = FFxZhj("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFxZhj("rm -f '%s'" % self.VVORR3) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFYBb8()
  if self.VVgVej:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFGJDB("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVPqb1:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VV3gZa == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVGwjZ)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVORR3, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVORR3
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVORR3, FF8EkF(result  , VVG7vV))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VV3gZa, FF8EkF(instPath, VVNRRl))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FF8EkF(failed, VVMioC))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFO3om(self, cmd)
class CC5T3l(Screen):
 VVm4ow   = 0
 VVRWCr  = 1
 VVNjun = 20
 VVXqOd  = None
 def __init__(self, session, VViCpT="/", mode=VVm4ow, VVFvRG="Select", VVIUEO=30, gotoMovie=False):
  self.skin, self.skinParam = FF65g3(VVbnJN, 1400, 920, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFC1qE(self)
  FF3fcb(self["keyRed"] , "Exit")
  FF3fcb(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVFvRG = VVFvRG
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  CC5T3l.VVXqOd = self
  if   self.gotoMovie        : VVJT3y, self.VViCpT = True , CC5T3l.VV31dK(self)[1] or "/"
  elif self.mode == self.VVm4ow  : VVJT3y, self.VViCpT = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVRWCr : VVJT3y, self.VViCpT = False, VViCpT
  else           : VVJT3y, self.VViCpT = True , VViCpT
  self.VViCpT = FFk4Wy(self.VViCpT)
  self["myMenu"] = CCvwoE(  directory   = "/"
         , VVJT3y   = VVJT3y
         , VVvg8E = True
         , VVJxcX   = self.skinParam["width"]
         , VVIUEO   = self.skinParam["bodyFontSize"]
         , VV1IUN  = self.skinParam["bodyLineH"]
         , VV71ap  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVyEiI      ,
   "red"    : self.VVIj6r     ,
   "green"    : self.VVzqSV    ,
   "yellow"   : self.VVjgeM   ,
   "blue"    : self.VVVomM   ,
   "menu"    : self.VVQWAe    ,
   "info"    : self.VVmQn1    ,
   "cancel"   : self.VVZtuQ     ,
   "pageUp"   : self.VVZtuQ     ,
   "chanUp"   : self.VVZtuQ
  }, -1)
  FFbkDu(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VV84CM)
 def onExit(self):
  CC5T3l.VVXqOd = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VV84CM)
  FFhBiL(self)
  FF0PjP(self["myMenu"], bg="#06003333")
  FF7qhl(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode == self.VVRWCr:
   FF3fcb(self["keyGreen"], self.VVFvRG)
   color = "#22000022"
   FFc3QD(self["myBody"], color)
   FFc3QD(self["myMenu"], color)
   color = "#22220000"
   FFc3QD(self["myTitle"], color)
   FFc3QD(self["myBar"], color)
  self.VV84CM()
  if self.VVXYU2(self.VViCpT) > self.bigDirSize:
   FFuCKD(self, "Changing directory...")
   FF4knh(self.VVdzRK)
  else:
   self.VVdzRK()
 def VVdzRK(self):
  self["myMenu"].VVbdSP(self.VViCpT)
  if self.gotoMovie:
   self.VVa9YY(chDir=False)
 def VVNAqK(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVmyTy(self):
  self["myMenu"].refresh()
  FF71De()
 def VVXYU2(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VVyEiI(self):
  if self["myMenu"].VVk2vm():
   path = self.VVSdxR(self.VV0IKZ())
   if self.VVXYU2(path) > self.bigDirSize:
    FFuCKD(self, "Changing directory...")
    FF4knh(self.VVFupP)
   else:
    self.VVFupP()
  else:
   self.VV9jpd()
 def VVFupP(self):
  self["myMenu"].descent()
  self.VV84CM()
 def VVZtuQ(self):
  if self["myMenu"].VVUZ4z():
   self["myMenu"].moveToIndex(0)
   self.VVFupP()
 def VVIj6r(self):
  if not FFcn9Z(self):
   self.close("")
 def VVzqSV(self):
  if self.mode == self.VVRWCr:
   path = self.VVSdxR(self.VV0IKZ())
   self.close(path)
 def VVmQn1(self):
  FFxBTP(self, self.VVyWOT, title="Calculating size ...")
 def VVyWOT(self):
  path = self.VVSdxR(self.VV0IKZ())
  param = self.VVisIU(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFoABH("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CC5T3l.VV4Q8E(path)
     freeSize = CC5T3l.VV7D2I(path)
     size = totSize - freeSize
     totSize  = CC5T3l.VVfT2w(totSize)
     freeSize = CC5T3l.VVfT2w(freeSize)
    else:
     size = FFoABH("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CC5T3l.VVfT2w(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFu1AK(pathTxt, VVGMgi) + "\n"
   if slBroken : fileTime = self.VVEjIH(path)
   else  : fileTime = self.VVtnN0(path)
   def VVjO6x(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVjO6x("Path"    , pathTxt)
   txt += VVjO6x("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVjO6x("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVjO6x("Total Size"   , "%s" % totSize)
    txt += VVjO6x("Used Size"   , "%s" % usedSize)
    txt += VVjO6x("Free Size"   , "%s" % freeSize)
   else:
    txt += VVjO6x("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVjO6x("Owner"    , owner)
   txt += VVjO6x("Group"    , group)
   txt += VVjO6x("Perm. (User)"  , permUser)
   txt += VVjO6x("Perm. (Group)"  , permGroup)
   txt += VVjO6x("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVjO6x("Perm. (Ext.)" , permExtra)
   txt += VVjO6x("iNode"    , iNode)
   txt += VVjO6x("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVyYSf, VVyYSf)
    txt += hLinkedFiles
   txt += self.VVuFIT(path)
  else:
   FFkZTy(self, "Cannot access information !")
  if len(txt) > 0:
   FFXXd4(self, txt)
 def VVisIU(self, path):
  path = path.strip()
  path = FFqenw(path)
  result = FFoABH("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVGrZn(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVGrZn(perm, 1, 4)
   permGroup = VVGrZn(perm, 4, 7)
   permOther = VVGrZn(perm, 7, 10)
   permExtra = VVGrZn(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFrjhl("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVuFIT(self, path):
  txt  = ""
  res  = FFoABH("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFu1AK("File Attributes:", VV9edY), txt)
  return txt
 def VVtnN0(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFNSik(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFNSik(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFNSik(os.path.getctime(path))
  return txt
 def VVEjIH(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFoABH("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFoABH("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFoABH("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVSdxR(self, currentSel):
  currentDir  = self["myMenu"].VVUZ4z()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVk2vm():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VV0IKZ(self):
  return self["myMenu"].getSelection()[0]
 def VV84CM(self):
  FFuCKD(self)
  path = self.VVSdxR(self.VV0IKZ())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VVplFV = self.VVMQbS()
  if VVplFV and len(VVplFV) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VVqXoy(path)
  if self.mode == self.VVm4ow and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
 def VVqXoy(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVc9sv(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVQWAe(self):
  if self.mode == self.VVm4ow:
   path  = self.VVSdxR(self.VV0IKZ())
   isDir  = os.path.isdir(path)
   VV4YjP = []
   VV4YjP.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVYA48(path):
     sepShown = True
     VV4YjP.append(VV32Zp)
     VV4YjP.append( (VVGMgi + "Archiving / Packaging"      , "VV1Dvs"  ))
    if self.VVhzsB(path):
     if not sepShown:
      VV4YjP.append(VV32Zp)
     VV4YjP.append( (VVGMgi + "Read Backup information"     , "VVtdVM"  ))
     VV4YjP.append( (VVGMgi + "Compress Octagon Image (to zip File)"  , "VVPyCg" ))
   elif os.path.isfile(path):
    selFile = self.VV0IKZ()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar")) : VV4YjP.extend(self.VVJGA8(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VV4YjP.extend(self.VVE7eh(True))
    elif selFile.endswith(".m3u")              : VV4YjP.extend(self.VVoxh6(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FFLiCQ(path):
     VV4YjP.append(VV32Zp)
     VV4YjP.append((VVGMgi + "View" , "text_View" ))
     VV4YjP.append((VVGMgi + "Edit" , "text_Edit" ))
    if len(txt) > 0:
     VV4YjP.append(VV32Zp)
     VV4YjP.append(   (VVGMgi + txt      , "VV9jpd"  ))
   VV4YjP.append(VV32Zp)
   VV4YjP.append(     ("Create SymLink"       , "VVDRfh" ))
   if not self.VVYA48(path):
    VV4YjP.append(   ("Rename"          , "VVF3UP" ))
    VV4YjP.append(   ("Copy"           , "copyFileOrDir" ))
    VV4YjP.append(   ("Move"           , "moveFileOrDir" ))
    VV4YjP.append(   ("DELETE"          , "VVuVVn" ))
    if fileExists(path):
     VV4YjP.append(VV32Zp)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VV4YjP.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VV4YjP.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VV4YjP.append( (chmodTxt + "777)"       , "chmod777"  ))
   VV4YjP.append(VV32Zp)
   VV4YjP.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VV4YjP.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CC5T3l.VV31dK(self)
   if fPath:
    VV4YjP.append(VV32Zp)
    VV4YjP.append(   (VVyveI + "Go to current movie"  , "VVa9YY"))
   VV4YjP.append(VV32Zp)
   VV4YjP.append(    ("Set current directory as \"Startup Path\"" , "VVxKUz" ))
   FF2oO5(self, self.VVjqOl, title="Options", VV4YjP=VV4YjP)
 def VVjqOl(self, item=None):
  if self.mode == self.VVm4ow:
   if item is not None:
    path = self.VVSdxR(self.VV0IKZ())
    selFile = self.VV0IKZ()
    if   item == "properties"    : self.VVmQn1()
    elif item == "VV1Dvs"  : self.VV1Dvs(path)
    elif item == "VVtdVM"  : self.VVtdVM(path)
    elif item == "VVPyCg" : self.VVPyCg(path)
    elif item.startswith("extract_")  : self.VVx7IX(path, selFile, item)
    elif item.startswith("script_")   : self.VVriUY(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVBO8SItem_m3u(path, selFile, item)
    elif item.startswith("text_View")  : FFr7JP(self, path)
    elif item.startswith("text_Edit")  : CCU5Qm(self, path)
    elif item == "chmod644"     : self.VVyKkI(path, selFile, "644")
    elif item == "chmod755"     : self.VVyKkI(path, selFile, "755")
    elif item == "chmod777"     : self.VVyKkI(path, selFile, "777")
    elif item == "VVDRfh"   : self.VVDRfh(path, selFile)
    elif item == "VVF3UP"   : self.VVF3UP(path, selFile)
    elif item == "copyFileOrDir"   : self.VVLvw2(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVLvw2(path, selFile, True)
    elif item == "VVuVVn"   : self.VVuVVn(path, selFile)
    elif item == "createNewFile"   : self.VV8ML1(path, True)
    elif item == "createNewDir"    : self.VV8ML1(path, False)
    elif item == "VVa9YY"   : self.VVa9YY()
    elif item == "VVxKUz"   : self.VVxKUz(path)
    elif item == "VV9jpd"    : self.VV9jpd()
    else         : self.close()
 def VV9jpd(self):
  selFile = self.VV0IKZ()
  path  = self.VVSdxR(selFile)
  if os.path.isfile(path):
   VVC2Uz = []
   category = self["myMenu"].VVVePj(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VV9Znd(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FFoFhU(self, selFile, path)
   elif category == "txt"         : FFr7JP(self, path)
   elif category in ("tar", "zip", "rar")     : self.VVEKJi(path, selFile)
   elif category == "scr"         : self.VVywEW(path, selFile)
   elif category == "m3u"         : self.VVgzwK(path, selFile)
   elif category in ("ipk", "deb")       : self.VVRpda(path, selFile)
   elif category == "mus"         : self.VVhoPs(self, path)
   elif category == "mov"         : self.VVhoPs(self, path)
   elif not FFLiCQ(path)        : FFr7JP(self, path)
 def VVjgeM(self):
  path = self.VVSdxR(self.VV0IKZ())
  action = self.VVqXoy(path)
  if action == 1:
   self.VVdXqX(path)
   FFuCKD(self, "Added", 500)
  elif action == -1:
   self.VVHRAe(path)
   FFuCKD(self, "Removed", 500)
  self.VVqXoy(path)
 def VVdXqX(self, path):
  VVplFV = self.VVMQbS()
  if not VVplFV:
   VVplFV = []
  if len(VVplFV) >= self.VVNjun:
   FFkZTy(SELF, "Max bookmarks reached (max=%d)." % self.VVNjun)
  elif not path in VVplFV:
   VVplFV = [path] + VVplFV
   self.VVLrk6(VVplFV)
 def VVVomM(self):
  VVplFV = self.VVMQbS()
  if VVplFV:
   newList = []
   for line in VVplFV:
    newList.append((line, line))
   VVUWK6  = ("Delete"  , self.VV217y )
   VVRGLF = ("Move Up"   , self.VVM1be )
   VVlEXM  = ("Move Down" , self.VVu25k )
   self.bookmarkMenu = FF2oO5(self, self.VVvLQP, title="Bookmarks", VV4YjP=newList, VVUWK6=VVUWK6, VVRGLF=VVRGLF, VVlEXM=VVlEXM)
 def VV217y(self, VV0IKZObj, path):
  if self.bookmarkMenu:
   VVplFV = self.VVHRAe(path)
   self.bookmarkMenu.VVdpBe(VVplFV)
 def VVM1be(self, VV0IKZObj, path):
  if self.bookmarkMenu:
   VVplFV = self.bookmarkMenu.VVuDwO(True)
   if VVplFV:
    self.VVLrk6(VVplFV)
 def VVu25k(self, VV0IKZObj, path):
  if self.bookmarkMenu:
   VVplFV = self.bookmarkMenu.VVuDwO(False)
   if VVplFV:
    self.VVLrk6(VVplFV)
 def VVvLQP(self, folder=None):
  if folder:
   folder = FFk4Wy(folder)
   self["myMenu"].VVbdSP(folder)
   self["myMenu"].moveToIndex(0)
  self.VV84CM()
 def VVMQbS(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVc9sv(self, path):
  VVplFV = self.VVMQbS()
  if VVplFV and path in VVplFV:
   return True
  else:
   return False
 def VV8QmY(self):
  if VVMQbS():
   return True
  else:
   return False
 def VVLrk6(self, VVplFV):
  line = ",".join(VVplFV)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVHRAe(self, path):
  VVplFV = self.VVMQbS()
  if VVplFV:
   while path in VVplFV:
    VVplFV.remove(path)
   self.VVLrk6(VVplFV)
   return VVplFV
 def VVa9YY(self, chDir=True):
  fPath, fDir, fName = CC5T3l.VV31dK(self)
  if fPath:
   if chDir:
    self["myMenu"].VVbdSP(fDir)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFuCKD(self, "Not found", 1000)
 def VVxKUz(self, path):
  if not os.path.isdir(path):
   path = FF4tyU(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VV9Znd(self, selFile, VVR8iK, command):
  FFsJwx(self, boundFunction(FFO3om, self, command, VVm8DP=self.VVmyTy), "%s\n\n%s" % (VVR8iK, selFile))
 def VVJGA8(self, path, calledFromMenu):
  destPath = self.VVteSy(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VV4YjP = []
  if calledFromMenu:
   VV4YjP.append(VV32Zp)
   color = VVGMgi
  else:
   color = ""
  VV4YjP.append((color + "List Archived Files"          , "extract_listFiles" ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VV4YjP.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VV4YjP.append((color + "Extract Here"            , "extract_here"  ))
  if VVsYt6 and path.endswith(".tar.gz"):
   VV4YjP.append(VV32Zp)
   VV4YjP.append((color + 'Convert to ".ipk" Package' , "VVAi2J"  ))
   VV4YjP.append((color + 'Convert to ".deb" Package' , "VVItvC"  ))
  return VV4YjP
 def VVEKJi(self, path, selFile):
  FF2oO5(self, boundFunction(self.VVx7IX, path, selFile), title="Compressed File Options", VV4YjP=self.VVJGA8(path, False))
 def VVx7IX(self, path, selFile, item=None):
  if item is not None:
   parent  = FF4tyU(path, False)
   destPath = self.VVteSy(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVyYSf
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFGJDB("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFGJDB("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVyYSf, VVyYSf)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFRkbo(self, cmd)
   elif path.endswith(".zip"):
    self.VVNZJS(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif path.endswith(".rar"):
    self.VVLNrf(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFxZhj("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VV9Znd(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VV9Znd(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FF4tyU(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VV9Znd(selFile, "Extract Here ?"      , cmd)
   elif item == "VVAi2J" : self.VVAi2J(path)
   elif item == "VVItvC" : self.VVItvC(path)
 def VVteSy(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVNZJS(self, item, path, parent, destPath, VVR8iK):
  FFsJwx(self, boundFunction(self.VVjJwq, item, path, parent, destPath), VVR8iK)
 def VVjJwq(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVyYSf
  cmd  = FFGJDB("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FF8EkF(destPath, VVG7vV))
  cmd +=   sep
  cmd += "fi;"
  FFJGAU(self, cmd, VVm8DP=self.VVmyTy)
 def VVLNrf(self, item, path, parent, destPath, VVR8iK):
  FFsJwx(self, boundFunction(self.VVNEan, item, path, parent, destPath), VVR8iK)
 def VVNEan(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFk4Wy(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVyYSf
  cmd  = FFGJDB("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FF8EkF(destPath, VVG7vV))
  cmd +=   sep
  cmd += "fi;"
  FFJGAU(self, cmd, VVm8DP=self.VVmyTy)
 def VVE7eh(self, addSep=False):
  VV4YjP = []
  if addSep:
   VV4YjP.append(VV32Zp)
  VV4YjP.append((VVGMgi + "View Script File"  , "script_View"  ))
  VV4YjP.append((VVGMgi + "Execute Script File" , "script_Execute" ))
  VV4YjP.append((VVGMgi + "Edit"     , "script_Edit" ))
  return VV4YjP
 def VVywEW(self, path, selFile):
  FF2oO5(self, boundFunction(self.VVriUY, path, selFile), title="Script File Options", VV4YjP=self.VVE7eh())
 def VVriUY(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFr7JP(self, path)
   elif item == "script_Execute" : self.VV9Znd(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCU5Qm(self, path)
 def VVoxh6(self, addSep=False):
  VV4YjP = []
  if addSep:
   VV4YjP.append(VV32Zp)
  VV4YjP.append((VVGMgi + "Browse IPTV Channels"  , "m3u_Browse" ))
  VV4YjP.append((VVGMgi + "Edit"      , "m3u_Edit" ))
  VV4YjP.append((VVGMgi + "View"      , "m3u_View" ))
  return VV4YjP
 def VVgzwK(self, path, selFile):
  FF2oO5(self, boundFunction(self.VVBO8SItem_m3u, path, selFile), title="M3U/M3U8 File Options", VV4YjP=self.VVoxh6())
 def VVBO8SItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFxBTP(self, boundFunction(self.session.open, CCdgmH, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCU5Qm(self, path)
   elif item == "m3u_View"  : FFr7JP(self, path)
 def VVyKkI(self, path, selFile, newChmod):
  FFsJwx(self, boundFunction(self.VVcGT6, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVcGT6(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVNzYd)
  result = FFoABH(cmd)
  if result == "Successful" : FFUwJf(self, result)
  else      : FFkZTy(self, result)
 def VVDRfh(self, path, selFile):
  parent = FF4tyU(path, False)
  self.session.openWithCallback(self.VVlBvs, boundFunction(CC5T3l, mode=CC5T3l.VVRWCr, VViCpT=parent, VVFvRG="Create Symlink here"))
 def VVlBvs(self, newPath):
  if len(newPath) > 0:
   target = self.VVSdxR(self.VV0IKZ())
   target = FFqenw(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFk4Wy(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFkZTy(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFsJwx(self, boundFunction(self.VV40Vm, target, link), "Create Soft Link ?\n\n%s" % txt, VVEGkV=True)
 def VV40Vm(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVNzYd)
  result = FFoABH(cmd)
  if result == "Successful" : FFUwJf(self, result)
  else      : FFkZTy(self, result)
 def VVF3UP(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFmIMB(self, boundFunction(self.VVlFfi, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVlFfi(self, path, selFile, VV1tLf):
  if VV1tLf:
   parent = FF4tyU(path, True)
   if os.path.isdir(path):
    path = FFqenw(path)
   newName = parent + VV1tLf
   cmd = "mv '%s' '%s' %s" % (path, newName, VVNzYd)
   if VV1tLf:
    if selFile != VV1tLf:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFsJwx(self, boundFunction(self.VVa6Ll, cmd), message, title="Rename file?")
    else:
     FFkZTy(self, "Cannot use same name!", title="Rename")
 def VVa6Ll(self, cmd):
  result = FFoABH(cmd)
  if "Fail" in result:
   FFkZTy(self, result)
  self.VVmyTy()
 def VVLvw2(self, path, selFile, isMove):
  if isMove : VVFvRG = "Move to here"
  else  : VVFvRG = "Copy to here"
  parent = FF4tyU(path, False)
  self.session.openWithCallback(boundFunction(self.VVlc84, isMove, path, selFile)
         , boundFunction(CC5T3l, mode=CC5T3l.VVRWCr, VViCpT=parent, VVFvRG=VVFvRG))
 def VVlc84(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFqenw(path)
   newPath = FFk4Wy(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFsJwx(self, boundFunction(FFb4nu, self, cmd, VVm8DP=self.VVmyTy), txt, VVEGkV=True)
   else:
    FFkZTy(self, "Cannot %s to same directory !" % action.lower())
 def VVuVVn(self, path, fileName):
  path = FFqenw(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFsJwx(self, boundFunction(self.VV90aJ, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VV90aJ(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VVmyTy()
 def VVYA48(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VV6vw4 and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VV8ML1(self, path, isFile):
  dirName = FFk4Wy(os.path.dirname(path))
  if isFile : objName, VV1tLf = "File"  , self.edited_newFile
  else  : objName, VV1tLf = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFmIMB(self, boundFunction(self.VVpbe3, dirName, isFile, title), title=title, defaultText=VV1tLf, message="Enter %s Name:" % objName)
 def VVpbe3(self, dirName, isFile, title, VV1tLf):
  if VV1tLf:
   if isFile : self.edited_newFile = VV1tLf
   else  : self.edited_newDir  = VV1tLf
   path = dirName + VV1tLf
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVNzYd)
    else  : cmd = "mkdir '%s' %s" % (path, VVNzYd)
    result = FFoABH(cmd)
    if "Fail" in result:
     FFkZTy(self, result)
    self.VVmyTy()
   else:
    FFkZTy(self, "Name already exists !\n\n%s" % path, title)
 def VVRpda(self, path, selFile):
  VV4YjP = []
  VV4YjP.append(("List Package Files"          , "VVAViP"     ))
  VV4YjP.append(("Package Information"          , "VVu55T"     ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Install Package"           , "VVJEhZ_CheckVersion" ))
  VV4YjP.append(("Install Package (force reinstall)"      , "VVJEhZ_ForceReinstall" ))
  VV4YjP.append(("Install Package (force overwrite)"      , "VVJEhZ_ForceOverwrite" ))
  VV4YjP.append(("Install Package (force downgrade)"      , "VVJEhZ_ForceDowngrade" ))
  VV4YjP.append(("Install Package (ignore failed dependencies)"    , "VVJEhZ_IgnoreDepends" ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Remove Related Package"         , "VV0zlR_ExistingPackage" ))
  VV4YjP.append(("Remove Related Package (force remove)"     , "VV0zlR_ForceRemove"  ))
  VV4YjP.append(("Remove Related Package (ignore failed dependencies)"  , "VV0zlR_IgnoreDepends" ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("Extract Files"           , "VVZbPl"     ))
  VV4YjP.append(("Unbuild Package"           , "VVBOZV"     ))
  FF2oO5(self, boundFunction(self.VVNmS6, path, selFile), VV4YjP=VV4YjP)
 def VVNmS6(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVAViP"      : self.VVAViP(path, selFile)
   elif item == "VVu55T"      : self.VVu55T(path)
   elif item == "VVJEhZ_CheckVersion"  : self.VVJEhZ(path, selFile, VVlw3T     )
   elif item == "VVJEhZ_ForceReinstall" : self.VVJEhZ(path, selFile, VVTA1J )
   elif item == "VVJEhZ_ForceOverwrite" : self.VVJEhZ(path, selFile, VVuYZI )
   elif item == "VVJEhZ_ForceDowngrade" : self.VVJEhZ(path, selFile, VVOctN )
   elif item == "VVJEhZ_IgnoreDepends" : self.VVJEhZ(path, selFile, VVmBvd )
   elif item == "VV0zlR_ExistingPackage" : self.VV0zlR(path, selFile, VVSstK     )
   elif item == "VV0zlR_ForceRemove"  : self.VV0zlR(path, selFile, VVepO0  )
   elif item == "VV0zlR_IgnoreDepends"  : self.VV0zlR(path, selFile, VVfG69 )
   elif item == "VVZbPl"     : self.VVZbPl(path, selFile)
   elif item == "VVBOZV"     : self.VVBOZV(path, selFile)
   else           : self.close()
 def VVAViP(self, path, selFile):
  if FFpLPM("ar") : cmd = "allOK='1';"
  else    : cmd  = FFYBb8()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVyYSf, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVyYSf, VVyYSf)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFUQFp(self, cmd, VVm8DP=self.VVmyTy)
 def VVZbPl(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FF4tyU(path, True) + selFile[:-4]
  cmd  =  FFYBb8()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFxZhj("mkdir '%s'" % dest) + ";"
  cmd +=    FFxZhj("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FF8EkF(dest, VVG7vV))
  cmd += "fi;"
  FFO3om(self, cmd, VVm8DP=self.VVmyTy)
 def VVBOZV(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVkbje = os.path.splitext(path)[0]
  else        : VVkbje = path + "_"
  if path.endswith(".deb")   : VVGwjZ = "DEBIAN"
  else        : VVGwjZ = "CONTROL"
  cmd  = FFYBb8()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVkbje, FFjCF2())
  cmd += "  mkdir '%s';"    % VVkbje
  cmd += "  CONTPATH='%s/%s';"  % (VVkbje, VVGwjZ)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVkbje
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVkbje, VVkbje)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVkbje
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVkbje, VVkbje)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVkbje
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVkbje
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVkbje, FF8EkF(VVkbje, VVG7vV))
  cmd += "fi;"
  FFO3om(self, cmd, VVm8DP=self.VVmyTy)
 def VVu55T(self, path):
  listCmd  = FFZIC7(VVc8pZ, "")
  infoCmd  = FF8XlR(VVlJ3S , "")
  filesCmd = FF8XlR(VVJ6I7, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FF8zAJ(VVyveI)
   notInst = "Package not installed."
   cmd  = FF92Aw("File Info", VVyveI)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FF92Aw("System Info", VVyveI)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FF8EkF(notInst, VVGMgi))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FF92Aw("Related Files", VVyveI)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFRkbo(self, cmd)
  else:
   FFmzPi(self)
 def VVJEhZ(self, path, selFile, cmdOpt):
  cmd = FF8XlR(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFsJwx(self, boundFunction(FFO3om, self, cmd, VVm8DP=FF71De), "Install Package ?\n\n%s" % selFile)
  else:
   FFmzPi(self)
 def VV0zlR(self, path, selFile, cmdOpt):
  listCmd  = FFZIC7(VVc8pZ, "")
  infoCmd  = FF8XlR(VVlJ3S, "")
  instRemCmd = FF8XlR(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FF8EkF(errTxt, VVGMgi))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FF8EkF(cannotTxt, VVGMgi))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FF8EkF(tryTxt, VVGMgi))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFsJwx(self, boundFunction(FFO3om, self, cmd, VVm8DP=FF71De), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFmzPi(self)
 def VVy9CW(self, path):
  hostName = FFoABH("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVhzsB(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVy9CW(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VV1Dvs(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VV4YjP = []
  VV4YjP.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VV4YjP.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VV4YjP.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VV4YjP.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VV4YjP.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VV4YjP.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VV4YjP.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VV4YjP.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VV4YjP.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VV4YjP.append(VV32Zp)
  VV4YjP.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VV4YjP.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FF2oO5(self, boundFunction(self.VVk71s, path), VV4YjP=VV4YjP)
 def VVk71s(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVc4UI(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVc4UI(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVc4UI(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVc4UI(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVc4UI(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVc4UI(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVc4UI(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVc4UI(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVc4UI(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVc4UI(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VV487A(path, False)
   elif item == "convertDirToDeb"   : self.VV487A(path, True)
   else         : self.close()
 def VV487A(self, path, VVgVej):
  self.session.openWithCallback(self.VVmyTy, boundFunction(CC81kT, path=path, VVgVej=VVgVej))
 def VVc4UI(self, path, fileExt, preserveDirStruct):
  parent  = FF4tyU(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFGJDB("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFGJDB("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFGJDB("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVyYSf
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFxZhj("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FF8EkF(resultFile, VVG7vV))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FF8EkF(failed, VVMioC))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFUQFp(self, cmd, VVm8DP=self.VVmyTy)
 def VVtdVM(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFr7JP(self, versionFile)
 def VVPyCg(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVy9CW(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFkZTy(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFghv7(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FF4tyU(path, False)
  VVkbje = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FF8EkF(errCmd, VVMioC))
  installCmd = FF8XlR(VVlw3T , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVkbje, VVkbje)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVkbje
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVkbje
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVkbje, VVkbje)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFO3om(self, cmd, VVm8DP=self.VVmyTy)
 def VVAi2J(self, path):
  FFkZTy(self, "Under Construction.")
 def VVItvC(self, path):
  FFkZTy(self, "Under Construction.")
 @staticmethod
 def VVhoPs(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   SELF.session.open(CCnyHZ, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VV31dK(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFk4Wy(fDir), fName
  return "", "", ""
 @staticmethod
 def VV4Q8E(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VV7D2I(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVfT2w(size, mode=0):
  txt = CC5T3l.VVjygI(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVjygI(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
class CCvwoE(MenuList):
 def __init__(self, VVvg8E=False, directory="/", VVRx0e=True, VVJT3y=True, VVge2o=True, VV92oz=None, VVNouF=False, VV7XGO=False, VV2rXZ=False, isTop=False, VVACWi=None, VVJxcX=1000, VVIUEO=30, VV1IUN=30, VV71ap="#00000000"):
  MenuList.__init__(self, list, VVvg8E, eListboxPythonMultiContent)
  self.VVRx0e  = VVRx0e
  self.VVJT3y    = VVJT3y
  self.VVge2o  = VVge2o
  self.VV92oz  = VV92oz
  self.VVNouF   = VVNouF
  self.VV7XGO   = VV7XGO or []
  self.VV2rXZ   = VV2rXZ or []
  self.isTop     = isTop
  self.additional_extensions = VVACWi
  self.VVJxcX    = VVJxcX
  self.VVIUEO    = VVIUEO
  self.VV1IUN    = VV1IUN
  self.pngBGColor    = FFHCHO(VV71ap)
  self.EXTENSIONS    = self.VVB89I()
  self.VVT0Y4   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VV9SQC, self.VVIUEO))
  self.l.setItemHeight(self.VV1IUN)
  self.png_mem   = self.VV1j7u("mem")
  self.png_usb   = self.VV1j7u("usb")
  self.png_fil   = self.VV1j7u("fil")
  self.png_dir   = self.VV1j7u("dir")
  self.png_dirup   = self.VV1j7u("dirup")
  self.png_srv   = self.VV1j7u("srv")
  self.png_slwfil   = self.VV1j7u("slwfil")
  self.png_slbfil   = self.VV1j7u("slbfil")
  self.png_slwdir   = self.VV1j7u("slwdir")
  self.VVNWtR()
  self.VVbdSP(directory)
 def VV1j7u(self, category):
  return LoadPixmap("%s%s.png" % (VVII1V, category), getDesktop(0))
 def VVB89I(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "rar" : "rar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u" ,
   "m3u8" : "m3u"
  }
 def VVfFfn(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFqenw(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFu1AK(" -> " , VVyveI) + FFu1AK(os.readlink(path), VVG7vV)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VV1IUN + 10, 0, self.VVJxcX, self.VV1IUN, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVVenG: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV1IUN-4, self.VV1IUN-4, png, self.pngBGColor, self.pngBGColor, VVVenG))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV1IUN-4, self.VV1IUN-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVVePj(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVNWtR(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVAsxI(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVl7CM(self, file):
  if os.path.realpath(file) == file:
   return self.VVAsxI(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVAsxI(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVAsxI(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVxfQS(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVT0Y4.info(l[0][0]).getEvent(l[0][0])
 def VVQfQd(self):
  return self.list
 def VVOU8U(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVbdSP(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVge2o:
    self.current_mountpoint = self.VVl7CM(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVge2o:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VV2rXZ and not self.VVOU8U(path, self.VV7XGO):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVfFfn(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVNouF:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVT0Y4 = eServiceCenter.getInstance()
   list = VVT0Y4.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVRx0e and not self.isTop:
   if directory == self.current_mountpoint and self.VVge2o:
    self.list.append(self.VVfFfn(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VV2rXZ and self.VVAsxI(directory) in self.VV2rXZ):
    self.list.append(self.VVfFfn(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVRx0e:
   for x in directories:
    if not (self.VV2rXZ and self.VVAsxI(x) in self.VV2rXZ) and not self.VVOU8U(x, self.VV7XGO):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVfFfn(name = name, absolute = x, isDir = True, png = png))
  if self.VVJT3y:
   for x in files:
    if self.VVNouF:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFu1AK(" -> " , VVyveI) + FFu1AK(target, VVG7vV)
       else:
        png = self.png_slbfil
        name += FFu1AK(" -> " , VVyveI) + FFu1AK(target, VVMioC)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVVePj(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVII1V, category))
    if (self.VV92oz is None) or iCompile(self.VV92oz).search(path):
     self.list.append(self.VVfFfn(name = name, absolute = x , isDir = False, png = png))
  if self.VVge2o and len(self.list) == 0:
   self.list.append(self.VVfFfn(name = FFu1AK("No USB connected", VVKXn9), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVUZ4z(self):
  return self.current_directory
 def VVk2vm(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVbdSP(self.getSelection()[0], select = self.current_directory)
 def VV5kNP(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VV3OWD(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVl4hA)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVl4hA)
 def refresh(self):
  self.VVbdSP(self.current_directory, self.VV5kNP())
 def VVl4hA(self, action, device):
  self.VVNWtR()
  if self.current_directory is None:
   self.refresh()
class CC30RM(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FF65g3(VVkTZL, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVplFV   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVpLaP(defFG, "#00FFFFFF")
  self.defBG   = self.VVpLaP(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFC1qE(self, self.Title)
  self["keyRed"].show()
  FF3fcb(self["keyGreen"] , "< > Transp.")
  FF3fcb(self["keyYellow"], "Foreground")
  FF3fcb(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVnwtx        ,
   "yellow"   : boundFunction(self.VVI395, False)  ,
   "blue"   : boundFunction(self.VVI395, True)  ,
   "up"   : self.VVfp4a          ,
   "down"   : self.VVwcmZ         ,
   "left"   : self.VVBx2y         ,
   "right"   : self.VVa5Bb         ,
   "last"   : boundFunction(self.VVus7o, -5) ,
   "next"   : boundFunction(self.VVus7o, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VV2xXB)
 def VV2xXB(self):
  self.onShown.remove(self.VV2xXB)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFc3QD(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFc3QD(self["keyRed"] , c)
  FFc3QD(self["keyGreen"] , c)
  self.VVelpg()
  self.VVlP2z()
  FFXws7(self["myColorTst"], self.defFG)
  FFc3QD(self["myColorTst"], self.defBG)
 def VVpLaP(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVlP2z(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVdcft(0, 0)
     return
 def VVnwtx(self):
  self.close(self.defFG, self.defBG)
 def VVfp4a(self): self.VVdcft(-1, 0)
 def VVwcmZ(self): self.VVdcft(1, 0)
 def VVBx2y(self): self.VVdcft(0, -1)
 def VVa5Bb(self): self.VVdcft(0, 1)
 def VVdcft(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVZqsp()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVSbqJ()
 def VVelpg(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVSbqJ(self):
  color = self.VVZqsp()
  if self.isBgMode: FFc3QD(self["myColorTst"], color)
  else   : FFXws7(self["myColorTst"], color)
 def VVI395(self, isBg):
  self.isBgMode = isBg
  self.VVelpg()
  self.VVlP2z()
 def VVus7o(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVdcft(0, 0)
 def VVUn4I(self):
  return hex(self.transp)[2:].zfill(2)
 def VVZqsp(self):
  return ("#%s%s" % (self.VVUn4I(), self.colors[self.curRow][self.curCol])).upper()
class CCzpvL(ScrollLabel):
 def __init__(self, parentSELF, text="", VVcNUm=True):
  ScrollLabel.__init__(self, text)
  self.VVcNUm=VVcNUm
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVJ0Vu  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVIUEO    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close   ,
   "cancel"  : parentSELF.close   ,
   "red"   : self.VV0zG6   ,
   "green"   : self.VVx813  ,
   "yellow"  : self.VVrh50  ,
   "blue"   : self.VVMuH2  ,
   "up"   : self.pageUp    ,
   "down"   : self.pageDown    ,
   "left"   : self.pageUp    ,
   "right"   : self.pageDown    ,
   "pageUp"  : self.VVbqRS    ,
   "chanUp"  : self.VVbqRS    ,
   "pageDown"  : self.VVUvZl    ,
   "chanDown"  : self.VVUvZl
  }, -1)
 def VVWjn0(self, isResizable=True, VV2L7a=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FF7qhl(self.parentSELF, True)
  self.isResizable = isResizable
  if VV2L7a:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVIUEO  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFc3QD(self, color)
 def FFc3QDColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVJ0Vu - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVktRp()
 def pageUp(self):
  if self.VVJ0Vu > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVJ0Vu > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVbqRS(self):
  self.setPos(0)
 def VVUvZl(self):
  self.setPos(self.VVJ0Vu-self.pageHeight)
 def VVlq5m(self):
  return self.VVJ0Vu <= self.pageHeight or self.curPos == self.VVJ0Vu - self.pageHeight
 def VVktRp(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVJ0Vu, 3))
   start = int((100 - vis) * self.curPos / (self.VVJ0Vu - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VV66pN=VVGsh0):
  old_VVlq5m = self.VVlq5m()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VVJ0Vu = self.long_text.calculateSize().height()
   if self.VVcNUm and self.VVJ0Vu > self.pageHeight:
    self.scrollbar.show()
    self.VVktRp()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVJ0Vu))
   if   VV66pN == VVY6j5: self.setPos(0)
   elif VV66pN == VVOCNl : self.VVUvZl()
   elif old_VVlq5m    : self.VVUvZl()
 def appendText(self, text, VV66pN=VVOCNl):
  self.setText(self.message + str(text), VV66pN)
 def VVrh50(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVEpCe(size)
 def VVMuH2(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVEpCe(size)
 def VVx813(self):
  self.VVEpCe(self.VVIUEO)
 def VVEpCe(self, VVIUEO):
  self.long_text.setFont(gFont(self.fontFamily, VVIUEO))
  self.setText(self.message, VV66pN=VVGsh0)
  self.VVtJrC(calledFromFontSizer=True)
 def VV0zG6(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FFk4Wy(expPath), self.textOutFile, FFKsmN())
    with open(outF, "w") as f:
     f.write(FFrQie(self.message))
    FFUwJf(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FFkZTy(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVtJrC(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVJ0Vu > 0 and self.pageHeight > 0:
   if self.VVJ0Vu < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVJ0Vu
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
