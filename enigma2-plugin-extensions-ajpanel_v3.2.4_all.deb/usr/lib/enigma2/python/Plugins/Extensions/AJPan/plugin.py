import os
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import ceil as iCeil
from time      import localtime, mktime, strftime, time as iTime
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVyy0v   = "v3.2.4"
VVVFWg    = "20-12-2021"
EASY_MODE    = 0
VVLWxX   = 0
VVEog1   = 0
VVloRZ  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVgT5I  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVbxzm    = "/media/usb/"
VVlO79    = "/usr/share/enigma2/picon/"
VVeRDn   = "/etc/enigma2/"
VVzdHc  = "ajpanel_update_url"
VVpGPW   = "AJPan"
VV8e5A    = "AUTO FIND"
VVUPCw    = ""
VVbhwc    = "Regular"
VVlWOd      = "-" * 80;
VVWygA    = ("-" * 100, )
VVEipR    = ""
VV7NYO   = " && echo 'Successful' || echo 'Failed!'"
VVC8iG    = []
VVyxHj  = "Cannot continue (No Enough Memory) !"
VVeFzk     = 0
VVF7WX    = ""
VVvPtm  = False
VVAkV7 = False
VVhg3T  = False
VVQV0S     = 0
VVkgSN    = 1
VVI3cc    = 2
VVGF95   = 3
VV4Jy1    = 4
VVmgsS    = 5
VVwgeJ = 6
VVFncf = 7
VVlzPL  = 8
VVfgzn   = 9
VVn45i   = 10
VVjyaz   = 11
VVjLx4  = 12
VVqLiq  = 13
VVvgu9    = 14
VVxDcM   = 15
VVIRaO   = 16
VVFsTR    = 17
VVnHE9    = 18
VVxwOa  = 15
VVUbEX   = 0
VVmdF8   = 1
VV1GDe   = 2
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices = [ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices = [ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices = [ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices = [ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsPath    = ConfigDirectory(default=VV8e5A, visible_width=51)
CFG.PIconsPath     = ConfigDirectory(default=VVlO79, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVbxzm, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
def FFBdI2():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VV5vEh  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVVcbN = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VV5vEh  : return 0
  elif VVVcbN : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVynug = FFBdI2()
VVKVzn = VVea45 = VVNRjX = VVBEBZ = VVK98e = VVVOLr = VVI0dy = VVX3gJ = COLOR_CONS_BRIGHT_YELLOW = VVVJBw = VVVqHz = VVaDNx = ""
def FFVMMr(FFVMMrText="", addSep=True):
 if VVLWxX:
  FFVMMrText = str(FFVMMrText)
  if "\n" in FFVMMrText: FFVMMrText = "\n" + FFVMMrText
  txt = VVlWOd + "\n" if addSep else ""
  txt += ">>>> %s >>  %s" % (PLUGIN_NAME, str(FFVMMrText))
  os.system("cat << '_EOF' \n" + txt + "\n_EOF")
def FFRPvh(txt, isAppend=True, ignoreErr=False):
 if VVLWxX:
  tm = FFf7s4()
  err = ""
  if not ignoreErr:
   try:
    from traceback import format_exc, format_stack
    trace = format_exc()
    if trace and len(trace) > 5:
     stack = format_stack()[:-1]
     sep = "*" * 70
     err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
     err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   except:
    pass
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFVMMr(err)
  FFVMMr("Output Log File : %s" % fileName)
VVC8iG = []
def FFeXHw(win):
 global VVC8iG
 if not win in VVC8iG:
  VVC8iG.append(win)
def FF0RxM(*args):
 global VVC8iG
 for win in VVC8iG:
  try:
   win.close()
  except:
   pass
 VVC8iG = []
def FF5IPT():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVCzvI = FF5IPT()
def getDescriptor(fnc, where, name=PLUGIN_NAME):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=True, name=name, description=PLUGIN_DESCRIPTION, icon=icon)
def FFP2kq()      : return getDescriptor(FFhcEP   , [ PluginDescriptor.WHERE_PLUGINMENU  ] )
def FFtO14()   : return getDescriptor(FFhcEP   , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] )
def FF3ozT()   : return getDescriptor(FFUaO1 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager")
def FFfF5Q()  : return getDescriptor(FF8QpJ , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Live Log (OSCam/NCam)")
def FFYDMD(): return getDescriptor(FFNG3y , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player")
def FFCTMM()  : return getDescriptor(FFUrvd  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV")
def FFpvks()     : return getDescriptor(FFF4ds , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info.")
def FFABsZ()       : return getDescriptor(FF8M69  , [ PluginDescriptor.WHERE_MENU    ] )
def FFSzLG()     : return PluginDescriptor(fnc=FFX83u, where=[PluginDescriptor.WHERE_SESSIONSTART])
def Plugins(**kwargs):
 result = [ FFP2kq() , FFABsZ() , FFSzLG() , FFpvks()]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFtO14())
  result.append(FF3ozT())
  result.append(FFfF5Q())
  result.append(FFYDMD())
  result.append(FFCTMM())
 return result
def FFX83u(reason, **kwargs):
 if reason == 0:
  FFMoz3()
  if "session" in kwargs:
   session = kwargs["session"]
   FFhln6(session)
   CCDOp1(session)
def FF8M69(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFhcEP, PLUGIN_NAME, 45)]
 else:
  return []
def FFhcEP(session, **kwargs):
 session.open(Main_Menu)
def FFUaO1(session, **kwargs):
 session.open(CCvQ2O)
def FF8QpJ(session, **kwargs):
 FF2meU(session, CCDWkt.VVdHzv)
def FFNG3y(session, **kwargs):
 FFT4Q8(session, isFromSession=True)
def FFUrvd(session, **kwargs):
 session.open(CCjXCp)
def FFF4ds(session, **kwargs):
 session.open(CCAHNs, fncMode=CCAHNs.VVtbnB)
def FFrCRC():
 pluginList   = iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU)
 descrPanel   = FFtO14()
 descrFileMan  = FF3ozT()
 descrCamLog   = FFfF5Q()
 descrSignalPlayer = FFYDMD()
 descrIptvMenu  = FFCTMM()
 try:
  if CFG.showInExtensionMenu.getValue():
   if not descrPanel in pluginList   : iPlugins.addPlugin(descrPanel)
   if not descrFileMan in pluginList  : iPlugins.addPlugin(descrFileMan)
   if not descrCamLog in pluginList  : iPlugins.addPlugin(descrCamLog)
   if not descrSignalPlayer in pluginList : iPlugins.addPlugin(descrSignalPlayer)
   if not descrIptvMenu in pluginList  : iPlugins.addPlugin(descrIptvMenu)
  else:
   if descrPanel in pluginList    : iPlugins.removePlugin(descrPanel)
   if descrFileMan in pluginList   : iPlugins.removePlugin(descrFileMan)
   if descrCamLog in pluginList   : iPlugins.removePlugin(descrCamLog)
   if descrSignalPlayer in pluginList  : iPlugins.removePlugin(descrSignalPlayer)
   if descrIptvMenu in pluginList   : iPlugins.removePlugin(descrIptvMenu)
 except:
  pass
VVYvBp = None
def FFMoz3():
 try:
  global VVYvBp
  if VVYvBp is None:
   VVYvBp    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFo4nK
  ChannelContextMenu.FF52AB = FF52AB
 except:
  pass
def FFo4nK(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVYvBp(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FF52AB, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FF52AB, title1, csel, isFind=True))))
def FF52AB(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFYDAT(refCode)
 except:
  pass
 self.session.open(boundFunction(CC6tWW, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFhln6(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFzCZC, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFzCZC, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFzCZC, session, "lred")
def FFzCZC(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFT4Q8(session, isFromSession=True)
def FFKXoA(SELF, title="", addLabel=False, addScrollLabel=False, VVwdxM=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFVjlE()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 if SELF.skinParam["topRightBtns"] > 0:
  SELF["keyMenu2F"]  = Label()
  SELF["keyMenu2"]  = Label("Menu")
  if SELF.skinParam["topRightBtns"] > 1:
   SELF["keyMenu1F"] = Label()
   SELF["keyMenu1"] = Label("Info")
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCVmtM(SELF)
 if VVwdxM:
  SELF["myMenu"] = MenuList(VVwdxM)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVPtX0        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFUYXl(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FFwWsx, SELF, "0") ,
  "1"    : boundFunction(FFwWsx, SELF, "1") ,
  "2"    : boundFunction(FFwWsx, SELF, "2") ,
  "3"    : boundFunction(FFwWsx, SELF, "3") ,
  "4"    : boundFunction(FFwWsx, SELF, "4") ,
  "5"    : boundFunction(FFwWsx, SELF, "5") ,
  "6"    : boundFunction(FFwWsx, SELF, "6") ,
  "7"    : boundFunction(FFwWsx, SELF, "7") ,
  "8"    : boundFunction(FFwWsx, SELF, "8") ,
  "9"    : boundFunction(FFwWsx, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFVxqf, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFwWsx(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVaDNx:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVaDNx + SELF.keyPressed + VVea45)
    txt = VVea45 + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFU79C(SELF, txt)
def FFVxqf(SELF, tableObj, colNum):
 FFU79C(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     tableObj.moveToIndex(i)
     SELF.VVDm0k()
     break
 except:
  pass
def FFY2w4(SELF, setMenuAction=True):
 if setMenuAction:
  global VVEipR
  VVEipR = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFVjlE():
 return ("  %s" % VVEipR)
def FFhu6U(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFaO74(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFzcsD(color):
 return parseColor(color).argb()
def FF1NxI(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFpRmN(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFBavC(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFdpXa(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVaDNx)
 else:
  return ""
def FFMJrr(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVlWOd, word, VVlWOd, VVaDNx)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVlWOd, word, VVlWOd)
def FFY8RM(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVaDNx
def FF2OPV(color):
 if color: return "echo -e '%s' %s;" % (VVlWOd, FFdpXa(VVlWOd, VVX3gJ))
 else : return "echo -e '%s';" % VVlWOd
def FFNBmg(title, color):
 title = "%s\n%s\n%s\n" % (VVlWOd, title, VVlWOd)
 return FFY8RM(title, color)
def FFfopI(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FF65YQ(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFZQW5(callBackFunction):
 tCons = CCH43c()
 tCons.ePopen("echo", boundFunction(FFdNiH, callBackFunction))
def FFdNiH(callBackFunction, result, retval):
 callBackFunction()
def FFa70X(SELF, fnc, title="Processing ...", clearMsg=True):
 FFU79C(SELF, title)
 tCons = CCH43c()
 tCons.ePopen("echo", boundFunction(FFH8nf, SELF, fnc, clearMsg))
def FFH8nf(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFU79C(SELF)
def FFs0FM(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVyxHj
  else       : return ""
def FF0s0U(cmd):
 txt = FFs0FM(cmd)
 if txt:
  txt.strip()
  if "\n" in txt:
   txt = txt.splitlines()
   return list(map(str.strip, txt))
  else:
   return [txt]
 else:
  return []
def FF5sfh(cmd):
 lines = FF0s0U(cmd)
 if lines: return lines[0]
 else : return ""
def FFsFyL(SELF, cmd):
 lines = FF0s0U(cmd)
 VV2XDg = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VV2XDg.append((key, val))
  elif line:
   VV2XDg.append((line, ""))
 if VV2XDg:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFsX1L(SELF, None, header=header, VVbKpp=VV2XDg, VVRSoy=widths, VVA2Pa=28)
 else:
  FFTM8D(SELF, cmd)
def FFTM8D(    SELF, cmd, **kwargs): SELF.session.open(CChvFG, VVLuAj=cmd, VVLBhN=True, VVbIQl=VVmdF8, **kwargs)
def FFphhB(  SELF, cmd, **kwargs): SELF.session.open(CChvFG, VVLuAj=cmd, **kwargs)
def FFj8K7(   SELF, cmd, **kwargs): SELF.session.open(CChvFG, VVLuAj=cmd, VVewp5=True, VViwBT=True, VVbIQl=VVmdF8, **kwargs)
def FF06MI(  SELF, cmd, **kwargs): SELF.session.open(CChvFG, VVLuAj=cmd, VVewp5=True, VViwBT=True, VVbIQl=VV1GDe, **kwargs)
def FFgQDF(  SELF, cmd, **kwargs): SELF.session.open(CChvFG, VVLuAj=cmd, VVPUvL=True , **kwargs)
def FFDyFw( SELF, cmd, **kwargs): SELF.session.open(CChvFG, VVLuAj=cmd, VVW7dW=True   , **kwargs)
def FFiNdd( SELF, cmd, **kwargs): SELF.session.open(CChvFG, VVLuAj=cmd, VVvaay=True  , **kwargs)
def FFoKN8(cmd):
 return cmd + " > /dev/null 2>&1"
def FFG7qD():
 return " > /dev/null 2>&1"
def FFZYBr(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFl0r9(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFKtW2():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FF5sfh(cmd)
VVmPX5     = 0
VVcFlp      = 1
VVHzCw   = 2
VVhYlS      = 3
VVJmdL      = 4
VVlwFj     = 5
VV5AxC     = 6
VVOhTz  = 7
VVkdhs = 8
VVHV5w  = 9
VVZ6uP     = 10
VVYVJg  = 11
VVbYh9  = 12
def FFSOBZ(parmNum, grepTxt):
 if   parmNum == VVmPX5  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVcFlp   : param = ["list"   , "apt list" ]
 elif parmNum == VVHzCw: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFKtW2()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFS262(parmNum, package):
 if   parmNum == VVhYlS      : param = ["info"      , "apt show"         ]
 elif parmNum == VVJmdL      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVlwFj     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VV5AxC     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVOhTz  : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVkdhs : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVHV5w  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVZ6uP     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVYVJg  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVbYh9  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFKtW2()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFO6jP():
 result = FF5sfh("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFS262(VV5AxC , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFoKN8("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFoKN8("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFdpXa(failed1, VVX3gJ))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFdpXa(failed2, VVX3gJ))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFdpXa(failed3, VVNRjX))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFwBeJ(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFS262(VV5AxC , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFoKN8("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFdpXa(failed1, VVX3gJ))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFdpXa(failed2, VVNRjX))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFCaZL(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFoKN8('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFoKN8("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFaq7Y(path, maxSize=-1):
 from io import open as ioOpen
 encodings = (None, "utf-8", "ISO8859-15", 'iso6937', "windows-1250", "windows-1252")
 txt = ""
 for enc in encodings:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFn8wV(path, keepends=False, maxSize=-1):
 lines = FFaq7Y(path, maxSize)
 return lines.splitlines(keepends)
def FFrFsL(SELF, path):
 title = os.path.basename(path)
 if fileExists(path):
  fSize = os.path.getsize(path)
  maxSize = 60000
  if (fSize > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFn8wV(path, maxSize=maxSize)
  if lines: FFMt3I(SELF, lines, title=title, VVbIQl=VVmdF8)
  else : FF2TvG(SELF, path, title=title)
 else:
  FFI53L(SELF, path, title)
def FFQsDF(SELF, path, title):
 if fileExists(path):
  txt = FFaq7Y(path)
  txt = txt.replace("#W#", VVaDNx)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVea45)
  txt = txt.replace("#C#", VVVJBw)
  txt = txt.replace("#P#", VVBEBZ)
  FFMt3I(SELF, txt, title=title)
 else:
  FFI53L(SELF, path, title)
def FF7j7O(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFotAE(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFAYBC(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFgbrL(parent)
 else    : return FFO8pH(parent)
def FFM3im(path):
 try:
  return os.path.getsize(path)
 except:
  return 0
def FFgbrL(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFO8pH(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFGV6k():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVloRZ)
 paths.append(VVloRZ.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFotAE(ba)
 for p in list:
  p = ba + p + VVloRZ
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVpGPW, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVloRZ, VVpGPW , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVUFKh, VVfmTj = FFGV6k()
def FFwg59():
 def VVhWqc(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 iPath = CFG.iptvHostsPath.getValue()
 if not iPath == VV8e5A and not pathExists(iPath):
  CFG.iptvHostsPath.setValue(VV8e5A)
  CFG.iptvHostsPath.save()
  oldIptvHostsPath = VV8e5A
 else:
  oldIptvHostsPath = ""
 VVYulR  = VVhWqc(CFG.backupPath, CC2L3a.VVklML())
 VVKmhy  = VVhWqc(CFG.downloadedPackagesPath, t)
 VVY9Si = VVhWqc(CFG.exportedTablesPath, t)
 VVrEgw = VVhWqc(CFG.exportedPIconsPath, t)
 VVtzCW  = VVhWqc(CFG.packageOutputPath, t)
 global VVbxzm
 VVbxzm = FFgbrL(CFG.backupPath.getValue())
 if VVYulR or VVtzCW or VVKmhy or VVY9Si or VVrEgw or oldIptvHostsPath:
  configfile.save()
 return VVYulR, VVtzCW, VVKmhy, VVY9Si, VVrEgw, oldIptvHostsPath
def FFftbc(path):
 path = FFO8pH(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFmbYL(SELF, pathList, tarFileName, addTimeStamp=True):
 VVbKpp = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVbKpp.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVbKpp.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVbKpp.append(path)
 if not VVbKpp:
  FFGr6w(SELF, "Files not found!")
 elif not pathExists(VVbxzm):
  FFGr6w(SELF, "Path not found!\n\n%s" % VVbxzm)
 else:
  VVZEpm = FFgbrL(VVbxzm)
  tarFileName = "%s%s" % (VVZEpm, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FF9n2A())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVbKpp:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVlWOd
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFdpXa(tarFileName, VVI0dy))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFdpXa(failed, VVI0dy))
  cmd += "fi;"
  cmd +=  sep
  FFphhB(SELF, cmd)
def FFqxjD(SELF, title, VV2FNE):
 SELF.session.open(boundFunction(CCvj1b, Title=title, VV2FNE=VV2FNE))
def FF7cim(labelObj, VV2FNE):
 if VV2FNE and fileExists(VV2FNE):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VVmX8Q(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VVmX8Q)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VV2FNE)
   return True
  except:
   pass
 return False
def FFGZ1p(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFARfj(satNum)
  return satName
def FFARfj(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFc8Er(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFGZ1p(val)
  else  : sat = FFARfj(val)
 return sat
def FFR1o4(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFGZ1p(num)
 except:
  pass
 return sat
def FF5B49(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFQzn1(SELF, isFromSession=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFN7dA(info, iServiceInformation.sServiceref)
   prov = FFN7dA(info, iServiceInformation.sProvider)
   state = str(FFN7dA(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFba7t(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFn6Kh(refCode)
 return info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFN7dA(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFQ7UT(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFYDAT(refCode):
 info = FFZIrl(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFyYGT(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFt9Zq(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFZIrl(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VV7FV8 = eServiceCenter.getInstance()
  if VV7FV8:
   info = VV7FV8.info(service)
 return info
def FFsOcb(SELF, refCode, VVuw4l=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  FFLcdV(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVuw4l:
   FFT4Q8(SELF, isFromSession)
 try:
  VVsMMP = InfoBar.instance
  if VVsMMP:
   VVWPt4 = VVsMMP.servicelist
   if VVWPt4:
    servRef = eServiceReference(refCode)
    VVWPt4.saveChannel(servRef)
 except:
  pass
def FFLcdV(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCigLq()
    if pr.VVxwrt(refCode, chName, decodedUrl, iptvRef):
     pr.VVHD1k(SELF, isFromSession)
def FFba7t(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFn6Kh(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FF5GG1(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFFX33(userBfile):
 txt = ""
 bFile = VVeRDn + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVeRDn + userBfile):
  fTxt = FFaq7Y(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FF5sfh('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
 return
def FF5GG1(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FFJxD2(url):
 if iQuote : return iQuote(url)
 else  : return url
def FF75Lb(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFUzJZ(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFlcZz(txt):
 try:
  return FF75Lb(FFUzJZ(txt)) == txt
 except:
  return False
def FFT4Q8(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(SELF, isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CChh4T, isFromExternal=isFromSession)
 else      : FFbXOA(session, reopen=True)
def FFbXOA(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFbXOA, session), CC8Kri)
  except:
   try:
    FFDSsE(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFDKXp(refCode):
 tp = CCloky()
 if tp.VV68Qb(refCode) : return True
 else        : return False
def FFn2dx(refCode, isHide):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFjOTm():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FF09hW():
 VVsMMP = InfoBar.instance
 if VVsMMP:
  VVWPt4 = VVsMMP.servicelist
  if VVWPt4:
   return VVWPt4.getBouquetList()
 return None
def FF3srY():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFsqsH():
 path = FF3srY()
 if path:
  txt = FFaq7Y(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFxolG():
 return FFoqwI(InfoBar.instance.servicelist.getRoot())
def FFoqwI(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VV7FV8 = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VV7FV8.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FFmDkq():
 VVbZDd = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVsekx = list(VVbZDd)
 return VVsekx, VVbZDd
def FFLC0G():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FF2meU(session, VVlc8J):
 VVhxnN, VVYNVc, VVYKjB, camCommand = FF9EtO()
 if VVYNVc:
  runLog = False
  if   VVlc8J == CCDWkt.VVErw3 : runLog = True
  elif VVlc8J == CCDWkt.VVkjJm : runLog = True
  elif not VVYKjB          : FFDSsE(session, message="SoftCam not started yet!")
  elif fileExists(VVYKjB)        : runLog = True
  else             : FFDSsE(session, message="File not found !\n\n%s" % VVYKjB)
  if runLog:
   session.open(boundFunction(CCDWkt, VVhxnN=VVhxnN, VVYNVc=VVYNVc, VVYKjB=VVYKjB, VVlc8J=VVlc8J))
 else:
  FFDSsE(session, message="No active OSCam/NCam found !", title="Live Log")
def FF9EtO():
 VVhxnN = "/etc/tuxbox/config/"
 VVYNVc = None
 VVYKjB  = None
 camCommand = FF5sfh("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVYNVc = "oscam"
 elif "ncam"  in camCommand : VVYNVc = "ncam"
 if VVYNVc:
  path = FF5sfh(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFgbrL(path)
  if pathExists(path):
   VVhxnN = path
  tFile = VVhxnN + VVYNVc + ".conf"
  tFile = FF5sfh("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVYKjB = tFile
 return VVhxnN, VVYNVc, VVYKjB, camCommand
def FF5Ufp(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFRsTW():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FF9n2A():
 return FFRsTW().replace(" ", "_").replace("-", "").replace(":", "")
def FFRq1D(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFf7s4():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFEUjD(url, outFile, timeout=3):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCjXCp.VVcHfY(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCjXCp.VVGerw(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFoKN8("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFsiza(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFcGmm(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFtKys():
 return int(FFs0FM("cat /proc/meminfo | grep MemFree | awk '{print $2}'"))
def FFGHWJ():
 global VVeFzk_TIME, VVF7WX
 VVF7WX  = int(FFtKys())
 VVeFzk_TIME = iTime()
def FFzqlV():
 elapsed = iTime() - VVeFzk_TIME
 elapsed = "{:.6f}".format(elapsed).rstrip("0").rstrip(".")
 mem  = FFtKys() - VVF7WX
 FFVMMr(">>>>>> Elapsed\t: {} seconds ... Memory\t: {} bytes".format(elapsed, mem))
def FF6zpT(SELF, message, title=""):
 SELF.session.open(boundFunction(CCyhl9, title=title, message=message, VV5ijV=True))
def FFMt3I(SELF, message, title="", VVbIQl=VVmdF8, **kwargs):
 SELF.session.open(boundFunction(CCyhl9, title=title, message=message, VVbIQl=VVbIQl, **kwargs))
def FFGr6w(SELF, message, title="")  : FFDSsE(SELF.session, message, title)
def FFI53L(SELF, path, title="") : FFDSsE(SELF.session, "File not found !\n\n%s" % path, title)
def FF2TvG(SELF, path, title="") : FFDSsE(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFQ7SS(SELF, title="")  : FFDSsE(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFDSsE(session, message, title="") : session.open(boundFunction(CCPu5L, title=title, message=message))
def FFK1qA(SELF, VV6vg0, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VV6vg0, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VV6vg0, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VV6vg0, boundFunction(CCwgCJ, title=title, message=message, VVb9jI=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFGr6w(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFIxs9(SELF, callBack_Yes, VVadeJ, callBack_No=None, title="", VVuXa8=False, VViYBh=True):
 SELF.session.openWithCallback(boundFunction(FFfkVU, callBack_Yes, callBack_No)
        , boundFunction(CCrHv1, title=title, VVadeJ=VVadeJ, VViYBh=VViYBh, VVuXa8=VVuXa8))
def FFfkVU(callBack_Yes, callBack_No, FFIxs9ed):
 if FFIxs9ed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFU79C(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFpRmN(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFQObc(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFpJmc(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVhInX = eTimer()
def FFQObc(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFFkzg, SELF))
 fnc = boundFunction(FFFkzg, SELF)
 try:
  t = VVhInX.timeout.connect(fnc)
 except:
  VVhInX.callback.append(fnc)
 VVhInX.start(milliSeconds, 1)
def FFFkzg(SELF):
 VVhInX.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFsX1L(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCdzzH, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCdzzH, **kwargs))
  FFeXHw(win)
  return win
 except:
  return None
def FFsmMG(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCKusJ, **kwargs))
 FFeXHw(win)
 return win
def FFASWh(SELF, **kwargs):
 SELF.session.open(CCAHNs, **kwargs)
def FFFOZ8(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   obj = SELF[name]
   SELF[name].instance.setBorderColor(parseColor("#000000"))
   SELF[name].instance.setBorderWidth(3)
   SELF[name].instance.setNoWrap(True)
  except:
   pass
def FFxJLq(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVbhwc, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFwO6z(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFxJLq(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFfmL1():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FF5ZEu(VVA2Pa):
 screenSize  = FFfmL1()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVA2Pa)
 return bodyFontSize
def FFl95Q(VVA2Pa, extraSpace):
 font = gFont(VVbhwc, VVA2Pa)
 VVCg7w = fontRenderClass.getInstance().getLineHeight(font) or (VVA2Pa * 1.25)
 return int(VVCg7w + VVCg7w * extraSpace)
def FFLMLT(fontName):
 fList = None
 try:
  from enigma import getFontFaces
  fList = getFontFaces()
 except:
  try:
   from skin import getFontFaces
   fList = getFontFaces()
  except:
   pass
 if fList and fontName in fList : return fontName
 else       : return VVbhwc
def FFFsgK(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFfmL1()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * VVxwOa)
 bodyFontStr  = 'font="%s;%d"' % (VVbhwc, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFl95Q(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVbhwc, titleFontSize, alignLeftCenter)
 if winType == VVQV0S or winType == VVkgSN:
  if winType == VVkgSN : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVnHE9:
  pass
 elif winType == VVvgu9:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FF6zpTL = b2Left2 + timeW + marginLeft
  FF6zpTW = b2Left3 - marginLeft - FF6zpTL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FF6zpTL  , b2Top, FF6zpTW , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00aa7777", "#00aa7777", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
 elif winType == VVxDcM:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VV4Jy1:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVI3cc:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVGF95:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVbhwc, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVbhwc, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVn45i:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FF6zpTH = int(bodyH * 0.5)
  inpTop = bodyTop + FF6zpTH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FF6zpTH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVbhwc, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVbhwc, mapF, alignCenter)
 elif winType == VVjyaz:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVjLx4:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVbhwc, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVIRaO:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVbhwc, fontH, alignCenter)
 elif winType == VVqLiq:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVbhwc, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVbhwc, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVbhwc, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVFsTR:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 else:
  if   winType == VVFncf : align = alignLeftCenter
  elif winType == VVwgeJ : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVfgzn:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VVmgsS:
   moreParams = ""
  else:
   fontStr = bodyFontStr
   if usefixedFont and winType == VVwgeJ:
    fontStr = 'font="%s;%d"' % (FFLMLT("Fixed"), bodyFontSize)
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" %s %s ' % (bodyColor, fontStr, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVA2Pa = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVbhwc, VVA2Pa, alignCenter)
 if topRightBtns > 0:
  btnW = int(ratioW * 80)
  btnH = int(titleH * 0.7)
  btnTop = int(titleH * 0.15)
  btnLeft = width - (btnW + btnTop)
  btnFont = int(btnH * 0.6)
  tmp += '<widget name="keyMenu2F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
  tmp += '<widget name="keyMenu2"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VVbhwc, btnFont, alignCenter)
  if topRightBtns > 1:
   btnLeft = btnLeft - btnW - 8
   tmp += '<widget name="keyMenu1F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="keyMenu1"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VVbhwc, btnFont, alignCenter)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVPOXl = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVbhwc, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVPOXl[i], VVbhwc, barFont, alignCenter)
   left += btnW + gap
 if winType == VVwgeJ:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVPOXl = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVPOXl[i], VVbhwc, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFFsgK(VVQV0S, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.hiddenMenuPass = ""
  self.themsList  = []
  VVwdxM = []
  if VVEog1:
   VVwdxM.append(("-- MY TEST --"    , "myTest"   ))
  VVwdxM.append(("  File Manager"     , "FileManager"  ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("  Services/Channels"    , "ChannelsTools" ))
  VVwdxM.append(("  IPTV"       , "IptvTools"  ))
  VVwdxM.append(("  PIcons"       , "PIconsTools"  ))
  VVwdxM.append(("  SoftCam"      , "SoftCam"   ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("  Plugins"      , "PluginsTools" ))
  VVwdxM.append(("  Terminal"      , "Terminal"  ))
  VVwdxM.append(("  Backup & Restore"    , "BackupRestore" ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("  Date/Time"      , "Date_Time"  ))
  VVwdxM.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVwdxM)
  FFKXoA(self, VVwdxM=VVwdxM)
  FFhu6U(self["keyRed"] , "Exit")
  FFhu6U(self["keyGreen"] , "Settings")
  FFhu6U(self["keyYellow"], "Dev. Info.")
  FFhu6U(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVuLWn       ,
   "yellow"  : self.VV22Qr       ,
   "blue"   : self.VV1Q6J       ,
   "info"   : self.VV1Q6J       ,
   "last"   : self.VVOahW      ,
   "next"   : self.VVXai1       ,
   "menu"   : self.VVzIFz     ,
   "0"    : boundFunction(self.VV42q4, 0) ,
   "1"    : boundFunction(self.VVp9Al, 1)   ,
   "2"    : boundFunction(self.VVp9Al, 2)   ,
   "3"    : boundFunction(self.VVp9Al, 3)   ,
   "4"    : boundFunction(self.VVp9Al, 4)   ,
   "5"    : boundFunction(self.VVp9Al, 5)   ,
   "6"    : boundFunction(self.VVp9Al, 6)   ,
   "7"    : boundFunction(self.VVp9Al, 7)   ,
   "8"    : boundFunction(self.VVp9Al, 8)   ,
   "9"    : boundFunction(self.VVp9Al, 9)
  })
  self.onShown.append(self.VVa2bU)
  self.onClose.append(self.onExit)
  global VVvPtm, VVhg3T
  VVvPtm = VVhg3T = False
 def VVPtX0(self):
  item = FFY2w4(self)
  self.VVp9Al(item)
 def VVp9Al(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVlITt()
   elif item in ("FileManager"  , 1) : self.session.open(CCvQ2O)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCVPCx)
   elif item in ("IptvTools"  , 3) : self.session.open(CCjXCp)
   elif item in ("PIconsTools"  , 4) : self.VV446k()
   elif item in ("SoftCam"   , 5) : self.session.open(CCN3sb)
   elif item in ("PluginsTools" , 6) : self.session.open(CC5299)
   elif item in ("Terminal"  , 7) : self.session.open(CCme9s)
   elif item in ("BackupRestore" , 8) : self.session.open(CC7JSO)
   elif item in ("Date_Time"  , 9) : self.session.open(CCIB92)
   elif item in ("CheckInternet" , 10) : self.session.open(CCSyxm)
   else         : self.close()
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  FFfopI(self["myMenu"])
  FFwO6z(self)
  FFFOZ8(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVyy0v)
  self["myTitle"].setText(title)
  VVYulR, VVtzCW, VVKmhy, VVY9Si, VVrEgw, oldIptvHostsPath = FFwg59()
  self.VVJoP5()
  if VVYulR or VVtzCW or VVKmhy or VVY9Si or VVrEgw or oldIptvHostsPath:
   VVLQyb = lambda path, subj: "%s:\n%s\n\n" % (subj, FFY8RM(path, VVNRjX)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVLQyb(oldIptvHostsPath  , "IPTV Hosts Files Path"   )
   txt += VVLQyb(VVYulR   , "Backup/Restore Path"    )
   txt += VVLQyb(VVtzCW  , "Created Package Files (IPK/DEB)" )
   txt += VVLQyb(VVKmhy  , "Download Packages (from feeds)" )
   txt += VVLQyb(VVY9Si , "Exported Tables"     )
   txt += VVLQyb(VVrEgw , "Exported PIcons"     )
   txt += "\nYou can change paths from Settings.\n"
   FFMt3I(self, txt, title="Settings Paths")
  if (EASY_MODE or VVLWxX or VVEog1):
   FFpRmN(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFU79C(self, "Welcome", 300)
  FFZQW5(boundFunction(self.VVRsBG, title))
 def VVRsBG(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CC2L3a.VVkXol()
   if url:
    newWebVer = CC2L3a.VVtevy(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFoKN8("rm /tmp/ajpanel*"))
  global VVvPtm, VVhg3T
  VVvPtm = VVhg3T = False
 def VV42q4(self, digit):
  self.hiddenMenuPass += str(digit)
  ln = len(self.hiddenMenuPass)
  global VVvPtm, VVAkV7
  if ln == 4:
   if self.hiddenMenuPass == "0" * ln:
    VVvPtm = True
    FFpRmN(self["myTitle"], "#800080")
   else:
    self.hiddenMenuPass = "x"
  elif self.hiddenMenuPass == "0" * ln:
   VVAkV7 = True
 def VVXai1(self):
  self.hiddenMenuPass += ">"
  if self.hiddenMenuPass == "0" * 4 + ">" * 2:
   global VVhg3T
   VVhg3T = True
   FFpRmN(self["myTitle"], "#dd5588")
 def VVOahW(self):
  self.hiddenMenuPass += "<"
  if self.hiddenMenuPass == "0" * 4 + "<" * 2:
   ok = False
   fnt = "ae_AlMateen.ttf"
   fontFile = "/usr/share/fonts/%s" % fnt
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    try:
     addFont(fontFile, fontName, 100, True)
     ok = True
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      ok = True
     except:
      pass
   if ok: txt = 'Added Font: "%s"' % fnt
   else : txt = '"%s" Not Found' % fnt
   FFU79C(self, txt, 2000, isGrn=ok)
 def VV446k(self):
  found = False
  pPath = CClRyV.VVvvid()
  if pathExists(pPath):
   for fName, fType in CClRyV.VVhEf2(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CClRyV)
  else:
   VVwdxM = []
   VVwdxM.append(("PIcons Manager" , "CClRyV" ))
   VVwdxM.append(VVWygA)
   VVwdxM.append(CClRyV.VVU2ko())
   VVwdxM.append(VVWygA)
   VVwdxM += CClRyV.VVDdOe()
   FFsmMG(self, self.VVnOg4, VVwdxM=VVwdxM)
 def VVnOg4(self, item=None):
  if item:
   if   item == "CClRyV"   : self.session.open(CClRyV)
   elif item == "VVNdV5"  : CClRyV.VVNdV5(self)
   elif item == "VVbJBe"  : CClRyV.VVbJBe(self)
   elif item == "findPiconBrokenSymLinks" : CClRyV.VVf2R3(self, True)
   elif item == "FindAllBrokenSymLinks" : CClRyV.VVf2R3(self, False)
 def VVuLWn(self):
  self.session.open(CC2L3a)
 def VV22Qr(self):
  self.session.open(CCVijD)
 def VV1Q6J(self):
  changeLogFile = VVfmTj + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FFn8wV(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFY8RM("\n%s\n%s\n%s" % (VVlWOd, line, VVlWOd), VVBEBZ, VVaDNx)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FFY8RM(line, VVea45, VVaDNx)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFMt3I(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVyy0v), VVA2Pa=26)
 def VVzIFz(self):
  VVwdxM = []
  VVwdxM.append(("Title Colors"   , "title" ))
  VVwdxM.append(("Menu Area Colors"  , "body" ))
  VVwdxM.append(("Menu Pointer Colors" , "cursor" ))
  VVwdxM.append(("Bottom Bar Colors" , "bar"  ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Reset"    , "reset" ))
  FFsmMG(self, self.VV5nA1, VVwdxM=VVwdxM, width=500, title="Main Menu Colors")
 def VV5nA1(self, item=None):
  if item:
   if item == "reset":
    os.system(FFoKN8("rm %s" % self.VVXLds()))
    self.close()
   else:
    tDict = self.VVEBD0()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VV4QwQ, tDict, item), CCqlZz, defFG=fg, defBG=bg)
 def VVXLds(self):
  return VVbxzm + "ajpanel_colors"
 def VVEBD0(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVXLds()
  if fileExists(p):
   txt = FFaq7Y(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VV4QwQ(self, tDict, item, fg, bg):
  if fg:
   self.VVgzaZ(item, fg)
   self.VV6EfU(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVhmr4(tDict)
 def VVhmr4(self, tDict):
   p = self.VVXLds()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVgzaZ(self, item, fg):
  if   item == "title" : FF1NxI(self["myTitle"], fg)
  elif item == "body"  :
   FF1NxI(self["myMenu"], fg)
   FF1NxI(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFpRmN(self["myBar"], fg)
   FF1NxI(self["keyRed"], fg)
   FF1NxI(self["keyGreen"], fg)
   FF1NxI(self["keyYellow"], fg)
   FF1NxI(self["keyBlue"], fg)
 def VV6EfU(self, item, bg):
  if   item == "title" : FFpRmN(self["myTitle"], bg)
  elif item == "body"  :
   FFpRmN(self["myMenu"], bg)
   FFpRmN(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFpRmN(self["myBar"], bg)
 def VVJoP5(self):
  tDict = self.VVEBD0()
  self.VVBBNK(tDict, "title")
  self.VVBBNK(tDict, "body")
  self.VVBBNK(tDict, "cursor")
  self.VVBBNK(tDict, "bar")
 def VVBBNK(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVgzaZ(name, fg)
  if bg: self.VV6EfU(name, bg)
 def VVlITt(self):
  pass
class CCVijD(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFFsgK(VVQV0S, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVwdxM = []
  VVwdxM.append(("Settings File"        , "SettingsFile"   ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Box Info"          , "VVk7Hr"    ))
  VVwdxM.append(("Tuners Info"         , "VV90BW"   ))
  VVwdxM.append(("Python Version"        , "VVcv1v"   ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Screen Size"         , "ScreenSize"    ))
  VVwdxM.append(("Locale"          , "Locale"     ))
  VVwdxM.append(("Processor"         , "Processor"    ))
  VVwdxM.append(("Operating System"        , "OperatingSystem"   ))
  VVwdxM.append(("Drivers"          , "drivers"     ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("System Users"         , "SystemUsers"    ))
  VVwdxM.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVwdxM.append(("Uptime"          , "Uptime"     ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Host Name"         , "HostName"    ))
  VVwdxM.append(("MAC Address"         , "MACAddress"    ))
  VVwdxM.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVwdxM.append(("Network Status"        , "NetworkStatus"   ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Disk Usage"         , "VV6DD7"    ))
  VVwdxM.append(("Mount Points"         , "MountPoints"    ))
  VVwdxM.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVwdxM.append(("USB Devices"         , "USB_Devices"    ))
  VVwdxM.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVwdxM.append(("Directory Size"        , "DirectorySize"   ))
  VVwdxM.append(("Memory"          , "Memory"     ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVwdxM.append(("Running Processes"       , "RunningProcesses"  ))
  VVwdxM.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFKXoA(self, VVwdxM=VVwdxM, title="Device Information")
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  FFfopI(self["myMenu"])
  FFwO6z(self)
 def VVPtX0(self):
  global VVEipR
  VVEipR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CC3FBK)
   elif item == "VVk7Hr"    : self.VVk7Hr()
   elif item == "VV90BW"   : self.VV90BW()
   elif item == "VVcv1v"   : self.VVcv1v()
   elif item == "ScreenSize"    : FFMt3I(self, "Width\t: %s\nHeight\t: %s" % (FFfmL1()[0], FFfmL1()[1]))
   elif item == "Locale"     : self.VV5K5H()
   elif item == "Processor"    : self.VVeY7h()
   elif item == "OperatingSystem"   : FFTM8D(self, "uname -a"        )
   elif item == "drivers"     : self.VVgRC5()
   elif item == "SystemUsers"    : FFTM8D(self, "id"          )
   elif item == "LoggedInUsers"   : FFTM8D(self, "who -a"         )
   elif item == "Uptime"     : FFTM8D(self, "uptime"         )
   elif item == "HostName"     : FFTM8D(self, "hostname"        )
   elif item == "MACAddress"    : self.VVgluS()
   elif item == "NetworkConfiguration"  : FFTM8D(self, "ifconfig %s %s" % (FFdpXa("HWaddr", VVVqHz), FFdpXa("addr:", VVX3gJ)))
   elif item == "NetworkStatus"   : FFTM8D(self, "netstat -tulpn"       )
   elif item == "VV6DD7"    : self.VV6DD7()
   elif item == "MountPoints"    : FFTM8D(self, "mount %s" % (FFdpXa(" on ", VVX3gJ)))
   elif item == "FileSystemTable"   : FFTM8D(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFTM8D(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFTM8D(self, "blkid"         )
   elif item == "DirectorySize"   : FFTM8D(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVpqzv="Reading size ...")
   elif item == "Memory"     : FFTM8D(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVvi4m()
   elif item == "RunningProcesses"   : FFTM8D(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFTM8D(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVraaL()
   else         : self.close()
 def VVgluS(self):
  res = FFs0FM("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFMt3I(self, txt)
  else:
   FFTM8D(self, "ip link")
 def VVuIDU(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FF0s0U(cmd)
  return lines
 def VVMsBM(self, lines, headerRepl, widths, VVxqTz):
  VV2XDg = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VV2XDg.append(parts)
  if VV2XDg and len(header) == len(widths):
   VV2XDg.sort(key=lambda x: x[0].lower())
   FFsX1L(self, None, header=header, VVbKpp=VV2XDg, VVxqTz=VVxqTz, VVRSoy=widths, VVA2Pa=28, VVKqJC=True)
   return True
  else:
   return False
 def VV6DD7(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VVuIDU(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVxqTz = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVMsBM(lines, headerRepl, widths, VVxqTz)
  if not allOK:
   lines = FF0s0U(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFO8pH(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVI0dy:
     note = "\n%s" % FFY8RM("Green = Mounted Partitions", VVI0dy)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVX3gJ
     elif line.endswith(mountList) : color = VVI0dy
     else       : color = VVea45
     txt += FFY8RM(line, color) + "\n"
    FFMt3I(self, txt + note)
   else:
    FFGr6w(self, "Not data from system !")
 def VVvi4m(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVuIDU(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVxqTz = (LEFT , CENTER, LEFT )
  allOK = self.VVMsBM(lines, headerRepl, widths, VVxqTz)
  if not allOK:
   FFTM8D(self, cmd)
 def VV5K5H(self):
  from locale import getdefaultlocale
  loc = getdefaultlocale()
  FFMt3I(self, "Language\t: %s\nEncoding\t: %s" % (loc[0], loc[1]))
 def VVgRC5(self):
  cmd = FFSOBZ(VVHzCw, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFTM8D(self, cmd)
  else : FFQ7SS(self)
 def VVeY7h(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFTM8D(self, cmd)
 def VVraaL(self):
  cmd = FFSOBZ(VVcFlp, "| grep secondstage")
  if cmd : FFTM8D(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFQ7SS(self)
 def VVk7Hr(self):
  c = VVI0dy
  VVbKpp = []
  VVbKpp.append((FFY8RM("Box Type"  , c), FFY8RM(self.VVcvqW("boxtype").upper(), c)))
  VVbKpp.append((FFY8RM("Board Version", c), FFY8RM(self.VVcvqW("board_revision") , c)))
  VVbKpp.append((FFY8RM("Chipset"  , c), FFY8RM(self.VVcvqW("chipset")  , c)))
  VVbKpp.append((FFY8RM("S/N"   , c), FFY8RM(self.VVcvqW("sn")    , c)))
  VVbKpp.append((FFY8RM("Version"  , c), FFY8RM(self.VVcvqW("version")  , c)))
  VV07hm   = []
  VV55VC = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VV55VC = SystemInfo[key]
     else:
      VV07hm.append((FFY8RM(str(key), VVVJBw), FFY8RM(str(SystemInfo[key]), VVVJBw)))
  except:
   pass
  if VV55VC:
   VV0JEj = self.VVGrEi(VV55VC)
   if VV0JEj:
    VV0JEj.sort(key=lambda x: x[0].lower())
    VVbKpp += VV0JEj
  if VV07hm:
   VV07hm.sort(key=lambda x: x[0].lower())
   VVbKpp += VV07hm
  if VVbKpp:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFsX1L(self, None, header=header, VVbKpp=VVbKpp, VVRSoy=widths, VVA2Pa=28, VVKqJC=True)
  else:
   FFMt3I(self, "Could not read info!")
 def VVcvqW(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFn8wV(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVGrEi(self, mbDict):
  try:
   mbList = list(mbDict)
   VVbKpp = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVbKpp.append((FFY8RM(subject, VVX3gJ), FFY8RM(value, VVX3gJ)))
  except:
   pass
  return VVbKpp
 def VV90BW(self):
  txt = self.VVRBj0("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVRBj0("/proc/bus/nim_sockets")
  if not txt: txt = self.VVS0vr()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFMt3I(self, txt)
 def VVS0vr(self):
  txt = ""
  VVLQyb = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVLQyb("Slot Name" , slot.getSlotName())
     txt += FFY8RM(slotName, VVX3gJ)
     txt += VVLQyb("Description"  , slot.getFullDescription())
     txt += VVLQyb("Frontend ID"  , slot.frontend_id)
     txt += VVLQyb("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVRBj0(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFn8wV(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFY8RM(line, VVX3gJ)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVcv1v(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFMt3I(self, txt)
class CC3FBK(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFFsgK(VVQV0S, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVwdxM = []
  VVwdxM.append(("Settings (All)"   , "Settings_All"   ))
  VVwdxM.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVwdxM.append(("Settings (FHDG-17)"  , "Settings_FHDG_17"  ))
  VVwdxM.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVwdxM.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVwdxM.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVwdxM.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVwdxM.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFKXoA(self, VVwdxM=VVwdxM)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  FFfopI(self["myMenu"])
  FFwO6z(self)
 def VVPtX0(self):
  global VVEipR
  VVEipR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFTM8D(self, cmd                )
   elif item == "Settings_HotKeys"   : FFTM8D(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFTM8D(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFTM8D(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFTM8D(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFTM8D(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFTM8D(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFTM8D(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCN3sb(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFFsgK(VVQV0S, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVhxnN, VVYNVc, VVYKjB, camCommand = FF9EtO()
  self.VVYNVc = VVYNVc
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVwdxM = []
  VVwdxM.append(("OSCam Files"        , "OSCamFiles"  ))
  VVwdxM.append(("NCam Files"        , "NCamFiles"  ))
  VVwdxM.append(("CCcam Files"        , "CCcamFiles"  ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVwdxM.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVwdxM.append(VVWygA)
  if VVYNVc:
   if   "oscam" in VVYNVc : camName = "OSCam"
   elif "ncam"  in VVYNVc : camName = "NCam"
   VVwdxM.append((camName + " Info."      , "camInfo"   ))
   VVwdxM.append((camName + " Live Status"    , "camLiveStatus" ))
   VVwdxM.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVwdxM.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVwdxM.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFKXoA(self, VVwdxM=VVwdxM)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  FFfopI(self["myMenu"])
  FFwO6z(self)
 def VVPtX0(self):
  global VVEipR
  VVEipR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCLgl4, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCLgl4, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCLgl4, "cccam"))
   elif item == "OSCamReaders"  : self.VV7GzJ("os")
   elif item == "NSCamReaders"  : self.VV7GzJ("n")
   elif item == "camInfo"   : FFsFyL(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FF2meU(self.session, CCDWkt.VVErw3)
   elif item == "camLiveReaders" : FF2meU(self.session, CCDWkt.VVkjJm)
   elif item == "camLiveLog"  : FF2meU(self.session, CCDWkt.VVdHzv)
   else       : self.close()
 def VV7GzJ(self, camPrefix):
  VV2XDg = self.VVnu5J(camPrefix)
  if VV2XDg:
   VV2XDg.sort(key=lambda x: int(x[0]))
   if self.VVYNVc and self.VVYNVc.startswith(camPrefix):
    VVcGuB = ("Toggle State", self.VVnNyh, [camPrefix], "Changing State ...")
   else:
    VVcGuB = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVxqTz  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFsX1L(self, None, header=header, VVbKpp=VV2XDg, VVxqTz=VVxqTz, VVRSoy=widths, VVA2Pa=26, VVcGuB=VVcGuB, VVuZx4=True)
 def VVnu5J(self, camPrefix):
  readersFile = self.VVhxnN + camPrefix + "cam.server"
  VV2XDg = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFn8wV(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VV2XDg.append((str(len(VV2XDg) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VV2XDg:
    FFGr6w(self, "No readers found !")
  else:
   FFI53L(self, readersFile)
  return VV2XDg
 def VVnNyh(self, VVL8CA, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVhxnN, camPrefix)
  readerState  = VVL8CA.VVt0P4(1)
  readerLabel  = VVL8CA.VVt0P4(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCN3sb.VVcNBK(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVL8CA.VVXTRT()
    FFGr6w(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VV2XDg = self.VVnu5J(camPrefix)
   if VV2XDg:
    VVL8CA.VVn17k(VV2XDg)
 @staticmethod
 def VVcNBK(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFn8wV(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFGr6w(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFGr6w(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFI53L(SELF, confFile)
   return None
  if not iRequest:
   FFGr6w(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFGr6w(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFGr6w(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCLgl4(Screen):
 def __init__(self, VVMheQ, session, args=0):
  self.skin, self.skinParam = FFFsgK(VVQV0S, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVhxnN, VVYNVc, VVYKjB, camCommand = FF9EtO()
  if   VVMheQ == "ncam" : self.prefix = "n"
  elif VVMheQ == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVwdxM = []
  if self.prefix == "":
   VVwdxM.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVwdxM.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVwdxM.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVwdxM.append(("constant.cw"         , "x_constant_cw" ))
   VVwdxM.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVwdxM.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVwdxM.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVwdxM.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVwdxM.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVwdxM.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVwdxM.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVwdxM.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVwdxM.append(VVWygA)
   VVwdxM.append(("SoftCam.Key"         , "x_SoftCam_Key" ))
   VVwdxM.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVwdxM.append(VVWygA)
   VVwdxM.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVwdxM.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVwdxM.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFKXoA(self, VVwdxM=VVwdxM)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  FFfopI(self["myMenu"])
  FFwO6z(self)
 def VVPtX0(self):
  global VVEipR
  VVEipR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFrFsL(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFrFsL(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFrFsL(self, self.VVhxnN + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFrFsL(self, self.VVhxnN + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVtnsq("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVtnsq("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVtnsq("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVtnsq("cam.provid"        )
   elif item == "x_cam_server"  : self.VVtnsq("cam.server"        )
   elif item == "x_cam_services" : self.VVtnsq("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVtnsq("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVtnsq("cam.user"        )
   elif item == "x_VVlWOd"   : pass
   elif item == "x_SoftCam_Key" : FFrFsL(self, self.VVhxnN + "SoftCam.Key"   )
   elif item == "x_CCcam_cfg"  : FFrFsL(self, self.VVhxnN + "CCcam.cfg"    )
   elif item == "x_VVlWOd"   : pass
   elif item == "x_cam_log"  : FFrFsL(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFrFsL(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFrFsL(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVtnsq(self, fileName):
  FFrFsL(self, self.VVhxnN + self.prefix + fileName)
class CCDWkt(Screen):
 VVErw3  = 0
 VVkjJm = 1
 VVdHzv = 2
 def __init__(self, session, VVhxnN="", VVYNVc="", VVYKjB="", VVlc8J=VVErw3):
  self.skin, self.skinParam = FFFsgK(VVwgeJ, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVYKjB   = VVYKjB
  self.VVlc8J  = VVlc8J
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVhxnN + VVYNVc + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVYNVc : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVhxnN, self.camPrefix)
  if self.VVlc8J == self.VVErw3:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVlc8J == self.VVkjJm:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFKXoA(self, self.Title, addScrollLabel=True)
  FFhu6U(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVS0gp
  self.onShown.append(self.VVa2bU)
  self.onClose.append(self.onExit)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  self["myLabel"].VVA9a4(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFFOZ8(self)
  self.VVS0gp()
 def onExit(self):
  self.timer.stop()
 def VVSzln(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVByuH)
  except:
   self.timer.callback.append(self.VVByuH)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFU79C(self, "Started", 1000)
 def VVmA83(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVByuH)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFU79C(self, "Stopped", 1000)
 def VVS0gp(self):
  if self.timerRunning:
   self.VVmA83()
  else:
   self.VVSzln()
   if self.VVlc8J == self.VVErw3 or self.VVlc8J == self.VVkjJm:
    if self.VVlc8J == self.VVErw3 : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCN3sb.VVcNBK(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFZQW5(self.VVlNMv)
    else:
     self.close()
   else:
    self.VVfMSO()
 def VVByuH(self):
  if self.timerRunning:
   if   self.VVlc8J == self.VVErw3 : self.VVtbMp()
   elif self.VVlc8J == self.VVkjJm : self.VVtbMp()
   else            : self.VVfMSO()
 def VVfMSO(self):
  if fileExists(self.VVYKjB):
   fTime = FF5Ufp(os.path.getmtime(self.VVYKjB))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVRhph(), VVbIQl=VV1GDe)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVYKjB)
 def VVlNMv(self):
  self.VVtbMp()
 def VVtbMp(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFY8RM("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVBEBZ))
   self.camWebIfErrorFound = True
   self.VVmA83()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVlc8J == self.VVErw3 : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFY8RM("Error while parsing data elements !\n\nError = %s" % str(e), VVNRjX)
   self.camWebIfErrorFound = True
   self.VVmA83()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVk2Vd(root)
  self["myLabel"].setText(txt, VVbIQl=VV1GDe)
  self["myBar"].setText("Last Update : %s" % FFRsTW())
 def VVk2Vd(self, rootElement):
  def VVLQyb(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVlc8J == self.VVErw3:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFY8RM(status, VVI0dy)
    else          : status = FFY8RM(status, VVNRjX)
    txt += VVlWOd + "\n"
    txt += VVLQyb("Name"  , name)
    txt += VVLQyb("Description" , desc)
    txt += VVLQyb("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVLQyb("Protocol" , protocol)
    txt += VVLQyb("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFY8RM("Yes", VVI0dy)
    else    : enabTxt = FFY8RM("No", VVNRjX)
    txt += VVlWOd + "\n"
    txt += VVLQyb("Label"  , label)
    txt += VVLQyb("Protocol" , protocol)
    txt += VVLQyb("Enabled" , enabTxt)
  return txt
 def VVRhph(self):
  wordsDict = self.VVpUmP()
  color = [ VVX3gJ, VVVqHz, VVI0dy, VVNRjX, VVVJBw, VVK98e]
  lines = FF0s0U("tail -n %d %s" % (100, self.VVYKjB))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVBEBZ + line[:19] + VVea45 + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVaDNx + line[ndx + 3:] + VVea45
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVX3gJ + line[ndx + 8 : ndx1 + 4] + VVea45 + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVea45)
   elif line.startswith("----") or ">>" in line:
    line = FFY8RM(line, VVX3gJ)
   txt += line + "\n"
  return txt
 def VVpUmP(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFn8wV(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CC7JSO(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFFsgK(VVQV0S, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVwdxM = []
  VVwdxM.append(("Backup Channels"        , "VVVPrz"   ))
  VVwdxM.append(("Restore Channels"        , "Restore_Channels"  ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Backup SoftCAM Files"       , "VVVMXe" ))
  VVwdxM.append(("Restore SoftCAM Files"      , "Restore_SoftCAM_Files" ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Backup Tuner Settings"      , "Backup_TunerDiSEqC"  ))
  VVwdxM.append(("Restore Tuner Settings"      , "Restore_TunerDiSEqC"  ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Backup HotKeys & FHDG17 Settings"    , "Backup_Hotkey_FHDG17" ))
  VVwdxM.append(("Restore HotKeys & FHDG17 Settings"   , "Restore_Hotkey_FHDG17" ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Backup Network Settings"      , "VVV5bc"   ))
  VVwdxM.append(("Restore Network Settings"      , "Restore_Network"   ))
  if VVhg3T:
   VVwdxM.append(VVWygA)
   VVwdxM.append((VVBEBZ + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME , "VVx7t6"   ))
   VVwdxM.append((VVI0dy + "2- Create %s for IPK"   % PLUGIN_NAME , "createMyIpk"   ))
   VVwdxM.append((VVI0dy + "3- Create %s for DEB"   % PLUGIN_NAME , "createMyDeb"   ))
   VVwdxM.append((VVVJBw + "Create %s TAR (Absolute Path)" % PLUGIN_NAME , "createMyTar"   ))
   VVwdxM.append((VVVJBw + "Decode %s Crash Report"   % PLUGIN_NAME , "VV8P52" ))
  FFKXoA(self, VVwdxM=VVwdxM)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  FFfopI(self["myMenu"])
  FFwO6z(self)
 def VVPtX0(self):
  global VVEipR
  VVEipR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVVPrz"    : self.VVVPrz()
   elif item == "Restore_Channels"    : self.VVLRnK("channels_backup*.tar.gz", self.VVOozk)
   elif item == "VVVMXe"   : self.VVVMXe()
   elif item == "Restore_SoftCAM_Files"  : self.VVLRnK("softcam_backup*.tar.gz", self.VVvCmY)
   elif item == "Backup_TunerDiSEqC"   : self.VVCXTM("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVLRnK("tuner_backup*.backup", boundFunction(self.VV0tTo, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVCXTM("hotkey_fhdg17_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVLRnK("hotkey_fhdg17_backup*.backup", boundFunction(self.VV0tTo, "misc"))
   elif item == "VVV5bc"    : self.VVV5bc()
   elif item == "Restore_Network"    : self.VVLRnK("network_backup*.tar.gz", self.VVPm6Z)
   elif item == "VVx7t6"     : FFIxs9(self, boundFunction(FFa70X, self, boundFunction(CC7JSO.VVx7t6, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVjnkh(False)
   elif item == "createMyDeb"     : self.VVjnkh(True)
   elif item == "createMyTar"     : self.VVebTN()
   elif item == "VV8P52"   : self.VV8P52()
 @staticmethod
 def VVx7t6(SELF):
  OBF_Path = VVUFKh + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVUFKh, VVyy0v, VVVFWg)
   if err : FFGr6w(SELF, err)
   else : FFMt3I(SELF, txt)
  else:
   FFI53L(SELF, OBF_Path)
 def VVjnkh(self, VVIteZ):
  OBF_Path = VVUFKh + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFGr6w(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVUFKh)
  os.system("mv -f %s %s" % (VVUFKh + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVUFKh + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVUFKh + "plugin.py"))
  self.session.openWithCallback(self.VVjnkh1, boundFunction(CC4z8v, path=VVUFKh, VVIteZ=VVIteZ))
 def VVjnkh1(self):
  os.system("mv -f %s %s" % (VVUFKh + "OBF/main.py"  , VVUFKh))
  os.system("mv -f %s %s" % (VVUFKh + "OBF/plugin.py" , VVUFKh))
 def VV8P52(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFGr6w(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFGr6w(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVwddt("%s*.list" % path)
  if err:
   FFI53L(self, path + "*.list")
   return
  srcF, err = self.VVwddt("%s*main_final.py" % path)
  if err:
   FFI53L(self, path + "*.final.py")
   return
  VVbKpp = []
  for f in files:
   f = os.path.basename(f)
   VVbKpp.append((f, f))
  FFsmMG(self, boundFunction(self.VVRnZs, path, codF, srcF), VVwdxM=VVbKpp)
 def VVRnZs(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFI53L(self, logF)
   else     : FFa70X(self, boundFunction(self.VVTsPY, logF, codF, srcF))
 def VVTsPY(self, logF, codF, srcF):
  lst  = []
  lines = FFn8wV(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFGr6w(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVanKb(lst, logF, newLogF)
  totSrc  = self.VVanKb(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFMt3I(self, txt)
 def VVwddt(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVanKb(self, lst, f1, f2):
  txt = FFaq7Y(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVebTN(self):
  VVbKpp = []
  VVbKpp.append("%s%s" % (VVUFKh, "*.py"))
  VVbKpp.append("%s%s" % (VVUFKh, "*.png"))
  VVbKpp.append("%s%s" % (VVUFKh, "*.xml"))
  VVbKpp.append("%s"  % (VVfmTj))
  FFmbYL(self, VVbKpp, "%s_%s" % (PLUGIN_NAME, VVyy0v), addTimeStamp=False)
 def VVVPrz(self):
  path1 = VVeRDn
  path2 = "/etc/tuxbox/"
  VVbKpp = []
  VVbKpp.append("%s%s" % (path1, "*.tv"))
  VVbKpp.append("%s%s" % (path1, "*.radio"))
  VVbKpp.append("%s%s" % (path1, "*list"))
  VVbKpp.append("%s%s" % (path1, "lamedb*"))
  VVbKpp.append("%s%s" % (path2, "*.xml"))
  FFmbYL(self, VVbKpp, "channels_backup", addTimeStamp=True)
 def VVVMXe(self):
  VVbKpp = []
  VVbKpp.append("/etc/tuxbox/config/")
  VVbKpp.append("/usr/keys/")
  VVbKpp.append("/usr/scam/")
  VVbKpp.append("/etc/CCcam.cfg")
  FFmbYL(self, VVbKpp, "softcam_backup", addTimeStamp=True)
 def VVV5bc(self):
  VVbKpp = []
  VVbKpp.append("/etc/hostname")
  VVbKpp.append("/etc/default_gw")
  VVbKpp.append("/etc/resolv.conf")
  VVbKpp.append("/etc/wpa_supplicant*.conf")
  VVbKpp.append("/etc/network/interfaces")
  VVbKpp.append("/etc/enigma2/nameserversdns.conf")
  FFmbYL(self, VVbKpp, "network_backup", addTimeStamp=True)
 def VVOozk(self, fileName):
  if fileName:
   FFIxs9(self, boundFunction(self.VVgAjl, fileName), "Overwrite current channels ?")
 def VVgAjl(self, fileName):
  path = "%s%s" % (VVbxzm, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCVPCx.VVjgqm()
   lamedb5File, diabled5File = CCVPCx.VVOMPI()
   cmd = ""
   cmd += FFoKN8("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFoKN8("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFjOTm()
   if res == 0 : FF6zpT(self, "Channels Restored.")
   else  : FFGr6w(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFI53L(self, path)
 def VVvCmY(self, fileName):
  if fileName:
   FFIxs9(self, boundFunction(self.VVXszJ, fileName), "Overwrite SoftCAM files ?")
 def VVXszJ(self, fileName):
  fileName = "%s%s" % (VVbxzm, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVlWOd
   note = "You may need to restart your SoftCAM."
   FF06MI(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFdpXa(note, VVX3gJ), sep))
  else:
   FFI53L(self, fileName)
 def VVPm6Z(self, fileName):
  if fileName:
   FFIxs9(self, boundFunction(self.VViMsc, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VViMsc(self, fileName):
  fileName = "%s%s" % (VVbxzm, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFgQDF(self,  cmd)
  else:
   FFI53L(self, fileName)
 def VVLRnK(self, pattern, callBackFunction, isTuner=False):
  title = FFVjlE()
  if pathExists(VVbxzm):
   myFiles = iGlob("%s%s" % (VVbxzm, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVbKpp = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVbKpp.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VV0ixh = ("Sat. List", self.VVi9Ko)
    else  : VV0ixh = None
    FFsmMG(self, callBackFunction, title=title, VVwdxM=VVbKpp, VV0ixh=VV0ixh)
   else:
    FFGr6w(self, "No files found in:\n\n%s" % VVbxzm, title)
  else:
   FFGr6w(self, "Path not found:\n\n%s" % VVbxzm, title)
 def VVCXTM(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCH43c()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VV0DeB, filePrefix))
 def VV0DeB(self, filePrefix, result, retval):
  title = FFVjlE()
  if pathExists(VVbxzm):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFGr6w(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVbxzm, filePrefix, FF9n2A())
    try:
     VVbKpp = str(result.strip()).split()
     if VVbKpp:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVbKpp:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVlWOd, FFY8RM(fName, VVX3gJ), VVlWOd)
       FFMt3I(self, txt, title=title, VVbIQl=VV1GDe)
      else:
       FFGr6w(self, "File creation failed!", title)
     else:
      FFGr6w(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFoKN8("rm %s" % fName))
     FFGr6w(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFoKN8("rm %s" % fName))
     FFGr6w(self, "Error while writing file.")
  else:
   FFGr6w(self, "Path not found:\n\n%s" % VVbxzm, title)
 def VV0tTo(self, mode, path):
  if path:
   path = "%s%s" % (VVbxzm, path)
   if fileExists(path):
    lines = FFn8wV(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys/FHDG17"
     FFIxs9(self, boundFunction(self.VVQfzQ, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FF2TvG(self, path, title=FFVjlE())
   else:
    FFI53L(self, path)
 def VVQfzQ(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVLuAj = []
  VVLuAj.append("echo -e 'Reading current settings ...'")
  VVLuAj.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVLuAj.append("echo -e 'Preparing new settings ...'")
  VVLuAj.append(settingsLines)
  VVLuAj.append("echo -e 'Applying new settings ...'")
  VVLuAj.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFiNdd(self, VVLuAj)
 def VVi9Ko(self, VVyzEqObj, path):
  if not path:
   return
  path = VVbxzm + path
  if not fileExists(path):
   FFI53L(self, path)
   return
  txt = FFaq7Y(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVbKpp  = []
   for item in satList:
    VVbKpp.append("%s\t%s" % (item[0], FFGZ1p(item[1])))
   FFMt3I(self, VVbKpp, title="  Satellites List")
  else:
   FFGr6w(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CC5299(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFFsgK(VVQV0S, 850, 700, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVwdxM = []
  VVwdxM.append(("Plugins Browser List"       , "VV23Di"   ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVwdxM.append(("Remove Packages (show all)"     , "VVf7RksAll"   ))
  VVwdxM.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Update List of Available Packages"   , "VVePXe"   ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Packaging Tool"        , "VVu7IP"    ))
  VVwdxM.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFKXoA(self, VVwdxM=VVwdxM)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  FFfopI(self["myMenu"])
  FFwO6z(self)
 def VVPtX0(self):
  global VVEipR
  VVEipR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV23Di"   : self.VV23Di()
   elif item == "pluginsDirList"    : self.VVw9IL()
   elif item == "downloadInstallPackages"  : FFa70X(self, boundFunction(self.VVi9sg, 0, ""))
   elif item == "VVf7RksAll"   : FFa70X(self, boundFunction(self.VVi9sg, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFa70X(self, boundFunction(self.VVi9sg, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVePXe"   : self.VVePXe()
   elif item == "VVu7IP"    : self.VVu7IP()
   elif item == "packagesFeeds"    : self.VVyn9t()
   else          : self.close()
 def VVw9IL(self):
  extDirs  = FFotAE(VVloRZ)
  sysDirs  = FFotAE(VVgT5I)
  VVbKpp  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVbKpp.append((item, VVloRZ + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVbKpp.append((item, VVgT5I + item))
  if VVbKpp:
   VVbKpp = sorted(VVbKpp, key=lambda x: x[0].lower())
   VVzhrG = ("Package Info.", self.VVtPwi, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFsX1L(self, None, header=header, VVbKpp=VVbKpp, VVRSoy=widths, VVA2Pa=28, VVzhrG=VVzhrG)
  else:
   FFGr6w(self, "Nothing found!")
 def VVtPwi(self, VVL8CA, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVloRZ) : loc = "extensions"
  elif path.startswith(VVgT5I) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVoLZU(package)
  else:
   FFGr6w(self, "No info!")
 def VVyn9t(self):
  pkg = FFKtW2()
  if pkg : FFTM8D(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFQ7SS(self)
 def VV23Di(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVLQyb(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVlWOd + "\n"
    txt += VVLQyb("Number"   , str(c))
    txt += VVLQyb("Name"   , FFY8RM(str(p.name), VVX3gJ))
    txt += VVLQyb("Path"  , p.path  )
    txt += VVLQyb("Description" , p.description )
    txt += VVLQyb("Icon"  , p.iconstr  )
    txt += VVLQyb("Wakeup Fnc" , p.wakeupfnc )
    txt += VVLQyb("NeedsRestart", p.needsRestart)
    txt += VVLQyb("Internal" , p.internal )
    txt += VVLQyb("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFMt3I(self, txt)
 def VVePXe(self):
  cmd = FFSOBZ(VVmPX5, "")
  if cmd : FFgQDF(self, cmd, checkNetAccess=True)
  else : FFQ7SS(self)
 def VVu7IP(self):
  pkg = FFKtW2()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FF6zpT(self, txt)
 def VVi9sg(self, mode, grep, VVL8CA=None, title=""):
  if   mode == 0: cmd = FFSOBZ(VVcFlp    , grep)
  elif mode == 1: cmd = FFSOBZ(VVHzCw , grep)
  elif mode == 2: cmd = FFSOBZ(VVHzCw , grep)
  if not cmd:
   FFQ7SS(self)
   return
  VV2XDg = FF0s0U(cmd)
  if not VV2XDg:
   if VVL8CA: VVL8CA.VVXTRT()
   FFGr6w(self, "No packages found!")
   return
  elif len(VV2XDg) == 1 and VV2XDg[0] == VVyxHj:
   FFGr6w(self, VVyxHj)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVbKpp  = []
  for item in VV2XDg:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVbKpp.append((name, package, version))
  if mode > 0:
   extensions = FF0s0U("ls %s -l | grep '^d' | awk '{print $9}'" % VVloRZ)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVbKpp:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVbKpp.append((name, VVloRZ + item, "-"))
   systemPlugins = FF0s0U("ls %s -l | grep '^d' | awk '{print $9}'" % VVgT5I)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVbKpp:
      if item.lower() == row[0].lower():
       break
     else:
      VVbKpp.append((item, VVgT5I + item, "-"))
  if not VVbKpp:
   FFGr6w(self, "No packages found!")
   return
  if VVL8CA:
   VVbKpp.sort(key=lambda x: x[0].lower())
   VVL8CA.VVn17k(VVbKpp, title)
  else:
   widths = (20, 50, 30)
   VVcGuB = None
   VVwqYz = None
   if mode == 0:
    VVZOCH = ("Install" , self.VVtfDU   , [])
    VVcGuB = ("Download" , self.VVIgQK   , [])
    VVwqYz = ("Filter"  , self.VVdtV1 , [])
   elif mode == 1:
    VVZOCH = ("Uninstall", self.VVf7Rk, [])
   elif mode == 2:
    VVZOCH = ("Uninstall", self.VVf7Rk, [])
    widths= (18, 57, 25)
   VVbKpp = sorted(VVbKpp, key=lambda x: x[0].lower())
   VVzhrG = ("Package Info.", self.VVvXlm, [])
   header   = ("Name" ,"Package" , "Version" )
   FFsX1L(self, None, header=header, VVbKpp=VVbKpp, VVRSoy=widths, VVA2Pa=28, VVZOCH=VVZOCH, VVcGuB=VVcGuB, VVzhrG=VVzhrG, VVwqYz=VVwqYz, VVdyvC=self.lastSelectedRow
     , VVslef="#22110011", VV7O11="#22191111", VVPOXl="#22191111", VVfU42="#00003030", VVd2OO="#00333333")
 def VVvXlm(self, VVL8CA, title, txt, colList):
  package = colList[1]
  self.VVoLZU(package)
 def VVdtV1(self, VVL8CA, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVwdxM = []
  VVwdxM.append(("All Packages", "all"))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVwdxM.append(VVWygA)
  for word in words:
   VVwdxM.append((word, word))
  FFsmMG(self, boundFunction(self.VVFRFh, VVL8CA), VVwdxM=VVwdxM, title="Select Filter")
 def VVFRFh(self, VVL8CA, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFa70X(VVL8CA, boundFunction(self.VVi9sg, 0, grep, VVL8CA, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVf7Rk(self, VVL8CA, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVloRZ, VVgT5I)):
   FFIxs9(self, boundFunction(self.VV5Jvz, VVL8CA, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVwdxM = []
   VVwdxM.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVwdxM.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVwdxM.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFsmMG(self, boundFunction(self.VVrDbD, VVL8CA, package), VVwdxM=VVwdxM)
 def VV5Jvz(self, VVL8CA, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VV7NYO)
  FFgQDF(self, cmd, VVlT5W=boundFunction(self.VVUs5X, VVL8CA))
 def VVrDbD(self, VVL8CA, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVZ6uP
   elif item == "remove_ForceRemove"  : cmdOpt = VVYVJg
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVbYh9
   FFIxs9(self, boundFunction(self.VVAxtP, VVL8CA, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVAxtP(self, VVL8CA, package, cmdOpt):
  self.lastSelectedRow = VVL8CA.VVlsdL()
  cmd = FFS262(cmdOpt, package)
  if cmd : FFgQDF(self, cmd, VVlT5W=boundFunction(self.VVUs5X, VVL8CA))
  else : FFQ7SS(self)
 def VVUs5X(self, VVL8CA):
  VVL8CA.cancel()
  FFLC0G()
 def VVtfDU(self, VVL8CA, title, txt, colList):
  package  = colList[1]
  VVwdxM = []
  VVwdxM.append(("Install Package"         , "install_CheckVersion" ))
  VVwdxM.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVwdxM.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVwdxM.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFsmMG(self, boundFunction(self.VV0dgj, package), VVwdxM=VVwdxM)
 def VV0dgj(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VV5AxC
   elif item == "install_ForceReinstall" : cmdOpt = VVOhTz
   elif item == "install_ForceDowngrade" : cmdOpt = VVkdhs
   elif item == "install_IgnoreDepends" : cmdOpt = VVHV5w
   FFIxs9(self, boundFunction(self.VV3aWK, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VV3aWK(self, package, cmdOpt):
  cmd = FFS262(cmdOpt, package)
  if cmd : FFgQDF(self, cmd, VVlT5W=FFLC0G, checkNetAccess=True)
  else : FFQ7SS(self)
 def VVIgQK(self, VVL8CA, title, txt, colList):
  package  = colList[1]
  FFIxs9(self, boundFunction(self.VVZy8c, package), "Download Package ?\n\n%s" % package)
 def VVZy8c(self, package):
  if FFCaZL():
   cmd = FFS262(VVlwFj, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFdpXa(success, VVI0dy))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFdpXa(fail, VVNRjX))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFgQDF(self, cmd, VVIkps=[VVNRjX, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFQ7SS(self)
  else:
   FFGr6w(self, "No internet connection !")
 def VVoLZU(self, package):
  infoCmd  = FFS262(VVhYlS, package)
  filesCmd = FFS262(VVJmdL, package)
  listInstCmd = FFSOBZ(VVHzCw, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FF2OPV(VVX3gJ)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFdpXa(notInst, VVBEBZ))
   cmd += "else "
   cmd +=   FFMJrr("System Info", VVX3gJ)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFMJrr("Related Files", VVX3gJ)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFj8K7(self, cmd)
  else:
   FFQ7SS(self)
class CCVPCx(Screen):
 VVJsqx  = 0
 VVuxEK = 1
 VVUezm  = 2
 VVYksr  = 3
 VVaQAp = 4
 VVvDXQ = 5
 VVKu9g = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFFsgK(VVQV0S, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVascv = None
  self.lastfilterUsed  = None
  VVwdxM = self.VVCbRD()
  FFKXoA(self, VVwdxM=VVwdxM, title="Services/Channels")
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self["myMenu"].setList(self.VVCbRD())
  FFfopI(self["myMenu"])
  FFwO6z(self)
 def VVCbRD(self):
  VVwdxM = []
  VVwdxM.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVwdxM.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Services (Reference)"      , "lameDB_allChannels_with_refCode"  ))
  VVwdxM.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVwdxM.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVwdxM.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVwdxM.append(("Services with PIcons for the System"  , "VVDGC6"     ))
  VVwdxM.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVwdxM.append(VVWygA)
  lamedbFile, disabledFile = CCVPCx.VVjgqm()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVwdxM.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVwdxM.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVwdxM.append(("Reset Parental Control Settings"   , "VVxD0k"    ))
  VVwdxM.append(("Delete Channels with no names"   , "VVTBYg"    ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Reload Channels and Bouquets"    , "VVHj3z"      ))
  return VVwdxM
 def VVPtX0(self):
  global VVEipR
  VVEipR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFT4Q8(self)
   elif item == "currentServiceInfo"     : FFASWh(self, fncMode=CCAHNs.VVtbnB)
   elif item == "TranspondersStats"     : FFa70X(self, self.VV6tvJ     )
   elif item == "lameDB_allChannels_with_refCode"  : FFa70X(self, self.VVLMdP )
   elif item == "lameDB_allChannels_with_tranaponder" : FFa70X(self, self.VVqwee)
   elif item == "lameDB_allChannels_with_details"  : FFa70X(self, self.VVWOPy )
   elif item == "parentalControlChannels"    : FFa70X(self, self.VVWU1K   )
   elif item == "showHiddenChannels"     : FFa70X(self, self.VVU3qQ     )
   elif item == "VVDGC6"     : FFa70X(self, self.VVN8Sx     )
   elif item == "servicesWithMissingPIcons"   : FFa70X(self, self.VVs8kv   )
   elif item == "enableHiddenChannels"     : self.VVZ9gR(True)
   elif item == "disableHiddenChannels"    : self.VVZ9gR(False)
   elif item == "VVxD0k"    : FFIxs9(self, self.VVxD0k, "Reset and Restart ?" )
   elif item == "VVTBYg"    : FFa70X(self, self.VVTBYg)
   elif item == "VVHj3z"      : FFa70X(self, boundFunction(CCVPCx.VVHj3z, self))
   else            : self.close()
 @staticmethod
 def VVHj3z(SELF):
  FFjOTm()
  FF6zpT(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVLMdP(self):
  self.VVascv = None
  self.lastfilterUsed  = None
  self.filterObj   = CCCU6U(self)
  VV2XDg = CCVPCx.VV2CvK(self, self.VVJsqx)
  if VV2XDg:
   VV2XDg.sort(key=lambda x: x[0].lower())
   VVRjvg  = ("Zap"   , self.VVWCnl     , [])
   VVCijI = (""    , self.VV6UOQ   , [])
   VVzhrG = ("Options"  , self.VV4RVo , [])
   VVcGuB = ("Current Service", self.VVwNdX , [])
   VVwqYz = ("Filter"   , self.VVGScy  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVxqTz  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFsX1L(self, None, header=header, VVbKpp=VV2XDg, VVxqTz=VVxqTz, VVRSoy=widths, VVA2Pa=26, VVRjvg=VVRjvg, VVCijI=VVCijI, VVcGuB=VVcGuB, VVzhrG=VVzhrG, VVwqYz=VVwqYz)
 def VVqwee(self):
  self.VVascv = None
  self.lastfilterUsed  = None
  self.filterObj   = CCCU6U(self)
  VV2XDg = CCVPCx.VV2CvK(self, self.VVuxEK)
  if VV2XDg:
   VV2XDg.sort(key=lambda x: x[0].lower())
   VVRjvg  = ("Zap"   , self.VVWCnl      , [])
   VVCijI = (""    , self.VV6UOQ    , [])
   VVcGuB = ("Current Service", self.VVwNdX  , [])
   VVzhrG = ("Options"  , self.VV9gvI , [])
   VVwqYz = ("Filter"   , self.VVxHcI  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVxqTz  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFsX1L(self, None, header=header, VVbKpp=VV2XDg, VVxqTz=VVxqTz, VVRSoy=widths, VVA2Pa=26, VVRjvg=VVRjvg, VVCijI=VVCijI, VVcGuB=VVcGuB, VVzhrG=VVzhrG, VVwqYz=VVwqYz)
 def VV4RVo(self, VVL8CA, title, txt, colList):
  servName = colList[0]
  refCode  = colList[3]
  pcState  = colList[4]
  hidState = colList[5]
  mSel  = CChV7M(self, VVL8CA, 3)
  mSel.VVSsEO(servName, refCode, pcState, hidState)
 def VV9gvI(self, VVL8CA, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CChV7M(self, VVL8CA, 3)
  mSel.VVSa8v(servName, refCode)
 def VVOOqT(self, VVL8CA, refCode, isAddToBlackList):
  self.VVascv = None
  self.lastfilterUsed  = None
  VVL8CA.VV7fYZ("Changing state ...")
  path = "/etc/enigma2/blacklist"
  if not fileExists(path):
   os.system("echo '' > %s" % path)
  if fileExists(path):
   if not refCode.endswith(":"):
    refCode += ":"
   if isAddToBlackList :
    os.system("sed -i '/%s/d' %s" % (refCode, path))
    os.system("echo '%s' >> %s" % (refCode, path))
   else:
    os.system("sed -i '/%s/d' %s" % (refCode, path))
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   if refCode.endswith(":"):
    refCode = refCode[:-1]
   FFa70X(self, boundFunction(self.VVOznR, VVL8CA, refCode))
  else:
   FFI53L(self, path)
 def VVLlpO(self, VVL8CA, refCode, isHide):
  self.VVascv = None
  self.lastfilterUsed  = None
  VVL8CA.VV7fYZ("Changing state ...")
  if FFDKXp(refCode):
   ret = FFn2dx(refCode, isHide)
   if ret : FFa70X(self, boundFunction(self.VVOznR, VVL8CA, refCode))
   else : FFGr6w(self, "Cannot Hide/Unhide this channel.")
  else:
   FFGr6w(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)")
 def VVOznR(self, VVL8CA, refCode):
  VV2XDg = CCVPCx.VV2CvK(self, self.VVJsqx, VVZ2GI=[3, [refCode], False])
  done = False
  if VV2XDg:
   data = VV2XDg[0]
   if data[3] == refCode:
    done = VVL8CA.VVZZ5t(data)
  if not done:
   self.VVgwxr(VVL8CA, VVL8CA.VV1hep(), self.VVJsqx)
  VVL8CA.VVXTRT()
 def VVGScy(self, VVL8CA, title, txt, colList):
  self.filterObj.VVd2Fw(1, VVL8CA, 2, boundFunction(self.VV2QwX, VVL8CA))
 def VV2QwX(self, VVL8CA, item):
  self.VVL0kp(VVL8CA, item, 2, self.VVJsqx)
 def VVxHcI(self, VVL8CA, title, txt, colList):
  self.filterObj.VVd2Fw(2, VVL8CA, 4, boundFunction(self.VV5VsY, VVL8CA))
 def VV5VsY(self, VVL8CA, item):
  self.VVL0kp(VVL8CA, item, 4, self.VVuxEK)
 def VV22KF(self, VVL8CA, title, txt, colList):
  self.filterObj.VVd2Fw(0, VVL8CA, 4, boundFunction(self.VVZmtq, VVL8CA))
 def VVZmtq(self, VVL8CA, item):
  self.VVL0kp(VVL8CA, item, 4, self.VVUezm)
 def VVL0kp(self, VVL8CA, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVL8CA.VVt0P4(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVascv = None
  else:
   words, asPrefix = CCCU6U.VVAvaW(words)
   self.VVascv = [col, words, asPrefix]
  if words: FFa70X(self, boundFunction(self.VVgwxr, VVL8CA, title, mode), title="Reading Services ...")
  else : FFU79C(VVL8CA, "Incorrect filter", 2000)
 def VVgwxr(self, VVL8CA, title, mode):
  VV2XDg = CCVPCx.VV2CvK(self, mode, VVZ2GI=self.VVascv, VV2jrq=False)
  if VV2XDg:
   VV2XDg.sort(key=lambda x: x[0].lower())
   VVL8CA.VVn17k(VV2XDg, title)
  else:
   VVL8CA.VVXTRT()
   FFU79C(VVL8CA, "Not found!", 1500)
 def VVl5mB(self, VVbKpp, VVRjvg=None, VVCijI=None, VVZOCH=None, VVcGuB=None, VVzhrG=None, VVwqYz=None):
  VVcGuB = ("Current Service", self.VVwNdX, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVxqTz = (LEFT  , LEFT  , CENTER, LEFT    )
  FFsX1L(self, None, header=header, VVbKpp=VVbKpp, VVxqTz=VVxqTz, VVRSoy=widths, VVA2Pa=26, VVRjvg=VVRjvg, VVCijI=VVCijI, VVZOCH=VVZOCH, VVcGuB=VVcGuB, VVzhrG=VVzhrG, VVwqYz=VVwqYz)
 def VVwNdX(self, VVL8CA, title, txt, colList):
  self.VVLZU0(VVL8CA)
 def VVOSVM(self, VVL8CA, title, txt, colList):
  self.VVLZU0(VVL8CA, True)
 def VVLZU0(self, VVL8CA, isFromDetails=False):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(self)
  if refCode:
   if isFromDetails:
    chName  = info.getName()
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVL8CA.VVh4rG(colDict, VV17Wy=True)
   else:
    VVL8CA.VVuOU0(3, refCode, True)
   return
  FFGr6w(self, "Colud not read current Reference Code !")
 def VVWOPy(self):
  self.VVascv = None
  self.lastfilterUsed  = None
  self.filterObj   = CCCU6U(self)
  VV2XDg = CCVPCx.VV2CvK(self, self.VVUezm)
  if VV2XDg:
   VV2XDg.sort(key=lambda x: x[0].lower())
   VVCijI = (""    , self.VVndLo , []      )
   VVcGuB = ("Current Service", self.VVOSVM  , []      )
   VVwqYz = ("Filter"   , self.VV22KF   , [], "Loading Filters ..." )
   VVRjvg  = ("Zap"   , self.VVlzP0      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVxqTz  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFsX1L(self, None, header=header, VVbKpp=VV2XDg, VVxqTz=VVxqTz, VVRSoy=widths, VVA2Pa=26, VVRjvg=VVRjvg, VVCijI=VVCijI, VVcGuB=VVcGuB, VVwqYz=VVwqYz)
 def VVndLo(self, VVL8CA, title, txt, colList):
  refCode  = self.VVLFrV(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFASWh(self, fncMode=CCAHNs.VV01b6, refCode=refCode, chName=chName, text=txt)
 def VVlzP0(self, VVL8CA, title, txt, colList):
  refCode = self.VVLFrV(colList)
  FFsOcb(self, refCode)
 def VVWCnl(self, VVL8CA, title, txt, colList):
  FFsOcb(self, colList[3])
 def VVLFrV(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VV2CvK(SELF, mode, VVZ2GI=None, VV2jrq=True, VVjy3R=True):
  lamedbFile, disabledFile = CCVPCx.VVjgqm()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVZ2GI:
    filterCol = VVZ2GI[0]
    filterWords = VVZ2GI[1]
    asPrefix = VVZ2GI[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCVPCx.VVJsqx:
    blackList = None
    path = "/etc/enigma2/blacklist"
    if fileExists(path):
     blackList = FFn8wV(path)
     if blackList:
      blackList = set(blackList)
   elif mode == CCVPCx.VVuxEK:
    tp = CCloky()
   VVsekx, VVbZDd = FFmDkq()
   tagFound  = False
   if mode in (CCVPCx.VVvDXQ, CCVPCx.VVKu9g):
    VV2XDg = {}
   else:
    VV2XDg = []
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFARfj(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CCVPCx.VVUezm:
        if sTypeInt in VVsekx:
         STYPE = VVbZDd[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VV2XDg.append(tRow)
         elif any(x in tmp for x in filterWords)    : VV2XDg.append(tRow)
        else:
         VV2XDg.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCVPCx.VVvDXQ:
         VV2XDg[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCVPCx.VVKu9g:
         VV2XDg[chName] = refCode
        elif mode == CCVPCx.VVJsqx:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VV2XDg.append(tRow)
          elif any(x in tmp for x in filterWords)    : VV2XDg.append(tRow)
         else:
          VV2XDg.append(tRow)
        elif mode == CCVPCx.VVuxEK:
         if sTypeInt in VVsekx:
          STYPE = VVbZDd[sTypeInt]
         freq, pol, fec, sr, syst = tp.VV3Vfi(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VV2XDg.append(tRow)
          elif any(x in tmp for x in filterWords)    : VV2XDg.append(tRow)
         else:
          VV2XDg.append(tRow)
        elif mode == CCVPCx.VVYksr:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VV2XDg.append((chName, chProv, sat, refCode))
        elif mode == CCVPCx.VVaQAp:
         VV2XDg.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VV2XDg and VV2jrq:
    FFGr6w(SELF, "No services found!")
   return VV2XDg
  else:
   if VVjy3R:
    FFI53L(SELF, lamedbFile)
   return None
 def VVWU1K(self):
  path = "/etc/enigma2/blacklist"
  if fileExists(path):
   lines = FFn8wV(path)
   if lines:
    newRows  = []
    VV2XDg = CCVPCx.VV2CvK(self, self.VVaQAp)
    if VV2XDg:
     lines = set(lines)
     for item in VV2XDg:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VV2XDg = newRows
      VV2XDg.sort(key=lambda x: x[0].lower())
      VVCijI = ("", self.VV6UOQ, [])
      VVRjvg = ("Zap", self.VVWCnl, [])
      self.VVl5mB(VVbKpp=VV2XDg, VVRjvg=VVRjvg, VVCijI=VVCijI)
     else:
      FFMt3I(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VV2XDg)))
   else:
    FF6zpT(self, "No active Parental Control services.", FFVjlE())
  else:
   FFI53L(self, path)
 def VVU3qQ(self):
  VV2XDg = CCVPCx.VV2CvK(self, self.VVYksr)
  if VV2XDg:
   VV2XDg.sort(key=lambda x: x[0].lower())
   VVCijI = ("" , self.VV6UOQ, [])
   VVRjvg  = ("Zap", self.VVWCnl, [])
   self.VVl5mB(VVbKpp=VV2XDg, VVRjvg=VVRjvg, VVCijI=VVCijI)
  else:
   FF6zpT(self, "No hidden services.", FFVjlE())
 def VV6tvJ(self):
  totT, totC, totA, totS, totS2, satList = self.VV0mkW()
  txt = FFY8RM("Total Transponders:\n\n", VVVJBw)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFY8RM("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVVJBw)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FF5B49(item), satList.count(item))
  FFMt3I(self, txt)
 def VV0mkW(self):
  lamedbFile, disabledFile = CCVPCx.VVjgqm()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     line = line.strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFI53L(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VVN8Sx(self)   : self.VVDGC6(True)
 def VVs8kv(self) : self.VVDGC6(False)
 def VVDGC6(self, isWithPIcons):
  piconsPath = CClRyV.VVvvid()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CClRyV.VVhEf2(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VV2XDg = CCVPCx.VV2CvK(self, self.VVaQAp)
    if VV2XDg:
     channels = []
     for (chName, chProv, sat, refCode) in VV2XDg:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFt9Zq(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VV2XDg)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVLQyb(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVLQyb("PIcons Path"  , piconsPath)
     txt += VVLQyb("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVLQyb("Total services" , totalServices)
     txt += VVLQyb("With PIcons"  , totalWithPIcons)
     txt += VVLQyb("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFMt3I(self, txt)
     else:
      VVCijI     = (""      , self.VV6UOQ , [])
      if isWithPIcons : VVwqYz = ("Export Current PIcon", self.VVK4Gd  , [])
      else   : VVwqYz = None
      VVzhrG     = ("Statistics", FFMt3I, [txt])
      VVRjvg      = ("Zap", self.VVWCnl, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVl5mB(VVbKpp=channels, VVRjvg=VVRjvg, VVCijI=VVCijI, VVzhrG=VVzhrG, VVwqYz=VVwqYz)
   else:
    FFGr6w(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFGr6w(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VV6UOQ(self, VVL8CA, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFASWh(self, fncMode=CCAHNs.VV01b6, refCode=refCode, chName=chName, text=txt)
 def VVK4Gd(self, VVL8CA, title, txt, colList):
  png, path = CClRyV.VVfqdE(colList[3], colList[0])
  if path:
   CClRyV.VVHDck(self, png, path)
 @staticmethod
 def VVjgqm():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVOMPI():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVZ9gR(self, isEnable):
  lamedbFile, disabledFile = CCVPCx.VVjgqm()
  if isEnable and not fileExists(disabledFile):
   FF6zpT(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FFGr6w(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFIxs9(self, boundFunction(self.VVqFQc, isEnable), "%s Hidden Channels ?" % word)
 def VVqFQc(self, isEnable):
  lamedbFile , disabledFile = CCVPCx.VVjgqm()
  lamedb5File, diabled5File = CCVPCx.VVOMPI()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFjOTm()
  if res == 0 : FF6zpT(self, "Hidden List %s" % word)
  else  : FFGr6w(self, "Error while restoring:\n\n%s" % fileName)
 def VVxD0k(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFiNdd(self, cmd)
 def VVTBYg(self):
  lamedbFile, disabledFile = CCVPCx.VVjgqm()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFoKN8("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFn8wV(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFoKN8("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFjOTm()
   FFMt3I(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFI53L(self, lamedbFile)
class CCAHNs(Screen):
 VVtbnB  = 0
 VVSpVM   = 1
 VVvYBs   = 2
 VV01b6    = 3
 VVxIaR    = 4
 VVQ4O4   = 5
 VVpAkQ   = 6
 VVtO1g    = 7
 VV3JtX   = 8
 VVUKMU   = 9
 VV879d   = 10
 VVv5nB   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFFsgK(VVwgeJ, 1400, 800, 50, 30, 20, "#110B2830", "#050B242c", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVtbnB)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFY8RM("%s\n", VVKVzn) % VVlWOd
  FFKXoA(self, title="Channel Info", addScrollLabel=True)
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  self["myLabel"].VVA9a4(textOutFile="chann_info")
  if   self.fncMode == self.VVtbnB : fnc = self.VVKyj1_VVtbnB
  elif self.fncMode == self.VVSpVM  : fnc = self.VVKyj1_VVtbnB
  elif self.fncMode == self.VVvYBs  : fnc = self.VVKyj1_VVtbnB
  elif self.fncMode == self.VV01b6  : fnc = self.VVKyj1_VV01b6
  elif self.fncMode == self.VVxIaR  : fnc = self.VVKyj1_VVxIaR
  elif self.fncMode == self.VVQ4O4  : fnc = self.VVKyj1_VVQ4O4
  elif self.fncMode == self.VVpAkQ  : fnc = self.VVKyj1_VVpAkQ
  elif self.fncMode == self.VVtO1g  : fnc = self.VVKyj1_VVtO1g
  elif self.fncMode == self.VV3JtX  : fnc = self.VVKyj1_VV3JtX
  elif self.fncMode == self.VVUKMU : fnc = self.VVKyj1_VVUKMU
  elif self.fncMode == self.VV879d  : fnc = self.VVKyj1_VV879d
  elif self.fncMode == self.VVv5nB : fnc = self.VVKyj1_VVv5nB
  self["myLabel"].setText("\n   Reading Info ...")
  FFZQW5(fnc)
 def VVSRtt(self, err):
  self["myLabel"].setText(err)
  FFpRmN(self["myTitle"], "#22200000")
  FFpRmN(self["myBody"], "#22200000")
  self["myLabel"].FFpRmNColor("#22200000")
  self["myLabel"].VVSLZQ()
 def VVKyj1_VVtbnB(self):
  try:
   dum = self.session
  except:
   return
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(self)
  self.refCode = refCode
  self.VV7JKA(chName)
 def VVKyj1_VV01b6(self):
  self.VV7JKA(self.chName)
 def VVKyj1_VVxIaR(self):
  self.VV7JKA(self.chName)
 def VVKyj1_VVQ4O4(self):
  self.VV7JKA(self.chName)
 def VVKyj1_VVpAkQ(self):
  self.VV7JKA("Picon Info")
 def VVKyj1_VVtO1g(self):
  self.VV7JKA(self.chName)
 def VVKyj1_VV3JtX(self):
  self.VV7JKA(self.chName)
 def VVKyj1_VVUKMU(self):
  self.VV7JKA(self.chName)
 def VVKyj1_VV879d(self):
  self.chUrl = self.refCode + self.callingSELF.VVbOQF(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VV7JKA(self.chName)
 def VVKyj1_VVv5nB(self):
  self.VV7JKA(self.chName)
 def VV7JKA(self, title):
  self.VVZ3y3(title)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(self)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVEjyL(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFY8RM(self.VVNcWh(tUrl), VVea45)
  if not self.epg:
   epg = self.VVUrVF(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VV6yaZ(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CClRyV.VVfqdE(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VV6yaZ(path)
  self.VVEIDa()
  self.VVRWcf()
  self["myLabel"].setText(self.text, VVbIQl=VVmdF8)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVSLZQ(minHeight=minH)
 def VVRWcf(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFba7t(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVV1rW(FF5GG1(url))
  if epg:
   self.text += "\n" + FFNBmg("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVEIDa()
 def VVEIDa(self):
  if not self.piconShown and self.picUrl:
   path, err = FFEUjD(self.picUrl, "ajpanel_tmp.png", timeout=2)
   if path:
    self.piconShown = self.VV6yaZ(path)
    if self.piconShown and self.refCode:
     self.VVIVYl(path, self.refCode)
 def VVIVYl(self, path, refCode):
  if path and fileExists(path) and os.system(FFoKN8("which ffmpeg")) == 0:
   pPath = CClRyV.VVvvid()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
    cmd += FFoKN8("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VV6yaZ(self, path):
  if path and fileExists(path):
   err, w, h = self.VVmkOP(path)
   if not err:
    if h > w:
     self.VVIDgF(self["myPicF"], w, h, True)
     self.VVIDgF(self["myPic"] , w, h, False)
   allOK = FF7cim(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVIDgF(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVmkOP(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FF5sfh(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVZ3y3(self, chName):
  if chName:
   self["myTitle"].setText("  " + chName + "  ")
 def VVEjyL(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFY8RM(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVLQyb(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFY8RM(state, VVBEBZ)
   txt += "State\t: %s\n" % state
  w = FFN7dA(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFN7dA(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVorfb(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVLQyb(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVLQyb(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVLQyb(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  isIptv = len(iptvRef) > 0
  if iptvRef:
   txt += "Service Type\t: %s\n" % FFY8RM("IPTV", VVVJBw)
   txt += self.VVT2JC(iptvRef)
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not refCode:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    path = serv.getPath()
    if path:
     txt += "Path\t: %s\n" % path
  txt += "\n"
  txt += self.VVZeoy(refCode, iptvRef, chName)
  if not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCloky()
    tpTxt, namespace = tp.VVSjK6(refCode)
    del tp
    if tpTxt:
     txt += FFY8RM("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFY8RM("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVLQyb(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVLQyb(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVLQyb(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVLQyb(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVLQyb(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVLQyb(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVLQyb(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVLQyb(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVLQyb(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVorfb(info):
  if info:
   aspect = FFN7dA(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVLQyb(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFN7dA(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVCsxZ(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVCsxZ(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVZeoy(self, refCode, iptvRef, chName):
  refCode = FFQ7UT(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFaq7Y(VVeRDn + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFaq7Y(VVeRDn + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVbKpp = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVeRDn + item
   if fileExists(path):
    txt = FFaq7Y(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVbKpp.append(bName)
  txt = self.Sep
  if VVbKpp:
   if len(VVbKpp) == 1:
    txt += "%s\t: %s\n" % (FFY8RM("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VVbKpp[0])
   else:
    txt += FFY8RM("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VVbKpp):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVUrVF(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVHcDy(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVHcDy(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVHcDy(event, 0)
     except:
      pass
  return epg
 def VVHcDy(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName().strip()    or ""
   evTime = event.getBeginTime()      or ""
   evDur = event.getDuration()      or ""
   evShort = event.getShortDescription() .strip() or ""
   evDesc = event.getExtendedDescription().strip() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = self.VVpFIU(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FFY8RM(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FFY8RM(evNameTransl, COLOR_CONS_BRIGHT_YELLOW))
    if evTime           : txt += "Start Time\t: %s\n" % FF5Ufp(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FF5Ufp(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFRq1D(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFRq1D(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFRq1D(evTime - now)
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFY8RM(evShort, VVea45)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFY8RM(evDesc , VVea45)
    if txt:
     txt = FFY8RM("\n%s\n%s Event:\n%s\n" % (VVlWOd, ("Current", "Next")[evNum], VVlWOd), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVT2JC(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFn6Kh(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCv1A9()
   valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVgrRP(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFY8RM("URL:", VVVJBw) + "\n%s\n" % self.VVNcWh(decodedUrl)
  else:
   txt = "\n"
   txt += FFY8RM("Reference:", VVVJBw) + "\n%s\n" % refCode
  return txt
 def VVNcWh(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVvPtm:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VVV1rW(self, decodedUrl):
  if not FFCaZL():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCjXCp.VVcHfY(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (not a subscription ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCjXCp.VVDihc(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVxMUW(tDict)
   elif uType == "movie" : epg, picUrl = self.VVHwot(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVxMUW(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCjXCp.VVpazX(item, "title"    , is_base64=True )
     lang    = CCjXCp.VVpazX(item, "lang"         ).upper()
     description   = CCjXCp.VVpazX(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCjXCp.VVpazX(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCjXCp.VVpazX(item, "start_timestamp"      )
     stop_timestamp  = CCjXCp.VVpazX(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCjXCp.VVpazX(item, "stop_timestamp"       )
     now_playing   = CCjXCp.VVpazX(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVaDNx, ""
      else     : color, txt = VVBEBZ , "    (CURRENT EVENT)"
      epg += FFY8RM("_" * 32 + "\n", VVKVzn)
      epg += FFY8RM("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFY8RM(description, VVea45)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVsFOe(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVHwot(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCjXCp.VVpazX(item, "movie_image" )
    genre  = CCjXCp.VVpazX(item, "genre"   ) or "-"
    plot  = CCjXCp.VVpazX(item, "plot"   ) or "-"
    cast  = CCjXCp.VVpazX(item, "cast"   ) or "-"
    rating  = CCjXCp.VVpazX(item, "rating"   ) or "-"
    director = CCjXCp.VVpazX(item, "director"  ) or "-"
    releasedate = CCjXCp.VVpazX(item, "releasedate" ) or "-"
    duration = CCjXCp.VVpazX(item, "duration"  ) or "-"
    try:
     lang = CCjXCp.VVpazX(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFY8RM(cast, VVea45)
    epg += "Plot:\n%s"    % FFY8RM(self.VVpFIU(plot), VVea45)
   except:
    pass
  return epg, movie_image
 def VVpFIU(self, evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = self.VVnlt1(evTxt, lang)
   return self.VVdLCM(txt).strip() or evTxt
 def VVdLCM(self, txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VVnlt1(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFJxD2(txt))
   txt, err = CCjXCp.VVDihc(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FF5GG1(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVsFOe(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
class CCv1A9():
 def __init__(self):
  self.VV5Dls  = ""
  self.VVuxRB   = ""
  self.VVsk2m  = ""
  self.colored_user  = "#f#11ffffaa#User"
  self.colored_server  = "#f#11aaffff#Server"
 def VV23UL(self, url, mac, VV17Wy=True):
  self.VV5Dls = ""
  self.VVuxRB  = ""
  self.VVsk2m = ""
  host = self.VVQRWi(url)
  if not host:
   if VV17Wy:
    self.VV17Wyor("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVQb7Z(mac)
  if not host:
   if VV17Wy:
    self.VV17Wyor("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VV5Dls = host
  self.VVuxRB  = mac
  self.VVsk2m = ""
  return True
 def VVbI5I(self):
  res, err = self.VVj6yW(self.VV5Dls, useCookies=False)
  if err:
   self.VV17Wyor(err, "Connect to Portal")
   return False
  if (res.status_code == 301):
   title = "Redirection"
   newUrl = res.headers['location']
   res, err = self.VVj6yW(newUrl, res.cookies)
   if err:
    self.VV17Wyor(err, "URL Redirection")
    return False
   else:
    host = self.VVQRWi(newUrl)
    if not host:
     self.VV17Wyor("Incorrect Redirection-URL Format !\n\n%s" % newUrl)
     return False
    self.VV5Dls = host
  token, profile = self.VVqe1M()
  if not token:
   return False
  return True
 def VVQRWi(self, url):
  ndx = url.lower().find("mac=")
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ ")
  return url
 def VVQb7Z(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVqe1M(self, VV17Wy=True):
  try:
   token = self.VVkANv()
   if token:
    self.VVsk2m = token
   else:
    if VV17Wy:
     self.VV17Wyor("Could not get Token from server !")
    return "", ""
   return token, self.VVJwdZ()
  except:
   return "", ""
 def VVkANv(self):
  token  = ""
  res, err = self.VVj6yW(self.VVrAIS())
  if not err:
   try:
    tDict = jLoads(res.text)
    token = CCjXCp.VVpazX(tDict["js"], "token")
   except:
    pass
  return token.strip()
 def VVJwdZ(self):
  res, err = self.VVj6yW(self.VVfG4K())
  if not err:
   try:
    profJson = jLoads(res.text)
    return profJson
   except:
    pass
  return ""
 def VVS7bu(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVl0FT()
  if len(rows) < 10:
   rows = self.VVQhOG()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VV5Dls ))
   rows.append(("MAC (from URL)" , self.VVuxRB ))
   rows.append(("Token"   , self.VVsk2m ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VVuxRB ))
   rows.append(("2", self.colored_server, "Host" , self.VV5Dls ))
   rows.append(("2", self.colored_server, "Token" , self.VVsk2m ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVdWJj(self, isPhp=True):
  token, profile = self.VVqe1M()
  if not token:
   return ""
  m3u_Url = ""
  url = self.VVXSBt()
  res, err = self.VVj6yW(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCjXCp.VVpazX(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = span.group(2)
     pass1 = span.group(3)
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url
 def VVl0FT(self):
  m3u_Url = self.VVdWJj()
  rows = []
  if m3u_Url:
   res, err = self.VVj6yW(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FF5Ufp(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FF5Ufp(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVQhOG(self):
  token, profile = self.VVqe1M()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFlcZz(val): val = FFUzJZ(val.decode("UTF-8"))
     else     : val = self.VVuxRB
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FF5Ufp(int(parts[1]))
      if parts[2] : ends = FF5Ufp(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FF5Ufp(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVbOQF(self, mode, chCm, epNum, epId):
  crLinkUrl = self.VViph2(mode, chCm, epNum, epId)
  token, profile = self.VVqe1M(VV17Wy=False)
  if not token:
   return ""
  res, err = self.VVj6yW(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCjXCp.VVpazX(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  return chUrl
 def VV3Grm(self):
  return self.VV5Dls + "/server/load.php?"
 def VVrAIS(self):
  return self.VV3Grm() + "type=stb&action=handshake&token=&mac=%s" % self.VVuxRB
 def VVfG4K(self):
  return self.VV3Grm() + "type=stb&action=get_profile"
 def VVCwHU(self, mode):
  url = self.VV3Grm() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VV5j21(self, catID):
  return self.VV3Grm() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVvJTI(self, mode, catID, page):
  url = self.VV3Grm() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "series" : url += "category=%s" % catID
  else    : url += "genre=%s&force_ch_link_check=" % catID
  return url
 def VVxYzh(self, mode, searchName, page):
  return self.VV3Grm() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VViSRC(self, mode, catID):
  return self.VV3Grm() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VViph2(self, mode, chCm, serCode, serId):
  url = self.VV3Grm() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVXSBt(self):
  return self.VV3Grm() + "type=itv&action=create_link"
 def VVfD4I(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVZNR2(catID, stID, chNum)
  query = self.VV15YB(mode, FF75Lb(host), FF75Lb(mac), serCode, serId, chCm)
  chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VV15YB(self, mode, host, mac, serCode, serId, chCm):
  query = "mode=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVgrRP(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VV15YB(mode, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFUzJZ(host)
  mac   = FFUzJZ(mac)
  valid = False
  if self.VVQRWi(playHost) and self.VVQRWi(host) and self.VVQRWi(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVj6yW(self, url, useCookies=True):
  err = ""
  try:
   import requests
   cookies = { "mac" : self.VVuxRB, "stb_lang" : "en" }
   headers = { 'User-Agent':  'Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3', }
   if self.VVsk2m:
    headers["Authorization"] = "Bearer %s" % self.VVsk2m
   if useCookies : res = requests.get(url, headers=headers, allow_redirects=False, timeout=2, cookies=cookies)
   else   : res = requests.get(url, headers=headers, allow_redirects=False, timeout=2)
   res.raise_for_status()
   return res, ""
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.exceptions.HTTPError as e  : err = "HTTP Error"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[120]
  return "", err + "\n\n" + url
 @staticmethod
 def VVbJxT(host, mac, tType, action, keysList=[]):
  myPortal = CCv1A9()
  ok = myPortal.VV23UL(host, mac)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile = myPortal.VVqe1M()
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s/server/load.php?type=%s&action=%s" % (host, tType, action)
  res, err = myPortal.VVj6yW(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVgE8C(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVgE8C(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VV17Wyor(self, err, title="Portal Browser"):
  FFGr6w(self, str(err), title=title)
 def VVOQFL(self, mode):
  if   mode in ("itv"  , CCjXCp.VVhDEg , CCjXCp.VVUL5B)  : return "Live"
  elif mode in ("vod"  , CCjXCp.VV7FRI , CCjXCp.VVWQ86)  : return "VOD"
  elif mode in ("series" , CCjXCp.VVFo24 , CCjXCp.VVRotG) : return "Series"
  else                          : return "IPTV"
 def VVz4yK(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVOQFL(mode), searchName)
 def VVnSrn(self, catchup=False):
  VVwdxM = []
  VVwdxM.append(("Live"    , "live"  ))
  VVwdxM.append(("VOD"    , "vod"   ))
  VVwdxM.append(("Series"   , "series"  ))
  if catchup:
   VVwdxM.append(VVWygA)
   VVwdxM.append(("Catchup TV" , "catchup"  ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Account Info." , "accountInfo" ))
  return VVwdxM
 @staticmethod
 def VVgQEA(decodedUrl):
  m3u_Url = ""
  p = CCv1A9()
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVgrRP(decodedUrl)
  if valid:
   ok = p.VV23UL(host, mac, VV17Wy=False)
   if ok:
    m3u_Url = p.VVdWJj(isPhp=False)
    span = iSearch(r".+ch\/(.+)_", decodedUrl, IGNORECASE)
    if span:
     m3u_Url += span.group(1)
  return m3u_Url
class CCigLq(CCv1A9):
 def __init__(self):
  CCv1A9.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVxwrt(self, refCode, chName, decodedUrl, iptvRef):
  valid, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVgrRP(decodedUrl)
  if valid:
   if self.VV23UL(host, mac, VV17Wy=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVHD1k(self, passedSELF=None, isFromSession=False):
  chUrl = self.VVbOQF(self.mode, self.chCm, self.epNum, self.epId)
  if not chUrl:
   return
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = self.refCode + chUrl.strip() + ":" + self.chName
  newIptvRef = ""
  ndx = chUrl.find("play_token=")
  if ndx > -1:
   ndx = chUrl.find(":", ndx)
   if ndx > -1:
    left  = chUrl[:ndx]
    right  = chUrl[ndx:]
    newIptvRef = left + "&" + self.query + right
  if newIptvRef:
   success = self.VVFyC5(self.iptvRef, newIptvRef)
   if passedSELF:
    FFsOcb(passedSELF, newIptvRef, VVuw4l=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFsOcb(self, newIptvRef, VVuw4l=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVFyC5(self, oldCode, newCode):
  bPath = FF3srY()
  if bPath:
   txt = FFaq7Y(bPath)
   if oldCode in txt:
    txt = txt.replace(oldCode, newCode)
    with open(bPath, "w") as f:
     f.write(txt)
    FFjOTm()
    return True
  return False
class CClMCv(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFFsgK(VVnHE9, 10, 10, 50, 30, 20, "#22002020", "#22001122", 30)
  self.session = session
  FFKXoA(self, "")
  self.close()
class CCDOp1(CCigLq):
 def __init__(self, passedSession):
  CCigLq.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.timer1   = eTimer()
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={ iPlayableService.evEnd: self.VVCwVc})
  except:
   pass
 def VVCwVc(self):
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VV9A3N)
  except:
   self.timer1.callback.append(self.VV9A3N)
  self.timer1.start(100, True)
 def VV9A3N(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(self.passedSession, isFromSession=True)
  valid = False
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if not ref == self.lastRef:
     valid = self.VVxwrt(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if not CChh4T.PLAYER_INSTANCE:
       self.VVHD1k(self.passedSession, isFromSession=True)
class CCFutt():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.adultWords  = ("adult", "sex", "porn", "xxx", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.nameTagPatt = r"(?:\s*[(|:]\s*)?[A-Z]{2}\s*.?\s*[)|:]\s*(?:.+[|:]\s*)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
 def VVpYaJ(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCjXCp.VVywit(name):
   return CCjXCp.VV7Izq(name)
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name, IGNORECASE)
   if span:
    name = span.group(1)
  return name.strip() or name
 def VVEmCF(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  span = iSearch(self.nameTagPatt, name, IGNORECASE)
  if span:
   name = span.group(1)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVYxt0(self, name):
  if self.hideAdult and any(x in name.lower() for x in self.adultWords):
   return ""
  else:
   return name.strip()
 def VVvo6G(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVyLDE(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCXYjf(CCv1A9):
 def __init__(self):
  CCv1A9.__init__(self)
 def VVuatv(self):
  try:
   import requests
   FFa70X(self, self.VVM6OT, title="Searching ...")
  except:
   FFIxs9(self, self.VVfhUa, '"Requests Library" is required to read Portal.\n\nInstall the library ?')
 def VVh0bB(self, winSession, url, mac):
  if self.VV23UL(url, mac):
   FFa70X(winSession, self.VVGFm1, title="Checking Server ...")
  else:
   FFGr6w(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVfhUa(self):
  from sys import version_info
  cmdUpd = FFSOBZ(VVmPX5, "")
  if cmdUpd:
   cmdInst = FFS262(VV5AxC, "python-requests")
   if version_info[0] >= 3:
    cmdInst = cmdInst.replace("python-", "python3-")
   cmd = cmdUpd + " && " + cmdInst
   FFgQDF(self, cmd, checkNetAccess=True, title="Installing Requests Library")
  else:
   FFQ7SS(self)
 def VVM6OT(self):
  path = CCjXCp.VVKlGK()
  lines = FF0s0U('find %s %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % (path, FFl0r9(1)))
  if lines:
   lines.sort()
   VVwdxM = []
   for line in lines:
    VVwdxM.append((line, line))
   OKBtnFnc = self.VV60AG
   FFsmMG(self, None, title="Select Portals File", VVwdxM=VVwdxM, width=1200, OKBtnFnc=OKBtnFnc)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFGr6w(self, 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt)
 def VV60AG(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   self.session.open(CCu37C, barTheme=CCu37C.VVcppe
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVWGQO, path)
       , VV6vg0 = boundFunction(self.VVXNAa, menuInstance, path))
 def VVWGQO(self, path, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with open(path, "r") as f:
   for line in f:
    totLines += 1
  progBarObj.VVx354(totLines)
  progBarObj.VVuEpa = []
  lineNum = 0
  with open(path, "r") as f:
   for line in f:
    lineNum += 1
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVW1AW(1, True)
    line = line.strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip() or "-"
     host = self.VVQRWi(url)
     mac  = self.VVQb7Z(mac)
     if host and mac and progBarObj:
      progBarObj.VVuEpa.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip() or "-"
      host = self.VVQRWi(url)
      mac  = self.VVQb7Z(mac)
      if host and mac and not mac.startswith("AC") and progBarObj:
       progBarObj.VVuEpa.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVXNAa(self, menuInstance, path, VVsXZs, VVuEpa, threadCounter, threadTotal, threadErr):
  title = "Portals List File"
  if VVuEpa:
   VVZOCH  = ("Home Menu", FF0RxM, [])
   VVwqYz  = None #("Check & Filter" , boundFunction(self.filterPortalAuthorizedServers, path), [])
   VVzhrG = ("Edit File" , boundFunction(self.VVLgnN, path) , [])
   VVRjvg  = ("Select"  , self.VVh0bB_fromMacFiles   , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVxqTz  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVL8CA = FFsX1L(self, None, title=title, header=header, VVbKpp=VVuEpa, VVxqTz=VVxqTz, VVRSoy=widths, VVA2Pa=26, VVRjvg=VVRjvg, VVZOCH=VVZOCH, VVzhrG=VVzhrG, VVwqYz=VVwqYz, VVslef="#0a001111", VV7O11="#0a001122", VVPOXl="#0a001122", VVfU42="#00000000", VVuZx4=True, searchCol=1)
   if not VVsXZs:
    FFU79C(VVL8CA, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVsXZs:
    FFGr6w(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVh0bB_fromMacFiles(self, VVL8CA, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVh0bB(VVL8CA, url, mac)
 def VVLgnN(self, path, VVL8CA, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCk6mL(self, path, VV6vg0=boundFunction(self.VVcgfm, VVL8CA), curRowNum=rowNum)
  else    : FFI53L(self, path)
 def VVcgfm(self, VVL8CA, fileChanged):
  if fileChanged:
   VVL8CA.cancel()
 def VVLhwq(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFUzJZ(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVGFm1(self):
  if self.VVbI5I():
   VVwdxM  = self.VVnSrn()
   OKBtnFnc = self.VVu1ze
   VVC269 = ("Home Menu", FF0RxM)
   FFsmMG(self, None, title="Portal Resources (MAC=%s)" % self.VVuxRB, VVwdxM=VVwdxM, OKBtnFnc=OKBtnFnc, VVC269=VVC269)
 def VVu1ze(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFa70X(menuInstance, boundFunction(self.VVglAT, mode), title="Reading Categories ...")
   else : FFa70X(menuInstance, boundFunction(self.VVW0nf, menuInstance, title), title="Reading Account ...")
 def VVW0nf(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVS7bu(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVuxRB)
  VVZOCH  = ("Home Menu" , FF0RxM, [])
  if totCols == 2:
   VVwqYz = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
   VVwqYz = ("More Info.", boundFunction(self.VVyTT3, menuInstance) , [])
  FFsX1L(self, None, title=title, width=1200, header=header, VVbKpp=rows, VVRSoy=widths, VVA2Pa=26, VVZOCH=VVZOCH, VVwqYz=VVwqYz, VVslef="#0a00292B", VV7O11="#0a002126", VVPOXl="#0a002126", VVfU42="#00000000", searchCol=searchCol)
 def VVyTT3(self, menuInstance, VVL8CA, title, txt, colList):
  VVL8CA.cancel()
  FFa70X(menuInstance, boundFunction(self.VVW0nf, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVglAT(self, mode):
  token, profile = self.VVqe1M()
  if not token:
   return
  res, err = self.VVj6yW(self.VVCwHU(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CCFutt()
     chList = tDict["js"]
     for item in chList:
      Id   = CCjXCp.VVpazX(item, "id"       )
      Title  = CCjXCp.VVpazX(item, "title"      )
      censored = CCjXCp.VVpazX(item, "censored"     )
      Title = processChanName.VVYxt0(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVvPtm:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVOQFL(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVslef, VV7O11, VVPOXl, VVfU42 = self.VV0qey(mode)
   mName = self.VVOQFL(mode)
   VVRjvg   = ("Show List"  , boundFunction(self.VVtQyJ, mode) , [])
   VVZOCH  = ("Home Menu"   , FF0RxM         , [])
   if mode in ("vod", "series"):
    VVzhrG = ("Find in %s" % mName , boundFunction(self.VVmJtG, mode), [])
   else:
    VVzhrG = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFsX1L(self, None, title=title, width=1200, header=header, VVbKpp=list, VVRSoy=widths, VVA2Pa=30, VVZOCH=VVZOCH, VVzhrG=VVzhrG, VVRjvg=VVRjvg, VVslef=VVslef, VV7O11=VV7O11, VVPOXl=VVPOXl, VVfU42=VVfU42)
  else:
   FFGr6w(self, "Could not get Categories from server!", title=title)
 def VVLYnM(self, mode, VVL8CA, title, txt, colList):
  FFa70X(VVL8CA, boundFunction(self.VVqC4l, mode, VVL8CA, title, txt, colList), title="Downloading ...")
 def VVqC4l(self, mode, VVL8CA, title, txt, colList):
  token, profile = self.VVqe1M()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVj6yW(self.VV5j21(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCjXCp.VVpazX(item, "id"    )
      actors   = CCjXCp.VVpazX(item, "actors"   )
      added   = CCjXCp.VVpazX(item, "added"   )
      age    = CCjXCp.VVpazX(item, "age"   )
      category_id  = CCjXCp.VVpazX(item, "category_id" )
      description  = CCjXCp.VVpazX(item, "description" )
      director  = CCjXCp.VVpazX(item, "director"  )
      genres_str  = CCjXCp.VVpazX(item, "genres_str"  )
      name   = CCjXCp.VVpazX(item, "name"   )
      path   = CCjXCp.VVpazX(item, "path"   )
      screenshot_uri = CCjXCp.VVpazX(item, "screenshot_uri" )
      series   = CCjXCp.VVpazX(item, "series"   )
      cmd    = CCjXCp.VVpazX(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VVRjvg  = ("Play"  , boundFunction(self.VViWGm, mode, False)      , [])
   VVCijI = (""   , boundFunction(self.VVb7p5, mode)      , [])
   VVZOCH = ("Home Menu" , FF0RxM                , [])
   VVcGuB = ("Download PIcons" , boundFunction(self.VVPAMH, mode)      , [])
   VVzhrG = ("Add ALL to Bouquet" , boundFunction(self.VVjk1y, mode, seriesName) , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVxqTz  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFsX1L(self, None, title=seriesName, width=1200, header=header, VVbKpp=list, VVxqTz=VVxqTz, VVRSoy=widths, VVA2Pa=26, VVZOCH=VVZOCH, VVcGuB=VVcGuB, VVzhrG=VVzhrG, VVRjvg=VVRjvg, VVCijI=VVCijI, VVslef="#0a00292B", VV7O11="#0a002126", VVPOXl="#0a002126", VVfU42="#00000000")
  else:
   FFGr6w(self, "Could not get Episodes from server!", title=seriesName)
 def VVmJtG(self, mode, VVL8CA, title, txt, colList):
  VVwdxM = []
  VVwdxM.append(("Keyboard"  , "manualEntry"))
  VVwdxM.append(("From Filter" , "fromFilter"))
  FFsmMG(self, boundFunction(self.VVQStC, VVL8CA, mode), title="Input Type", VVwdxM=VVwdxM, width=400)
 def VVQStC(self, VVL8CA, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFK1qA(self, boundFunction(self.VVOvYK, VVL8CA, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCCU6U(self)
    filterObj.VVbVqV(boundFunction(self.VVOvYK, VVL8CA, mode))
 def VVOvYK(self, VVL8CA, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VVz4yK(mode, searchName)
   if len(searchName) < 3:
    FFGr6w(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CCFutt()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVvo6G([searchName]):
     FFGr6w(self, processChanName.VVyLDE(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVHEbe(mode, searchName, "", searchName)
 def VVtQyJ(self, mode, VVL8CA, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVHEbe(mode, bName, catID, "")
 def VVHEbe(self, mode, bName, catID, searchName):
  self.session.open(CCu37C, barTheme=CCu37C.VVqL20
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVuXe7, mode, bName, catID, searchName)
      , VV6vg0 = boundFunction(self.VV7TUk, mode, bName, catID, searchName))
 def VV7TUk(self, mode, bName, catID, searchName, VVsXZs, VVuEpa, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVz4yK(mode, searchName)
  else   : title = "%s : %s" % (self.VVOQFL(mode), bName)
  if VVuEpa:
   if mode == "series":
    VVslef, VV7O11, VVPOXl, VVfU42 = self.VV0qey("series2")
    VVRjvg  = ("Episodes", boundFunction(self.VVLYnM, mode) , [])
    VVcGuB = None
    VVzhrG = None
   else:
    VVslef, VV7O11, VVPOXl, VVfU42 = self.VV0qey("")
    VVRjvg  = ("Play"    , boundFunction(self.VViWGm, mode, False)   , [])
    VVcGuB = ("Download PIcons" , boundFunction(self.VVPAMH, mode)     , [])
    VVzhrG = ("Add ALL to Bouquet" , boundFunction(self.VVjk1y, mode, bName) , [])
   VVCijI = (""      , boundFunction(self.VVRRsa, mode)    , [])
   VVZOCH = ("Home Menu"    , FF0RxM             , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VVxqTz  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , CENTER)
   VVL8CA = FFsX1L(self, None, title=title, header=header, VVbKpp=VVuEpa, VVxqTz=VVxqTz, VVRSoy=widths, VVA2Pa=26, VVZOCH=VVZOCH, VVcGuB=VVcGuB, VVzhrG=VVzhrG, VVRjvg=VVRjvg, VVCijI=VVCijI, VVslef=VVslef, VV7O11=VV7O11, VVPOXl=VVPOXl, VVfU42=VVfU42, VVuZx4=True, searchCol=1)
   if not VVsXZs:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVL8CA.VVdR5e(VVL8CA.VV1hep() + tot)
    if threadErr: FFU79C(VVL8CA, "Error while reading !", 2000)
    else  : FFU79C(VVL8CA, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFGr6w(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFGr6w(self, "Could not get list from server !", title=title)
 def VVRRsa(self, mode, VVL8CA, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFASWh(self, fncMode=CCAHNs.VVv5nB, portalHost=self.VV5Dls, portalMac=self.VVuxRB, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVq9of(mode, VVL8CA, title, txt, colList)
 def VVb7p5(self, mode, VVL8CA, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFY8RM(colList[10], VVea45)
  txt += "Description:\n%s" % FFY8RM(colList[11], VVea45)
  self.VVq9of(mode, VVL8CA, title, txt, colList)
 def VVq9of(self, mode, VVL8CA, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVu9cp(mode, colList)
  refCode, chUrl = self.VVfD4I(self.VV5Dls, self.VVuxRB, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFASWh(self, fncMode=CCAHNs.VV879d, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVuXe7(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile = self.VVqe1M()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVuEpa, total_items, max_page_items, err = self.VVuE6r(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVuEpa and total_items > -1 and max_page_items > -1:
    progBarObj.VVx354(total_items)
    progBarObj.VVW1AW(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVuE6r(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VVUlM3()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVuEpa += list
      progBarObj.VVW1AW(len(list), True)
  except:
   pass
 def VVuE6r(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url =self.VVxYzh(mode, searchName, page)
  else   : url =self.VVvJTI(mode, catID, page)
  res, err = self.VVj6yW(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVLue5(CCjXCp.VVpazX(item, "total_items" ))
     max_page_items = self.VVLue5(CCjXCp.VVpazX(item, "max_page_items" ))
     processChanName = CCFutt()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCjXCp.VVpazX(item, "id"    )
      name   = CCjXCp.VVpazX(item, "name"   )
      tv_genre_id  = CCjXCp.VVpazX(item, "tv_genre_id" )
      number   = CCjXCp.VVpazX(item, "number"   ) or str(counter)
      logo   = CCjXCp.VVpazX(item, "logo"   )
      screenshot_uri = CCjXCp.VVpazX(item, "screenshot_uri" )
      cmd    = CCjXCp.VVpazX(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      if mode == "itv" and not cmdStr in cmd:
       span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
      picon   = logo or screenshot_uri
      counter += 1
      name = processChanName.VVpYaJ(name)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVjk1y(self, mode, bName, VVL8CA, title, txt, colList):
  FFa70X(VVL8CA, boundFunction(self.VVCT5P, mode, bName, VVL8CA, title, txt, colList), title="Adding Channels ...")
 def VVCT5P(self, mode, bName, VVL8CA, title, txt, colList):
  bNameFile = CCjXCp.VVGerw(bName)
  num  = 0
  path = VVeRDn + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVeRDn + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVL8CA.VVD696():
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVu9cp(mode, row)
    refCode, chUrl = self.VVfD4I(self.VV5Dls, self.VVuxRB, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
    totChange += 1
  FFFX33(os.path.basename(path))
  self.VVdFPU(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVLue5(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VViWGm(self, mode, fromPlayer, VVL8CA, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVu9cp(mode, colList)
  refCode, chUrl = self.VVfD4I(self.VV5Dls, self.VVuxRB, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if fromPlayer:
   self.VVCKdN(mode, VVL8CA, chUrl)
  elif self.VVywit(chName):
   FFU79C(VVL8CA, "This is a marker!", 300)
  else:
   FFa70X(VVL8CA, boundFunction(self.VVCKdN, mode, VVL8CA, chUrl), title="Playing ...")
 def VVCKdN(self, mode, VVL8CA, chUrl):
  FFsOcb(self, chUrl, VVuw4l=False)
  self.session.open(CChh4T, portalTableParam=(self, VVL8CA, mode))
 def VVu9cp(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName, catID, stID, chNum, chCm, serCode, serId, picUrl
class CCjXCp(Screen, CCXYjf):
 VVfk9C = 0
 VVki9A = 1
 VVLvW5 = 2
 VV2SxV = 3
 VVhArH  = 4
 VVHx6a  = 5
 VVrxkf  = 6
 VVNepB  = 7
 VVwh38   = 8
 VV7S2m  = 9
 VViJOy  = 10
 VVphSh  = 11
 VVczYd  = 12
 VV1cQi   = 13
 VVG5xu   = 14
 VVkJs6   = 15
 VV1IPq   = 16
 VVIZMC   = 17
 VVYt9L    = 0
 VVhDEg   = 1
 VV7FRI   = 2
 VVFo24   = 3
 VVkO7S  = 4
 VVinSE  = 5
 VVUL5B   = 6
 VVWQ86   = 7
 VVRotG  = 8
 VVblUo  = 9
 VVSFwu  = 10
 def __init__(self, session):
  self.skin, self.skinParam = FFFsgK(VVQV0S, 1000, 1050, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.VVL8CA  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVI6UfData  = {}
  self.lastFindIptvName = ""
  CCXYjf.__init__(self)
  VVwdxM= self.VV1nlY()
  FFKXoA(self, title="IPTV", VVwdxM=VVwdxM)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  FFfopI(self["myMenu"])
  FFwO6z(self)
  FFeXHw(self)
 def VV1nlY(self):
  files = self.VV7RzG()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"    , "VVI6Uf_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal File)"    , "VVI6Uf_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U File)"     , "VVI6Uf_fromM3u"  ))
  qUrl, iptvRef = self.VV11bg()
  if qUrl:
   tList.append(("IPTV Server Browser (from Current Channel)"  , "VVI6Uf_fromCurrChan" ))
  VVwdxM = []
  if files:
   if self.VVL8CA:
    VVwdxM.append(("Add Current List to a New Bouquet"      , "VVdOj0"  ))
    VVwdxM.append(VVWygA)
    VVwdxM.append(("Change Current List References to Unique Codes"   , "VVuD3j"))
    VVwdxM.append(("Change Current List References to Identical Codes"  , "VV6I4H_rows" ))
    VVwdxM.append(VVWygA)
    VVwdxM.append(("Share Reference with Satellite/C/T Service (manual entry)", "VV2eHt"   ))
    VVwdxM.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VVLmpb"   ))
   else:
    VVwdxM += tList
    VVwdxM.append(VVWygA)
    VVwdxM.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    if qUrl:
     VVwdxM.append(VVWygA)
     VVwdxM.append(("Update Current Bouquet EPG (from IPTV Server)"  , "refreshIptvEPG"   ))
    VVwdxM.append(VVWygA)
    VVwdxM.append(("Count Available IPTV Channels"       , "VVrvtx"    ))
    VVwdxM.append(("Check Reference Codes Format"        , "VVLeMY"   ))
    VVwdxM.append(("Check System Acceptable Reference Types"     , "VVMN4y"   ))
    VVwdxM.append(VVWygA)
    VVwdxM.append(("Share Reference with Sat./C/T (Only Matching Names)"  , "VVZaAb" ))
    VVwdxM.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVhumR"  ))
    VVwdxM.append(("Change ALL References to Unique Codes"     , "VVnAYx" ))
    VVwdxM.append(("Change ALL References to Identical Codes"     , "VV6I4H_all" ))
  if not self.VVL8CA:
   if not files:
    VVwdxM += tList
   VVwdxM.append(VVWygA)
   VVwdxM.append(("M3U Files Tools ..."           , "VVPAkf"   ))
   VVwdxM.append(VVWygA)
   VVwdxM.append(("Reload Channels and Bouquets"         , "VVHj3z"   ))
  return VVwdxM
 def VVp9Al(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   if   item == "VVdOj0"   : FFK1qA(self, self.VVdOj0, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVuD3j" : FFIxs9(self, boundFunction(FFa70X, self.VVL8CA, self.VVuD3j ), "Change Current List References to Unique Codes ?")
   elif item == "VV6I4H_rows" : FFIxs9(self, boundFunction(FFa70X, self.VVL8CA, self.VV6I4H   ), "Change Current List References to Identical Codes ?")
   elif item == "VV2eHt"   : self.VV2eHt(tTitle)
   elif item == "VVLmpb"   : self.VVLmpb(tTitle)
   elif item == "VVI6Uf_fromPlayList" : FFa70X(self, boundFunction(self.VVEFaC, True), title="Searching ...")
   elif item == "VVI6Uf_fromM3u"  : FFa70X(self, boundFunction(self.VVFe4o, 0), title="Searching ...")
   elif item == "VVI6Uf_fromMac"  : self.VVuatv()
   elif item == "VVI6Uf_fromCurrChan" : self.VVh0bB_fromCurrChan()
   elif item == "iptvTable_live"   : FFa70X(self, boundFunction(self.VVrKc1, self.VVNepB ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFa70X(self, boundFunction(self.VVrKc1, self.VVfk9C) , title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VVS5B9()
   elif item == "VVrvtx"    : FFa70X(self, self.VVrvtx)
   elif item == "VVLeMY"    : FFa70X(self, self.VVLeMY)
   elif item == "VVMN4y"   : FFa70X(self, self.VVMN4y)
   elif item == "VVZaAb"  : FFIxs9(self, boundFunction(FFa70X, self, self.VVZaAb ), "Continue ?")
   elif item == "VVhumR"  : self.VVhumR()
   elif item == "VVnAYx" : FFIxs9(self, boundFunction(FFa70X, self, self.VVnAYx ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VV6I4H_all" : FFIxs9(self, boundFunction(FFa70X, self, self.VV6I4H  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "VVPAkf"   : self.VVPAkf()
   elif item == "VVHj3z"   : FFa70X(self, boundFunction(CCVPCx.VVHj3z, self))
 def VVPAkf(self):
  VVwdxM = []
  VVwdxM.append(("Analyse m3u File"            , "VV0tQD"   ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Convert m3u File to Bouquet (from File Manager)"    , "VVWuBL" ))
  VVwdxM.append(("Convert m3u File to Bouquet (from m3u File List)"    , "VV4K5i" ))
  VVwdxM.append(('Convert m3u File to Bouquet (Download from "Play Lists")'  , "VVUXnh" ))
  FFsmMG(self, self.VVFX17, title="M3U Files Tools", VVwdxM=VVwdxM)
 def VVFX17(self, item):
  if item is not None:
   t = "Searching ..."
   if   item == "VV0tQD"   : FFa70X(self, boundFunction(self.VVFe4o, 1), title="Searching ...")
   elif item == "VVWuBL" : self.VVWuBL()
   elif item == "VV4K5i" : FFa70X(self, boundFunction(self.VVFe4o, 2), title=t)
   elif item == "VVUXnh" : FFa70X(self, boundFunction(self.VVEFaC, False), title=t)
 def VVPtX0(self):
  global VVEipR
  VVEipR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVp9Al(item)
 def VVrKc1(self, mode):
  VV2XDg = self.VVklyG(mode)
  if VV2XDg:
   VVcGuB = ("Current Service", self.VVw5mH    , [])
   VVzhrG = ("Options"  , self.VVgqbK      , [])
   VVwqYz = ("Filter"   , self.VVtZ86       , [])
   VVRjvg  = ("Play"   , boundFunction(self.VVMmwq, False) , [])
   VVCijI = (""    , self.VVO9eT       , [])
   VVRExa = (""    , self.VV1XbQ        , [])
   VV3Ab1 = (""    , self.VVldUS       , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVxqTz  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFsX1L(self, None, header=header, VVbKpp=VV2XDg, VVxqTz=VVxqTz, VVRSoy=widths, VVA2Pa=26
     , VVRjvg=VVRjvg, VVcGuB=VVcGuB, VVzhrG=VVzhrG, VVwqYz=VVwqYz, VVCijI=VVCijI, VVRExa=VVRExa
     , VVslef="#0a00292B", VV7O11="#0a002126", VVPOXl="#0a002126", VVfU42="#00000000", VVuZx4=True, searchCol=1)
  else:
   if mode == self.VVNepB: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFGr6w(self, err)
 def VV1XbQ(self, VVL8CA, title, txt, colList):
  self.VVL8CA = VVL8CA
 def VVldUS(self, VVL8CA):
  self.VVL8CA = None
 def VVgqbK(self, VVL8CA, title, txt, colList):
  VVwdxM= self.VV1nlY()
  FFsmMG(self, self.VVp9Al, title="IPTV Tools", VVwdxM=VVwdxM)
 def VVtZ86(self, VVL8CA, title, txt, colList):
  VVwdxM = []
  VVwdxM.append(("All"         , "all"   ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Prefix of Selected Channel"   , "sameName" ))
  VVwdxM.append(("Suggest Words from Selected Channel" , "partName" ))
  VVwdxM.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Live TV"        , "live"  ))
  VVwdxM.append(("VOD"         , "vod"   ))
  VVwdxM.append(("Series"        , "series"  ))
  VVwdxM.append(("Uncategorised"      , "uncat"  ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Video"        , "video"  ))
  VVwdxM.append(("Audio"        , "audio"  ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("MKV"         , "MKV"   ))
  VVwdxM.append(("MP4"         , "MP4"   ))
  VVwdxM.append(("MP3"         , "MP3"   ))
  VVwdxM.append(("AVI"         , "AVI"   ))
  VVwdxM.append(("FLV"         , "FLV"   ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVjuj3()
  if bNames:
   bNames.sort()
   VVwdxM.append(VVWygA)
   for item in bNames:
    VVwdxM.append((item, "__b__" + item))
  filterObj = CCCU6U(self)
  filterObj.VVdaeQ(VVwdxM, VVwdxM, boundFunction(self.VV0wO5, VVL8CA))
 def VV0wO5(self, VVL8CA, item=None):
  prefix = VVL8CA.VVt0P4(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVfk9C, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVki9A , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVLvW5 , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VV2SxV , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVNepB  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVwh38   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VV7S2m  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VViJOy  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVphSh  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVczYd  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VV1cQi   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVG5xu   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVkJs6   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VV1IPq   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVIZMC   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVrxkf  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVhArH  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVHx6a  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVLvW5:
   VVwdxM = []
   chName = VVL8CA.VVt0P4(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVwdxM.append((item, item))
    if not VVwdxM and chName:
     VVwdxM.append((chName, chName))
    FFsmMG(self, boundFunction(self.VVWUbP_partOfName, title), title="Words from Current Selection", VVwdxM=VVwdxM)
   else:
    VVL8CA.VV5Ruh("Invalid Channel Name")
  else:
   words, asPrefix = CCCU6U.VVAvaW(words)
   if not words and mode in (self.VVhArH, self.VVHx6a):
    FFU79C(self.VVL8CA, "Incorrect filter", 2000)
   else:
    FFa70X(self.VVL8CA, boundFunction(self.VV8wEk, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVWUbP_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFa70X(self.VVL8CA, boundFunction(self.VV8wEk, self.VVLvW5, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VV7Izq(txt):
  return "#f#11ffff00#" + txt
 def VV8wEk(self, mode, words, asPrefix, title):
  VV2XDg = self.VVklyG(mode=mode, words=words, asPrefix=asPrefix)
  if VV2XDg : self.VVL8CA.VVn17k(VV2XDg, title)
  else  : self.VVL8CA.VV5Ruh("Not found")
 def VVklyG(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VV2XDg = []
  files  = self.VV7RzG()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFaq7Y(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVBcUD = span.group(1)
    else : VVBcUD = ""
    VVBcUD_lCase = VVBcUD.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVywit(chName): chNameMod = self.VV7Izq(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVBcUD, chType, refCode, url)
     ok = False
     tUrl = FF5GG1(url).lower()
     if mode == self.VVfk9C       : ok = True
     elif mode == self.VVrxkf       : ok = True
     elif mode == self.VVphSh:
      if CCjXCp.VVcHfY(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVczYd:
      if CCjXCp.VVcHfY(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVNepB:
      if CCjXCp.VVcHfY(tUrl, compareType="live")  : ok = True
     elif mode == self.VVwh38:
      if CCjXCp.VVcHfY(tUrl, compareType="movie") : ok = True
     elif mode == self.VV7S2m:
      if CCjXCp.VVcHfY(tUrl, compareType="series") : ok = True
     elif mode == self.VViJOy:
      if CCjXCp.VVcHfY(tUrl, compareType="")   : ok = True
     elif mode == self.VV1cQi:
      if CCjXCp.VVcHfY(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVG5xu:
      if CCjXCp.VVcHfY(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVkJs6:
      if CCjXCp.VVcHfY(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VV1IPq:
      if CCjXCp.VVcHfY(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVIZMC:
      if CCjXCp.VVcHfY(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVki9A:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVLvW5:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VV2SxV:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVhArH:
      if words[0] == VVBcUD_lCase:
       ok = True
     elif mode == self.VVHx6a:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VV2XDg.append(row)
      chNum += 1
  if VV2XDg and mode == self.VVrxkf:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VV2XDg)
   for item in VV2XDg:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VV2XDg = newRows
  return VV2XDg
 def VVdOj0(self, bName):
  if bName:
   FFa70X(self.VVL8CA, boundFunction(self.VVMXK6, bName), title="Adding Channels ...")
 def VVMXK6(self, bName):
  num = 0
  path = VVeRDn + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVeRDn + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVL8CA.VVD696():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFaO74(row[1]))
    totChange += 1
  FFFX33(os.path.basename(path))
  self.VVdFPU(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVhumR(self):
  txt = "Stream Type "
  VVwdxM = []
  VVwdxM.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVwdxM.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVwdxM.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVwdxM.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVwdxM.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVwdxM.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFsmMG(self, self.VVERSR, title="Change Reference Types to:", VVwdxM=VVwdxM)
 def VVERSR(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVnYSe("1"   )
   elif item == "RT_4097" : self.VVnYSe("4097")
   elif item == "RT_5001" : self.VVnYSe("5001")
   elif item == "RT_5002" : self.VVnYSe("5002")
   elif item == "RT_8192" : self.VVnYSe("8192")
   elif item == "RT_8193" : self.VVnYSe("8193")
 def VVnYSe(self, rType):
  FFIxs9(self, boundFunction(FFa70X, self, boundFunction(self.VV2ZmP, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VV2ZmP(self, refType):
  totChange = 0
  files  = self.VV7RzG()
  if files:
   for path in files:
    txt = FFaq7Y(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFFX33(os.path.basename(path))
  self.VVdFPU(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVrvtx(self):
  totFiles = 0
  files  = self.VV7RzG()
  if files:
   totFiles = len(files)
  totChans = 0
  VV2XDg = self.VVklyG()
  if VV2XDg:
   totChans = len(VV2XDg)
  FFMt3I(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVLeMY(self):
  files  = self.VV7RzG()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFaq7Y(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVI0dy
   else    : color = VVBEBZ
   totInvalid = FFY8RM(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFY8RM("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFMt3I(self, txt, title="Check IPTV References")
 def VVMN4y(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVeRDn + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFFX33(os.path.basename(path))
  FFjOTm()
  acceptedList = []
  VVaUDr = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVaUDr:
   VVDIAQ = FFoqwI(VVaUDr)
   if VVDIAQ:
    for service in VVDIAQ:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVeRDn + userBName
  bFile = VVeRDn + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFoKN8("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFoKN8("rm -f '%s'" % path)
  os.system(cmd)
  FFjOTm()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVI0dy
    else     : res, color = "No" , VVBEBZ
    txt += "    %s\t: %s\n" % (item, FFY8RM(res, color))
   FFMt3I(self, txt, title=title)
  else:
   txt = FFGr6w(self, "Could not complete the test on your system!", title=title)
 def VVZaAb(self):
  lameDbChans = CCVPCx.VV2CvK(self, CCVPCx.VVKu9g)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VV7RzG():
    toSave = False
    txt = FFaq7Y(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVdFPU(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFGr6w(self, 'No channels in "lamedb" !')
 def VVnAYx(self):
  files  = self.VV7RzG()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFn8wV(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVYtdX(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVdFPU(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVuD3j(self):
  iptvRefList = []
  files  = self.VV7RzG()
  if files:
   for path in files:
    txt = FFaq7Y(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVL8CA.VVq0ms(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVYtdX(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VV7RzG()
  if files:
   for path in files:
    lines = FFn8wV(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVdFPU(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVYtdX(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VV6I4H(self):
  list = None
  if self.VVL8CA:
   list = []
   for row in self.VVL8CA.VVD696():
    list.append(row[4] + row[5])
  files  = self.VV7RzG()
  totChange = 0
  if files:
   for path in files:
    lines = FFn8wV(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVdFPU(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVdFPU(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFjOTm()
   if refreshTable and self.VVL8CA:
    VV2XDg = self.VVklyG()
    if VV2XDg and self.VVL8CA:
     self.VVL8CA.VVn17k(VV2XDg, self.tableTitle)
     self.VVL8CA.VV5Ruh(txt)
   FFMt3I(self, txt, title=title)
  else:
   FF6zpT(self, "No changes.")
 def VVjuj3(self):
  files = self.VV7RzG()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with open(path, "r") as f:
     span = iSearch(r"#NAME\s+(.*)", f.readline(), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VVcXkV = FF09hW()
    if VVcXkV:
     for b in VVcXkV:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VV7RzG(self):
  return CCjXCp.VVlkN6(self)
 @staticmethod
 def VVlkN6(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVeRDn + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFaq7Y(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVO9eT(self, VVL8CA, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FF5GG1(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFASWh(self, fncMode=CCAHNs.VVtO1g, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVMmwq(self, fromPlayer, VVL8CA, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  self.VVH8N3(fromPlayer, VVL8CA, chName, chUrl, "localIptv")
 def VVN87Z(self, mode, fromPlayer, VVL8CA, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVH6kx(mode, colList)
  self.VVH8N3(fromPlayer, VVL8CA, chName, chUrl, mode)
 def VVH8N3(self, fromPlayer, VVL8CA, chName, chUrl, playerFlag):
  chName = FFaO74(chName)
  if fromPlayer:
   self.VViOID(VVL8CA, chUrl, playerFlag)
  elif self.VVywit(chName):
   FFU79C(VVL8CA, "This is a marker!", 300)
  else:
   FFa70X(VVL8CA, boundFunction(self.VViOID, VVL8CA, chUrl, playerFlag), title="Playing ...")
 def VViOID(self, VVL8CA, chUrl, playerFlag):
  FFsOcb(self, chUrl, VVuw4l=False)
  self.session.open(CChh4T, portalTableParam=(self, VVL8CA, playerFlag))
 @staticmethod
 def VVywit(chName):
  mark = ("--", "__", "==", "##", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVw5mH(self, VVL8CA, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(self)
  if refCode:
   bName = FFsqsH()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFQ7UT(refCode, origUrl, chName) }
   VVL8CA.VVh4rG_partial(colDict, VV17Wy=True)
 def VVWuBL(self):
  self.session.open(CCvQ2O)
  self.close()
 def VVFe4o(self, m3uMode):
  path = CCjXCp.VVKlGK()
  lines = FF0s0U("find %s %s -iname '*.m3u' | grep -i '.m3u'" % (path, FFl0r9(1)))
  if lines:
   lines.sort()
   VVwdxM = []
   for line in lines:
    VVwdxM.append((line, line))
   if   m3uMode == 0 : title = "Browse Server from M3U URLs"
   elif m3uMode == 1 : title = "Analyse M3U File"
   else    : title = "Convert M3U File to Bouquet"
   if m3uMode in [0, 2]: VVu6qN = ("All to Playlist", self.VVraH2)
   else    : VVu6qN = None
   OKBtnFnc = boundFunction(self.VVnTxg, m3uMode, title)
   VV0ixh = ("Show Full Path", self.VVXCFk)
   FFsmMG(self, None, title=title, VVwdxM=VVwdxM, OKBtnFnc=OKBtnFnc, VV0ixh=VV0ixh, VVu6qN=VVu6qN)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n\n%s" % path
   FFGr6w(self, 'No ".m3u" files found %s' % txt)
 def VVXCFk(self, VVyzEqObj, url):
  FFMt3I(self, url, title="Full Path")
 def VVnTxg(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if   m3uMode == 0 : FFa70X(menuInstance, boundFunction(self.VVEdfI, title, path))
   elif m3uMode == 1 : self.VV0tQD(title, path)
   else    : self.VV9ZCM(menuInstance, path)
 def VVraH2(self, VVyzEqObj, item=None):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVyzEqObj.VVwdxM):
    path = item[1]
    if fileExists(path):
     with open(path, "r") as f:
      for line in f:
       url = self.VVC2Jy(line)
       if url:
        if not url in pList : pList.append(url)
        else    : dupl += 1
        break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCjXCp.VVKlGK()
    if path == "/":
     path = CFG.exportedTablesPath.getValue()
    pListF = "%sPlaylist_%s.txt" % (FFgbrL(path), FF9n2A())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVyzEqObj.VVwdxM)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFMt3I(self, txt, title=title)
   else:
    FFGr6w(self, "Could not obtain URLs from this file list !", title=title)
 def VV0tQD(self, title, path):
  if fileExists(path):
   self.session.open(CCu37C, barTheme=CCu37C.VVcppe
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VVNrhZ, path)
       , VV6vg0 = boundFunction(self.VVzOwV, title, path))
  else:
   FFGr6w(SELF, "Cannot open file :\n\n%s" % path, title=title)
 def VVzOwV(self, title, path, VVsXZs, VVuEpa, threadCounter, threadTotal, threadErr):
  if VVsXZs:
   FFMt3I(self, VVuEpa, title=title)
 def VVNrhZ(self, path, progBarObj):
  totChan   = 0
  totLive   = 0
  totVod   = 0
  totSeries  = 0
  totUncat  = 0
  totVideo  = 0
  totAudio  = 0
  txt = FFaq7Y(path)
  lst = iFindall(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?((.+)(:[^:\/]+$)|.+)", txt, IGNORECASE)
  txt = ""
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVuEpa = ""
  progBarObj.VVx354(len(lst))
  for item in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVW1AW(1, True)
   totChan += 1
   chName  = item[0].strip()
   fullUrl  = item[1].strip()
   urlPart1 = item[2]
   if urlPart1 : tUrl = urlPart1
   else  : tUrl = fullUrl
   tUrl = FF5GG1(tUrl).lower()
   chType, host, username, password, streamId, chName = CCjXCp.VVcHfY(tUrl)
   if   chType == "live" : totLive += 1
   elif chType == "movie" : totVod += 1
   elif chType == "series" : totSeries += 1
   else     : totUncat += 1
   aud_vid = CCjXCp.VVcHfY(tUrl, getAudVid=True)
   if   aud_vid == "vid" : totVideo += 1
   elif aud_vid == "aud" : totAudio += 1
  txt = ""
  txt += FFY8RM("File:\n", VVVJBw)
  txt += "    %s\n"   % path
  txt += "\n"
  txt += FFY8RM("Channels:\n", VVVJBw)
  if lst:
   txt += "    Total\t: %d\n" % totChan
   txt += "\n"
   txt += FFY8RM("Category:\n", VVVJBw)
   txt += "    Live\t: %d\n" % totLive
   txt += "    VOD\t: %d\n" % totVod
   txt += "    Series\t: %d\n" % totSeries
   txt += "    Uncat.\t: %d\n" % totUncat
   txt += "\n"
   txt += FFY8RM("Content:\n", VVVJBw)
   txt += "    Video\t: %d\n" % totVideo
   txt += "    Audio\t: %d\n" % totAudio
   txt += "\n"
  else:
   txt += "    No channels  (or invalid file file format)"
  if progBarObj:
   progBarObj.VVuEpa = txt
 def VVEFaC(self, isBrowseServer):
  path = CCjXCp.VVKlGK()
  lines = FF0s0U('find %s %s -iname "*playlist*" | grep -i ".txt"' % (path, FFl0r9(1)))
  if lines:
   lines.sort()
   VVwdxM = []
   for line in lines:
    VVwdxM.append((line, line))
   OKBtnFnc = boundFunction(self.VVnSmG, isBrowseServer)
   FFsmMG(self, None, title="Select Playlist File", VVwdxM=VVwdxM, width=1200, OKBtnFnc=OKBtnFnc)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFGr6w(self, 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt)
 def VVnSmG(self, isBrowseServer, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFa70X(menuInstance, boundFunction(self.VVZFnH, menuInstance, path, isBrowseServer), title="Processing File ...")
 def VVZFnH(self, fileMenuInstance, path, isBrowseServer):
  VVwdxM = []
  lines = FFn8wV(path)
  for line in lines:
   line = line.strip()
   span = iSearch(r"(http.+php.+username=.+password=.+)(?:[&]+)*", line, IGNORECASE)
   if span:
    VVwdxM.append((span.group(1), span.group(1)))
   else:
    span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
    if span:
     host = FFgbrL(span.group(1).strip())
     user1 = span.group(2).strip()
     pass1 = span.group(3).strip()
     line = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
     VVwdxM.append((line, line))
  if VVwdxM:
   if isBrowseServer : title = "Select Server URL  (Total = %d)" % len(VVwdxM)
   else    : title = "Convert to Bouquet"
   OKBtnFnc  = boundFunction(self.VVpuHQ, isBrowseServer, title)
   VVC269  = ("Home Menu"  , FF0RxM)
   VV0ixh  = ("Show URL"  , self.VVJxJY)
   VVu6qN   = ("Check & Filter" , boundFunction(self.VVHMl1, fileMenuInstance, path, isBrowseServer))
   FFsmMG(self, None, title=title, VVwdxM=VVwdxM, width=1200, OKBtnFnc=OKBtnFnc, VVC269=VVC269, VV0ixh=VV0ixh, VVu6qN=VVu6qN)
  else:
   FFGr6w(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVJxJY(self, VVyzEqObj, url):
  FFMt3I(self, url, title="URL")
 def VVpuHQ(self, isBrowseServer, title, item=None):
  if item:
   menuInstance, txt, url, ndx = item
   if isBrowseServer:
    FFa70X(menuInstance, boundFunction(self.VVsFG0, title, url), title="Checking Server ...")
   else:
    FFIxs9(self, boundFunction(FFa70X, menuInstance, boundFunction(self.VVfDR0, menuInstance, url), title="Downloading ..."), "Download m3u file from this URL ?\n\n%s" % url, title=title)
 def VVfDR0(self, menuInstance, url):
  path, err = FFEUjD(url, "ajpanel_tmp.m3u", timeout=3)
  title = "Download Problem"
  if err:
   FFGr6w(self, err, title=title)
  else:
   if fileExists(path):
    txt = FFaq7Y(path)
    if '{"user_info":{"auth":0}}' in txt:
     FFGr6w(self, "Unauthorized", title=title)
     os.system(FFoKN8("rm -f '%s'" % path))
     return
   self.VV9ZCM(menuInstance, path)
 def VV2eHt(self, title):
  curChName = self.VVL8CA.VVt0P4(1)
  FFK1qA(self, boundFunction(self.VVr7tZ, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVr7tZ(self, title, name):
  if name:
   lameDbChans = CCVPCx.VV2CvK(self, CCVPCx.VVaQAp, VV2jrq=False, VVjy3R=False)
   list = []
   if lameDbChans:
    processChanName = CCFutt()
    name = processChanName.VVEmCF(name)
    ratio = "1"
    for item in lameDbChans:
     if name in item[0].lower():
      list.append((item[0], FFR1o4(item[2]), item[3], ratio))
   if list : self.VVosBL(list, title)
   else : FFGr6w(self, "Not found:\n\n%s" % name, title=title)
 def VVLmpb(self, title):
  curChName = self.VVL8CA.VVt0P4(1)
  self.session.open(CCu37C, barTheme=CCu37C.VVcppe
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVAuga
      , VV6vg0 = boundFunction(self.VV8IGq, title, curChName))
 def VVAuga(self, progBarObj):
  curChName = self.VVL8CA.VVt0P4(1)
  lameDbChans = CCVPCx.VV2CvK(self, CCVPCx.VVvDXQ, VV2jrq=False, VVjy3R=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVuEpa = []
  progBarObj.VVx354(len(lameDbChans))
  processChanName = CCFutt()
  curCh = processChanName.VVEmCF(curChName)
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CClRyV.VV3Fsm(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVW1AW(1, True)
   if ratio > 50:
    progBarObj.VVuEpa.append((chName, FFR1o4(sat), refCode.replace("_", ":"), str(ratio)))
 def VV8IGq(self, title, curChName, VVsXZs, VVuEpa, threadCounter, threadTotal, threadErr):
  if VVuEpa : self.VVosBL(VVuEpa, title)
  elif VVsXZs : FFGr6w(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVosBL(self, VV2XDg, title):
  curChName = self.VVL8CA.VVt0P4(1)
  curRefCode = self.VVL8CA.VVt0P4(4)
  curUrl  = self.VVL8CA.VVt0P4(5)
  VV2XDg = sorted(VV2XDg, key=lambda x: (100-int(x[3]), x[0].lower()))
  VVRjvg  = ("Share Sat/C/T Ref.", boundFunction(self.VVMAYJ, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFsX1L(self, None, title=title, header=header, VVbKpp=VV2XDg, VVRSoy=widths, VVA2Pa=26, VVRjvg=VVRjvg, VVslef="#0a00112B", VV7O11="#0a001126", VVPOXl="#0a001126", VVfU42="#00000000")
 def VVMAYJ(self, newtitle, curChName, curRefCode, curUrl, VVL8CA, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFIxs9(self.VVL8CA, boundFunction(FFa70X, self.VVL8CA, boundFunction(self.VVmq0k, VVL8CA, data)), ques, title=newtitle, VVuXa8=True)
 def VVmq0k(self, VVL8CA, data):
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  if curFullUrl and newFullUrl:
   for path in self.VV7RzG():
    txt = FFaq7Y(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFjOTm()
    newRow = []
    for i in range(6):
     newRow.append(self.VVL8CA.VVt0P4(i))
    newRow[4] = newRefCode
    done = self.VVL8CA.VVZZ5t(newRow)
    FF6zpT(self, "Done", title=title)
   else:
    FFGr6w(self, "Not found in IPTV files !", title=title)
  else:
   FFGr6w(self, "Could not read channel info !", title=title)
  VVL8CA.cancel()
 def VVHMl1(self, fileMenuInstance, path, isBrowseServer, urlMenuInstance, item):
  self.session.open(CCu37C, barTheme=CCu37C.VVcppe
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VVOJ9H, urlMenuInstance)
      , VV6vg0 = boundFunction(self.VVuiGO, fileMenuInstance, path, isBrowseServer, urlMenuInstance))
 def VVOJ9H(self, urlMenuInstance, progBarObj):
  progBarObj.VVx354(len(urlMenuInstance.VVwdxM))
  progBarObj.VVuEpa = []
  for ndx, item in enumerate(urlMenuInstance.VVwdxM):
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVW1AW(1, True)
   qUrl = self.VVwZyX(self.VVYt9L, item[0])
   txt, err = self.VVDihc(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVpazX(item, "auth") == "0":
       progBarObj.VVuEpa.append(qUrl)
    except:
     pass
 def VVuiGO(self, fileMenuInstance, path, isBrowseServer, urlMenuInstance, VVsXZs, VVuEpa, threadCounter, threadTotal, threadErr):
  if VVsXZs:
   list = VVuEpa
   title = "Authorized Servers"
   if list:
    totChk = len(urlMenuInstance.VVwdxM)
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FF9n2A()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVEFaC(isBrowseServer)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFY8RM(str(totAuth), VVI0dy)
     txt += "%s\n\n%s"     %  (FFY8RM("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFMt3I(self, txt, title=title)
     urlMenuInstance.close()
     fileMenuInstance.close()
    else:
     FF6zpT(self, "All URLs are authorized.", title=title)
   else:
    FFGr6w(self, "No authorized URL found !", title=title)
 def VV9ZCM(self, parentInstant, path):
  files = CCjXCp.VVlkN6(self, atLeastOne=True)
  if files: exitCurWin = False
  else : exitCurWin = True
  CCjXCp.VVBGRO(parentInstant, path, exitCurWin)
 @staticmethod
 def VVBGRO(SELF, path, exitCurWin):
  FFIxs9(SELF, boundFunction(FFa70X, SELF, boundFunction(CCjXCp.VVLNxD, SELF, path, exitCurWin), title="Converting ...")
    , "Convert file to bouquet ?\n\n%s" % path, title="Convert m3u file")
 @staticmethod
 def VVLNxD(SELF, path, exitCurWin):
  SID = TSID = ONID = 0
  MAX = 65535
  title = "Convert m3u File to Bouquet"
  if not fileExists(path):
   FFGr6w(SELF, "Cannot open file :\n\n%s" % path, title=title)
   return
  bName  = os.path.basename(path)
  bName  = os.path.splitext(bName)[0]
  bName   = CCjXCp.VVGerw(bName)
  bName  = "IPTV_" + bName
  bFileName = "userbouquet.%s.tv" % bName
  if fileExists(VVeRDn + bFileName):
   while True:
    SID += 1
    tmpBName = "%s_%d" % (bName, SID)
    bFileName = "userbouquet.%s.tv" % tmpBName
    if not fileExists(VVeRDn + bFileName):
     bName = tmpBName
     break
  txt = FFaq7Y(path)
  pattern = r"#EXTINF.+,(.+)\n(.+)"
  span = iSearch(r"#EXTINF.+,(.+)\n(.+)", txt, IGNORECASE)
  if span:
   with open(VVeRDn + bFileName, "w") as f:
    totChan = 0
    f.write("#NAME %s\n" % bName.replace("IPTV_", "IPTV - ", 1))
    for match in iFinditer(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?(.+)", txt, IGNORECASE):
     TSID += 1
     if TSID > MAX:
      TSID = MAX
      ONID += 1
      if ONID > MAX:
       ONID = 0
     chName = match.group(1).strip()
     url  = FFJxD2(match.group(2).strip())
     rType = CFG.iptvAddToBouquetRefType.getValue()
     refCode = "%s:0:1:%s:%s:%s:0:0:0:0:" % (rType, hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:])
     line1 = "#SERVICE %s%s\n" % (refCode.upper(), url)
     line2 = "#DESCRIPTION %s\n" % chName
     f.write(line1 + line2)
     totChan += 1
   FFFX33(bFileName)
   FFjOTm()
   FF6zpT(SELF, 'New Bouquet = %s\n\nTotal Channels = %d' % (bName, totChan), title=title)
  else:
   FFGr6w(SELF, "No channels found in file (or invalid file format) !\n\n%s" % path, title=title)
  if exitCurWin:
   SELF.close()
 @staticmethod
 def VVDihc(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVFmcI(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVcHfY(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = parts[1]
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVwZyX(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVFmcI(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVYt9L   : return "%s"            % url
  elif mode == self.VVhDEg   : return "%s&action=get_live_categories"     % url
  elif mode == self.VV7FRI   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVFo24  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVkO7S  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVinSE : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVUL5B   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVWQ86    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVRotG  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVSFwu : return "%s&action=get_live_streams"      % url
  elif mode == self.VVblUo  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVpazX(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FF5Ufp(int(val))
    elif is_base64 : val = FFUzJZ(val)
    elif isToHHMMSS : val = FFRq1D(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVEdfI(self, title, path):
  if fileExists(path):
   qUrl = ""
   with open(path, "r") as f:
    for line in f:
     qUrl = self.VVC2Jy(line)
     if qUrl:
      break
   if qUrl : self.VVsFG0(title, qUrl)
   else : FFGr6w(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFGr6w(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVh0bB_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VV11bg()
  if qUrl:
   host, mac, isPortalUrl = self.VVLhwq(iptvRef)
   if isPortalUrl:
    if host and mac : self.VVh0bB(self, host, mac)
    else   : FFGr6w(self, "Error in current channel URL/MAC !", title=title)
   else:
    FFa70X(self, boundFunction(self.VVsFG0, title, qUrl), title="Checking Server ...")
  else:
   FFGr6w(self, "Error in current channel URL !", title=title)
 def VV11bg(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(self)
  qUrl = self.VVC2Jy(decodedUrl)
  return qUrl, iptvRef
 def VVC2Jy(self, url):
  if url.startswith("#"):
   return ""
  url = url.lstrip(" /").rstrip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) >= 2 : return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else    : return ""
 def VVsFG0(self, title, url):
  self.VVI6UfData = {}
  qUrl = self.VVwZyX(self.VVYt9L, url)
  txt, err = self.VVDihc(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVI6UfData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVI6UfData["username"    ] = self.VVpazX(item, "username"        )
    self.VVI6UfData["password"    ] = self.VVpazX(item, "password"        )
    self.VVI6UfData["message"    ] = self.VVpazX(item, "message"        )
    self.VVI6UfData["auth"     ] = self.VVpazX(item, "auth"         )
    self.VVI6UfData["status"    ] = self.VVpazX(item, "status"        )
    self.VVI6UfData["exp_date"    ] = self.VVpazX(item, "exp_date"    , isDate=True )
    self.VVI6UfData["is_trial"    ] = self.VVpazX(item, "is_trial"        )
    self.VVI6UfData["active_cons"   ] = self.VVpazX(item, "active_cons"       )
    self.VVI6UfData["created_at"   ] = self.VVpazX(item, "created_at"   , isDate=True )
    self.VVI6UfData["max_connections"  ] = self.VVpazX(item, "max_connections"      )
    self.VVI6UfData["allowed_output_formats"] = self.VVpazX(item, "allowed_output_formats"    )
    lst = []
    key = "allowed_output_formats"
    if key in item:
     for item in item[key]:
      lst.append(str(item))
     self.VVI6UfData[key] = lst
    item = tDict["server_info"]
    self.VVI6UfData["url"    ] = self.VVpazX(item, "url"        )
    self.VVI6UfData["port"    ] = self.VVpazX(item, "port"        )
    self.VVI6UfData["https_port"  ] = self.VVpazX(item, "https_port"      )
    self.VVI6UfData["server_protocol" ] = self.VVpazX(item, "server_protocol"     )
    self.VVI6UfData["rtmp_port"   ] = self.VVpazX(item, "rtmp_port"       )
    self.VVI6UfData["timezone"   ] = self.VVpazX(item, "timezone"       )
    self.VVI6UfData["timestamp_now"  ] = self.VVpazX(item, "timestamp_now"  , isDate=True )
    self.VVI6UfData["time_now"   ] = self.VVpazX(item, "time_now"       )
    VVwdxM  = self.VVnSrn(True)
    OKBtnFnc = self.VVI6UfOptions
    VVC269 = ("Home Menu", FF0RxM)
    FFsmMG(self, None, title="IPTV Server Resources", VVwdxM=VVwdxM, OKBtnFnc=OKBtnFnc, VVC269=VVC269)
   else:
    err = "Could not get data from server !"
  if err:
   FFGr6w(self, err, title=title)
  FFU79C(self)
 def VVI6UfOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFa70X(menuInstance, boundFunction(self.VVhX71, self.VVhDEg  , title=title), title=wTxt)
   elif ref == "vod"   : FFa70X(menuInstance, boundFunction(self.VVhX71, self.VV7FRI  , title=title), title=wTxt)
   elif ref == "series"  : FFa70X(menuInstance, boundFunction(self.VVhX71, self.VVFo24 , title=title), title=wTxt)
   elif ref == "catchup"  : FFa70X(menuInstance, boundFunction(self.VVhX71, self.VVkO7S , title=title), title=wTxt)
   elif ref == "accountInfo" : FFa70X(menuInstance, boundFunction(self.VVwS17           , title=title), title=wTxt)
 def VVwS17(self, title):
  rows = []
  for key, val in self.VVI6UfData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VVZOCH = ("Home Menu", FF0RxM, [])
  header   = ("Num", "User/Server" , "Subject" , "Value" )
  widths   = (0 , 15   , 35  , 50  )
  FFsX1L(self, None, title=title, width=1200, header=header, VVbKpp=rows, VVRSoy=widths, VVA2Pa=26, VVZOCH=VVZOCH, VVslef="#0a00292B", VV7O11="#0a002126", VVPOXl="#0a002126", VVfU42="#00000000", searchCol=2)
 def VVmPCc(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CCFutt()
    if mode in (self.VVUL5B, self.VVblUo):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVpazX(item, "num"         )
      name     = self.VVpazX(item, "name"        )
      stream_id    = self.VVpazX(item, "stream_id"       )
      stream_icon    = self.VVpazX(item, "stream_icon"       )
      epg_channel_id   = self.VVpazX(item, "epg_channel_id"      )
      added     = self.VVpazX(item, "added"    , isDate=True )
      is_adult    = self.VVpazX(item, "is_adult"       )
      category_id    = self.VVpazX(item, "category_id"       )
      tv_archive    = self.VVpazX(item, "tv_archive"       )
      name = processChanName.VVpYaJ(name)
      if name:
       if mode == self.VVUL5B or mode == self.VVblUo and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVWQ86:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVpazX(item, "num"         )
      name    = self.VVpazX(item, "name"        )
      stream_id   = self.VVpazX(item, "stream_id"       )
      stream_icon   = self.VVpazX(item, "stream_icon"       )
      added    = self.VVpazX(item, "added"    , isDate=True )
      is_adult   = self.VVpazX(item, "is_adult"       )
      category_id   = self.VVpazX(item, "category_id"       )
      container_extension = self.VVpazX(item, "container_extension"     ) or "mp4"
      name = processChanName.VVpYaJ(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVRotG:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVpazX(item, "num"        )
      name    = self.VVpazX(item, "name"       )
      series_id   = self.VVpazX(item, "series_id"      )
      cover    = self.VVpazX(item, "cover"       )
      genre    = self.VVpazX(item, "genre"       )
      episode_run_time = self.VVpazX(item, "episode_run_time"    )
      category_id   = self.VVpazX(item, "category_id"      )
      container_extension = self.VVpazX(item, "container_extension"    ) or "mp4"
      name = processChanName.VVpYaJ(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVhX71(self, mode, title):
  cList, err = self.VVKQey(mode)
  if cList and mode == self.VVkO7S:
   cList = self.VV7ruc(cList)
  if err:
   FFGr6w(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVslef, VV7O11, VVPOXl, VVfU42 = self.VV0qey(mode)
   mName = self.VVOQFL(mode)
   if   mode == self.VVhDEg  : fMode = self.VVUL5B
   elif mode == self.VV7FRI  : fMode = self.VVWQ86
   elif mode == self.VVFo24 : fMode = self.VVRotG
   elif mode == self.VVkO7S : fMode = self.VVblUo
   if mode == self.VVkO7S:
    VVzhrG = None
   else:
    VVzhrG = ("Find in %s" % mName , boundFunction(self.VVDKAS, fMode) , [])
   VVRjvg   = ("Show List"   , boundFunction(self.VVoMdr, mode) , [])
   VVZOCH  = ("Home Menu"   , FF0RxM          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFsX1L(self, None, title=title, width=1200, header=header, VVbKpp=cList, VVRSoy=widths, VVA2Pa=30, VVZOCH=VVZOCH, VVzhrG=VVzhrG, VVRjvg=VVRjvg, VVslef=VVslef, VV7O11=VV7O11, VVPOXl=VVPOXl, VVfU42=VVfU42)
  else:
   FFGr6w(self, "No list from server !", title=title)
  FFU79C(self)
 def VVKQey(self, mode):
  qUrl  = self.VVwZyX(mode, self.VVI6UfData["playListURL"])
  txt, err = self.VVDihc(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    processChanName = CCFutt()
    for item in tDict:
     category_id  = self.VVpazX(item, "category_id"  )
     category_name = self.VVpazX(item, "category_name" )
     parent_id  = self.VVpazX(item, "parent_id"  )
     category_name = processChanName.VVYxt0(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VV7ruc(self, catList):
  mode  = self.VVblUo
  qUrl  = self.VVwZyX(mode, self.VVI6UfData["playListURL"])
  txt, err = self.VVDihc(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVmPCc(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVoMdr(self, mode, VVL8CA, title, txt, colList):
  title = colList[1]
  FFa70X(VVL8CA, boundFunction(self.VVFNFV, mode, VVL8CA, title, txt, colList), title="Downloading ...")
 def VVFNFV(self, mode, VVL8CA, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVOQFL(mode) + " : "+ bName
  if   mode == self.VVhDEg  : mode = self.VVUL5B
  elif mode == self.VV7FRI  : mode = self.VVWQ86
  elif mode == self.VVFo24 : mode = self.VVRotG
  elif mode == self.VVkO7S : mode = self.VVblUo
  qUrl  = self.VVwZyX(mode, self.VVI6UfData["playListURL"], catID)
  txt, err = self.VVDihc(qUrl)
  list  = []
  if not err and mode in (self.VVUL5B, self.VVWQ86, self.VVRotG, self.VVblUo):
   list, err = self.VVmPCc(mode, txt)
  if err:
   FFGr6w(self, err, title=title)
  elif list:
   VVZOCH  = ("Home Menu"   , FF0RxM             , [])
   if mode in (self.VVUL5B, self.VVblUo):
    VVslef, VV7O11, VVPOXl, VVfU42 = self.VV0qey(mode)
    VVCijI = (""     , boundFunction(self.VVZRoe, mode)     , [])
    VVcGuB = ("Download PIcons" , boundFunction(self.VVPAMH, mode)     , [])
    VVzhrG = ("Add ALL to Bouquet" , boundFunction(self.VVhuJV, mode, bName)  , [])
    if mode == self.VVUL5B:
     VVRjvg = ("Play"    , boundFunction(self.VVN87Z, mode, False)   , [])
    elif mode == self.VVblUo:
     VVRjvg  = ("Programs", boundFunction(self.VVnVw6, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVxqTz  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVWQ86:
    VVslef, VV7O11, VVPOXl, VVfU42 = self.VV0qey(mode)
    VVRjvg  = ("Play"    , boundFunction(self.VVN87Z, mode, False)  , [])
    VVCijI = (""     , boundFunction(self.VVZRoe, mode)    , [])
    VVcGuB = ("Download PIcons" , boundFunction(self.VVPAMH, mode)    , [])
    VVzhrG = ("Add ALL to Bouquet" , boundFunction(self.VVhuJV, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVxqTz  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVRotG:
    VVslef, VV7O11, VVPOXl, VVfU42 = self.VV0qey("series2")
    VVRjvg  = ("Show Seasons", boundFunction(self.VVvdDm, mode) , [])
    VVCijI = ("", boundFunction(self.VVK0ez, mode)  , [])
    VVcGuB = None
    VVzhrG = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVxqTz  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFsX1L(self, None, title=title, header=header, VVbKpp=list, VVxqTz=VVxqTz, VVRSoy=widths, VVA2Pa=26, VVRjvg=VVRjvg, VVZOCH=VVZOCH, VVcGuB=VVcGuB, VVzhrG=VVzhrG, VVCijI=VVCijI, VVslef=VVslef, VV7O11=VV7O11, VVPOXl=VVPOXl, VVfU42=VVfU42, VVuZx4=True, searchCol=1)
  else:
   FFGr6w(self, "No Channels found !", title=title)
  FFU79C(self)
 def VVnVw6(self, mode, bName, VVL8CA, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVI6UfData["playListURL"]
  ok_fnc  = boundFunction(self.VVcA8O, hostUrl, chName, catId, streamId)
  FFa70X(VVL8CA, boundFunction(CCjXCp.VVpasw, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVcA8O(self, chUrl, chName, catId, streamId, VVL8CA, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCjXCp.VVFmcI(chUrl)
   chNum = "333"
   refCode = CCjXCp.VVZNR2(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFsOcb(self, chUrl, VVuw4l=False)
   self.session.open(CChh4T)
  else:
   FFGr6w(self, "Incorrect Timestamp", pTitle)
 def VVvdDm(self, mode, VVL8CA, title, txt, colList):
  title = colList[1]
  FFa70X(VVL8CA, boundFunction(self.VVpOFx, mode, VVL8CA, title, txt, colList), title="Downloading ...")
 def VVpOFx(self, mode, VVL8CA, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVwZyX(self.VVinSE, self.VVI6UfData["playListURL"], series_id)
  txt, err = self.VVDihc(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVpazX(tDict["info"], "name"   )
      category_id = self.VVpazX(tDict["info"], "category_id" )
      icon  = self.VVpazX(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVpazX(EP, "id"     )
        episode_num   = self.VVpazX(EP, "episode_num"   )
        epTitle    = self.VVpazX(EP, "title"     )
        container_extension = self.VVpazX(EP, "container_extension" )
        seasonNum   = self.VVpazX(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFGr6w(self, err, title=title)
  elif list:
   VVZOCH = ("Home Menu"   , FF0RxM            , [])
   VVcGuB = ("Download PIcons" , boundFunction(self.VVPAMH , mode)   , [])
   VVzhrG = ("Add ALL to Bouquet" , boundFunction(self.VVhuJV, mode, title) , [])
   VVCijI = (""     , boundFunction(self.VVZRoe, mode)    , [])
   VVRjvg  = ("Play"    , boundFunction(self.VVN87Z, mode, False)  , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVxqTz  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFsX1L(self, None, title=title, header=header, VVbKpp=list, VVxqTz=VVxqTz, VVRSoy=widths, VVA2Pa=26, VVZOCH=VVZOCH, VVcGuB=VVcGuB, VVRjvg=VVRjvg, VVCijI=VVCijI, VVzhrG=VVzhrG, VVslef="#0a00292B", VV7O11="#0a002126", VVPOXl="#0a002126", VVfU42="#00000000")
  else:
   FFGr6w(self, "No Channels found !", title=title)
  FFU79C(self)
 def VVDKAS(self, mode, VVL8CA, title, txt, colList):
  VVwdxM = []
  VVwdxM.append(("Keyboard"  , "manualEntry"))
  VVwdxM.append(("From Filter" , "fromFilter"))
  FFsmMG(self, boundFunction(self.VVvSwW, VVL8CA, mode), title="Input Type", VVwdxM=VVwdxM, width=400)
 def VVvSwW(self, VVL8CA, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFK1qA(self, boundFunction(self.VViKys, VVL8CA, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCCU6U(self)
    filterObj.VVbVqV(boundFunction(self.VViKys, VVL8CA, mode))
 def VViKys(self, VVL8CA, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CCFutt()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVvo6G(words):
     FFGr6w(self, processChanName.VVyLDE(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CCu37C, barTheme=CCu37C.VVcppe
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VVnxXJ, VVL8CA, mode, title, words, toFind, asPrefix, processChanName)
         , VV6vg0 = boundFunction(self.VVOeEb, mode, toFind, title))
   else:
    FFGr6w(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVnxXJ(self, VVL8CA, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVx354(VVL8CA.VV5Kj3())
  progBarObj.VVuEpa = []
  for row in VVL8CA.VVD696():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVW1AW(1)
   progBarObj.VVcU8Y_fromIptvFind(catName)
   qUrl  = self.VVwZyX(mode, self.VVI6UfData["playListURL"], catID)
   txt, err = self.VVDihc(qUrl)
   if not err:
    tList, err = self.VVmPCc(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VVpYaJ(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVUL5B:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VVuEpa.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVWQ86:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VVuEpa.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVRotG:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VVuEpa.append((num, name, catID, ID, genre, catName, ext, cover))
 def VVOeEb(self, mode, toFind, title, VVsXZs, VVuEpa, threadCounter, threadTotal, threadErr):
  if VVuEpa:
   title = self.VVz4yK(mode, toFind)
   if mode == self.VVUL5B or mode == self.VVWQ86:
    bName   = CCjXCp.VVGerw(toFind)
    VVRjvg  = ("Play"     , boundFunction(self.VVN87Z, mode, False)  , [])
    VVzhrG = ("Add ALL to Bouquet" , boundFunction(self.VVhuJV, mode, bName) , [])
    VVcGuB = ("Download PIcons" , boundFunction(self.VVPAMH, mode)    , [])
   elif mode == self.VVRotG:
    VVRjvg  = ("Show Seasons"  , boundFunction(self.VVvdDm, mode)    , [])
    VVzhrG = None
    VVcGuB = None
   VVCijI = (""   , boundFunction(self.VVZRoe, mode) , [])
   VVZOCH = ("Home Menu" , FF0RxM         , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VVxqTz  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVL8CA = FFsX1L(self, None, title=title, header=header, VVbKpp=VVuEpa, VVxqTz=VVxqTz, VVRSoy=widths, VVA2Pa=26, VVRjvg=VVRjvg, VVZOCH=VVZOCH, VVcGuB=VVcGuB, VVzhrG=VVzhrG, VVCijI=VVCijI, VVslef="#0a00292B", VV7O11="#0a002126", VVPOXl="#0a002126", VVfU42="#00000000", VVuZx4=True, searchCol=1)
   if not VVsXZs:
    FFU79C(VVL8CA, "Stopped" , 1000)
  else:
   if VVsXZs:
    FFGr6w(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVH6kx(self, mode, colList):
  if mode in (self.VVUL5B, self.VVblUo):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVWQ86:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFaO74(chName)
  url = self.VVI6UfData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVFmcI(url)
  refCode = self.VVZNR2(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVZRoe(self, mode, VVL8CA, title, txt, colList):
  FFa70X(VVL8CA, boundFunction(self.VV61bb, mode, VVL8CA, title, txt, colList))
 def VV61bb(self, mode, VVL8CA, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVH6kx(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFASWh(self, fncMode=CCAHNs.VV3JtX, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVK0ez(self, mode, VVL8CA, title, txt, colList):
  FFa70X(VVL8CA, boundFunction(self.VVtN4j, mode, VVL8CA, title, txt, colList))
 def VVtN4j(self, mode, VVL8CA, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFASWh(self, fncMode=CCAHNs.VVUKMU, chName=name, text=txt, picUrl=Cover)
 def VVhuJV(self, mode, bName, VVL8CA, title, txt, colList):
  FFa70X(VVL8CA, boundFunction(self.VVlSId, mode, bName, VVL8CA, title, txt, colList), title="Adding Channels ...")
 def VVlSId(self, mode, bName, VVL8CA, title, txt, colList):
  url = self.VVI6UfData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVFmcI(url)
  bNameFile = CCjXCp.VVGerw(bName)
  num  = 0
  path = VVeRDn + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVeRDn + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVL8CA.VVD696():
    chName, chUrl, picUrl, refCode = self.VVH6kx(mode, row)
    f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
    f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
    totChange += 1
  FFFX33(os.path.basename(path))
  self.VVdFPU(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVPAMH(self, mode, VVL8CA, title, txt, colList):
  if os.system(FFoKN8("which ffmpeg")) == 0:
   self.session.open(CCu37C, barTheme=CCu37C.VVe8IQ
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VVipzg, VVL8CA, mode)
       , VV6vg0 = self.VVmrDM)
  else:
   FFIxs9(self, self.VVedoL, '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?')
 def VVmrDM(self, VVsXZs, VVuEpa, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVuEpa["proces"], VVuEpa["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVuEpa["ok"], VVuEpa["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVuEpa["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVuEpa["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVuEpa["badURL"]
  txt += "PIcons Path\t\t: %s\n"    % VVuEpa["path"]
  if not VVsXZs  : color = "#11402000"
  elif VVuEpa["err"]: color = "#11201000"
  else     : color = None
  if VVuEpa["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVuEpa["err"], txt)
  title = "PIcons Download Result"
  if not VVsXZs:
   title += "  (cancelled)"
  FFMt3I(self, txt, title=title, VVPOXl=color)
 def VVipzg(self, VVL8CA, mode, progBarObj):
  totRows = VVL8CA.VV5Kj3()
  progBarObj.VVx354(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CClRyV.VVvvid()
  progBarObj.VVuEpa = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for row in VVL8CA.VVD696():
    if progBarObj.isCancelled:
     break
    progBarObj.VVuEpa["proces"] += 1
    progBarObj.VVW1AW(1)
    if mode in ("itv", "vod", "series"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVu9cp(mode, row)
     refCode = CCjXCp.VVZNR2(catID, stID, chNum)
    else:
     chName, chUrl, picUrl, refCode = self.VVH6kx(mode, row)
    if picUrl:
     picon = refCode.replace(":", "_").rstrip("_") + ".png"
     if not fileExists(pPath + picon):
      progBarObj.VVuEpa["attempt"] += 1
      path, err = FFEUjD(picUrl, picon, timeout=1)
      if path:
       progBarObj.VVuEpa["ok"] += 1
       if FFM3im(path) > 0:
        cmd = ""
        if not mode == CCjXCp.VVUL5B:
         cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
        cmd += FFoKN8("mv -f '%s' '%s'" % (path, pPath)) + ";"
        os.system(cmd)
       else:
        progBarObj.VVuEpa["size0"] += 1
        os.system(FFoKN8("rm -f '%s'" % path))
      elif err:
       progBarObj.VVuEpa["fail"] += 1
       if any(x in err.lower() for x in ("time-out", "unauthorized")):
        progBarObj.VVuEpa["err"] = err.title()
        break
     else:
      progBarObj.VVuEpa["exist"] += 1
    else:
     progBarObj.VVuEpa["badURL"] += 1
  except:
   pass
 def VVedoL(self):
  cmd = FFS262(VV5AxC, "ffmpeg")
  if cmd : FFgQDF(self, cmd, title="Installing FFmpeg")
  else : FFQ7SS(self)
 def VVS5B9(self):
  self.session.open(CCu37C, barTheme=CCu37C.VVyp4b
      , titlePrefix = ""
      , fncToRun  = self.VVK7op
      , VV6vg0 = self.VVw6Bh)
 def VVK7op(self, progBarObj):
  bName = FFsqsH()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  progBarObj.VVuEpa = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = FFxolG()
  if not progBarObj or progBarObj.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   progBarObj.VVx354(totCh)
   for serv in services:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVW1AW(1)
    progBarObj.VVcU8Y_fromImportEPG(totEpgOK, uChName)
    fullRef  = serv[0]
    if FFba7t(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFn6Kh(fullRef)
     span = iSearch(r"(mode=.+end=)", fullRef, IGNORECASE)
     if span:
      m3u_Url = CCv1A9.VVgQEA(fullRef)
      uType, uHost, uUser, uPass, uId, uChName  = CCjXCp.VVcHfY(fullRef)
      uType, uHost, uUser, uPass, uId, uChName1 = CCjXCp.VVcHfY(m3u_Url)
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCjXCp.VVcHfY(m3u_Url)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCjXCp.VVIExZ(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCAHNs.VVsFOe(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
      else:
       pass
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if progBarObj:
     progBarObj.VVuEpa = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   progBarObj.VVuEpa = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VVw6Bh(self, VVsXZs, VVuEpa, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVuEpa
  title = "IPTV EPG Import"
  if err:
   FFGr6w(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFY8RM(str(totNotIptv), VVBEBZ)
    if totServErr : txt += "Server Errors\t: %s\n" % FFY8RM(str(totServErr) + t1, VVBEBZ)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFY8RM(str(totInv), VVBEBZ)
   if not VVsXZs:
    title += "  (stopped)"
   FFMt3I(self, txt, title=title)
 @staticmethod
 def VVIExZ(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCjXCp.VVFmcI(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCjXCp.VVDihc(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCjXCp.VVpazX(item, "description" , is_base64=True ).replace("\n", " .. ")
    has_archive   = CCjXCp.VVpazX(item, "has_archive"      )
    lang    = CCjXCp.VVpazX(item, "lang"        ).upper()
    now_playing   = CCjXCp.VVpazX(item, "now_playing"      )
    start    = CCjXCp.VVpazX(item, "start"        )
    start_timestamp  = CCjXCp.VVpazX(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCjXCp.VVpazX(item, "start_timestamp"     )
    stop_timestamp  = CCjXCp.VVpazX(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCjXCp.VVpazX(item, "stop_timestamp"      )
    tTitle    = CCjXCp.VVpazX(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVZNR2(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCjXCp.VVYza4(catID, MAX_4b)
  TSID = CCjXCp.VVYza4(chNum, MAX_4b)
  ONID = CCjXCp.VVYza4(chNum, MAX_4b)
  NS  = CCjXCp.VVYza4(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVYza4(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVGerw(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VV0qey(mode):
  if   mode in ("itv"  , CCjXCp.VVhDEg)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCjXCp.VV7FRI)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCjXCp.VVFo24) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCjXCp.VVkO7S) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCjXCp.VVblUo    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 @staticmethod
 def VVKlGK():
  path = CFG.iptvHostsPath.getValue()
  if not pathExists(path) or path == VV8e5A: return "/"
  else          : return FFgbrL(path)
 @staticmethod
 def VVpasw(SELF, hostUrl, chName, streamId, ok_fnc):
  title = "Catchup TV Programs"
  pList, err = CCjXCp.VVIExZ(hostUrl, streamId, True)
  if err:
   FFGr6w(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVslef, VV7O11, VVPOXl, VVfU42 = CCjXCp.VV0qey("")
   VVZOCH = ("Home Menu" , FF0RxM, [])
   VVRjvg  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVxqTz  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFsX1L(SELF, None, title="Programs for : " + chName, header=header, VVbKpp=pList, VVxqTz=VVxqTz, VVRSoy=widths, VVA2Pa=24, VVRjvg=VVRjvg, VVZOCH=VVZOCH, VVslef=VVslef, VV7O11=VV7O11, VVPOXl=VVPOXl, VVfU42=VVfU42)
  else:
   FFGr6w(SELF, "No Programs from server", title=title)
class CC6tWW(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFFsgK(VVQV0S, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVpuOK  = 0
  self.VVOdgs = 1
  self.VVjj3Z  = 2
  VVwdxM = []
  VVwdxM.append(("Find in All Service (from filter)" , "VViH3K" ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Find in All (Manual Entry)"   , "VVp0JS"    ))
  VVwdxM.append(("Find in TV"       , "VVQSSn"    ))
  VVwdxM.append(("Find in Radio"      , "VVrFqZ"   ))
  if self.VVCTSU():
   VVwdxM.append(VVWygA)
   VVwdxM.append(("Hide Channel: %s" % self.servName , "VVA258"   ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Zap History"       , "VVluUP"    ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("IPTV Tools"       , "iptv"      ))
  VVwdxM.append(("PIcons Tools"       , "PIconsTools"     ))
  VVwdxM.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FFKXoA(self, VVwdxM=VVwdxM, title=title)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  FFfopI(self["myMenu"])
  FFwO6z(self)
  if self.isFindMode:
   self.VV1lPf(self.VVAbk0())
 def VVPtX0(self):
  global VVEipR
  VVEipR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVp0JS"    : self.VVp0JS()
   elif item == "VViH3K" : self.VViH3K()
   elif item == "VVQSSn"    : self.VVQSSn()
   elif item == "VVrFqZ"   : self.VVrFqZ()
   elif item == "VVA258"   : self.VVA258()
   elif item == "VVluUP"    : self.VVluUP()
   elif item == "iptv"       : self.session.open(CCjXCp)
   elif item == "PIconsTools"     : self.session.open(CClRyV)
   elif item == "ChannelsTools"    : self.session.open(CCVPCx)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVQSSn(self) : self.VV1lPf(self.VVpuOK)
 def VVrFqZ(self) : self.VV1lPf(self.VVOdgs)
 def VVp0JS(self) : self.VV1lPf(self.VVjj3Z)
 def VV1lPf(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFK1qA(self, boundFunction(self.VVAIVk, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VViH3K(self):
  filterObj = CCCU6U(self)
  filterObj.VVbVqV(self.VVW69a)
 def VVW69a(self, item):
  self.VVAIVk(self.VVjj3Z, item)
 def VVCTSU(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFba7t(self.refCode)        : return False
  return True
 def VVAIVk(self, mode, VV9zOS):
  FFa70X(self, boundFunction(self.VVFdDQ, mode, VV9zOS), title="Searching ...")
 def VVFdDQ(self, mode, VV9zOS):
  if VV9zOS:
   self.findTxt = VV9zOS
   if   mode == self.VVpuOK  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVOdgs : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VV9zOS)
   if len(title) > 55:
    title = title[:55] + ".."
   VV2XDg = self.VVaSLh(VV9zOS, servTypes)
   if self.isFindMode or mode == self.VVjj3Z:
    VV2XDg += self.VVQcN9(VV9zOS)
   if VV2XDg:
    VV2XDg.sort(key=lambda x: x[0].lower())
    VV3Ab1 = self.VVW2fM
    VVRjvg  = ("Zap"   , self.VVdV5B    , [])
    VVcGuB = ("Current Service", self.VVYpiG , [])
    VVzhrG = ("Options"  , self.VVrUZW , [])
    VVCijI = (""    , self.VVeaD4 , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVxqTz  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFsX1L(self, None, title=title, header=header, VVbKpp=VV2XDg, VVxqTz=VVxqTz, VVRSoy=widths, VVA2Pa=26, VVRjvg=VVRjvg, VV3Ab1=VV3Ab1, VVcGuB=VVcGuB, VVzhrG=VVzhrG, VVCijI=VVCijI)
   else:
    self.VV1lPf(self.VVAbk0())
    FF6zpT(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVaSLh(self, VV9zOS, servTypes):
  VV7FV8  = eServiceCenter.getInstance()
  VVqgtP   = '%s ORDER BY name' % servTypes
  VVZ2uU   = eServiceReference(VVqgtP)
  VVxiW1 = VV7FV8.list(VVZ2uU)
  if VVxiW1: VVbKpp = VVxiW1.getContent("CN", False)
  else     : VVbKpp = None
  VV2XDg = []
  if VVbKpp:
   VVsekx, VVbZDd = FFmDkq()
   tp   = CCloky()
   words, asPrefix = CCCU6U.VVAvaW(VV9zOS)
   colorYellow  = CCGmwk.VVTCSR(VVX3gJ)
   colorWhite  = CCGmwk.VVTCSR(VVaDNx)
   for s in VVbKpp:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFc8Er(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVsekx:
        STYPE = VVbZDd[sTypeInt]
       freq, pol, fec, sr, syst = tp.VV3Vfi(refCode)
       if not "-S" in syst:
        sat = syst
       VV2XDg.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VV2XDg
 def VVQcN9(self, VV9zOS):
  VV9zOS = VV9zOS.lower()
  VVcXkV = FF09hW()
  VV2XDg = []
  colorYellow  = CCGmwk.VVTCSR(VVX3gJ)
  colorWhite  = CCGmwk.VVTCSR(VVaDNx)
  if VVcXkV:
   for b in VVcXkV:
    VVBcUD  = b[0]
    VVYyR6  = b[1].toString()
    VVaUDr = eServiceReference(VVYyR6)
    VVDIAQ = FFoqwI(VVaUDr)
    for service in VVDIAQ:
     refCode  = service[0]
     if FFba7t(refCode):
      servName = service[1]
      if VV9zOS in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VV9zOS), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VV2XDg.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VV2XDg
 def VVAbk0(self):
  VVsMMP = InfoBar.instance
  if VVsMMP:
   VVWPt4 = VVsMMP.servicelist
   if VVWPt4:
    return VVWPt4.mode == 1
  return self.VVjj3Z
 def VVW2fM(self, VVL8CA):
  self.close()
  VVL8CA.cancel()
 def VVdV5B(self, VVL8CA, title, txt, colList):
  FFsOcb(VVL8CA, colList[2], VVuw4l=False, checkParentalControl=True)
 def VVYpiG(self, VVL8CA, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(VVL8CA)
  if refCode:
   VVL8CA.VVuOU0(2, FFQ7UT(refCode, iptvRef, chName), True)
 def VVrUZW(self, VVL8CA, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CChV7M(self, VVL8CA, 2)
  mSel.VVSa8v(servName, refCode)
 def VVeaD4(self, VVL8CA, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFASWh(self, fncMode=CCAHNs.VVxIaR, refCode=refCode, chName=chName, text=txt)
 def VVA258(self):
  FFIxs9(self, self.VV5QZU, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VV5QZU(self):
  ret = FFn2dx(self.refCode, True)
  if ret:
   self.VV4d8y()
   self.close()
  else:
   FFU79C(self, "Cannot change state" , 1000)
 def VV4d8y(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVmCl9()
  except:
   self.VVCw9I()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFLcdV(self, serviceRef)
 def VV7DwY(self):
  VVsMMP = InfoBar.instance
  if VVsMMP:
   VVWPt4 = VVsMMP.servicelist
   if VVWPt4:
    VVWPt4.setMode()
 def VVmCl9(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVsMMP = InfoBar.instance
   if VVsMMP:
    VVWPt4 = VVsMMP.servicelist
    if VVWPt4:
     hList = VVWPt4.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVWPt4.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVWPt4.history  = newList
       VVWPt4.history_pos = pos
 def VVCw9I(self):
  VVsMMP = InfoBar.instance
  if VVsMMP:
   VVWPt4 = VVsMMP.servicelist
   if VVWPt4:
    VVWPt4.history  = []
    VVWPt4.history_pos = 0
 def VVluUP(self):
  VVsMMP = InfoBar.instance
  VV2XDg = []
  if VVsMMP:
   VVWPt4 = VVsMMP.servicelist
   if VVWPt4:
    VVsekx, VVbZDd = FFmDkq()
    for chParams in VVWPt4.history:
     refCode = chParams[-1].toString()
     chName = FFYDAT(refCode)
     isIptv = FFba7t(refCode)
     if isIptv: sat = "-"
     else  : sat = FFc8Er(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVsekx:
       STYPE = VVbZDd[sTypeInt]
     VV2XDg.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VV2XDg:
   VVRjvg  = ("Zap"   , self.VVRw6N   , [])
   VVzhrG = ("Clear History" , self.VVVaQ6   , [])
   VVCijI = (""    , self.VVKyj1FromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVxqTz  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFsX1L(self, None, title=title, header=header, VVbKpp=VV2XDg, VVxqTz=VVxqTz, VVRSoy=widths, VVA2Pa=28, VVRjvg=VVRjvg, VVzhrG=VVzhrG, VVCijI=VVCijI)
  else:
   FF6zpT(self, "Not found", title=title)
 def VVRw6N(self, VVL8CA, title, txt, colList):
  FFsOcb(VVL8CA, colList[3], VVuw4l=False, checkParentalControl=True)
 def VVVaQ6(self, VVL8CA, title, txt, colList):
  FFIxs9(self, boundFunction(self.VVXe5b, VVL8CA), "Clear Zap History ?")
 def VVXe5b(self, VVL8CA):
  self.VVCw9I()
  VVL8CA.cancel()
 def VVKyj1FromZapHistory(self, VVL8CA, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFASWh(self, fncMode=CCAHNs.VVQ4O4, refCode=refCode, chName=chName, text=txt)
class CClRyV(Screen):
 VV3DzA   = 0
 VVN2IS  = 1
 VVUKQe  = 2
 VVc9fL  = 3
 VVrDZb  = 4
 VVRC0c  = 5
 VVs2PJ  = 6
 VVInhm  = 7
 VVhtXY = 8
 VVy7oc = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFFsgK(VVqLiq, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFKXoA(self, self.Title)
  FFhu6U(self["keyRed"] , "OK = Zap")
  FFhu6U(self["keyGreen"] , "Current Service")
  FFhu6U(self["keyYellow"], "Page Options")
  FFhu6U(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CClRyV.VVvvid()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVbKpp    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVlzYm        ,
   "green"   : self.VVqyqN       ,
   "yellow"  : self.VVsBUL        ,
   "blue"   : self.VVoQ4p        ,
   "menu"   : self.VVCrXM        ,
   "info"   : self.VVKyj1         ,
   "up"   : self.VVmzSZ          ,
   "down"   : self.VVcFVq         ,
   "left"   : self.VVPGw2         ,
   "right"   : self.VVxtQm         ,
   "pageUp"  : boundFunction(self.VV30zp, True) ,
   "chanUp"  : boundFunction(self.VV30zp, True) ,
   "pageDown"  : boundFunction(self.VV30zp, False) ,
   "chanDown"  : boundFunction(self.VV30zp, False) ,
   "next"   : self.VVUwVU        ,
   "last"   : self.VV3K59         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  FFFOZ8(self)
  FFpRmN(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFa70X(self, boundFunction(self.VVwusN, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVCrXM(self):
  if not self.isBusy:
   VVwdxM = []
   VVwdxM.append(("Statistics"           , "VVVwO7"    ))
   VVwdxM.append(VVWygA)
   VVwdxM.append(("Suggest PIcons for Current Channel"     , "VVCbG9"   ))
   VVwdxM.append(("Set to Current Channel (copy file)"     , "VVxzaY_file"  ))
   VVwdxM.append(("Set to Current Channel (as SymLink)"     , "VVxzaY_link"  ))
   VVwdxM.append(VVWygA)
   VVwdxM.append(CClRyV.VVU2ko())
   VVwdxM.append(VVWygA)
   if self.filterTitle == "PIcons without Channels":
    c = VVBEBZ
    VVwdxM.append((FFY8RM("Move Unused PIcons to a Directory", c) , "VVfQoH"  ))
    VVwdxM.append((FFY8RM("DELETE Unused PIcons", c)    , "VVs8pM" ))
    VVwdxM.append(VVWygA)
   VVwdxM.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVACRW"  ))
   VVwdxM.append(VVWygA)
   VVwdxM += CClRyV.VVDdOe()
   VVwdxM.append(VVWygA)
   VVwdxM.append(("RCU Keys Help"          , "VVnShr"    ))
   FFsmMG(self, self.VVp9Al, title=self.Title, VVwdxM=VVwdxM)
 def VVp9Al(self, item=None):
  if item is not None:
   if   item == "VVVwO7"     : self.VVVwO7()
   elif item == "VVCbG9"    : self.VVCbG9()
   elif item == "VVxzaY_file"   : self.VVxzaY(0)
   elif item == "VVxzaY_link"   : self.VVxzaY(1)
   elif item == "VVPwuY_file"  : self.VVPwuY(0)
   elif item == "VVPwuY_link"  : self.VVPwuY(1)
   elif item == "VV3mEJ"   : self.VV3mEJ()
   elif item == "VVFk6Y"  : self.VVFk6Y()
   elif item == "VVfQoH"    : self.VVfQoH()
   elif item == "VVs8pM"   : self.VVs8pM()
   elif item == "VVACRW"   : self.VVACRW()
   elif item == "VVNdV5"   : CClRyV.VVNdV5(self)
   elif item == "VVbJBe"   : CClRyV.VVbJBe(self)
   elif item == "findPiconBrokenSymLinks"  : CClRyV.VVf2R3(self, True)
   elif item == "FindAllBrokenSymLinks"  : CClRyV.VVf2R3(self, False)
   elif item == "VVnShr"      : self.VVnShr()
 def VVsBUL(self):
  if not self.isBusy:
   VVwdxM = []
   VVwdxM.append(("Go to First PIcon"  , "VVu8ES"  ))
   VVwdxM.append(("Go to Last PIcon"   , "VVWw8D"  ))
   VVwdxM.append(VVWygA)
   VVwdxM.append(("Sort by Channel Name"     , "sortByChan" ))
   VVwdxM.append(("Sort by File Name"  , "sortByFile" ))
   VVwdxM.append(VVWygA)
   VVwdxM.append(("Find from File List .." , "VVrCiu" ))
   FFsmMG(self, self.VVDmpq, title=self.Title, VVwdxM=VVwdxM)
 def VVDmpq(self, item=None):
  if item is not None:
   if   item == "VVu8ES"   : self.VVu8ES()
   elif item == "VVWw8D"   : self.VVWw8D()
   elif item == "sortByChan"  : self.VVPhMF(2)
   elif item == "sortByFile"  : self.VVPhMF(0)
   elif item == "VVrCiu"  : self.VVrCiu()
 def VVnShr(self):
  FFQsDF(self, VVfmTj + "_help_picons", "PIcons Manager (Keys Help)")
 def VVmzSZ(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVWw8D()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VV9Neu()
 def VVcFVq(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVu8ES()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VV9Neu()
 def VVPGw2(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVWw8D()
  else:
   self.curCol -= 1
   self.VV9Neu()
 def VVxtQm(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVu8ES()
  else:
   self.curCol += 1
   self.VV9Neu()
 def VV3K59(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VV9Neu(True)
 def VVUwVU(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VV9Neu(True)
 def VVu8ES(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VV9Neu(True)
 def VVWw8D(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VV9Neu(True)
 def VVrCiu(self):
  VVwdxM = []
  for item in self.VVbKpp:
   VVwdxM.append((item[0], item[0]))
  FFsmMG(self, self.VVubIt, title='PIcons ".png" Files', VVwdxM=VVwdxM, VVXrUb=True)
 def VVubIt(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVCoSq(ndx)
 def VVlzYm(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVBZwj()
   if refCode:
    FFsOcb(self, refCode)
    self.VVJcXa()
    self.VVPEBs()
 def VV30zp(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVJcXa()
   self.VVPEBs()
  except:
   pass
 def VVqyqN(self):
  if self["keyGreen"].getVisible():
   self.VVCoSq(self.curChanIndex)
 def VVCoSq(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VV9Neu(True)
  else:
   FFU79C(self, "Not found", 1000)
 def VVPhMF(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFa70X(self, boundFunction(self.VVwusN, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVxzaY(self, mode):
  title = "Change Current Channel PIcon"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVBZwj()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVwdxM = []
     VVwdxM.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVwdxM.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFsmMG(self, boundFunction(self.VVLbFs, mode, curChF, selPiconF), VVwdxM=VVwdxM, title="Current Channel PIcon (already exists)")
    else:
     self.VVLbFs(mode, curChF, selPiconF, "overwrite")
   else:
    FFGr6w(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFGr6w(self, "Could not read current channel info. !", title=title)
 def VVLbFs(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFa70X(self, boundFunction(self.VVwusN, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVPwuY(self, mode):
  pass
 def VV3mEJ(self):
  pass
 def VVFk6Y(self):
  pass
 def VVfQoH(self):
  defDir = FFgbrL(CClRyV.VVvvid() + "picons_backup")
  os.system(FFoKN8("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(boundFunction(self.VVo6id, defDir), boundFunction(CCvQ2O
         , mode=CCvQ2O.VVNlqz, VVlCyw=CClRyV.VVvvid()))
 def VVo6id(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CClRyV.VVvvid():
    FFGr6w(self, "Cannot move to same directory !", title=title)
   else:
    if not FFgbrL(path) == FFgbrL(defDir):
     self.VVrOHZ(defDir)
    FFIxs9(self, boundFunction(FFa70X, self, boundFunction(self.VVTkf0, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVbKpp), path), title=title)
  else:
   self.VVrOHZ(defDir)
 def VVTkf0(self, title, defDir, toPath):
  try:
   from shutil import move as iMove
  except:
   self.VVrOHZ(defDir)
   FFGr6w(self, 'Could not load "shutil" module !', title=title)
   return
  toPath = FFgbrL(toPath)
  pPath = CClRyV.VVvvid()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVbKpp:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVbKpp)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFMt3I(self, txt, title=title, VVPOXl="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVWUbP("all")
 def VVrOHZ(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVs8pM(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVbKpp)
  s = "s" if tot > 1 else ""
  FFIxs9(self, boundFunction(FFa70X, self, boundFunction(self.VVNUCl, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, s), title=title)
 def VVNUCl(self, title):
  pPath = CClRyV.VVvvid()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVbKpp:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVbKpp)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFY8RM(str(totErr), VVBEBZ)
  FFMt3I(self, txt, title=title)
 def VVACRW(self):
  lines = FF0s0U("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFIxs9(self, boundFunction(self.VV4WIt, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVuXa8=True)
  else:
   FF6zpT(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VV4WIt(self, fList):
  os.system(FFoKN8("find -L '%s' -type l -delete" % self.pPath))
  FF6zpT(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVKyj1(self):
  FFa70X(self, self.VVyya6)
 def VVyya6(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVBZwj()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFY8RM("PIcon Directory:\n", VVVJBw)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFftbc(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFftbc(path)
   txt += FFY8RM("PIcon File:\n", VVVJBw)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FF0s0U(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFY8RM("Found %d SymLink%s to this file from:\n" % (tot, s), VVVJBw)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFYDAT(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFY8RM(tChName, VVI0dy)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFY8RM(line, VVea45), tChName)
    txt += "\n"
   if chName:
    txt += FFY8RM("Channel:\n", VVVJBw)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFY8RM(chName, VVI0dy)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFY8RM("Remarks:\n", VVVJBw)
    txt += "  %s\n" % FFY8RM("Unused", VVBEBZ)
  else:
   txt = "No info found"
  FFASWh(self, fncMode=CCAHNs.VVpAkQ, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVBZwj(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVbKpp[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFR1o4(sat)
  return fName, refCode, chName, sat, inDB
 def VVJcXa(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVbKpp):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVPEBs(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVBZwj()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFY8RM("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVVJBw))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVBZwj()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFY8RM(self.curChanName, VVX3gJ)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVVwO7(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VVbKpp:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FF5sfh("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFMt3I(self, txt, title=self.Title)
 def VVoQ4p(self):
  if not self.isBusy:
   VVwdxM = []
   VVwdxM.append(("All"         , "all"   ))
   VVwdxM.append(VVWygA)
   VVwdxM.append(("Used by Channels"      , "used"  ))
   VVwdxM.append(("Unused PIcons"      , "unused"  ))
   VVwdxM.append(VVWygA)
   VVwdxM.append(("PIcons Files"       , "pFiles"  ))
   VVwdxM.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVwdxM.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVwdxM.append(VVWygA)
   VVwdxM.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVwdxM.append(VVWygA)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFARfj(val)
      VVwdxM.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCCU6U(self)
   filterObj.VVua69(VVwdxM, self.nsList, self.VVKJ8o)
 def VVKJ8o(self, item=None):
  if item is not None:
   self.VVWUbP(item)
 def VVWUbP(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VV3DzA   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVN2IS   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVUKQe  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVc9fL  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVrDZb  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVRC0c  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVs2PJ   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVInhm   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVhtXY , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVRC0c:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FF0s0U("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFU79C(self, "Not found", 1000)
     return
   elif mode == self.VVy7oc:
    return
   else:
    words, asPrefix = CCCU6U.VVAvaW(words)
   if not words and mode in (self.VVInhm, self.VVhtXY):
    FFU79C(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFa70X(self, boundFunction(self.VVwusN, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVCbG9(self):
  self.session.open(CCu37C, barTheme=CCu37C.VVcppe
      , titlePrefix = ""
      , fncToRun  = self.VVX8tJ
      , VV6vg0 = self.VVF1aJ)
 def VVX8tJ(self, progBarObj):
  lameDbChans = CCVPCx.VV2CvK(self, CCVPCx.VVvDXQ, VV2jrq=False, VVjy3R=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVuEpa = []
  progBarObj.VVx354(len(lameDbChans))
  if lameDbChans:
   processChanName = CCFutt()
   curCh = processChanName.VVEmCF(self.curChanName)
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVW1AW(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CClRyV.VV3Fsm(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CClRyV.VVy2gd(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VVuEpa.append(f.replace(".png", ""))
 def VVF1aJ(self, VVsXZs, VVuEpa, threadCounter, threadTotal, threadErr):
  if VVuEpa:
   self.timer = eTimer()
   fnc = boundFunction(FFa70X, self, boundFunction(self.VVwusN, mode=self.VVy7oc, words=VVuEpa), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FFU79C(self, "Not found", 2000)
 def VVwusN(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVshzX(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCVPCx.VV2CvK(self, CCVPCx.VVvDXQ, VV2jrq=False, VVjy3R=False)
  iptvRefList = self.VV6SbB()
  tList = []
  for fName, fType in CClRyV.VVhEf2(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VV3DzA:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVN2IS  and chName         : isAdd = True
   elif mode == self.VVUKQe and not chName        : isAdd = True
   elif mode == self.VVc9fL  and fType == 0        : isAdd = True
   elif mode == self.VVrDZb  and fType == 1        : isAdd = True
   elif mode == self.VVRC0c  and fName in words       : isAdd = True
   elif mode == self.VVy7oc and fName in words       : isAdd = True
   elif mode == self.VVs2PJ  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVInhm  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVhtXY:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVbKpp   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFU79C(self)
  else:
   self.isBusy = False
   FFU79C(self, "Not found", 1000)
   return
  self.VVbKpp.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVJcXa()
  self.totalPIcons = len(self.VVbKpp)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VV9Neu(True)
 def VVshzX(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CClRyV.VVhEf2(self.pPath):
    if fName:
     return True
   if isFirstTime : FFGr6w(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFU79C(self, "Not found", 1000)
  else:
   FFGr6w(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VV6SbB(self):
  VV2XDg = {}
  files  = CCjXCp.VVlkN6(self)
  if files:
   for path in files:
    txt = FFaq7Y(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VV2XDg[refCode] = item[1]
  return VV2XDg
 def VV9Neu(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVRCMz = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVRCMz: self.curPage = VVRCMz
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVtHN4()
  if self.curPage == VVRCMz:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVPEBs()
  filName, refCode, chName, sat, inDB = self.VVBZwj()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVtHN4(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVbKpp[ndx]
   fName = self.VVbKpp[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFY8RM(chName, VVI0dy))
    else : lbl.setText("-")
   except:
    lbl.setText(FFY8RM(chName, VVVqHz))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VV3Fsm(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVU2ko():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVNdV5"   )
 @staticmethod
 def VVDdOe():
  VVwdxM = []
  VVwdxM.append(("Find SymLinks (to PIcon Directory)"   , "VVbJBe"   ))
  VVwdxM.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVwdxM.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVwdxM
 @staticmethod
 def VVNdV5(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(SELF)
  png, path = CClRyV.VVfqdE(refCode)
  if path : CClRyV.VVHDck(SELF, png, path)
  else : FFGr6w(SELF, "No PIcon found for current channel in:\n\n%s" % CClRyV.VVvvid())
 @staticmethod
 def VVbJBe(SELF):
  if VVX3gJ:
   sed1 = FFdpXa("->", VVX3gJ)
   sed2 = FFdpXa("picon", VVBEBZ)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVVqHz, VVaDNx)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFj8K7(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFl0r9(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVf2R3(SELF, isPIcon):
  sed1 = FFdpXa("->", VVVqHz)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFdpXa("picon", VVBEBZ)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFj8K7(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFl0r9(), grep, sed1, sed2))
 @staticmethod
 def VVhEf2(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVvvid():
  path = CFG.PIconsPath.getValue()
  return FFgbrL(path)
 @staticmethod
 def VVfqdE(refCode, chName=None):
  if FFba7t(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFn6Kh(refCode)
  allPath, fName, refCodeFile, pList = CClRyV.VVy2gd(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVHDck(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFdpXa("%s%s" % (dest, png), VVI0dy))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFdpXa(errTxt, VVNRjX))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFTM8D(SELF, cmd)
 @staticmethod
 def VVy2gd(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CClRyV.VVvvid()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFaO74(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCOCST():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVg3z8  = None
  self.VV4yef = ""
  self.VV6zPM  = noService
  self.VVU7t9 = 0
  self.VVBR9r  = noService
  self.VVf5Xn = 0
  self.VVx3HO  = "-"
  self.VV8z17 = 0
  self.VVeXz3  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVmLOk(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVg3z8 = frontEndStatus
     self.VVJBKl()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVJBKl(self):
  if self.VVg3z8:
   val = self.VVg3z8.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VV4yef = "%3.02f dB" % (val / 100.0)
   else         : self.VV4yef = ""
   val = self.VVg3z8.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVU7t9 = int(val)
   self.VV6zPM  = "%d%%" % val
   val = self.VVg3z8.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVf5Xn = int(val)
   self.VVBR9r  = "%d%%" % val
   val = self.VVg3z8.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVx3HO  = "%d" % val
   val = int(val * 100 / 500)
   self.VV8z17 = min(500, val)
   val = self.VVg3z8.get("tuner_locked", 0)
   if val == 1 : self.VVeXz3 = "Locked"
   else  : self.VVeXz3 = "Not locked"
 def VVC2wj(self)   : return self.VV4yef
 def VVgrgr(self)   : return self.VV6zPM
 def VVgUXt(self)  : return self.VVU7t9
 def VVAl7s(self)   : return self.VVBR9r
 def VVzjFd(self)  : return self.VVf5Xn
 def VVujp1(self)   : return self.VVx3HO
 def VVSbEu(self)  : return self.VV8z17
 def VVVRAV(self)   : return self.VVeXz3
 def VV1A1J(self) : return self.serviceName
class CCloky():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVR1rC(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFyYGT(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVbwfw(self.ORPOS  , mod=1   )
      self.sat2  = self.VVbwfw(self.ORPOS  , mod=2   )
      self.freq  = self.VVbwfw(self.FREQ  , mod=3   )
      self.sr   = self.VVbwfw(self.SR   , mod=4   )
      self.inv  = self.VVbwfw(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVbwfw(self.POL  , self.D_POL )
      self.fec  = self.VVbwfw(self.FEC  , self.D_FEC )
      self.syst  = self.VVbwfw(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVbwfw("modulation" , self.D_MOD )
       self.rolof = self.VVbwfw("rolloff"  , self.D_ROLOF )
       self.pil = self.VVbwfw("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVbwfw("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVbwfw("pls_code"  )
       self.iStId = self.VVbwfw("is_id"   )
       self.t2PlId = self.VVbwfw("t2mi_plp_id" )
       self.t2PId = self.VVbwfw("t2mi_pid"  )
 def VVbwfw(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFARfj(val)
  elif mod == 2   : return FFGZ1p(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVSjK6(self, refCode):
  txt = ""
  self.VVR1rC(refCode)
  if self.data:
   def VVLQyb(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVLQyb("System"   , self.syst)
    txt += VVLQyb("Satellite"  , self.sat2)
    txt += VVLQyb("Frequency"  , self.freq)
    txt += VVLQyb("Inversion"  , self.inv)
    txt += VVLQyb("Symbol Rate"  , self.sr)
    txt += VVLQyb("Polarization" , self.pol)
    txt += VVLQyb("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVLQyb("Modulation" , self.mod)
     txt += VVLQyb("Roll-Off" , self.rolof)
     txt += VVLQyb("Pilot"  , self.pil)
     txt += VVLQyb("Input Stream", self.iStId)
     txt += VVLQyb("T2MI PLP ID" , self.t2PlId)
     txt += VVLQyb("T2MI PID" , self.t2PId)
     txt += VVLQyb("PLS Mode" , self.plsMod)
     txt += VVLQyb("PLS Code" , self.plsCod)
   else:
    txt += VVLQyb("System"   , self.txMedia)
    txt += VVLQyb("Frequency"  , self.freq)
  return txt, self.namespace
 def VV9C7D(self, refCode):
  txt = "Transpoder : ?"
  self.VVR1rC(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVVJBw + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VV3Vfi(self, refCode):
  self.data = None
  servRef = eServiceReference(refCode)
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFyYGT(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVbwfw(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVbwfw(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVbwfw(self.SYST, self.D_SYS_S)
     freq = self.VVbwfw(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVbwfw(self.POL , self.D_POL)
      fec = self.VVbwfw(self.FEC , self.D_FEC)
      sr = self.VVbwfw(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VV68Qb(self, refCode):
  self.data = None
  self.VVR1rC(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCk6mL():
 def __init__(self, VVaUAY, path, VV6vg0=None, curRowNum=-1):
  self.VVaUAY  = VVaUAY
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VV6vg0  = VV6vg0
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFoKN8("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVmFvV(curRowNum)
  else:
   FFGr6w(self.VVaUAY, "Error while preparing edit!")
 def VVmFvV(self, curRowNum):
  VV2XDg = self.VVOXBW()
  VVZOCH = None #("Delete Line" , self.deleteLine  , [])
  VVcGuB = ("Save Changes" , self.VVbuZ8   , [])
  VVRjvg  = ("Edit Line"  , self.VVXaMa    , [])
  VVwqYz = ("Line Options" , self.VVWySb   , [])
  VVRExa = (""    , self.VV2Dg8 , [])
  VV3Ab1 = self.VVbKF2
  VVdvWi  = self.VVcSHU
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVxqTz  = (CENTER  , LEFT  )
  VVL8CA = FFsX1L(self.VVaUAY, None, title=self.Title, header=header, VVbKpp=VV2XDg, VVxqTz=VVxqTz, VVRSoy=widths, VVA2Pa=26, VVZOCH=VVZOCH, VVcGuB=VVcGuB, VVRjvg=VVRjvg, VVwqYz=VVwqYz, VV3Ab1=VV3Ab1, VVdvWi=VVdvWi, VVRExa=VVRExa, VVuZx4=True
    , VVslef   = "#11001111"
    , VV7O11   = "#11001111"
    , VVPOXl   = "#11001111"
    , VVfU42  = "#05333333"
    , VVd2OO  = "#00222222"
    , VVm63O  = "#11331133"
    )
  VVL8CA.VV4dVP(curRowNum)
 def VVWySb(self, VVL8CA, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVL8CA.VV4fXI()
  VVwdxM = []
  VVwdxM.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVwdxM.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVSogk"  ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVUPCw:
   VVwdxM.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(  ("Delete Line"         , "deleteLine"   ))
  FFsmMG(self.VVaUAY, boundFunction(self.VVRdrm, VVL8CA, lineNum), VVwdxM=VVwdxM, title="Line Options")
 def VVRdrm(self, VVL8CA, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVprlQ("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVL8CA)
   elif item == "VVSogk"  : self.VVSogk(VVL8CA, lineNum)
   elif item == "copyToClipboard"  : self.VVQLbF(VVL8CA, lineNum)
   elif item == "pasteFromClipboard" : self.VVdnMq(VVL8CA, lineNum)
   elif item == "deleteLine"   : self.VVprlQ("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVL8CA)
 def VVcSHU(self, VVL8CA):
  VVL8CA.VVRsrd()
 def VV2Dg8(self, VVL8CA, title, txt, colList):
  if   self.insertMode == 1: VVL8CA.VVIgGQ()
  elif self.insertMode == 2: VVL8CA.VVTVNm()
  self.insertMode = 0
 def VVSogk(self, VVL8CA, lineNum):
  if lineNum == VVL8CA.VV4fXI():
   self.insertMode = 1
   self.VVprlQ("echo '' >> '%s'" % self.tmpFile, VVL8CA)
  else:
   self.insertMode = 2
   self.VVprlQ("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVL8CA)
 def VVQLbF(self, VVL8CA, lineNum):
  global VVUPCw
  VVUPCw = FF5sfh("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVL8CA.VV5Ruh("Copied to clipboard")
 def VVbuZ8(self, VVL8CA, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFoKN8("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFoKN8("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVL8CA.VV5Ruh("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVL8CA.VVRsrd()
    else:
     FFGr6w(self.VVaUAY, "Cannot save file!")
   else:
    FFGr6w(self.VVaUAY, "Cannot create backup copy of original file!")
 def VVbKF2(self, VVL8CA):
  if self.fileChanged:
   FFIxs9(self.VVaUAY, boundFunction(self.VVA3bZ, VVL8CA), "Cancel changes ?")
  else:
   finalOK = os.system(FFoKN8("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVA3bZ(VVL8CA)
 def VVA3bZ(self, VVL8CA):
  VVL8CA.cancel()
  os.system(FFoKN8("rm -f '%s'" % self.tmpFile))
  if self.VV6vg0:
   self.VV6vg0(self.fileSaved)
 def VVXaMa(self, VVL8CA, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVaDNx + "ORIGINAL TEXT:\n" + VVea45 + lineTxt
  FFK1qA(self.VVaUAY, boundFunction(self.VVpDRk, lineNum, VVL8CA), title="File Line", defaultText=lineTxt, message=message)
 def VVpDRk(self, lineNum, VVL8CA, VVb9jI):
  if not VVb9jI is None:
   if VVL8CA.VV4fXI() <= 1:
    self.VVprlQ("echo %s > '%s'" % (VVb9jI, self.tmpFile), VVL8CA)
   else:
    self.VVQ2bt(VVL8CA, lineNum, VVb9jI)
 def VVdnMq(self, VVL8CA, lineNum):
  if lineNum == VVL8CA.VV4fXI() and VVL8CA.VV4fXI() == 1:
   self.VVprlQ("echo %s >> '%s'" % (VVUPCw, self.tmpFile), VVL8CA)
  else:
   self.VVQ2bt(VVL8CA, lineNum, VVUPCw)
 def VVQ2bt(self, VVL8CA, lineNum, newTxt):
  VVL8CA.VV7fYZ("Saving ...")
  lines = FFn8wV(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVL8CA.VV59wi()
  VV2XDg = self.VVOXBW()
  VVL8CA.VVn17k(VV2XDg)
 def VVprlQ(self, cmd, VVL8CA):
  tCons = CCH43c()
  tCons.ePopen(cmd, boundFunction(self.VV8jt0, VVL8CA))
  self.fileChanged = True
  VVL8CA.VV59wi()
 def VV8jt0(self, VVL8CA, result, retval):
  VV2XDg = self.VVOXBW()
  VVL8CA.VVn17k(VV2XDg)
 def VVOXBW(self):
  if fileExists(self.tmpFile):
   lines = FFn8wV(self.tmpFile)
   VV2XDg = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VV2XDg.append((str(ndx), line.strip()))
   if not VV2XDg:
    VV2XDg.append((str(1), ""))
   return VV2XDg
  else:
   FFI53L(self.VVaUAY, self.tmpFile)
class CCCU6U():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVwdxM   = []
  self.satList   = []
 def VVbVqV(self, VV6vg0):
  self.VVwdxM = []
  VVwdxM, VVj3dL = self.VVXGmV(False, True)
  if VVwdxM:
   self.VVwdxM += VVwdxM
   self.VV4m9N(VV6vg0, VVj3dL)
 def VVd2Fw(self, mode, VVL8CA, satCol, VV6vg0):
  VVL8CA.VV7fYZ("Loading Filters ...")
  self.VVwdxM = []
  self.VVwdxM.append(("All Services" , "all"))
  if mode == 1:
   self.VVwdxM.append(VVWygA)
   self.VVwdxM.append(("Parental Control", "parentalControl"))
   self.VVwdxM.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVwdxM.append(VVWygA)
   self.VVwdxM.append(("Selected Transponder"   , "selectedTP" ))
   self.VVwdxM.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVG84f(VVL8CA, satCol)
  VVwdxM, VVj3dL = self.VVXGmV(True, False)
  if VVwdxM:
   VVwdxM.insert(0, VVWygA)
   self.VVwdxM += VVwdxM
  VVL8CA.VVXTRT()
  self.VV4m9N(VV6vg0, VVj3dL)
 def VVua69(self, VVwdxM, sats, VV6vg0):
  self.VVwdxM = VVwdxM
  VVwdxM, VVj3dL = self.VVXGmV(True, False)
  if VVwdxM:
   self.VVwdxM.append(VVWygA)
   self.VVwdxM += VVwdxM
  self.VV4m9N(VV6vg0, VVj3dL)
 def VVdaeQ(self, VVwdxM, sats, VV6vg0):
  self.VVwdxM = VVwdxM
  VVwdxM, VVj3dL = self.VVXGmV(True, False)
  if VVwdxM:
   self.VVwdxM.append(VVWygA)
   self.VVwdxM += VVwdxM
  self.VV4m9N(VV6vg0, VVj3dL)
 def VV4m9N(self, VV6vg0, VVj3dL):
  VV0ixh = ("Edit Filter", boundFunction(self.VVlRNr, VVj3dL))
  VVu6qN  = ("Filter Help", boundFunction(self.VV8UWN, VVj3dL))
  FFsmMG(self.callingSELF, boundFunction(self.VVHRiS, VV6vg0), VVwdxM=self.VVwdxM, title="Select Filter", VV0ixh=VV0ixh, VVu6qN=VVu6qN)
 def VVHRiS(self, VV6vg0, item):
  if item:
   VV6vg0(item)
 def VVlRNr(self, VVj3dL, VVyzEqObj, sel):
  if fileExists(VVj3dL) : CCk6mL(self.callingSELF, VVj3dL, VV6vg0=None)
  else       : FFI53L(self.callingSELF, VVj3dL)
  VVyzEqObj.cancel()
 def VV8UWN(self, VVj3dL, VVyzEqObj, sel):
  FFQsDF(self.callingSELF, VVfmTj + "_help_service_filter", "Service Filter")
 def VVG84f(self, VVL8CA, satColNum):
  if not self.satList:
   satList = VVL8CA.VVq0ms(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFR1o4(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVWygA)
  if self.VVwdxM:
   self.VVwdxM += self.satList
 def VVXGmV(self, addTag, VV17Wy):
  FFwg59()
  fileName  = "ajpanel_services_filter"
  VVj3dL = VVbxzm + fileName
  VVwdxM  = []
  if not fileExists(VVj3dL):
   os.system(FFoKN8("cp -f '%s' '%s'" % (VVfmTj + fileName, VVj3dL)))
  fileFound = False
  if fileExists(VVj3dL):
   fileFound = True
   lines = FFn8wV(VVj3dL)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVwdxM.append((line, "__w__" + line))
       else  : VVwdxM.append((line, line))
  if VV17Wy:
   if   not fileFound : FFI53L(self.callingSELF , VVj3dL)
   elif not VVwdxM : FF2TvG(self.callingSELF , VVj3dL)
  return VVwdxM, VVj3dL
 @staticmethod
 def VVAvaW(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CChV7M():
 def __init__(self, callingSELF, VVL8CA, refCodeColNum):
  self.callingSELF = callingSELF
  self.VVL8CA = VVL8CA
  self.refCodeColNum = refCodeColNum
  self.VVwdxM = []
  iMulSel = self.VVL8CA.VVOdDi()
  if iMulSel : self.VVwdxM.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVwdxM.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVL8CA.VVcrKb()
  self.VVwdxM.append(    ("Select all"    , "selectAll"  ))
  if tot > 0:
   self.VVwdxM.append(   ("Unselect all"    , "unselectAll"  ))
  self.VVwdxM.append(VVWygA)
 def VVSa8v(self, servName, refCode):
  tot = self.VVL8CA.VVcrKb()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVwdxM.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VV7TxJ_multi" ))
  else    : self.VVwdxM.append( ("Add to Bouquet : %s"      % servName , "VV7TxJ_one" ))
  self.VVb8it(servName, refCode)
 def VVSsEO(self, servName, refCode, pcState, hidState):
  self.VVwdxM = []
  if pcState == "No" : self.VVwdxM.append(("Add to Parental Control"  , "parentalControl_add"  ))
  else    : self.VVwdxM.append(("Remove from Parental Control" , "parentalControl_remove" ))
  if hidState == "No" : self.VVwdxM.append(("Add to Hidden Services"  , "hiddenServices_add"  ))
  else    : self.VVwdxM.append(("Remove from Hidden Services" , "hiddenServices_remove" ))
  self.VVb8it(servName, refCode)
 def VVb8it(self, servName, refCode):
  FFsmMG(self.callingSELF, boundFunction(self.VVNxd8, servName, refCode), title="Options", VVwdxM=self.VVwdxM)
 def VVNxd8(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"    : self.VVL8CA.VVjJv0(True)
   elif item == "MultSelDisab"    : self.VVL8CA.VVjJv0(False)
   elif item == "selectAll"    : self.VVL8CA.VVCXGx()
   elif item == "unselectAll"    : self.VVL8CA.VVRJ0z()
   elif item == "parentalControl_add"  : self.callingSELF.VVOOqT(self.VVL8CA, refCode, True)
   elif item == "parentalControl_remove" : self.callingSELF.VVOOqT(self.VVL8CA, refCode, False)
   elif item == "hiddenServices_add"  : self.callingSELF.VVLlpO(self.VVL8CA, refCode, True)
   elif item == "hiddenServices_remove" : self.callingSELF.VVLlpO(self.VVL8CA, refCode, False)
   elif item == "VV7TxJ_multi" : self.VV7TxJ(refCode, True)
   elif item == "VV7TxJ_one" : self.VV7TxJ(refCode, False)
 def VV7TxJ(self, refCode, isMulti):
  bouquets = FF09hW()
  if bouquets:
   VVwdxM = []
   for item in bouquets:
    VVwdxM.append((item[0], item[1].toString()))
   VV0ixh = ("Create New", boundFunction(self.VVGw04, refCode, isMulti))
   FFsmMG(self.callingSELF, boundFunction(self.VVgOBy, refCode, isMulti), VVwdxM=VVwdxM, title="Add to Bouquet", VV0ixh=VV0ixh, VVXrUb=True, VVdN6x=True)
  else:
   FFIxs9(self.callingSELF, boundFunction(self.VVuCKf, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVgOBy(self, refCode, isMulti, bName=None):
  if bName:
   FFa70X(self.VVL8CA, boundFunction(self.VVjo2I, refCode, isMulti, bName), title="Adding Channels ...")
 def VVjo2I(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVijb7(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVsMMP = InfoBar.instance
    if VVsMMP:
     VVWPt4 = VVsMMP.servicelist
     if VVWPt4:
      mutableList = VVWPt4.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVL8CA.VVXTRT()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FF6zpT(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFGr6w(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVijb7(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVL8CA.VVdyz2(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVGw04(self, refCode, isMulti, VVyzEqObj, path):
  self.VVuCKf(refCode, isMulti)
 def VVuCKf(self, refCode, isMulti):
  FFK1qA(self.callingSELF, boundFunction(self.VVXvUx, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVXvUx(self, refCode, isMulti, name):
  if name:
   FFa70X(self.VVL8CA, boundFunction(self.VVMh40, refCode, isMulti, name), title="Adding Channels ...")
 def VVMh40(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVijb7(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVsMMP = InfoBar.instance
    if VVsMMP:
     VVWPt4 = VVsMMP.servicelist
     if VVWPt4:
      try:
       VVWPt4.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVWPt4.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVL8CA.VVXTRT()
   title = "Add to Bouquet"
   if allOK: FF6zpT(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFGr6w(self.callingSELF, "Nothing added!", title=title)
class CCIB92(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFFsgK(VVGF95, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFKXoA(self)
  FFhu6U(self["keyRed"]  , "Exit")
  FFhu6U(self["keyGreen"]  , "Save")
  FFhu6U(self["keyYellow"] , "Refresh")
  FFhu6U(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVvoh9  ,
   "green"   : self.VV9B6A ,
   "yellow"  : self.VVHmSc  ,
   "blue"   : self.VVdcQ0   ,
   "up"   : self.VVmzSZ    ,
   "down"   : self.VVcFVq   ,
   "left"   : self.VVPGw2   ,
   "right"   : self.VVxtQm   ,
   "cancel"  : self.VVvoh9
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVHmSc()
  self.VVss0I()
  FFFOZ8(self)
 def VVvoh9(self) : self.close(True)
 def VVN96j(self) : self.close(False)
 def VVdcQ0(self):
  self.session.openWithCallback(self.VVnMNs, boundFunction(CCsWIf))
 def VVnMNs(self, closeAll):
  if closeAll:
   self.close()
 def VVmzSZ(self):
  self.VVwXq1(1)
 def VVcFVq(self):
  self.VVwXq1(-1)
 def VVPGw2(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVss0I()
 def VVxtQm(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVss0I()
 def VVwXq1(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVcR2z(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVcR2z(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVcR2z(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVT57a(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVT57a(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVss0I(self):
  for obj in self.list:
   FFpRmN(obj, "#11404040")
  FFpRmN(self.list[self.index], "#11ff8000")
 def VVHmSc(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VV9B6A(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCH43c()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVqbRV)
 def VVqbRV(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FF6zpT(self, "Nothing returned from the system!")
  else:
   FF6zpT(self, str(result))
class CCsWIf(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFFsgK(VVFncf, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFKXoA(self, addLabel=True)
  FFhu6U(self["keyRed"]  , "Exit")
  FFhu6U(self["keyGreen"]  , "Sync")
  FFhu6U(self["keyYellow"] , "Refresh")
  FFhu6U(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVvoh9   ,
   "green"   : self.VVrG1P  ,
   "yellow"  : self.VV2Kdt ,
   "blue"   : self.VV3UcY  ,
   "cancel"  : self.VVvoh9
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVoQVc()
  self.onShow.append(self.start)
 def start(self):
  FFZQW5(self.refresh)
  FFFOZ8(self)
 def refresh(self):
  self.VVbq3Q()
  self.VVXrHc(False)
 def VVvoh9(self)  : self.close(True)
 def VV3UcY(self) : self.close(False)
 def VVoQVc(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVbq3Q(self):
  self.VVLiRH()
  self.VVdRDs()
  self.VVBw9q()
  self.VVpTfI()
 def VV2Kdt(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVoQVc()
   self.VVbq3Q()
   FFZQW5(self.refresh)
 def VVrG1P(self):
  if len(self["keyGreen"].getText()) > 0:
   FFIxs9(self, self.VV5YTZ, "Synchronize with Internet Date/Time ?")
 def VV5YTZ(self):
  self.VVbq3Q()
  FFZQW5(boundFunction(self.VVXrHc, True))
 def VVLiRH(self)  : self["keyRed"].show()
 def VVV8fs(self)  : self["keyGreen"].show()
 def VVTNkd(self) : self["keyYellow"].show()
 def VVwfSI(self)  : self["keyBlue"].show()
 def VVdRDs(self)  : self["keyGreen"].hide()
 def VVBw9q(self) : self["keyYellow"].hide()
 def VVpTfI(self)  : self["keyBlue"].hide()
 def VVXrHc(self, sync):
  localTime = FFRsTW()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVeUH7(server)
   if epoch_time is not None:
    ntpTime = FF5Ufp(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCH43c()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVqbRV, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVTNkd()
  self.VVwfSI()
  if ok:
   self.VVV8fs()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVqbRV(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVXrHc(False)
  except:
   pass
 def VVeUH7(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFCaZL():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCSyxm(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFFsgK(VVlzPL, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFKXoA(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  FFZQW5(self.VVoeYW)
 def VVoeYW(self):
  if FFCaZL(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFpRmN(self["myBody"], color)
   FFpRmN(self["myLabel"], color)
  except:
   pass
class CC8Kri(Screen):
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFfmL1()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFFsgK(VVjLx4, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCIvPO(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCIvPO(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCIvPO(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCOCST()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFKXoA(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVmzSZ          ,
   "down"  : self.VVcFVq         ,
   "left"  : self.VVPGw2         ,
   "right"  : self.VVxtQm         ,
   "info"  : self.VVjeyu        ,
   "epg"  : self.VVjeyu        ,
   "menu"  : self.VVnShr         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "last"  : boundFunction(self.VVOyn6, -1)  ,
   "next"  : boundFunction(self.VVOyn6, 1)  ,
   "pageUp" : boundFunction(self.VV2C1M, True) ,
   "chanUp" : boundFunction(self.VV2C1M, True) ,
   "pageDown" : boundFunction(self.VV2C1M, False) ,
   "chanDown" : boundFunction(self.VV2C1M, False) ,
   "0"   : boundFunction(self.VVOyn6, 0)  ,
   "1"   : boundFunction(self.VVhANr, pos=1) ,
   "2"   : boundFunction(self.VVhANr, pos=2) ,
   "3"   : boundFunction(self.VVhANr, pos=3) ,
   "4"   : boundFunction(self.VVhANr, pos=4) ,
   "5"   : boundFunction(self.VVhANr, pos=5) ,
   "6"   : boundFunction(self.VVhANr, pos=6) ,
   "7"   : boundFunction(self.VVhANr, pos=7) ,
   "8"   : boundFunction(self.VVhANr, pos=8) ,
   "9"   : boundFunction(self.VVhANr, pos=9) ,
  }, -1)
  self.onShown.append(self.VVa2bU)
  self.onClose.append(self.onExit)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  self.sliderSNR.VVkl4I()
  self.sliderAGC.VVkl4I()
  self.sliderBER.VVkl4I(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVhANr()
  self.VVCoCHInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVCoCH)
  except:
   self.timer.callback.append(self.VVCoCH)
  self.timer.start(500, False)
 def VVCoCHInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVmLOk(service)
  serviceName = self.tunerInfo.VV1A1J()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(self)
  tp = CCloky()
  txt = tp.VV9C7D(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVCoCH(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVmLOk(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVC2wj())
   self["mySNR"].setText(self.tunerInfo.VVgrgr())
   self["myAGC"].setText(self.tunerInfo.VVAl7s())
   self["myBER"].setText(self.tunerInfo.VVujp1())
   self.sliderSNR.VVz1Ci(self.tunerInfo.VVgUXt())
   self.sliderAGC.VVz1Ci(self.tunerInfo.VVzjFd())
   self.sliderBER.VVz1Ci(self.tunerInfo.VVSbEu())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVz1Ci(0)
   self.sliderAGC.VVz1Ci(0)
   self.sliderBER.VVz1Ci(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(self)
    if state and not state == "Tuned":
     FFU79C(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVjeyu(self):
  FFASWh(self, fncMode=CCAHNs.VVSpVM)
 def VVnShr(self):
  FFQsDF(self, VVfmTj + "_help_signal", "Signal Monitor (Keys)")
 def VVmzSZ(self)  : self.VVhANr(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVcFVq(self) : self.VVhANr(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVPGw2(self) : self.VVhANr(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVxtQm(self) : self.VVhANr(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVhANr(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVOyn6(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFsiza(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VV2C1M(self, isUp):
  FFU79C(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVCoCHInfo()
  except:
   pass
class CCIvPO(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVkl4I(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFpRmN(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVfmTj +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFpRmN(self.covObj, self.covColor)
   else:
    FFpRmN(self.covObj, "#00006688")
    self.isColormode = True
  self.VVz1Ci(0)
 def VVz1Ci(self, val):
  val  = FFsiza(val, self.minN, self.maxN)
  width = int(FFcGmm(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFsiza(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCu37C(Screen):
 VVcppe    = 0
 VVe8IQ = 1
 VVqL20 = 2
 VVyp4b  = 3
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VV6vg0=None, barTheme=VVcppe):
  ratio = self.VV3vlc(barTheme)
  self.skin, self.skinParam = FFFsgK(VVIRaO, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VV6vg0 = VV6vg0
  self.isCancelled = False
  self.isError  = False
  self.curValue  = 0
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVuEpa = None
  self.timer   = eTimer()
  self.myThread  = None
  FFKXoA(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVa2bU)
  self.onClose.append(self.onExit)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  self.VV4GuY()
  self["myProgBarVal"].setText("0%")
  FFpRmN(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVFXsX()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVFXsX)
  except:
   self.timer.callback.append(self.VVFXsX)
  self.timer.start(300, False)
  from threading import Thread as iThread
  self.myThread = iThread(name="threadFnc", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def onExit(self):
  self.timer.stop()
 def VVx354(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVcU8Y_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVuEpa), self.counter, self.maxValue, catName)
 def VVcU8Y_fromImportEPG(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVW1AW(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VVuEpa), self.counter, self.maxValue)
  except:
   pass
 def VVUlM3(self):
  self.isError = True
  self.cancel()
 def cancel(self):
  FFU79C(self, "Cancelling ...")
  self.isCancelled = True
  if self.VV6vg0:
   self.VV6vg0(False, self.VVuEpa, self.counter, self.maxValue, self.isError)
  self.close()
 def VVFXsX(self):
  val = FFsiza(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFcGmm(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if self.VV6vg0 and not self.isCancelled:
    self.VV6vg0(True, self.VVuEpa, self.counter, self.maxValue, self.isError)
   self.close()
 def VV4GuY(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVe8IQ, self.VVyp4b):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
  elif self.barTheme == self.VVqL20:
   pass
 def VV3vlc(self, barTheme):
  if   barTheme == self.VVe8IQ : return 0.7
  elif barTheme == self.VVqL20 : return 1
  elif barTheme == self.VVyp4b  : return 0.7
  else              : return 1
class CCH43c(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VV6vg0 = {}
  self.commandRunning = False
  self.VVIteZ  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VV6vg0, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VV6vg0[name] = VV6vg0
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVIteZ:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVt5iN, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVszCu , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVt5iN, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVszCu , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVszCu(name, retval)
  return True
 def VVt5iN(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVszCu(self, name, retval):
  if not self.VVIteZ:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VV6vg0[name]:
   self.VV6vg0[name](self.appResults[name], retval)
  del self.VV6vg0[name]
 def VVR0GP(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CChvFG(Screen):
 def __init__(self, session, title="", VVLuAj=None, VVLBhN=False, VViwBT=False, VVW7dW=False, VVvaay=False, VVewp5=False, VVPUvL=False, VVbIQl=VVUbEX, VVlT5W=None, VVqUQu=False, VVIkps=None, VVpqzv="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFFsgK(VVwgeJ, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFKXoA(self, addScrollLabel=True)
  if not VVpqzv:
   VVpqzv = "Processing ..."
  self["myLabel"].setText("   %s" % VVpqzv)
  self.VVLBhN   = VVLBhN
  self.VViwBT   = VViwBT
  self.VVW7dW   = VVW7dW
  self.VVvaay  = VVvaay
  self.VVewp5 = VVewp5
  self.VVPUvL = VVPUvL
  self.VVbIQl   = VVbIQl
  self.VVlT5W = VVlT5W
  self.VVqUQu  = VVqUQu
  self.VVIkps  = VVIkps
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCH43c()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFVjlE()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVLuAj, str):
   self.VVLuAj = [VVLuAj]
  else:
   self.VVLuAj = VVLuAj
  if self.VVW7dW or self.VVvaay:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVlWOd, VVlWOd)
   self.VVLuAj.append("echo -e '\n%s\n' %s" % (restartNote, FFdpXa(restartNote, VVX3gJ)))
   if self.VVW7dW:
    self.VVLuAj.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVLuAj.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVewp5:
   FFU79C(self, "Processing ...")
  self.onLayoutFinish.append(self.VVotXT)
  self.onClose.append(self.VV6Xjy)
 def VVotXT(self):
  self["myLabel"].VVA9a4(textOutFile="console" if self.enableSaveRes else "")
  if self.VVLBhN:
   self["myLabel"].VVSLZQ()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVBLnV()
  else:
   self.VVnz5G()
 def VVBLnV(self):
  if FFCaZL():
   self["myLabel"].setText("Processing ...")
   self.VVnz5G()
  else:
   self["myLabel"].setText(FFY8RM("\n   No connection to internet!", VVBEBZ))
 def VVnz5G(self):
  allOK = self.container.ePopen(self.VVLuAj[0], self.VVu2QC, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVu2QC("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVPUvL or self.VVW7dW or self.VVvaay:
    self["myLabel"].setText(FFNBmg("STARTED", VVX3gJ) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVIkps:
   colorWhite = CCGmwk.VVTCSR(VVaDNx)
   color  = CCGmwk.VVTCSR(self.VVIkps[0])
   words  = self.VVIkps[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVbIQl=self.VVbIQl)
 def VVu2QC(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVLuAj):
   allOK = self.container.ePopen(self.VVLuAj[self.cmdNum], self.VVu2QC, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVu2QC("Cannot connect to Console!", -1)
  else:
   if self.VVewp5 and FFpJmc(self):
    FFU79C(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVPUvL:
    self["myLabel"].appendText("\n" + FFNBmg("FINISHED", VVX3gJ), self.VVbIQl)
   if self.VVLBhN or self.VViwBT:
    self["myLabel"].VVSLZQ()
   if self.VVlT5W is not None:
    self.VVlT5W()
   if not retval and self.VVqUQu:
    self.VV6Xjy()
 def VV6Xjy(self):
  if self.container.VVR0GP():
   self.container.killAll()
class CCme9s(Screen):
 def __init__(self, session, VVLuAj=None, VVewp5=False):
  self.skin, self.skinParam = FFFsgK(VVwgeJ, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVbxzm + "ajpanel_terminal.history"
  self.customCommandsFile = VVbxzm + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FF5sfh("pwd") or "/home/root"
  self.container   = CCH43c()
  FFKXoA(self, addScrollLabel=True)
  FFhu6U(self["keyRed"] , "Exit = Stop Command")
  FFhu6U(self["keyGreen"] , "OK = History")
  FFhu6U(self["keyYellow"], "Menu = Custom Cmds")
  FFhu6U(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVmQRd ,
   "cancel" : self.VV31wM  ,
   "menu"  : self.VVeWzq ,
   "last"  : self.VVW6k9  ,
   "next"  : self.VVW6k9  ,
   "1"   : self.VVW6k9  ,
   "2"   : self.VVW6k9  ,
   "3"   : self.VVW6k9  ,
   "4"   : self.VVW6k9  ,
   "5"   : self.VVW6k9  ,
   "6"   : self.VVW6k9  ,
   "7"   : self.VVW6k9  ,
   "8"   : self.VVW6k9  ,
   "9"   : self.VVW6k9  ,
   "0"   : self.VVW6k9
  })
  self.onLayoutFinish.append(self.VVa2bU)
  self.onClose.append(self.VVJyIo)
 def VVa2bU(self):
  self["myLabel"].VVA9a4(isResizable=False, textOutFile="terminal")
  FF1NxI(self["keyRed"]  , "#00ff8000")
  FFpRmN(self["keyRed"]  , self.skinParam["titleColor"])
  FFpRmN(self["keyGreen"]  , self.skinParam["titleColor"])
  FFpRmN(self["keyYellow"] , self.skinParam["titleColor"])
  FFpRmN(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVeE6s(FF5sfh("date"), 5)
  result = FF5sfh("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVo6IK()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVfmTj + "LinuxCommands.lst"
   newTemplate = VVfmTj + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFoKN8("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFoKN8("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVJyIo(self):
  if self.container.VVR0GP():
   self.container.killAll()
   self.VVeE6s("Process killed\n", 4)
   self.VVo6IK()
 def VV31wM(self):
  if self.container.VVR0GP():
   self.VVJyIo()
  else:
   FFIxs9(self, self.close, "Exit ?", VViYBh=False)
 def VVo6IK(self):
  self.VVeE6s(self.prompt, 1)
  self["keyRed"].hide()
 def VVeE6s(self, txt, mode):
  if   mode == 1 : color = VVX3gJ
  elif mode == 2 : color = VVVJBw
  elif mode == 3 : color = VVaDNx
  elif mode == 4 : color = VVBEBZ
  elif mode == 5 : color = VVea45
  elif mode == 6 : color = VVKVzn
  else   : color = VVaDNx
  try:
   self["myLabel"].appendText(FFY8RM(txt, color))
  except:
   pass
 def VVEjXM(self, cmd):
  self["keyRed"].show()
  cmd = cmd.strip()
  if "#" in cmd:
   parts = cmd.split("#")
   left  = FFY8RM(parts[0].strip(), VVVJBw)
   right = FFY8RM("#" + parts[1].strip(), VVKVzn)
   txt = "%s    %s\n" % (left, right)
  else:
   txt = "%s\n" % cmd
  self.VVeE6s(txt, 2)
  lastLine = self.VVxyc4()
  if not lastLine or not cmd == lastLine:
   self.lastCommand = cmd
   self.VV8aDv(cmd)
  span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
  if span:
   self.curDir = span.group(1)
  allOK = self.container.ePopen(cmd, self.VVu2QC, dataAvailFnc=self.dataAvail, curDir=self.curDir)
  if not allOK:
   FFGr6w(self, "Cannot connect to Console!")
  self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVeE6s(data, 3)
 def VVu2QC(self, data, retval):
  if not retval == 0:
   self.VVeE6s("Exit Code : %d\n" % retval, 4)
  self.VVo6IK()
 def VVmQRd(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVxyc4() == "":
   self.VV8aDv("cd /tmp")
   self.VV8aDv("ls")
  VV2XDg = []
  if fileExists(self.commandHistoryFile):
   lines  = FFn8wV(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VV2XDg.append((str(c), line, str(lNum)))
   self.VVvSil(VV2XDg, title, self.commandHistoryFile, isHistory=True)
  else:
   FFI53L(self, self.commandHistoryFile, title=title)
 def VVxyc4(self):
  lastLine = FF5sfh("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VV8aDv(self, cmd):
  os.system("echo '%s' >> %s" % (cmd, self.commandHistoryFile))
 def VVeWzq(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFn8wV(self.customCommandsFile)
   lastLineIsSep = False
   VV2XDg = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VV2XDg.append((str(c), line, str(lNum)))
   self.VVvSil(VV2XDg, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFI53L(self, self.customCommandsFile, title=title)
 def VVvSil(self, VV2XDg, title, filePath=None, isHistory=False):
  if VV2XDg:
   VVfU42 = "#05333333"
   if isHistory: VVslef = VV7O11 = VVPOXl = "#11000020"
   else  : VVslef = VV7O11 = VVPOXl = "#06002020"
   VVzhrG = VVwqYz = None
   VVRjvg   = ("Send"   , self.VVcryB        , [])
   VVcGuB  = ("Modify & Send" , self.VVmCtl        , [])
   if isHistory:
    VVzhrG = ("Clear History" , self.VVonsz        , [])
   elif filePath:
    VVwqYz = ("Edit File"  , boundFunction(self.VVnDRx, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VVxqTz     = (CENTER  , LEFT   , CENTER )
   FFsX1L(self, None, title=title, header=header, VVbKpp=VV2XDg, VVxqTz=VVxqTz, VVRSoy=widths, VVA2Pa=26, VVRjvg=VVRjvg, VVcGuB=VVcGuB, VVzhrG=VVzhrG, VVwqYz=VVwqYz, VVuZx4=True
     , VVslef   = VVslef
     , VV7O11   = VV7O11
     , VVPOXl   = VVPOXl
     , VVXIBQ  = "#05ffff00"
     , VVfU42  = VVfU42
    )
  else:
   FF2TvG(self, filePath, title=title)
 def VVcryB(self, VVL8CA, title, txt, colList):
  cmd = colList[1].strip()
  VVL8CA.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVeE6s("\n%s\n" % cmd, 6)
   self.VVeE6s(self.prompt, 1)
  else:
   if cmd.startswith("passwd"):
    self.VVeE6s(cmd, 2)
    self.VVeE6s("\nCannot change passwrod from Console this way. Try using:\n", 4)
    txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
    for ch in txt:
     if not ch == "#":
      self.VVeE6s(ch, 0)
    self.VVeE6s("\nor\n", 4)
    self.VVeE6s("echo root:NEW_PASSWORD | chpasswd\n", 0)
    self.VVo6IK()
   else:
    self.VVEjXM(cmd)
 def VVmCtl(self, VVL8CA, title, txt, colList):
  cmd = colList[1]
  self.VVhwh3(VVL8CA, cmd)
 def VVonsz(self, VVL8CA, title, txt, colList):
  FFIxs9(self, boundFunction(self.VVUMZg, VVL8CA), "Reset History File ?", title="Command History")
 def VVUMZg(self, VVL8CA):
  os.system(FFoKN8("echo '' > %s" % self.commandHistoryFile))
  VVL8CA.cancel()
 def VVnDRx(self, filePath, VVL8CA, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCk6mL(self, filePath, VV6vg0=boundFunction(self.VVxKTL, VVL8CA), curRowNum=rowNum)
  else     : FFI53L(self, filePath)
 def VVxKTL(self, VVL8CA, fileChanged):
  if fileChanged:
   VVL8CA.cancel()
   FFZQW5(self.VVeWzq)
 def VVW6k9(self):
  self.VVhwh3(None, self.lastCommand)
 def VVhwh3(self, VVL8CA, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFK1qA(self, boundFunction(self.VVBcQe, VVL8CA), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVBcQe(self, VVL8CA, cmd):
  if cmd and len(cmd) > 0:
   self.VVEjXM(cmd)
   if VVL8CA:
    VVL8CA.cancel()
class CCwgCJ(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVb9jI="", VVhQTT=False, VVZUao=False, isTrimEnds=True):
  self.skin, self.skinParam = FFFsgK(VVn45i, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFKXoA(self, title, addLabel=True)
  FFhu6U(self["keyRed"] , "Up/Down = Change")
  FFhu6U(self["keyGreen"] , "Overwrite")
  FFhu6U(self["keyYellow"], "Pick Key Map")
  FFhu6U(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVZUao   = VVZUao
  self.VVhQTT  = VVhQTT
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVb9jI, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVuaQu      ,
   "green"    : self.VVEAPT    ,
   "yellow"   : self.VVye9T      ,
   "blue"    : self.VVKodB     ,
   "menu"    : self.VVPFSp     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVQFip, True) ,
   "down"    : boundFunction(self.VVQFip, False) ,
   "left"    : self.VVKuof       ,
   "right"    : self.VVYaiF       ,
   "home"    : self.VVeGQl       ,
   "end"    : self.VVg8W6       ,
   "next"    : self.VVN6f0      ,
   "last"    : self.VVSdfY      ,
   "deleteForward"  : self.VVN6f0      ,
   "deleteBackward" : self.VVSdfY      ,
   "tab"    : self.VVNcSy       ,
   "toggleOverwrite" : self.VVEAPT    ,
   "0"     : self.VVJVfS     ,
   "1"     : self.VVJVfS     ,
   "2"     : self.VVJVfS     ,
   "3"     : self.VVJVfS     ,
   "4"     : self.VVJVfS     ,
   "5"     : self.VVJVfS     ,
   "6"     : self.VVJVfS     ,
   "7"     : self.VVJVfS     ,
   "8"     : self.VVJVfS     ,
   "9"     : self.VVJVfS
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVs9Zh()
  self.onShown.append(self.VVa2bU)
  self.onClose.append(self.onExit)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  self["myLabel"].setText(self.message)
  self.VVlB0q()
  if self.VVhQTT : self.VVEAPT()
  else    : self.VVv5P8()
  FFFOZ8(self)
  FFpRmN(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVPA8v)
  except:
   self.timer.callback.append(self.VVPA8v)
 def onExit(self):
  self.timer.stop()
 def VVuaQu(self):
  self.VVj8bm()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVj8bm()
  self.close(None)
 def VVPFSp(self):
  VVwdxM = []
  VVwdxM.append(("Home"         , "home"    ))
  VVwdxM.append(("End"         , "end"     ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Clear All"       , "clearAll"   ))
  VVwdxM.append(("Clear To Home"      , "clearToHome"   ))
  VVwdxM.append(("Clear To End"       , "clearToEnd"   ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVUPCw:
   VVwdxM.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("To Capital Letters"     , "toCapital"   ))
  VVwdxM.append(("To Small Letters"      , "toSmall"    ))
  FFsmMG(self, self.VVb8O5, title="Edit Options", VVwdxM=VVwdxM)
 def VVb8O5(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVeGQl()
   elif item == "end"     : self.VVg8W6()
   elif item == "clearAll"    : self.VVfIRm()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVeGQl()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVUPCw
    VVUPCw = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVUPCw)
    self.VVeGQl()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVPA8v(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVEAPT(self):
  self["myInput"].toggleOverwrite()
  self.VVv5P8()
 def VVye9T(self):
  self.session.openWithCallback(self.VVR70l, boundFunction(CCsZz6, mode=self.charMode, VVZUao=self.VVZUao))
 def VVR70l(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVlB0q()
 def VVv5P8(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVs9Zh(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVj8bm(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVglLd(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVKuof(self)     : self.VVw3wD(self["myInput"].left)
 def VVYaiF(self)     : self.VVw3wD(self["myInput"].right)
 def VVN6f0(self)     : self.VVw3wD(self["myInput"].delete)
 def VVeGQl(self)     : self.VVw3wD(self["myInput"].home)
 def VVg8W6(self)     : self.VVw3wD(self["myInput"].end)
 def VVSdfY(self)    : self.VVw3wD(self["myInput"].deleteBackward)
 def VVNcSy(self)     : self.VVw3wD(self["myInput"].tab)
 def VVfIRm(self)     : self["myInput"].setText("")
 def VVw3wD(self, fnc):
  fnc()
  self.VVPA8v()
 def VVJVfS(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVglLd(newChar, overwrite)
   self.VVKdGJ(newChar, self["myInput"].mapping[number])
 def VVQFip(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCsZz6.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCsZz6.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVglLd(newChar, True)
   for group in groups:
    if newChar in group:
     self.VVKdGJ(newChar, group)
     break
 def VVKdGJ(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVaDNx:
    group = VVea45 + group.replace(newChar, FFY8RM(newChar, VVaDNx, VVea45))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVKodB(self):
  if self.VVZUao : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVlB0q()
 def VVlB0q(self):
  self["myInput"].mapping = CCsZz6.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCsZz6.RCU_MAP_TITLES[self.charMode])
class CCsZz6(Screen):
 VVqhO0  = 0
 VV3lE1  = 1
 VViyfv  = 2
 VVuzDH  = 3
 VViowD = 4
 VVAo7O = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols, arabic_nums1, arabic1)
       , ( symbols, arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A" , u"\u0628")
       , (u"\u0647" , u"\u062A")
       )
 def __init__(self, session, mode=VVqhO0, VVZUao=False):
  self.skin, self.skinParam = FFFsgK(VVjyaz, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVZUao  = VVZUao
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFKXoA(self, title=self.Title)
  FFhu6U(self["keyRed"] ,"OK = Select")
  FFhu6U(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVC3hS     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVMVMQ, -1) ,
   "next"  : boundFunction(self.VVMVMQ, +1) ,
   "left"  : boundFunction(self.VVMVMQ, -1) ,
   "right"  : boundFunction(self.VVMVMQ, +1) ,
  }, -1)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  FFpRmN(self["keyRed"], "#11222222")
  FFpRmN(self["keyGreen"], "#11222222")
  self.VVUZFB()
 def VVUZFB(self):
  self.VVFoGB()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVFoGB(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVMVMQ(self, direction):
  if self.VVZUao : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVUZFB()
 def VVC3hS(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCyhl9(Screen):
 def __init__(self, session, title="", message="", VVbIQl=VVUbEX, VV5ijV=False, VVPOXl=None, VVA2Pa=30):
  self.skin, self.skinParam = FFFsgK(VVwgeJ, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVA2Pa)
  self.session   = session
  FFKXoA(self, title, addScrollLabel=True)
  self.VVbIQl   = VVbIQl
  self.VV5ijV   = VV5ijV
  self.VVPOXl   = VVPOXl
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  self["myLabel"].VVA9a4(VV5ijV=self.VV5ijV)
  self["myLabel"].setText(self.message, self.VVbIQl)
  if self.VVPOXl:
   FFpRmN(self["myBody"], self.VVPOXl)
   FFpRmN(self["myLabel"], self.VVPOXl)
   FFBavC(self["myLabel"], self.VVPOXl)
  self["myLabel"].VVSLZQ()
class CCPu5L(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFFsgK(VVfgzn, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFKXoA(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  path = VVfmTj + "err.png"
  if fileExists(path):
   self["errPic"].instance.setScale(1)
   self["errPic"].instance.setPixmapFromFile(path)
class CChh4T(Screen, CCigLq):
 PLAYER_INSTANCE = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False):
  self.skin, self.skinParam = FFFsgK(VVvgu9, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCigLq.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  FFKXoA(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVCaR1())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVPtX0         ,
   "info"  : self.VVjeyu        ,
   "epg"  : self.VVjeyu        ,
   "menu"  : self.FFsmMG         ,
   "cancel" : self.cancel         ,
   "red"  : self.VVW1TF        ,
   "blue"  : self.VVFKeY        ,
   "green"  : boundFunction(self.VVKV2W, True),
   "yellow" : self.VV8Axg   ,
   "left"  : boundFunction(self.VVVhpL, -1)   ,
   "right"  : boundFunction(self.VVVhpL,  1)   ,
   "play"  : self.VVW1TF        ,
   "pause"  : self.VVW1TF        ,
   "playPause" : self.VVW1TF        ,
   "stop"  : self.VVW1TF        ,
   "rewind" : self.VVGej4        ,
   "forward" : self.VVCaSS        ,
   "rewindDm" : self.VVGej4        ,
   "forwardDm" : self.VVCaSS        ,
   "last"  : boundFunction(self.VVZ6pl, 0)    ,
   "next"  : self.VVveaz        ,
   "pageUp" : boundFunction(self.VVC9bc, True) ,
   "pageDown" : boundFunction(self.VVC9bc, False) ,
   "chanUp" : boundFunction(self.VVC9bc, True) ,
   "chanDown" : boundFunction(self.VVC9bc, False) ,
   "up"  : boundFunction(self.VVC9bc, True) ,
   "down"  : boundFunction(self.VVC9bc, False) ,
   "0"   : boundFunction(self.VVZnoR , 10)  ,
   "1"   : boundFunction(self.VVZnoR , 1)  ,
   "2"   : boundFunction(self.VVZnoR , 2)  ,
   "3"   : boundFunction(self.VVZnoR , 3)  ,
   "4"   : boundFunction(self.VVZnoR , 4)  ,
   "5"   : boundFunction(self.VVZnoR , 5)  ,
   "6"   : boundFunction(self.VVZnoR , 6)  ,
   "7"   : boundFunction(self.VVZnoR , 7)  ,
   "8"   : boundFunction(self.VVZnoR , 8)  ,
   "9"   : boundFunction(self.VVZnoR , 9)
  }, -1)
  self.onShown.append(self.VVa2bU)
  self.onClose.append(self.onExit)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  if not CChh4T.PLAYER_INSTANCE or self.portalTableParam:
   CChh4T.PLAYER_INSTANCE = self
  else:
   self.close()
  self.VVnKP5()
  self.instance.move(ePoint(40, 40))
  self.VVejet(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVvbDT)
  except:
   self.timer.callback.append(self.VVvbDT)
  self.timer.start(250, False)
  self.VVvbDT("Checking ...")
  self.VVKV2W()
 def onExit(self):
  self.timer.stop()
  CChh4T.PLAYER_INSTANCE = None
 def VVnKP5(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FFpRmN(self["myTitle"], color)
 def FFsmMG(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(self)
  VVwdxM = []
  if self.isFromExternal:
   VVwdxM.append(("IPTV Menu"    , "iptv" ))
   VVwdxM.append(VVWygA)
  if FFba7t(iptvRef) and not "&end=" in decodedUrl and not any(x in decodedUrl for x in ("/movie/", "/series/")):
   uType, uHost, uUser, uPass, uId, uChName = CCjXCp.VVcHfY(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVwdxM.append(("Catchup Programs"  , "catchup" ))
    VVwdxM.append(VVWygA)
  VVwdxM.append(("Stop Current Service"   , "stop" ))
  if not "&end=" in decodedUrl:
   VVwdxM.append(("Restart Current Service" , "restart" ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Move to Top"     , "top"  ))
  VVwdxM.append(("Move to Bottom"    , "botm" ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Help"       , "help" ))
  FFsmMG(self, self.VVEiL9, VVwdxM=VVwdxM, width=550, title="Options")
 def VVEiL9(self, item=None):
  if item:
   if item == "iptv"  :
    self.session.open(CCjXCp)
    self.close()
   elif item == "catchup" : self.VV8Axg()
   elif item == "stop"  : self.VV4Yfb(0)
   elif item == "restart" : self.VV4Yfb(1)
   elif item == "botm"  : self.VVejet(0)
   elif item == "top"  : self.VVejet(1)
   elif item == "help"  : FFQsDF(self, VVfmTj + "_help_player", "Player Controller (Keys)")
 def VV4Yfb(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.close()
   elif typ == 1:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
 def VVejet(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VVPtX0(self):
  if self.isManualSeek:
   self.VVqOif()
   self.VVZ6pl(self.manualSeekPts)
  else:
   if self.shown: self.hide()
   else   : self.show()
 def cancel(self):
  if self.isManualSeek:
   self.VVqOif()
  else:
   self.close()
 def VVjeyu(self):
  FFASWh(self, fncMode=CCAHNs.VVvYBs)
 def VVW1TF(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
   inst.playpauseStreamService()
  except Exception as e:
   pass
  self.VVvbDT("Toggling Play/Pause ...")
 def VVqOif(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVVhpL(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVuxMO()
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.jumpMinutes * 60.0
   else:
    self.manualSeekSec += direc * self.jumpMinutes * 60.0
    self.manualSeekSec = FFsiza(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFcGmm(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFRq1D(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVZnoR(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   FFhu6U(self["myPlayJmp"], self.VVCaR1())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVvbDT("Changed Jump Minutes to : %d" % val)
 def VVCaR1(self):
  return "Jump:%dm" % self.jumpMinutes
 def VVvbDT(self, stateTxt=""):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(self)
  fr = res = ""
  if info:
   w = FFN7dA(info, iServiceInformation.sVideoWidth) or -1
   h = FFN7dA(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFN7dA(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CCAHNs.VVorfb(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVuxMO()
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FFsiza(percVal, 0, 100)
    width = int(FFcGmm(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   FF1NxI(self["myPlayMsg"], "#00ff8066")
   self["myPlayMsg"].setText("-" if decodedUrl else FFc8Er(refCode, True))
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not durTxt:
   self["myPlayVal"].setText(">>>>>")
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText(prov)
  if not posTxt:
   self["myPlayPos"].setText("")
  if not remTxt:
   self["myPlayRem"].setText("")
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VVisTJ() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   FF1NxI(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVjsKM()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VVZ6pl(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
  state = self.VV9YD0()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FF1NxI(self["myPlayMsg"], "#0000ff00")
  else     : FF1NxI(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVuxMO(self):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = self.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFRq1D(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFRq1D(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal
      remTxt = FFRq1D(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVFKeY(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVisTJ()
   if cList:
    VVwdxM = []
    for pts, what in cList:
     txt = FFRq1D(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVwdxM.append((txt, pts))
    FFsmMG(self, self.VVMA8B, VVwdxM=VVwdxM, title="Cut List")
   else:
    self.VVvbDT("No Cut-List for this channel !")
 def VVMA8B(self, item=None):
  if item:
   self.VVZ6pl(item)
 def VVisTJ(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVCaSS(self) : self.VVDKUJ(self.jumpMinutes)
 def VVGej4(self) : self.VVDKUJ(-self.jumpMinutes)
 def VVDKUJ(self, mins):
  try:
   inst = InfoBar.instance
   inst.doSeekRelative(mins * 60 * 90000)
   inst.hide()
   if   mins > 0 : self.VVvbDT("Forawrd (%d min) ..." % self.jumpMinutes)
   elif mins < 0 : self.VVvbDT("Rewind (%d min) ..." % self.jumpMinutes)
  except:
   self.VVvbDT("Cannot jump")
 def VV8tPo(self):
  InfoBar.instance.VV8tPo()
 def VVZ6pl(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVvbDT("Changing Time ...")
 def VVveaz(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVuxMO()
   if durVal > 0:
    pts = int(durVal * 60 * 90000)
    InfoBar.instance.doSeek(pts)
    self.VVvbDT("Jumping to end ...")
  except:
   pass
 def VVjsKM(self):
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VV9YD0(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVC9bc(self, isUp):
  if self.enableZapping:
   self.VVvbDT("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVqOif()
   if self.portalTableParam:
    self.VVaxXD(isUp)
   else:
    try:
     if isUp : InfoBar.instance.zapDown()
     else : InfoBar.instance.zapUp()
    except:
     pass
    self.lastPlayPos = 0
    self.VVnKP5()
    self.VVKV2W()
 def VVaxXD(self, isUp):
  CCjXCp_inatance, VVL8CA, mode = self.portalTableParam
  if isUp : VVL8CA.VVgTA5()
  else : VVL8CA.VVl69j()
  FFa70X(VVL8CA, boundFunction(self.VV99fm, mode, VVL8CA, CCjXCp_inatance), title="Playing ...")
 def VV99fm(self, mode, VVL8CA, CCjXCp_inatance):
  colList = VVL8CA.VV4AJr()
  if mode == "localIptv":
   CCjXCp_inatance.VVMmwq(True, VVL8CA, "", "", colList)
  elif isinstance(mode, int):
   CCjXCp_inatance.VVN87Z(mode, True, VVL8CA, "", "", colList)
  else:
   CCjXCp_inatance.VViWGm(mode, True, VVL8CA, "", "", colList)
  self.close()
 def VVKV2W(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVuxMO()
    if posTxt:
     return
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(self)
   if not self.VVxwrt(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVvbDT("Refreshing Portal")
   FFZQW5(self.VVcuC3)
  except:
   pass
 def VVcuC3(self):
  self.restoreLastPlayPos = self.VVHD1k()
 def VV8Axg(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFQzn1(self)
  if not decodedUrl or any(x in decodedUrl for x in ("/movie/", "/series/")):
   self.VVvbDT("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.index(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCjXCp.VVcHfY(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVvbDT("Reading Program List ...")
   ok_fnc = boundFunction(self.VVbrla, refCode, chName, streamId, uHost, uUser, uPass)
   FFZQW5(boundFunction(CCjXCp.VVpasw, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVvbDT("Cannot process this channel")
 def VVbrla(self, refCode, chName, streamId, uHost, uUser, uPass, VVL8CA, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVL8CA.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVvbDT("Changing Program ...")
   FFZQW5(boundFunction(self.VVHLXZ, chUrl))
  else:
   self.VVvbDT("Incorrect Timestamp !")
 def VVHLXZ(self, chUrl):
   FFsOcb(self, chUrl, VVuw4l=False)
   self.lastPlayPos = 0
   self.VVnKP5()
class CCrHv1(Screen):
 def __init__(self, session, title="", VVadeJ="Continue?", VViYBh=True, VVuXa8=False):
  self.skin, self.skinParam = FFFsgK(VV4Jy1, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVadeJ = VVadeJ
  self.VVuXa8 = VVuXa8
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VViYBh : VVwdxM = [no , yes]
  else   : VVwdxM = [yes, no ]
  FFKXoA(self, title, VVwdxM=VVwdxM, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVPtX0 ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVadeJ)
  if self.VVuXa8:
   self["myLabel"].instance.setHAlign(0)
  self.VVGt4N()
  FFfopI(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FF65YQ(self["myMenu"])
  FFxJLq(self, self["myMenu"])
 def VVPtX0(self):
  item = FFY2w4(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVGt4N(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCKusJ(Screen):
 def __init__(self, session, title="", VVwdxM=None, width=1000, OKBtnFnc=None, VVC269=None, VVcvF8=None, VV0ixh=None, VVu6qN=None, VVXrUb=False, VVdN6x=False):
  self.skin, self.skinParam = FFFsgK(VVQV0S, width, 850, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVwdxM   = VVwdxM
  self.OKBtnFnc   = OKBtnFnc
  self.VVC269   = VVC269
  self.VVcvF8  = VVcvF8
  self.VV0ixh  = VV0ixh
  self.VVu6qN   = VVu6qN
  self.VVXrUb  = VVXrUb
  self.VVdN6x  = VVdN6x
  FFKXoA(self, title, VVwdxM=VVwdxM)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVPtX0          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVkGHI         ,
   "green"  : self.VVSRpv         ,
   "yellow" : self.VVog4J         ,
   "blue"  : self.VVtnSN         ,
   "pageUp" : self.VVE76Q       ,
   "chanUp" : self.VVE76Q       ,
   "pageDown" : self.VVZqq9        ,
   "chanDown" : self.VVZqq9
  }, -1)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  FFfopI(self["myMenu"])
  FFwO6z(self)
  self.VVASbM(self["keyRed"]  , self.VVC269 )
  self.VVASbM(self["keyGreen"] , self.VVcvF8 )
  self.VVASbM(self["keyYellow"] , self.VV0ixh )
  self.VVASbM(self["keyBlue"]  , self.VVu6qN )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFFOZ8(self)
 def VVASbM(self, btnObj, btnFnc):
  if btnFnc:
   FFhu6U(btnObj, btnFnc[0])
 def VVPtX0(self):
  item = FFY2w4(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVXrUb: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVkGHI(self)  : self.VVw3wD(self.VVC269)
 def VVSRpv(self) : self.VVw3wD(self.VVcvF8)
 def VVog4J(self) : self.VVw3wD(self.VV0ixh)
 def VVtnSN(self) : self.VVw3wD(self.VVu6qN)
 def VVw3wD(self, btnFnc):
  if btnFnc:
   item = FFY2w4(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVdN6x:
    self.cancel()
 def VVjXxM(self, VVwdxM):
  if len(VVwdxM) > 0:
   newList = []
   for item in VVwdxM:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVADMA(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVE76Q(self):
  self["myMenu"].moveToIndex(0)
 def VVZqq9(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCdzzH(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VVbKpp=None, VVxqTz=None, VVRSoy=None, VVA2Pa=26, VVuZx4=False, VVRjvg=None, VVCijI=None, VVZOCH=None, VVcGuB=None, VVzhrG=None, VVwqYz=None, VVdvWi=None, VVRExa=None, VV3Ab1=None, VVdyvC=-1, VVKqJC=False, searchCol=0, VVslef=None, VV7O11=None, VVboNh="#00dddddd", VVPOXl="#11002233", VVXIBQ="#00ff8833", VVfU42="#11111111", VVd2OO="#0a555555", VV1Lwh="#0affffff", VVm63O="#11552200", VVt6CB="#0055ff55"):
  self.skin, self.skinParam = FFFsgK(VVI3cc, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFKXoA(self, title)
  self.header     = header
  self.VVbKpp     = VVbKpp
  self.totalCols    = len(VVbKpp[0])
  self.VV1udG   = 0
  self.lastSortModeIsReverese = False
  self.VVuZx4   = VVuZx4
  self.VVTTSU   = 0.01
  self.VVuGUg   = 0.02
  self.VVhShs  = 1
  self.VVRSoy = VVRSoy
  self.colWidthPixels   = []
  self.VVRjvg   = VVRjvg
  self.OKButtonObj   = None
  self.VVCijI   = VVCijI
  self.VVZOCH   = VVZOCH
  self.VVcGuB   = VVcGuB
  self.VVzhrG  = VVzhrG
  self.VVwqYz   = VVwqYz
  self.VVdvWi    = VVdvWi
  self.VVRExa   = VVRExa
  self.VV3Ab1  = VV3Ab1
  self.VVdyvC    = VVdyvC
  self.VVKqJC   = VVKqJC
  self.searchCol    = searchCol
  self.VVxqTz    = VVxqTz
  self.keyPressed    = -1
  self.VVA2Pa    = FF5ZEu(VVA2Pa)
  self.VVCg7w    = FFl95Q(self.VVA2Pa, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVslef    = VVslef
  self.VV7O11      = VV7O11
  self.VVboNh    = FFzcsD(VVboNh)
  self.VVPOXl    = FFzcsD(VVPOXl)
  self.VVXIBQ    = FFzcsD(VVXIBQ)
  self.VVfU42    = FFzcsD(VVfU42)
  self.VVd2OO   = FFzcsD(VVd2OO)
  self.VV1Lwh    = FFzcsD(VV1Lwh)
  self.VVm63O    = FFzcsD(VVm63O)
  self.VVt6CB   = FFzcsD(VVt6CB)
  self.VVF3ID  = False
  self.selectedItems   = 0
  self.VVvsq6   = FFzcsD("#01fefe01")
  self.VVS4ZO   = FFzcsD("#11400040")
  self.VVAVes  = self.VVvsq6
  self.VVfNf9  = self.VVfU42
  if self.VVKqJC:
   self["keyMenu1F"].hide()
   self["keyMenu1"].hide()
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVrahZ  ,
   "red"   : self.VVMBJw  ,
   "green"   : self.VVB8E6 ,
   "yellow"  : self.VVLuVS ,
   "blue"   : self.VVyW3M  ,
   "menu"   : self.VV4Fde ,
   "info"   : self.VVuRda  ,
   "cancel"  : self.VVkmSd  ,
   "up"   : self.VVl69j    ,
   "down"   : self.VVgTA5  ,
   "left"   : self.VV3K59   ,
   "right"   : self.VVUwVU  ,
   "pageUp"  : self.VVbgXW  ,
   "chanUp"  : self.VVbgXW  ,
   "pageDown"  : self.VVTVNm  ,
   "chanDown"  : self.VVTVNm
  }, -1)
  FFUYXl(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  try:
   self.VVhlJN()
  except Exception as err:
   FFGr6w(self, str(err))
   self.close(None)
 def VVhlJN(self):
  FFFOZ8(self)
  if self.VVslef:
   FFpRmN(self["myTitle"], self.VVslef)
  if self.VV7O11:
   FFpRmN(self["myBody"] , self.VV7O11)
   FFpRmN(self["myTableH"] , self.VV7O11)
   FFpRmN(self["myTable"] , self.VV7O11)
   FFpRmN(self["myBar"]  , self.VV7O11)
  self.VVASbM(self.VVZOCH  , self["keyRed"])
  self.VVASbM(self.VVcGuB  , self["keyGreen"])
  self.VVASbM(self.VVzhrG , self["keyYellow"])
  self.VVASbM(self.VVwqYz  , self["keyBlue"])
  if self.VVRjvg:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVRjvg[0])
    FFpRmN(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVCg7w)
  self["myTableH"].l.setFont(0, gFont(VVbhwc, self.VVA2Pa))
  self["myTable"].l.setItemHeight(self.VVCg7w)
  self["myTable"].l.setFont(0, gFont(VVbhwc, self.VVA2Pa))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVCg7w)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVCg7w))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVCg7w)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVCg7w
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVCg7w * len(self.VVbKpp) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVRSoy:
   self.VVRSoy = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVRSoy)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVxqTz:
   self.VVxqTz = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVxqTz
   self.VVxqTz = []
   for item in tmpList:
    self.VVxqTz.append(item | RT_VALIGN_CENTER)
  self.VV7kWU()
  if self.VVdvWi:
   self.VVdvWi(self)
 def VVASbM(self, btnFnc, btn):
  if btnFnc : FFhu6U(btn, btnFnc[0])
  else  : FFhu6U(btn, "")
 def VVzZ3H(self, waitTxt):
  FFa70X(self, self.VV7kWU, title=waitTxt)
 def VV7kWU(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VViSqy(0, self.header, self.VV1Lwh, self.VVm63O, self.VV1Lwh, self.VVm63O, self.VVt6CB)])
   rows = []
   for c, row in enumerate(self.VVbKpp):
    rows.append(self.VViSqy(c, row, self.VVboNh, self.VVPOXl, self.VVXIBQ, self.VVfU42, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVdyvC > -1:
    self["myTable"].moveToIndex(self.VVdyvC )
   self.VVDm0k()
   if self.VVKqJC:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVCg7w * len(self.VVbKpp)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVRExa:
    self.VVw3wD(self.VVRExa, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFGr6w(self, str(err))
    self.close()
   except:
    pass
 def VViSqy(self, keyIndex, columns, VVboNh, VVPOXl, VVXIBQ, VVfU42, VVt6CB):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVt6CB and ndx == self.VV1udG : textColor = VVt6CB
   else           : textColor = VVboNh
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFzcsD(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVPOXl = c
    entry = span.group(3)
   if self.VVxqTz[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVCg7w)
           , font   = 0
           , flags   = self.VVxqTz[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVPOXl
           , color_sel  = VVXIBQ
           , backcolor_sel = VVfU42
           , border_width = 1
           , border_color = self.VVd2OO
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVuRda(self):
  rowData = self.VVunoX()
  if rowData:
   title, txt, colList = rowData
   if self.VVCijI:
    fnc  = self.VVCijI[1]
    params = self.VVCijI[2]
    fnc(self, title, txt, colList)
   else:
    FFMt3I(self, txt, title)
 def VVrahZ(self):
  if   self.VVF3ID : self.VViYeF(self.VVlsdL(), mode=2)
  elif self.VVRjvg  : self.VVw3wD(self.VVRjvg, None)
  else      : self.VVuRda()
 def VVMBJw(self) : self.VVw3wD(self.VVZOCH , self["keyRed"])
 def VVB8E6(self) : self.VVw3wD(self.VVcGuB , self["keyGreen"])
 def VVLuVS(self): self.VVw3wD(self.VVzhrG , self["keyYellow"])
 def VVyW3M(self) : self.VVw3wD(self.VVwqYz , self["keyBlue"])
 def VVw3wD(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFU79C(self, buttonFnc[3])
    FFZQW5(boundFunction(self.VV0K61, buttonFnc))
   else:
    self.VV0K61(buttonFnc)
 def VV0K61(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVunoX()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VViYeF(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VVbKpp[ndx]
   isSelected = row[1][9] == self.VVvsq6
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VViSqy(ndx, item, self.VVboNh, self.VVPOXl, self.VVXIBQ, self.VVfU42, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VViSqy(ndx, item, self.VVvsq6, self.VVS4ZO, self.VVAVes, self.VVfNf9, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVDm0k()
 def VVCXGx(self):
  FFa70X(self, self.VVpHQA, title="Selecting all ...")
 def VVpHQA(self):
  self.VVjJv0(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVvsq6
   if not isSelected:
    item = self.VVbKpp[ndx]
    newRow = self.VViSqy(ndx, item, self.VVvsq6, self.VVS4ZO, self.VVAVes, self.VVfNf9, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVDm0k()
  self.VVrDoy()
 def VVRJ0z(self):
  FFa70X(self, self.VVqT1q, title="Unselecting all ...")
 def VVqT1q(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVvsq6:
    item = self.VVbKpp[ndx]
    newRow = self.VViSqy(ndx, item, self.VVboNh, self.VVPOXl, self.VVXIBQ, self.VVfU42, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVDm0k()
  self.VVrDoy()
 def VVrDoy(self):
  self.hide()
  self.show()
 def VVunoX(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVRSoy[i] > 1 or self.VVRSoy[i] == self.VVTTSU:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VVbKpp))
   return rowNum, txt, colList
  else:
   return None
 def VVkmSd(self):
  if self.VV3Ab1 : self.VV3Ab1(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VV1hep(self):
  return self["myTitle"].getText().strip()
 def VVdR5e(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VV7fYZ(self, txt):
  FFU79C(self, txt)
 def VV5Ruh(self, txt):
  FFU79C(self, txt, 1000)
 def VVXTRT(self):
  FFU79C(self)
 def VV4fXI(self):
  return len(self.VVbKpp)
 def VV59wi(self): self["keyGreen"].show()
 def VVRsrd(self): self["keyGreen"].hide()
 def VVlsdL(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VV5Kj3(self):
  return len(self["myTable"].list)
 def VVjJv0(self, isOn):
  self.VVF3ID = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   if self.VVwqYz: self["keyBlue"].hide()
   if self.VVRjvg and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
   if self.VVwqYz: self["keyBlue"].show()
   if self.VVRjvg and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVRjvg[0])
   self.VVRJ0z()
  FFpRmN(self["myTitle"], color)
  FFpRmN(self["myBar"]  , color)
 def VVOdDi(self):
  return self.VVF3ID
 def VVcrKb(self):
  return self.selectedItems
 def VV4dVP(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVDm0k()
 def VVIgGQ(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVDm0k()
 def VVOad6(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VVbKpp:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVzO1X(self):
  txt  = "Total Rows\t: %d\n\n" % self.VV4fXI()
  txt += FFNBmg("Total Unique Items", VVBEBZ)
  for i in range(self.totalCols):
   if self.VVRSoy[i - 1] > 1 or self.VVRSoy[i - 1] == self.VVTTSU:
    name, tot = self.VVOad6(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFMt3I(self, txt)
 def VVt0P4(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VV4AJr(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVn17k(self, newList, newTitle=""):
  if newList:
   self.VVbKpp = newList
   if self.VVuZx4 and self.VV1udG == 0:
    self.VVbKpp = sorted(self.VVbKpp, key=lambda x: int(x[self.VV1udG])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VVbKpp = sorted(self.VVbKpp, key=lambda x: x[self.VV1udG].lower(), reverse=self.lastSortModeIsReverese)
   self.VVzZ3H("Refreshing ...")
   if newTitle:
    self.VVdR5e(newTitle)
  else:
   FFGr6w(self, "Cannot refresh list")
   self.cancel()
 def VVZZ5t(self, data):
  ndx = self.VVlsdL()
  newRow = self.VViSqy(ndx, data, self.VVboNh, self.VVPOXl, self.VVXIBQ, self.VVfU42, None)
  if newRow:
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVDm0k()
   return True
  else:
   return False
 def VVuOU0(self, colNum, textToFind, VV17Wy=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVDm0k()
    break
  else:
   if VV17Wy:
    FFU79C(self, "Not found", 1000)
 def VVh4rG(self, colDict, VV17Wy=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVDm0k()
    return
  if VV17Wy:
   FFU79C(self, "Not found", 1000)
 def VVh4rG_partial(self, colDict, VV17Wy=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVDm0k()
    return
  if VV17Wy:
   FFU79C(self, "Not found", 1000)
 def VVq0ms(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVdyz2(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVvsq6:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVD696(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VV4Fde(self):
  if not self["keyMenu2F"].getVisible() or self.VVKqJC:
   return
  VVwdxM = []
  VVwdxM.append(("Table Statistcis"             , "tableStat"  ))
  VVwdxM.append(VVWygA)
  VVwdxM.append((FFY8RM("Export Table to .html"     , VVBEBZ) , "VVjClK" ))
  VVwdxM.append((FFY8RM("Export Table to .csv"     , VVBEBZ) , "VVnlgD" ))
  VVwdxM.append((FFY8RM("Export Table to .txt (Tab Separated)", VVBEBZ) , "VVewlB" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVRSoy[i] > 1 or self.VVRSoy[i] == self.VVuGUg:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVwdxM.append(VVWygA)
   if tot == 1 : VVwdxM.append(("Sort", sList[0][1]))
   else  : VVwdxM += sList
  FFsmMG(self, self.VVkYBk, VVwdxM=VVwdxM, title=self.VV1hep())
 def VVkYBk(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVzO1X()
   elif item == "VVjClK": FFa70X(self, self.VVjClK, title=title)
   elif item == "VVnlgD" : FFa70X(self, self.VVnlgD , title=title)
   elif item == "VVewlB" : FFa70X(self, self.VVewlB , title=title)
   else:
    isReversed = False
    if self.VV1udG == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVuZx4 and item == 0:
     self.VVbKpp = sorted(self.VVbKpp, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VVbKpp = sorted(self.VVbKpp, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VV1udG = item
    self.VVzZ3H("Sorting ...")
 def VVl69j(self):
  self["myTable"].up()
  self.VVDm0k()
 def VVgTA5(self):
  self["myTable"].down()
  self.VVDm0k()
 def VV3K59(self):
  self["myTable"].pageUp()
  self.VVDm0k()
 def VVUwVU(self):
  self["myTable"].pageDown()
  self.VVDm0k()
 def VVbgXW(self):
  self["myTable"].moveToIndex(0)
  self.VVDm0k()
 def VVTVNm(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVDm0k()
 def VVewlB(self):
  expFile = self.VVBRyY() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVzoxs()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VVbKpp:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVRSoy[ndx] > self.VVhShs:
      col = self.VVckCV(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVNYpH(expFile)
 def VVnlgD(self):
  expFile = self.VVBRyY() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVzoxs()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VVbKpp:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVRSoy[ndx] > self.VVhShs:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVckCV(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVNYpH(expFile)
 def VVjClK(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VV1hep(), PLUGIN_NAME, VVyy0v)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VV1hep()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVzoxs()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVRSoy:
   colgroup += '   <colgroup>'
   for w in self.VVRSoy:
    if w > self.VVhShs:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVBRyY() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VVbKpp:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVRSoy[ndx] > self.VVhShs:
      col = self.VVckCV(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVNYpH(expFile)
 def VVzoxs(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVRSoy[ndx] > self.VVhShs:
     newRow.append(col.strip())
  return newRow
 def VVckCV(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFaO74(col)
 def VVBRyY(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VV1hep())
  fileName = fileName.replace("__", "_")
  path  = FFgbrL(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FF9n2A()
  return expFile
 def VVNYpH(self, expFile):
  FF6zpT(self, "File exported to:\n\n%s" % expFile, title=self.VV1hep())
 def VVDm0k(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCvj1b(Screen):
 def __init__(self, session, Title="", VV2FNE=None):
  self.skin, self.skinParam = FFFsgK(VVmgsS, 1400, 800, 50, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FFKXoA(self, Title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VV2FNE = VV2FNE
  if len(Title) == 0 : Title = FFVjlE()
  else    : Title = "File : %s" % VV2FNE
  self["myTitle"] = Label("  %s" % Title)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  allOK = FF7cim(self["myLabel"], self.VV2FNE)
  if not allOK:
   FFGr6w(self, "Could not view this picture file")
   self.close()
class CC2L3a(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFFsgK(VVkgSN, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 28, barHeight=40, topRightBtns=1)
  self.session  = session
  FFKXoA(self)
  FFhu6U(self["keyGreen"], "Save")
  self.VVbKpp = []
  self.VVbKpp.append(getConfigListEntry("Show in Main Menu"         , CFG.showInMainMenu   ))
  self.VVbKpp.append(getConfigListEntry("Show in Extensions Menu"        , CFG.showInExtensionMenu  ))
  self.VVbKpp.append(getConfigListEntry("Show in Channel List Context Menu"     , CFG.showInChannelListMenu  ))
  self.VVbKpp.append(getConfigListEntry("Input Type"           , CFG.keyboard     ))
  self.VVbKpp.append(getConfigListEntry("Signal & Player Cotroller Hotkey"     , CFG.hotkey_signal    ))
  if VVAkV7:
   self.VVbKpp.append(getConfigListEntry("EPG Translation Language"      , CFG.epgLanguage    ))
  self.VVbKpp.append(getConfigListEntry(VVlWOd *2            ,         ))
  self.VVbKpp.append(getConfigListEntry("Default IPTV Reference Type"       , CFG.iptvAddToBouquetRefType ))
  self.VVbKpp.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"    , CFG.hideIptvServerAdultWords ))
  self.VVbKpp.append(getConfigListEntry('Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)' , CFG.hideIptvServerChannPrefix ))
  self.VVbKpp.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"  , CFG.iptvHostsPath    ))
  self.VVbKpp.append(getConfigListEntry(VVlWOd *2            ,         ))
  self.VVbKpp.append(getConfigListEntry("PIcons Path"           , CFG.PIconsPath    ))
  self.VVbKpp.append(getConfigListEntry(VVlWOd *2            ,         ))
  self.VVbKpp.append(getConfigListEntry("Backup/Restore Path"         , CFG.backupPath    ))
  self.VVbKpp.append(getConfigListEntry("Created Package Files (IPK/DEB)"      , CFG.packageOutputPath   ))
  self.VVbKpp.append(getConfigListEntry("Downloaded Packages (from feeds)"     , CFG.downloadedPackagesPath ))
  self.VVbKpp.append(getConfigListEntry("Exported Tables"          , CFG.exportedTablesPath  ))
  self.VVbKpp.append(getConfigListEntry("Exported PIcons"          , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, self.VVbKpp, session)
  self["setupActions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard", "OkCancelActions"],
  {
   "ok"  : self.VVPtX0   ,
   "OK"  : self.VVPtX0   ,
   "green"  : self.VVf3qj  ,
   "menu"  : self.VVxVEh ,
   "cancel" : self.VVoyfV
  }, -1)
  self.titleText = "  Settings"
  self["myTitle"].setText(self.titleText)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  FFfopI(self["config"])
  FFwO6z(self,  self["config"])
  FFFOZ8(self)
 def VVPtX0(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsPath   : self.VV83m2()
   elif item == CFG.PIconsPath    : self.VVMQc5(item)
   elif item == CFG.backupPath    : self.VVMQc5(item)
   elif item == CFG.packageOutputPath  : self.VVMQc5(item)
   elif item == CFG.downloadedPackagesPath : self.VVMQc5(item)
   elif item == CFG.exportedTablesPath  : self.VVMQc5(item)
   elif item == CFG.exportedPIconsPath  : self.VVMQc5(item)
 def VV83m2(self):
  VVwdxM = []
  VVwdxM.append(("Auto Find" , "auto"))
  VVwdxM.append(("Custom Path" , "path"))
  FFsmMG(self, self.VVY4Me, VVwdxM=VVwdxM, title="IPTV Hosts Files Path")
 def VVY4Me(self, item=None):
  if item:
   if   item == "auto": CFG.iptvHostsPath.setValue(VV8e5A)
   elif item == "path": self.VVMQc5(CFG.iptvHostsPath)
 def VVMQc5(self, configObj):
  sDir = configObj.getValue()
  if sDir == VV8e5A:
   sDir = "/"
  self.session.openWithCallback(boundFunction(self.VVI8oO, configObj)
         , boundFunction(CCvQ2O, mode=CCvQ2O.VVNlqz, VVlCyw=sDir))
 def VVI8oO(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVoyfV(self):
  if CFG.showInMainMenu.isChanged()    or \
   CFG.showInExtensionMenu.isChanged()   or \
   CFG.showInChannelListMenu.isChanged()  or \
   CFG.keyboard.isChanged()     or \
   CFG.hotkey_signal.isChanged()    or \
   CFG.epgLanguage.isChanged()     or \
   CFG.iptvAddToBouquetRefType.isChanged()  or \
   CFG.hideIptvServerAdultWords.isChanged() or \
   CFG.hideIptvServerChannPrefix.isChanged() or \
   CFG.iptvHostsPath.isChanged()    or \
   CFG.PIconsPath.isChanged()     or \
   CFG.backupPath.isChanged()     or \
   CFG.packageOutputPath.isChanged()   or \
   CFG.downloadedPackagesPath.isChanged()  or \
   CFG.exportedTablesPath.isChanged()   or \
   CFG.exportedPIconsPath.isChanged():
    FFIxs9(self, self.VVf3qj, "Save Changes ?", callBack_No=self.cancel)
  else:
   self.cancel()
 def VVf3qj(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VV8KwK()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVxVEh(self):
  VVwdxM = []
  VVwdxM.append(("Use Backup directory in all other paths"      , "VViMfO"   ))
  VVwdxM.append(("Reset all to default (including File Manager bookmarks)"  , "VVe5Dw"   ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Backup %s Settings" % PLUGIN_NAME        , "VV30al"  ))
  VVwdxM.append(("Restore %s Settings" % PLUGIN_NAME       , "VVUz84"  ))
  if fileExists(VVbxzm + VVzdHc):
   VVwdxM.append(VVWygA)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVwdxM.append(('%s Checking for Update' % txt1       , txt2     ))
   VVwdxM.append(("Reinstall %s" % PLUGIN_NAME        , "VVTZnb"  ))
   VVwdxM.append(("Update %s" % PLUGIN_NAME        , "VVT6Hp"   ))
  FFsmMG(self, self.VV2CoR, VVwdxM=VVwdxM, title="Config. Options")
 def VV2CoR(self, item=None):
  if item:
   if   item == "VViMfO"  : FFIxs9(self, self.VViMfO , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVe5Dw"  : FFIxs9(self, self.VVe5Dw, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCGmwk)
   elif item == "VV30al" : self.VV30al()
   elif item == "VVUz84" : FFa70X(self, self.VVUz84, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVvGAd(True)
   elif item == "disableChkUpdate" : self.VVvGAd(False)
   elif item == "VVTZnb" : FFa70X(self, self.VVTZnb , "Checking Server ...")
   elif item == "VVT6Hp"  : FFa70X(self, self.VVT6Hp  , "Checking Server ...")
 def VV30al(self):
  path = "%sajpanel_settings_%s" % (VVbxzm, FF9n2A())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FF6zpT(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVUz84(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FF0s0U("find / %s -iname '%s*' | grep %s" % (FFl0r9(1), name, name))
  if lines:
   lines.sort()
   VVwdxM = []
   for line in lines:
    VVwdxM.append((line, line))
   FFsmMG(self, boundFunction(self.VVjIJe, title), title=title, VVwdxM=VVwdxM, width=1200)
  else:
   FFGr6w(self, "No settings files found !", title=title)
 def VVjIJe(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFn8wV(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VV8KwK()
    FFwg59()
   else:
    FFI53L(SELF, path, title=title)
 def VVvGAd(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VViMfO(self):
  newPath = FFgbrL(VVbxzm)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VV8KwK()
 @staticmethod
 def VVklML():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVe5Dw(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.epgLanguage.setValue("off")
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.iptvHostsPath.setValue(VV8e5A)
  CFG.PIconsPath.setValue(VVlO79)
  CFG.backupPath.setValue(CC2L3a.VVklML())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  CFG.showInMainMenu.save()
  CFG.showInExtensionMenu.save()
  CFG.showInChannelListMenu.save()
  CFG.keyboard.save()
  CFG.hotkey_signal.save()
  CFG.epgLanguage.save()
  CFG.iptvAddToBouquetRefType.save()
  CFG.hideIptvServerAdultWords.save()
  CFG.hideIptvServerChannPrefix.save()
  CFG.iptvHostsPath.save()
  CFG.PIconsPath.save()
  CFG.backupPath.save()
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  CFG.browserStartPath.save()
  CFG.browserBookmarks.save()
  self.VV8KwK()
  self.close()
 def VV8KwK(self):
  configfile.save()
  global VVbxzm
  VVbxzm = CFG.backupPath.getValue()
  FFrCRC()
 def VVT6Hp(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVtUs2(title)
  if webVer:
   FFIxs9(self, boundFunction(FFa70X, self, boundFunction(self.VViVLS, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVTZnb(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVtUs2(title, True)
  if webVer:
   FFIxs9(self, boundFunction(FFa70X, self, boundFunction(self.VViVLS, webVer, title)), "Install and Restart ?", title=title)
 def VViVLS(self, webVer, title):
  url = self.VVkXol(self, title)
  if url:
   VVIteZ = FFKtW2() == "dpkg"
   if VVIteZ == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVIteZ else "ipk")
   path, err = FFEUjD(url + fName, fName, timeout=2)
   if path:
    cmd = FFS262(VVOhTz, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFgQDF(self, cmd)
    else:
     FFQ7SS(self, title=title)
   else:
    FFGr6w(self, err, title=title)
 def VVtUs2(self, title, anyVer=False):
  url = self.VVkXol(self, title)
  if not url:
   return ""
  path, err = FFEUjD(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFGr6w(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFaq7Y(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFGr6w(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVyy0v.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FF0s0U(cmd)
   if list and curVer == list[0]:
    return webVer
  FF6zpT(self, FFY8RM("No update required.", VVI0dy) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVkXol(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVbxzm + VVzdHc
  if fileExists(path):
   span = iSearch(r"(http.+)", FFaq7Y(path), IGNORECASE)
   if span : url = FFgbrL(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFGr6w(SELF, err, title)
  return url
 @staticmethod
 def VVtevy(url):
  path, err = FFEUjD(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFaq7Y(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVyy0v.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FF0s0U(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCGmwk(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFFsgK(VVxDcM, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVynug
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFKXoA(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVCduJ("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVCduJ("\c00888888", i) + sp + "GREY\n"
   txt += self.VVCduJ("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVCduJ("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVCduJ("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVCduJ("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVCduJ("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVCduJ("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVCduJ("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVCduJ("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVCduJ("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVCduJ("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVPtX0 ,
   "green"   : self.VVPtX0 ,
   "left"   : self.VVPGw2 ,
   "right"   : self.VVxtQm ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  self.VV0Isl()
 def VVPtX0(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFIxs9(self, self.VVyh2v, "Change to : %s" % txt, title=self.Title)
 def VVyh2v(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVynug
  VVynug = self.cursorPos
  self.VVDm9Y()
  self.close()
 def VVPGw2(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VV0Isl()
 def VVxtQm(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VV0Isl()
 def VV0Isl(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVCduJ(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVTCSR(color):
  if VVX3gJ: return "\\" + color
  else    : return ""
 @staticmethod
 def VVDm9Y():
  global VVKVzn, VVea45, VVNRjX, VVBEBZ, VVK98e, VVVOLr, VVI0dy, VVX3gJ, COLOR_CONS_BRIGHT_YELLOW, VVVJBw, VVVqHz, VVaDNx
  VVaDNx   = CCGmwk.VVCduJ("\c00FFFFFF", VVynug)
  VVea45    = CCGmwk.VVCduJ("\c00888888", VVynug)
  VVKVzn  = CCGmwk.VVCduJ("\c005A5A5A", VVynug)
  VVVOLr    = CCGmwk.VVCduJ("\c00FF0000", VVynug)
  VVNRjX   = CCGmwk.VVCduJ("\c00FF5000", VVynug)
  VVX3gJ   = CCGmwk.VVCduJ("\c00FFFF00", VVynug)
  COLOR_CONS_BRIGHT_YELLOW = CCGmwk.VVCduJ("\c00FFFFAA", VVynug)
  VVI0dy   = CCGmwk.VVCduJ("\c0000FF00", VVynug)
  VVK98e    = CCGmwk.VVCduJ("\c000066FF", VVynug)
  VVVJBw    = CCGmwk.VVCduJ("\c0000FFFF", VVynug)
  VVVqHz   = CCGmwk.VVCduJ("\c00FA55E7", VVynug)
  VVBEBZ    = CCGmwk.VVCduJ("\c00FF8F5F", VVynug)
CCGmwk.VVDm9Y()
class CC4z8v(Screen):
 def __init__(self, session, path, VVIteZ):
  self.skin, self.skinParam = FFFsgK(VVFncf, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVpydF   = path
  self.VVwLQk   = ""
  self.VVoXdm   = ""
  self.VVIteZ    = VVIteZ
  self.VVxpGT    = ""
  self.VVueG7  = ""
  self.VVK2ji    = False
  self.VVhBS6  = False
  self.postInstAcion   = 0
  self.VVwwO5  = "enigma2-plugin-extensions"
  self.VVTFVj  = "enigma2-plugin-systemplugins"
  self.VVGCdg = "enigma2"
  self.VVYgnG  = 0
  self.VV2Kci  = 1
  self.VVOMET  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVbeZK = "DEBIAN"
  else        : self.VVbeZK = "CONTROL"
  self.controlPath = self.Path + self.VVbeZK
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVIteZ:
   self.packageExt  = ".deb"
   self.VVPOXl  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVPOXl  = "#11001020"
  FFKXoA(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFhu6U(self["keyRed"] , "Create")
  FFhu6U(self["keyGreen"] , "Post Install")
  FFhu6U(self["keyYellow"], "Installation Path")
  FFhu6U(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVljOx  ,
   "green"   : self.VVwxsI ,
   "yellow"  : self.VVIf62  ,
   "blue"   : self.VVv9yb  ,
   "cancel"  : self.VVvoh9
  }, -1)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  FFFOZ8(self)
  if self.VVPOXl:
   FFpRmN(self["myBody"], self.VVPOXl)
   FFpRmN(self["myLabel"], self.VVPOXl)
  self.VVTGBO(True)
  self.VVKyj1(True)
 def VVKyj1(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVJqT0()
  if isFirstTime:
   if   package.startswith(self.VVwwO5) : self.VVpydF = VVloRZ + self.VVxpGT + "/"
   elif package.startswith(self.VVTFVj) : self.VVpydF = VVgT5I + self.VVxpGT + "/"
   else            : self.VVpydF = self.Path
  if self.VVK2ji : myColor = VVBEBZ
  else    : myColor = VVaDNx
  txt  = ""
  txt += "Source Path\t: %s\n" % FFY8RM(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFY8RM(self.VVpydF, VVX3gJ)
  if self.VVoXdm : txt += "Package File\t: %s\n" % FFY8RM(self.VVoXdm, VVea45)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFY8RM("Check Control File fields : %s" % errTxt, VVNRjX)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFY8RM("Restart GUI", VVBEBZ)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFY8RM("Reboot Device", VVBEBZ)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FFY8RM("Post Install", VVI0dy), act)
  if not errTxt and VVNRjX in controlInfo:
   txt += "Warning\t: %s\n" % FFY8RM("Errors in control file may affect the result package.", VVNRjX)
  txt += "\nControl File\t: %s\n" % FFY8RM(self.controlFile, VVea45)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVwxsI(self):
  VVwdxM = []
  VVwdxM.append(("No Action"    , "noAction"  ))
  VVwdxM.append(("Restart GUI"    , "VVW7dW"  ))
  VVwdxM.append(("Reboot Device"   , "rebootDev"  ))
  FFsmMG(self, self.VVIoIy, title="Package Installation Option (after completing installation)", VVwdxM=VVwdxM)
 def VVIoIy(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVW7dW"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVTGBO(False)
   self.VVKyj1()
 def VVIf62(self):
  rootPath = FFY8RM("/%s/" % self.VVxpGT, VVKVzn)
  VVwdxM = []
  VVwdxM.append(("Current Path"        , "toCurrent"  ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Extension Path"       , "toExtensions" ))
  VVwdxM.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVwdxM.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFsmMG(self, self.VVPpiB, title="Installation Path", VVwdxM=VVwdxM)
 def VVPpiB(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVHfQB(FFAYBC(self.Path, True))
   elif item == "toExtensions"  : self.VVHfQB(VVloRZ)
   elif item == "toSystemPlugins" : self.VVHfQB(VVgT5I)
   elif item == "toRootPath"  : self.VVHfQB("/")
   elif item == "toRoot"   : self.VVHfQB("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVcp0D, boundFunction(CCvQ2O, mode=CCvQ2O.VVNlqz, VVlCyw=VVbxzm))
 def VVcp0D(self, path):
  if len(path) > 0:
   self.VVHfQB(path)
 def VVHfQB(self, parent, withPackageName=True):
  if withPackageName : self.VVpydF = parent + self.VVxpGT + "/"
  else    : self.VVpydF = "/"
  mode = self.VVg8KA()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVLfZu(mode), self.controlFile))
  self.VVKyj1()
 def VVv9yb(self):
  if fileExists(self.controlFile):
   lines = FFn8wV(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFK1qA(self, self.VVSxsl, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFGr6w(self, "Version not found or incorrectly set !")
  else:
   FFI53L(self, self.controlFile)
 def VVSxsl(self, VVb9jI):
  if VVb9jI:
   version, color = self.VVInwt(VVb9jI, False)
   if color == VVVJBw:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVb9jI, self.controlFile))
    self.VVKyj1()
   else:
    FFGr6w(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVvoh9(self):
  if self.newControlPath:
   if self.VVK2ji:
    self.VVpPKt()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFY8RM(self.newControlPath, VVea45)
    txt += FFY8RM("Do you want to keep these files ?", VVX3gJ)
    FFIxs9(self, self.close, txt, callBack_No=self.VVpPKt, title="Create Package", VVuXa8=True)
  else:
   self.close()
 def VVpPKt(self):
  os.system(FFoKN8("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVLfZu(self, mode):
  if   mode == self.VV2Kci : prefix = self.VVwwO5
  elif mode == self.VVOMET : prefix = self.VVTFVj
  else        : prefix = self.VVGCdg
  return prefix + "-" + self.VVueG7
 def VVg8KA(self):
  if   self.VVpydF.startswith(VVloRZ) : return self.VV2Kci
  elif self.VVpydF.startswith(VVgT5I) : return self.VVOMET
  else            : return self.VVYgnG
 def VVTGBO(self, isFirstTime):
  self.VVxpGT   = os.path.basename(os.path.normpath(self.Path))
  self.VVxpGT   = "_".join(self.VVxpGT.split())
  self.VVueG7 = self.VVxpGT.lower()
  self.VVK2ji = self.VVueG7 == VVpGPW.lower()
  if self.VVK2ji and self.VVueG7.endswith("ajpan"):
   self.VVueG7 += "el"
  if self.VVK2ji : self.VVwLQk = VVbxzm
  else    : self.VVwLQk = CFG.packageOutputPath.getValue()
  self.VVwLQk = FFgbrL(self.VVwLQk)
  if not pathExists(self.controlPath):
   os.system(FFoKN8("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVK2ji : t = PLUGIN_NAME
  else    : t = self.VVxpGT
  self.VVtkis(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVUFKh.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVK2ji : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVtkis(self.postrmFile, txt)
  if self.VVK2ji:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVyy0v)
   self.VVtkis(self.preinstFile, txt)
  else:
   self.VVtkis(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVxpGT)
  mode = self.VVg8KA()
  if isFirstTime and not mode == self.VVYgnG:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVlWOd
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVtkis(self.postinstFile, txt, VVhQTT=True)
  os.system(FFoKN8("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVK2ji : version, descripton, maintainer = VVyy0v , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVxpGT , self.VVxpGT
   txt = ""
   txt += "Package: %s\n"  % self.VVLfZu(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVtkis(self, path, lines, VVhQTT=False):
  if not fileExists(path) or VVhQTT:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVJqT0(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFn8wV(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFY8RM(line, VVNRjX)
     elif not line.startswith(" ")    : line = FFY8RM(line, VVNRjX)
     else          : line = FFY8RM(line, VVVJBw)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVVJBw
   else   : color = VVNRjX
   descr = FFY8RM(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVNRjX
     elif line.startswith((" ", "\t")) : color = VVNRjX
     elif line.startswith("#")   : color = VVea45
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVInwt(val, True)
      elif key == "Version"  : version, color = self.VVInwt(val, False)
      elif key == "Maintainer" : maint  , color = val, VVVJBw
      elif key == "Architecture" : arch  , color = val, VVVJBw
      else:
       color = VVVJBw
      if not key == "OE" and not key.istitle():
       color = VVNRjX
     else:
      color = VVBEBZ
     txt += FFY8RM(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVoXdm = self.VVwLQk + packageName
   self.VVhBS6 = True
   errTxt = ""
  else:
   self.VVoXdm  = ""
   self.VVhBS6 = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVInwt(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVVJBw
  else          : return val, VVNRjX
 def VVljOx(self):
  if not self.VVhBS6:
   FFGr6w(self, "Please fix Control File errors first.")
   return
  if self.VVIteZ: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFAYBC(self.VVpydF, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVxpGT
  symlinkTo  = FFO8pH(self.Path)
  dataDir   = self.VVpydF.rstrip("/")
  removePorjDir = FFoKN8("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFoKN8("rm -f '%s'" % self.VVoXdm) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFO6jP()
  if self.VVIteZ:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFwBeJ("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVK2ji:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVpydF == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVbeZK)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVoXdm, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVoXdm
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVoXdm, FFdpXa(result  , VVI0dy))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVpydF, FFdpXa(instPath, VVVJBw))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFdpXa(failed, VVNRjX))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFgQDF(self, cmd)
class CCvQ2O(Screen):
 VVGcS9   = 0
 VVNlqz  = 1
 VVFlQR = 20
 def __init__(self, session, VVlCyw="/", mode=VVGcS9, VVHBYv="Select", VVA2Pa=30):
  self.skin, self.skinParam = FFFsgK(VVQV0S, 1400, 820, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFKXoA(self)
  FFhu6U(self["keyRed"] , "Exit")
  FFhu6U(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVHBYv = VVHBYv
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  if   self.mode == self.VVGcS9  : VVLzLj, self.VVlCyw = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVNlqz : VVLzLj, self.VVlCyw = False, VVlCyw
  else           : VVLzLj, self.VVlCyw = True , VVlCyw
  self.VVlCyw = FFgbrL(self.VVlCyw)
  self["myMenu"] = CCf2Ls(  directory   = "/"
         , VVLzLj   = VVLzLj
         , VVQP6i = True
         , VV2IsJ   = self.skinParam["width"]
         , VVA2Pa   = self.skinParam["bodyFontSize"]
         , VVCg7w  = self.skinParam["bodyLineH"]
         , VVIePE  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVPtX0      ,
   "red"    : self.cancel      ,
   "green"    : self.VVsESW    ,
   "yellow"   : self.VVdyzl   ,
   "blue"    : self.VVc3Xv   ,
   "menu"    : self.VVykl2    ,
   "info"    : self.VVCMO5    ,
   "cancel"   : self.VV18s6     ,
   "pageUp"   : self.VV18s6     ,
   "chanUp"   : self.VV18s6
  }, -1)
  FFUYXl(self, self["myMenu"])
  self.onShown.append(self.start)
  self["myMenu"].onSelectionChanged.append(self.VVss0I)
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVss0I)
  FFfopI(self["myMenu"], bg="#06003333")
  FFFOZ8(self)
  self.maxTitleWidth = self["keyMenu1"].getPosition()[0] - 40
  if self.mode == self.VVNlqz:
   FFhu6U(self["keyGreen"], self.VVHBYv)
   color = "#22000022"
   FFpRmN(self["myBody"], color)
   FFpRmN(self["myMenu"], color)
   color = "#22220000"
   FFpRmN(self["myTitle"], color)
   FFpRmN(self["myBar"], color)
  self.VVss0I()
  if self.VVa30G(self.VVlCyw) > self.bigDirSize:
   FFU79C(self, "Changing directory...")
   FFZQW5(self.VVcwQB)
  else:
   self.VVcwQB()
 def VVcwQB(self):
  self["myMenu"].VVVXEV(self.VVlCyw)
 def VVH7HW(self):
  self["myMenu"].refresh()
  FFLC0G()
 def VVa30G(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VVPtX0(self):
  if self["myMenu"].VV8V4U():
   path = self.VVunTR(self.VVyzEq())
   if self.VVa30G(path) > self.bigDirSize:
    FFU79C(self, "Changing directory...")
    FFZQW5(self.VVOnGx)
   else:
    self.VVOnGx()
  else:
   self.VVxO6I()
 def VVOnGx(self):
  self["myMenu"].descent()
  self["myMenu"].moveToIndex(0)
  self.VVss0I()
 def VV18s6(self):
  if self["myMenu"].VVLQPS():
   self["myMenu"].moveToIndex(0)
   self.VVOnGx()
 def cancel(self):
  if not FFpJmc(self):
   self.close("")
 def VVsESW(self):
  if self.mode == self.VVNlqz:
   path = self.VVunTR(self.VVyzEq())
   self.close(path)
 def VVCMO5(self):
  FFa70X(self, self.VV3Joq, title="Calculating size ...")
 def VV3Joq(self):
  path = self.VVunTR(self.VVyzEq())
  param = self.VVyb9j(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = ""
   if typeChar == "d":
    result = FF5sfh("myDir='%s'; totDirs=$(find $myDir -type d | wc -l); totFiles=$(find $myDir ! -type d | wc -l); echo $totDirs','$totFiles" % path)
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents  = "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
    size = FF5sfh("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    size = int(size)
   if size >= 1024 : size = "%s  ( %s bytes )" % (self.VVt66A(size), format(size, ',d'))
   else   : size = "%s" % self.VVt66A(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFY8RM(pathTxt, VVBEBZ) + "\n"
   if slBroken : fileTime = self.VVrLLk(path)
   else  : fileTime = self.VV8Sti(path)
   def VVPjwD(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVPjwD("Path"    , pathTxt)
   txt += VVPjwD("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVPjwD("Target"   , slTarget)
   txt += VVPjwD("Size"    , "%s" % size)
   txt += contents
   txt += "\n"
   txt += VVPjwD("Owner"    , owner)
   txt += VVPjwD("Group"    , group)
   txt += VVPjwD("Perm. (User)"  , permUser)
   txt += VVPjwD("Perm. (Group)"  , permGroup)
   txt += VVPjwD("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVPjwD("Perm. (Ext.)" , permExtra)
   txt += VVPjwD("iNode"    , iNode)
   txt += VVPjwD("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVlWOd, VVlWOd)
    txt += hLinkedFiles
   txt += self.VVhZft(path)
  else:
   FFGr6w(self, "Cannot access information !")
  if len(txt) > 0:
   FFMt3I(self, txt)
 def VVyb9j(self, path):
  path = path.strip()
  path = FFO8pH(path)
  result = FF5sfh("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVtYl5(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVtYl5(perm, 1, 4)
   permGroup = VVtYl5(perm, 4, 7)
   permOther = VVtYl5(perm, 7, 10)
   permExtra = VVtYl5(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFs0FM("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVhZft(self, path):
  txt  = ""
  res  = FF5sfh("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFY8RM("File Attributes:", VVVqHz), txt)
  return txt
 def VV8Sti(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FF5Ufp(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FF5Ufp(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FF5Ufp(os.path.getctime(path))
  return txt
 def VVrLLk(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FF5sfh("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FF5sfh("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FF5sfh("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVt66A(self, size):
  power = 1024.0
  n = 0
  power_labels = {0 : 'B', 1: 'kB', 2: 'MB', 3: 'GB', 4: 'TB'}
  while size > power:
   size /= power
   n += 1
  size = "%.1f" % size
  if size.endswith(".0"):
   size = size[:-2]
  return "%s %s" % (size, power_labels[n])
 def VVunTR(self, currentSel):
  currentDir  = self["myMenu"].VVLQPS()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VV8V4U():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVyzEq(self):
  return self["myMenu"].getSelection()[0]
 def VVss0I(self):
  FFU79C(self)
  path = self.VVunTR(self.VVyzEq())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VVbKpp = self.VVD3ti()
  if VVbKpp and len(VVbKpp) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VVFCFH(path)
  if self.mode == self.VVGcS9 and len(path) > 0:
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
  else:
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
 def VVFCFH(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VV7LOK(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVykl2(self):
  if self.mode == self.VVGcS9:
   path  = self.VVunTR(self.VVyzEq())
   isDir  = os.path.isdir(path)
   VVwdxM = []
   VVwdxM.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVUJEl(path):
     sepShown = True
     VVwdxM.append(VVWygA)
     VVwdxM.append( (VVBEBZ + "Archiving / Packaging"      , "VVI35V"  ))
    if self.VVTfOA(path):
     if not sepShown:
      VVwdxM.append(VVWygA)
     VVwdxM.append( (VVBEBZ + "Read Backup information"     , "VVdIMN"  ))
     VVwdxM.append( (VVBEBZ + "Compress Octagon Image (to zip File)"  , "VVlADx" ))
   elif os.path.isfile(path):
    selFile = self.VVyzEq()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar")) : VVwdxM.extend(self.VVpNTR(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVwdxM.extend(self.VVOVzi(True))
    elif selFile.endswith(".m3u")              : VVwdxM.extend(self.VVu61u(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FF7j7O(path):
     VVwdxM.append(VVWygA)
     VVwdxM.append((VVBEBZ + "View" , "text_View" ))
     VVwdxM.append((VVBEBZ + "Edit" , "text_Edit" ))
    if len(txt) > 0:
     VVwdxM.append(VVWygA)
     VVwdxM.append(   (VVBEBZ + txt      , "VVxO6I"  ))
   VVwdxM.append(VVWygA)
   VVwdxM.append(     ("Create SymLink"       , "VVkeLg" ))
   if not self.VVUJEl(path):
    VVwdxM.append(   ("Rename"          , "VVP19t" ))
    VVwdxM.append(   ("Copy"           , "copyFileOrDir" ))
    VVwdxM.append(   ("Move"           , "moveFileOrDir" ))
    VVwdxM.append(   ("DELETE"          , "VVVcn0" ))
    if fileExists(path):
     VVwdxM.append(VVWygA)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVwdxM.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVwdxM.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVwdxM.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVwdxM.append(VVWygA)
   VVwdxM.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVwdxM.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   VVwdxM.append(VVWygA)
   VVwdxM.append(    ("Set current directory as \"Startup Path\"" , "VVBsOb" ))
   FFsmMG(self, self.VVLiqX, title="Options", VVwdxM=VVwdxM)
 def VVLiqX(self, item=None):
  if self.mode == self.VVGcS9:
   if item is not None:
    path = self.VVunTR(self.VVyzEq())
    selFile = self.VVyzEq()
    if   item == "properties"    : self.VVCMO5()
    elif item == "VVI35V"  : self.VVI35V(path)
    elif item == "VVdIMN"  : self.VVdIMN(path)
    elif item == "VVlADx" : self.VVlADx(path)
    elif item.startswith("extract_")  : self.VVxBTs(path, selFile, item)
    elif item.startswith("script_")   : self.VVdIVD(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVp9AlItem_m3u(path, selFile, item)
    elif item.startswith("text_View")  : FFrFsL(self, path)
    elif item.startswith("text_Edit")  : CCk6mL(self, path)
    elif item == "chmod644"     : self.VV62A3(path, selFile, "644")
    elif item == "chmod755"     : self.VV62A3(path, selFile, "755")
    elif item == "chmod777"     : self.VV62A3(path, selFile, "777")
    elif item == "VVkeLg"   : self.VVkeLg(path, selFile)
    elif item == "VVP19t"   : self.VVP19t(path, selFile)
    elif item == "copyFileOrDir"   : self.VVSR6F(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVSR6F(path, selFile, True)
    elif item == "VVVcn0"   : self.VVVcn0(path, selFile)
    elif item == "createNewFile"   : self.VVCXCw(path, True)
    elif item == "createNewDir"    : self.VVCXCw(path, False)
    elif item == "VVBsOb"   : self.VVBsOb(path)
    elif item == "VVxO6I"    : self.VVxO6I()
    else         : self.close()
 def VVxO6I(self):
  selFile = self.VVyzEq()
  path  = self.VVunTR(selFile)
  if os.path.isfile(path):
   VVLuAj = []
   category = self["myMenu"].VVOclv(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVMult(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FFqxjD(self, selFile, path)
   elif category == "txt"         : FFrFsL(self, path)
   elif category in ("tar", "zip", "rar")     : self.VVOBAM(path, selFile)
   elif category == "scr"         : self.VVXBnh(path, selFile)
   elif category == "m3u"         : self.VV2gnl(path, selFile)
   elif category in ("ipk", "deb")       : self.VVcgnh(path, selFile)
   elif category == "mus"         : self.VVPmFy(path)
   elif category == "mov"         : self.VVPmFy(path)
   elif not FF7j7O(path)        : FFrFsL(self, path)
 def VVPmFy(self, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   FFsOcb(self, refCode)
  except:
   pass
 def VVdyzl(self):
  path = self.VVunTR(self.VVyzEq())
  action = self.VVFCFH(path)
  if action == 1:
   self.VVqIWE(path)
   FFU79C(self, "Added", 500)
  elif action == -1:
   self.VVkA8R(path)
   FFU79C(self, "Removed", 500)
  self.VVFCFH(path)
 def VVqIWE(self, path):
  VVbKpp = self.VVD3ti()
  if not VVbKpp:
   VVbKpp = []
  if len(VVbKpp) >= self.VVFlQR:
   FFGr6w(SELF, "Max bookmarks reached (max=%d)." % self.VVFlQR)
  elif not path in VVbKpp:
   VVbKpp = [path] + VVbKpp
   self.VVSx71(VVbKpp)
 def VVc3Xv(self):
  VVbKpp = self.VVD3ti()
  if VVbKpp:
   newList = []
   for line in VVbKpp:
    newList.append((line, line))
   VVC269  = ("Delete"  , self.VVDsrl )
   VV0ixh = ("Move Up"   , self.VVcp6Y )
   VVu6qN  = ("Move Down" , self.VV5Bu6 )
   self.bookmarkMenu = FFsmMG(self, self.VV8Ika, title="Bookmarks", VVwdxM=newList, VVC269=VVC269, VV0ixh=VV0ixh, VVu6qN=VVu6qN)
 def VVDsrl(self, VVyzEqObj, path):
  if self.bookmarkMenu:
   VVbKpp = self.VVkA8R(path)
   self.bookmarkMenu.VVjXxM(VVbKpp)
 def VVcp6Y(self, VVyzEqObj, path):
  if self.bookmarkMenu:
   VVbKpp = self.bookmarkMenu.VVADMA(True)
   if VVbKpp:
    self.VVSx71(VVbKpp)
 def VV5Bu6(self, VVyzEqObj, path):
  if self.bookmarkMenu:
   VVbKpp = self.bookmarkMenu.VVADMA(False)
   if VVbKpp:
    self.VVSx71(VVbKpp)
 def VV8Ika(self, folder=None):
  if folder:
   if not folder.endswith("/"):
    folder += "/"
   self["myMenu"].VVVXEV(folder)
   self["myMenu"].moveToIndex(0)
  self.VVss0I()
 def VVD3ti(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VV7LOK(self, path):
  VVbKpp = self.VVD3ti()
  if VVbKpp and path in VVbKpp:
   return True
  else:
   return False
 def VVHB1S(self):
  if VVD3ti():
   return True
  else:
   return False
 def VVSx71(self, VVbKpp):
  line = ",".join(VVbKpp)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVkA8R(self, path):
  VVbKpp = self.VVD3ti()
  if VVbKpp:
   while path in VVbKpp:
    VVbKpp.remove(path)
   self.VVSx71(VVbKpp)
   return VVbKpp
 def VVBsOb(self, path):
  if not os.path.isdir(path):
   path = FFAYBC(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVMult(self, selFile, VVadeJ, command):
  FFIxs9(self, boundFunction(FFgQDF, self, command, VVlT5W=self.VVH7HW), "%s\n\n%s" % (VVadeJ, selFile))
 def VVpNTR(self, path, calledFromMenu):
  destPath = self.VVIDXX(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVwdxM = []
  if calledFromMenu:
   VVwdxM.append(VVWygA)
   color = VVBEBZ
  else:
   color = ""
  VVwdxM.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVwdxM.append(VVWygA)
  VVwdxM.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVwdxM.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVwdxM.append((color + "Extract Here"            , "extract_here"  ))
  if VVhg3T and path.endswith(".tar.gz"):
   VVwdxM.append(VVWygA)
   VVwdxM.append((color + 'Convert to ".ipk" Package' , "VVrQ9x"  ))
   VVwdxM.append((color + 'Convert to ".deb" Package' , "VVMSIH"  ))
  return VVwdxM
 def VVOBAM(self, path, selFile):
  FFsmMG(self, boundFunction(self.VVxBTs, path, selFile), title="Compressed File Options", VVwdxM=self.VVpNTR(path, False))
 def VVxBTs(self, path, selFile, item=None):
  if item is not None:
   parent  = FFAYBC(path, False)
   destPath = self.VVIDXX(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVlWOd
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFwBeJ("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFwBeJ("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVlWOd, VVlWOd)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFj8K7(self, cmd)
   elif path.endswith(".zip"):
    self.VVIQCv(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif path.endswith(".rar"):
    self.VV0Ni3(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFoKN8("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVMult(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVMult(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFAYBC(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVMult(selFile, "Extract Here ?"      , cmd)
   elif item == "VVrQ9x" : self.VVrQ9x(path)
   elif item == "VVMSIH" : self.VVMSIH(path)
 def VVIDXX(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVIQCv(self, item, path, parent, destPath, VVadeJ):
  FFIxs9(self, boundFunction(self.VVqg2X, item, path, parent, destPath), VVadeJ)
 def VVqg2X(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVlWOd
  cmd  = FFwBeJ("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFdpXa(destPath, VVI0dy))
  cmd +=   sep
  cmd += "fi;"
  FF06MI(self, cmd, VVlT5W=self.VVH7HW)
 def VV0Ni3(self, item, path, parent, destPath, VVadeJ):
  FFIxs9(self, boundFunction(self.VV13wQ, item, path, parent, destPath), VVadeJ)
 def VV13wQ(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFgbrL(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVlWOd
  cmd  = FFwBeJ("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFdpXa(destPath, VVI0dy))
  cmd +=   sep
  cmd += "fi;"
  FF06MI(self, cmd, VVlT5W=self.VVH7HW)
 def VVOVzi(self, addSep=False):
  VVwdxM = []
  if addSep:
   VVwdxM.append(VVWygA)
  VVwdxM.append((VVBEBZ + "View Script File"  , "script_View"  ))
  VVwdxM.append((VVBEBZ + "Execute Script File" , "script_Execute" ))
  VVwdxM.append((VVBEBZ + "Edit"     , "script_Edit" ))
  return VVwdxM
 def VVXBnh(self, path, selFile):
  FFsmMG(self, boundFunction(self.VVdIVD, path, selFile), title="Script File Options", VVwdxM=self.VVOVzi())
 def VVdIVD(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFrFsL(self, path)
   elif item == "script_Execute" : self.VVMult(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCk6mL(self, path)
 def VVu61u(self, addSep=False):
  VVwdxM = []
  if addSep:
   VVwdxM.append(VVWygA)
  VVwdxM.append((VVBEBZ + "View"      , "m3u_View" ))
  VVwdxM.append((VVBEBZ + "Edit"      , "m3u_Edit" ))
  VVwdxM.append((VVBEBZ + "Convert to IPTV Bouquet" , "m3u_Convert" ))
  return VVwdxM
 def VV2gnl(self, path, selFile):
  FFsmMG(self, boundFunction(self.VVp9AlItem_m3u, path, selFile), title="M3U File Options", VVwdxM=self.VVu61u())
 def VVp9AlItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_View"  : FFrFsL(self, path)
   elif item == "m3u_Edit"  : CCk6mL(self, path)
   elif item == "m3u_Convert" : CCjXCp.VVBGRO(self, path, False)
 def VV62A3(self, path, selFile, newChmod):
  FFIxs9(self, boundFunction(self.VVnITU, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVnITU(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VV7NYO)
  result = FF5sfh(cmd)
  if result == "Successful" : FF6zpT(self, result)
  else      : FFGr6w(self, result)
 def VVkeLg(self, path, selFile):
  parent = FFAYBC(path, False)
  self.session.openWithCallback(self.VVMj5S, boundFunction(CCvQ2O, mode=CCvQ2O.VVNlqz, VVlCyw=parent, VVHBYv="Create Symlink here"))
 def VVMj5S(self, newPath):
  if len(newPath) > 0:
   target = self.VVunTR(self.VVyzEq())
   target = FFO8pH(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFgbrL(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFGr6w(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFIxs9(self, boundFunction(self.VVpnjM, target, link), "Create Soft Link ?\n\n%s" % txt, VVuXa8=True)
 def VVpnjM(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VV7NYO)
  result = FF5sfh(cmd)
  if result == "Successful" : FF6zpT(self, result)
  else      : FFGr6w(self, result)
 def VVP19t(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFK1qA(self, boundFunction(self.VVKJ3F, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVKJ3F(self, path, selFile, VVb9jI):
  if VVb9jI:
   parent = FFAYBC(path, True)
   if os.path.isdir(path):
    path = FFO8pH(path)
   newName = parent + VVb9jI
   cmd = "mv '%s' '%s' %s" % (path, newName, VV7NYO)
   if VVb9jI:
    if selFile != VVb9jI:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFIxs9(self, boundFunction(self.VVmVNp, cmd), message, title="Rename file?")
    else:
     FFGr6w(self, "Cannot use same name!", title="Rename")
 def VVmVNp(self, cmd):
  result = FF5sfh(cmd)
  if "Fail" in result:
   FFGr6w(self, result)
  self.VVH7HW()
 def VVSR6F(self, path, selFile, isMove):
  if isMove : VVHBYv = "Move to here"
  else  : VVHBYv = "Copy to here"
  parent = FFAYBC(path, False)
  self.session.openWithCallback(boundFunction(self.VV5ewF, isMove, path, selFile)
         , boundFunction(CCvQ2O, mode=CCvQ2O.VVNlqz, VVlCyw=parent, VVHBYv=VVHBYv))
 def VV5ewF(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFO8pH(path)
   newPath = FFgbrL(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFIxs9(self, boundFunction(FFTM8D, self, cmd, VVlT5W=self.VVH7HW), txt, VVuXa8=True)
   else:
    FFGr6w(self, "Cannot %s to same directory !" % action.lower())
 def VVVcn0(self, path, fileName):
  path = FFO8pH(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFIxs9(self, boundFunction(self.VVmIqG, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVmIqG(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VVH7HW()
 def VVUJEl(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVvPtm and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVCXCw(self, path, isFile):
  dirName = FFgbrL(os.path.dirname(path))
  if isFile : objName, VVb9jI = "File"  , self.edited_newFile
  else  : objName, VVb9jI = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFK1qA(self, boundFunction(self.VVvAv2, dirName, isFile, title), title=title, defaultText=VVb9jI, message="Enter %s Name:" % objName)
 def VVvAv2(self, dirName, isFile, title, VVb9jI):
  if VVb9jI:
   if isFile : self.edited_newFile = VVb9jI
   else  : self.edited_newDir  = VVb9jI
   path = dirName + VVb9jI
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VV7NYO)
    else  : cmd = "mkdir '%s' %s" % (path, VV7NYO)
    result = FF5sfh(cmd)
    if "Fail" in result:
     FFGr6w(self, result)
    self.VVH7HW()
   else:
    FFGr6w(self, "Name already exists !\n\n%s" % path, title)
 def VVcgnh(self, path, selFile):
  VVwdxM = []
  VVwdxM.append(("List Package Files"          , "VV55SW"     ))
  VVwdxM.append(("Package Information"          , "VVegvs"     ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Install Package"           , "VV6Oi9_CheckVersion" ))
  VVwdxM.append(("Install Package (force reinstall)"      , "VV6Oi9_ForceReinstall" ))
  VVwdxM.append(("Install Package (force downgrade)"      , "VV6Oi9_ForceDowngrade" ))
  VVwdxM.append(("Install Package (ignore failed dependencies)"    , "VV6Oi9_IgnoreDepends" ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Remove Related Package"         , "VVZSuH_ExistingPackage" ))
  VVwdxM.append(("Remove Related Package (force remove)"     , "VVZSuH_ForceRemove"  ))
  VVwdxM.append(("Remove Related Package (ignore failed dependencies)"  , "VVZSuH_IgnoreDepends" ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("Extract Files"           , "VVxuGh"     ))
  VVwdxM.append(("Unbuild Package"           , "VVMNVb"     ))
  FFsmMG(self, boundFunction(self.VV1UQY, path, selFile), VVwdxM=VVwdxM)
 def VV1UQY(self, path, selFile, item=None):
  if item is not None:
   if   item == "VV55SW"      : self.VV55SW(path, selFile)
   elif item == "VVegvs"      : self.VVegvs(path)
   elif item == "VV6Oi9_CheckVersion"  : self.VV6Oi9(path, selFile, VV5AxC     )
   elif item == "VV6Oi9_ForceReinstall" : self.VV6Oi9(path, selFile, VVOhTz )
   elif item == "VV6Oi9_ForceDowngrade" : self.VV6Oi9(path, selFile, VVkdhs )
   elif item == "VV6Oi9_IgnoreDepends" : self.VV6Oi9(path, selFile, VVHV5w )
   elif item == "VVZSuH_ExistingPackage" : self.VVZSuH(path, selFile, VVZ6uP     )
   elif item == "VVZSuH_ForceRemove"  : self.VVZSuH(path, selFile, VVYVJg  )
   elif item == "VVZSuH_IgnoreDepends"  : self.VVZSuH(path, selFile, VVbYh9 )
   elif item == "VVxuGh"     : self.VVxuGh(path, selFile)
   elif item == "VVMNVb"     : self.VVMNVb(path, selFile)
   else           : self.close()
 def VV55SW(self, path, selFile):
  if FFZYBr("ar") : cmd = "allOK='1';"
  else    : cmd  = FFO6jP()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVlWOd, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVlWOd, VVlWOd)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFphhB(self, cmd, VVlT5W=self.VVH7HW)
 def VVxuGh(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFAYBC(path, True) + selFile[:-4]
  cmd  =  FFO6jP()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFoKN8("mkdir '%s'" % dest) + ";"
  cmd +=    FFoKN8("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFdpXa(dest, VVI0dy))
  cmd += "fi;"
  FFgQDF(self, cmd, VVlT5W=self.VVH7HW)
 def VVMNVb(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVZEpm = os.path.splitext(path)[0]
  else        : VVZEpm = path + "_"
  if path.endswith(".deb")   : VVbeZK = "DEBIAN"
  else        : VVbeZK = "CONTROL"
  cmd  = FFO6jP()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVZEpm, FFG7qD())
  cmd += "  mkdir '%s';"    % VVZEpm
  cmd += "  CONTPATH='%s/%s';"  % (VVZEpm, VVbeZK)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVZEpm
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVZEpm, VVZEpm)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVZEpm
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVZEpm, VVZEpm)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVZEpm
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVZEpm
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVZEpm, FFdpXa(VVZEpm, VVI0dy))
  cmd += "fi;"
  FFgQDF(self, cmd, VVlT5W=self.VVH7HW)
 def VVegvs(self, path):
  listCmd  = FFSOBZ(VVHzCw, "")
  infoCmd  = FFS262(VVhYlS , "")
  filesCmd = FFS262(VVJmdL, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FF2OPV(VVX3gJ)
   notInst = "Package not installed."
   cmd  = FFMJrr("File Info", VVX3gJ)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFMJrr("System Info", VVX3gJ)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFdpXa(notInst, VVBEBZ))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFMJrr("Related Files", VVX3gJ)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFj8K7(self, cmd)
  else:
   FFQ7SS(self)
 def VV6Oi9(self, path, selFile, cmdOpt):
  cmd = FFS262(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFIxs9(self, boundFunction(FFgQDF, self, cmd, VVlT5W=FFLC0G), "Install Package ?\n\n%s" % selFile)
  else:
   FFQ7SS(self)
 def VVZSuH(self, path, selFile, cmdOpt):
  listCmd  = FFSOBZ(VVHzCw, "")
  infoCmd  = FFS262(VVhYlS, "")
  instRemCmd = FFS262(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFdpXa(errTxt, VVBEBZ))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFdpXa(cannotTxt, VVBEBZ))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFdpXa(tryTxt, VVBEBZ))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFIxs9(self, boundFunction(FFgQDF, self, cmd, VVlT5W=FFLC0G), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFQ7SS(self)
 def VVPSqX(self, path):
  hostName = FF5sfh("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVTfOA(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVPSqX(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVI35V(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVwdxM = []
  VVwdxM.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVwdxM.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVwdxM.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVwdxM.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVwdxM.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVwdxM.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVwdxM.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVwdxM.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVwdxM.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVwdxM.append(VVWygA)
  VVwdxM.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVwdxM.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFsmMG(self, boundFunction(self.VVSrtS, path), VVwdxM=VVwdxM)
 def VVSrtS(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVDAUn(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVDAUn(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVDAUn(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVDAUn(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVDAUn(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVDAUn(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVDAUn(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVDAUn(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVDAUn(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVDAUn(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VV6b4o(path, False)
   elif item == "convertDirToDeb"   : self.VV6b4o(path, True)
   else         : self.close()
 def VV6b4o(self, path, VVIteZ):
  self.session.openWithCallback(self.VVH7HW, boundFunction(CC4z8v, path=path, VVIteZ=VVIteZ))
 def VVDAUn(self, path, fileExt, preserveDirStruct):
  parent  = FFAYBC(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFwBeJ("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFwBeJ("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFwBeJ("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVlWOd
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFoKN8("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FFdpXa(resultFile, VVI0dy))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FFdpXa(failed, VVNRjX))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFphhB(self, cmd, VVlT5W=self.VVH7HW)
 def VVdIMN(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFrFsL(self, versionFile)
 def VVlADx(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVPSqX(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFGr6w(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFn8wV(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFAYBC(path, False)
  VVZEpm = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FFdpXa(errCmd, VVNRjX))
  installCmd = FFS262(VV5AxC , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVZEpm, VVZEpm)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVZEpm
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVZEpm
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVZEpm, VVZEpm)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFgQDF(self, cmd, VVlT5W=self.VVH7HW)
 def VVrQ9x(self, path):
  FFGr6w(self, "Under Construction.")
 def VVMSIH(self, path):
  FFGr6w(self, "Under Construction.")
class CCf2Ls(MenuList):
 def __init__(self, VVQP6i=False, directory="/", VVpWWW=True, VVLzLj=True, VVhgLq=True, VVM9FD=None, VVLA2r=False, VVi3dx=False, VVw4px=False, isTop=False, VVce9I=None, VV2IsJ=1000, VVA2Pa=30, VVCg7w=30, VVIePE="#00000000"):
  MenuList.__init__(self, list, VVQP6i, eListboxPythonMultiContent)
  self.VVpWWW  = VVpWWW
  self.VVLzLj    = VVLzLj
  self.VVhgLq  = VVhgLq
  self.VVM9FD  = VVM9FD
  self.VVLA2r   = VVLA2r
  self.VVi3dx   = VVi3dx or []
  self.VVw4px   = VVw4px or []
  self.isTop     = isTop
  self.additional_extensions = VVce9I
  self.VV2IsJ    = VV2IsJ
  self.VVA2Pa    = VVA2Pa
  self.VVCg7w    = VVCg7w
  self.pngBGColor    = FFzcsD(VVIePE)
  self.EXTENSIONS    = self.VVarE4()
  self.VV7FV8   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVbhwc, self.VVA2Pa))
  self.l.setItemHeight(self.VVCg7w)
  self.png_mem   = self.VVQUJY("mem")
  self.png_usb   = self.VVQUJY("usb")
  self.png_fil   = self.VVQUJY("fil")
  self.png_dir   = self.VVQUJY("dir")
  self.png_dirup   = self.VVQUJY("dirup")
  self.png_srv   = self.VVQUJY("srv")
  self.png_slwfil   = self.VVQUJY("slwfil")
  self.png_slbfil   = self.VVQUJY("slbfil")
  self.png_slwdir   = self.VVQUJY("slwdir")
  self.VVQlEs()
  self.VVVXEV(directory)
 def VVQUJY(self, category):
  return LoadPixmap("%s%s.png" % (VVfmTj, category), getDesktop(0))
 def VVarE4(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "rar" : "rar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u"
  }
 def VVWJCa(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFO8pH(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFY8RM(" -> " , VVX3gJ) + FFY8RM(os.readlink(path), VVI0dy)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVCg7w + 10, 0, self.VV2IsJ, self.VVCg7w, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVCzvI: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVCg7w-4, self.VVCg7w-4, png, self.pngBGColor, self.pngBGColor, VVCzvI))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVCg7w-4, self.VVCg7w-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVOclv(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVQlEs(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VV22g5(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVAq2Y(self, file):
  if os.path.realpath(file) == file:
   return self.VV22g5(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VV22g5(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VV22g5(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVvOuW(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VV7FV8.info(l[0][0]).getEvent(l[0][0])
 def VVDykN(self):
  return self.list
 def VVMP0i(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVVXEV(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVhgLq:
    self.current_mountpoint = self.VVAq2Y(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVhgLq:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVw4px and not self.VVMP0i(path, self.VVi3dx):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVWJCa(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVLA2r:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VV7FV8 = eServiceCenter.getInstance()
   list = VV7FV8.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVpWWW and not self.isTop:
   if directory == self.current_mountpoint and self.VVhgLq:
    self.list.append(self.VVWJCa(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVw4px and self.VV22g5(directory) in self.VVw4px):
    self.list.append(self.VVWJCa(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVpWWW:
   for x in directories:
    if not (self.VVw4px and self.VV22g5(x) in self.VVw4px) and not self.VVMP0i(x, self.VVi3dx):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVWJCa(name = name, absolute = x, isDir = True, png = png))
  if self.VVLzLj:
   for x in files:
    if self.VVLA2r:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFY8RM(" -> " , VVX3gJ) + FFY8RM(target, VVI0dy)
       else:
        png = self.png_slbfil
        name += FFY8RM(" -> " , VVX3gJ) + FFY8RM(target, VVNRjX)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVOclv(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVfmTj, category))
    if (self.VVM9FD is None) or iCompile(self.VVM9FD).search(path):
     self.list.append(self.VVWJCa(name = name, absolute = x , isDir = False, png = png))
  if self.VVhgLq and len(self.list) == 0:
   self.list.append(self.VVWJCa(name = FFY8RM("No USB connected", VVea45), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVLQPS(self):
  return self.current_directory
 def VV8V4U(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVVXEV(self.getSelection()[0], select = self.current_directory)
 def VVnap8(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVFswf(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVb8P5)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVb8P5)
 def refresh(self):
  self.VVVXEV(self.current_directory, self.VVnap8())
 def VVb8P5(self, action, device):
  self.VVQlEs()
  if self.current_directory is None:
   self.refresh()
class CCqlZz(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFFsgK(VVFsTR, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVbKpp   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVcXaO(defFG, "#00FFFFFF")
  self.defBG   = self.VVcXaO(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFKXoA(self, self.Title)
  self["keyRed"].show()
  FFhu6U(self["keyGreen"] , "< > Transp.")
  FFhu6U(self["keyYellow"], "Foreground")
  FFhu6U(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVVYU9        ,
   "yellow"   : boundFunction(self.VVLboA, False)  ,
   "blue"   : boundFunction(self.VVLboA, True)  ,
   "up"   : self.VVmzSZ          ,
   "down"   : self.VVcFVq         ,
   "left"   : self.VVPGw2         ,
   "right"   : self.VVxtQm         ,
   "last"   : boundFunction(self.VVXejf, -5) ,
   "next"   : boundFunction(self.VVXejf, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVa2bU)
 def VVa2bU(self):
  self.onShown.remove(self.VVa2bU)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFpRmN(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFpRmN(self["keyRed"] , c)
  FFpRmN(self["keyGreen"] , c)
  self.VVkM7G()
  self.VVLwSm()
  FF1NxI(self["myColorTst"], self.defFG)
  FFpRmN(self["myColorTst"], self.defBG)
 def VVcXaO(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVLwSm(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVpKtj(0, 0)
     return
 def VVVYU9(self):
  self.close(self.defFG, self.defBG)
 def VVmzSZ(self): self.VVpKtj(-1, 0)
 def VVcFVq(self): self.VVpKtj(1, 0)
 def VVPGw2(self): self.VVpKtj(0, -1)
 def VVxtQm(self): self.VVpKtj(0, 1)
 def VVpKtj(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVjq8J()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVtfZd()
 def VVkM7G(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVtfZd(self):
  color = self.VVjq8J()
  if self.isBgMode: FFpRmN(self["myColorTst"], color)
  else   : FF1NxI(self["myColorTst"], color)
 def VVLboA(self, isBg):
  self.isBgMode = isBg
  self.VVkM7G()
  self.VVLwSm()
 def VVXejf(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVpKtj(0, 0)
 def VVgA7J(self):
  return hex(self.transp)[2:].zfill(2)
 def VVjq8J(self):
  return ("#%s%s" % (self.VVgA7J(), self.colors[self.curRow][self.curCol])).upper()
class CCVmtM(ScrollLabel):
 def __init__(self, parentSELF, text="", VVTtk2=True):
  ScrollLabel.__init__(self, text)
  self.VVTtk2=VVTtk2
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VV7SEX  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVA2Pa    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close   ,
   "cancel"  : parentSELF.close   ,
   "red"   : self.VVf5Pz   ,
   "green"   : self.VVDB8S  ,
   "yellow"  : self.VVzc56  ,
   "blue"   : self.VVMrIa  ,
   "up"   : self.pageUp    ,
   "down"   : self.pageDown    ,
   "left"   : self.pageUp    ,
   "right"   : self.pageDown    ,
   "pageUp"  : self.VVgg0X    ,
   "chanUp"  : self.VVgg0X    ,
   "pageDown"  : self.VVRCMz    ,
   "chanDown"  : self.VVRCMz
  }, -1)
 def VVA9a4(self, isResizable=True, VV5ijV=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFFOZ8(self.parentSELF, True)
  self.isResizable = isResizable
  if VV5ijV:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVA2Pa  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFpRmN(self, color)
 def FFpRmNColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VV7SEX - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVsRkR()
 def pageUp(self):
  if self.VV7SEX > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VV7SEX > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVgg0X(self):
  self.setPos(0)
 def VVRCMz(self):
  self.setPos(self.VV7SEX-self.pageHeight)
 def VVae3r(self):
  return self.VV7SEX <= self.pageHeight or self.curPos == self.VV7SEX - self.pageHeight
 def VVsRkR(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VV7SEX, 3))
   start = int((100 - vis) * self.curPos / (self.VV7SEX - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVbIQl=VVUbEX):
  old_VVae3r = self.VVae3r()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VV7SEX = self.long_text.calculateSize().height()
   if self.VVTtk2 and self.VV7SEX > self.pageHeight:
    self.scrollbar.show()
    self.VVsRkR()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VV7SEX))
   if   VVbIQl == VVmdF8: self.setPos(0)
   elif VVbIQl == VV1GDe : self.VVRCMz()
   elif old_VVae3r    : self.VVRCMz()
 def appendText(self, text, VVbIQl=VV1GDe):
  self.setText(self.message + str(text), VVbIQl)
 def VVzc56(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVGrlU(size)
 def VVMrIa(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVGrlU(size)
 def VVDB8S(self):
  self.VVGrlU(self.VVA2Pa)
 def VVGrlU(self, VVA2Pa):
  self.long_text.setFont(gFont(self.fontFamily, VVA2Pa))
  self.setText(self.message, VVbIQl=VVUbEX)
  self.VVSLZQ(calledFromFontSizer=True)
 def VVf5Pz(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FFgbrL(expPath), self.textOutFile, FF9n2A())
    with open(outF, "w") as f:
     f.write(FFaO74(self.message))
    FF6zpT(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FFGr6w(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVSLZQ(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VV7SEX > 0 and self.pageHeight > 0:
   if self.VV7SEX < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VV7SEX
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
