import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile
except: iMove = iCopyfile = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVVsnC   = "v8.2.0"
VVZ1EB    = "16-12-2022"
EASY_MODE    = 0
VVxG5f   = 0
VVE7eu   = 0
VVZvBa  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVvMcE  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVAVra    = "/media/usb/"
VV2DcN    = "/usr/share/enigma2/picon/"
VV7lVB = "/etc/enigma2/blacklist"
VVMOat   = "/etc/enigma2/"
VVaDqM   = "AJPan"
VVrV5t  = "AUTO FIND"
VVN9NZ  = "Custom"
VVClf2    = ""
VVRvDu = "Regular"
VVl20R = "Fixed"
VVdJ3x  = "AJP_Main"
VVZtGY = "AJP_Terminal"
VVYN98 = "AJP_System"
VV07pp  = VVRvDu
VVtc24      = "-" * 80
VVHMBI    = ("-" * 100, )
VVtXrR    = ""
VV56tq   = " && echo 'Successful' || echo 'Failed!'"
VVk8Pc    = []
VVmwUY  = "Cannot continue (No Enough Memory) !"
BAR_BUTTONS_COLORS  = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
VVh0o2  = False
VVks1Y  = False
VVtBbU     = 0
VVOWvY    = 1
VVQQVG    = 2
VVQZV2   = 3
VVoC9G    = 4
VVg0pw    = 5
VVinJE = 6
VV95UA = 7
VVDWFj  = 8
VV168T   = 9
VVVnfS  = 10
VVnHvF  = 11
VVAHed = 12
VVfjZk    = 13
VVAUOK   = 14
VVCOjl   = 15
VVh7Ze    = 16
VV9oFo    = 17
VVP9BS  = 18
VVX7Sq    = 19
VVXWIl   = 0
VVaZwj   = 1
VVC4tc   = 2
def FFAiXd():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VV07pp
  if VVdJ3x in lst and CFG.fontPathMain.getValue(): VV07pp = VVdJ3x
  else               : VV07pp = VVRvDu
  return lst
 else:
  return [VVRvDu]
def FF7ym2(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[("v", "Virtual Keyboard"),("s", "System Default")])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[("d", "Directory Up"),("e", "Exit File Manage")])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[("off", "Disable"),("lok", "Long-OK"),("lesc", "Long-Exit"),("lred", "Long-Red")])
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[("off", "Disable"),("jpg", "JPG"),("png", "PNG"),("bmp", "BMP")])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[("1", "1 (DVB Stream)"),("4097", "4097 (servicemp3)"),("5001", "5001 (GST Player)"),("5002", "5002 (Ext-3 EPlayer)"),("8192", "8192 (HDMI input)"),("8193", "8193 (eServiceUri)")])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVrV5t, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.PIconsPath     = ConfigDirectory(default=VV2DcN, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVAVra, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindMovie    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
CFG.transpColorMovies   = ConfigText(default="#11404040")
CFG.epgLangTitle    = ConfigText(default="")
CFG.epgLangDescr    = ConfigText(default="")
tmp = [("srt", "FROM SRT FILE"),("#00FFFF", "Aqua"),("#000000", "Black"),("#0000FF", "Blue"),("#FF00FF", "Fuchsia"),("#808080", "Gray"),("#008000", "Green"),("#00FF00", "Lime"),("#800000", "Maroon"),("#000080", "Navy"),("#808000", "Olive"),("#800080", "Purple"),("#FF0000", "Red"),("#C0C0C0", "Silver"),("#008080", "Teal"),("#FFFFFF", "White"),("#FFFF00", "Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VV07pp, choices=[(x,  x) for x in FFAiXd()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[("0", "Left"),("1", "Center"),("2", "Right")])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FFw1hg():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVfTxa  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVX0ld = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVfTxa  : return 0
  elif VVX0ld : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
COLOR_SCHEME_NUM = FFw1hg()
VVPYB5 = VVsvZg = VVSGHr = VVnKNv = VVsIVN = VVPN93 = VVoRk2 = VVEanD = VVUdsq = VVSTv2 = VVBfw8 = VVpkep = VVOEUI = VVJCMd = VVlagI = VVZ51O = ""
def FF3etF()  : FFQ5zt(FFrCBj())
def FFjRiB()  : FFQ5zt(FFhcdq())
def FFe96c(tDict): FFQ5zt(iDumps(tDict, indent=4, sort_keys=True))
def FFRcfv(*args): FFRbes(True, True, *args)
def FFQ5zt(*args) : FFRbes(True , False , *args)
def FFwfhz(*args): FFRbes(False, False, *args)
def FFRbes(addSep=True, isArray=True, *args):
 if VVxG5f:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(key.ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFWNhN(fnc):
 def VVWcO8(*args, **kwargs):
  t1 = iTime()
  fnc(*args, **kwargs)
  FFQ5zt(">>>>>> Elapsed : %s sec\nargs = %s\nkwargs = %s" % (("%.6f" % (iTime() - t1)).rstrip("0"), args, kwargs))
 return VVWcO8
def FFXUBf(*args):
 if VVxG5f:
  path = "/tmp/ajpanel_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FFwfhz("Added to : %s" % path)
def FFFz6y(txt, isAppend=True, ignoreErr=False):
 if VVxG5f:
  tm = FFWXiC()
  err = ""
  if not ignoreErr:
   err = FFhcdq()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFQ5zt(err)
  FFQ5zt("Output Log File : %s" % fileName)
def FFhcdq():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFWXiC()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFrCBj():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVSVrT = 0
def FFvJ10():
 global VVSVrT
 VVSVrT = iTime()
def FFmkvW(txt=""):
 FFQ5zt(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VVSVrT)).rstrip("0"), txt))
VVk8Pc = []
def FFkraF(win):
 global VVk8Pc
 if not win in VVk8Pc:
  VVk8Pc.append(win)
def FFaoGB(*args):
 global VVk8Pc
 for win in VVk8Pc:
  try:
   win.close()
  except:
   pass
 VVk8Pc = []
def FFsgAT():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVejcx = FFsgAT()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFrFfT()    : return PluginDescriptor(fnc=FF8D5D, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FFh4nw()      : return getDescriptor(FFmbFy , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFEae1()     : return getDescriptor(FF1wNt  , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFpWXJ()  : return getDescriptor(FFXzOc, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFo5cf() : return getDescriptor(FFFtub , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FFIABR()  : return getDescriptor(FFDgaO , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FF1bLy()  : return getDescriptor(FFH2Vj  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFrpWu()    : return getDescriptor(FFBZNG, [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFEae1() , FFh4nw() , FFrFfT() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFpWXJ())
  result.append(FFo5cf())
  result.append(FFIABR())
  result.append(FF1bLy())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFrpWu())
 return result
def FF8D5D(reason, **kwargs):
 if reason == 0:
  FFoxHW()
  if "session" in kwargs:
   session = kwargs["session"]
   FFJUB7(session)
   CCNhb1(session)
def FFmbFy(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FF1wNt, PLUGIN_NAME, 45)]
 else:
  return []
def FF1wNt(session, **kwargs):
 session.open(Main_Menu)
def FFXzOc(session, **kwargs):
 session.open(CCr5c7)
def FFFtub(session, **kwargs):
 session.open(CCCu2Z)
def FFDgaO(session, **kwargs):
 CCM2Fd.VV8elw(session, isFromExternal=True)
def FFH2Vj(session, **kwargs):
 FFyGv4(session, reopen=True)
def FFBZNG(session, **kwargs):
 session.open(CC6biu, fncMode=CC6biu.VVn9lJ)
def FFHzqE():
 FFZCXS(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFpWXJ(), FFo5cf(), FFIABR(), FF1bLy() ])
 FFZCXS(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFrpWu() ])
def FFZCXS(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VVaLLY = None
def FFoxHW():
 try:
  global VVaLLY
  if VVaLLY is None:
   VVaLLY    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFFlRE
  ChannelContextMenu.FFGyyq = FFGyyq
 except:
  pass
def FFFlRE(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVaLLY(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , BF(SELF.FFGyyq, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , BF(SELF.FFGyyq, title1, csel, isFind=True))))
def FFGyyq(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFqfF5(refCode)
 except:
  pass
 self.session.open(BF(CCMiPi, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFJUB7(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FFdZ7A, session, "lok")
 hk.actions["longCancel"]= BF(FFdZ7A, session, "lesc")
 hk.actions["longRed"] = BF(FFdZ7A, session, "lred")
 for k in (CCmMzJ.VVcSqq, CCmMzJ.VV19PO, CCmMzJ.VVaJUc):
  hk.actions[k] = BF(CCmMzJ.VVswZg, session, k)
def FFdZ7A(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CChWWt.VVaEJ0:
    CChWWt.VVaEJ0.close()
   if not CCM2Fd.VVUYe0:
    CCM2Fd.VV8elw(session, isFromExternal=True)
  except:
   pass
def FFCfiF(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FFsw8F(SELF, title="", addLabel=False, addScrollLabel=False, VVegP0=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFyqg5()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCfDKH(SELF)
 if VVegP0:
  SELF["myMenu"] = MenuList(VVegP0)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.VVu0DR ,
   "cancel": SELF.close ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.close,
   "cancel": SELF.close,
   "red" : SELF.close
  }, -1)
def FF0zxL(SELF, tableObj, colNum=0, isMenu=False):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFOfCN, SELF, "0"),
  "1" : BF(FFOfCN, SELF, "1"),
  "2" : BF(FFOfCN, SELF, "2"),
  "3" : BF(FFOfCN, SELF, "3"),
  "4" : BF(FFOfCN, SELF, "4"),
  "5" : BF(FFOfCN, SELF, "5"),
  "6" : BF(FFOfCN, SELF, "6"),
  "7" : BF(FFOfCN, SELF, "7"),
  "8" : BF(FFOfCN, SELF, "8"),
  "9" : BF(FFOfCN, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFpi8A, SELF, tableObj, colNum, isMenu))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFOfCN(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVZ51O:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVZ51O + SELF.keyPressed + VVsvZg)
    txt = VVsvZg + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFtMfC(SELF, txt)
def FFpi8A(SELF, tableObj, colNum, isMenu):
 FFtMfC(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    if isMenu: item = tableObj.list[i][colNum].strip()
    else  : item = tableObj.list[i][colNum + 1][7].strip()
    item = FF2AUs(item).encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     if isMenu: SELF.VVc7DL(i)
     else  : SELF.VVwqjr(i)
     break
 except:
  pass
def FFyqg5():
 return ("  %s" % VVtXrR)
def FF154z(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FF2AUs(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFXhEg(color):
 return parseColor(color).argb()
def FFD09G(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFo6oa(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFTnVH(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFmjg3(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVZ51O)
 else:
  return ""
def FFBxX8(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVtc24, word, VVtc24, VVZ51O)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVtc24, word, VVtc24)
def FF6TiS(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVZ51O
def FF7nYK(color):
 if color: return "echo -e '%s' %s;" % (VVtc24, FFmjg3(VVtc24, VVBfw8))
 else : return "echo -e '%s';" % VVtc24
def FFqjvC(title, color):
 title = "%s\n%s\n%s\n" % (VVtc24, title, VVtc24)
 return FF6TiS(title, color)
def FFCoOh(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FF9mPY(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFDxKA(callBackFunction):
 tCons = CCXMpW()
 tCons.ePopen("echo", BF(FFv9zx, callBackFunction))
def FFv9zx(callBackFunction, result, retval):
 callBackFunction()
def FFG53m(SELF, fnc, title="Processing ...", clearMsg=True):
 FFtMfC(SELF, title)
 tCons = CCXMpW()
 tCons.ePopen("echo", BF(FFMYgu, SELF, fnc, clearMsg))
def FFMYgu(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFtMfC(SELF)
def FF5whR(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVmwUY
  else       : return ""
def FF5Sgm(cmd):
 txt = FF5whR(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFN7zW(cmd):
 lines = FF5Sgm(cmd)
 if lines: return lines[0]
 else : return ""
def FFWD2L(SELF, cmd):
 lines = FF5Sgm(cmd)
 VVzto2 = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVzto2.append((key, val))
  elif line:
   VVzto2.append((line, ""))
 if VVzto2:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFqiz1(SELF, None, header=header, VVVC4T=VVzto2, VVx2iV=widths, VVwwGj=28)
 else:
  FFSCk3(SELF, cmd)
def FFSCk3(    SELF, cmd, **kwargs): SELF.session.open(CCHOmo, VVb1hE=cmd, VVdXTj=True, VVwZYa=VVaZwj, **kwargs)
def FFKG3v(  SELF, cmd, **kwargs): SELF.session.open(CCHOmo, VVb1hE=cmd, **kwargs)
def FFlo7E(   SELF, cmd, **kwargs): SELF.session.open(CCHOmo, VVb1hE=cmd, VVEtLW=True, VVfE3s=True, VVwZYa=VVaZwj, **kwargs)
def FFvkVo(  SELF, cmd, **kwargs): SELF.session.open(CCHOmo, VVb1hE=cmd, VVEtLW=True, VVfE3s=True, VVwZYa=VVC4tc, **kwargs)
def FFYyBc(  SELF, cmd, **kwargs): SELF.session.open(CCHOmo, VVb1hE=cmd, VV7FEJ=True , **kwargs)
def FF1jRo(  session, cmd, **kwargs):      session.open(CCHOmo, VVb1hE=cmd, VV7FEJ=True , **kwargs)
def FFBZDd( SELF, cmd, **kwargs): SELF.session.open(CCHOmo, VVb1hE=cmd, VVOAUy=True   , **kwargs)
def FFq3ul( SELF, cmd, **kwargs): SELF.session.open(CCHOmo, VVb1hE=cmd, VVSiFo=True  , **kwargs)
def FFNxGN(cmd):
 return cmd + " > /dev/null 2>&1"
def FFBAbA(cmd):
 return cmd + " 2> /dev/null"
def FFlMiq():
 return " > /dev/null 2>&1"
def FF63FC(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFdsA4(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFdjjI():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FFN7zW(cmd)
VVvVUt     = 0
VVxe2n      = 1
VVXp23   = 2
VViz0h      = 3
VV3b1m      = 4
VVcrY8     = 5
VVerzX     = 6
VVw4vm = 7
VVFhZO = 8
VVpj31 = 9
VVjszN  = 10
VVUSd3     = 11
VVUCVW  = 12
VVM72P  = 13
def FFQz9o(parmNum, grepTxt):
 if   parmNum == VVvVUt  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVxe2n   : param = ["list"   , "apt list" ]
 elif parmNum == VVXp23: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFdjjI()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFiwac(parmNum, package):
 if   parmNum == VViz0h      : param = ["info"      , "apt show"         ]
 elif parmNum == VV3b1m      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVcrY8     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVerzX     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVw4vm : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVFhZO : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VVpj31 : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVjszN  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVUSd3     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVUCVW  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVM72P  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFdjjI()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFZKBU():
 result = FFN7zW("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFiwac(VVerzX , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFNxGN("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFNxGN("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFmjg3(failed1, VVBfw8))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFmjg3(failed2, VVBfw8))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFmjg3(failed3, VVSGHr))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FF3XrD(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFiwac(VVerzX , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFNxGN("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFmjg3(failed1, VVBfw8))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFmjg3(failed2, VVSGHr))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFpySX(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFNxGN('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFNxGN("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFu1EI(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCBlwj.VVFyVU()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FF5DO4(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFu1EI(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FF1QId(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFREV4(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFu1EI(path, maxSize=maxSize, encLst=encLst)
  if lines: FFJRXg(SELF, lines, title=title, VVwZYa=VVaZwj, width=1600, height=1000, titleFontSize=30)
  else : FFiIsE(SELF, path, title=title)
 else:
  FFlkXm(SELF, path, title)
def FFHU3T(SELF, fName, title):
 path = VVeop3 + fName
 if fileExists(path):
  txt = FFu1EI(path)
  txt = txt.replace("#W#", VVZ51O)
  txt = txt.replace("#Y#", VVpkep)
  txt = txt.replace("#G#", VVsvZg)
  txt = txt.replace("#C#", VVOEUI)
  txt = txt.replace("#P#", VVsIVN)
  FFJRXg(SELF, txt, title=title)
 else:
  FFlkXm(SELF, path, title)
def FFdvPe(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFRlhS(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFxJSp(parent)
 else    : return FFhn59(parent)
def FFjyTm(path):
 return os.path.basename(os.path.normpath(path))
def FFREV4(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FFWXwG(path):
 size = 0
 for Dir, dirs, files in os.walk(path):
  for f in files:
   fp = os.path.join(Dir, f)
   try:
    size += os.path.getsize(fp)
   except:
    pass
 return size
def FFO0bd(path):
 try:
  os.remove(path)
 except:
  pass
def FFZqpj(path):
 return os.system(FFNxGN("chattr -AacDdijsStu '%s'" % path) + ";" + FFNxGN("rm -fr '%s'" % path))
def FFxJSp(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFhn59(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFbels():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVZvBa)
 paths.append(VVZvBa.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFdvPe(ba)
 for p in list:
  p = ba + p + VVZvBa
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVaDqM, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVZvBa, VVaDqM , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVcLQT, VVeop3 = FFbels()
def FFaCeZ():
 def VVkrGn(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VVJu6Y   = VVkrGn(CFG.backupPath, CCAqEA.VV5kmb())
 VVUvHH   = VVkrGn(CFG.downloadedPackagesPath, t)
 VVFykX  = VVkrGn(CFG.exportedTablesPath, t)
 VV1idp  = VVkrGn(CFG.exportedPIconsPath, t)
 VVgGkd   = VVkrGn(CFG.packageOutputPath, t)
 global VVAVra
 VVAVra = FFxJSp(CFG.backupPath.getValue())
 if VVJu6Y or VVgGkd or VVUvHH or VVFykX or VV1idp or oldMovieDownloadPath:
  configfile.save()
 return VVJu6Y, VVgGkd, VVUvHH, VVFykX, VV1idp, oldMovieDownloadPath
def FF61aD(path):
 path = FFhn59(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FF5ja7(SELF, pathList, tarFileName, addTimeStamp=True):
 VVVC4T = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVVC4T.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVVC4T.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVVC4T.append(path)
 if not VVVC4T:
  FFnHzu(SELF, "Files not found!")
 elif not pathExists(VVAVra):
  FFnHzu(SELF, "Path not found!\n\n%s" % VVAVra)
 else:
  VVftjM = FFxJSp(VVAVra)
  tarFileName = "%s%s" % (VVftjM, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFxsfY())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVVC4T:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVtc24
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFmjg3(tarFileName, VVUdsq))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFmjg3(failed, VVUdsq))
  cmd += "fi;"
  cmd +=  sep
  FFKG3v(SELF, cmd)
def FF6aqB(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFeKhX(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFeKhX(SELF["keyInfo"], "info")
def FFeKhX(barObj, fName):
 path = "%s%s%s" % (VVeop3, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FF9TiB(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FF99jt(satNum)
  return satName
def FF99jt(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFkzUr(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FF9TiB(val)
  else  : sat = FF99jt(val)
 return sat
def FFWJ2v(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FF9TiB(num)
 except:
  pass
 return sat
def FF96lQ(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFZRjy(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFIO7o(info, iServiceInformation.sServiceref)
   prov = FFIO7o(info, iServiceInformation.sProvider)
   state = str(FFIO7o(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FF2IUY(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFiRgM(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFIO7o(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFgjov(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFqfF5(refCode):
 info = FF7wIU(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFSeor(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFSTOf(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FF7wIU(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVV82e = eServiceCenter.getInstance()
  if VVV82e:
   info = VVV82e.info(service)
 return info
def FFGrAa(SELF, refCode, VVMo36=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFg1na(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVMo36:
   FFPC1a(SELF, isFromSession)
 try:
  VVcxBI = InfoBar.instance
  if VVcxBI:
   VVHQTD = VVcxBI.servicelist
   if VVHQTD:
    servRef = eServiceReference(refCode)
    VVHQTD.saveChannel(servRef)
 except:
  pass
def FFg1na(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCM7WN()
    if pr.VV7eRj(refCode, chName, decodedUrl, iptvRef):
     pr.VVEJxa(SELF, isFromSession)
def FF2IUY(refCode):
 return True if iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE) else False
def FFabwQ(ref):
 if "chcm=" in ref.lower(): return False
 else      : return True if iSearch(r"https?([:]|%3a)\/\/(127.0.0.\d|0.0.0.0|192.168.\d.\d|localhost).+", ref, IGNORECASE) else False
def FFa4u4(url): return FF2xh4(url) or FFA3h4(url)
def FF2xh4(url)  : return any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFA3h4(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFiRgM(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFyQaB(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFyQaB(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFXjqJ(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFLLdk(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFHC0y(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFp8pW(txt):
 try:
  return FFLLdk(FFHC0y(txt)) == txt
 except:
  return False
def FFT5mp(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FFxJSp(newPath), patt))
def FFPC1a(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: CCM2Fd.VV8elw(session, isFromExternal=isFromSession)
 else      : FFyGv4(session, reopen=True)
def FFyGv4(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FFyGv4, session), CChWWt)
  except:
   try:
    FFM8cf(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFYvXi(refCode):
 tp = CCxkcu()
 if tp.VVKvS6(refCode) : return True
 else        : return False
def FFqMFs(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFmB3r(True)
     return True
 return False
def FFmB3r(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FFbqZe()
def FFbqZe():
 VVcxBI = InfoBar.instance
 if VVcxBI:
  VVHQTD = VVcxBI.servicelist
  if VVHQTD:
   VVHQTD.setMode()
def FFXd2v(root):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVV82e = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVV82e.info(service)
    lst.append((service.toString(), info.getName(service)))
 except:
  pass
 return lst
def FF1mjb():
 VVnYkd = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVCpBm = list(VVnYkd)
 return VVCpBm, VVnYkd
def FFrn02():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFRAMp(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FFrOxn(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FF9ucJ():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFxsfY():
 return FF9ucJ().replace(" ", "_").replace("-", "").replace(":", "")
def FFFSaa(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFWXiC():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFHXM5(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCCu2Z.VVERnQ(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCCu2Z.VV8ga2(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFNxGN("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFGQm9(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FFJHIK(num):
 return "s" if num > 1 else ""
def FF3qV5(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFXM7k(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFt4mY(a, b):
 return (a > b) - (a < b)
def FFAqgR(a, b):
 def VV7SkU(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VV7SkU(a)
 b = VV7SkU(b)
 return (a > b) - (a < b)
def FF6NUe(mycmp):
 class CCRVLS(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CCRVLS
def FFcZi2(SELF, message, title="", VVuJdT=None):
 SELF.session.openWithCallback(VVuJdT, CCuB4X, title=title, message=message, VVhATy=True)
def FFJRXg(SELF, message, title="", VVwZYa=VVaZwj, VVuJdT=None, **kwargs):
 SELF.session.openWithCallback(VVuJdT, CCuB4X, title=title, message=message, VVwZYa=VVwZYa, **kwargs)
def FFnHzu(SELF, message, title="")  : FFM8cf(SELF.session, message, title)
def FFlkXm(SELF, path, title="") : FFM8cf(SELF.session, "File not found !\n\n%s" % path, title)
def FFiIsE(SELF, path, title="") : FFM8cf(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFw6dW(SELF, title="")  : FFM8cf(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFM8cf(session, message, title="") : session.open(BF(CCqH3G, title=title, message=message))
def FFYvs0(SELF, VVuJdT, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVuJdT, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVuJdT, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFnHzu(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFWBJu(SELF, callBack_Yes, VVFNjG, callBack_No=None, title="", VVARnJ=False, VV6Lpq=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FFPUse, callBack_Yes, callBack_No)
         , BF(CCawWb, title=title, VVFNjG=VVFNjG, VV6Lpq=VV6Lpq, VVARnJ=VVARnJ))
def FFPUse(callBack_Yes, callBack_No, FFWBJued):
 if FFWBJued : callBack_Yes()
 elif callBack_No: callBack_No()
def FFtMfC(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFo6oa(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FF5xFA(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFfrnp(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVDSrT = eTimer()
def FF5xFA(SELF, milliSeconds=1000):
 SELF.onClose.append(BF(FFK453, SELF))
 fnc = BF(FFK453, SELF)
 try:
  t = VVDSrT.timeout.connect(fnc)
 except:
  VVDSrT.callback.append(fnc)
 VVDSrT.start(milliSeconds, 1)
def FFK453(SELF):
 VVDSrT.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFqiz1(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCbfio, **kwargs))
  else   : win = SELF.session.open(BF(CCbfio, **kwargs))
  FFkraF(win)
  return win
 except:
  return None
def FFJcY1(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CCUQPd, **kwargs))
 FFkraF(win)
 return win
def FFQJnR(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFiqcT(SELF, **kwargs):
 SELF.session.open(CC6biu, **kwargs)
def FFnLuC(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFmknE(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFzEDc(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VV07pp, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFUSMR(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFzEDc(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize = winInst.size()
 FFOgS2(SELF, winSize.width(), winSize.height())
def FFOgS2(SELF, w, h):
 fSize = SELF["myInfoFrame"].instance.size()
 bSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((w - fSize.width()) // 2, (h - fSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((w - bSize.width()) // 2, (h - bSize.height()) // 2))
def FFF92P():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFtS1n(VVwwGj):
 screenSize  = FFF92P()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVwwGj)
 return bodyFontSize
def FFlCly(VVwwGj, extraSpace):
 font = gFont(VV07pp, VVwwGj)
 VVLEkl = fontRenderClass.getInstance().getLineHeight(font) or (VVwwGj * 1.25)
 return int(VVLEkl + VVLEkl * extraSpace)
def FFAJVu(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, vSliderW=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True, menuLabel=0):
 screenSize = FFF92P()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 extraPar  = None
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 vSliderW  = int(ratioW  * vSliderW)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VV07pp, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFlCly(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0" size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb"  %s />' % (width, titleH, titleColor, VV07pp, titleFontSize, alignLeftCenter)
 if winType in (VVtBbU, VVOWvY):
  if winType == VVOWvY : menuName = "config"
  else      : menuName = "myMenu"
  menuW = bodyW - int(bodyW * menuLabel / 100.0) - marginLeft if menuLabel else bodyW
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, menuW, bodyH, bodyColor, bodyLineH)
  if menuLabel:
   param = 'backgroundColor="%s" foregroundColor="#ffffff" %s' % (bodyColor, bodyFontStr)
   x, w, gap = menuW + marginLeft * 2, bodyW - menuW - marginLeft, int(marginLeft / 2.0)
   tmp += '<widget name="myLabelFrm" position="%d,%d" size="%d,%d" zPosition="3" %s />' % (x - gap, bodyTop, w + gap * 2, bodyH, param)
   tmp += '<widget name="myLabelTit" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + 10, w, titleH, alignCenter, param)
   tmp += '<widget name="myLabelTxt" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + titleH + gap , w, bodyH - titleH - gap * 2, alignLeftCenter, param)
 elif winType == VVP9BS:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == VV9oFo:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VV07pp, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d"    position="1,%d" size="%d,%d" zPosition="6" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VVfjZk:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FFcZi2L = b2Left2 + timeW + marginLeft
  FFcZi2W = b2Left3 - marginLeft - FFcZi2L
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FFcZi2L , b2Top, FFcZi2W , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVAUOK:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVoC9G:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVQQVG:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVQZV2:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VV07pp, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VV07pp, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVVnfS:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VV07pp, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVCOjl:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VV07pp, fontH, alignCenter)
 elif winType in (VVnHvF, VVAHed):
  if winType == VVnHvF: totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  else         : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + 2
  boxW = int((width - vSliderW)  / totCols)
  boxH = int((height - barHeight - boxT) / totRows)
  picH = int(boxH * picR)
  lblH = int(boxH * lblR) - 2
  lblT = boxT + picH + 2
  lblFont = int(lblH * 0.65)
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVnHvF:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h, fg, bg[i]  , VV07pp, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h, fg, bg[i+3], VV07pp, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VV07pp, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VV07pp, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h , fg, bg, VV07pp, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h , fg, bg, VV07pp, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00FFFF00"/>' % (0, boxT, boxW, boxH)
  extraPar = (boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2, transpBG)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VV07pp, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVh7Ze:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVg0pw:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VV95UA : align = alignLeftCenter
  elif winType == VVinJE : align = alignLeftTop
  else          : align = alignCenter
  if winType == VV168T:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VV07pp
  if usefixedFont and winType == VVinJE:
   fLst = FFAiXd()
   if   VVZtGY in fLst and CFG.fontPathTerm.getValue(): fontName = VVZtGY
   elif VVl20R in fLst         : fontName = VVl20R
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVwwGj = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VV07pp, VVwwGj, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VV07pp, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, BAR_BUTTONS_COLORS[i], VV07pp, barFont, alignCenter)
   left += btnW + gap
 if vSliderW:
  par = 'position="0,0" size="20,20"'
  tmp += '<widget name="mySbFrm" zPosition="13" %s />' % par
  tmp += '<widget name="mySbBak" zPosition="14" %s />' % par
  tmp += '<widget name="mySbSld" zPosition="15" %s />' % par
 if winType == VVinJE:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, BAR_BUTTONS_COLORS[i], VV07pp, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap, "extraPar":extraPar}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAJVu(VVtBbU, 800, 950, 40, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VVXHtd = ""
  self.themsList  = []
  self.Title   = "%s - %s" % (PLUGIN_NAME, VVVsnC)
  VVegP0 = []
  if VVE7eu:
   VVegP0.append(("-- MY TEST --"  , "myTest" ))
  VVegP0.append(("File Manager"    , "fMan" ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("IPTV"      , "iptv" ))
  VVegP0.append(("Movies Browser"   , "movie" ))
  VVegP0.append(("Services/Channels"  , "chan" ))
  VVegP0.append(("PIcons"     , "picon" ))
  VVegP0.append(("EPG"      , "epg"  ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Terminal"     , "term" ))
  VVegP0.append(("SoftCam"     , "soft" ))
  VVegP0.append(("Plugins"     , "plug" ))
  VVegP0.append(("Backup & Restore"   , "bakup" ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Date/Time"    , "date" ))
  for ndx, item in enumerate(VVegP0):
   item = list(item)
   item[0] = "  %s" % item[0]
   VVegP0[ndx] = tuple(item)
  FFsw8F(self, title=self.Title, VVegP0=VVegP0)
  FF154z(self["keyRed"] , "Exit")
  FF154z(self["keyGreen"] , "Settings")
  FF154z(self["keyYellow"], "Dev. Info.")
  FF154z(self["keyBlue"] , "Color/Font")
  self["myActionMap"].actions.update({
   "red" : self.close       ,
   "green" : self.VVNjXH      ,
   "yellow": self.VVosD9      ,
   "blue" : self.VV7E6C     ,
   "info" : BF(FFG53m, self, self.VVEc2P) ,
   "text" : self.VVBVWt      ,
   "menu" : self.VVhzzi    ,
   "0"  : BF(self.VVptCl, 0)   ,
   "1"  : BF(self.VVfx3d, "fMan")   ,
   "2"  : BF(self.VVfx3d, "iptv")   ,
   "3"  : BF(self.VVfx3d, "movie")   ,
   "4"  : BF(self.VVfx3d, "chan")   ,
   "5"  : BF(self.VVfx3d, "picon")   ,
   "6"  : BF(self.VVfx3d, "epg")   ,
   "7"  : BF(self.VVfx3d, "term")   ,
   "8"  : BF(self.VVfx3d, "soft")   ,
   "9"  : BF(self.VVfx3d, "plug")   ,
   "last" : BF(self.VVfx3d, "bakup")   ,
   "next" : BF(self.VVfx3d, "date")   ,
  })
  self.onShown.append(self.VVoCo0)
  self.onClose.append(self.onExit)
  global VVh0o2, VVks1Y
  VVh0o2 = VVks1Y = False
 def VVu0DR(self):
  self.VVfx3d(self["myMenu"].l.getCurrentSelection()[1])
 def VVfx3d(self, item):
  if item is not None:
   for ndx, param in enumerate(self["myMenu"].list):
    if len(param) > 1 and param[1] == item:
     self["myMenu"].moveToIndex(ndx)
     break
   global VVtXrR
   VVtXrR = self["myMenu"].l.getCurrentSelection()[0].strip()
   if   item == "myTest" : self.VVcfQJ()
   elif item == "fMan"  : self.session.open(CCr5c7)
   elif item == "iptv"  : self.session.open(CCCu2Z)
   elif item == "movie" : FFG53m(self, BF(CCeTYo.VVLlqm, self))
   elif item == "chan"  : self.session.open(CCcecd)
   elif item == "picon" : self.VVkgEm()
   elif item == "epg"  : self.session.open(CC2gVv)
   elif item == "term"  : self.session.open(CCEQiY)
   elif item == "soft"  : self.session.open(CCjquA)
   elif item == "plug"  : self.session.open(CCVxIp)
   elif item == "bakup" : self.session.open(CC7weG)
   elif item == "date"  : self.session.open(CCP4yf)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FFCoOh(self["myMenu"])
  FFUSMR(self)
  FFnLuC(self)
  FF6aqB(self)
  VVJu6Y, VVgGkd, VVUvHH, VVFykX, VV1idp, oldMovieDownloadPath = FFaCeZ()
  if VVJu6Y or VVgGkd or VVUvHH or VVFykX or VV1idp or oldMovieDownloadPath:
   VVcOV6 = lambda path, subj: "%s:\n%s\n\n" % (subj, FF6TiS(path, VVnKNv)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVcOV6(VVJu6Y   , "Backup/Restore Path"    )
   txt += VVcOV6(VVgGkd  , "Created Package Files (IPK/DEB)" )
   txt += VVcOV6(VVUvHH  , "Download Packages (from feeds)" )
   txt += VVcOV6(VVFykX , "Exported Tables"     )
   txt += VVcOV6(VV1idp , "Exported PIcons"     )
   txt += VVcOV6(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFJRXg(self, txt, title="Settings Paths")
  self.VV9SYJ()
  if (EASY_MODE or VVxG5f or VVE7eu):
   FFo6oa(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFtMfC(self, "Welcome", 300)
  FFDxKA(self.VVu7Mq)
 def VVu7Mq(self):
  if CFG.checkForUpdateAtStartup.getValue():
   curVer, webVer, url, isHigher, err = CCAqEA.VVIIjd()
   if webVer and isHigher:
    self["myTitle"].setText("  %s (v%s available)" % (self.Title, webVer))
 def onExit(self):
  os.system(FFNxGN("rm /tmp/ajpanel*"))
  global VVh0o2, VVks1Y
  VVh0o2 = VVks1Y = False
 def VVptCl(self, digit):
  self.VVXHtd += str(digit)
  ln = len(self.VVXHtd)
  global VVh0o2
  if ln == 4:
   if self.VVXHtd == "0" * ln:
    VVh0o2 = True
    FFo6oa(self["myTitle"], "#11805040")
   else:
    self.VVXHtd = "x"
 def VVBVWt(self):
  self.VVXHtd += "t"
  if self.VVXHtd == "0" * 4 + "t" * 2:
   global VVks1Y
   VVks1Y = True
   FFo6oa(self["myTitle"], "#dd5588")
 def VVkgEm(self):
  found = False
  pPath = CC96Ar.VVwdi5()
  if pathExists(pPath):
   for fName, fType in CC96Ar.VVNp49(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CC96Ar)
  else:
   VVegP0 = []
   VVegP0.append(("PIcons Tools" , "CC96Ar" ))
   VVegP0.append(VVHMBI)
   VVegP0.append(CC96Ar.VVsACl())
   VVegP0.append(VVHMBI)
   VVegP0 += CC96Ar.VVBM0S()
   FFJcY1(self, self.VV5wZk, VVegP0=VVegP0)
 def VV5wZk(self, item=None):
  if item:
   if   item == "CC96Ar"   : self.session.open(CC96Ar)
   elif item == "VVXWEs"  : CC96Ar.VVXWEs(self)
   elif item == "VV23Du"  : CC96Ar.VV23Du(self)
   elif item == "findPiconBrokenSymLinks" : CC96Ar.VVIphI(self, True)
   elif item == "FindAllBrokenSymLinks" : CC96Ar.VVIphI(self, False)
 def VVEc2P(self):
  changeLogFile = VVeop3 + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FF5DO4(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FF6TiS("\n%s\n%s\n%s" % (VVtc24, line, VVtc24), VVBfw8, VVZ51O)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FF6TiS(line, VVsvZg, VVZ51O)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFJRXg(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVVsnC, PLUGIN_DESCRIPTION), VVwwGj=28, width=1600, height=1000)
 def VVhzzi(self):
  VVegP0 = []
  VVegP0.append(("Check Internet Connection" , "intr"))
  VVegP0.append(VVHMBI)
  VVegP0.append(("%s Requirements" % PLUGIN_NAME, "libr"))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Keys Help"     , "hlp" ))
  FFJcY1(self, self.VVPeHq, VVegP0=VVegP0, width=650, title="Options")
 def VVPeHq(self, item=None):
  if item:
   if   item == "intr" : self.session.open(CCqwei)
   elif item == "libr" : FFG53m(self, BF(self.VV22GD))
   elif item == "hlp" : FFHU3T(self, "_help_main", "Main Page (Keys Help)")
 def VVNjXH(self) : self.session.open(CCAqEA)
 def VVosD9(self) : self.session.open(CCl7xP)
 def VV7E6C(self):
  title = "Colors and Fonts"
  c1, c2, c3, c4 = VVSTv2, VVnKNv, VVpkep, VVPN93
  VVegP0 = []
  VVegP0.append((c1 + "Change Title Colors"   , "title"  ))
  VVegP0.append((c1 + "Change Menu Area Colors"  , "body"  ))
  VVegP0.append((c1 + "Change Menu Pointer Colors" , "cursor"  ))
  VVegP0.append((c1 + "Change Bottom Bar Colors" , "bar"   ))
  VVegP0.append((c2 + "Reset Colors"    , "resetColor" ))
  VVegP0.append(VVHMBI)
  VVegP0.append((c3 + "Change %s Font" % PLUGIN_NAME, "mainFont" ))
  VVegP0.append((c3 + "Change Termianl Font"   , "termFont" ))
  VVegP0.append(VVHMBI)
  VVegP0.append((c4 + "Change System Font"    , "sysFont"  ))
  FFJcY1(self, BF(self.VV0IjR, title), VVegP0=VVegP0, width=600, title=title)
 def VV0IjR(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VV0x2b()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVFu43, tDict, item), CCHuHv, defFG=fg, defBG=bg)
   elif item == "resetColor" : FFWBJu(self, self.VV2tgl, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVb4wr(VVdJ3x  )
   elif item == "termFont"  : self.VVb4wr(VVZtGY)
   elif item == "sysFont"  : self.VVb4wr(VVYN98  )
 def VV22GD(self):
  title = "%s requirements (for some features)" % PLUGIN_NAME
  VVzto2, pkgs = self.VVQCYU()
  VVdn6T = ("Install", BF(self.VVBFeP, title, pkgs)  , [])
  VVDB15  = ("Update Sys. Packages", self.VVWnrF , [])
  header  = ("Library", "State", "Usage" )
  widths  = (20   , 25  , 55  )
  VVsZoP = (LEFT  , CENTER , LEFT  )
  VVR0r4 = FFqiz1(self, None, title=title, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=28, width=1350, VVdn6T=VVdn6T, VVDB15=VVDB15, VVbSmQ="#00ffffaa", VVPDqC=1)
 def VVBFeP(self, Title, pkgs, VVR0r4, title, txt, colList):
  if "Not" in colList[1]:
   cbFnc = BF(self.VVLS9a, VVR0r4)
   item = colList[0]
   if   item == "requests" : CC6kXN.VVv4ri(self, cbFnc=cbFnc)
   elif item == "Imaging" : CCmMzJ.VV0T6t(self, Title, False, cbFnc=cbFnc)
   elif item == "ar"  : FFYyBc(self, FFZKBU(), VVhgup=cbFnc)
   elif item in pkgs  : FFYyBc(self, FF3XrD(item, item, item.capitalize()), VVhgup=cbFnc)
  else:
   FFtMfC(VVR0r4, "Already installed.", 700, isGrn=True)
 def VVWnrF(self, VVR0r4, title, txt, colList):
  CCVxIp.VVNwii(self)
 def VVLS9a(self, VVR0r4):
  VVzto2, pkgs = self.VVQCYU()
  VVR0r4.VVkf6n(VVzto2[VVR0r4.VVVZYd()])
 def VVQCYU(self):
  tDict = {}
  path = VVeop3 + "_sup_lib"
  if fileExists(path):
   for line in FF5DO4(path):
    lib, eq, txt = line.partition("=")
    tDict[lib] = txt
  def VVcOV6(lib, ok):
   txt = tDict.get(lib, "")
   if ok: return (lib, FF6TiS("Installed", VVUdsq), txt)
   else : return (lib, FF6TiS("Not installed", VVSGHr), txt)
  pkgs = ("xz", "zip", "unrar", "bzip2", "ffmpeg")
  VVzto2 = []
  VVzto2.append(VVcOV6("requests", CC6kXN.VVv4ri(self, install=False)))
  VVzto2.append(VVcOV6("Imaging" , CCmMzJ.VV0T6t(self, "", False, install=False)))
  VVzto2.append(VVcOV6("ar"   , os.system("if [[ \"$(ar -V 2> /dev/null | grep 'GNU ar')\" ]]; then exit 1; else exit 0; fi")))
  for item in pkgs: VVzto2.append(VVcOV6(item, FF63FC(item)))
  VVzto2.sort(key=lambda x: x[0].lower())
  return VVzto2, pkgs
 def VV8PrY(self):
  return VVAVra + "ajpanel_colors"
 def VV0x2b(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VV8PrY()
  if fileExists(p):
   txt = FFu1EI(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVFu43(self, tDict, item, fg, bg):
  if fg:
   self.VVx84u(item, fg)
   self.VVj7Xt(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVSNWU(tDict)
 def VVSNWU(self, tDict):
   p = self.VV8PrY()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVx84u(self, item, fg):
  if   item == "title" : FFD09G(self["myTitle"], fg)
  elif item == "body"  :
   FFD09G(self["myMenu"], fg)
   FFD09G(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   for item in ("myBar", "keyRed", "keyGreen", "keyYellow", "keyBlue"): FFD09G(self[item], fg)
 def VVj7Xt(self, item, bg):
  if   item == "title" : FFo6oa(self["myTitle"], bg)
  elif item == "body"  :
   FFo6oa(self["myMenu"], bg)
   FFo6oa(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFo6oa(self["myBar"], bg)
 def VV2tgl(self):
  os.system(FFNxGN("rm %s" % self.VV8PrY()))
  self.close()
 def VV9SYJ(self):
  tDict = self.VV0x2b()
  for item in ("title", "body", "cursor", "bar"):
   self.VVXKef(tDict, item)
 def VVXKef(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVx84u(name, fg)
  if bg: self.VVj7Xt(name, bg)
 def VVb4wr(self, which):
  if   which == VVdJ3x  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VVZtGY : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VVYN98  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CCQUFG.VVjEqN(self, "Change %s Font" % title, defFnt, rest, BF(self.VVKuie, which))
 def VVKuie(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VVdJ3x  : FFCfiF(CFG.fontPathMain, path)
   elif which == VVZtGY: FFCfiF(CFG.fontPathTerm, path)
   elif which == VVYN98  : FFCfiF(CFG.fontPathSys , path)
   err = Main_Menu.VVUjM1(which)
   if err          : FFnHzu(self, err, title=title)
   elif which == VVdJ3x   : self.close()
   elif which == VVZtGY  : FFtMfC(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VVYN98 and path: FFtMfC(self, "System font applied", 1500, isGrn=True)
   elif which == VVYN98   : FFWBJu(self, BF(Main_Menu.VVOAUy, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VVOAUy(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVUjM1(name):
  if   name == VVdJ3x : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VVZtGY: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VVYN98 : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FFAiXd()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VVYN98:
   nameLst = []
   for nm in FFAiXd():
    if not nm in (VVdJ3x, VVZtGY):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FF7ym2(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FFAiXd()
  else    : return "Could not add font"
 def VVcfQJ(self):
  CCM2Fd.VV8elw(self.session)
class CCmMzJ():
 VVcSqq  = "all"
 VV19PO = "vid"
 VVaJUc  = "osd"
 @staticmethod
 def VVswZg(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FF63FC("grab"):
    winShown = session.current_dialog.shown
    if k == CCmMzJ.VV19PO and winShown: session.current_dialog.hide()
    FFDxKA(BF(CCmMzJ.VV9aWe, title, session, k, winShown))
   else:
    FFM8cf(session, "No Grab command !", title=title)
 @staticmethod
 def VV9aWe(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CCmMzJ.VVaJUc:
   if not winShown:
    FFM8cf(session, "No Window to capture !", title=title)
    return
   if not CCmMzJ.VV0T6t(session, title, True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CCmMzJ.VVtYaV(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FFM8cf(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(session, isFromSession=True)
   chName = iSub(r"[^A-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FFxJSp(CFG.exportedPIconsPath.getValue()), fTitle, FFxsfY(), ext)
  res = os.system(FFBAbA("grab -q -s %s > '%s'" % (typ, path)))
  if k == CCmMzJ.VV19PO and winShown:
   session.current_dialog.show()
  elif k == CCmMzJ.VVaJUc:
   ok = CCmMzJ.VVJAr0(path, x, y, w, h)
   if not ok:
    FFO0bd(path)
    FFM8cf(session, "Error while cropping image file !", title=title)
    return
  if res == 0 and fileExists(path): session.open(BF(CCDdSC, title=path, VVQyig=path))
  else       : FFM8cf(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VV0T6t(SELF, title, isFromExternal, install=True, cbFnc=None):
  try:
   from PIL import Image
   return True
  except:
   if install:
    FFWBJu(SELF, BF(CCmMzJ.VV4HAd, SELF, isFromExternal, cbFnc=cbFnc), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VV4HAd(SELF, isFromExternal, cbFnc=None):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  if isFromExternal: fnc = BF(FF1jRo, VVhgup=cbFnc)
  else    : fnc = BF(FFYyBc , VVhgup=cbFnc)
  fnc(SELF, FFiwac(VVerzX, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VVtYaV(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-z0-9]" ,repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VVJAr0(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FFF92P()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FFXM7k(x , 0, scrW, 0, w)
     y  = FFXM7k(y , 0, scrH, 0, h)
     x1 = FFXM7k(x1, 0, scrW, 0, w)
     y1 = FFXM7k(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
 @staticmethod
 def VVav1t(path):
  size = FFREV4(path)
  sizeTxt = CCr5c7.VVJv7c(size) if size > -1 else ""
  try:
   from PIL import Image
   im = Image.open(path)
   form = im.format
   mode = im.mode
   resTxt = "%d x %d" % im.size
  except:
   resTxt = form = mode = ""
  return size, sizeTxt, resTxt, form, mode
class CCQUFG(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FFAJVu(VVtBbU, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FF6TiS(" (Requires GUI Restart)", VVPN93) if withRestart else ""
  VVegP0 = []
  for path in self.fontsList:
   VVegP0.append((os.path.splitext(os.path.basename(path))[0], path))
  VVegP0.sort(key=lambda x: x[0].lower())
  VVegP0.insert(0, VVHMBI)
  VVegP0.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VVegP0):
    if len(item) == 2 and item[1] == self.defFnt:
     VVegP0[ndx] = (VVUdsq + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVegP0[curIndex] = (VVUdsq + VVegP0[curIndex][0], VVegP0[curIndex][1])
  FFsw8F(self, VVegP0=VVegP0, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FFCoOh(self["myMenu"])
  FFUSMR(self)
  self["myMenu"].onSelectionChanged.append(self.VVdyzC)
  self["myBar"].setText(self.VVhyuI())
  self["myBar"].instance.setHAlign(1)
  self.VVdyzC()
 def VVu0DR(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVdyzC(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FF7ym2(path, fnt, isRepl=1)
  else:
   fnt = VVRvDu
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VVhyuI(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VVjEqN(SELF, title, defFnt, rest, VVuJdT):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FFT5mp(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VVuJdT, CCQUFG, title, fontsList, defFnt, rest)
  else  : FFnHzu(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CCAMw5(Screen):
 def __init__(self, session, path, VVegP0, title):
  self.skin, self.skinParam = FFAJVu(VVtBbU, 1700, 1000, 40, 40, 30, "#11001122", "#11002233", 30, menuLabel=50)
  self.session = session
  self.path  = path
  FFsw8F(self, VVegP0=VVegP0, title=title)
  self["myLabelFrm"] = Label()
  self["myLabelTit"] = Label("Result Sample")
  self["myLabelTxt"] = Label()
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVu0DR   ,
   "cancel" : self.cancel   ,
   "pageUp" : self.VVDgBr,
   "chanUp" : self.VVDgBr,
   "pageDown" : self.VVH5zb ,
   "chanDown" : self.VVH5zb ,
  }, -1)
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FFCoOh(self["myMenu"])
  FFUSMR(self)
  FFo6oa(self["myLabelFrm"], "#11110000")
  FFo6oa(self["myLabelTit"], "#11663322")
  FFo6oa(self["myLabelTxt"], "#11110000")
  self["myLabelTxt"].instance.setNoWrap(True)
  self["myMenu"].onSelectionChanged.append(self.VVC6QX)
  self.VVC6QX()
 def VVC6QX(self):
  if fileExists(self.path): txt = FFu1EI(self.path, maxSize=1000, encLst=[self["myMenu"].l.getCurrentSelection()[1]])
  else     : txt = "Review error !"
  self["myLabelTxt"].setText(txt.strip())
 def VVu0DR(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVDgBr(self) : self["myMenu"].moveToIndex(0)
 def VVH5zb(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCBlwj():
 @staticmethod
 def VVFyVU():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVii9V(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFqiz1(SELF, None, VVVC4T=lst, VVwwGj=30, VVPDqC=1)
 @staticmethod
 def VV2bQD(path, SELF=None):
  for enc in CCBlwj.VVFyVU():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFnHzu(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVy65L(SELF, path, cbFnc, defEnc="utf8", onlyWorkingEnc=True, title="Select Encoding"):
  FFtMfC(SELF)
  lst = CCBlwj.VVbtGR(path, onlyWorkingEnc=onlyWorkingEnc)
  if lst:
   VVegP0 = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if defEnc == enc:
     txt = FF6TiS(txt, VVUdsq)
    VVegP0.append((txt, enc))
   if onlyWorkingEnc: SELF.session.openWithCallback(cbFnc, CCAMw5, path, VVegP0, title)
   else    : FFJcY1(SELF, cbFnc, title=title, VVegP0=VVegP0, width=900, VVXbiY="#22220000", VVVy8H="#22220000")
  else:
   FFtMfC(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVbtGR(path, onlyWorkingEnc=True):
  encLst = []
  cPath = VVeop3 + "_sup_codecs"
  if fileExists(cPath):
   lines = FF5DO4(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCBlwj.VVFyVU())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if onlyWorkingEnc:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CCl7xP(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAJVu(VVtBbU, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVegP0 = []
  VVegP0.append(("Settings File"        , "SettingsFile"   ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Box Info"          , "VVH95d"    ))
  VVegP0.append(("Tuners Info"         , "VVPlEj"   ))
  VVegP0.append(("Python Version"        , "VVDk0y"   ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Screen Size"         , "ScreenSize"    ))
  VVegP0.append(("Language/Locale"        , "Locale"     ))
  VVegP0.append(("Processor"         , "Processor"    ))
  VVegP0.append(("Operating System"        , "OperatingSystem"   ))
  VVegP0.append(("Drivers"          , "drivers"     ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("System Users"         , "SystemUsers"    ))
  VVegP0.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVegP0.append(("Uptime"          , "Uptime"     ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Host Name"         , "HostName"    ))
  VVegP0.append(("MAC Address"         , "MACAddress"    ))
  VVegP0.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVegP0.append(("Network Status"        , "NetworkStatus"   ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Disk Usage"         , "VVVKRQ"    ))
  VVegP0.append(("Mount Points"         , "MountPoints"    ))
  VVegP0.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVegP0.append(("USB Devices"         , "USB_Devices"    ))
  VVegP0.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVegP0.append(("Directory Size"        , "DirectorySize"   ))
  VVegP0.append(("Memory"          , "Memory"     ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVegP0.append(("Running Processes"       , "RunningProcesses"  ))
  VVegP0.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFsw8F(self, VVegP0=VVegP0, title="Device Information")
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FFCoOh(self["myMenu"])
  FFUSMR(self)
 def VVu0DR(self):
  global VVtXrR
  VVtXrR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CC2K22)
   elif item == "VVH95d"    : self.VVH95d()
   elif item == "VVPlEj"   : self.VVPlEj()
   elif item == "VVDk0y"   : self.VVDk0y()
   elif item == "ScreenSize"    : FFJRXg(self, "Width\t: %s\nHeight\t: %s" % (FFF92P()[0], FFF92P()[1]))
   elif item == "Locale"     : CCBlwj.VVii9V(self)
   elif item == "Processor"    : self.VV1Vh0()
   elif item == "OperatingSystem"   : FFSCk3(self, "uname -a"        )
   elif item == "drivers"     : self.VVWstV()
   elif item == "SystemUsers"    : FFSCk3(self, "id"          )
   elif item == "LoggedInUsers"   : FFSCk3(self, "who -a"         )
   elif item == "Uptime"     : FFSCk3(self, "uptime"         )
   elif item == "HostName"     : FFSCk3(self, "hostname"        )
   elif item == "MACAddress"    : self.VVJRyT()
   elif item == "NetworkConfiguration"  : FFSCk3(self, "ifconfig %s %s" % (FFmjg3("HWaddr", VVlagI), FFmjg3("addr:", VVBfw8)))
   elif item == "NetworkStatus"   : FFSCk3(self, "netstat -tulpn"       )
   elif item == "VVVKRQ"    : self.VVVKRQ()
   elif item == "MountPoints"    : FFSCk3(self, "mount %s" % (FFmjg3(" on ", VVBfw8)))
   elif item == "FileSystemTable"   : FFSCk3(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFSCk3(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFSCk3(self, "blkid"         )
   elif item == "DirectorySize"   : FFSCk3(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VV9R3L="Reading size ...")
   elif item == "Memory"     : FFSCk3(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVEkVc()
   elif item == "RunningProcesses"   : FFSCk3(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFSCk3(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVt0K9()
   else         : self.close()
 def VVJRyT(self):
  res = FF5whR("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFJRXg(self, txt)
  else:
   FFSCk3(self, "ip link")
 def VV9x9T(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FF5Sgm(cmd)
  return lines
 def VVIC5W(self, lines, headerRepl, widths, VVsZoP):
  VVzto2 = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVzto2.append(parts)
  if VVzto2 and len(header) == len(widths):
   VVzto2.sort(key=lambda x: x[0].lower())
   FFqiz1(self, None, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=28, VVPDqC=1)
   return True
  else:
   return False
 def VVVKRQ(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FF5whR(cmd)
  if not "invalid option" in txt:
   lines  = self.VV9x9T(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVsZoP = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVIC5W(lines, headerRepl, widths, VVsZoP)
  else:
   cmd = "df -h"
   lines  = self.VV9x9T(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVsZoP = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVIC5W(lines, headerRepl, widths, VVsZoP)
  if not allOK:
   lines = FF5Sgm(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFhn59(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVUdsq:
     note = "\n%s" % FF6TiS("Green = Mounted Partitions", VVUdsq)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVBfw8
     elif line.endswith(mountList) : color = VVUdsq
     else       : color = VVsvZg
     txt += FF6TiS(line, color) + "\n"
    FFJRXg(self, txt + note)
   else:
    FFnHzu(self, "Not data from system !")
 def VVEkVc(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VV9x9T(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVsZoP = (LEFT , CENTER, LEFT )
  allOK = self.VVIC5W(lines, headerRepl, widths, VVsZoP)
  if not allOK:
   FFSCk3(self, cmd)
 def VVWstV(self):
  cmd = FFQz9o(VVXp23, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFSCk3(self, cmd)
  else : FFw6dW(self)
 def VV1Vh0(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFSCk3(self, cmd)
 def VVt0K9(self):
  cmd = FFQz9o(VVxe2n, "| grep secondstage")
  if cmd : FFSCk3(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFw6dW(self)
 def VVH95d(self):
  c = VVUdsq
  VVVC4T = []
  VVVC4T.append((FF6TiS("Box Type"  , c), FF6TiS(self.VVGHtW("boxtype").upper(), c)))
  VVVC4T.append((FF6TiS("Board Version", c), FF6TiS(self.VVGHtW("board_revision") , c)))
  VVVC4T.append((FF6TiS("Chipset"  , c), FF6TiS(self.VVGHtW("chipset")  , c)))
  VVVC4T.append((FF6TiS("S/N"   , c), FF6TiS(self.VVGHtW("sn")    , c)))
  VVVC4T.append((FF6TiS("Version"  , c), FF6TiS(self.VVGHtW("version")  , c)))
  VVqjr2   = []
  VVcugb = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVcugb = SystemInfo[key]
     else:
      VVqjr2.append((FF6TiS(str(key), VVOEUI), FF6TiS(str(SystemInfo[key]), VVOEUI)))
  except:
   pass
  if VVcugb:
   VVPHh2 = self.VVAaF5(VVcugb)
   if VVPHh2:
    VVPHh2.sort(key=lambda x: x[0].lower())
    VVVC4T += VVPHh2
  if VVqjr2:
   VVqjr2.sort(key=lambda x: x[0].lower())
   VVVC4T += VVqjr2
  if VVVC4T:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFqiz1(self, None, header=header, VVVC4T=VVVC4T, VVx2iV=widths, VVwwGj=28, VVPDqC=1)
  else:
   FFJRXg(self, "Could not read info!")
 def VVGHtW(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FF5DO4(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVAaF5(self, mbDict):
  try:
   mbList = list(mbDict)
   VVVC4T = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVVC4T.append((FF6TiS(subject, VVBfw8), FF6TiS(value, VVBfw8)))
  except:
   pass
  return VVVC4T
 def VVPlEj(self):
  txt = self.VV4hRO("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VV4hRO("/proc/bus/nim_sockets")
  if not txt: txt = self.VVphfa()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFJRXg(self, txt)
 def VVphfa(self):
  txt = ""
  VVcOV6 = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVcOV6("Slot Name" , slot.getSlotName())
     txt += FF6TiS(slotName, VVBfw8)
     txt += VVcOV6("Description"  , slot.getFullDescription())
     txt += VVcOV6("Frontend ID"  , slot.frontend_id)
     txt += VVcOV6("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VV4hRO(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FF5DO4(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FF6TiS(line, VVBfw8)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVDk0y(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFJRXg(self, txt)
 @staticmethod
 def VVQTGB():
  def VVcOV6(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VVcOV6(v,0), "/etc/issue.net": VVcOV6(v,1), "/etc/image-version": VVcOV6(v,2)}
  for p1, d in v.items():
   img = CCl7xP.VVfxla(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VVcOV6(v,0), p + "Plugins/": VVcOV6(v,1), VVvMcE: VVcOV6(v,2), VVZvBa: VVcOV6(v,3)}
  for p1, d in v.items():
   img = CCl7xP.VVymKp(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VVfxla(path, d):
  if fileExists(path):
   txt = FFu1EI(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVymKp(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CC2K22(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAJVu(VVtBbU, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVegP0 = []
  VVegP0.append(("Settings (All)"   , "Settings_All"   ))
  VVegP0.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVegP0.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVegP0.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVegP0.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVegP0.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVegP0.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VVks1Y:
   VVegP0.append(VVHMBI)
   VVegP0.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVegP0.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FFsw8F(self, VVegP0=VVegP0)
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FFCoOh(self["myMenu"])
  FFUSMR(self)
 def VVu0DR(self):
  global VVtXrR
  VVtXrR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %ssettings" % VVMOat
   grep = " | grep "
   if   item == "Settings_All"    : FFSCk3(self, cmd                )
   elif item == "Settings_HotKeys"   : FFSCk3(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_ajp"    : FFSCk3(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME     )
   elif item == "Settings_FHDG_17"   : FFSCk3(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFSCk3(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFSCk3(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFSCk3(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFSCk3(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFSCk3(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CCjquA(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAJVu(VVtBbU, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VV8FEI, VV1y8R, VVjAzW, camCommand = CCjquA.VVD0gF()
  self.VV1y8R = VV1y8R
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VV1y8R:
   c = VVSTv2 if VVjAzW else VVJCMd
   if   "oscam" in VV1y8R : camName, oC = "OSCam", c
   elif "ncam"  in VV1y8R : camName, nC = "NCam" , c
  VVegP0 = []
  VVegP0.append(("OSCam Files" , "OSCamFiles"  ))
  VVegP0.append(("NCam Files" , "NCamFiles"  ))
  VVegP0.append(("CCcam Files" , "CCcamFiles"  ))
  VVegP0.append(VVHMBI)
  VVegP0.append((VVpkep + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VVhoSY" ))
  VVegP0.append(VVHMBI)
  VVegP0.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVegP0.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVegP0.append(VVHMBI)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  if VV1y8R: VVegP0.append((c + txt  , "camInfo" ))
  else  : VVegP0.append((txt  ,    ))
  VVegP0.append(VVHMBI)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VV1y8R:
   for item in camLst: VVegP0.append(item)
  else:
   for item in camLst: VVegP0.append((item[0], ))
  FFsw8F(self, VVegP0=VVegP0)
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FFCoOh(self["myMenu"])
  FFUSMR(self)
 def VVu0DR(self):
  global VVtXrR
  VVtXrR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCp2GH, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCp2GH, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCp2GH, "cccam"))
   elif item == "VVhoSY" : self.VVhoSY()
   elif item == "OSCamReaders"  : self.VVIeRB("os")
   elif item == "NSCamReaders"  : self.VVIeRB("n")
   elif item == "camInfo"   : FFWD2L(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CCjquA.VVsk7g(self.session, CC5Y0m.VVg08W)
   elif item == "camLiveReaders" : CCjquA.VVsk7g(self.session, CC5Y0m.VVq4pW)
   elif item == "camLiveLog"  : CCjquA.VVsk7g(self.session, CC5Y0m.VV7aAl)
   else       : self.close()
 def VVhoSY(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVAVra, FFxsfY())
  if fileExists(path):
   lines = FF5DO4("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VVcOV6 = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VVcOV6("label"    , "CCcam-Line-%d" % ndx))
      f.write(VVcOV6("description"  , "CCcam-Line-%d" % ndx))
      f.write(VVcOV6("protocol"   , "cccam"))
      f.write(VVcOV6("device"    , "%s,%s" % (host, port)))
      f.write(VVcOV6("user"    , User))
      f.write(VVcOV6("password"   , Pass))
      f.write(VVcOV6("fallback"   , "1"))
      f.write(VVcOV6("group"    , "64"))
      f.write(VVcOV6("cccversion"   , "2.3.2"))
      f.write(VVcOV6("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FFcZi2(self, "Output = %d Reader%s in:\n\n%s" % (tot, FFJHIK(tot), outFile))
   else:
    FFtMfC(self, "No valid CCcam lines", 1500)
  else:
   FFtMfC(self, "%s not found" % path, 1500)
 def VVIeRB(self, camPrefix):
  VVzto2 = self.VVUqzy(camPrefix)
  if VVzto2:
   VVzto2.sort(key=lambda x: int(x[0]))
   if self.VV1y8R and self.VV1y8R.startswith(camPrefix):
    VVdn6T = ("Toggle State", self.VVtBM9, [camPrefix], "Changing State ...")
   else:
    VVdn6T = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVsZoP  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFqiz1(self, None, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VVdn6T=VVdn6T, VVSwEr=True)
 def VVUqzy(self, camPrefix):
  readersFile = self.VV8FEI + camPrefix + "cam.server"
  VVzto2 = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FF5DO4(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVzto2.append((str(len(VVzto2) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVzto2:
    FFnHzu(self, "No readers found !")
  else:
   FFlkXm(self, readersFile)
  return VVzto2
 def VVtBM9(self, VVR0r4, camPrefix):
  confFile  = "%s%scam.conf" % (self.VV8FEI, camPrefix)
  readerState  = VVR0r4.VV5xX4(1)
  readerLabel  = VVR0r4.VV5xX4(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCjquA.VVVjTN(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVR0r4.VVRZ9B()
    FFnHzu(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVzto2 = self.VVUqzy(camPrefix)
   if VVzto2:
    VVR0r4.VVwzoo(VVzto2)
  else:
   VVR0r4.VVRZ9B()
 @staticmethod
 def VVVjTN(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FF5DO4(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFnHzu(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFnHzu(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFlkXm(SELF, confFile)
   return None
  if not iRequest:
   FFnHzu(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CCjquA.VVqMK4(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FFnHzu(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VVqMK4(SELF):
  if iElem:
   return True
  else:
   FFnHzu(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVsk7g(session, VV0aj2):
  VV8FEI, VV1y8R, VVjAzW, camCommand = CCjquA.VVD0gF()
  if VV1y8R:
   runLog = False
   if   VV0aj2 == CC5Y0m.VVg08W : runLog = True
   elif VV0aj2 == CC5Y0m.VVq4pW : runLog = True
   elif not VVjAzW          : FFM8cf(session, message="SoftCam not started yet!")
   elif fileExists(VVjAzW)        : runLog = True
   else             : FFM8cf(session, message="File not found !\n\n%s" % VVjAzW)
   if runLog:
    session.open(BF(CC5Y0m, VV8FEI=VV8FEI, VV1y8R=VV1y8R, VVjAzW=VVjAzW, VV0aj2=VV0aj2))
  else:
   FFM8cf(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VVD0gF():
  VV8FEI = "/etc/tuxbox/config/"
  VV1y8R = None
  VVjAzW  = None
  camCommand = FFN7zW("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VV1y8R = "oscam"
   elif camCmd.startswith("ncam") : VV1y8R = "ncam"
  if VV1y8R:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFu1EI(path), IGNORECASE)
     if span:
      VV8FEI = FFxJSp(span.group(1))
      break
   else:
    path = FFN7zW(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FFxJSp(path)
    if pathExists(path):
     VV8FEI = path
   tFile = FFxJSp(VV8FEI) + VV1y8R + ".conf"
   tFile = FFN7zW("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVjAzW = tFile
  return VV8FEI, VV1y8R, VVjAzW, camCommand
class CCp2GH(Screen):
 def __init__(self, VVWn99, session, args=0):
  self.skin, self.skinParam = FFAJVu(VVtBbU, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VV8FEI, VV1y8R, VVjAzW, camCommand = CCjquA.VVD0gF()
  if   VVWn99 == "ncam" : self.prefix = "n"
  elif VVWn99 == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVegP0 = []
  if self.prefix == "":
   VVegP0.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVegP0.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVegP0.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVegP0.append(("constant.cw"         , "x_constant_cw" ))
   VVegP0.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVegP0.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVegP0.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVegP0.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVegP0.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVegP0.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVegP0.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVegP0.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVegP0.append(VVHMBI)
   VVegP0.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVegP0.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVegP0.append(VVHMBI)
   VVegP0.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVegP0.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVegP0.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFsw8F(self, VVegP0=VVegP0)
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FFCoOh(self["myMenu"])
  FFUSMR(self)
 def VVu0DR(self):
  global VVtXrR
  VVtXrR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FF1QId(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FF1QId(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FF1QId(self, self.VV8FEI + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FF1QId(self, self.VV8FEI + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVz6Gp("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVz6Gp("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVz6Gp("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVz6Gp("cam.provid"        )
   elif item == "x_cam_server"  : self.VVz6Gp("cam.server"        )
   elif item == "x_cam_services" : self.VVz6Gp("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVz6Gp("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVz6Gp("cam.user"        )
   elif item == "x_VVtc24"   : pass
   elif item == "x_SoftCam_Key" : self.VVVIPt()
   elif item == "x_CCcam_cfg"  : FF1QId(self, self.VV8FEI + "CCcam.cfg"    )
   elif item == "x_VVtc24"   : pass
   elif item == "x_cam_log"  : FF1QId(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FF1QId(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FF1QId(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVz6Gp(self, fileName):
  FF1QId(self, self.VV8FEI + self.prefix + fileName)
 def VVVIPt(self):
  path = self.VV8FEI + "SoftCam.Key"
  if fileExists(path) : FF1QId(self, path)
  else    : FF1QId(self, path.replace(".Key", ".key"))
class CC5Y0m(Screen):
 VVg08W  = 0
 VVq4pW = 1
 VV7aAl = 2
 def __init__(self, session, VV8FEI="", VV1y8R="", VVjAzW="", VV0aj2=VVg08W):
  self.skin, self.skinParam = FFAJVu(VVinJE, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVjAzW   = VVjAzW
  self.VV0aj2  = VV0aj2
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VV8FEI + VV1y8R + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VV1y8R : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VV8FEI, self.camPrefix)
  if self.VV0aj2 == self.VVg08W:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VV0aj2 == self.VVq4pW:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFsw8F(self, self.Title, addScrollLabel=True)
  FF154z(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVKTbJ
  self.onShown.append(self.VVoCo0)
  self.onClose.append(self.onExit)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  self["myLabel"].VV8dj1(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFnLuC(self)
  self.VVKTbJ()
 def onExit(self):
  self.timer.stop()
 def VV4ujc(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVW41z)
  except:
   self.timer.callback.append(self.VVW41z)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFtMfC(self, "Started", 1000)
 def VVC0Tq(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVW41z)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFtMfC(self, "Stopped", 1000)
 def VVKTbJ(self):
  if self.timerRunning:
   self.VVC0Tq()
  else:
   self.VV4ujc()
   if self.VV0aj2 == self.VVg08W or self.VV0aj2 == self.VVq4pW:
    if self.VV0aj2 == self.VVg08W : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCjquA.VVVjTN(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFDxKA(self.VVkp69)
    else:
     self.close()
   else:
    self.VVuUj3()
 def VVW41z(self):
  if self.timerRunning:
   if   self.VV0aj2 == self.VVg08W : self.VVoFdU()
   elif self.VV0aj2 == self.VVq4pW : self.VVoFdU()
   else            : self.VVuUj3()
 def VVuUj3(self):
  if fileExists(self.VVjAzW):
   fTime = FFrOxn(os.path.getmtime(self.VVjAzW))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVnKJ9(), VVwZYa=VVC4tc)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVjAzW)
 def VVkp69(self):
  self.VVoFdU()
 def VVoFdU(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FF6TiS("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVsIVN))
   self.camWebIfErrorFound = True
   self.VVC0Tq()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VV0aj2 == self.VVg08W : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FF6TiS("Error while parsing data elements !\n\nError = %s" % str(e), VVSGHr)
   self.camWebIfErrorFound = True
   self.VVC0Tq()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VViMBD(root)
  self["myLabel"].setText(txt, VVwZYa=VVC4tc)
  self["myBar"].setText("Last Update : %s" % FF9ucJ())
 def VViMBD(self, rootElement):
  def VVcOV6(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VV0aj2 == self.VVg08W:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FF6TiS(status, VVUdsq)
    else          : status = FF6TiS(status, VVSGHr)
    txt += VVtc24 + "\n"
    txt += VVcOV6("Name"  , name)
    txt += VVcOV6("Description" , desc)
    txt += VVcOV6("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVcOV6("Protocol" , protocol)
    txt += VVcOV6("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FF6TiS("Yes", VVUdsq)
    else    : enabTxt = FF6TiS("No", VVSGHr)
    txt += VVtc24 + "\n"
    txt += VVcOV6("Label"  , label)
    txt += VVcOV6("Protocol" , protocol)
    txt += VVcOV6("Enabled" , enabTxt)
  return txt
 def VVnKJ9(self):
  lines = FF5Sgm("tail -n %d %s" % (100, self.VVjAzW))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VVPN93 + line[:19] + VVsvZg + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVoRk2 + "WebIf" + VVsvZg)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VVOEUI + h1 + h2 + VVsvZg + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VVUdsq + span.group(2) + VVpkep + span.group(3) + VVsvZg + span.group(4)
    line = self.VVmq74(line, VVpkep, ("(webif)", ))
    line = self.VVmq74(line, VVpkep, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VVmq74(line, VVUdsq, ("OSCam", "NCam", "log switched"))
    line = self.VVmq74(line, VVnKNv, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVBfw8 + line[ndx + 3:] + VVsvZg
   elif line.startswith("----") or ">>" in line:
    line = FF6TiS(line, VVZ51O)
   txt += line + "\n"
  return txt
 def VVmq74(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVsvZg + t3
  return line
class CC7weG(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAJVu(VVtBbU, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVegP0 = []
  VVegP0.append(("Backup Channels"    , "VV8nwt"   ))
  VVegP0.append(("Restore Channels"    , "Restore_Channels"  ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Backup SoftCAM Files"   , "VVkFjD" ))
  VVegP0.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVegP0.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVegP0.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Backup Network Settings"  , "VVaXF0"   ))
  VVegP0.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVks1Y:
   VVegP0.append(VVHMBI)
   VVegP0.append((VVsIVN + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VVI322"   ))
   VVegP0.append((VVUdsq + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVZ1EB) , "createMyIpk"   ))
   VVegP0.append((VVUdsq + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVZ1EB) , "createMyDeb"   ))
   VVegP0.append((VVOEUI + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVegP0.append((VVOEUI + "Decode %s Crash Report"   % PLUGIN_NAME     , "VVdQQ2" ))
  FFsw8F(self, VVegP0=VVegP0)
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FFCoOh(self["myMenu"])
  FFUSMR(self)
 def VVu0DR(self):
  global VVtXrR
  VVtXrR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV8nwt"    : self.VV8nwt()
   elif item == "Restore_Channels"    : self.VVnS2Q("channels_backup*.tar.gz", self.VVJk4C, isChan=True)
   elif item == "VVkFjD"   : self.VVkFjD()
   elif item == "Restore_SoftCAM_Files"  : self.VVnS2Q("softcam_backup*.tar.gz", self.VVlZHX)
   elif item == "Backup_TunerDiSEqC"   : self.VVO6xh("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVnS2Q("tuner_backup*.backup", BF(self.VV9jk9, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVO6xh("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVnS2Q("hotkey_*backup*.backup", BF(self.VV9jk9, "misc"))
   elif item == "VVaXF0"    : self.VVaXF0()
   elif item == "Restore_Network"    : self.VVnS2Q("network_backup*.tar.gz", self.VVXCIO)
   elif item == "VVI322"     : FFWBJu(self, BF(FFG53m, self, BF(CC7weG.VVI322, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VV2uK8(False)
   elif item == "createMyDeb"     : self.VV2uK8(True)
   elif item == "createMyTar"     : self.VVX7rS()
   elif item == "VVdQQ2"   : self.VVdQQ2()
 @staticmethod
 def VVI322(SELF):
  OBF_Path = VVcLQT + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVcLQT, VVVsnC, VVZ1EB)
   if err : FFnHzu(SELF, err)
   else : FFJRXg(SELF, txt)
  else:
   FFlkXm(SELF, OBF_Path)
 def VV2uK8(self, VVMRua):
  OBF_Path = VVcLQT + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFnHzu(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVcLQT)
  os.system("mv -f %s %s" % (VVcLQT + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVcLQT + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVcLQT + "plugin.py"))
  self.session.openWithCallback(self.VVqmDL, BF(CCfSCG, path=VVcLQT, VVMRua=VVMRua))
 def VVqmDL(self):
  os.system("mv -f %s %s" % (VVcLQT + "OBF/main.py"  , VVcLQT))
  os.system("mv -f %s %s" % (VVcLQT + "OBF/plugin.py" , VVcLQT))
 def VVdQQ2(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFnHzu(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFnHzu(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVpzDP("%s*.list" % path)
  if err:
   FFlkXm(self, path + "*.list")
   return
  srcF, err = self.VVpzDP("%s*main_final.py" % path)
  if err:
   FFlkXm(self, path + "*.final.py")
   return
  VVVC4T = []
  for f in files:
   f = os.path.basename(f)
   VVVC4T.append((f, f))
  FFJcY1(self, BF(self.VVQ8wJ, path, codF, srcF), VVegP0=VVVC4T)
 def VVQ8wJ(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFlkXm(self, logF)
   else     : FFG53m(self, BF(self.VVkpIR, logF, codF, srcF))
 def VVkpIR(self, logF, codF, srcF):
  lst  = []
  lines = FF5DO4(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFnHzu(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VV6M9q(lst, logF, newLogF)
  totSrc  = self.VV6M9q(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFJRXg(self, txt)
 def VVpzDP(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VV6M9q(self, lst, f1, f2):
  txt = FFu1EI(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVX7rS(self):
  VVVC4T = []
  VVVC4T.append("%s%s" % (VVcLQT, "*.py"))
  VVVC4T.append("%s%s" % (VVcLQT, "*.png"))
  VVVC4T.append("%s%s" % (VVcLQT, "*.xml"))
  VVVC4T.append("%s"  % (VVeop3))
  FF5ja7(self, VVVC4T, "%s_%s" % (PLUGIN_NAME, VVVsnC), addTimeStamp=False)
 def VV8nwt(self):
  path1 = VVMOat
  path2 = "/etc/tuxbox/"
  VVVC4T = []
  VVVC4T.append("%s%s" % (path1, "*.tv"))
  VVVC4T.append("%s%s" % (path1, "*.radio"))
  VVVC4T.append("%s%s" % (path1, "*list"))
  VVVC4T.append("%s%s" % (path1, "lamedb*"))
  VVVC4T.append("%s%s" % (path2, "*.xml"))
  FF5ja7(self, VVVC4T, self.VVshuR("channels_backup"), addTimeStamp=True)
 def VVkFjD(self):
  VVVC4T = []
  VVVC4T.append("/etc/tuxbox/config/")
  VVVC4T.append("/usr/keys/")
  VVVC4T.append("/usr/scam/")
  VVVC4T.append("/etc/CCcam.cfg")
  FF5ja7(self, VVVC4T, self.VVshuR("softcam_backup"), addTimeStamp=True)
 def VVaXF0(self):
  VVVC4T = []
  VVVC4T.append("/etc/hostname")
  VVVC4T.append("/etc/default_gw")
  VVVC4T.append("/etc/resolv.conf")
  VVVC4T.append("/etc/wpa_supplicant*.conf")
  VVVC4T.append("/etc/network/interfaces")
  VVVC4T.append("%snameserversdns.conf" % VVMOat)
  FF5ja7(self, VVVC4T, self.VVshuR("network_backup"), addTimeStamp=True)
 def VVshuR(self, fName):
  img = CCl7xP.VVQTGB()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVJk4C(self, fileName=None):
  if fileName:
   FFWBJu(self, BF(FFG53m, self, BF(self.VV2620, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VV2620(self, fileName):
  path = "%s%s" % (VVAVra, fileName)
  if fileExists(path):
   if CCr5c7.VVlrmK(path):
    VVnpEv , VVPkZu = CCcecd.VVq1kN()
    VVwpQl, VV0njx = CCcecd.VVu25s()
    cmd  = FFNxGN("cd %s" % VVMOat) + ";"
    cmd += FFNxGN("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VVPkZu, VV0njx))+ ";"
    cmd += "tar -xzf '%s' -C /" % path
    res = os.system(cmd)
    FFmB3r()
    if res == 0 : FFcZi2(self, "Channels Restored.")
    else  : FFnHzu(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FFnHzu(self, "Invalid tar file:\n\n%s" % path)
  else:
   FFlkXm(self, path)
 def VVlZHX(self, fileName=None):
  if fileName:
   FFWBJu(self, BF(self.VVH0iw, fileName), "Overwrite SoftCAM files ?")
 def VVH0iw(self, fileName):
  fileName = "%s%s" % (VVAVra, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVtc24
   note = "You may need to restart your SoftCAM."
   FFvkVo(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFmjg3(note, VVBfw8), sep))
  else:
   FFlkXm(self, fileName)
 def VVXCIO(self, fileName=None):
  if fileName:
   FFWBJu(self, BF(self.VVHj73, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVHj73(self, fileName):
  fileName = "%s%s" % (VVAVra, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFYyBc(self,  cmd)
  else:
   FFlkXm(self, fileName)
 def VVnS2Q(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFyqg5()
  if pathExists(VVAVra):
   myFiles = FFT5mp(VVAVra, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVVC4T = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVVC4T.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VVzqGT = ("Sat. List", self.VVkiGv)
    elif isChan and iTar: VVzqGT = ("Bouquets Importer", CChuYY.VVx0kH)
    else    : VVzqGT = None
    FFJcY1(self, callBackFunction, title=title, width=1200, VVegP0=VVVC4T, VVzqGT=VVzqGT, yellowBasePath=VVAVra)
   else:
    FFnHzu(self, "No files found in:\n\n%s" % VVAVra, title)
  else:
   FFnHzu(self, "Path not found:\n\n%s" % VVAVra, title)
 def VVO6xh(self, filePrefix, wordsFilter):
  settingFile = "%ssettings" % VVMOat
  tCons = CCXMpW()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VVVRSI, filePrefix))
 def VVVRSI(self, filePrefix, result, retval):
  title = FFyqg5()
  if pathExists(VVAVra):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFnHzu(self, "Cannot read settings file", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVAVra, filePrefix, self.VVshuR(""), FFxsfY())
    try:
     VVVC4T = str(result.strip()).split()
     if VVVC4T:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVVC4T:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVtc24, FF6TiS(fName, VVBfw8), VVtc24)
       FFJRXg(self, txt, title=title, VVwZYa=VVC4tc)
      else:
       FFnHzu(self, "File creation failed!", title)
     else:
      FFnHzu(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFNxGN("rm %s" % fName))
     FFnHzu(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFNxGN("rm %s" % fName))
     FFnHzu(self, "Error while writing file.")
  else:
   FFnHzu(self, "Path not found:\n\n%s" % VVAVra, title)
 def VV9jk9(self, mode, path=None):
  if path:
   path = "%s%s" % (VVAVra, path)
   if fileExists(path):
    lines = FF5DO4(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFWBJu(self, BF(self.VVgeWs, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFiIsE(self, path, title=FFyqg5())
   else:
    FFlkXm(self, path)
 def VVgeWs(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  isVTi = pathExists(VVvMcE + "VTIPanel")
  finalList = []
  for line in newList:
   if line.strip() and not line in finalList:
    if isVTi and ".dvbs." in line: pass
    else       : finalList.append(line)
  VVb1hE = []
  sFile = "/etc/enigma2/settings"
  tFile = "/tmp/ajpanel_tmp"
  VVb1hE.append("echo -e 'Reading current settings ...'")
  VVb1hE.append("cat %s | grep -v '%s' > %s" % (sFile, grepFilter, tFile))
  settingsLines = "echo -e '"
  for line in finalList:
   settingsLines += line
  settingsLines = settingsLines.strip()
  settingsLines += "' >> %s" % tFile
  VVb1hE.append("echo -e 'Preparing new settings ...'")
  VVb1hE.append(settingsLines)
  VVb1hE.append("echo -e 'Applying new settings ...'")
  VVb1hE.append("mv -f %s %s" % (tFile, sFile))
  FFq3ul(self, VVb1hE)
 def VVkiGv(self, VVsxjbObj, path):
  if not path:
   return
  path = VVAVra + path
  if not fileExists(path):
   FFlkXm(self, path)
   return
  txt = FFu1EI(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FF9TiB(item[1]))
   FFJRXg(self, txt, title="Satellites List")
  else:
   FFnHzu(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CChuYY():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VVx0kH(SELF, fName):
  bi = CChuYY(SELF)
  bi.instance = bi
  bi.VVKCZI(SELF, fName)
 @staticmethod
 def VVwGWc(SELF):
  bi = CChuYY(SELF)
  bi.instance = bi
  bi.VV3MaG()
 def VVKCZI(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVAVra + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FFG53m(waitObg, self.VVym5c, title="Reading bouquets ...")
  else      : self.VVWdUN(self.filePath)
 def VVbCAY(self, txt) : FFnHzu(self.SELF, txt, title=self.Title)
 def VVozbc(self, txt)  : FFtMfC(self, txt, 1500)
 def VVWdUN(self, path) : FFlkXm(self.SELF, path, title=self.Title)
 def VV3MaG(self):
  if pathExists(VVAVra):
   lst = FFT5mp(VVAVra, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VVoKQ4())
   if len(lst) > 0:
    VVegP0 = []
    for item in lst:
     item = os.path.basename(item)
     txt = FF6TiS(item, VVpkep) if item.endswith(".zip") else item
     VVegP0.append((txt, item))
    VVegP0.sort(key=lambda x: x[1].lower())
    OKBtnFnc = self.VV7ZOF
    FFJcY1(self.SELF, self.VVcXcG, minRows=3, title=self.Title, width=1200, VVegP0=VVegP0, OKBtnFnc=OKBtnFnc, yellowBasePath=VVAVra, VVXbiY="#22111111", VVVy8H="#22111111")
   else:
    self.VVbCAY("No valid backup files found in:\n\n%s" % VVAVra)
  else:
   self.VVbCAY("Backup Directory not found:\n\n%s" % VVAVra)
 def VV7ZOF(self, item=None):
  if item:
   menuInstance, txt, fName, ndx = item
   self.VVKCZI(menuInstance, fName)
 def VVcXcG(self, item=None):
  if not item and self.instance:
   del self.instance
 def VVoKQ4(self):
  files = FFT5mp(VVAVra, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VVym5c(self):
  lines, err = CChuYY.VVH4Fv(self.filePath, "bouquets.tv")
  if err:
   self.VVbCAY(err)
   return
  bTvSortLst  = self.VVr4vU(lines)
  lines, err = CChuYY.VVH4Fv(self.filePath, "bouquets.radio")
  if err:
   self.VVbCAY(err)
   return
  bRadSortLst = self.VVr4vU(lines)
  VVzto2 = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VVWln2(f, mode, len(VVzto2), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVzto2.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VVWln2(f, mode, len(VVzto2), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VVWln2(f, mode, len(VVzto2), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVzto2.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VVWln2(f, mode, len(VVzto2), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVzto2:
   VVzto2.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVzto2): VVzto2[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVzto2):
     if key == os.path.basename(row[9]):
      VVzto2 = VVzto2[:ndx+1] + lst + VVzto2[ndx+1:]
      break
   for ndx, item in enumerate(VVzto2): VVzto2[ndx][0] = str(ndx + 1)
   VVvi08 = "#11000600"
   VV91FP  = ("Show Services" , self.VV8IoX  , [], "Reading ..." )
   VVBSYf = (""    , self.VV4TdZ, [])
   VVljWo = ("Options"  , self.VVVsq9, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "S.Relay" , "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 36   , 7  , 7   , 7  , 7  , 7   , 7   , 7   , 8   ,  0.01 )
   VVsZoP  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER , CENTER ,  LEFT )
   FFqiz1(self.SELF, None, title=self.Title, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=24, VV91FP=VV91FP, VVBSYf=VVBSYf, VVljWo=VVljWo, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVXbiY=VVvi08, VVVy8H=VVvi08, VVvi08=VVvi08, VVbSmQ="#11ffffff", VVTrrJ="#00004455", VVcd71="#0a282828")
  else:
   self.VVbCAY("No valid bouquets in:\n\n%s" % self.filePath)
 def VVr4vU(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VV4TdZ(self, VVR0r4, title, txt, colList):
  FFJRXg(self.SELF, FF2AUs(txt), title=title)
 def VVVsq9(self, VVR0r4, title, txt, colList):
  mSel = CCeaGv(self.SELF, VVR0r4)
  if VVR0r4.VV9Jt5:
   totSel = VVR0r4.VVkGfp()
   if totSel: VVegP0 = [("Import %s Bouquet%s" % (FF6TiS(str(totSel), VVUdsq), FFJHIK(totSel)), "imp")]
   else  : VVegP0 = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FF6TiS(bName, VVUdsq)
   VVegP0 = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FFG53m, VVR0r4, BF(CChuYY.VVyRvb, self.SELF, VVR0r4, self.filePath))}
  mSel.VVxIpf(VVegP0, cbFncDict)
 def VV8IoX(self, VVR0r4, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CChuYY.VVH4Fv(self.filePath, "lamedb")
   if err:
    self.VVbCAY(err)
    return
   dbServLst = CCcecd.VVYm2F(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName = VVR0r4.VVVPDl()
   lines, err = CChuYY.VVH4Fv(self.filePath, os.path.basename(fName))
   if err:
    self.VVbCAY(err)
    return
   VVzto2 = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVzto2.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVzto2.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVzto2.append((span.group(1).strip() or "-", "Stream Relay" if FFabwQ(line) else "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVzto2.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVzto2.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CCcecd.VVMC5S(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVzto2.append((name.strip() or "-", FFkzUr(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVzto2):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CChuYY.VVH4Fv(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVzto2[ndx] = (bName, descr)
   if VVzto2:
    VVvi08 = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VVsZoP = (LEFT  , CENTER)
    FFqiz1(self.SELF, None, title="Services in : %s" % bName, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=28, VVXbiY=VVvi08, VVVy8H=VVvi08, VVvi08=VVvi08, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FFtMfC(VVR0r4, err, 1500)
  else : VVR0r4.VVRZ9B()
 def VVWln2(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totSRelay = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VVbCAY("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif FFabwQ(line)             : totSRelay += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VVCvCu(var):
   return str(var) if var else VVPYB5 + str(var)
  totItem = VVBfw8 + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VVsIVN   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVpkep, "Sub-B."
  else  : bColor, totBnb = ""      , VVCvCu(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VVCvCu(totDVB), VVCvCu(totIptv), VVCvCu(totSRelay), VVCvCu(totLoc), VVCvCu(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VVyRvb(SELF, VVR0r4, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVMOat + "bouquets.tv"
  radBouquetFile = VVMOat + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FFlkXm(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FFlkXm(SELF, radBouquetFile, title=title)
   return
  isMulti = VVR0r4.VV9Jt5
  if isMulti : rows = VVR0r4.VVFwt1()
  else  : rows = [VVR0r4.VVVPDl()]
  for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FFnHzu(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FF2AUs(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FF2AUs(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVMOat + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVMOat + newFile
    CChuYY.VVZlWu(archPath, fName, VVMOat, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   CCu3Fm.VV9EsP(tvBouquetFile)
   CCu3Fm.VV9EsP(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CChuYY.VVJA4e(SELF, archPath, bList)
   FFmB3r()
  txt  = FF6TiS("Added:\n", VVpkep)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FF6TiS("Imported to lamedab:\n", VVpkep)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FF6TiS("Missing from archived lamedb:\n", VVsIVN)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FFJRXg(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVJA4e(SELF, archPath, bList):
  VVnpEv, err = CCcecd.VVMV5K(SELF, VV6Oa0=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CCcecd.VVlQRe(VVnpEv, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FF5DO4(VVMOat + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CCcecd.VVMC5S(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CCcecd.VVutLW(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CChuYY.VVDPCv(archPath, dbName)
   CChuYY.VVZlWu(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CCcecd.VVlQRe(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CCcecd.VVlQRe(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CCcecd.VVlQRe(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CCcecd.VVlQRe(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFO0bd(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VVnpEv + ".tmp"
   lines   = FF5DO4(VVnpEv)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   os.system(FFNxGN("mv -f '%s' '%s'" % (tmpDbFile, VVnpEv)))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VVMaow(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VVDPCv(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVZlWu(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VVH4Fv(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CCVxIp(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAJVu(VVtBbU, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVegP0 = []
  VVegP0.append(("Plugins Browser List"       , "VVMnQv"   ))
  VVegP0.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVegP0.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Download/Install Packages (from image feeds)" , "downloadInstallPackages"  ))
  VVegP0.append(("Remove Packages (show all)"     , "VV5evasAll"   ))
  VVegP0.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Update Packages List from Feed"    , "VVNwii"   ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Packaging Tool"        , "VVqhiV"    ))
  VVegP0.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFsw8F(self, VVegP0=VVegP0)
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FFCoOh(self["myMenu"])
  FFUSMR(self)
 def VVu0DR(self):
  global VVtXrR
  VVtXrR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVMnQv"   : self.VVMnQv()
   elif item == "pluginsMenus"     : self.VV42Pt(0)
   elif item == "pluginsStartup"    : self.VV42Pt(1)
   elif item == "pluginsDirList"    : self.VV7cWK()
   elif item == "downloadInstallPackages"  : FFG53m(self, BF(self.VVvBDK, 0, ""))
   elif item == "VV5evasAll"   : FFG53m(self, BF(self.VVvBDK, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFG53m(self, BF(self.VVvBDK, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVNwii"   : CCVxIp.VVNwii(self)
   elif item == "VVqhiV"    : self.VVqhiV()
   elif item == "packagesFeeds"    : self.VVJatn()
   else          : self.close()
 def VV7cWK(self):
  extDirs  = FFdvPe(VVZvBa)
  sysDirs  = FFdvPe(VVvMcE)
  VVVC4T  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVVC4T.append((item, VVZvBa + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVVC4T.append((item, VVvMcE + item))
  if VVVC4T:
   VVVC4T.sort(key=lambda x: x[0].lower())
   VVljWo = ("Package Info.", self.VVKyeB, [])
   VVDB15 = ("Open in File Manager", BF(self.VVuWIO, 1), [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFqiz1(self, None, header=header, VVVC4T=VVVC4T, VVx2iV=widths, VVwwGj=28, VVljWo=VVljWo, VVDB15=VVDB15)
  else:
   FFnHzu(self, "Nothing found!")
 def VVKyeB(self, VVR0r4, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVZvBa) : loc = "extensions"
  elif path.startswith(VVvMcE) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVXSfZ(package)
  else:
   FFnHzu(self, "No info!")
 def VVJatn(self):
  pkg = FFdjjI()
  if pkg : FFSCk3(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFw6dW(self)
 def VVMnQv(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVcOV6(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVtc24 + "\n"
    txt += VVcOV6("Number"   , str(c))
    txt += VVcOV6("Name"   , FF6TiS(str(p.name), VVBfw8))
    txt += VVcOV6("Path"  , p.path  )
    txt += VVcOV6("Description" , p.description )
    txt += VVcOV6("Icon"  , p.iconstr  )
    txt += VVcOV6("Wakeup Fnc" , p.wakeupfnc )
    txt += VVcOV6("NeedsRestart", p.needsRestart)
    txt += VVcOV6("Internal" , p.internal )
    txt += VVcOV6("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFJRXg(self, txt)
 def VV42Pt(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVVC4T = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVVC4T.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVVC4T:
   VVVC4T.sort(key=lambda x: x[0].lower())
   VVDB15 = ("Open in File Manager", BF(self.VVuWIO, 4), [])
   header   = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths   = (19  , 25 , 20  , 27   , 9  )
   FFqiz1(self, None, title=title, header=header, VVVC4T=VVVC4T, VVx2iV=widths, VVwwGj=26, VVDB15=VVDB15)
  else:
   FFnHzu(self, "Nothing Found", title=title)
 def VVuWIO(self, pathColNum, VVR0r4, title, txt, colList):
  path = colList[pathColNum].strip()
  if pathExists(path) : self.session.open(CCr5c7, mode=CCr5c7.VViEDa, VV3Cmf=path)
  else    : FFtMfC(VVR0r4, "Path not found !", 1500)
 @staticmethod
 def VVNwii(SELF):
  cmd = FFQz9o(VVvVUt, "")
  if cmd : FFYyBc(SELF, cmd, checkNetAccess=True)
  else : FFw6dW(SELF)
 def VVqhiV(self):
  pkg = FFdjjI()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFcZi2(self, txt)
 def VVvBDK(self, mode, grep, VVR0r4=None, title=""):
  if   mode == 0: cmd = FFQz9o(VVxe2n    , grep)
  elif mode == 1: cmd = FFQz9o(VVXp23 , grep)
  elif mode == 2: cmd = FFQz9o(VVXp23 , grep)
  if not cmd:
   FFw6dW(self)
   return
  VVzto2 = FF5Sgm(cmd)
  if VVzto2:
   err = CCr5c7.VVlY6G(VVzto2, fromFind=False)
   if err:
    FFnHzu(self, err)
    return
  else:
   if VVR0r4: VVR0r4.VVRZ9B()
   FFnHzu(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVVC4T  = []
  for item in VVzto2:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVVC4T.append((name, package, version))
  if mode > 0:
   extensions = FF5Sgm("ls %s -l | grep '^d' | awk '{print $9}'" % VVZvBa)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVVC4T:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVVC4T.append((name, VVZvBa + item, "-"))
   systemPlugins = FF5Sgm("ls %s -l | grep '^d' | awk '{print $9}'" % VVvMcE)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVVC4T:
      if item.lower() == row[0].lower():
       break
     else:
      VVVC4T.append((item, VVvMcE + item, "-"))
  if not VVVC4T:
   FFnHzu(self, "No packages found!")
   return
  if VVR0r4:
   VVVC4T.sort(key=lambda x: x[0].lower())
   VVR0r4.VVwzoo(VVVC4T, title)
  else:
   widths = (20, 50, 30)
   VVdn6T = None
   VVDB15 = None
   if mode == 0:
    VVIqI1 = ("Install" , self.VVfDPh   , [])
    VVdn6T = ("Download" , self.VV678o   , [])
    VVDB15 = ("Filter"  , self.VVND2u , [])
   elif mode == 1:
    VVIqI1 = ("Uninstall", self.VV5eva, [])
   elif mode == 2:
    VVIqI1 = ("Uninstall", self.VV5eva, [])
    widths= (18, 57, 25)
   VVVC4T.sort(key=lambda x: x[0].lower())
   VVljWo = ("Package Info.", self.VVYI1V, [])
   header   = ("Name" ,"Package" , "Version" )
   FFqiz1(self, None, header=header, VVVC4T=VVVC4T, VVx2iV=widths, VVwwGj=28, VVIqI1=VVIqI1, VVdn6T=VVdn6T, VVljWo=VVljWo, VVDB15=VVDB15, VVwmtP=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVXbiY="#22110011", VVVy8H="#22191111", VVvi08="#22191111", VVTrrJ="#00003030", VVcd71="#00333333")
 def VVYI1V(self, VVR0r4, title, txt, colList):
  package = colList[1]
  self.VVXSfZ(package)
 def VVND2u(self, VVR0r4, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVegP0 = []
  VVegP0.append(("All Packages", "all"))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVegP0.append(VVHMBI)
  for word in words:
   VVegP0.append((word, word))
  FFJcY1(self, BF(self.VVRa1f, VVR0r4), VVegP0=VVegP0, title="Select Filter")
 def VVRa1f(self, VVR0r4, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFG53m(VVR0r4, BF(self.VVvBDK, 0, grep, VVR0r4, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VV5eva(self, VVR0r4, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVZvBa, VVvMcE)):
   FFWBJu(self, BF(self.VVPTIc, VVR0r4, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVegP0 = []
   VVegP0.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVegP0.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVegP0.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFJcY1(self, BF(self.VV3Uu9, VVR0r4, package), VVegP0=VVegP0)
 def VVPTIc(self, VVR0r4, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VV56tq)
  FFYyBc(self, cmd, VVhgup=BF(self.VVTfVS, VVR0r4))
 def VV3Uu9(self, VVR0r4, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVUSd3
   elif item == "remove_ForceRemove"  : cmdOpt = VVUCVW
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVM72P
   FFWBJu(self, BF(self.VVz23p, VVR0r4, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVz23p(self, VVR0r4, package, cmdOpt):
  self.lastSelectedRow = VVR0r4.VVVZYd()
  cmd = FFiwac(cmdOpt, package)
  if cmd : FFYyBc(self, cmd, VVhgup=BF(self.VVTfVS, VVR0r4))
  else : FFw6dW(self)
 def VVTfVS(self, VVR0r4):
  VVR0r4.cancel()
  FFrn02()
 def VVfDPh(self, VVR0r4, title, txt, colList):
  package  = colList[1]
  VVegP0 = []
  VVegP0.append(("Install Package"         , "install_CheckVersion" ))
  VVegP0.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVegP0.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VVegP0.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVegP0.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFJcY1(self, BF(self.VVUdNK, package), VVegP0=VVegP0)
 def VVUdNK(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVerzX
   elif item == "install_ForceReinstall" : cmdOpt = VVw4vm
   elif item == "install_ForceOverwrite" : cmdOpt = VVFhZO
   elif item == "install_ForceDowngrade" : cmdOpt = VVpj31
   elif item == "install_IgnoreDepends" : cmdOpt = VVjszN
   FFWBJu(self, BF(self.VVS7RB, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVS7RB(self, package, cmdOpt):
  cmd = FFiwac(cmdOpt, package)
  if cmd : FFYyBc(self, cmd, VVhgup=FFrn02, checkNetAccess=True)
  else : FFw6dW(self)
 def VV678o(self, VVR0r4, title, txt, colList):
  package  = colList[1]
  FFWBJu(self, BF(self.VVOXml, package), "Download Package ?\n\n%s" % package)
 def VVOXml(self, package):
  if FFpySX():
   cmd = FFiwac(VVcrY8, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFmjg3(success, VVUdsq))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFmjg3(fail, VVSGHr))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFYyBc(self, cmd, VVIUog=[VVSGHr, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFw6dW(self)
  else:
   FFnHzu(self, "No internet connection !")
 def VVXSfZ(self, package):
  infoCmd  = FFiwac(VViz0h, package)
  filesCmd = FFiwac(VV3b1m, package)
  listInstCmd = FFQz9o(VVXp23, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FF7nYK(VVBfw8)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFmjg3(notInst, VVsIVN))
   cmd += "else "
   cmd +=   FFBxX8("System Info", VVBfw8)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFBxX8("Related Files", VVBfw8)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFlo7E(self, cmd)
  else:
   FFw6dW(self)
class CCEwHg():
 def VVFwK4(self, isRef, onlyEpg=False):
  self.shareIsRef   = isRef
  self.onlyEpg   = onlyEpg
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VVmG5K()
 def VVmG5K(self):
  files = FFT5mp(VVAVra, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVegP0 = []
   for fil in files:
    VVegP0.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVXbiY, VVVy8H = "#22221133", "#22221133"
   else    : VVXbiY, VVVy8H = "#22003344", "#22002233"
   VVzqGT  = ("Add new File", self.VV8N7J)
   FFJcY1(self, self.VVyUjr, VVegP0=VVegP0, width=1100, VVzqGT=VVzqGT, yellowBasePath="", minRows=4, VVXbiY=VVXbiY, VVVy8H=VVVy8H)
  else:
   FFWBJu(self, self.VVHOEy, "No files found.\n\nCreate a new file ?")
 def VVHOEy(self):
  path = self.VVOxDw()
  if fileExists(path) : self.VVmG5K()
  else    : FFtMfC(self, "Cannot create file", 1500)
 def VV8N7J(self, menuInstance, path):
  path = self.VVOxDw()
  menuInstance.VVzxEM((os.path.basename(path), path), isSort=True)
 def VVOxDw(self):
  path = "%s%s%s.xml" % (VVAVra, self.shareFilePrefix, FFxsfY())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VVyUjr(self, path=None):
  if path:
   FFG53m(self, BF(self.VVDJbV, path))
 def VVDJbV(self, path):
  if not fileExists(path):
   FFlkXm(self, path)
   return
  elif not CCr5c7.VVKo2B(self, path, FFyqg5()):
   return
  else:
   self.shareFilePath = path
  if not CCjquA.VVqMK4(self):
   return
  tree = CCcecd.VVQD4i(self, self.shareFilePath)
  if not tree:
   return
  refLst = CCu3Fm.VVanvk()
  def VVcOV6(refCode):
   if   FFYvXi(refCode): return FF6TiS("DVB", VVSTv2)
   elif refCode in refLst     : return FF6TiS("IPTV", VVSTv2)
   else         : return ""
  VVzto2= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VVHx2W(ch)
   if ok:
    srcTxt = VVcOV6(srcRef)
    dstTxt = VVcOV6(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVzto2:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVzto2.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVzto2:
   if self.shareIsRef : VVXbiY, VVVy8H, optTxt = "#22221133", "#22221133", "Share Reference"
   else    : VVXbiY, VVVy8H, optTxt = "#1a003344", "#1a002233", "Copy EPG" if self.onlyEpg else "Copy EPG/PIcons"
   VVqfcE = (""    , BF(self.VVX5tt, dupl), [])
   VVBSYf = (""    , self.VV9khw    , [])
   VVIqI1 = ("Delete Entry" , self.VVC9rT   , [])
   VVdn6T = ("Add Entry"  , self.VVLVT0   , [])
   VVljWo = (optTxt   , self.VVmNZ1  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VVsZoP = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVR0r4 = FFqiz1(self, None, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=24, VVqfcE=VVqfcE, VVBSYf=VVBSYf, VVIqI1=VVIqI1, VVdn6T=VVdn6T, VVljWo=VVljWo, VVSwEr=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVXbiY=VVXbiY, VVVy8H=VVVy8H, VVvi08=VVVy8H, VVbSmQ="#00ffffaa", VVTrrJ="#0a000000")
  else:
   FFnHzu(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VVX5tt(self, dupl, VVR0r4, title, txt, colList):
  if dupl:
   VVR0r4.VVsu20("Skipped %d duplicate%s" % (dupl, FFJHIK(dupl)), 2000)
 def VV9khw(self, VVR0r4, title, txt, colList):
  def VVcOV6(key, val): return "%s\t: %s\n" % (key, val or FF6TiS("?", VVnKNv))
  Keys = VVR0r4.VVZqSH()
  Vals = VVR0r4.VVVPDl()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VVcOV6(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VVUdsq, VVnKNv
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FFJRXg(self, txt + txt1, title=title)
 def VVHx2W(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VVC9rT(self, VVR0r4, title, txt, colList):
  if VVR0r4.VVVZYd() == 0 and VVR0r4.VVsBGq() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FFWBJu(self, BF(self.VVkjuh, isLast, VVR0r4), ques)
 def VVkjuh(self, isLast, VVR0r4):
  if isLast:
   FFO0bd(self.shareFilePath)
   VVR0r4.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVR0r4.VVVPDl()
   if self.VVUebY(srcName, srcRef, dstName, dstRef):
    VVR0r4.VVWDEt()
    VVR0r4.VVOzcm()
    FFtMfC(VVR0r4, "Deleted", 500, isGrn=True)
   else:
    FFtMfC(VVR0r4, "Cannot delete from file", 2000)
 def VVLVT0(self, VVR0r4, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VVblyx(VVR0r4, isDvb=True)
  else    : self.VVVNsL(VVR0r4, "Source Channel", "#22003344", "#22002233")
 def VVVNsL(self, mainTableInst, title, VVXbiY, VVVy8H):
  FFJcY1(self, BF(self.VV5qjV, mainTableInst, title), VVegP0=[("DVB", "DVB"), ("IPTV / Stream Relay", "IPTV")], title=title + " Type", width=800, VVXbiY=VVXbiY, VVVy8H=VVVy8H)
 def VV5qjV(self, mainTableInst, title, item=None):
  if item:
   FFG53m(mainTableInst, BF(self.VV82kT, mainTableInst, title, item), clearMsg=False)
 def VV82kT(self, mainTableInst, title, item):
  FFtMfC(mainTableInst)
  if item == "DVB": self.VVblyx(mainTableInst, isDvb=True)
  else   : self.VVblyx(mainTableInst, isDvb=False)
 def VVSsZR(self, mainTableInst, chType, VVR0r4, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVR0r4.VVVZYd()
  if   chType == "DVB" : FFCfiF(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FFCfiF(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVtxRM()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FFnHzu(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VVQ6Sw(srcName, srcRef, dstName, dstRef):
      mainTableInst.VVkySl((str(mainTableInst.VVsBGq() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FFtMfC(mainTableInst, "Added", 500, isGrn=True)
     else:
      FFtMfC(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FFtMfC(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VVblyx(mainTableInst, isDvb=False)
   else    : FFDxKA(BF(self.VVVNsL, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVR0r4.cancel()
 def VVLhlN(self, item, VVR0r4, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVR0r4.VVwqjr(ndx)
 def VVblyx(self, VVR0r4, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VVSsZR, VVR0r4, typ)
  doneFnc = BF(self.VVLhlN, typ)
  if isDvb: CCEwHg.VVYuL3(VVR0r4 , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CCEwHg.VV5oIe(VVR0r4, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VVYuL3(SELF, title, okFnc, doneFnc=None):
  FFG53m(SELF, BF(CCEwHg.VVnAji, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVnAji(SELF, title, okFnc, doneFnc=None):
  VVzto2, err = CCcecd.VV4wpk(SELF, CCcecd.VVbljq)
  if VVzto2:
   color = "#0a000022"
   VVzto2.sort(key=lambda x: x[0].lower())
   VV91FP = ("Select" , okFnc, [])
   VVqfcE= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VVsZoP = (LEFT  , LEFT  , CENTER, LEFT    )
   FFqiz1(SELF, None, title=title, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VVXbiY=color, VVVy8H=color, VVvi08=color, VV91FP=VV91FP, VVqfcE=VVqfcE, lastFindConfigObj=CFG.lastFindServices)
  else:
   FFnHzu(SELF, "No DVB Services !")
 @staticmethod
 def VV5oIe(SELF, title, okFnc, doneFnc=None):
  FFG53m(SELF, BF(CCEwHg.VV5ScN, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VV5ScN(SELF, title, okFnc, doneFnc=None):
  VVzto2 = CCEwHg.VVTzb4()
  if VVzto2:
   color = "#0a112211"
   VVzto2.sort(key=lambda x: x[0].lower())
   VV91FP = ("Select" , okFnc, [])
   VVqfcE= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FFqiz1(SELF, None, title=title, header=header, VVVC4T=VVzto2, VVx2iV=widths, VVwwGj=26, VVXbiY=color, VVVy8H=color, VVvi08=color, VV91FP=VV91FP, VVqfcE=VVqfcE, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFnHzu(SELF, "No IPTV Services !")
 @staticmethod
 def VVTzb4():
  VVzto2 = []
  files  = CCCu2Z.VVfoZV()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFu1EI(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVztNS = span.group(1)
    else : VVztNS = ""
    VVztNS_lCase = VVztNS.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVzto2.append((chName, VVztNS, url, refCode))
  return VVzto2
 def VVQ6Sw(self, srcName, srcRef, dstName, dstRef):
  tree = CCcecd.VVQD4i(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VVLba7(tree, root)
  return True
 def VVUebY(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CCcecd.VVQD4i(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VVHx2W(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VVLba7(tree, root)
  return found
 def VVLba7(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CCcecd.VVoj5o(xmlTxt)
  parser = CCcecd.CCYxeK()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VVmNZ1(self, VVR0r4, title, txt, colList):
  if self.onlyEpg:
   self.VVVhJD(VVR0r4, "epg")
  else:
   if self.shareIsRef:
    FFWBJu(self, BF(FFG53m, VVR0r4, BF(self.VVgJzZ, VVR0r4)), "Copy all References from Source to Destination ?")
   else:
    VVegP0 = []
    VVegP0.append(("Copy EPG\t (All List)" , "epg"  ))
    VVegP0.append(("Copy Picons\t (All List)" , "picon" ))
    FFJcY1(self, BF(self.VVVhJD, VVR0r4), VVegP0=VVegP0, width=1000)
 def VVVhJD(self, VVR0r4, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VVWCGR  , "EPG"
   elif item == "picon": fnc, txt = self.VVEFI2 , "PIcons"
   title = "Copy %s" % txt
   tot   = VVR0r4.VVsBGq()
   FFWBJu(self, BF(FFG53m, VVR0r4, BF(fnc, VVR0r4, title)), "Overwrite %s for %d Service%s ?" % (FF6TiS(txt, VVBfw8), tot, FFJHIK(tot)), title=title)
 def VVgJzZ(self, VVR0r4):
  files = CCCu2Z.VVfoZV()
  totChange = 0
  if files:
   for path in files:
    txt = FFu1EI(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVR0r4.VVtxRM():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFmB3r()
  tot = VVR0r4.VVsBGq()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FFJRXg(self, txt)
 def VVEFI2(self, VVR0r4, title):
  if not iCopyfile:
   FFnHzu(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CC96Ar.VVwdi5()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVR0r4.VVtxRM():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVR0r4.VVsBGq()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FFJRXg(self, txt, title=title)
 def VVWCGR(self, VVR0r4, title):
  txt, err = CC2gVv.VVgqNZ(VVR0r4, title)
  if err : FFnHzu(self, err, title=title)
  else : FFJRXg(self, txt, title=title)
 class CCYxeK(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VVQD4i(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CCcecd.CCYxeK())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FF6TiS("XML Parse Error in:", VVnKNv), path)
   txt += "%s\n%s\n\n" % (FF6TiS("Error:", VVnKNv), str(e))
   FFJRXg(SELF, txt, VVvi08="#11220000", title=title)
   return None
 @staticmethod
 def VVoj5o(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
class CC2gVv(Screen, CCEwHg):
 VV8WDd  = "BDTSE"
 VVp5eH   = "save"
 VVUoQ3   = "load"
 VVkBGN  = "flushEPG"
 def __init__(self, session):
  self.skin, self.skinParam = FFAJVu(VVtBbU, 950, 800, 50, 40, 30, "#22110011", "#22110022", 30)
  self.session  = session
  valid, path, sz, szTxt = CC2gVv.VVrZKD()
  qUrl, iptvRef = CCCu2Z.VVBzpG(self)
  VVegP0 = []
  VVegP0.append((VVSTv2 + "Cache File Info." , "inf"))
  VVegP0.append(VVHMBI)
  fTxt = " (%s)" % os.path.basename(path) if valid else ""
  t1 = "Save EPG to File%s" % fTxt
  t2 = "Load EPG from File%s" % fTxt
  if valid:
   VVegP0.append((t1, self.VVp5eH))
   VVegP0.append((t2, self.VVUoQ3))
  else:
   VVegP0.append((t1, ))
   VVegP0.append((t2, ))
  VVegP0.append(VVHMBI)
  VVegP0.append((VVsIVN + "Delete EPG (from RAM only)", self.VVkBGN))
  VVegP0.append(VVHMBI)
  txt = "Update Current Bouquet EPG (from IPTV Server)"
  if qUrl or "chCode" in iptvRef: VVegP0.append((txt, "refreshIptvEPG" ))
  else        : VVegP0.append((txt,     ))
  VVegP0.append(("Copy EPG between Channels (from xml file)", "copyEpg" ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Translate Current Channel EPG %s(Experimental)" % VVsIVN, "VVssf8"))
  FFsw8F(self, VVegP0=VVegP0)
  self.onShown.append(self.VVoCo0)
 def VVu0DR(self):
  global VVtXrR
  VVtXrR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "inf"    : self.VVPe7U()
   elif item in (self.VVp5eH, self.VVUoQ3, self.VVkBGN):
    reset = item == self.VVUoQ3
    FFWBJu(self, BF(FFG53m, self, BF(self.VVxwEf, item, reset)), VVFNjG="Continue ?")
   elif item == "refreshIptvEPG"  : CCCu2Z.VVvP5F(self)
   elif item == "VVssf8" : self.VVssf8()
   elif item == "copyEpg"    : self.VVFwK4(False, onlyEpg=True)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FFCoOh(self["myMenu"])
  FFUSMR(self)
 def VVxwEf(self, act, reset=False):
  ok = CC2gVv.VVhhK3(act)
  if ok:
   if reset:
    CC2gVv.VVTLeU(self)
   FFcZi2(self, "Done")
  else:
   FFcZi2(self, "Failed!")
 def VVPe7U(self):
  title = "EPG Cache File"
  valid, path, sz, szTxt = CC2gVv.VVrZKD()
  if path:
   if valid: txt = "File Path\t: %s\n\nFile Size\t: %s\n" % (path, szTxt or "?")
   else : txt = "System Settings: %s\n\n%s" % (path, FF6TiS("File not found (check System EPG settings).", VVsIVN))
   FFJRXg(self, txt, title=title)
  else:
   FFnHzu(self, "Cannot read Path Settings !", title=title)
 @staticmethod
 def VVDwpl():
  return [("", "Disable"),("af","Afrikaans"),("sq","Albanian"),("am","Amharic"),("ar","Arabic"),("hy","Armenian"),("as","Assamese"),("ay","Aymara"),("az","Azerbaijani"),("bm","Bambara"),("eu","Basque"),("be","Belarusian"),("bn","Bengali"),("bho","Bhojpuri"),("bs","Bosnian"),("bg","Bulgarian"),("ca","Catalan"),("ceb","Cebuano"),("ny","Chichewa"),("zh-CN","Chinese (Simplified)"),("zh-TW","Chinese (Traditional)"),("co","Corsican"),("hr","Croatian"),("cs","Czech"),("da","Danish"),("dv","Dhivehi"),("doi","Dogri"),("nl","Dutch"),("en","English"),("eo","Esperanto"),("et","Estonian"),("ee","Ewe"),("tl","Filipino"),("fi","Finnish"),("fr","French"),("fy","Frisian"),("gl","Galician"),("ka","Georgian"),("de","German"),("el","Greek"),("gn","Guarani"),("gu","Gujarati"),("ht","Haitian Creole"),("ha","Hausa"),("haw","Hawaiian"),("iw","Hebrew"),("hi","Hindi"),("hmn","Hmong"),("hu","Hungarian"),("is","Icelandic"),("ig","Igbo"),("ilo","Ilocano"),("id","Indonesian"),("ga","Irish"),("it","Italian"),("ja","Japanese"),("jw","Javanese"),("kn","Kannada"),("kk","Kazakh"),("km","Khmer"),("rw","Kinyarwanda"),("gom","Konkani"),("ko","Korean"),("kri","Krio"),("ku","Kurdish (Kurmanji)"),("ckb","Kurdish (Sorani)"),("ky","Kyrgyz"),("lo","Lao"),("la","Latin"),("lv","Latvian"),("ln","Lingala"),("lt","Lithuanian"),("lg","Luganda"),("lb","Luxembourgish"),("mk","Macedonian"),("mai","Maithili"),("mg","Malagasy"),("ms","Malay"),("ml","Malayalam"),("mt","Maltese"),("mi","Maori"),("mr","Marathi"),("mni-Mtei","Meiteilon (Manipuri)"),("lus","Mizo"),("mn","Mongolian"),("my","Myanmar (Burmese)"),("ne","Nepali"),("no","Norwegian"),("or","Odia (Oriya)"),("om","Oromo"),("ps","Pashto"),("fa","Persian"),("pl","Polish"),("pt","Portuguese"),("pa","Punjabi"),("qu","Quechua"),("ro","Romanian"),("ru","Russian"),("sm","Samoan"),("sa","Sanskrit"),("gd","Scots Gaelic"),("nso","Sepedi"),("sr","Serbian"),("st","Sesotho"),("sn","Shona"),("sd","Sindhi"),("si","Sinhala"),("sk","Slovak"),("sl","Slovenian"),("so","Somali"),("es","Spanish"),("su","Sundanese"),("sw","Swahili"),("sv","Swedish"),("tg","Tajik"),("ta","Tamil"),("tt","Tatar"),("te","Telugu"),("th","Thai"),("ti","Tigrinya"),("ts","Tsonga"),("tr","Turkish"),("tk","Turkmen"),("ak","Twi"),("uk","Ukrainian"),("ur","Urdu"),("ug","Uyghur"),("uz","Uzbek"),("vi","Vietnamese"),("cy","Welsh"),("xh","Xhosa"),("yi","Yiddish"),("yo","Yoruba"),("zu","Zulu")]
 def VVssf8(self):
  title = "Translate Current Channel EPG"
  bg = "#11101010"
  VV91FP  = (""  , BF(self.VVbDcQ, title, True) , [])
  VVdn6T = ("Start" , BF(self.VVbDcQ, title, False), [])
  VVDB15 = ("Change Language", self.VVijYX      , [])
  widths  = (70 , 30)
  VVsZoP = (LEFT , CENTER)
  FFqiz1(self, None, title=title, VVVC4T=self.VV1Isv(), VVsZoP=VVsZoP, VVx2iV=widths, width=1200, vMargin=20, VVwwGj=30, VV91FP=VV91FP, VVdn6T=VVdn6T, VVDB15=VVDB15, VVPDqC=2
    , VVXbiY="#11201010", VVVy8H=bg, VVvi08=bg, VVbSmQ="#00ffffaa", VVTrrJ="#00004455", VVcd71=bg)
 def VV1Isv(self):
  Def, ch = "DISABLED", dict(CC2gVv.VVDwpl())
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  VVVC4T = [("Event Name Language", ch.get(tVal, Def)), ("Description Language", ch.get(dVal, Def))]
  return VVVC4T
 def VVijYX(self, VVR0r4, title, txt, colList):
  ndx = VVR0r4.VVVZYd()
  title = colList[0]
  confItem = CFG.epgLangTitle if ndx == 0 else CFG.epgLangDescr
  CCAqEA.VVLGjH(self, confItem, title, lst=CC2gVv.VVDwpl(), cbFnc=BF(self.VVlQsq, VVR0r4))
 def VVlQsq(self, VVR0r4):
  for ndx, row in enumerate(self.VV1Isv()):
   VVR0r4.VVsr2V(ndx, row)
 def VVbDcQ(self, Title, isAsk, VVR0r4, title, txt, colList):
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  if not (tVal or dVal):
   FFtMfC(VVR0r4, "Change Language", 700)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self)
   refCode, evList, err = CC2gVv.VVHDku(refCode)
   fnc = BF(self.VVm9Qs, Title, refCode, evList, VVR0r4)
   if   err : FFnHzu(self, err, title=Title)
   elif isAsk : FFWBJu(self, fnc, "Start ?", title=Title)
   else  : fnc()
 def VVm9Qs(self, title, refCode, evList, VVR0r4):
  self.session.open(CCDe3n, barTheme=CCDe3n.VVEpKA, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VV2XQv, evList)
      , VVuJdT = BF(self.VVbe7R, title, refCode))
  VVR0r4.cancel()
 def VV2XQv(self, evList, VVEkKt):
  totEv = len(evList)
  newLst = []
  totErrName = totErrShort = totErrLong = totSkip = 0
  VVEkKt.VVQWYw(totEv)
  VVEkKt.VVyzJx = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
  lang = CFG.epgLangDescr.getValue()
  for ev in evList:
   trName, trShort, trLong, errName, errShort, errLong = CC2gVv.VVeM6p(*ev[2:5])
   totErrName  += errName
   totErrShort += errShort
   totErrLong  += errLong
   if not VVEkKt or VVEkKt.isCancelled:
    return
   VVEkKt.VVHjIy(1)
   VVEkKt.VVERp8(len(newLst), ev[2] if len(ev[2]) < 22 else ev[2][:22] + " ...")
   name1, short1, long1 = ev[2:5]
   if (name1, short1, long1) != (trName, trShort, trLong):
    item = list(ev)
    item[2], item[3], item[4] = trName, trShort, trLong
    item.append(1)
    newLst.append(tuple(item))
   else:
    totSkip += 1
   VVEkKt.VVyzJx = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
 def VVbe7R(self, title, refCode, VVLnvr, VVyzJx, threadCounter, threadTotal, threadErr):
  newLst, totEv, totErrName, totErrShort, totErrLong, totSkip = VVyzJx
  if newLst: totEv, totOK = CC2gVv.VVcLdy(refCode, newLst)
  else  : totOK = 0
  if totOK:
   CC2gVv.VVAhVB()
   CC2gVv.VVTLeU(self)
  txt  = "Events\t: %d\n"  % totEv
  txt += "Processed\t: %d\n" % len(newLst)
  txt += "Changed\t: %d\n" % totOK
  if totSkip : txt += "Skipped\t: %d \t... Same language\n" % totSkip
  if any((totErrName, totErrShort, totErrLong)):
   txt += "\nErrors:\n"
   if totErrName : txt += "  Event Name\t: %d\n" % totErrName
   if totErrShort: txt += "  Description\t: %d\n" % totErrShort
   if totErrLong : txt += "  Description\t: %d\n" % totErrLong
  FFJRXg(self, txt, title=title)
 @staticmethod
 def VVeM6p(eName, eShort, eLong):
  eName, eShort, eLong = eName.strip(), eShort.strip(), eLong.strip()
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  lang, lst, resLst, errLst = (tVal, dVal, dVal), (eName, eShort, eLong), ["", "", ""], [0, 0, 0]
  def VVcOV6(ndx):
   if lst[ndx] and lang[ndx]:
    txt, err = CC2gVv.VVskcb(lst[ndx], lang[ndx])
    resLst[ndx], errLst[ndx] = txt, 1 if err else 0
  thLst = []
  for ndx in range(3):
   th = iThread(name="ajp_%d" % ndx, target=BF(VVcOV6, ndx))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  trName, trShort, trLong = resLst[0] or eName, resLst[1] or eShort, resLst[2] or eLong
  errName, errShort, errLong = errLst
  return trName, trShort, trLong, errName, errShort, errLong
 @staticmethod
 def VVskcb(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "%s%s&q=%s" % ("=lt&otua=ls&?m/moc.elgoog.etalsnart//:sptth"[::-1], toLang, FFXjqJ(txt))
   txt, err = CCCu2Z.VVex4B(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFyQaB(txt)
    ndx  = txt.find('<div class="result-container">')
    if ndx > -1:
     txt = txt[ndx + 30:]
     ndx  = txt.find("</div>")
     if ndx > -1:
      return str(CC2gVv.VVwBKA(txt[:ndx])).strip(), ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVrZKD():
  path = szTxt = ""
  valid = sz = 0
  try: path = config.misc.epgcache_filename.getValue()
  except: pass
  if fileExists(path):
   valid = 1
   sz = FFREV4(path)
   szTxt = CCr5c7.VVJv7c(sz) if sz > -1 else ""
  return valid, path, sz, szTxt
 @staticmethod
 def VVHP6L():
  try:
   from enigma import eEPGCache
   return eEPGCache, eEPGCache.getInstance()
  except:
   return None, None
 @staticmethod
 def VVAhVB(): CC2gVv.VVhhK3(CC2gVv.VVp5eH)
 @staticmethod
 def VVhhK3(act):
  ec, inst = CC2gVv.VVHP6L()
  if inst and hasattr(ec, act):
   try:
    exec("inst.%s()" % act)
    return True
   except:
    pass
  return False
 @staticmethod
 def VVTLeU(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   SELF.session.nav.stopService()
   SELF.session.nav.playService(serv)
 @staticmethod
 def VVHDku(refCode):
  ec, inst = CC2gVv.VVHP6L()
  if inst:
   try:
    evList = inst.lookupEvent([CC2gVv.VV8WDd, (refCode, 0, -1, 20160)])
    if evList: return refCode, evList, ""
    else  : return refCode, [], "System returned empty EPG list"
   except:
    return refCode, [], "EPG Read-Error !"
  else:
   return refCode, [], "Cannot read EPG Cache !"
 @staticmethod
 def VVcLdy(refCode, events, longDescDays=0):
  ec, inst = CC2gVv.VVHP6L()
  totEv, totOK, fnc = 0, 0, None
  if inst:
   if   hasattr(ec, "importEvents"): fnc = inst.importEvents
   elif hasattr(ec, "importEvent") : fnc = inst.importEvent
  if fnc:
   for data in events:
    totEv += 1
    try:
     if longDescDays and data[0] > iTime() + 86400 * longDescDays:
      data = data[:4] + ("",) + data[5:]
     fnc(refCode, (data,))
     totOK += 1
    except:
     pass
  return totEv, totOK
 @staticmethod
 def VVjWEY(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   ec, inst = CC2gVv.VVHP6L()
   if ec:
    event = inst.lookupEventTime(serv, -1, 0)
    if event:
     return CC2gVv.VVaFM1(event)
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CC6biu.CC2gVv(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVaFM1(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CC2gVv.VVGuZo(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVTRuo(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   ec, inst = CC2gVv.VVHP6L()
   try:
    if inst:
     for evNum in range(2):
      event = inst.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CC2gVv.VVaFM1(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FFrOxn(evTime)
       evEndTxt  = FFrOxn(evEnd)
       evDurTxt  = FFFSaa(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FFFSaa(evPos)
        evRem = evEnd - now
        evRemTxt = FFFSaa(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FFFSaa(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VVGuZo(event):
  genre = PR = ""
  try:
   genre  = CC2gVv.VVWiSN(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CC2gVv.VVee3w(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVee3w(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVWiSN(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CC2gVv.VVZ7Xe()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVZ7Xe():
  path = VVeop3 + "_sup_genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFu1EI(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFu1EI(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVgqNZ(VVR0r4, title):
  ec, inst = CC2gVv.VVHP6L()
  if not inst:
   return "", "Cannot access EPG Cache !"
  totFound = totEvents = totSuccess = totInvalid = totEvErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVR0r4.VVtxRM():
   if remark == "0":
    try:
     evList = inst.lookupEvent([CC2gVv.VV8WDd, (srcRef, 0, -1, 20160)])
    except:
     totEvErr += 1
     evList = []
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CC2gVv.VVcLdy(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CC2gVv.VVAhVB()
  txt  = "Services\t: %d\n"  % VVR0r4.VVsBGq()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  if totEvErr:
   txt += "EPG Errors\t: %d" % totEvErr
  return txt, ""
 @staticmethod
 def VVVt6g(info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += CC2gVv.VVveOd(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += CC2gVv.VVveOd(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += CC2gVv.VVveOd(event, 0)
     except:
      pass
  return epg
 @staticmethod
 def VVveOd(event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CC2gVv.VVaFM1(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    trName, trShort, trLong, errName, errShort, errLong = CC2gVv.VVeM6p(evName, evShort, evDesc)
    evShort, evDesc = trShort, trLong
    evNameTransl = trName if evName and trName and evName != trName else ""
    if evName          : txt += "Name\t: %s\n"   % FF6TiS(evName, VVpkep)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (CFG.epgLangDescr.getValue().upper(), FF6TiS(evNameTransl, VVpkep))
    if evTime           : txt += "Start Time\t: %s\n" % FFrOxn(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFrOxn(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFFSaa(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFFSaa(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFFSaa(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FF6TiS(evShort, VVJCMd)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FF6TiS(evDesc , VVJCMd)
    if txt:
     txt = FF6TiS("\n%s\n%s Event:\n%s\n" % (VVtc24, ("Current", "Next")[evNum], VVtc24), VVpkep) + txt
  return txt
 @staticmethod
 def VVwBKA(txt):
  try:
   from HTMLParser import HTMLParser
   return HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
class CCcecd(Screen, CCEwHg):
 VVjSMn  = 0
 VVD91T = 1
 VVrNsc  = 2
 VVh8SR  = 3
 VVc6zg = 4
 VVEkB2 = 5
 VVdsHn = 6
 VVbljq   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FFAJVu(VVtBbU, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVRDt0 = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVegP0 = self.VVLIrn()
  FFsw8F(self, VVegP0=VVegP0, title="Services/Channels")
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self["myMenu"].setList(self.VVLIrn())
  FFCoOh(self["myMenu"])
  FFUSMR(self)
 def VVLIrn(self):
  VVegP0 = []
  c = VVSTv2
  VVegP0.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVegP0.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVegP0.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVegP0.append(VVHMBI)
  c = VVpkep
  VVegP0.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVegP0.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVegP0.append((VVnKNv + "More tables ..."     , "VV2dbc"    ))
  c = VVJCMd
  VVegP0.append(VVHMBI)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVegP0.append((c + txt          , "VVwGWc"  ))
  else : VVegP0.append((txt           ,          ))
  VVegP0.append((c + 'Export Services to "channels.xml"'    , "VV2SLS"      ))
  VVegP0.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VVPN93
  VVegP0.append(VVHMBI)
  VVegP0.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVegP0.append((c + "Invalid Services Cleaner"       , "VVP6Kx"    ))
  c = VVPN93
  VVegP0.append(VVHMBI)
  VVegP0.append((c + "Delete Channels with no names"     , "VVvwd4"    ))
  VVegP0.append((c + "Delete Empty Bouquets"       , "VV2yHE"     ))
  VVegP0.append(VVHMBI)
  VVnpEv, VVPkZu = CCcecd.VVq1kN()
  if fileExists(VVnpEv):
   enab = fileExists(VVPkZu)
   if enab: VVegP0.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVegP0.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVegP0.append(("Reset Parental Control Settings"      , "VVPbWY"    ))
  VVegP0.append(("Reload Channels and Bouquets"       , "VVcNqo"      ))
  return VVegP0
 def VVu0DR(self):
  global VVtXrR
  VVtXrR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCM2Fd.VV8elw(self.session)
   elif item == "openSignal"       : FFyGv4(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFiqcT(self, fncMode=CC6biu.VVn9lJ)
   elif item == "lameDB_allChannels_with_refCode"  : FFG53m(self, self.VV1Kgt)
   elif item == "lameDB_allChannels_with_tranaponder" : FFG53m(self, self.VVlNdL)
   elif item == "VV2dbc"     : self.VV2dbc()
   elif item == "VVwGWc"  : CChuYY.VVwGWc(self)
   elif item == "VV2SLS"      : self.VV2SLS()
   elif item == "copyEpgPicons"      : self.VVFwK4(False)
   elif item == "SatellitesCleaner"     : FFG53m(self, self.FFG53m_SatellitesCleaner)
   elif item == "VVP6Kx"    : FFG53m(self, BF(self.VVP6Kx))
   elif item == "VVvwd4"    : FFG53m(self, self.VVvwd4)
   elif item == "VV2yHE"     : self.VV2yHE(self)
   elif item == "enableHiddenChannels"     : self.VVwXKA(True)
   elif item == "disableHiddenChannels"    : self.VVwXKA(False)
   elif item == "VVPbWY"    : FFWBJu(self, self.VVPbWY, "Reset and Restart ?")
   elif item == "VVcNqo"      : FFG53m(self, BF(CCcecd.VVcNqo, self))
 def VV2dbc(self):
  VVegP0 = []
  VVegP0.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVegP0.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVegP0.append(("Services with PIcons for the System"  , "VVMtzH"     ))
  VVegP0.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVegP0.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"     ))
  FFJcY1(self, self.VVD8tS, VVegP0=VVegP0, title="Service Information", VV4p4D=True)
 def VVD8tS(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FFG53m(self, BF(self.VVIICV, title))
   elif ref == "parentalControlChannels"   : FFG53m(self, BF(self.VVIaUz, title))
   elif ref == "showHiddenChannels"    : FFG53m(self, BF(self.VVpNQN, title))
   elif ref == "VVMtzH"    : FFG53m(self, BF(self.VV7wPD, title))
   elif ref == "servicesWithMissingPIcons"   : FFG53m(self, BF(self.VVD3kN, title))
   elif ref == "TranspondersStats"     : FFG53m(self, BF(self.VVszdd, title))
   elif ref == "SatellitesXmlStats"    : FFG53m(self, BF(self.VVs4T4, title))
 def VV2SLS(self):
  VVegP0 = []
  VVegP0.append(("All DVB-S/C/T Services", "all"))
  VVegP0.extend(CCu3Fm.VVo7xX())
  FFJcY1(self, self.VVhrbl, VVegP0=VVegP0, title="", VV4p4D=True)
 def VVhrbl(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCcecd.VVZoCU("1:7:")
   else   : lst = FFXd2v(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFkzUr(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFabwQ(r)  : sat = "Stream Relay"
       elif FF2IUY(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FFxJSp(CFG.exportedTablesPath.getValue()), FFxsfY())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FFcZi2(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFtMfC(self, "No Services found !", 1500)
 @staticmethod
 def VVcNqo(SELF):
  FFmB3r()
  FFcZi2(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VV1Kgt(self):
  self.VVRDt0 = None
  self.lastfilterUsed  = None
  self.filterObj   = CCSAYR(self)
  VVzto2, err = CCcecd.VV4wpk(self, self.VVjSMn)
  if VVzto2:
   VVzto2.sort(key=lambda x: x[0].lower())
   VV91FP  = ("Zap"   , self.VVN9JW     , [])
   VVBSYf = (""    , self.VVCgZm   , [])
   VVljWo = ("Options"  , self.VVrwLz , [])
   VVdn6T = ("Current Service", self.VVQtuQ , [])
   VVDB15 = ("Filter"   , self.VVDhnc  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVsZoP  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFqiz1(self, None, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VV91FP=VV91FP, VVBSYf=VVBSYf, VVdn6T=VVdn6T, VVljWo=VVljWo, VVDB15=VVDB15, lastFindConfigObj=CFG.lastFindServices)
 def VVlNdL(self):
  self.VVRDt0 = None
  self.lastfilterUsed  = None
  self.filterObj   = CCSAYR(self)
  VVzto2, err = CCcecd.VV4wpk(self, self.VVD91T)
  if VVzto2:
   VVzto2.sort(key=lambda x: x[0].lower())
   VV91FP  = ("Zap"   , self.VVN9JW      , [])
   VVBSYf = (""    , self.VVCgZm    , [])
   VVdn6T = ("Current Service", self.VVQtuQ  , [])
   VVljWo = ("Options"  , self.VV1g1r , [])
   VVDB15 = ("Filter"   , self.VVBHAJ  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVsZoP  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFqiz1(self, None, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VV91FP=VV91FP, VVBSYf=VVBSYf, VVdn6T=VVdn6T, VVljWo=VVljWo, VVDB15=VVDB15, lastFindConfigObj=CFG.lastFindServices)
 def VVrwLz(self, VVR0r4, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CCeaGv(self, VVR0r4)
  VVegP0 = []
  isMulti = VVR0r4.VV9Jt5
  if isMulti:
   refCodeList = VVR0r4.VVYpZO(3)
   if refCodeList:
    VVegP0.append(("Add Selection to Parental Control"    , "parentalControl_sel_add"  ))
    VVegP0.append(("Remove Selection from Parental Control"   , "parentalControl_sel_remove" ))
    VVegP0.append(VVHMBI)
    VVegP0.append(("Add Selection to Hidden Services"    , "hiddenServices_sel_add"  ))
    VVegP0.append(("Remove Selection from Hidden Services"   , "hiddenServices_sel_remove" ))
    VVegP0.append(VVHMBI)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVegP0.append((txt1, "parentalControl_add" ))
    VVegP0.append((txt2,       ))
   else:
    VVegP0.append((txt1,       ))
    VVegP0.append((txt2, "parentalControl_remove"))
   VVegP0.append(VVHMBI)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVegP0.append((txt1, "hiddenServices_add" ))
    VVegP0.append((txt2,       ))
   else:
    VVegP0.append((txt1,       ))
    VVegP0.append((txt2, "hiddenServices_remove" ))
   VVegP0.append(VVHMBI)
  cbFncDict = { "parentalControl_add"   : BF(self.VV8QpA, VVR0r4, refCode, True)
     , "parentalControl_remove"  : BF(self.VV8QpA, VVR0r4, refCode, False)
     , "hiddenServices_add"   : BF(self.VVwGzk, VVR0r4, refCode, True)
     , "hiddenServices_remove"  : BF(self.VVwGzk, VVR0r4, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VV3Rix, VVR0r4, True)
     , "parentalControl_sel_remove" : BF(self.VV3Rix, VVR0r4, False)
     , "hiddenServices_sel_add"  : BF(self.VVe289, VVR0r4, True)
     , "hiddenServices_sel_remove" : BF(self.VVe289, VVR0r4, False)
     }
  VVegP01, cbFncDict1 = CCcecd.VVTdBB(self, VVR0r4, servName, 3)
  VVegP0.extend(VVegP01)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VVxIpf(VVegP0, cbFncDict)
 def VV1g1r(self, VVR0r4, title, txt, colList):
  servName = colList[0]
  mSel = CCeaGv(self, VVR0r4)
  VVegP0, cbFncDict = CCcecd.VVTdBB(self, VVR0r4, servName, 3)
  mSel.VVxIpf(VVegP0, cbFncDict)
 @staticmethod
 def VVTdBB(SELF, VVR0r4, servName, refCodeCol):
  tot = VVR0r4.VVkGfp()
  if tot > 0:
   sTxt = FF6TiS("%d Service%s" % (tot, FFJHIK(tot)), VVpkep)
   VVegP0 = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FF2AUs(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FF6TiS(servName, VVpkep)
   VVegP0 = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CCcecd.VVsIAT, SELF, VVR0r4, refCodeCol, True)
     , "addToBouquet_one" : BF(CCcecd.VVsIAT, SELF, VVR0r4, refCodeCol, False)
     }
  return VVegP0, cbFncDict
 @staticmethod
 def VVsIAT(SELF, VVR0r4, refCodeCol, isMulti):
  picker = CCu3Fm(SELF, VVR0r4, "Add to Bouquet", BF(CCcecd.VVF5sL, VVR0r4, refCodeCol, isMulti))
 @staticmethod
 def VVF5sL(VVR0r4, refCodeCol, isMulti):
  if isMulti : refCodeList = VVR0r4.VVYpZO(refCodeCol)
  else  : refCodeList = [VVR0r4.VVVPDl()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VV8QpA(self, VVR0r4, refCode, isAddToBlackList):
  VVR0r4.VV7IKK("Processing ...")
  FFDxKA(BF(self.VVy3eK, VVR0r4, [refCode], isAddToBlackList))
 def VV3Rix(self, VVR0r4, isAddToBlackList):
  refCodeList = VVR0r4.VVYpZO(3)
  if not refCodeList:
   FFnHzu(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVR0r4.VV7IKK("Processing ...")
  FFDxKA(BF(self.VVy3eK, VVR0r4, refCodeList, isAddToBlackList))
 def VVy3eK(self, VVR0r4, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VV7lVB, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VV7lVB):
   lines = FF5DO4(VV7lVB)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VV7lVB, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVR0r4.VV9Jt5
   if isMulti:
    self.VVAgTp(VVR0r4, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVdyef(VVR0r4, refCode)
    VVR0r4.VVRZ9B()
  else:
   VVR0r4.VVsu20("No changes")
 def VVwGzk(self, VVR0r4, refCode, isHide):
  title = "Change Hidden State"
  if FFYvXi(refCode):
   VVR0r4.VV7IKK("Processing ...")
   ret = FFqMFs(refCode, isHide)
   if ret : FFG53m(self, BF(self.VVdyef, VVR0r4, refCode))
   else : FFnHzu(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFnHzu(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVdyef(self, VVR0r4, refCode):
  VVzto2, err = CCcecd.VV4wpk(self, self.VVjSMn, VVShIp=[3, [refCode], False])
  done = False
  if VVzto2:
   data = VVzto2[0]
   if data[3] == refCode:
    done = VVR0r4.VVkf6n(data)
  if not done:
   self.VVqmd5(VVR0r4, VVR0r4.VVUbIN(), self.VVjSMn)
  VVR0r4.VVRZ9B()
 def VVAgTp(self, VVR0r4, totRefCodes):
  VVzto2, err = CCcecd.VV4wpk(self, self.VVjSMn, VVShIp=self.VVRDt0)
  VVR0r4.VVwzoo(VVzto2)
  VVR0r4.VVHKEm(False)
  VVR0r4.VVsu20("%d Processed" % totRefCodes)
 def VVe289(self, VVR0r4, isHide):
  refCodeList = VVR0r4.VVYpZO(3)
  if not refCodeList:
   FFnHzu(self, "Nothing selected", title="Change Hidden State")
   return
  VVR0r4.VV7IKK("Processing ...")
  FFDxKA(BF(self.VVl0nC, VVR0r4, refCodeList, isHide))
 def VVl0nC(self, VVR0r4, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFqMFs(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFmB3r(True)
   self.VVAgTp(VVR0r4, len(refCodeList))
  else:
   VVR0r4.VVsu20("No changes")
 def VVDhnc(self, VVR0r4, title, txt, colList):
  inFilterFnc = BF(self.VVljiB, VVR0r4) if self.VVRDt0 else None
  self.filterObj.VV4Lnf(1, VVR0r4, 2, BF(self.VVLfxr, VVR0r4), inFilterFnc=inFilterFnc)
 def VVLfxr(self, VVR0r4, item):
  self.VVzehk(VVR0r4, False, item, 2, self.VVjSMn)
 def VVljiB(self, VVR0r4, menuInstance, item):
  self.VVzehk(VVR0r4, True, item, 2, self.VVjSMn)
 def VVBHAJ(self, VVR0r4, title, txt, colList):
  inFilterFnc = BF(self.VVR7d4, VVR0r4) if self.VVRDt0 else None
  self.filterObj.VV4Lnf(2, VVR0r4, 4, BF(self.VVbz0x, VVR0r4), inFilterFnc=inFilterFnc)
 def VVbz0x(self, VVR0r4, item):
  self.VVzehk(VVR0r4, False, item, 4, self.VVD91T)
 def VVR7d4(self, VVR0r4, menuInstance, item):
  self.VVzehk(VVR0r4, True, item, 4, self.VVD91T)
 def VVPUjn(self, VVR0r4, title, txt, colList):
  inFilterFnc = BF(self.VV5VQI, VVR0r4) if self.VVRDt0 else None
  self.filterObj.VV4Lnf(0, VVR0r4, 4, BF(self.VVaqTK, VVR0r4), inFilterFnc=inFilterFnc)
 def VVaqTK(self, VVR0r4, item):
  self.VVzehk(VVR0r4, False, item, 4, self.VVrNsc)
 def VV5VQI(self, VVR0r4, menuInstance, item):
  self.VVzehk(VVR0r4, True, item, 4, self.VVrNsc)
 def VVzehk(self, VVR0r4, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVR0r4.VV5xX4(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVRDt0 = None
  else:
   words, asPrefix = CCSAYR.VVaVMf(words)
   self.VVRDt0 = [col, words, asPrefix]
  if words: FFG53m(VVR0r4, BF(self.VVqmd5, VVR0r4, title, mode), clearMsg=False)
  else : FFtMfC(VVR0r4, "Incorrect filter", 2000)
 def VVqmd5(self, VVR0r4, title, mode):
  VVzto2, err = CCcecd.VV4wpk(self, mode, VVShIp=self.VVRDt0, VVITXJ=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVR0r4.VVtxRM():
    try:
     ndx = VVzto2.index(tuple(list(map(str.strip, row))))
     lst.append(VVzto2[ndx])
    except:
     pass
   VVzto2 = lst
  if VVzto2:
   VVzto2.sort(key=lambda x: x[0].lower())
   VVR0r4.VVwzoo(VVzto2, title)
  else:
   FFtMfC(VVR0r4, "Not found!", 1500)
 def VVIGsN(self, title, VVVC4T, VV91FP=None, VVBSYf=None, VVIqI1=None, VVdn6T=None, VVljWo=None, VVDB15=None):
  VVdn6T = ("Current Service", self.VVQtuQ, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVsZoP = (LEFT  , LEFT  , CENTER, LEFT    )
  FFqiz1(self, None, title=title, header=header, VVVC4T=VVVC4T, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VV91FP=VV91FP, VVBSYf=VVBSYf, VVIqI1=VVIqI1, VVdn6T=VVdn6T, VVljWo=VVljWo, VVDB15=VVDB15, lastFindConfigObj=CFG.lastFindServices)
 def VVQtuQ(self, VVR0r4, title, txt, colList):
  self.VVHUmU(VVR0r4)
 def VVWpOz(self, VVR0r4, title, txt, colList):
  self.VVHUmU(VVR0r4, True)
 def VVHUmU(self, VVR0r4, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVR0r4.VVzatv(colDict, VVozbc=True)
   else:
    VVR0r4.VVRgyb(3, refCode, True)
   return
  FFnHzu(self, "Cannot read current Reference Code !")
 def VVIICV(self, title):
  self.VVRDt0 = None
  self.lastfilterUsed  = None
  self.filterObj   = CCSAYR(self)
  VVzto2, err = CCcecd.VV4wpk(self, self.VVrNsc)
  if VVzto2:
   VVzto2.sort(key=lambda x: x[0].lower())
   VVBSYf = (""    , self.VVDMMI , []      )
   VVdn6T = ("Current Service", self.VVWpOz  , []      )
   VVDB15 = ("Filter"   , self.VVPUjn   , [], "Loading Filters ..." )
   VV91FP  = ("Zap"   , self.VVPDzy      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVsZoP  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFqiz1(self, None, title=title, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VV91FP=VV91FP, VVBSYf=VVBSYf, VVdn6T=VVdn6T, VVDB15=VVDB15, lastFindConfigObj=CFG.lastFindServices)
 def VVDMMI(self, VVR0r4, title, txt, colList):
  refCode  = self.VVPYhX(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFiqcT(self, fncMode=CC6biu.VV2EPz, refCode=refCode, chName=chName, text=txt)
 def VVPDzy(self, VVR0r4, title, txt, colList):
  refCode = self.VVPYhX(colList)
  FFGrAa(self, refCode)
 def VVN9JW(self, VVR0r4, title, txt, colList):
  FFGrAa(self, colList[3])
 def VVPYhX(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVlQRe(VVnpEv, mode=0):
  lines = FF5DO4(VVnpEv, encLst=["UTF-8"])
  return CCcecd.VVYm2F(lines, mode)
 @staticmethod
 def VVYm2F(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VV4wpk(SELF, mode, VVShIp=None, VVITXJ=True, VV6Oa0=True):
  VVnpEv, err = CCcecd.VVMV5K(SELF, VV6Oa0)
  if err:
   return None, err
  asPrefix = False
  if VVShIp:
   filterCol = VVShIp[0]
   filterWords = VVShIp[1]
   asPrefix = VVShIp[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCcecd.VVjSMn:
   blackList = None
   if fileExists(VV7lVB):
    blackList = FF5DO4(VV7lVB)
    if blackList:
     blackList = set(blackList)
  elif mode == CCcecd.VVD91T:
   tp = CCxkcu()
  VVCpBm, VVnYkd = FF1mjb()
  if mode in (CCcecd.VVEkB2, CCcecd.VVdsHn):
   VVzto2 = {}
  else:
   VVzto2 = []
  tagFound = False
  with ioOpen(VVnpEv, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FF99jt(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCcecd.VVrNsc:
       if sTypeInt in VVCpBm:
        STYPE = VVnYkd[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVzto2.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVzto2.append(tRow)
       else:
        VVzto2.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCcecd.VVbljq:
        VVzto2.append((chName, chProv, sat, refCode))
       elif mode == CCcecd.VVEkB2:
        VVzto2[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCcecd.VVdsHn:
        VVzto2[chName] = refCode
       elif mode == CCcecd.VVjSMn:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVzto2.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVzto2.append(tRow)
        else:
         VVzto2.append(tRow)
       elif mode == CCcecd.VVD91T:
        if sTypeInt in VVCpBm:
         STYPE = VVnYkd[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVyO6x(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVzto2.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVzto2.append(tRow)
        else:
         VVzto2.append(tRow)
       elif mode == CCcecd.VVh8SR:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVzto2.append((chName, chProv, sat, refCode))
       elif mode == CCcecd.VVc6zg:
        VVzto2.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVzto2 and VVITXJ:
   FFnHzu(SELF, "No services found!")
  return VVzto2, ""
 def VVIaUz(self, title):
  if fileExists(VV7lVB):
   lines = FF5DO4(VV7lVB)
   if lines:
    newRows = []
    VVzto2, err = CCcecd.VV4wpk(self, self.VVc6zg)
    if VVzto2:
     lines = set(lines)
     for item in VVzto2:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVzto2 = newRows
      VVzto2.sort(key=lambda x: x[0].lower())
      VVBSYf = ("", self.VVCgZm, [])
      VV91FP = ("Zap", self.VVN9JW, [])
      self.VVIGsN(title, VVzto2, VV91FP=VV91FP, VVBSYf=VVBSYf)
     else:
      FFJRXg(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVzto2)))
   else:
    FFcZi2(self, "No active Parental Control services.", FFyqg5())
  else:
   FFlkXm(self, VV7lVB)
 def VVpNQN(self, title):
  VVzto2, err = CCcecd.VV4wpk(self, self.VVh8SR)
  if VVzto2:
   VVzto2.sort(key=lambda x: x[0].lower())
   VVBSYf = ("" , self.VVCgZm, [])
   VV91FP  = ("Zap", self.VVN9JW, [])
   self.VVIGsN(title, VVzto2, VV91FP=VV91FP, VVBSYf=VVBSYf)
  elif err:
   pass
  else:
   FFcZi2(self, "No hidden services.", FFyqg5())
 def VVP6Kx(self):
  title = "Services unused in Tuner Configuration"
  VVnpEv, err = CCcecd.VVMV5K(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CCcecd.VVXq2S()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VVwDwX(str(item[0]))
    nsLst.add(ns)
  sysLst = CCcecd.VVZoCU("1:7:")
  tpLst  = CCcecd.VVlQRe(VVnpEv, mode=1)
  VVzto2 = []
  for refCode, chName in sysLst:
   servID = CCcecd.VVMC5S(refCode)
   tpID = CCcecd.VVutLW(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVzto2.append((chName, FFkzUr(refCode, False), refCode, servID))
  if VVzto2:
   VVzto2.sort(key=lambda x: x[0].lower())
   VVljWo = ("Options"   , BF(self.VVD4J4, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VVsZoP  = (LEFT  , CENTER , LEFT   , CENTER   )
   FFqiz1(self, None, title=title, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VVljWo=VVljWo, VVXbiY="#0a001122", VVVy8H="#0a001122", VVvi08="#0a001122", VVTrrJ="#00004455", VVcd71="#0a333333", VVVygK="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FFcZi2(self, "No invalid service found !", title=title)
 def VVD4J4(self, Title, VVR0r4, title, txt, colList):
  mSel = CCeaGv(self, VVR0r4)
  isMulti = VVR0r4.VV9Jt5
  if isMulti : txt = "Remove %s Services" % FF6TiS(str(VVR0r4.VVkGfp()), VVnKNv)
  else  : txt = "Remove : %s" % FF6TiS(VVR0r4.VVVPDl()[0], VVnKNv)
  VVegP0 = [(txt, "del")]
  cbFncDict = {"del": BF(FFG53m, VVR0r4, BF(self.VVWAyB, VVR0r4, Title))}
  mSel.VVxIpf(VVegP0, cbFncDict)
 def VVWAyB(self, VVR0r4, title):
  VVnpEv, err = CCcecd.VVMV5K(self, title=title)
  if err:
   return
  isMulti = VVR0r4.VV9Jt5
  skipLst = []
  if isMulti : skipLst = VVR0r4.VVYpZO(3)
  else  : skipLst = [VVR0r4.VVVPDl()[3]]
  tpLst = CCcecd.VVlQRe(VVnpEv, mode=0)
  servLst = CCcecd.VVlQRe(VVnpEv, mode=10)
  tmpDbFile = VVnpEv + ".tmp"
  lines   = FF5DO4(VVnpEv)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  os.system(FFNxGN("mv -f '%s' '%s'" % (tmpDbFile, VVnpEv)))
  VVzto2 = []
  for row in VVR0r4.VVtxRM():
   if not row[3] in skipLst:
    VVzto2.append(row)
  FFmB3r()
  FFJRXg(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVzto2:
   VVR0r4.VVwzoo(VVzto2, title)
   VVR0r4.VVHKEm(False)
  else:
   VVR0r4.cancel()
 def VVszdd(self, title):
  VVnpEv, err = CCcecd.VVMV5K(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VVa5Y9(VVnpEv)
  txt = FF6TiS("Total Transponders:\n\n", VVOEUI)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FF6TiS("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVOEUI)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FF96lQ(item), satList.count(item))
  FFJRXg(self, txt, title)
 def VVa5Y9(self, VVnpEv):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVnpEv, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVs4T4(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFlkXm(self, path, title=title)
   return
  elif not CCr5c7.VVKo2B(self, path, title):
   return
  if not CCjquA.VVqMK4(self):
   return
  tree = CCcecd.VVQD4i(self, path, title=title)
  if not tree:
   return
  VVzto2 = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FF99jt(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVzto2.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVzto2:
   VVzto2.sort(key=lambda x: int(x[1]))
   VVdn6T = ("Current Satellite", BF(self.VVV4fg, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VVsZoP  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FFqiz1(self, None, title=title, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=25, VVLnTw=1, VVdn6T=VVdn6T, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFnHzu(self, "No data found !", title=title)
 def VVV4fg(self, satCol, VVR0r4, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self)
  sat = FFkzUr(refCode, False)
  for ndx, row in enumerate(VVR0r4.VVtxRM()):
   if sat == row[satCol].strip():
    VVR0r4.VVwqjr(ndx)
    break
  else:
   FFtMfC(VVR0r4, "No listed !", 1500)
 def FFG53m_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FFnHzu(self, "No Satellites found !")
   return
  usedSats = CCcecd.VVXq2S()
  VVzto2 = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVzto2.append((sat[1], posTxt, FF99jt(sat[0]), tuners, str(posVal)))
  if VVzto2:
   VVvi08 = "#11222222"
   VVzto2.sort(key=lambda x: int(x[1]))
   VVdn6T = ("Current Satellite" , BF(self.VVV4fg, 2) , [])
   VVljWo = ("Options"   , self.VVo6TV  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VVsZoP  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FFqiz1(self, None, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=28, VVdn6T=VVdn6T, VVljWo=VVljWo, VVXbiY=VVvi08, VVVy8H=VVvi08, VVvi08=VVvi08, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFnHzu(self, "No data found !")
 def VVo6TV(self, VVR0r4, title, txt, colList):
  mSel = CCeaGv(self, VVR0r4)
  isMulti = VVR0r4.VV9Jt5
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FF6TiS(str(VVR0r4.VVkGfp()), VVnKNv)
  else  : txt = "Remove ALL Services on : %s" % FF6TiS(VVR0r4.VVVPDl()[0], VVnKNv)
  VVegP0 = []
  VVegP0.append((txt, "deleteSat"))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Delete Empty Bouquets", "VV2yHE"))
  cbFncDict = { "deleteSat"   : BF(FFG53m, VVR0r4, BF(self.VVc7C0, VVR0r4))
     , "VV2yHE" : BF(self.VV2yHE, VVR0r4)
     }
  mSel.VVxIpf(VVegP0, cbFncDict)
 def VVc7C0(self, VVR0r4):
  posLst = []
  isMulti = VVR0r4.VV9Jt5
  posLst = []
  if isMulti : posLst = VVR0r4.VVYpZO(4)
  else  : posLst = [VVR0r4.VVVPDl()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VVwDwX(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VVjQTu(nsLst)
  FFmB3r(True)
  FFJRXg(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VV2yHE(self, winObj):
  title = "Delete Empty Bouquets"
  FFWBJu(self, BF(FFG53m, winObj, BF(self.VV950y, title)), "Delete bouquets with no services ?", title=title)
 def VV950y(self, title):
  bList = CCu3Fm.VVf1LL()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CCu3Fm.VVyYIw(bRef)
    bPath = VVMOat + bFile
    FFO0bd(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVMOat + fil
     if fileExists(path):
      lines = FF5DO4(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFmB3r(True)
  if bNames: txt = "%s\n\n%s" % (FF6TiS("Deleted Bouquets:", VVpkep), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FFJRXg(self, txt, title=title)
 def VVwDwX(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VVjQTu(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVMOat)
  for srcF in files:
   if fileExists(srcF):
    lines = FF5DO4(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFSeor(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VV7wPD(self, title)   : self.VVMtzH(title, True)
 def VVD3kN(self, title) : self.VVMtzH(title, False)
 def VVMtzH(self, title, isWithPIcons):
  piconsPath = CC96Ar.VVwdi5()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CC96Ar.VVNp49(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVzto2, err = CCcecd.VV4wpk(self, self.VVc6zg)
    if VVzto2:
     channels = []
     for (chName, chProv, sat, refCode) in VVzto2:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFSTOf(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVzto2)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVcOV6(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVcOV6("PIcons Path"  , piconsPath)
     txt += VVcOV6("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVcOV6("Total services" , totalServices)
     txt += VVcOV6("With PIcons"  , totalWithPIcons)
     txt += VVcOV6("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFJRXg(self, txt)
     else:
      VVBSYf     = (""      , self.VVCgZm , [])
      if isWithPIcons : VVDB15 = ("Export Current PIcon", self.VVJqCU  , [])
      else   : VVDB15 = None
      VVljWo     = ("Statistics", FFJRXg, [txt])
      VV91FP      = ("Zap", self.VVN9JW, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVIGsN(title, channels, VV91FP=VV91FP, VVBSYf=VVBSYf, VVljWo=VVljWo, VVDB15=VVDB15)
   else:
    FFnHzu(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFnHzu(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVCgZm(self, VVR0r4, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFiqcT(self, fncMode=CC6biu.VV2EPz, refCode=refCode, chName=chName, text=txt)
 def VVJqCU(self, VVR0r4, title, txt, colList):
  png, path = CC96Ar.VVtefF(colList[3], colList[0])
  if path:
   CC96Ar.VVSdwi(self, png, path)
 @staticmethod
 def VVq1kN():
  VVnpEv  = "%slamedb" % VVMOat
  VVPkZu = "%slamedb.disabled" % VVMOat
  return VVnpEv, VVPkZu
 @staticmethod
 def VVu25s():
  VVwpQl  = "%slamedb5" % VVMOat
  VV0njx = "%slamedb5.disabled" % VVMOat
  return VVwpQl, VV0njx
 def VVwXKA(self, isEnable):
  VVnpEv, VVPkZu = CCcecd.VVq1kN()
  if isEnable and not fileExists(VVPkZu):
   FFcZi2(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVnpEv):
   FFnHzu(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFWBJu(self, BF(self.VVHTu1, isEnable), "%s Hidden Channels ?" % word)
 def VVHTu1(self, isEnable):
  VVnpEv , VVPkZu = CCcecd.VVq1kN()
  VVwpQl, VV0njx = CCcecd.VVu25s()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVPkZu, VVPkZu, VVnpEv)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VV0njx, VV0njx, VVwpQl)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVnpEv  , VVnpEv , VVPkZu)
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVwpQl , VVwpQl, VV0njx)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVPkZu, VVnpEv )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VV0njx, VVwpQl)
  res = os.system(cmd)
  FFmB3r()
  if res == 0 : FFcZi2(self, "Hidden List %s" % word)
  else  : FFnHzu(self, "Error while restoring:\n\n%s" % fileName)
 def VVPbWY(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %ssettings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVMOat
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %ssettings" % VVMOat
  FFq3ul(self, cmd)
 def VVvwd4(self):
  VVnpEv, err = CCcecd.VVMV5K(self)
  if err:
   return
  tmpFile = "/tmp/ajpanel_lamedb"
  FFO0bd(tmpFile)
  totChan = totRemoved = 0
  lines = FF5DO4(VVnpEv, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FFWBJu(self, BF(FFG53m, self, BF(self.VVgxlc, tmpFile, VVnpEv, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FFJHIK(totRemoved), totChan, FFJHIK(totChan))
      , callBack_No=BF(self.VVX9Bg, tmpFile))
  else:
   FFJRXg(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVgxlc(self, tmpFile, VVnpEv, totRemoved, totChan):
  os.system(FFNxGN("mv -f '%s' '%s'" % (tmpFile, VVnpEv)))
  FFmB3r()
  FFJRXg(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VVX9Bg(self, tmpFile):
  FFO0bd(tmpFile)
 @staticmethod
 def VVMV5K(SELF, VV6Oa0=True, title=""):
  VVnpEv, VVPkZu = CCcecd.VVq1kN()
  if   not fileExists(VVnpEv)       : err = "File not found !\n\n%s" % VVnpEv
  elif not CCr5c7.VVKo2B(SELF, VVnpEv) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VV6Oa0:
   FFnHzu(SELF, err, title=title)
  return VVnpEv, err
 @staticmethod
 def VVutLW(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VVMC5S(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VVZoCU(servTypes):
  VVV82e  = eServiceCenter.getInstance()
  VVVzTq   = '%s ORDER BY name' % servTypes
  VVoRPf   = eServiceReference(VVVzTq)
  VV0k6p = VVV82e.list(VVoRPf)
  if VV0k6p: return VV0k6p.getContent("CN", False)
  else     : return []
 @staticmethod
 def VVXq2S():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CC6biu(Screen):
 VVn9lJ  = 0
 VVngWh   = 1
 VVsVTC   = 2
 VV2EPz    = 3
 VVYL5u    = 4
 VVLAP8   = 5
 VV20Jv   = 6
 VVq8cn    = 7
 VVhNUL   = 8
 VVCAZt   = 9
 VV2pbT   = 10
 VVnHsd   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFAJVu(VVinJE, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVn9lJ)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FF6TiS("%s\n", VVPYB5) % VVtc24
  self.picViewer  = None
  FFsw8F(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVbB94 })
  self["myPicF"] = Label()
  self["myPicB"] = Label()
  self["myPic"] = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVoCo0)
  self.onClose.append(self.onExit)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  self["myLabel"].VV8dj1(outputFileToSave="chann_info")
  if   self.fncMode == self.VVn9lJ : fnc = self.VVubd3
  elif self.fncMode == self.VVngWh  : fnc = self.VVubd3
  elif self.fncMode == self.VVsVTC  : fnc = self.VVubd3
  elif self.fncMode == self.VV2EPz  : fnc = self.VV7qhc
  elif self.fncMode == self.VVYL5u  : fnc = self.VV7kYC
  elif self.fncMode == self.VVLAP8  : fnc = self.VVnE50
  elif self.fncMode == self.VV20Jv  : fnc = self.VVXglT
  elif self.fncMode == self.VVq8cn  : fnc = self.VVqfpR
  elif self.fncMode == self.VVhNUL  : fnc = self.VVv9el
  elif self.fncMode == self.VVCAZt : fnc = self.VVzd6A
  elif self.fncMode == self.VV2pbT  : fnc = self.VV3VXE
  elif self.fncMode == self.VVnHsd : fnc = self.VVRw8Q
  self["myLabel"].setText("\n   Reading Info ...")
  FFDxKA(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVN4p9()
 def VVUUXJ(self, err):
  self["myLabel"].setText(err)
  FFo6oa(self["myTitle"], "#22200000")
  FFo6oa(self["myBody"], "#22200000")
  self["myLabel"].VV8ZEE("#22200000")
  self["myLabel"].VVzVRx()
 def VVubd3(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self)
  self.refCode = refCode
  self.VVcz19(chName)
 def VV7qhc(self):
  self.VVcz19(self.chName)
 def VV7kYC(self):
  self.VVcz19(self.chName)
 def VVnE50(self):
  self.VVcz19(self.chName)
 def VVXglT(self):
  self.VVcz19("Picon Info")
 def VVqfpR(self):
  self.VVcz19(self.chName)
 def VVv9el(self):
  self.VVcz19(self.chName)
 def VVzd6A(self):
  self.VVcz19(self.chName)
 def VV3VXE(self):
  self.chUrl = self.refCode + self.callingSELF.VVI0Qk(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVcz19(self.chName)
 def VVRw8Q(self):
  self.VVcz19(self.chName)
 def VVcz19(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFZRjy(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VV0PUS(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FF6TiS(self.VVMJtQ(tUrl), VVsvZg)
  if not self.epg:
   epg = CC2gVv.VVVt6g(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVfe5D(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CC96Ar.VVtefF(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVfe5D(path)
  self.VVoAry()
  self.VVHTMG()
  self["myLabel"].setText(self.text or "   No active service", VVwZYa=VVaZwj)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVzVRx(minHeight=minH)
 def VVHTMG(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FF2IUY(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVI508(FFyQaB(url))
  if epg:
   self.text += "\n" + FFqjvC("EPG:", VVpkep) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVoAry()
 def VVoAry(self):
  if not self.piconShown and self.picUrl:
   path, err = FFHXM5(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVfe5D(path)
    if self.piconShown and self.refCode:
     self.VVygAZ(path, self.refCode)
 def VVygAZ(self, path, refCode):
  if path and fileExists(path) and os.system(FFNxGN("which ffmpeg")) == 0:
   pPath = CC96Ar.VVwdi5()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CC6biu.VVfDUr(path)
    cmd += FFNxGN("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVfe5D(self, path):
  if path and fileExists(path):
   err, w, h = self.VVMK2p(path)
   if not err:
    if h > w:
     self.VViDHr(self["myPicF"], w, h, True)
     self.VViDHr(self["myPicB"], w, h, False)
     self.VViDHr(self["myPic"] , w, h, False)
   self.picViewer = CCSdHC.VV302x(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VViDHr(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVMK2p(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFN7zW(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VV0PUS(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FF6TiS(chName, VVpkep)
  txt += self.VVcOV6(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FF6TiS(state, VVsIVN)
   txt += "State\t: %s\n" % state
  w = FFIO7o(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFIO7o(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVE6rQ(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVcOV6(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVcOV6(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVcOV6(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVnH3z()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVs4ZN()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CC6biu.VVPtQu(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FF6TiS("Stream-Relay" if FFabwQ(decodedUrl) else "IPTV", VVOEUI)
   txt += self.VVnPSE(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVTHjy(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCxkcu()
    tpTxt, namespace = tp.VVcvQt(refCode)
    if tpTxt:
     txt += FF6TiS("Tuner:\n", VVpkep)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FF6TiS("Codes:\n", VVpkep)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVcOV6(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVcOV6(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVcOV6(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVcOV6(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVcOV6(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVcOV6(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVcOV6(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVcOV6(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVcOV6(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVE6rQ(info):
  if info:
   aspect = FFIO7o(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVcOV6(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFIO7o(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVda6P(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVda6P(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVnH3z(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VVs4ZN(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVTHjy(self, refCode, iptvRef, chName):
  refCode = FFgjov(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFu1EI(VVMOat + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFu1EI(VVMOat + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VVVC4T = []
  tmpRefCode = FFyQaB(refCode)
  for item in fList:
   path = VVMOat + item
   if fileExists(path):
    txt = FFu1EI(path)
    if tmpRefCode in FFyQaB(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVVC4T.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VVVC4T:
   if len(VVVC4T) == 1:
    txt += "%s\t: %s%s\n" % (FF6TiS("Bouquet", VVpkep), VVVC4T[0][0], " (%s)" % VVVC4T[0][1] if VVh0o2 else "")
   else:
    txt += FF6TiS("Bouquets:\n", VVpkep)
    for ndx, item in enumerate(VVVC4T):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVh0o2 else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVnPSE(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFiRgM(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCwh19()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVKFVK(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FF6TiS("URL:", VVOEUI) + "\n%s\n" % self.VVMJtQ(decodedUrl)
  else:
   txt = "\n"
   txt += FF6TiS("Reference:", VVOEUI) + "\n%s\n" % refCode
  return txt
 def VVMJtQ(self, url):
  if not FFabwQ(url):
   span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
   if span:
    url = span.group(1)
   if not VVks1Y:
    url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return FFyQaB(url)
 def VVI508(self, decodedUrl):
  if not FFpySX():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCCu2Z.VVERnQ(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCCu2Z.VVex4B(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVvsOd(tDict)
   elif uType == "movie" : epg, picUrl = CC6biu.VVL0r4(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVvsOd(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCCu2Z.VVU8hy(item, "title"    , is_base64=True )
     lang    = CCCu2Z.VVU8hy(item, "lang"         ).upper()
     description   = CCCu2Z.VVU8hy(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCCu2Z.VVU8hy(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCCu2Z.VVU8hy(item, "start_timestamp"      )
     stop_timestamp  = CCCu2Z.VVU8hy(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCCu2Z.VVU8hy(item, "stop_timestamp"       )
     now_playing   = CCCu2Z.VVU8hy(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVZ51O, ""
      else     : color, txt = VVsIVN , "    (CURRENT EVENT)"
      epg += FF6TiS("_" * 32 + "\n", VVPYB5)
      epg += FF6TiS("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FF6TiS(description, VVsvZg)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = CC2gVv.VVcLdy(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)], longDescDays=7)
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVL0r4(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCCu2Z.VVU8hy(item, "movie_image" )
    genre  = CCCu2Z.VVU8hy(item, "genre"   ) or "-"
    plot  = CCCu2Z.VVU8hy(item, "plot"   ) or "-"
    cast  = CCCu2Z.VVU8hy(item, "cast"   ) or "-"
    rating  = CCCu2Z.VVU8hy(item, "rating"   ) or "-"
    director = CCCu2Z.VVU8hy(item, "director"  ) or "-"
    releasedate = CCCu2Z.VVU8hy(item, "releasedate" ) or "-"
    duration = CCCu2Z.VVU8hy(item, "duration"  ) or "-"
    try:
     lang = CCCu2Z.VVU8hy(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FF6TiS(cast, VVsvZg)
    epg += "Plot:\n%s"    % FF6TiS(plot, VVsvZg)
   except:
    pass
  return epg, movie_image
 def VVbB94(self):
  if VVks1Y:
   def VVcOV6(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVcOV6(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCwh19()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVKFVK(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVcOV6(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (VVtc24, txt))
   FFtMfC(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVLbYm(SELF):
  if not CC6kXN.VVv4ri(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(SELF)
  err = url =  fSize = resumable = ""
  if FFa4u4(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCwh19.VVNGLS(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCwh19.VVqqlL(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFnHzu(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCr5c7.VVJv7c(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FF6TiS(" (M3U/M3U8 File)", VVsvZg)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCBXuV.VVFKg3(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVCvCu(subj, val):
   return "%s\n%s\n\n" % (FF6TiS("%s:" % subj, VVpkep), val)
  title = "File Size"
  txt  = VVCvCu(title , fSize or "?")
  txt += VVCvCu("Name" , chName)
  txt += VVCvCu("URL" , url)
  if resumable: txt += VVCvCu("Supports Download-Resume", resumable)
  if err  : txt += FF6TiS("Error:\n", VVsIVN) + err
  FFJRXg(SELF, txt, title=title)
 @staticmethod
 def VVPtQu(SELF):
  fPath, fDir, fName = CCr5c7.VVt1SH(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVfDUr(path):
  return "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
 @staticmethod
 def VVvYZX(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CC96Ar.VVwdi5() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VVKJhs(serv):
  isLocal = isIptv = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if FF2IUY(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFSeor(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCwh19():
 def __init__(self):
  self.VVO1en   = ""
  self.VVQtHS    = ""
  self.VVfphO   = ""
  self.VVSK5y = ""
  self.VVybfO  = ""
  self.VVC50x = 0
  self.VVtdUV    = ""
  self.VVeI9c   = "#f#11ffffaa#User"
  self.VV9HXW   = "#f#11aaffff#Server"
 def VVS2Ka(self, url, mac, ph1="", VVozbc=True):
  self.VVO1en   = ""
  self.VVQtHS    = ""
  self.VVfphO   = ""
  self.VVSK5y = ""
  self.VVybfO  = ""
  self.VVC50x = 0
  self.VVtdUV    = {"s": "/server/load.php", "p": "/portal.php"}.get(ph1, "")
  host = self.VVg8rp(url)
  if not host:
   if VVozbc:
    self.VVbCAY("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVM83e(mac)
  if not host:
   if VVozbc:
    self.VVbCAY("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVO1en = host
  self.VVQtHS  = mac
  return True
 def VVg8rp(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVM83e(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVQhYQ(self):
  res, err = self.VVduQC(self.VVMUI1())
  if "404" in err:
   if self.VVO1en.endswith("/c"):
    self.VVO1en = self.VVO1en[:-2]
    res, err = self.VVduQC(self.VVMUI1())
   elif self.VVO1en.endswith("/stalker_portal"):
    self.VVO1en = self.VVO1en[:-15]
    res, err = self.VVduQC(self.VVMUI1())
   else:
    self.VVO1en += "/c"
    res, err = self.VVduQC(self.VVMUI1())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCCu2Z.VVU8hy(tDict["js"], "token")
    rand  = CCCu2Z.VVU8hy(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVWK0O(self, VVozbc=True):
  if not self.VVtdUV:
   self.VVtdUV = self.VVhjJ9()
  err = blkMsg = FFcZi2Txt = ""
  try:
   token, rand, err = self.VVQhYQ()
   if token:
    self.VVfphO = token
    self.VVSK5y = rand
    if rand:
     self.VVC50x = 2
    prof, retTxt = self.VVyQ0T(True)
    if prof:
     self.VVybfO = retTxt
     if any(x in retTxt for x in ("device_id mismatch", "old firmware")):
      self.VVC50x = 3
      prof, retTxt = self.VVyQ0T(False)
      if retTxt:
       self.VVybfO = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFcZi2Txt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFcZi2Txt: tErr += "\n%s" % FFcZi2Txt
  if VVozbc:
   self.VVbCAY(tErr)
  return "", "", tErr
 def VVhjJ9(self):
  try:
   import requests
   url = self.VV99Y1()
   jsFile = "xpcom.common.js"
   res = requests.get("%s/stalker_portal/c/%s" % (url, jsFile), headers=CCwh19.VVqqlL(), stream=True, timeout=2)
   if not res.ok:
    res = requests.get("%s/c/%s" % (url, jsFile), headers=CCwh19.VVqqlL(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    patt = ""
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r"\s*var\s+pattern\s*=\s*\/(.+)\/\s*;", line, IGNORECASE)
      if span:
       patt = span.group(1)
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       if "portal_path" in line:
        if patt.endswith("*\/(.)*") : url += "/c"
        else      : url += "/stalker_portal"
       self.VVO1en = url
       return span.group(1)
  except:
   pass
  return "/server/load.php"
 def VV99Y1(self):
  url = self.VVO1en.rstrip("/")
  if url.endswith("/c")    : url = url[:-2]
  if url.endswith("/stalker_portal") : url = url[:-15]
  return url
 def VVgKin(self, url, isJsFile=False):
  import requests
  jsFile = "xpcom.common.js" if isJsFile else "version.js"
  res, err = self.VVduQC("%s/stalker_portal/c/%s" % (url, jsFile))
  if err:
   res, err = self.VVduQC("%s/c/%s" % (url, jsFile))
  if not err and res.ok and "javascript" in res.headers.get("content-type"):
   if isJsFile:
    return res.text, ""
   else:
    span = iSearch(r"var\s+ver\s*=\s*'(.+)'", res.text, IGNORECASE)
    if span:
     return span.group(1), ""
  return "", err
 def VVyQ0T(self, capMac):
  res, err = self.VVduQC(self.VVoBFW(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCCu2Z.VVU8hy(tDict["js"], "block_%s" % word)
    FFcZi2Txt = CCCu2Z.VVU8hy(tDict["js"], word)
    return tDict, FFcZi2Txt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVoBFW(self, capMac):
  param = ""
  if self.VVybfO or self.VVSK5y:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVQtHS.upper() if capMac else self.VVQtHS.lower(), self.VVSK5y))
  return self.VVmQyq() + "type=stb&action=get_profile" + param
 exec(FFHC0y("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gPSAiJmF1dGhfc2Vjb25kX3N0ZXA9MSZod192ZXJzaW9uPTIuMTctSUItMDAmaHdfdmVyc2lvbl8yPTYyJnNuPSVzJmRldmljZV9pZD0lcyZkZXZpY2VfaWQyPSVzJnNpZ25hdHVyZT0lcyIgJSAoSWRbMF0sIElkWzFdLCBJZFsxXSwgSWRbMl0pDQogcmV0dXJuIHBhcmFtICsgJyZ2ZXI9UGxheWVyIEVuZ2luZSB2ZXJzaW9uOiAweDU4YyZtZXRyaWNzPXsibWFjIjoiJXMiLCJzbiI6IiVzIiwidHlwZSI6IlNUQiIsIm1vZGVsIjoiTUFHMjUwIiwicmFuZG9tIjoiJXMifScgJSAoSWRbM10sIElkWzBdLCBJZFs0XSkNCmRlZiBnZXRNb3JlQXV0aF9JRHMoc2VsZiwgbSwgcik6DQogaW1wb3J0IGhhc2hsaWINCiBtYWNVdGY4ID0gbS5lbmNvZGUoJ3V0Zi04JykNCiBzID0gaGFzaGxpYi5tZDUobWFjVXRmOCkuaGV4ZGlnZXN0KCkudXBwZXIoKVs6MTNdDQogcmV0dXJuIHMsIGhhc2hsaWIuc2hhMjU2KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKCksIGhhc2hsaWIuc2hhMjU2KChzICsgbSkuZW5jb2RlKCd1dGYtOCcpKS5oZXhkaWdlc3QoKS51cHBlcigpLCBtLCBy"))
 def VVaE54(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVZpGu()
  if len(rows) < 10:
   rows = self.VVZ9D5()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVO1en ))
   rows.append(("MAC (from URL)" , self.VVQtHS ))
   rows.append(("Token"   , self.VVfphO ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVeI9c  , "MAC" , self.VVQtHS ))
   rows.append(("2", self.VV9HXW, "Host" , self.VVO1en ))
   rows.append(("2", self.VV9HXW, "Token" , self.VVfphO ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVMRAF(self, isPhp=True, VVozbc=False):
  token, profile, tErr = self.VVWK0O(VVozbc)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VVo16T()
  res, err = self.VVduQC(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCCu2Z.VVU8hy(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFXjqJ(span.group(2))
     pass1 = FFXjqJ(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VVZpGu(self):
  m3u_Url, host, user1, pass1, err = self.VVMRAF()
  rows = []
  if m3u_Url:
   res, err = self.VVduQC(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFrOxn(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVeI9c, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFrOxn(int(val))
      else      : val = str(val)
      rows.append(("2", self.VV9HXW, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVZ9D5(self):
  token, profile, tErr = self.VVWK0O()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFp8pW(val): val = FFHC0y(val.decode("UTF-8"))
     else     : val = self.VVQtHS
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFrOxn(int(parts[1]))
      if parts[2] : ends = FFrOxn(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFrOxn(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVI0Qk(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVWK0O(VVozbc=False)
  if not token:
   return ""
  crLinkUrl = self.VVkpJD(mode, chCm, epNum, epId)
  res, err = self.VVduQC(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCCu2Z.VVU8hy(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVmQyq(self):
  return self.VVO1en + self.VVtdUV + "?"
 def VVMUI1(self):
  return self.VVmQyq() + "type=stb&action=handshake&token=&mac=%s" % self.VVQtHS
 def VVvu0w(self, mode):
  url = self.VVmQyq() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVK1C7(self, catID):
  return self.VVmQyq() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVtLxf(self, mode, catID, page):
  url = self.VVmQyq() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVUzQS(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VVmQyq() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVnP8S(self, mode, catID):
  return self.VVmQyq() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVkpJD(self, mode, chCm, serCode, serId):
  url = self.VVmQyq() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=0&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVo16T(self):
  return self.VVmQyq() + "type=itv&action=create_link"
 def VVkJgo(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VV2JiH(catID, stID, chNum)
  query = self.VV99LN(mode, self.VVtdUV[1:2], FFLLdk(host), FFLLdk(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VV99LN(self, mode, ph1, host, mac, serCode, serId, chCm):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVKFVK(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VV99LN(mode, ph1, host, mac, epNum, epId, FFXjqJ(chCm))
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFHC0y(host)
  mac   = FFHC0y(mac)
  valid = False
  if self.VVg8rp(playHost) and self.VVg8rp(host) and self.VVg8rp(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVduQC(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCwh19.VVqqlL()
   if self.VVfphO:
    headers["Authorization"] = "Bearer %s" % self.VVfphO
   if useCookies : cookies = {"mac": self.VVQtHS, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok:
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVviU3(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCwh19.VVqqlL(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVqqlL():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVl7PH(host, mac, tType, action, keysList=None):
  myPortal = CCwh19()
  ph1 = "s"
  pref = "/portal.php" if par == "p" else "/server/load.php"
  ok = myPortal.VVS2Ka(host, mac, ph1)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVWK0O(VVozbc=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s%s?type=%s&action=%s" % (host, ph1, tType, action)
  res, err = myPortal.VVduQC(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VVr1cS(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VVr1cS(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVbCAY(self, err, title="Portal Browser"):
  FFnHzu(self, str(err), title=title)
 def VV742P(self, mode):
  if   mode in ("itv"  , CCCu2Z.VVkN6E , CCCu2Z.VV2QgQ)  : return "Live"
  elif mode in ("vod"  , CCCu2Z.VVLb5y , CCCu2Z.VVNceW)  : return "VOD"
  elif mode in ("series" , CCCu2Z.VVaI7O , CCCu2Z.VVYpZi) : return "Series"
  else                          : return "IPTV"
 def VVab0I(self, mode, searchName):
  return 'Find in %s : %s' % (self.VV742P(mode), FF6TiS(searchName, VVsvZg))
 def VVHRKw(self, catchup=False):
  VVegP0 = []
  VVegP0.append(("Live"    , "live"  ))
  VVegP0.append(("VOD"    , "vod"   ))
  VVegP0.append(("Series"   , "series"  ))
  if catchup:
   VVegP0.append(VVHMBI)
   VVegP0.append(("Catch-up TV" , "catchup"  ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Account Info." , "accountInfo" ))
  return VVegP0
 @staticmethod
 def VVx1dg(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCwh19()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVKFVK(decodedUrl)
  if valid:
   ok = p.VVS2Ka(host, mac, ph1, VVozbc=False)
   if ok:
    m3u_Url, host, user1, pass1, err = p.VVMRAF(isPhp=False, VVozbc=False)
    streamId = CCwh19.VVmwQr(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err
 @staticmethod
 def VVmwQr(decodedUrl):
  p = CCwh19()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVKFVK(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFHC0y(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVNGLS(decodedUrl):
  p = CCwh19()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVKFVK(decodedUrl)
  if valid:
   if CCwh19.VVYLSF(chCm):
    return FFyQaB(chCm)
   else:
    ok = p.VVS2Ka(host, mac, ph1, VVozbc=False)
    if ok:
     try:
      chUrl = p.VVI0Qk(mode, chCm, epNum, epId)
      return FFyQaB(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VVYLSF(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
class CCM7WN(CCwh19):
 def __init__(self):
  CCwh19.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VV7eRj(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVKFVK(decodedUrl)
  if valid:
   if self.VVS2Ka(host, mac, ph1, VVozbc=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVEJxa(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVI0Qk(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CCwh19.VVYLSF(self.chCm):
   chUrl = FFyQaB(self.chCm)
   chUrl = FFXjqJ(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVS9TO(chUrl)
  bPath = CCu3Fm.VVwd5l()
  if newIptvRef:
   if passedSELF:
    FFGrAa(passedSELF, newIptvRef, VVMo36=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFGrAa(self, newIptvRef, VVMo36=False, fromPrtalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VV2fvE(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VVS9TO(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VV2fvE(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("&ph1=s", "&ph1=p", "&ph1=")
   for param in params: newPar = newPar.replace(param, "")
   lines = FF5DO4(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for param in params: filePar = filePar.replace(param, "")
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFmB3r()
class CCNhb1(CCM7WN):
 def __init__(self, passedSession):
  CCM7WN.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVUjM1(VVdJ3x  )
  Main_Menu.VVUjM1(VVZtGY)
  Main_Menu.VVUjM1(VVYN98  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVfSxZ, iPlayableService.evEOF: self.VVHF5A, iPlayableService.evEnd: self.VVA4HF})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVhwdC)
  except:
   self.timer2.callback.append(self.VVhwdC)
  self.timer2.start(3000, False)
  self.VVhwdC()
 def VVhwdC(self):
  if not CFG.downloadMonitor.getValue():
   self.VVvV5T()
   return
  lst = CCBXuV.VVRszV()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFREV4(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCBXuV.VVG9SO(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin:
    self.dnldWin = self.passedSession.instantiateDialog(CCyHS0, txt, 30)
    self.dnldWin.instance.move(ePoint(30, 20))
    self.dnldWin.show()
    FFmknE(self.dnldWin["myWinTitle"], "#440000", 1)
   else:
    self.dnldWin["myWinTitle"].setText(txt)
  elif self.dnldWin:
   self.VVvV5T()
 def VVvV5T(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVfSxZ(self):
  self.startTime = iTime()
 def VVHF5A(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self.passedSession, isFromSession=True)
    if iptvRef and not FFa4u4(decodedUrl):
     self.isFromEOF = True
     CCBMOM(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVA4HF(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVyj7O)
  except:
   self.timer1.callback.append(self.VVyj7O)
  self.timer1.start(100, True)
 def VVyj7O(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VV7eRj(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCM2Fd.VVUYe0:
       self.isFromEOF = False
       self.VVEJxa(self.passedSession, isFromSession=True)
class CCDbht():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-z0-9\/\-._:|\]\[]+[\])|:](.+)")
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "xxi", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.adultWords2 = ("\u042d\u0440\u043e\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0435", "dla doros\u0142ych")
 def VVkO9i(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCCu2Z.VVxbqQ(name):
   return CCCu2Z.VVd1Bb(name)
  name = self.VVtY8c(name)
  return name.strip() or name
 def VVtY8c(self, name):
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     return tName
  return name
 def VVpSN0(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVtY8c(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVYVet(self, name):
  if self.hideAdult:
   if any(x in name.lower() for x in self.adultWords):
    return ""
   elif any(x in name.encode('ascii', 'backslashreplace').decode('utf-8').lower() for x in self.adultWords2):
    return ""
  return name.strip()
 def VVzzEe(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVeJdV(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CC6kXN(CCwh19):
 def __init__(self):
  CCwh19.__init__(self)
 def VV9Rnv(self):
  if CC6kXN.VVv4ri(self):
   FFG53m(self, BF(self.VVC2Nt, 2), title="Searching ...")
 def VVm08Q(self, winSession, url, mac):
  self.curUrl = url
  if CC6kXN.VVv4ri(self):
   if self.VVS2Ka(url, mac):
    FFG53m(winSession, self.VVh1PZ, title="Checking Server ...")
   else:
    FFnHzu(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVYoAR(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CCBlwj.VV2bQD(path, self)
   if enc == -1:
    return
   self.session.open(CCDe3n, barTheme=CCDe3n.VVzwEk
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VV5cXZ, path, enc)
       , VVuJdT = BF(self.VVumkS, menuInstance, path))
 def VV5cXZ(self, path, enc, VVEkKt):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVEkKt.VVQWYw(totLines)
  VVEkKt.VVyzJx = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVEkKt or VVEkKt.isCancelled:
     return
    VVEkKt.VVHjIy(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVg8rp(url)
     mac  = self.VVM83e(mac)
     if host and mac and VVEkKt:
      VVEkKt.VVyzJx.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVg8rp(url)
      mac  = self.VVM83e(mac)
      if host and mac and not mac.startswith("AC") and VVEkKt:
       VVEkKt.VVyzJx.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVumkS(self, menuInstance, path, VVLnvr, VVyzJx, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVyzJx:
   VVIqI1  = ("Home Menu"  , FFaoGB            , [])
   VVljWo = ("Edit File"  , BF(self.VVTtyw, path)       , [])
   VVdn6T = ("M3U Options" , self.VV18hI         , [])
   VVDB15 = ("Check & Filter" , BF(self.VV7oTu, menuInstance, path), [])
   VV91FP  = ("Select"   , self.VV8tdf      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVsZoP  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVR0r4 = FFqiz1(self, None, title=title, header=header, VVVC4T=VVyzJx, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VV91FP=VV91FP, VVIqI1=VVIqI1, VVdn6T=VVdn6T, VVljWo=VVljWo, VVDB15=VVDB15, VVXbiY="#0a001122", VVVy8H="#0a001122", VVvi08="#0a001122", VVTrrJ="#00004455", VVcd71="#0a333333", VVVygK="#11331100", VVSwEr=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VVLnvr:
    FFtMfC(VVR0r4, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVLnvr:
    FFnHzu(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VV18hI(self, VVR0r4, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVegP0 = []
  VVegP0.append(("Browse as M3U"  , "browse"))
  VVegP0.append(("Download M3U File" , "downld"))
  FFJcY1(self, BF(self.VVihAz, VVR0r4, host, mac), title=title, VVegP0=VVegP0, width=600, VV4p4D=True)
 def VVihAz(self, VVR0r4, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FFG53m(VVR0r4, BF(self.VVxu5v, VVR0r4, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFWBJu(self, BF(FFG53m, VVR0r4, BF(self.VVxu5v, VVR0r4, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVxu5v(self, VVR0r4, title, host, mac, item):
  p = CCwh19()
  m3u_Url = ""
  ok = p.VVS2Ka(host, mac, VVozbc=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VVMRAF(VVozbc=False)
  if m3u_Url:
   if   item == "browse": self.VVM9OU(title, m3u_Url)
   elif item == "downld": self.VVPysf(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FFnHzu(self, err or "No response from Server !", title=title)
 def VV8tdf(self, VVR0r4, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVm08Q(VVR0r4, url, mac)
 def VVTtyw(self, path, VVR0r4, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCzWmm(self, path, VVuJdT=BF(self.VVXFaR, VVR0r4), curRowNum=rowNum)
  else    : FFlkXm(self, path)
 def VV7oTu(self, menuInstance, path, VVR0r4, title, txt, colList):
  self.session.open(CCDe3n, barTheme=CCDe3n.VVEpKA
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VV5POX, VVR0r4)
      , VVuJdT = BF(self.VVQpVI, menuInstance, VVR0r4, path))
 def VV5POX(self, VVR0r4, VVEkKt):
  VVEkKt.VVyzJx = []
  VVEkKt.VVQWYw(VVR0r4.VVsBGq())
  for row in VVR0r4.VVtxRM():
   if not VVEkKt or VVEkKt.isCancelled:
    return
   VVEkKt.VVHjIy(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVS2Ka(host, mac, VVozbc=False):
    token, profile, tErr = self.VVWK0O(VVozbc=False)
    if token and VVEkKt and not VVEkKt.isCancelled:
     res, err = self.VVduQC(self.VVvu0w("itv"))
     if res and VVEkKt and not VVEkKt.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVEkKt.VVHjIy(0, showFound=True)
       VVEkKt.VVyzJx.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVEkKt:
    return
 def VVQpVI(self, menuInstance, VVR0r4, path, VVLnvr, VVyzJx, threadCounter, threadTotal, threadErr):
  if VVyzJx:
   VVR0r4.close()
   menuInstance.close()
   newPath = "%s_OK_%s.txt" % (path, FFxsfY())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVyzJx:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FF6TiS(str(threadCounter), VVsIVN)
    skipped = FF6TiS(str(threadTotal - threadCounter), VVsIVN)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVyzJx)
   txt += "%s\n\n%s"    %  (FF6TiS("Result File:", VVpkep), newPath)
   FFJRXg(self, txt, title="Accessible Portals")
  elif VVLnvr:
   FFnHzu(self, "No portal access found !", title="Accessible Portals")
 def VVR2ce(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFHC0y(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVh1PZ(self):
  token, profile, tErr = self.VVWK0O()
  if token:
   dots = "." * self.VVC50x
   dots += "+" if self.VVtdUV[1:2] == "p" else ""
   VVegP0  = self.VVHRKw()
   OKBtnFnc = self.VV5Yrv
   infoBtnFnc = self.VVe4hF
   VVKP6N = ("Home Menu", FFaoGB)
   VVV5x7= ("Add to Menu", BF(CCCu2Z.VVUPPU, self, True, self.VVO1en + "\t" + self.VVQtHS))
   VVZKXi = ("Bookmark Server", BF(CCCu2Z.VVUjaF, self, True, self.VVO1en + "\t" + self.VVQtHS))
   FFJcY1(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVQtHS, dots), VVegP0=VVegP0, OKBtnFnc=OKBtnFnc, infoBtnFnc=infoBtnFnc, VVKP6N=VVKP6N, VVV5x7=VVV5x7, VVZKXi=VVZKXi)
 def VV5Yrv(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFG53m(menuInstance, BF(self.VVshRb, mode), title="Reading Categories ...")
   else : FFG53m(menuInstance, BF(self.VVRVYt, menuInstance, title), title="Reading Account ...")
 def VVRVYt(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVaE54(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVQtHS)
  VVIqI1  = ("Home Menu" , FFaoGB           , [])
  VVdn6T  = None
  if VVks1Y:
   VVdn6T = ("Get JS"  , BF(self.VV4tMX, self.VV99Y1()) , [])
  if totCols == 2:
   VVDB15 = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVDB15 = ("More Info.", BF(self.VVnx3K, menuInstance)    , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFqiz1(self, None, title=title, width=1200, header=header, VVVC4T=rows, VVx2iV=widths, VVwwGj=26, VVIqI1=VVIqI1, VVdn6T=VVdn6T, VVDB15=VVDB15, VVXbiY="#0a00292B", VVVy8H="#0a002126", VVvi08="#0a002126", VVTrrJ="#00000000", searchCol=searchCol)
 def VV4tMX(self, url, VVR0r4, title, txt, colList):
  FFG53m(VVR0r4, BF(self.VV3Cx0, url), title="Getting JS ...")
 def VV3Cx0(self, url):
  txt  = "// Host\t: %s\t%s\n" % (url, self.VVQtHS)
  ver, err = self.VVgKin(url)
  txt += "// Version\t: %s\n\n" % (ver or err)
  js , err = self.VVgKin(url, isJsFile=True)
  if err: txt += "Error : %s" % err
  else  : txt += js
  FFJRXg(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VVnx3K(self, menuInstance, VVR0r4, title, txt, colList):
  VVR0r4.cancel()
  FFG53m(menuInstance, BF(self.VVRVYt, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVshRb(self, mode):
  token, profile, tErr = self.VVWK0O()
  if not token:
   return
  res, err = self.VVduQC(self.VVvu0w(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     VV9Xp9 = CCDbht()
     chList = tDict["js"]
     for item in chList:
      Id   = CCCu2Z.VVU8hy(item, "id"       )
      Title  = CCCu2Z.VVU8hy(item, "title"      )
      censored = CCCu2Z.VVU8hy(item, "censored"     )
      Title = VV9Xp9.VVYVet(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVh0o2:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VV742P(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVXbiY, VVVy8H, VVvi08, VVTrrJ = self.VVrucS(mode)
   mName = self.VV742P(mode)
   VV91FP   = ("Show List"   , BF(self.VVpZY9, mode)   , [])
   VVIqI1  = ("Home Menu"   , FFaoGB        , [])
   if mode in ("vod", "series"):
    VVljWo = ("Find in %s" % mName , BF(self.VVzGbE, mode, False), [])
    VVDB15 = ("Find in Selected" , BF(self.VVzGbE, mode, True) , [])
   else:
    VVljWo = None
    VVDB15 = None
   header   = None
   widths   = (100   , 0  )
   FFqiz1(self, None, title=title, width=1200, header=header, VVVC4T=list, VVx2iV=widths, VVwwGj=30, VVIqI1=VVIqI1, VVljWo=VVljWo, VVDB15=VVDB15, VV91FP=VV91FP, VVXbiY=VVXbiY, VVVy8H=VVVy8H, VVvi08=VVvi08, VVTrrJ=VVTrrJ, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVybfO:
     txt += "\n\n( %s )" % self.VVybfO
   else:
    txt = "Could not get Categories from server!"
   FFnHzu(self, txt, title=title)
 def VVcHPj(self, mode, VVR0r4, title, txt, colList):
  FFG53m(VVR0r4, BF(self.VV6MfY, mode, VVR0r4, title, txt, colList), title="Downloading ...")
 def VV6MfY(self, mode, VVR0r4, title, txt, colList):
  token, profile, tErr = self.VVWK0O()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVduQC(self.VVK1C7(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCCu2Z.VVU8hy(item, "id"    )
      actors   = CCCu2Z.VVU8hy(item, "actors"   )
      added   = CCCu2Z.VVU8hy(item, "added"   )
      age    = CCCu2Z.VVU8hy(item, "age"   )
      category_id  = CCCu2Z.VVU8hy(item, "category_id" )
      description  = CCCu2Z.VVU8hy(item, "description" )
      director  = CCCu2Z.VVU8hy(item, "director"  )
      genres_str  = CCCu2Z.VVU8hy(item, "genres_str"  )
      name   = CCCu2Z.VVU8hy(item, "name"   )
      path   = CCCu2Z.VVU8hy(item, "path"   )
      screenshot_uri = CCCu2Z.VVU8hy(item, "screenshot_uri" )
      series   = CCCu2Z.VVU8hy(item, "series"   )
      cmd    = CCCu2Z.VVU8hy(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VV91FP  = ("Play"    , BF(self.VVu2wZ, mode)       , [])
   VVBSYf = (""     , BF(self.VVLKmm, mode)     , [])
   VVIqI1 = ("Home Menu"   , FFaoGB            , [])
   VVdn6T = ("Download Options" , BF(self.VVf0sf, mode, "sp", seriesName) , [])
   VVljWo = ("Options"   , BF(self.VVrQT7, "pEp", mode, seriesName) , [])
   VVDB15 = ("Posters Mode"  , BF(self.VVarJa, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVsZoP  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFqiz1(self, None, title=seriesName, width=1200, header=header, VVVC4T=list, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VV91FP=VV91FP, VVBSYf=VVBSYf, VVIqI1=VVIqI1, VVdn6T=VVdn6T, VVljWo=VVljWo, VVDB15=VVDB15, lastFindConfigObj=CFG.lastFindIptv, VVXbiY="#0a00292B", VVVy8H="#0a002126", VVvi08="#0a002126", VVTrrJ="#00000000")
  else:
   FFnHzu(self, "Could not get Episodes from server!", title=seriesName)
 def VVzGbE(self, mode, searchInCat, VVR0r4, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVegP0 = []
  VVegP0.append(("Keyboard"  , "manualEntry"))
  VVegP0.append(("From Filter" , "fromFilter"))
  FFJcY1(self, BF(self.VV5L4y, VVR0r4, mode, searchCatId), title="Input Type", VVegP0=VVegP0, width=400)
 def VV5L4y(self, VVR0r4, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFYvs0(self, BF(self.VVbpFw, VVR0r4, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCSAYR(self)
    filterObj.VVnKMp(BF(self.VVbpFw, VVR0r4, mode, searchCatId))
 def VVbpFw(self, VVR0r4, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FFCfiF(CFG.lastFindIptv, searchName)
   title = self.VVab0I(mode, searchName)
   if "," in searchName : FFnHzu(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FFnHzu(self, "Enter at least 3 characters.", title=title)
   else     :
    VV9Xp9 = CCDbht()
    if CFG.hideIptvServerAdultWords.getValue() and VV9Xp9.VVzzEe([searchName]):
     FFnHzu(self, VV9Xp9.VVeJdV(), title=title)
    else:
     self.VVK66J(mode, searchName, "", searchName, searchCatId)
 def VVpZY9(self, mode, VVR0r4, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVK66J(mode, bName, catID, "", "")
 def VVK66J(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CCDe3n, barTheme=CCDe3n.VVzwEk
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVLwdE, mode, bName, catID, searchName, searchCatId)
      , VVuJdT = BF(self.VVKqYN, mode, bName, catID, searchName, searchCatId))
 def VVKqYN(self, mode, bName, catID, searchName, searchCatId, VVLnvr, VVyzJx, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVab0I(mode, searchName)
  else   : title = "%s : %s" % (self.VV742P(mode), bName)
  if VVyzJx:
   VVdn6T = None
   VVljWo = None
   if mode == "series":
    VVXbiY, VVVy8H, VVvi08, VVTrrJ = self.VVrucS("series2")
    VV91FP  = ("Episodes"   , BF(self.VVcHPj, mode)           , [])
   else:
    VVXbiY, VVVy8H, VVvi08, VVTrrJ = self.VVrucS("")
    VV91FP  = ("Play"    , BF(self.VVu2wZ, mode)           , [])
    VVdn6T = ("Download Options" , BF(self.VVf0sf, mode, "vp" if mode == "vod" else "", "") , [])
    VVljWo = ("Options"   , BF(self.VVrQT7, "pCh", mode, bName)      , [])
   VVBSYf = (""      , BF(self.VVP3s4, mode)         , [])
   VVIqI1 = ("Home Menu"    , FFaoGB                , [])
   VVDB15 = ("Posters Mode"   , BF(self.VVarJa, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Category/Genre" , "Logo")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25    , 6  )
   VVsZoP  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT    , CENTER)
   VVR0r4 = FFqiz1(self, None, title=title, header=header, VVVC4T=VVyzJx, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VVIqI1=VVIqI1, VVdn6T=VVdn6T, VVljWo=VVljWo, VVDB15=VVDB15, lastFindConfigObj=CFG.lastFindIptv, VV91FP=VV91FP, VVBSYf=VVBSYf, VVXbiY=VVXbiY, VVVy8H=VVVy8H, VVvi08=VVvi08, VVTrrJ=VVTrrJ, VVSwEr=True, searchCol=1)
   if not VVLnvr:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVR0r4.VVUlFx(VVR0r4.VVUbIN() + tot)
    if threadErr: FFtMfC(VVR0r4, "Error while reading !", 2000)
    else  : FFtMfC(VVR0r4, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFnHzu(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFnHzu(self, "Could not get list from server !", title=title)
 def VVP3s4(self, mode, VVR0r4, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFiqcT(self, fncMode=CC6biu.VVnHsd, portalHost=self.VVO1en, portalMac=self.VVQtHS, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VV3EzK(mode, VVR0r4, title, txt, colList)
 def VVLKmm(self, mode, VVR0r4, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FF6TiS(colList[10], VVsvZg)
  txt += "Description:\n%s" % FF6TiS(colList[11], VVsvZg)
  self.VV3EzK(mode, VVR0r4, title, txt, colList)
 def VV3EzK(self, mode, VVR0r4, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVXTJq(mode, colList)
  refCode, chUrl = self.VVkJgo(self.VVO1en, self.VVQtHS, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFiqcT(self, fncMode=CC6biu.VV2pbT, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVLwdE(self, mode, bName, catID, searchName, searchCatId, VVEkKt):
  try:
   token, profile, tErr = self.VVWK0O()
   if not token:
    return
   if VVEkKt.isCancelled:
    return
   VVEkKt.VVyzJx, total_items, max_page_items, err = self.VV40Kn(mode, catID, 1, 1, searchName, searchCatId)
   if VVEkKt.isCancelled:
    return
   if VVEkKt.VVyzJx and total_items > -1 and max_page_items > -1:
    VVEkKt.VVQWYw(total_items)
    VVEkKt.VVHjIy(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVEkKt.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VV40Kn(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVEkKt.VV2RjU()
     if VVEkKt.isCancelled:
      return
     if list:
      VVEkKt.VVyzJx += list
      VVEkKt.VVHjIy(len(list), True)
  except:
   pass
 def VV40Kn(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVUzQS(mode, searchName, searchCatId, page)
  else   : url = self.VVtLxf(mode, catID, page)
  res, err = self.VVduQC(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VV6o6z(CCCu2Z.VVU8hy(item, "total_items" ))
     max_page_items = self.VV6o6z(CCCu2Z.VVU8hy(item, "max_page_items" ))
     VV9Xp9 = CCDbht()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCCu2Z.VVU8hy(item, "id"    )
      name   = CCCu2Z.VVU8hy(item, "name"   )
      o_name   = CCCu2Z.VVU8hy(item, "o_name"   )
      tv_genre_id  = CCCu2Z.VVU8hy(item, "tv_genre_id" )
      number   = CCCu2Z.VVU8hy(item, "number"   ) or str(counter)
      logo   = CCCu2Z.VVU8hy(item, "logo"   )
      screenshot_uri = CCCu2Z.VVU8hy(item, "screenshot_uri" )
      cmd    = CCCu2Z.VVU8hy(item, "cmd"   )
      censored  = CCCu2Z.VVU8hy(item, "censored"  )
      genres_str  = CCCu2Z.VVU8hy(item, "genres_str"  )
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       span = iSearch(r"stream=(.+)&", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
       else:
        span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      isIcon = "Yes" if picon else ""
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVO1en + picon).replace(sp * 2, sp)
      counter += 1
      name = VV9Xp9.VVkO9i(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd, genres_str, isIcon))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VV6o6z(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVu2wZ(self, mode, VVR0r4, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVXTJq(mode, colList)
  refCode, chUrl = self.VVkJgo(self.VVO1en, self.VVQtHS, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVxbqQ(chName):
   FFtMfC(VVR0r4, "This is a marker!", 300)
  else:
   FFG53m(VVR0r4, BF(self.VViwNp, mode, VVR0r4, chUrl), title="Playing ...")
 def VViwNp(self, mode, VVR0r4, chUrl):
  FFGrAa(self, chUrl, VVMo36=False)
  CCM2Fd.VV8elw(self.session, iptvTableParams=(self, VVR0r4, mode))
 def VVW5yl(self, mode, VVR0r4, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVXTJq(mode, colList)
  refCode, chUrl = self.VVkJgo(self.VVO1en, self.VVQtHS, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVXTJq(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVv4ri(SELF, install=True, cbFnc=None):
  try:
   import requests
   return True
  except:
   if install:
    title = 'Install "Requests"'
    VVegP0 = []
    VVegP0.append((title        , "inst" ))
    VVegP0.append(("Update Packages then %s" % title , "updInst" ))
    FFJcY1(SELF, BF(CC6kXN.VV0tPl, SELF, cbFnc=cbFnc), title='This requires Python "Requests" library', VVegP0=VVegP0)
   return False
 @staticmethod
 def VV0tPl(SELF, item=None, cbFnc=None):
  if item:
   cmdUpd = FFQz9o(VVvVUt, "")
   if cmdUpd:
    cmdInst = FFiwac(VVerzX, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFYyBc(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library', VVhgup=cbFnc)
   else:
    FFw6dW(SELF)
class CCCu2Z(Screen, CC6kXN, CCEwHg):
 VV9f9k    = 0
 VVultd    = 1
 VViSKT    = 2
 VVcxqd    = 3
 VVEyF7     = 4
 VVQzFk     = 5
 VViIq6     = 6
 VV0h6M     = 7
 VVN17r     = 8
 VV3STL     = 9
 VVQZ8G      = 10
 VVf7jt     = 11
 VVgvvn     = 12
 VVCOoH     = 13
 VVXHbo     = 14
 VVLBt0      = 15
 VVtT0S      = 16
 VVmg1J      = 17
 VVclAt      = 18
 VVKCfI      = 19
 VVXLZs    = 0
 VVkN6E   = 1
 VVLb5y   = 2
 VVaI7O   = 3
 VVAaer  = 4
 VVv4Ht  = 5
 VV2QgQ   = 6
 VVNceW   = 7
 VVYpZi  = 8
 VVvSNq  = 9
 VV5oTq  = 10
 VVcGEG = 0
 VV1V9V = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFAJVu(VVtBbU, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28, topRightBtns=1)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVR0r4    = None
  self.tableTitle     = "IPTV Channels List"
  self.VVgvNCData    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CCCu2Z.VVfoZV(atLeastOne=True)
  self.isFirstTime    = True
  self.curUrl      = ""
  CC6kXN.__init__(self)
  VVegP0 = self.VVLIrn()
  FFsw8F(self, title="IPTV", VVegP0=VVegP0)
  self["myActionMap"].actions.update({
   "menu" : self.VVLbUX
  })
  self["myMenu"].onSelectionChanged.append(self.VVVZHz)
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self["myMenu"].setList(self.VVLIrn())
  FFUSMR(self)
  FF6aqB(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFCoOh(self["myMenu"])
   FFkraF(self)
   if self.m3uOrM3u8File:
    self.VVwkvc(self.m3uOrM3u8File, (0, (), False, ""))
 def VVVZHz(self):
  if self["myMenu"].getCurrent()[1] in ("VV1j6R", "VVtGqgPortal") : self["keyMenu"].show()
  else                      : self["keyMenu"].hide()
 def VVLbUX(self):
  if self["myMenu"].getVisible():
   title = self["myMenu"].getCurrent()[0]
   item  = self["myMenu"].getCurrent()[1]
   if   item == "VVtGqgPortal" : confItem = CFG.favServerPortal
   elif item == "VV1j6R" : confItem = CFG.favServerPlaylist
   else         : return
   FFWBJu(self, BF(self.VVMC7H, confItem), 'Remove from menu ?', title=title)
 def VVMC7H(self, confItem):
  FFCfiF(confItem, "")
  self.VVoCo0()
 def VVLIrn(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VVPN93
  VVegP0 = []
  if isFav1: VVegP0.append((c +  "Favourite Playlist Server"   , "VV1j6R" ))
  if isFav2: VVegP0.append((c +  "Favourite Portal Server"    , "VVtGqgPortal" ))
  VVegP0.append(("IPTV Server Browser (from Playlists)"     , "VVgvNC_fromPlayList" ))
  VVegP0.append(("IPTV Server Browser (from Portal List)"    , "VVgvNC_fromMac"  ))
  VVegP0.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VVgvNC_fromM3u"  ))
  qUrl, iptvRef = CCCu2Z.VVBzpG(self)
  item = "IPTV Server Browser (from Current Channel)"
  if qUrl or "chCode" in iptvRef : VVegP0.append((item     , "VVgvNC_fromCurrChan" ))
  else       : VVegP0.append((item     ,       ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("M3U/M3U8 File Browser"        , "VVYXDx"   ))
  if self.iptvFileAvailable:
   VVegP0.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVegP0.append(VVHMBI)
  item1 = "Update Current Bouquet EPG (from IPTV Server)"
  item2 = "Update Current Bouquet PIcons (from IPTV Server)"
  if qUrl or "chCode" in iptvRef:
   VVegP0.append((item1            , "refreshIptvEPG"   ))
   VVegP0.append((item2            , "refreshIptvPicons"  ))
  else:
   VVegP0.append((item1            ,       ))
   VVegP0.append((item2            ,       ))
  if self.iptvFileAvailable:
   VVegP0.append(VVHMBI)
   c1, c2 = VVJCMd, VVpkep
   t1 = FF6TiS("auto-match names", VVPN93)
   t2 = FF6TiS("from xml file"  , VVPN93)
   VVegP0.append((c1 + "Count Available IPTV Channels"    , "VVTjKa"    ))
   VVegP0.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVegP0.append(VVHMBI)
   VVegP0.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVegP0.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VV6CmU" ))
   VVegP0.append((VVnKNv + "More Reference Tools ..."  , "VVB6zD"   ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Reload Channels and Bouquets"       , "VVcNqo"   ))
  VVegP0.append(VVHMBI)
  if not CCBXuV.VVGcd9():
   VVegP0.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVegP0.append(("Download Manager ... No donwloads"    ,       ))
  return VVegP0
 def VVfx3d(self, item):
  self.curUrl = ""
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVzbfv"   : self.VVzbfv()
   elif item == "VVCYaV" : FFWBJu(self, self.VVCYaV, "Change Current List References to Unique Codes ?")
   elif item == "VVogQg_rows" : FFWBJu(self, BF(FFG53m, self.VVR0r4, self.VVogQg), "Change Current List References to Identical Codes ?")
   elif item == "VVVlf5"   : self.VVVlf5(tTitle)
   elif item == "VVTz7l"   : self.VVTz7l(tTitle)
   elif item == "VV1j6R" : self.VVtGqg(False)
   elif item == "VVtGqgPortal" : self.VVtGqg(True)
   elif item == "VVgvNC_fromPlayList" : FFG53m(self, BF(self.VVC2Nt, 1), title=title)
   elif item == "VVgvNC_fromM3u"  : FFG53m(self, BF(self.VVtRxU, CCCu2Z.VVcGEG), title=title)
   elif item == "VVgvNC_fromMac"  : self.VV9Rnv()
   elif item == "VVgvNC_fromCurrChan" : self.VVYFiO()
   elif item == "VVYXDx"   : self.VVYXDx()
   elif item == "iptvTable_all"   : FFG53m(self, BF(self.VVdSsm, self.VV9f9k), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : CCCu2Z.VVvP5F(self)
   elif item == "refreshIptvPicons"  : self.VVAGpV()
   elif item == "VVTjKa"    : FFG53m(self, self.VVTjKa)
   elif item == "copyEpgPicons"   : self.VVFwK4(False)
   elif item == "renumIptvRef_fromFile" : self.VVFwK4(True)
   elif item == "VV6CmU" : FFWBJu(self, BF(FFG53m, self, self.VV6CmU), VVFNjG="Continue ?")
   elif item == "VVB6zD"    : self.VVB6zD()
   elif item == "VVcNqo"   : FFG53m(self, BF(CCcecd.VVcNqo, self))
   elif item == "dload_stat"    : CCBXuV.VVmWLp(self)
 def VVYXDx(self):
  if CC6kXN.VVv4ri(self):
   FFG53m(self, BF(self.VVtRxU, CCCu2Z.VV1V9V), title="Searching ...")
 def VVu0DR(self):
  global VVtXrR
  VVtXrR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVfx3d(item)
 def VVdSsm(self, mode):
  VVzto2 = self.VVmOew(mode)
  if VVzto2:
   VVdn6T = ("Current Service", self.VVS58H , [])
   VVljWo = ("Options"  , self.VVT2mm   , [])
   VVDB15 = ("Filter"   , self.VVOCAp   , [])
   VV91FP  = ("Play"   , BF(self.VVMDWM)  , [])
   VVBSYf = (""    , self.VVUkMp    , [])
   VVqfcE = (""    , self.VVcry2     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VVsZoP  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FFqiz1(self, None, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26
     , VV91FP=VV91FP, VVdn6T=VVdn6T, VVljWo=VVljWo, VVDB15=VVDB15, VVBSYf=VVBSYf, VVqfcE=VVqfcE
     , VVXbiY="#0a00292B", VVVy8H="#0a002126", VVvi08="#0a002126", VVTrrJ="#00000000", VVSwEr=True, searchCol=1)
  else:
   if mode == self.VV3STL: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFnHzu(self, err)
 def VVcry2(self, VVR0r4, title, txt, colList):
  self.VVR0r4 = VVR0r4
 def VVT2mm(self, VVR0r4, title, txt, colList):
  VVegP0 = []
  VVegP0.append(("Add Current List to a New Bouquet"    , "VVzbfv"  ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Change Current List References to Unique Codes" , "VVCYaV"))
  VVegP0.append(("Change Current List References to Identical Codes", "VVogQg_rows" ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Share Reference with DVB Service (manual entry)" , "VVVlf5"   ))
  VVegP0.append(("Share Reference with DVB Service (auto-find)"  , "VVTz7l"   ))
  FFJcY1(self, self.VVfx3d, title="IPTV Tools", VVegP0=VVegP0)
 def VVOCAp(self, VVR0r4, title, txt, colList):
  VVegP0 = []
  VVegP0.append(("All"         , "all"   ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Prefix of Selected Channel"   , "sameName" ))
  VVegP0.append(("Suggest Words from Selected Channel" , "partName" ))
  VVegP0.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVegP0.append(("Duplicate References"     , "depRef"  ))
  VVegP0.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVegP0.append(("Stream Relay"       , "SRelay"  ))
  VVegP0.append(FFQJnR("Category"))
  VVegP0.append(("Live TV"        , "live"  ))
  VVegP0.append(("VOD"         , "vod"   ))
  VVegP0.append(("Series"        , "series"  ))
  VVegP0.append(("Uncategorised"      , "uncat"  ))
  VVegP0.append(FFQJnR("Media"))
  VVegP0.append(("Video"        , "video"  ))
  VVegP0.append(("Audio"        , "audio"  ))
  VVegP0.append(FFQJnR("File Type"))
  VVegP0.append(("MKV"         , "MKV"   ))
  VVegP0.append(("MP4"         , "MP4"   ))
  VVegP0.append(("MP3"         , "MP3"   ))
  VVegP0.append(("AVI"         , "AVI"   ))
  VVegP0.append(("FLV"         , "FLV"   ))
  VVegP0.extend(CCu3Fm.VVo7xX(prefix="__b__"))
  inFilterFnc = BF(self.VVdGL3, VVR0r4) if VVR0r4.VVUbIN().startswith("IPTV Filter ") else None
  filterObj = CCSAYR(self)
  filterObj.VV6OVY(VVegP0, VVegP0, BF(self.VV06W9, VVR0r4, False), inFilterFnc=inFilterFnc)
 def VVdGL3(self, VVR0r4, menuInstance, item):
  self.VV06W9(VVR0r4, True, item)
 def VV06W9(self, VVR0r4, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVR0r4.VV5xX4(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VV9f9k , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVultd , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VViSKT , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVcxqd , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VViIq6  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VV0h6M  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "SRelay"   : mode, words, title = self.VVN17r  , ""  , f + "= Stream Relay"
   elif item == "live"    : mode, words, title = self.VV3STL  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVQZ8G   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVf7jt  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVgvvn  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVCOoH  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVXHbo  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVLBt0   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVtT0S   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVmg1J   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVclAt   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVKCfI   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVEyF7  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVQzFk  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VViSKT:
   VVegP0 = []
   chName = VVR0r4.VV5xX4(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVegP0.append((item, item))
    if not VVegP0 and chName:
     VVegP0.append((chName, chName))
    FFJcY1(self, BF(self.VVgb1J, title), title="Words from Current Selection", VVegP0=VVegP0)
   else:
    VVR0r4.VVsu20("Invalid Channel Name")
  else:
   words, asPrefix = CCSAYR.VVaVMf(words)
   if not words and mode in (self.VVEyF7, self.VVQzFk):
    FFtMfC(self.VVR0r4, "Incorrect filter", 2000)
   else:
    FFG53m(self.VVR0r4, BF(self.VVUvuT, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVgb1J(self, title, word=None):
  if word:
   words = [word.lower()]
   FFG53m(self.VVR0r4, BF(self.VVUvuT, self.VViSKT, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVd1Bb(txt):
  return "#f#11ffff00#" + txt
 def VVUvuT(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVzto2 = self.VVahL5(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVzto2 = self.VVmOew(mode=mode, words=words, asPrefix=asPrefix)
  if VVzto2 : self.VVR0r4.VVwzoo(VVzto2, title)
  else  : self.VVR0r4.VVsu20("Not found")
 def VVahL5(self, mode=0, words=None, asPrefix=False):
  VVzto2 = []
  for row in self.VVR0r4.VVtxRM():
   row = list(map(str.strip, row))
   chNum, chName, VVztNS, chType, refCode, url = row
   if self.VVywxz(mode, refCode, FFyQaB(url).lower(), chName, words, VVztNS.lower(), asPrefix):
    VVzto2.append(row)
  VVzto2 = self.VV8dGw(mode, VVzto2)
  return VVzto2
 def VVmOew(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVzto2 = []
  files  = self.VVfs0p()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFu1EI(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVztNS = span.group(1)
    else : VVztNS = ""
    VVztNS_lCase = VVztNS.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVxbqQ(chName): chNameMod = self.VVd1Bb(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVztNS, chType + (" SRel" if FFabwQ(url) else ""), refCode, url)
     if self.VVywxz(mode, refCode, FFyQaB(url).lower(), chName, words, VVztNS_lCase, asPrefix):
      VVzto2.append(row)
      chNum += 1
  VVzto2 = self.VV8dGw(mode, VVzto2)
  return VVzto2
 def VV8dGw(self, mode, VVzto2):
  newRows = []
  if VVzto2 and mode == self.VViIq6:
   from collections import Counter
   counted  = Counter(elem[4] for elem in VVzto2)
   for item in VVzto2:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVzto2
 def VVywxz(self, mode, refCode, tUrl, chName, words, VVztNS_lCase, asPrefix):
  if   mode == self.VV9f9k : return True
  elif mode == self.VViIq6 : return True
  elif mode == self.VV0h6M  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VVN17r : return FFabwQ(tUrl)
  elif mode == self.VVCOoH  : return CCCu2Z.VVERnQ(tUrl, getAudVid=True) == "vid"
  elif mode == self.VVXHbo  : return CCCu2Z.VVERnQ(tUrl, getAudVid=True) == "aud"
  elif mode == self.VV3STL  : return CCCu2Z.VVERnQ(tUrl, compareType="live")
  elif mode == self.VVQZ8G  : return CCCu2Z.VVERnQ(tUrl, compareType="movie")
  elif mode == self.VVf7jt : return CCCu2Z.VVERnQ(tUrl, compareType="series")
  elif mode == self.VVgvvn  : return CCCu2Z.VVERnQ(tUrl, compareType="")
  elif mode == self.VVLBt0  : return CCCu2Z.VVERnQ(tUrl, compareExt="mkv")
  elif mode == self.VVtT0S  : return CCCu2Z.VVERnQ(tUrl, compareExt="mp4")
  elif mode == self.VVmg1J  : return CCCu2Z.VVERnQ(tUrl, compareExt="mp3")
  elif mode == self.VVclAt  : return CCCu2Z.VVERnQ(tUrl, compareExt="avi")
  elif mode == self.VVKCfI  : return CCCu2Z.VVERnQ(tUrl, compareExt="flv")
  elif mode == self.VVultd: return chName.lower().startswith(words[0])
  elif mode == self.VViSKT: return words[0] in chName.lower()
  elif mode == self.VVcxqd: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVEyF7 : return words[0] == VVztNS_lCase
  elif mode == self.VVQzFk :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVzbfv(self):
  picker = CCu3Fm(self, self.VVR0r4, "Add to Bouquet", self.VV7fp8)
 def VV7fp8(self):
  chUrlLst = []
  for row in self.VVR0r4.VVtxRM():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VVB6zD(self):
  c1 = VVSTv2
  t1 = FF6TiS("Bouquet", VVPN93)
  t2 = FF6TiS("ALL", VVPN93)
  refTxt = "(1/4097/5001/5002/8192/8193)"
  VVegP0 = []
  VVegP0.append((c1 + "Check System Acceptable Reference Types" , "VVZOzK"    ))
  if self.iptvFileAvailable:
   VVegP0.append((c1 + "Check Reference Codes Format"  , "VVaeR3"    ))
  VVegP0.append(VVHMBI)
  VVegP0.append(('Change %s Ref. Types to %s ..' % (t1, refTxt) , "VVfn66" ))
  VVegP0.append(('Change %s Ref. Types to %s ..' % (t2, refTxt) , "VVYH4I_all"  ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Change %s References to Unique Codes" % t2 , "VVXE4U"  ))
  VVegP0.append(("Change %s References to Identical Codes" % t2 , "VVogQg_all"  ))
  OKBtnFnc = self.VVBYfa
  FFJcY1(self, None, width=1200, title="Reference Tools", VVegP0=VVegP0, OKBtnFnc=OKBtnFnc)
 def VVBYfa(self, item=None):
  if item:
   ques = "Continue ?"
   menuInstance, txt, item, ndx = item
   if   item == "VVZOzK"    : FFG53m(menuInstance, self.VVZOzK)
   elif item == "VVaeR3"     : FFG53m(menuInstance, self.VVaeR3)
   elif item == "VVfn66" : self.VVfn66(menuInstance)
   elif item == "VVYH4I_all"  : self.VVqpGV(menuInstance, None, None)
   elif item == "VVXE4U"  : FFWBJu(self, BF(self.VVXE4U , menuInstance, txt), title=txt, VVFNjG=ques)
   elif item == "VVogQg_all"  : FFWBJu(self, BF(FFG53m, menuInstance, self.VVogQg), title=txt, VVFNjG=ques)
 def VVqpGV(self, menuInstance, bName, bPath):
  txt = "Stream Type "
  VVegP0 = []
  VVegP0.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVegP0.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVegP0.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVegP0.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVegP0.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))  #
  VVegP0.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFJcY1(self, BF(self.VVAf5E, menuInstance, bName, bPath), VVegP0=VVegP0, width=750, title="Change Reference Types to:")
 def VVAf5E(self, menuInstance, bName, bPath, item=None):
  if item:
   if   item == "RT_1"  : self.VVnIg5(menuInstance, bName, bPath, "1"   )
   elif item == "RT_4097" : self.VVnIg5(menuInstance, bName, bPath, "4097")
   elif item == "RT_5001" : self.VVnIg5(menuInstance, bName, bPath, "5001")
   elif item == "RT_5002" : self.VVnIg5(menuInstance, bName, bPath, "5002")
   elif item == "RT_8192" : self.VVnIg5(menuInstance, bName, bPath, "8192")
   elif item == "RT_8193" : self.VVnIg5(menuInstance, bName, bPath, "8193")
 def VVfn66(self, menuInstance):
  VVegP0 = CCu3Fm.VVo7xX()
  if VVegP0:
   FFJcY1(self, BF(self.VVrwUJ, menuInstance), VVegP0=VVegP0, title="IPTV Bouquets", VV4p4D=True)
  else:
   FFtMfC(menuInstance, "No bouquets Found !", 1500)
 def VVrwUJ(self, menuInstance, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVMOat + span.group(1)
    if fileExists(bPath): self.VVqpGV(menuInstance, bName, bPath)
    else    : FFtMfC(menuInstance, "Bouquet file not found!", 2000)
   else:
    FFtMfC(menuInstance, "Cannot process bouquet !", 2000)
 def VVnIg5(self, menuInstance, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FF6TiS(bName, VVBfw8)
  else : title = "Change for %s" % FF6TiS("All IPTV Services", VVBfw8)
  FFWBJu(self, BF(FFG53m, menuInstance, BF(self.VV2Q8z, menuInstance, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FF6TiS(rType, VVBfw8), title=title)
 def VV2Q8z(self, menuInstance, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = self.VVfs0p()
  if files:
   newRType = rType + ":"
   piconPath = CC96Ar.VVwdi5()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CCr5c7.VVKo2B(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FFnHzu(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           os.system(FFNxGN("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png")))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    os.system(FFNxGN(cmd))
  self.VVcMYX(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VVTjKa(self):
  totFiles = 0
  files  = self.VVfs0p()
  if files:
   totFiles = len(files)
  totChans = 0
  VVzto2 = self.VVmOew()
  if VVzto2:
   totChans = len(VVzto2)
  FFJRXg(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVaeR3(self):
  files  = self.VVfs0p()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFu1EI(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVUdsq
   else    : color = VVsIVN
   totInvalid = FF6TiS(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FF6TiS("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFJRXg(self, txt, title="Check IPTV References")
 def VVZOzK(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  chUrlLst  = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CCu3Fm.VVCuKe(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVATEZ = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVATEZ:
   VVefrB = FFXd2v(VVATEZ)
   if VVefrB:
    for service in VVefrB:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVMOat + userBName
  bFile = VVMOat + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFNxGN("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFNxGN("rm -f '%s'" % path)
  os.system(cmd)
  FFmB3r()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVUdsq
    else     : res, color = "No" , VVsIVN
    txt += "    %s\t: %s\n" % (item, FF6TiS(res, color))
   FFJRXg(self, txt, title=title)
  else:
   txt = FFnHzu(self, "Could not complete the test on your system!", title=title)
 def VV6CmU(self):
  VVlShi, err = CCcecd.VV4wpk(self, CCcecd.VVdsHn)
  if VVlShi:
   totChannels = 0
   totChange = 0
   for path in self.VVfs0p():
    toSave = False
    txt = FFu1EI(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVlShi.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVcMYX(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFnHzu(self, 'No channels in "lamedb" !')
 def VVXE4U(self, menuInstance, title):
  bFiles = self.VVfs0p()
  if bFiles:
   self.session.open(CCDe3n, barTheme=CCDe3n.VVEpKA
       , titlePrefix = "Renumbering References"
       , fncToRun  = BF(self.VVQpG3, bFiles)
       , VVuJdT = BF(self.VV03Qr, title))
  else:
   FFtMfC(menuInstance, "No bouquets files !", 1500)
 def VVQpG3(self, bFiles, VVEkKt):
  VVEkKt.VVyzJx = ""
  VVEkKt.VVKrKU("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FF5DO4(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVEkKt or VVEkKt.isCancelled:
   return
  elif not totLines:
   VVEkKt.VVyzJx = "No IPTV Services !"
   return
  else:
   VVEkKt.VVQWYw(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVEkKt or VVEkKt.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FF5DO4(path)
    for ndx, line in enumerate(lines):
     if not VVEkKt or VVEkKt.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVEkKt:
       VVEkKt.VVKrKU("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVEkKt:
       VVEkKt.VVHjIy(1)
      refCode, startId, startNS = CCu3Fm.VVvdTT(rType, CCu3Fm.VVGX2e, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVEkKt:
        VVEkKt.VVyzJx = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VV03Qr(self, title, VVLnvr, VVyzJx, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVyzJx:
   txt += "\n\n%s\n%s" % (FF6TiS("Ended with Error:", VVsIVN), VVyzJx)
  self.VVcMYX(True, title, txt)
 def VVCYaV(self):
  bFiles = self.VVfs0p()
  if not bFiles:
   FFtMfC(self.VVR0r4, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVR0r4.VVtxRM():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FFtMfC(self.VVR0r4, "Cannot read list", 1500)
   return
  self.session.open(CCDe3n, barTheme=CCDe3n.VVEpKA
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVNi9Y, bFiles, tableRefList)
      , VVuJdT = BF(self.VV03Qr, "Change Current List References to Unique Codes"))
 def VVNi9Y(self, bFiles, tableRefList, VVEkKt):
  VVEkKt.VVyzJx = ""
  VVEkKt.VVKrKU("Reading System References ...")
  refLst = CCu3Fm.VVSBzQ(CCu3Fm.VVGX2e, stripRType=True)
  if not VVEkKt or VVEkKt.isCancelled:
   return
  VVEkKt.VVQWYw(len(tableRefList))
  rType  = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVEkKt or VVEkKt.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFu1EI(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVEkKt or VVEkKt.isCancelled:
     return
    VVEkKt.VVKrKU("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVEkKt or VVEkKt.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVEkKt.VVHjIy(1)
      refCode, startId, startNS = CCu3Fm.VVvdTT(rType, CCu3Fm.VVGX2e, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVEkKt:
        VVEkKt.VVyzJx = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VVogQg(self):
  list = None
  if self.VVR0r4:
   list = []
   for row in self.VVR0r4.VVtxRM():
    list.append(row[4] + row[5])
  files  = self.VVfs0p()
  totChange = 0
  if files:
   for path in files:
    lines = FF5DO4(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VVcMYX(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVcMYX(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFmB3r()
   if refreshTable and self.VVR0r4:
    VVzto2 = self.VVmOew()
    if VVzto2 and self.VVR0r4:
     self.VVR0r4.VVwzoo(VVzto2, self.tableTitle)
     self.VVR0r4.VVsu20(txt)
   FFJRXg(self, txt, title=title)
  else:
   FFcZi2(self, "No changes.")
 def VVfs0p(self):
  return CCCu2Z.VVfoZV()
 @staticmethod
 def VVfoZV(atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVMOat + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFu1EI(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVUkMp(self, VVR0r4, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFyQaB(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFiqcT(self, fncMode=CC6biu.VVq8cn, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VViNSU(self, VVR0r4, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVMDWM(self, VVR0r4, title, txt, colList):
  chName, chUrl = self.VViNSU(VVR0r4, colList)
  self.VVLt6x(VVR0r4, chName, chUrl, "localIptv")
 def VV7VCM(self, mode, VVR0r4, colList):
  chName, chUrl, picUrl, refCode = self.VVMMKf(mode, colList)
  return chName, chUrl
 def VVugaT(self, mode, VVR0r4, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVMMKf(mode, colList)
  self.VVLt6x(VVR0r4, chName, chUrl, mode)
 def VVLt6x(self, VVR0r4, chName, chUrl, playerFlag):
  chName = FF2AUs(chName)
  if self.VVxbqQ(chName):
   FFtMfC(VVR0r4, "This is a marker!", 300)
  else:
   FFG53m(VVR0r4, BF(self.VVXkZM, VVR0r4, chUrl, playerFlag), title="Playing ...")
 def VVXkZM(self, VVR0r4, chUrl, playerFlag):
  FFGrAa(self, chUrl, VVMo36=False)
  CCM2Fd.VV8elw(self.session, iptvTableParams=(self, VVR0r4, playerFlag))
 @staticmethod
 def VVxbqQ(chName):
  mark = ("--", "__", "==", "##",  "**", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVS58H(self, VVR0r4, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self)
  if refCode:
   url1 = FFyQaB(origUrl.strip())
   for ndx, row in enumerate(VVR0r4.VVtxRM()):
    if refCode in row[4]:
     tableRow = FFyQaB(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVR0r4.VVwqjr(ndx)
      break
   else:
    FFtMfC(VVR0r4, "No found", 1000)
 def VVtRxU(self, m3uMode):
  lines = self.VVkyv4(3)
  if lines:
   lines.sort()
   VVegP0 = []
   for line in lines:
    VVegP0.append((line, line))
   if m3uMode == CCCu2Z.VVcGEG:
    title = "Browse Server from M3U URLs"
    VVZKXi = ("All to Playlist", self.VVpbdA)
   else:
    title = "M3U/M3U8 File Browser"
    VVZKXi = None
   OKBtnFnc = BF(self.VVH2r5, m3uMode, title)
   infoBtnFnc = self.VVKaET
   FFJcY1(self, None, title=title, VVegP0=VVegP0, width=1200, OKBtnFnc=OKBtnFnc, infoBtnFnc=infoBtnFnc, yellowBasePath="", VVZKXi=VVZKXi, VVXbiY="#11221122", VVVy8H="#11221122")
 def VVH2r5(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == CCCu2Z.VVcGEG:
    FFG53m(menuInstance, BF(self.VV7KUy, title, path))
   else:
    self.VVghTZ(menuInstance, path)
 def VVghTZ(self, menuInstance, path=None):
  if path:
   VVegP0 = []
   VVegP0.append(("All"         , "all"   ))
   VVegP0.append(FFQJnR("Category"))
   VVegP0.append(("Live TV"        , "live"  ))
   VVegP0.append(("VOD"         , "vod"   ))
   VVegP0.append(("Series"        , "series"  ))
   VVegP0.append(("Uncategorised"      , "uncat"  ))
   VVegP0.append(FFQJnR("Media"))
   VVegP0.append(("Video"        , "video"  ))
   VVegP0.append(("Audio"        , "audio"  ))
   VVegP0.append(FFQJnR("File Type"))
   VVegP0.append(("MKV"         , "MKV"   ))
   VVegP0.append(("MP4"         , "MP4"   ))
   VVegP0.append(("MP3"         , "MP3"   ))
   VVegP0.append(("AVI"         , "AVI"   ))
   VVegP0.append(("FLV"         , "FLV"   ))
   filterObj = CCSAYR(self, VVXbiY="#11552233", VVVy8H="#11552233")
   filterObj.VV6OVY(VVegP0, [], BF(self.VV3rzg, menuInstance, path), inFilterFnc=None)
 def VV3rzg(self, menuInstance, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VV9f9k , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VV3STL  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VVQZ8G  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VVf7jt  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VVgvvn  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VVCOoH  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VVXHbo  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VVLBt0  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VVtT0S  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VVmg1J  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVclAt  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VVKCfI  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVQzFk  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CCSAYR.VVaVMf(words)
   if not mode == self.VV9f9k:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FF6TiS(fTitle, VVsvZg)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FFG53m(menuInstance, BF(self.VVwkvc, path, m3uFilterParam))
 def VVwkvc(self, srcPath, m3uFilterParam):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFu1EI(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  VV9Xp9 = CCDbht()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVmyeS(propLine, "group-title") or "-"
   if not group == "-" and VV9Xp9.VVkO9i(group):
    groups.add(group)
  span = iSearch(r"#EXTINF:.+\n(.+)\n.+", txt, IGNORECASE)
  if span:
   self.curUrl = span.group(1)
  VVzto2 = []
  if len(groups) > 0:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   for group in groups:
    VVzto2.append((group, group))
   VVzto2.append(("ALL", ""))
   VVzto2.sort(key=lambda x: x[0].lower())
   VVs5Sk = self.VVCRxf
   VV91FP  = ("Select" , BF(self.VVwSgL, srcPath, m3uFilterParam), [])
   widths   = (100  , 0)
   VVsZoP  = (LEFT  , LEFT)
   FFqiz1(self, None, title=title, width= 1000, header=None, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=30, VV91FP=VV91FP, VVs5Sk=VVs5Sk, lastFindConfigObj=CFG.lastFindIptv
     , VVXbiY="#11110022", VVVy8H="#11110022", VVvi08="#11110022", VVTrrJ="#00444400")
  else:
   txt = FFu1EI(srcPath)
   self.VVSnke(txt, "", m3uFilterParam)
 def VVwSgL(self, srcPath, m3uFilterParam, VVR0r4, title, txt, colList):
  group = colList[1]
  txt = FFu1EI(srcPath)
  self.VVSnke(txt, group, m3uFilterParam)
 def VVSnke(self, txt, filterGroup="", m3uFilterParam=None):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CCDe3n, barTheme=CCDe3n.VVzwEk
       , titlePrefix = "Reading File Lines", endTitle="Loading channels ..."
       , fncToRun  = BF(self.VVJcYB, lst, filterGroup, m3uFilterParam)
       , VVuJdT = BF(self.VVAoAx, title, bName))
  else:
   self.VVtsbo("Not valid lines found !", title)
 def VVJcYB(self, lst, filterGroup, m3uFilterParam, VVEkKt):
  VVEkKt.VVyzJx = []
  VVEkKt.VVQWYw(len(lst))
  VV9Xp9 = CCDbht()
  num = 0
  for cols in lst:
   if not VVEkKt or VVEkKt.isCancelled:
    return
   VVEkKt.VVHjIy(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVmyeS(propLine, "tvg-logo")
   group = self.VVmyeS(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not VV9Xp9.VVkO9i(group) : skip = True
    elif chName and not VV9Xp9.VVkO9i(chName) : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VVywxz(mode, "", FFyQaB(url).lower(), chName, words, "", asPrefix)
    if not skip and VVEkKt:
     num += 1
     VVEkKt.VVyzJx.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
 def VVAoAx(self, title, bName, VVLnvr, VVyzJx, threadCounter, threadTotal, threadErr):
  if VVyzJx:
   VVs5Sk = self.VVCRxf
   VV91FP  = ("Select"   , BF(self.VVytCl, title)   , [])
   VVBSYf = (""    , self.VV92VP        , [])
   VVdn6T = ("Download PIcons", self.VVkOyZ       , [])
   VVljWo = ("Options"  , BF(self.VVrQT7, "m3Ch", "", bName) , [])
   VVDB15 = ("Posters Mode" , BF(self.VVarJa, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVsZoP  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFqiz1(self, None, title=title, header=header, VVVC4T=VVyzJx, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=28, VV91FP=VV91FP, VVs5Sk=VVs5Sk, VVBSYf=VVBSYf, VVdn6T=VVdn6T, VVljWo=VVljWo, VVDB15=VVDB15, lastFindConfigObj=CFG.lastFindIptv, VVSwEr=True, searchCol=1
     , VVXbiY="#0a00192B", VVVy8H="#0a00192B", VVvi08="#0a00192B", VVTrrJ="#00000000")
  else:
   self.VVtsbo("Not found !", title)
 def VVkOyZ(self, VVR0r4, title, txt, colList):
  self.VVQSMU(VVR0r4, "m3u/m3u8")
 def VVxeS6(self, rowNum, url, chName):
  refCode = self.VVQdgN(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFXjqJ(url), chName)
  return chUrl
 def VVQdgN(self, rowNum, url, chName):
  fName = os.path.basename(url)
  catID = "333"
  stID  =  "444"
  if fName:
   num = os.path.splitext(fName)[0]
   if num.isdigit() and int(num) < 0xeeee0000:
    stID = num
  chNum = str(rowNum + 1)
  refCode = self.VV2JiH(catID, stID, chNum)
  return refCode
 def VVmyeS(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVytCl(self, Title, VVR0r4, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFG53m(VVR0r4, BF(self.VVvzia, Title, VVR0r4, colList), title="Checking Server ...")
  else:
   self.VVAvcI(VVR0r4, url, chName)
 def VVvzia(self, title, VVR0r4, colList):
  if not CC6kXN.VVv4ri(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCwh19.VVviU3(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVegP0 = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCCu2Z.VVnoeh(url, fPath)
     VVegP0.append((resol, fullUrl))
    if VVegP0:
     if len(VVegP0) > 1:
      FFJcY1(self, BF(self.VV8zp9, VVR0r4, chName), VVegP0=VVegP0, title="Resolution", VV4p4D=True, VVk6EI=True)
     else:
      self.VVAvcI(VVR0r4, VVegP0[0][1], chName)
    else:
     span = iSearch(r"(http.+)", txt, IGNORECASE)
     if span:
      self.VVAvcI(VVR0r4, span.group(1), chName)
     else:
      span = iSearch(r"#EXT-X-STREAM-INF.*\n(.+)", txt, IGNORECASE)
      if span:
       fullUrl = CCCu2Z.VVnoeh(url, span.group(1))
       self.VVAvcI(VVR0r4, fullUrl, chName)
      else:
       self.VVbCAY("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVSnke(txt, filterGroup="")
      return
    self.VVAvcI(VVR0r4, url, chName)
   else:
    self.VVtsbo("Cannot process this channel !", title)
  else:
   self.VVtsbo(err, title)
 def VV8zp9(self, VVR0r4, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVAvcI(VVR0r4, resolUrl, chName)
 def VVAvcI(self, VVR0r4, url, chName):
  FFG53m(VVR0r4, BF(self.VVKNPE, VVR0r4, url, chName), title="Playing ...")
 def VVKNPE(self, VVR0r4, url, chName):
  chUrl = self.VVxeS6(VVR0r4.VVVZYd(), url, chName)
  FFGrAa(self, chUrl, VVMo36=False)
  CCM2Fd.VV8elw(self.session, iptvTableParams=(self, VVR0r4, "m3u/m3u8"))
 def VVcx5m(self, VVR0r4, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVxeS6(VVR0r4.VVVZYd(), url, chName)
  return chName, chUrl
 def VV92VP(self, VVR0r4, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFiqcT(self, fncMode=CC6biu.VVq8cn, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVtsbo(self, err, title):
  FFnHzu(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVCRxf(self, VVR0r4):
  if self.m3uOrM3u8File:
   self.close()
  VVR0r4.cancel()
 def VVpbdA(self, VVsxjbObj, item=None):
  FFG53m(VVsxjbObj, BF(self.VVHfrS, VVsxjbObj, item))
 def VVHfrS(self, VVsxjbObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVsxjbObj.VVegP0):
    path = item[1]
    if fileExists(path):
     enc = CCBlwj.VV2bQD(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = CCCu2Z.VVQJb2(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCCu2Z.VVK76l()
    pListF = "%sPlaylist_%s.txt" % (path, FFxsfY())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVsxjbObj.VVegP0)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFJRXg(self, txt, title=title)
   else:
    FFnHzu(self, "Could not obtain URLs from this file list !", title=title)
 def VVC2Nt(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVqvUl
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VVYoAR
  lines = self.VVkyv4(mode)
  if lines:
   lines.sort()
   VVegP0 = []
   for line in lines:
    VVegP0.append((FF6TiS(line, VVpkep) if "Bookmarks" in line else line, line))
   infoBtnFnc = self.VVKaET
   FFJcY1(self, None, title=title, VVegP0=VVegP0, width=1200, OKBtnFnc=okFnc, infoBtnFnc=infoBtnFnc, yellowBasePath="")
 def VVKaET(self, menuInstance, txt, ref, ndx):
  txt = ref
  sz = FFREV4(ref)
  if sz > 0:
   txt += "\n\nSize: %s" % CCr5c7.VVJv7c(sz)
  FFJRXg(self, txt, title="File Path")
 def VVqvUl(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFG53m(menuInstance, BF(self.VVcSgz, menuInstance, path), title="Processing File ...")
 def VVcSgz(self, VViwhT, path):
  enc = CCBlwj.VV2bQD(path, self)
  if enc == -1:
   return
  VVzto2 = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FFxJSp(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCCu2Z.VVacAj(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVzto2:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVzto2.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVzto2:
   title = "Playlist File : %s" % os.path.basename(path)
   VV91FP  = ("Start"    , BF(self.VVNSyG, "Playlist File")      , [])
   VVIqI1 = ("Home Menu"   , FFaoGB             , [])
   VVdn6T = ("Download M3U File" , self.VVFt6q         , [])
   VVljWo = ("Edit File"   , BF(self.VVU58K, path)        , [])
   VVDB15 = ("Check & Filter"  , BF(self.VVJb1U, VViwhT, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVsZoP  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFqiz1(self, None, title=title, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VV91FP=VV91FP, VVIqI1=VVIqI1, VVDB15=VVDB15, VVdn6T=VVdn6T, VVljWo=VVljWo, VVXbiY="#11001116", VVVy8H="#11001116", VVvi08="#11001116", VVTrrJ="#00003635", VVcd71="#0a333333", VVVygK="#11331100", VVSwEr=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FFnHzu(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVFt6q(self, VVR0r4, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFWBJu(self, BF(FFG53m, VVR0r4, BF(self.VVPysf, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVPysf(self, title, url):
  path, err = FFHXM5(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFnHzu(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFu1EI(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFO0bd(path)
    FFnHzu(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFO0bd(path)
    FFnHzu(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCCu2Z.VVK76l() + fName
    os.system(FFNxGN("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FFcZi2(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFnHzu(self, "Could not download the M3U file!", title=errTitle)
 def VVNSyG(self, Title, VVR0r4, title, txt, colList):
  url = colList[6]
  FFG53m(VVR0r4, BF(self.VVM9OU, Title, url), title="Checking Server ...")
 def VVU58K(self, path, VVR0r4, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCzWmm(self, path, VVuJdT=BF(self.VVXFaR, VVR0r4), curRowNum=rowNum)
  else    : FFlkXm(self, path)
 def VVXFaR(self, VVR0r4, fileChanged):
  if fileChanged:
   VVR0r4.cancel()
 def VVVlf5(self, title):
  curChName = self.VVR0r4.VV5xX4(1)
  FFYvs0(self, BF(self.VVpd1a, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVpd1a(self, title, name):
  if name:
   VVlShi, err = CCcecd.VV4wpk(self, CCcecd.VVc6zg, VVITXJ=False, VV6Oa0=False)
   list = []
   if VVlShi:
    VV9Xp9 = CCDbht()
    name = VV9Xp9.VVpSN0(name)
    ratio = "1"
    for item in VVlShi:
     if name in item[0].lower():
      list.append((item[0], FFWJ2v(item[2]), item[3], ratio))
   if list : self.VVld9d(list, title)
   else : FFnHzu(self, "Not found:\n\n%s" % name, title=title)
 def VVTz7l(self, title):
  curChName = self.VVR0r4.VV5xX4(1)
  self.session.open(CCDe3n, barTheme=CCDe3n.VVzwEk
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVtqne
      , VVuJdT = BF(self.VVWDt6, title, curChName))
 def VVtqne(self, VVEkKt):
  curChName = self.VVR0r4.VV5xX4(1)
  VVlShi, err = CCcecd.VV4wpk(self, CCcecd.VVEkB2, VVITXJ=False, VV6Oa0=False)
  if not VVlShi or not VVEkKt or VVEkKt.isCancelled:
   return
  VVEkKt.VVyzJx = []
  VVEkKt.VVQWYw(len(VVlShi))
  VV9Xp9 = CCDbht()
  curCh = VV9Xp9.VVpSN0(curChName)
  for refCode in VVlShi:
   chName, sat, inDB = VVlShi.get(refCode, ("", "", 0))
   ratio = CC96Ar.VVD5cG(chName.lower(), curCh)
   if not VVEkKt or VVEkKt.isCancelled:
    return
   VVEkKt.VVHjIy(1, True)
   if VVEkKt and ratio > 50:
    VVEkKt.VVyzJx.append((chName, FFWJ2v(sat), refCode.replace("_", ":"), str(ratio)))
 def VVWDt6(self, title, curChName, VVLnvr, VVyzJx, threadCounter, threadTotal, threadErr):
  if VVyzJx: self.VVld9d(VVyzJx, title)
  elif VVLnvr: FFnHzu(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVld9d(self, VVzto2, title):
  curChName = self.VVR0r4.VV5xX4(1)
  VVIkoa = self.VVR0r4.VV5xX4(4)
  curUrl  = self.VVR0r4.VV5xX4(5)
  VVzto2.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VV91FP  = ("Share Sat/C/T Ref.", BF(self.VVAOKV, title, curChName, VVIkoa, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFqiz1(self, None, title=title, header=header, VVVC4T=VVzto2, VVx2iV=widths, VVwwGj=26, VV91FP=VV91FP, VVXbiY="#0a00112B", VVVy8H="#0a001126", VVvi08="#0a001126", VVTrrJ="#00000000")
 def VVAOKV(self, newtitle, curChName, VVIkoa, curUrl, VVR0r4, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVIkoa, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFWBJu(self.VVR0r4, BF(FFG53m, self.VVR0r4, BF(self.VVSgF7, VVR0r4, data)), ques, title=newtitle, VVARnJ=True)
 def VVSgF7(self, VVR0r4, data):
  VVR0r4.cancel()
  title, curChName, VVIkoa, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVIkoa = VVIkoa.strip()
  newRefCode = newRefCode.strip()
  if not VVIkoa.endswith(":") : VVIkoa += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVIkoa, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVIkoa + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVfs0p():
    txt = FFu1EI(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFmB3r()
    newRow = []
    for i in range(6):
     newRow.append(self.VVR0r4.VV5xX4(i))
    newRow[4] = newRefCode
    done = self.VVR0r4.VVkf6n(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFDxKA(BF(FFcZi2 , self, resTxt, title=title))
  elif resErr: FFDxKA(BF(FFnHzu, self, resErr, title=title))
 def VVJb1U(self, VViwhT, path, VVR0r4, title, txt, colList):
  self.session.open(CCDe3n, barTheme=CCDe3n.VVEpKA
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVFS8d, VVR0r4)
      , VVuJdT = BF(self.VVuWJh, VViwhT, path, VVR0r4))
 def VVFS8d(self, VVR0r4, VVEkKt):
  VVEkKt.VVQWYw(VVR0r4.VV6qIs())
  VVEkKt.VVyzJx = []
  for row in VVR0r4.VVtxRM():
   if not VVEkKt or VVEkKt.isCancelled:
    return
   VVEkKt.VVHjIy(1, True)
   qUrl = self.VVlqW6(self.VVXLZs, row[6])
   txt, err = self.VVex4B(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVU8hy(item, "auth") == "0":
       VVEkKt.VVyzJx.append(qUrl)
    except:
     pass
 def VVuWJh(self, VViwhT, path, VVR0r4, VVLnvr, VVyzJx, threadCounter, threadTotal, threadErr):
  if VVLnvr:
   list = VVyzJx
   title = "Authorized Servers"
   if list:
    totChk = VVR0r4.VV6qIs()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFxsfY()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVC2Nt(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FF6TiS(str(totAuth), VVUdsq)
     txt += "%s\n\n%s"    %  (FF6TiS("Result File:", VVpkep), newPath)
     FFJRXg(self, txt, title=title)
     VVR0r4.close()
     VViwhT.close()
    else:
     FFcZi2(self, "All URLs are authorized.", title=title)
   else:
    FFnHzu(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVex4B(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVacAj(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVERnQ(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CCAnG2.VVXWgC()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVgZiB(decodedUrl):
  return CCCu2Z.VVERnQ(decodedUrl, justRetDotExt=True)
 def VVlqW6(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVacAj(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVXLZs   : return "%s"            % url
  elif mode == self.VVkN6E   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVLb5y   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVaI7O  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVAaer  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVv4Ht : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VV2QgQ   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVNceW    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVYpZi  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VV5oTq : return "%s&action=get_live_streams"      % url
  elif mode == self.VVvSNq  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVU8hy(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFrOxn(int(val))
    elif is_base64 : val = FFHC0y(val)
    elif isToHHMMSS : val = FFFSaa(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VV7KUy(self, title, path):
  if fileExists(path):
   enc = CCBlwj.VV2bQD(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = CCCu2Z.VVQJb2(line)
     if qUrl:
      break
   if qUrl : self.VVM9OU(title, qUrl)
   else : FFnHzu(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFnHzu(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVYFiO(self):
  title = "Current Channel Server"
  qUrl, iptvRef = CCCu2Z.VVBzpG(self)
  if qUrl or "chCode" in iptvRef:
   p = CCwh19()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVKFVK(iptvRef)
   if valid:
    self.VVm08Q(self, host, mac)
    return
   elif qUrl:
    FFG53m(self, BF(self.VVM9OU, title, qUrl), title="Checking Server ...")
    return
  FFnHzu(self, "Error in current channel URL !", title=title)
 @staticmethod
 def VVBzpG(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(SELF)
  qUrl = CCCu2Z.VVQJb2(decodedUrl)
  return qUrl, iptvRef
 @staticmethod
 def VVQJb2(url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVM9OU(self, title, url):
  self.curUrl = url
  self.VVgvNCData = {}
  qUrl = self.VVlqW6(self.VVXLZs, url)
  txt, err = self.VVex4B(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVgvNCData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVgvNCData["username"    ] = self.VVU8hy(item, "username"        )
    self.VVgvNCData["password"    ] = self.VVU8hy(item, "password"        )
    self.VVgvNCData["message"    ] = self.VVU8hy(item, "message"        )
    self.VVgvNCData["auth"     ] = self.VVU8hy(item, "auth"         )
    self.VVgvNCData["status"    ] = self.VVU8hy(item, "status"        )
    self.VVgvNCData["exp_date"    ] = self.VVU8hy(item, "exp_date"    , isDate=True )
    self.VVgvNCData["is_trial"    ] = self.VVU8hy(item, "is_trial"        )
    self.VVgvNCData["active_cons"   ] = self.VVU8hy(item, "active_cons"       )
    self.VVgvNCData["created_at"   ] = self.VVU8hy(item, "created_at"   , isDate=True )
    self.VVgvNCData["max_connections"  ] = self.VVU8hy(item, "max_connections"      )
    self.VVgvNCData["allowed_output_formats"] = self.VVU8hy(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVgvNCData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVgvNCData["url"    ] = self.VVU8hy(item, "url"        )
    self.VVgvNCData["port"    ] = self.VVU8hy(item, "port"        )
    self.VVgvNCData["https_port"  ] = self.VVU8hy(item, "https_port"      )
    self.VVgvNCData["server_protocol" ] = self.VVU8hy(item, "server_protocol"     )
    self.VVgvNCData["rtmp_port"   ] = self.VVU8hy(item, "rtmp_port"       )
    self.VVgvNCData["timezone"   ] = self.VVU8hy(item, "timezone"       )
    self.VVgvNCData["timestamp_now"  ] = self.VVU8hy(item, "timestamp_now"  , isDate=True )
    self.VVgvNCData["time_now"   ] = self.VVU8hy(item, "time_now"       )
    VVegP0  = self.VVHRKw(True)
    OKBtnFnc = self.VV8mVt
    infoBtnFnc = self.VVe4hF
    VVKP6N = ("Home Menu", FFaoGB)
    VVV5x7= ("Add to Menu", BF(CCCu2Z.VVUPPU, self, False, self.VVgvNCData["playListURL"]))
    VVZKXi = ("Bookmark Server", BF(CCCu2Z.VVUjaF, self, False, self.VVgvNCData["playListURL"]))
    FFJcY1(self, None, title="IPTV Server Resources", VVegP0=VVegP0, OKBtnFnc=OKBtnFnc, infoBtnFnc=infoBtnFnc, VVKP6N=VVKP6N, VVV5x7=VVV5x7, VVZKXi=VVZKXi)
   else:
    err = "Could not get data from server !"
  if err:
   FFnHzu(self, err, title=title)
  FFtMfC(self)
 def VV8mVt(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFG53m(menuInstance, BF(self.VVIrhA, self.VVkN6E  , title=title), title=wTxt)
   elif ref == "vod"   : FFG53m(menuInstance, BF(self.VVIrhA, self.VVLb5y  , title=title), title=wTxt)
   elif ref == "series"  : FFG53m(menuInstance, BF(self.VVIrhA, self.VVaI7O , title=title), title=wTxt)
   elif ref == "catchup"  : FFG53m(menuInstance, BF(self.VVIrhA, self.VVAaer , title=title), title=wTxt)
   elif ref == "accountInfo" : FFG53m(menuInstance, BF(self.VVglLf           , title=title), title=wTxt)
 def VVe4hF(self, menuInstance, txt, ref, ndx):
  txt = self.curUrl
  if VVks1Y:
   ver, err = self.VVgKin(self.VV99Y1())
   txt += "\n\n"
   txt += "Portal\t: %s\n" % self.VVO1en
   txt += "PHP\t: %s\n" % self.VVtdUV
   txt += "Extra\t: %s\n" % {2:"Big", 3:"Sml"}.get(self.VVC50x, "-")
   txt += "Version\t: %s" % (ver or err)
  FFJRXg(self, txt, title="Current Server URL")
 def VVglLf(self, title):
  rows = []
  for key, val in self.VVgvNCData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VV9HXW
   else:
    num, part = "1", self.VVeI9c
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVIqI1  = ("Home Menu", FFaoGB, [])
  VVdn6T  = None
  if VVks1Y:
   VVdn6T = ("Get JS" , BF(self.VV4tMX, "/".join(self.VVgvNCData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFqiz1(self, None, title=title, width=1200, header=header, VVVC4T=rows, VVx2iV=widths, VVwwGj=26, VVIqI1=VVIqI1, VVdn6T=VVdn6T, VVXbiY="#0a00292B", VVVy8H="#0a002126", VVvi08="#0a002126", VVTrrJ="#00000000", searchCol=2)
 def VVVjWr(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    VV9Xp9 = CCDbht()
    if mode in (self.VV2QgQ, self.VVvSNq):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVU8hy(item, "num"         )
      name     = self.VVU8hy(item, "name"        )
      stream_id    = self.VVU8hy(item, "stream_id"       )
      stream_icon    = self.VVU8hy(item, "stream_icon"       )
      epg_channel_id   = self.VVU8hy(item, "epg_channel_id"      )
      added     = self.VVU8hy(item, "added"    , isDate=True )
      is_adult    = self.VVU8hy(item, "is_adult"       )
      category_id    = self.VVU8hy(item, "category_id"       )
      tv_archive    = self.VVU8hy(item, "tv_archive"       )
      direct_source   = self.VVU8hy(item, "direct_source"      )
      tv_archive_duration  = self.VVU8hy(item, "tv_archive_duration"     )
      name = VV9Xp9.VVkO9i(name, is_adult)
      if name:
       if mode == self.VV2QgQ or mode == self.VVvSNq and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVNceW:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVU8hy(item, "num"         )
      name    = self.VVU8hy(item, "name"        )
      stream_id   = self.VVU8hy(item, "stream_id"       )
      stream_icon   = self.VVU8hy(item, "stream_icon"       )
      added    = self.VVU8hy(item, "added"    , isDate=True )
      is_adult   = self.VVU8hy(item, "is_adult"       )
      category_id   = self.VVU8hy(item, "category_id"       )
      container_extension = self.VVU8hy(item, "container_extension"     ) or "mp4"
      name = VV9Xp9.VVkO9i(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VVYpZi:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVU8hy(item, "num"        )
      name    = self.VVU8hy(item, "name"       )
      series_id   = self.VVU8hy(item, "series_id"      )
      cover    = self.VVU8hy(item, "cover"       )
      genre    = self.VVU8hy(item, "genre"       )
      episode_run_time = self.VVU8hy(item, "episode_run_time"    )
      category_id   = self.VVU8hy(item, "category_id"      )
      container_extension = self.VVU8hy(item, "container_extension"    ) or "mp4"
      name = VV9Xp9.VVkO9i(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVIrhA(self, mode, title):
  cList, err = self.VVnnW8(mode)
  if cList and mode == self.VVAaer:
   cList = self.VVPIIl(cList)
  if err:
   FFnHzu(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVXbiY, VVVy8H, VVvi08, VVTrrJ = self.VVrucS(mode)
   mName = self.VV742P(mode)
   if   mode == self.VVkN6E  : fMode = self.VV2QgQ
   elif mode == self.VVLb5y  : fMode = self.VVNceW
   elif mode == self.VVaI7O : fMode = self.VVYpZi
   elif mode == self.VVAaer : fMode = self.VVvSNq
   if mode == self.VVAaer:
    VVljWo = None
    VVDB15 = None
   else:
    VVljWo = ("Find in %s" % mName , BF(self.VVh8lW, fMode, True) , [])
    VVDB15 = ("Find in Selected" , BF(self.VVh8lW, fMode, False) , [])
   VV91FP   = ("Show List"   , BF(self.VVJEg5, mode)  , [])
   VVIqI1  = ("Home Menu"   , FFaoGB         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFqiz1(self, None, title=title, width=1200, header=header, VVVC4T=cList, VVx2iV=widths, VVwwGj=30, VVIqI1=VVIqI1, VVljWo=VVljWo, VVDB15=VVDB15, VV91FP=VV91FP, VVXbiY=VVXbiY, VVVy8H=VVVy8H, VVvi08=VVvi08, VVTrrJ=VVTrrJ, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFnHzu(self, "No list from server !", title=title)
  FFtMfC(self)
 def VVnnW8(self, mode):
  qUrl  = self.VVlqW6(mode, self.VVgvNCData["playListURL"])
  txt, err = self.VVex4B(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    VV9Xp9 = CCDbht()
    for item in tDict:
     category_id  = self.VVU8hy(item, "category_id"  )
     category_name = self.VVU8hy(item, "category_name" )
     parent_id  = self.VVU8hy(item, "parent_id"  )
     category_name = VV9Xp9.VVYVet(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVPIIl(self, catList):
  mode  = self.VVvSNq
  qUrl  = self.VVlqW6(mode, self.VVgvNCData["playListURL"])
  txt, err = self.VVex4B(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVVjWr(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVJEg5(self, mode, VVR0r4, title, txt, colList):
  title = colList[1]
  FFG53m(VVR0r4, BF(self.VVhBVC, mode, VVR0r4, title, txt, colList), title="Downloading ...")
 def VVhBVC(self, mode, VVR0r4, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VV742P(mode) + " : "+ bName
  if   mode == self.VVkN6E  : mode = self.VV2QgQ
  elif mode == self.VVLb5y  : mode = self.VVNceW
  elif mode == self.VVaI7O : mode = self.VVYpZi
  elif mode == self.VVAaer : mode = self.VVvSNq
  qUrl  = self.VVlqW6(mode, self.VVgvNCData["playListURL"], catID)
  txt, err = self.VVex4B(qUrl)
  list  = []
  if not err and mode in (self.VV2QgQ, self.VVNceW, self.VVYpZi, self.VVvSNq):
   list, err = self.VVVjWr(mode, txt)
  if err:
   FFnHzu(self, err, title=title)
  elif list:
   VVIqI1  = ("Home Menu"   , FFaoGB            , [])
   if mode in (self.VV2QgQ, self.VVvSNq):
    VVXbiY, VVVy8H, VVvi08, VVTrrJ = self.VVrucS(mode)
    VVBSYf = (""     , BF(self.VVs8aO, mode)      , [])
    VVdn6T = ("Download Options" , BF(self.VVf0sf, mode, "", "")   , [])
    VVljWo = ("Options"   , BF(self.VVrQT7, "lv", mode, bName)   , [])
    VVDB15 = ("Posters Mode"  , BF(self.VVarJa, mode, False)     , [])
    if mode == self.VV2QgQ:
     VV91FP = ("Play"    , BF(self.VVugaT, mode)       , [])
    else:
     VV91FP = ("Programs"   , BF(self.VVKEIU, mode, bName) , [])
   elif mode == self.VVNceW:
    VVXbiY, VVVy8H, VVvi08, VVTrrJ = self.VVrucS(mode)
    VV91FP  = ("Play"    , BF(self.VVugaT, mode)       , [])
    VVBSYf = (""     , BF(self.VVs8aO, mode)      , [])
    VVdn6T = ("Download Options" , BF(self.VVf0sf, mode, "v", "")   , [])
    VVljWo = ("Options"   , BF(self.VVrQT7, "v", mode, bName)   , [])
    VVDB15 = ("Posters Mode"  , BF(self.VVarJa, mode, False)     , [])
   elif mode == self.VVYpZi:
    VVXbiY, VVVy8H, VVvi08, VVTrrJ = self.VVrucS("series2")
    VV91FP  = ("Show Seasons"  , BF(self.VVWTxa, mode)       , [])
    VVBSYf = (""     , BF(self.VVr9lU, mode)     , [])
    VVdn6T = None
    VVljWo = None
    VVDB15 = ("Posters Mode"  , BF(self.VVarJa, mode, True)      , [])
   header, widths, VVsZoP = self.VVYsR9(mode)
   FFqiz1(self, None, title=title, header=header, VVVC4T=list, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VV91FP=VV91FP, VVIqI1=VVIqI1, VVdn6T=VVdn6T, VVljWo=VVljWo, VVDB15=VVDB15, lastFindConfigObj=CFG.lastFindIptv, VVBSYf=VVBSYf, VVXbiY=VVXbiY, VVVy8H=VVVy8H, VVvi08=VVvi08, VVTrrJ=VVTrrJ, VVSwEr=True, searchCol=1)
  else:
   FFnHzu(self, "No Channels found !", title=title)
  FFtMfC(self)
 def VVYsR9(self, mode):
  if mode in (self.VV2QgQ, self.VVvSNq):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VVsZoP  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVNceW:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VVsZoP  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VVYpZi:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VVsZoP  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VVsZoP
 def VVKEIU(self, mode, bName, VVR0r4, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVgvNCData["playListURL"]
  ok_fnc  = BF(self.VVtYJL, hostUrl, chName, catId, streamId)
  FFG53m(VVR0r4, BF(CCCu2Z.VVDAXv, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVtYJL(self, chUrl, chName, catId, streamId, VVR0r4, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCCu2Z.VVacAj(chUrl)
   chNum = "333"
   refCode = CCCu2Z.VV2JiH(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFGrAa(self, chUrl, VVMo36=False)
   CCM2Fd.VV8elw(self.session)
  else:
   FFnHzu(self, "Incorrect Timestamp", pTitle)
 def VVWTxa(self, mode, VVR0r4, title, txt, colList):
  title = colList[1]
  FFG53m(VVR0r4, BF(self.VVN5Vr, mode, VVR0r4, title, txt, colList), title="Downloading ...")
 def VVN5Vr(self, mode, VVR0r4, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVlqW6(self.VVv4Ht, self.VVgvNCData["playListURL"], series_id)
  txt, err = self.VVex4B(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVU8hy(tDict["info"], "name"   )
      category_id = self.VVU8hy(tDict["info"], "category_id" )
      icon  = self.VVU8hy(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      VV9Xp9 = CCDbht()
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVU8hy(EP, "id"     )
        episode_num   = self.VVU8hy(EP, "episode_num"   )
        epTitle    = self.VVU8hy(EP, "title"     )
        container_extension = self.VVU8hy(EP, "container_extension" )
        seasonNum   = self.VVU8hy(EP, "season"    )
        epTitle = VV9Xp9.VVkO9i(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFnHzu(self, err, title=title)
  elif list:
   VVIqI1 = ("Home Menu"   , FFaoGB          , [])
   VVdn6T = ("Download Options" , BF(self.VVf0sf, mode, "s", title), [])
   VVljWo = ("Options"   , BF(self.VVrQT7, "s", mode, title) , [])
   VVDB15 = ("Posters Mode"  , BF(self.VVarJa, mode, False)   , [])
   VVBSYf = (""     , BF(self.VVs8aO, mode)    , [])
   VV91FP  = ("Play"    , BF(self.VVugaT, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVsZoP  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFqiz1(self, None, title=title, header=header, VVVC4T=list, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VVIqI1=VVIqI1, VVdn6T=VVdn6T, VV91FP=VV91FP, VVBSYf=VVBSYf, VVljWo=VVljWo, VVDB15=VVDB15, lastFindConfigObj=CFG.lastFindIptv, VVXbiY="#0a00292B", VVVy8H="#0a002126", VVvi08="#0a002126", VVTrrJ="#00000000")
  else:
   FFnHzu(self, "No Channels found !", title=title)
  FFtMfC(self)
 def VVh8lW(self, mode, isAll, VVR0r4, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVegP0 = []
  VVegP0.append(("Keyboard"  , "manualEntry"))
  VVegP0.append(("From Filter" , "fromFilter"))
  FFJcY1(self, BF(self.VVgYlF, VVR0r4, mode, onlyCatID), title="Input Type", VVegP0=VVegP0, width=400)
 def VVgYlF(self, VVR0r4, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFYvs0(self, BF(self.VVmKIL, VVR0r4, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCSAYR(self)
    filterObj.VVnKMp(BF(self.VVmKIL, VVR0r4, mode, onlyCatID))
 def VVmKIL(self, VVR0r4, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FFCfiF(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CCSAYR.VVaVMf(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FFnHzu(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FFnHzu(self, "All words must be at least 3 characters !", title=title)
        return
     VV9Xp9 = CCDbht()
     if CFG.hideIptvServerAdultWords.getValue() and VV9Xp9.VVzzEe(words):
      FFnHzu(self, VV9Xp9.VVeJdV(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CCDe3n, barTheme=CCDe3n.VVzwEk
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVIM3A, VVR0r4, mode, onlyCatID, title, words, toFind, asPrefix, VV9Xp9)
          , VVuJdT = BF(self.VVmyqi, mode, toFind, title))
   if not words:
    FFtMfC(VVR0r4, "Nothing to find !", 1500)
 def VVIM3A(self, VVR0r4, mode, onlyCatID, title, words, toFind, asPrefix, VV9Xp9, VVEkKt):
  VVEkKt.VVQWYw(VVR0r4.VVsBGq() if onlyCatID is None else 1)
  VVEkKt.VVyzJx = []
  for row in VVR0r4.VVtxRM():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVEkKt or VVEkKt.isCancelled:
    return
   VVEkKt.VVHjIy(1)
   VVEkKt.VV4wDL(catName)
   qUrl  = self.VVlqW6(mode, self.VVgvNCData["playListURL"], catID)
   txt, err = self.VVex4B(qUrl)
   if not err:
    tList, err = self.VVVjWr(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = VV9Xp9.VVkO9i(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       VVEkKt.VVyzJx.append(item)
 def VVmyqi(self, mode, toFind, title, VVLnvr, VVyzJx, threadCounter, threadTotal, threadErr):
  if VVyzJx:
   title = self.VVab0I(mode, toFind)
   if mode == self.VV2QgQ or mode == self.VVNceW:
    if mode == self.VVNceW : typ = "v"
    else          : typ = ""
    bName   = CCCu2Z.VV8ga2(toFind)
    VV91FP  = ("Play"     , BF(self.VVugaT, mode)     , [])
    VVdn6T = ("Download Options" , BF(self.VVf0sf, mode, typ, "") , [])
    VVljWo = ("Options"   , BF(self.VVrQT7, "fnd", mode, bName), [])
    VVDB15 = ("Posters Mode"  , BF(self.VVarJa, mode, False)   , [])
    VVBSYf = (""     , BF(self.VVs8aO, mode)    , [])
   elif mode == self.VVYpZi:
    VV91FP  = ("Show Seasons"  , BF(self.VVWTxa, mode)     , [])
    VVljWo = None
    VVdn6T = None
    VVDB15 = ("Posters Mode"  , BF(self.VVarJa, mode, True)    , [])
    VVBSYf = (""     , BF(self.VVr9lU, mode)   , [])
   VVIqI1  = ("Home Menu"   , FFaoGB          , [])
   header, widths, VVsZoP = self.VVYsR9(mode)
   VVR0r4 = FFqiz1(self, None, title=title, header=header, VVVC4T=VVyzJx, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VV91FP=VV91FP, VVIqI1=VVIqI1, VVdn6T=VVdn6T, VVljWo=VVljWo, VVDB15=VVDB15, VVBSYf=VVBSYf, VVXbiY="#0a00292B", VVVy8H="#0a002126", VVvi08="#0a002126", VVTrrJ="#00000000", VVSwEr=True, searchCol=1)
   if not VVLnvr:
    FFtMfC(VVR0r4, "Stopped" , 1000)
  else:
   if VVLnvr:
    FFnHzu(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVMMKf(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VV2QgQ, self.VVvSNq):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVNceW:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FF2AUs(chName)
  url = self.VVgvNCData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVacAj(url)
  refCode = self.VV2JiH(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVs8aO(self, mode, VVR0r4, title, txt, colList):
  FFG53m(VVR0r4, BF(self.VVj8OJ, mode, VVR0r4, title, txt, colList))
 def VVj8OJ(self, mode, VVR0r4, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVMMKf(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFiqcT(self, fncMode=CC6biu.VVhNUL, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVr9lU(self, mode, VVR0r4, title, txt, colList):
  FFG53m(VVR0r4, BF(self.VV7Ozt, mode, VVR0r4, title, txt, colList))
 def VV7Ozt(self, mode, VVR0r4, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFiqcT(self, fncMode=CC6biu.VVCAZt, chName=name, text=txt, picUrl=Cover)
 def VVarJa(self, mode, isSerNames, VVR0r4, title, txt, colList):
  if   mode in ("itv"  , CCCu2Z.VV2QgQ, CCCu2Z.VVvSNq): category = "live"
  elif mode in ("vod"  , CCCu2Z.VVNceW )          : category = "vod"
  elif mode in ("series" , CCCu2Z.VVYpZi)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VV2QgQ : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVvSNq : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVNceW  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVYpZi : picCol, descCol, descTxt = 5, 0, "Season"
  FFG53m(VVR0r4, BF(self.session.open, CCaknG, VVR0r4, category, nameCol, picCol, descCol, descTxt))
 def VVf0sf(self, mode, typ, seriesName, VVR0r4, title, txt, colList):
  VVegP0 = []
  isMulti = VVR0r4.VV9Jt5
  tot  = VVR0r4.VVkGfp()
  if isMulti:
   if tot < 1:
    FFtMfC(VVR0r4, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVegP0.append(("Download %s PIcon%s" % (name, FFJHIK(tot)), "dnldPicons" ))
  if typ:
   VVegP0.append(VVHMBI)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVegP0.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVegP0.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVegP0.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCBXuV.VVGcd9():
    VVegP0.append(VVHMBI)
    VVegP0.append(("Download Manager"      , "dload_stat" ))
  FFJcY1(self, BF(self.VVQl33, VVR0r4, mode, typ, seriesName, colList), title="Download Options", VVegP0=VVegP0)
 def VVQl33(self, VVR0r4, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVQSMU(VVR0r4, mode)
   elif item == "dnldSel"  : self.VVFJDh(VVR0r4, mode, typ, colList, True)
   elif item == "addSel"  : self.VVFJDh(VVR0r4, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVnhNt(VVR0r4, mode, typ, seriesName)
   elif item == "dload_stat" : CCBXuV.VVmWLp(self)
 def VVFJDh(self, VVR0r4, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVIESl(mode, typ, colList)
  if startDnld:
   CCBXuV.VVL8YB(self, decodedUrl)
  else:
   self.VVHL6J(VVR0r4, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVnhNt(self, VVR0r4, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVR0r4.VVtxRM():
   chName, decodedUrl = self.VVIESl(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVHL6J(VVR0r4, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVHL6J(self, VVR0r4, title, chName, decodedUrl_list, startDnld):
  FFWBJu(self, BF(self.VVrOoL, VVR0r4, decodedUrl_list, startDnld), chName, title=title)
 def VVrOoL(self, VVR0r4, decodedUrl_list, startDnld):
  added, skipped = CCBXuV.VVWTb4(decodedUrl_list)
  FFtMfC(VVR0r4, "Added", 1000)
 def VVIESl(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVMMKf(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVXTJq(mode, colList)
   refCode, chUrl = self.VVkJgo(self.VVO1en, self.VVQtHS, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFiRgM(chUrl)
  return chName, decodedUrl
 def VVQSMU(self, VVR0r4, mode):
  if os.system(FFNxGN("which ffmpeg")) == 0:
   self.session.open(CCDe3n, barTheme=CCDe3n.VVEpKA
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVKS8K, VVR0r4, mode)
       , VVuJdT = self.VVVzP5)
  else:
   FFWBJu(self, BF(CCCu2Z.VVFJ8M, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVVzP5(self, VVLnvr, VVyzJx, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVyzJx["proces"], VVyzJx["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVyzJx["ok"], VVyzJx["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVyzJx["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVyzJx["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVyzJx["badURL"]
  txt += "Download Failure\t: %d\n"   % VVyzJx["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVyzJx["path"]
  if not VVLnvr  : color = "#11402000"
  elif VVyzJx["err"]: color = "#11201000"
  else     : color = None
  if VVyzJx["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVyzJx["err"], txt)
  title = "PIcons Download Result"
  if not VVLnvr:
   title += "  (cancelled)"
  FFJRXg(self, txt, title=title, VVvi08=color)
 def VVKS8K(self, VVR0r4, mode, VVEkKt):
  isMulti = VVR0r4.VV9Jt5
  if isMulti : totRows = VVR0r4.VVkGfp()
  else  : totRows = VVR0r4.VVsBGq()
  VVEkKt.VVQWYw(totRows)
  VVEkKt.VVc4KL(0)
  counter     = VVEkKt.counter
  maxValue    = VVEkKt.maxValue
  pPath     = CC96Ar.VVwdi5()
  VVEkKt.VVyzJx = {   "total" : totRows
         , "proces" : 0
         , "attempt" : 0
         , "fail" : 0
         , "ok"  : 0
         , "size0" : 0
         , "exist" : 0
         , "badURL" : 0
         , "path" : pPath
         , "err"  : "" }
  try:
   for rowNum, row in enumerate(VVR0r4.VVtxRM()):
    if VVEkKt.isCancelled:
     break
    if not isMulti or VVR0r4.VVFcPL(rowNum):
     VVEkKt.VVyzJx["proces"] += 1
     VVEkKt.VVHjIy(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVXTJq(mode, row)
      refCode = CCCu2Z.VV2JiH(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVQdgN(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVMMKf(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVEkKt.VVyzJx["attempt"] += 1
       path, err = FFHXM5(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVEkKt:
         VVEkKt.VVyzJx["ok"] += 1
         VVEkKt.VVc4KL(VVEkKt.VVyzJx["ok"])
        if FFREV4(path) > 0:
         cmd = CC6biu.VVfDUr(path)
         cmd += FFNxGN("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         if VVEkKt:
          VVEkKt.VVyzJx["size0"] += 1
         FFO0bd(path)
       elif err:
        if VVEkKt:
         VVEkKt.VVyzJx["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVEkKt:
          VVEkKt.VVyzJx["err"] = err.title()
         break
      else:
       if VVEkKt:
        VVEkKt.VVyzJx["exist"] += 1
     else:
      if VVEkKt:
       VVEkKt.VVyzJx["badURL"] += 1
  except:
   pass
 def VVAGpV(self):
  title = "Download PIcons for Current Bouquet"
  if os.system(FFNxGN("which ffmpeg")) == 0:
   self.session.open(CCDe3n, barTheme=CCDe3n.VVEpKA
       , titlePrefix = ""
       , fncToRun  = self.VVSDe7
       , VVuJdT = BF(self.VVHufW, title))
  else:
   FFWBJu(self, BF(CCCu2Z.VVFJ8M, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VVSDe7(self, VVEkKt):
  bName = CCu3Fm.VVKht1()
  pPath = CC96Ar.VVwdi5()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVEkKt.VVyzJx = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CCu3Fm.VVQwOu()
  if not VVEkKt or VVEkKt.isCancelled:
   return
  if not services or len(services) == 0:
   VVEkKt.VVyzJx = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVEkKt.VVQWYw(totCh)
  VVEkKt.VVc4KL(0)
  for serv in services:
   if not VVEkKt or VVEkKt.isCancelled:
    return
   VVEkKt.VVyzJx = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVEkKt.VVHjIy(1)
   VVEkKt.VVc4KL(totPic)
   fullRef  = serv[0]
   if FF2IUY(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFiRgM(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CCwh19.VVx1dg(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CCCu2Z.VVERnQ(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInv += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCCu2Z.VVex4B(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CC6biu.VVL0r4(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFHXM5(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVEkKt:
     VVEkKt.VVc4KL(totPic)
    if FFREV4(path) > 0:
     cmd = CC6biu.VVfDUr(path)
     cmd += FFNxGN("mv -f '%s' '%s'" % (path, pPath)) + ";"
     os.system(cmd)
     totPicOK += 1
    else:
     totSize0
     FFO0bd(path)
  if VVEkKt:
   VVEkKt.VVyzJx = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVHufW(self, title, VVLnvr, VVyzJx, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVyzJx
  if err:
   FFnHzu(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FF6TiS(str(totExist)  , VVsIVN)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FF6TiS(str(totNotIptv)  , VVsIVN)
    if totServErr : txt += "Server Errors\t: %s\n" % FF6TiS(str(totServErr) + t1, VVsIVN)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FF6TiS(str(totParseErr) , VVsIVN)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FF6TiS(str(totInvServ)  , VVsIVN)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FF6TiS(str(totInvPicUrl) , VVsIVN)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FF6TiS(str(totSize0)  , VVsIVN)
   if not VVLnvr:
    title += "  (stopped)"
   FFJRXg(self, txt, title=title)
 @staticmethod
 def VVFJ8M(SELF):
  cmd = FFiwac(VVerzX, "ffmpeg")
  if cmd : FFYyBc(SELF, cmd, title="Installing FFmpeg")
  else : FFw6dW(SELF)
 @staticmethod
 def VVvP5F(SELF):
  SELF.session.open(CCDe3n, barTheme=CCDe3n.VVEpKA
      , titlePrefix = ""
      , fncToRun  = CCCu2Z.VVzhFH
      , VVuJdT = BF(CCCu2Z.VVv4qu, SELF))
 @staticmethod
 def VVzhFH(VVEkKt):
  bName = CCu3Fm.VVKht1()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVEkKt.VVyzJx = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CCu3Fm.VVQwOu()
  if not VVEkKt or VVEkKt.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVEkKt.VVQWYw(totCh)
   for serv in services:
    if not VVEkKt or VVEkKt.isCancelled:
     return
    VVEkKt.VVHjIy(1)
    fullRef = serv[0]
    if FF2IUY(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFiRgM(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     if span:
      valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CCwh19.VVx1dg(decodedUrl)
      if valid and mode == "itv" : uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
      else      : uHost = uUser = uPass = uId = uChName = ""
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCCu2Z.VVERnQ(m3u_Url)
     if VVEkKt:
      VVEkKt.VVoXWq(totEpgOK, uChName)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCCu2Z.VVOAQF(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CC2gVv.VVcLdy(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if VVEkKt:
     VVEkKt.VVyzJx = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVEkKt.VVyzJx = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 @staticmethod
 def VVv4qu(SELF, VVLnvr, VVyzJx, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVyzJx
  title = "IPTV EPG Import"
  if err:
   FFnHzu(SELF, err, title=title)
  else:
   if VVLnvr and totEpgOK > 0:
    CC2gVv.VVAhVB()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FF6TiS(str(totNotIptv), VVsIVN)
    if totServErr : txt += "Server Errors\t: %s\n" % FF6TiS(str(totServErr) + t1, VVsIVN)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FF6TiS(str(totInv), VVsIVN)
   if not VVLnvr:
    title += "  (stopped)"
   FFJRXg(SELF, txt, title=title)
 @staticmethod
 def VVOAQF(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCCu2Z.VVacAj(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCCu2Z.VVex4B(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCCu2Z.VVU8hy(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CCCu2Z.VVU8hy(item, "lang"        ).upper()
    now_playing   = CCCu2Z.VVU8hy(item, "now_playing"      )
    start    = CCCu2Z.VVU8hy(item, "start"        )
    start_timestamp  = CCCu2Z.VVU8hy(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCCu2Z.VVU8hy(item, "start_timestamp"     )
    stop_timestamp  = CCCu2Z.VVU8hy(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCCu2Z.VVU8hy(item, "stop_timestamp"      )
    tTitle    = CCCu2Z.VVU8hy(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VV2JiH(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCCu2Z.VV7syJ(catID, MAX_4b)
  TSID = CCCu2Z.VV7syJ(chNum, MAX_4b)
  ONID = CCCu2Z.VV7syJ(chNum, MAX_4b)
  NS  = CCCu2Z.VV7syJ(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VV7syJ(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VV8ga2(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVrucS(mode):
  if   mode in ("itv"  , CCCu2Z.VVkN6E)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCCu2Z.VVLb5y)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCCu2Z.VVaI7O) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCCu2Z.VVAaer) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCCu2Z.VVvSNq    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVkyv4(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVrV5t:
   excl = FFdsA4(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFnHzu(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FF5Sgm('find %s %s %s' % (path, excl, par))
  if files:
   err = CCr5c7.VVlY6G(files)
   if err : FFnHzu(self, err + FF6TiS('\n\n( Change "IPTV Hosts Files Path" to "Custom" and try again )', VVpkep))
   else : return files
  else:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFnHzu(self, err)
  return []
 @staticmethod
 def VVK76l():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FFxJSp(path)
  return "/"
 @staticmethod
 def VVDAXv(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CCCu2Z.VVOAQF(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FFnHzu(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVXbiY, VVVy8H, VVvi08, VVTrrJ = CCCu2Z.VVrucS("")
   VVIqI1 = ("Home Menu" , FFaoGB, [])
   VV91FP  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVsZoP  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFqiz1(SELF, None, title="Programs for : " + chName, header=header, VVVC4T=pList, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=24, VV91FP=VV91FP, VVIqI1=VVIqI1, VVXbiY=VVXbiY, VVVy8H=VVVy8H, VVvi08=VVvi08, VVTrrJ=VVTrrJ)
  else:
   FFnHzu(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVnoeh(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VVUPPU(self, isPortal, line, VVsxjbObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FFWBJu(self, BF(self.VVKqVs, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FFCfiF(confItem, line)
   FFcZi2(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VVKqVs(self, title, confItem):
  FFCfiF(confItem, "")
  FFcZi2(self, "Removed from IPTV Menu.", title=title)
 def VVtGqg(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VVm08Q(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FFG53m(self, BF(self.VVM9OU, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FFnHzu(self, "Incorrect server data !")
 @staticmethod
 def VVUjaF(SELF, isPortal, line, VVsxjbObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCCu2Z.VVK76l()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFnHzu(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFcZi2(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFnHzu(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVrQT7(self, source, mode, curBName, VVR0r4, title, txt, colList):
  isMulti = VVR0r4.VV9Jt5
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVR0r4.VVkGfp()
   totTxt = "%d Service%s" % (tot, FFJHIK(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FF6TiS(totTxt, VVpkep)
  curBName2 = ""
  if self.curUrl:
   name = iUrlparse(self.curUrl).netloc
   if name:
    curBName2 = "%s (%s)" % (curBName, name.split(":")[0])
  title = "Add to Bouquet"
  mSel = CCeaGv(self, VVR0r4, addSep=False)
  thTxt = "Adding Services ..."
  VVegP0, cbFncDict = [], None
  VVegP0.append(VVHMBI)
  if itemsOK:
   VVegP0.append(("Add %s to New Bouquet : %s"    % (totTxt, FF6TiS(curBName , VVUdsq)), "addToCur1"))
   if curBName2: VVegP0.append(("Add %s to New Bouquet : %s" % (totTxt, FF6TiS(curBName2, VVOEUI)) , "addToCur2"))
   VVegP0.append(("Add %s to Existing Bouquet ..."   % (totTxt)            , "addToNew" ))
   cbFncDict = { "addToCur1": BF(FFG53m, mSel.VVR0r4, BF(self.VVBRA1,source, mode, curBName , VVR0r4, title), title=thTxt)
      , "addToCur2": BF(FFG53m, mSel.VVR0r4, BF(self.VVBRA1,source, mode, curBName2, VVR0r4, title), title=thTxt)
      , "addToNew" : BF(self.VVkIAc, source, mode, curBName, VVR0r4, title)
      }
  else:
   VVegP0.append(("Add to Bouquet (nothing selected)", ))
  mSel.VVxIpf(VVegP0, cbFncDict, width=1200)
 def VVBRA1(self, source, mode, curBName, VVR0r4, Title):
  chUrlLst = self.VVoJSQ(source, mode, VVR0r4)
  CCu3Fm.VVCuKe(self, Title, curBName, "", chUrlLst)
 def VVkIAc(self, source, mode, curBName, VVR0r4, Title):
  picker = CCu3Fm(self, VVR0r4, Title, BF(self.VVoJSQ, source, mode, VVR0r4), defBName=curBName)
 def VVoJSQ(self, source, mode, VVR0r4):
  totChange = 0
  isMulti = VVR0r4.VV9Jt5
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVR0r4.VVtxRM()):
   if not isMulti or VVR0r4.VVFcPL(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVXTJq(mode, row)
     refCode, chUrl = self.VVkJgo(self.VVO1en, self.VVQtHS, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VVxeS6(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVMMKf(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
class CCdJHg(object):
 def __init__(self, SELF):
  SELF["mySbFrm"] = Label()
  SELF["mySbBak"] = Label()
  SELF["mySbSld"] = Label()
  self.frm, self.bak, self.sld = SELF["mySbFrm"], SELF["mySbBak"], SELF["mySbSld"]
  self.frmI = self.bakI = self.sldI = None
  self.sldX = self.sldY = self.sldW = self.sldH = 0
  for obj in (self.frm, self.bak, self.sld): obj.hide()
 def VVUQ8F(self, x, y, w, h, bW=1, frmColor="#11aaaaaa", bakColor="#11003344", sldColor="#11ff8000"):
  x, y, w, h = int(x), int(y), int(w), int(h)
  FFo6oa(self.frm, frmColor)
  FFo6oa(self.bak, bakColor)
  FFo6oa(self.sld, sldColor)
  self.frmI, self.bakI, self.sldI = self.frm.instance, self.bak.instance, self.sld.instance
  self.frmI.move(ePoint(x, y))
  self.frmI.resize(eSize(w, h))
  self.bakI.move(ePoint(x + bW, y + bW))
  self.bakI.resize(eSize(w - bW * 2, h - bW * 2))
  self.sldX = x + bW
  self.sldY = y + bW
  self.sldW = w - bW * 2
  self.sldH = h - bW * 2
  self.sldI.move(ePoint(self.sldX, self.sldY))
  self.sldI.resize(eSize(self.sldW, self.sldH))
 def VVkcjA(self, val, maxN):
  if maxN < 2:
   for obj in (self.frm, self.bak, self.sld): obj.hide()
  else:
   for obj in (self.frm, self.bak, self.sld): obj.show()
   visH = max(self.sldH / maxN, self.sldH * 0.05)
   self.sldI.resize(eSize(self.sldW, int(visH)))
   y = FFXM7k(val, 1, maxN, 0, self.sldH - visH)
   self.sldI.move(ePoint(self.sldX, int(self.sldY + y)))
class CCG33Y(CCdJHg):
 def __init__(self, rows, cols, colorCfg):
  self.TOTAL_ROWS   = rows
  self.TOTAL_COLS   = cols
  self.PAGE_ITEMS   = self.TOTAL_ROWS * self.TOTAL_COLS
  self.colorCfg   = colorCfg
  self.totalItems   = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.isBusy    = False
  CCdJHg.__init__(self, self)
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "up" : self.VV7Q5E   ,
   "down" : self.VVNA9M  ,
   "left" : self.VVITAJ  ,
   "right" : self.VVHgAf  ,
   "next" : self.VVCKqL ,
   "last" : self.VVunAJ
  }, -1)
 def VVHtEg(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
    self["myPosterLbl%d%d" % (row, col)].instance.setNoWrap(True)
  gap = int(self.skinParam["marginLeft"] / 1)
  topBox = self["myPosterPic%d%d" % (0, 0)].instance
  botBox = self["myPosterPic%d%d" % (self.TOTAL_ROWS - 1, self.TOTAL_COLS - 1)].instance
  w = 20
  y = topBox.position().y() - int(self.skinParam["marginTop"] / 2) + 2
  h = self.skinParam["height"] - self.skinParam["barHeight"] - y - 2
  x = self.skinParam["width"] - w - 2
  self.VVUQ8F(x, y, w, h)
  self.VVkRUB()
 def VVDaEC(self):
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > self.totalItems: f1 = self.totalItems
  if f2 > self.totalItems: f2 = self.totalItems
  return f1, f2
 def VV7Q5E(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVhSal()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVcpxm()
 def VVNA9M(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVng3z()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVcpxm()
 def VVITAJ(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVhSal()
  else:
   self.curCol -= 1
   self.VVcpxm()
 def VVHgAf(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVng3z()
  else:
   self.curCol += 1
   self.VVcpxm()
 def VVunAJ(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVcpxm(True)
 def VVCKqL(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVcpxm(True)
 def VVng3z(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVcpxm(True)
 def VVhSal(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVcpxm(True)
 def VVcpxm(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVwK9Z = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVwK9Z: self.curPage = VVwK9Z
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  self.VVL8IZ()
  self.VVkcjA(self.curPage + 1, self.totalPages)
  FFDxKA(BF(self.VVCgeQ, force or not oldPage == self.curPage, VVwK9Z))
 def VVCgeQ(self, force, VVwK9Z):
  if force:
   self.VVPwpG()
  if self.curPage == VVwK9Z:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  self.curIndex = self.curPage * self.PAGE_ITEMS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVL8IZ()
  boxT, boxW, boxH = self.skinParam["extraPar"]
  self["myPiconPtr"].instance.move(ePoint(int(boxW * self.curCol), int(boxT + boxH * self.curRow)))
  self["myPiconPtr"].show()
 def VVUsey(self, ndx):
  if ndx > -1 and ndx < self.totalItems:
   self.curPage = int(ndx / self.PAGE_ITEMS)
   firstInPage  = self.curPage * self.PAGE_ITEMS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVcpxm(True)
  else:
   FFtMfC(self, "Not found", 1000)
 def VVviJw(self):
  self.VVUsey(self.totalItems - 1 if self.curIndex == 0 else 0)
 def VVg7d3(self):
  self["myPiconPtr"].hide()
 def VVpafX(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)].hide()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
 def VV6xDt(self):
  fg = bg = self.colorCfg.getValue()
  self.session.openWithCallback(self.VV1SHJ, CCHuHv, defFG=fg, defBG=bg, onlyBG=True)
 def VV1SHJ(self, fg, bg):
  if bg:
   FFCfiF(self.colorCfg, bg)
   self.VVkRUB()
 def VVkRUB(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFo6oa(self["myPosterRep%d%d" % (row, col)], self.colorCfg.getValue())
class CCaknG(Screen, CCG33Y):
 def __init__(self, session, VVR0r4, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FFAJVu(VVAHed, 1870, 1030, 50, 10, 10, "#33000000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "Server Browser"
  self.VVR0r4  = VVR0r4
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.VVVC4T    = []
  self.totPosterUrls  = 0
  self.totalItems   = 0
  FFsw8F(self, self.Title)
  CCG33Y.__init__(self, 2, 6, CFG.transpColorPosters)
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVAVra, subPath)
  if not pathExists(self.pPath):
   os.system(FFNxGN("mkdir -p '%s'" % (self.pPath)))
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myAction"].actions.update(
  {
   "ok" : self.VVu0DR    ,
   "cancel": self.close    ,
   "menu" : self.VV3cNR ,
   "info" : self.VVpgKG  ,
   "0"  : self.VVviJw
  })
  self.onShown.append(self.VVoCo0)
  self.onClose.append(self.onExit)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FF6aqB(self)
  FFnLuC(self)
  self["myPiconInf0"].instance.setNoWrap(True)
  self["myPiconInf1"].instance.setNoWrap(True)
  self.VVHtEg()
  self.VVYdbD()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VV3cNR(self):
  chName, subj, desc, fName, picUrl = self.VVVC4T[self.curIndex]
  VVegP0 = []
  txt1 = "Show Selected Picture"
  txt2 = "Copy Selected Picture to Export-Directory"
  txt3 = "Set Selected Picture as a Poster for a Local Media"
  if fName:
   VVegP0.append((txt1, "VVv1gj"   ))
   VVegP0.append((txt2, "VVNNKT"  ))
   VVegP0.append((txt3, "VVQbwF" ))
  else:
   VVegP0.append((txt1, ))
   VVegP0.append((txt2, ))
   VVegP0.append((txt3, ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Cache details"       , "VV7tz1"  ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Change Poster/Picon Transparency Color" , "VV6xDt" ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Help (Keys)"        , "help"     ))
  FFJcY1(self, self.VV1HrG, title=self.Title, VVegP0=VVegP0)
 def VV1HrG(self, item=None):
  if item is not None:
   if   item == "VVv1gj"   : self.VVv1gj()
   elif item == "VVNNKT"   : self.VVNNKT()
   elif item == "VVQbwF"  : self.VVQbwF()
   elif item == "VV7tz1"  : FFG53m(self, self.VV7tz1, title="Calculating ...")
   elif item == "VV6xDt": self.VV6xDt()
   elif item == "help"     : FFHU3T(self, "_help_servBr", "Server Browser (Keys)")
 def VVu0DR(self):
  self.VVR0r4.VVwqjr(self.curIndex)
  self.VVR0r4.VV8Zm9()
 def VVpgKG(self):
  self.VVR0r4.VVwqjr(self.curIndex)
  self.VVR0r4.VV1dxz()
 def VVYdbD(self):
  for colList in self.VVR0r4.VVtxRM():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = os.path.basename(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VVVC4T.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalItems = len(self.VVVC4T)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  ndx = self.VVR0r4.VVVZYd()
  self.curPage = int(ndx / self.PAGE_ITEMS)
  ndx     -= self.curPage * self.PAGE_ITEMS
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VVcpxm(True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVufrD)
  except:
   self.timer.callback.append(self.VVufrD)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VVsalV)
  self.myThread.start()
 def VVsalV(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VVVC4T):
    if not self.stopThread:
     if picUrl and not fName:
      fName = os.path.basename(picUrl)
      path, err = FFHXM5(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       os.system(FFNxGN("mv -f '%s' '%s'" % (path, self.pPath + fName)))
       self.VVVC4T[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VVufrD(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVSGHr + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalItems
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVVC4T[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VVVC4T[ndx] = (chName, subj, desc, fName, "")
     try:
      CCeTYo.VVEcC6(self["myPosterPic%d%d" % (row, col)], path)
     except:
      pass
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVPwpG(self):
  self.VVpafX()
  f1, f2 = self.VVDaEC()
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVVC4T[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.setText(chName)
   lbl.show()
   pic.show()
   path = ""
   if fName:
    path = self.pPath + fName
   if not fileExists(path):
    path = VVeop3 + "iptv.png"
   try:
    CCeTYo.VVEcC6(pic, path)
    pic.show()
   except:
    pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVL8IZ(self):
  chName, subj, desc, fName, picUrl = self.VVVC4T[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVv1gj(self):
  chName, subj, desc, fName, picUrl = self.VVVC4T[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCDdSC.VVvctb(self, self.pPath + fName)
  else          : FFtMfC(self, "File not found", 1500)
 def VVNNKT(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VVVC4T[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   res = os.system(FFNxGN("cp -f '%s' '%s'" % (self.pPath + fName, dstF)))
   if res == 0 : FFcZi2(self, "File copied to:\n\n%s" % dstF, title=title)
   else  : FFnHzu(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FFnHzu(self, "No Poster/PIcon found", title=title)
 def VVQbwF(self):
  self.session.openWithCallback(self.VVqoIu, BF(CCr5c7, patternMode="movies", VV3Cmf=CFG.MovieDownloadPath.getValue()))
 def VVqoIu(self, path):
  if path:
   title = "Set Selected Picture as a Poster for a Local Media"
   chName, subj, desc, fName, picUrl = self.VVVC4T[self.curIndex]
   if fName:
    srcF = self.pPath + fName
    dstF = "%s%s" % (os.path.splitext(path)[0], os.path.splitext(srcF)[1])
    res = os.system(FFNxGN("cp -f '%s' '%s'" % (srcF, dstF)))
    if res == 0 : FFcZi2(self, "File copied to:\n\n%s" % dstF, title=title)
    else  : FFnHzu(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstF), title=title)
    CCeTYo.VVSNHe(dstF)
   else:
    FFnHzu(self, "No Poster/PIcon found", title=title)
 def VV7tz1(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVAVra, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FFN7zW("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CCr5c7.VVJv7c(size)
   txt += "%s\n    %s\n\n" % (FF6TiS(path, VVpkep), size)
  mainPath = "%sPosters" % VVAVra
  totFiles = FFN7zW("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FFJHIK(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FF6TiS("Total space used by Posters/PIcons%s:" % totFTxt, VVBfw8), CCr5c7.VVJv7c(totSize))
  mountPath = CCr5c7.VV3dPe(mainPath)
  if pathExists(mountPath):
   totSize  = CCr5c7.VVHFaI(mountPath)
   freeSize = CCr5c7.VVPnvT(mountPath)
   usedSize = CCr5c7.VVJv7c(totSize - freeSize)
   totSize  = CCr5c7.VVJv7c(totSize)
   freeSize = CCr5c7.VVJv7c(freeSize)
   txt += "%s\n" % VVtc24
   txt += FF6TiS("Media Space:\n", VVPN93)
   txt += "    Media Path\t: %s\n" % FF6TiS(mountPath, VVJCMd)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FFJRXg(self, txt, title="Cache Used Size", height=1000)
class CCeTYo(Screen, CCG33Y):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFAJVu(VVAHed, 1870, 1030, 50, 10, 10, "#33440000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = title
  self.VVVC4T    = lst
  FFsw8F(self, self.Title)
  CCG33Y.__init__(self, 2, 6, CFG.transpColorMovies)
  self["myAction"].actions.update(
  {
   "ok" : self.VVu0DR    ,
   "cancel": self.close    ,
   "menu" : self.VV5hc8 ,
   "info" : self.VV51wy  ,
   "0"  : self.VVviJw
  })
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FF6aqB(self)
  FFnLuC(self)
  self["myPiconInf0"].instance.setNoWrap(True)
  self["myPiconInf1"].instance.setNoWrap(True)
  self.VVHtEg()
  self.totalItems = len(self.VVVC4T)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVcpxm(True)
 def VVPwpG(self):
  self.VVpafX()
  f1, f2 = self.VVDaEC()
  mPath = CFG.MovieDownloadPath.getValue()
  row = col = 0
  for ndx in range(f1, f2):
   path, movie, poster = self.VVVC4T[ndx]
   path = os.path.join(mPath, path)
   path = os.path.join(path, movie)
   if poster: poster = os.path.join(os.path.dirname(path), poster)
   else  : poster = VVeop3 + "noPos.png"
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.setText(os.path.splitext(os.path.basename(path))[0])
   lbl.show()
   pic.show()
   try:
    self.VVEcC6(pic, poster)
   except:
    pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVS0vf(self):
  path, movie, poster = self.VVVC4T[self.curIndex]
  path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
  path = os.path.join(path, movie)
  if poster:
   poster = os.path.join(os.path.dirname(path), poster)
  return path, poster
 def VVL8IZ(self):
  path, poster = self.VVS0vf()
  self["myPiconInf0"].setText("  " + os.path.splitext(os.path.basename(path))[0] + "  ")
  self["myPiconInf1"].setText("   " + os.path.dirname(path) + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VV5hc8(self):
  path, poster = self.VVS0vf()
  VVegP0 = []
  VVegP0.append(("Go to movie ...", "VVDJmN"))
  VVegP0.append(VVHMBI)
  txt1 = "Show Poster"
  txt2 = "Copy Poster to Export-Directory"
  if poster:
   VVegP0.append((txt1, "VVv1gj" ))
   VVegP0.append((txt2, "VVNNKT"))
  else:
   VVegP0.append((txt1, ))
   VVegP0.append((txt2, ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Change Poster/Picon Transparency Color"  , "VV6xDt" ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Change Poster (from current movie path) ..." , "VVx0oB1"  ))
  VVegP0.append(("Change Poster (locate manually) ..."   , "VVx0oB2"  ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Help (Keys)"         , "help"     ))
  FFJcY1(self, self.VVbCMy, title=self.Title, VVegP0=VVegP0)
 def VVbCMy(self, item=None):
  if item is not None:
   if   item == "VVDJmN"    : self.VVDJmN()
   elif item == "VVNNKT"    : self.VVNNKT()
   elif item == "VVv1gj"    : self.VVv1gj()
   elif item == "VV6xDt" : self.VV6xDt()
   elif item == "VVx0oB1"  : self.VVx0oB()
   elif item == "VVx0oB2"  : self.VVx0oB(True)
   elif item == "help"      : FFHU3T(self, "_help_movBr", "Movies Browser (Keys)")
 def VVDJmN(self):
  VVzto2 = []
  for ndx, item in enumerate(self.VVVC4T):
   path, movie, poster = item
   path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
   VVzto2.append((os.path.splitext(movie)[0], path, str(ndx)))
  VVzto2.sort(key=lambda x: x[0].lower())
  VV91FP = ("Select" , self.VVxHrt, [])
  header  = ("Name" , "Path", "NDX.")
  widths  = (60  , 40 , 0  )
  FFqiz1(self, None, title="Select Movie", width=1800, height=1000, header=header, VVVC4T=VVzto2, VVx2iV=widths, VVwwGj=26, VV91FP=VV91FP, lastFindConfigObj=CFG.lastFindMovie)
 def VVxHrt(self, VVR0r4, title, txt, colList):
  self.VVUsey(int(colList[2].strip()))
  VVR0r4.cancel()
 def VVu0DR(self):
  path, poster = self.VVS0vf()
  FFG53m(self, BF(CCr5c7.VVU4yQ, self, path), title="Playing Media ...")
 def VV51wy(self):
  path, poster = self.VVS0vf()
  txt = "%s:\n%s\n\n" % (FF6TiS("Path", VVpkep), path)
  size = FFREV4(path)
  if size > -1:
   txt += "%s:\n%s\n\n" % (FF6TiS("File Size", VVpkep), CCr5c7.VVJv7c(size))
  if poster:
   txt += "%s:\n%s" % (FF6TiS("Poster", VVpkep), poster)
  FFJRXg(self, txt, title="Media File Information")
 def VVv1gj(self):
  path, poster = self.VVS0vf()
  if fileExists(poster): CCDdSC.VVvctb(self, poster)
  else     : FFtMfC(self, "No Poster", 1500)
 def VVNNKT(self):
  title = "Copy Poster"
  path, poster = self.VVS0vf()
  if poster:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = os.path.join(dstPath, os.path.basename(poster))
   res = os.system(FFNxGN("cp -f '%s' '%s'" % (poster, dstF)))
   if res == 0 : FFcZi2(self, "File copied to:\n\n%s" % dstF, title=title)
   else  : FFnHzu(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (poster, dstPath), title=title)
  else:
   FFtMfC(self, "No Poster", 1500)
 def VVx0oB(self, isManual=False):
  path, poster = self.VVS0vf()
  sDir = FFxJSp(os.path.dirname(path))
  if isManual:
   self.session.openWithCallback(BF(self.VVVWUJ, sDir, path), BF(CCr5c7, patternMode="poster", VV3Cmf=sDir))
  else:
   VVegP0 = []
   for item in [f for f in os.listdir(sDir) if iSearch(r"^.*\.(jpg|png)", f, IGNORECASE)]:
    VVegP0.append((os.path.basename(item), sDir + item))
   if VVegP0:
    VVegP0.sort(key=lambda x: x[0].lower())
    infoBtnFnc = self.VVZ02T
    FFJcY1(self, BF(self.VVVWUJ, sDir, path), VVegP0=VVegP0, title="Posters", infoBtnFnc=infoBtnFnc, yellowBasePath=sDir)
   else:
    FFtMfC(self, "No jpg/png in current dir", 1500)
 def VVZ02T(self, menuInstance, txt, ref, ndx):
  CCDdSC.VVvctb(self, VVQyig=ref)
 def VVVWUJ(self, sDir, path, pPath=None):
  if pPath:
   newPath = sDir + os.path.splitext(os.path.basename(path))[0] + os.path.splitext(pPath)[1].lower()
   res = os.system(FFNxGN("cp -f '%s' '%s'" % (pPath, newPath)))
   if res == 0 or pPath == newPath:
    self.VVVC4T[self.curIndex] = (self.VVVC4T[self.curIndex][0], self.VVVC4T[self.curIndex][1], os.path.basename(newPath))
    FFG53m(self, self.VVPwpG)
    CCeTYo.VVSNHe(newPath)
   else:
    FFtMfC(self, "Cannot copy file", 1000)
 @staticmethod
 def VVSNHe(path):
  if path.endswith(".png"):
   fileNoExt = path[:-4]
   jpgF = fileNoExt + ".jpg"
   if fileExists(jpgF):
    c = 1
    newF = "%s_%d.jpg" % (fileNoExt, c)
    while fileExists(newF):
     c += 1
     newF = "%s_%d.jpg" % (fileNoExt, c)
    os.system(FFNxGN("mv -f '%s' '%s'" % (jpgF, newF)))
 @staticmethod
 def VVEcC6(pixObj, path):
  if path.endswith(".png"):
   pixObj.instance.setPixmapFromFile(path)
  else:
   png = LoadPixmap(path)
   pixObj.instance.setScale(1)
   pixObj.instance.setPixmap(png)
 @staticmethod
 def VVLlqm(SELF):
  eLst = CCAnG2.VVXWgC()["mov"]
  mPath = CFG.MovieDownloadPath.getValue()
  lst = []
  for (Dir, dirs, files) in os.walk(mPath):
   for f in files:
    if os.path.splitext(f)[1].lstrip(".").lower() in eLst:
     path = os.path.join(Dir, f)
     poster = ""
     for ext in ("jpg", "png"):
      pic = "%s.%s" % (os.path.splitext(path)[0], ext)
      if fileExists(pic):
       poster = os.path.basename(pic)
       break
     lst.append((os.path.dirname(path).replace(mPath, ""), os.path.basename(path), poster))
  title = "Movies Browser"
  lst.sort(key=lambda x: x[1].lower())
  if lst: SELF.session.open(CCeTYo, title, lst)
  else  : FFnHzu(SELF, "No movies found in:\n\n%s\n\nYou can change the path from settings." % mPath, title=title)
class CCMiPi(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFAJVu(VVtBbU, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVK8oP  = 0
  self.VVbCz1 = 1
  self.VV07Sl  = 2
  VVegP0 = []
  VVegP0.append(("Find in All Service (from filter)" , "VVhdGI" ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Find in All (Manual Entry)"   , "VVGkdD"    ))
  VVegP0.append(("Find in TV"       , "VV2BeR"    ))
  VVegP0.append(("Find in Radio"      , "VVRZwE"   ))
  if self.VVdPlb():
   VVegP0.append(VVHMBI)
   VVegP0.append(("Hide Channel: %s" % self.servName , "VVdpjx"   ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Zap History"       , "VVYlyR"    ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("IPTV Tools"       , "iptv"      ))
  VVegP0.append(("PIcons Tools"       , "PIconsTools"     ))
  VVegP0.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  VVegP0.append(("EPG Tools"       , "epgTools"     ))
  FFsw8F(self, VVegP0=VVegP0, title=title)
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FFCoOh(self["myMenu"])
  FFUSMR(self)
  if self.isFindMode:
   self.VVxX7H(self.VVxzT4())
 def VVu0DR(self):
  global VVtXrR
  VVtXrR = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVGkdD"    : self.VVGkdD()
   elif item == "VVhdGI" : self.VVhdGI()
   elif item == "VV2BeR"    : self.VV2BeR()
   elif item == "VVRZwE"   : self.VVRZwE()
   elif item == "VVdpjx"   : self.VVdpjx()
   elif item == "VVYlyR"    : self.VVYlyR()
   elif item == "iptv"       : self.session.open(CCCu2Z)
   elif item == "PIconsTools"     : self.session.open(CC96Ar)
   elif item == "ChannelsTools"    : self.session.open(CCcecd)
   elif item == "epgTools"      : self.session.open(CC2gVv)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VV2BeR(self) : self.VVxX7H(self.VVK8oP)
 def VVRZwE(self) : self.VVxX7H(self.VVbCz1)
 def VVGkdD(self) : self.VVxX7H(self.VV07Sl)
 def VVxX7H(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFYvs0(self, BF(self.VVX8ft, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VVhdGI(self):
  filterObj = CCSAYR(self)
  filterObj.VVnKMp(self.VV3Pmb)
 def VV3Pmb(self, item):
  self.VVX8ft(self.VV07Sl, item)
 def VVdPlb(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FF2IUY(self.refCode)        : return False
  return True
 def VVX8ft(self, mode, VVBbiK):
  FFG53m(self, BF(self.VVraXW, mode, VVBbiK), title="Searching ...")
 def VVraXW(self, mode, VVBbiK):
  if VVBbiK:
   VVBbiK = VVBbiK.strip()
  if VVBbiK:
   self.findTxt = VVBbiK
   CFG.lastFindContextFind.setValue(VVBbiK)
   if   mode == self.VVK8oP  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVbCz1 : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVBbiK)
   if len(title) > 55:
    title = title[:55] + ".."
   VVzto2 = self.VV066z(VVBbiK, servTypes)
   if self.isFindMode or mode == self.VV07Sl:
    VVzto2 += self.VVPSW9(VVBbiK)
   if VVzto2:
    VVzto2.sort(key=lambda x: x[0].lower())
    VVs5Sk = self.VVicaE
    VV91FP  = ("Zap"   , self.VVkafh    , [])
    VVdn6T = ("Current Service", self.VVof5u , [])
    VVljWo = ("Options"  , self.VVcsq2 , [])
    VVBSYf = (""    , self.VVenMI , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVsZoP  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFqiz1(self, None, title=title, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VV91FP=VV91FP, VVs5Sk=VVs5Sk, VVdn6T=VVdn6T, VVljWo=VVljWo, VVBSYf=VVBSYf, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVxX7H(self.VVxzT4())
    FFcZi2(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VV066z(self, VVBbiK, servTypes):
  VVVC4T = CCcecd.VVZoCU(servTypes)
  VVzto2 = []
  if VVVC4T:
   VVCpBm, VVnYkd = FF1mjb()
   tp = CCxkcu()
   words, asPrefix = CCSAYR.VVaVMf(VVBbiK)
   colorYellow  = CCbPmL.VV4viU(VVBfw8)
   colorWhite  = CCbPmL.VV4viU(VVZ51O)
   for s in VVVC4T:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFkzUr(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVCpBm:
        STYPE = VVnYkd[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVyO6x(refCode)
       if not "-S" in syst:
        sat = syst
       VVzto2.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVzto2
 def VVPSW9(self, VVBbiK):
  VVBbiK = VVBbiK.lower()
  VVzto2 = []
  colorYellow  = CCbPmL.VV4viU(VVBfw8)
  colorWhite  = CCbPmL.VV4viU(VVZ51O)
  for b in CCu3Fm.VVfpE8():
   VVztNS  = b[0]
   VVviZM  = b[1].toString()
   VVATEZ = eServiceReference(VVviZM)
   VVefrB = FFXd2v(VVATEZ)
   for service in VVefrB:
    refCode  = service[0]
    if FF2IUY(refCode):
     servName = service[1]
     if VVBbiK in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVBbiK), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVzto2.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVzto2
 def VVxzT4(self):
  VVcxBI = InfoBar.instance
  if VVcxBI:
   VVHQTD = VVcxBI.servicelist
   if VVHQTD:
    return VVHQTD.mode == 1
  return self.VV07Sl
 def VVicaE(self, VVR0r4):
  self.close()
  VVR0r4.cancel()
 def VVkafh(self, VVR0r4, title, txt, colList):
  FFGrAa(VVR0r4, colList[2], VVMo36=False, checkParentalControl=True)
 def VVof5u(self, VVR0r4, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(VVR0r4)
  if refCode:
   VVR0r4.VVRgyb(2, FFgjov(refCode, iptvRef, chName), True)
 def VVcsq2(self, VVR0r4, title, txt, colList):
  servName = colList[0]
  mSel = CCeaGv(self, VVR0r4)
  VVegP0, cbFncDict = CCcecd.VVTdBB(self, VVR0r4, servName, 2)
  mSel.VVxIpf(VVegP0, cbFncDict)
 def VVenMI(self, VVR0r4, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFiqcT(self, fncMode=CC6biu.VVYL5u, refCode=refCode, chName=chName, text=txt)
 def VVdpjx(self):
  FFWBJu(self, self.VVJwjI, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVJwjI(self):
  ret = FFqMFs(self.refCode, True)
  if ret:
   self.VVbMbE()
   self.close()
  else:
   FFtMfC(self, "Cannot change state" , 1000)
 def VVbMbE(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVEQLU()
  except:
   self.VVEq0T()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFg1na(self, serviceRef)
 def VVEQLU(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVcxBI = InfoBar.instance
   if VVcxBI:
    VVHQTD = VVcxBI.servicelist
    if VVHQTD:
     hList = VVHQTD.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVHQTD.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVHQTD.history  = newList
       VVHQTD.history_pos = pos
 def VVEq0T(self):
  VVcxBI = InfoBar.instance
  if VVcxBI:
   VVHQTD = VVcxBI.servicelist
   if VVHQTD:
    VVHQTD.history  = []
    VVHQTD.history_pos = 0
 def VVYlyR(self):
  VVcxBI = InfoBar.instance
  VVzto2 = []
  if VVcxBI:
   VVHQTD = VVcxBI.servicelist
   if VVHQTD:
    VVCpBm, VVnYkd = FF1mjb()
    for serv in VVHQTD.history:
     refCode = serv[-1].toString()
     chName = FFqfF5(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FF2IUY(refCode)
     isSRel = FFabwQ(refCode)
     sat = "-" if isIptv and not isSRel or isLocal else FFkzUr(refCode, True)
     if isIptv : STYPE = "Stream Relay" if isSRel else "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVCpBm:
       STYPE = VVnYkd[sTypeInt]
     VVzto2.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVzto2:
   VV91FP  = ("Zap"   , self.VVOVEn   , [])
   VVljWo = ("Clear History" , self.VVVHwZ   , [])
   VVBSYf = (""    , self.VVURU6 , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVsZoP  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFqiz1(self, None, title=title, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=28, VV91FP=VV91FP, VVljWo=VVljWo, VVBSYf=VVBSYf)
  else:
   FFcZi2(self, "Not found", title=title)
 def VVOVEn(self, VVR0r4, title, txt, colList):
  FFGrAa(VVR0r4, colList[3], VVMo36=False, checkParentalControl=True)
 def VVVHwZ(self, VVR0r4, title, txt, colList):
  FFWBJu(self, BF(self.VVU7Ue, VVR0r4), "Clear Zap History ?")
 def VVU7Ue(self, VVR0r4):
  self.VVEq0T()
  VVR0r4.cancel()
 def VVURU6(self, VVR0r4, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFiqcT(self, fncMode=CC6biu.VVLAP8, refCode=refCode, chName=chName, text=txt)
class CC96Ar(Screen, CCG33Y):
 VVwsmq   = 0
 VVXLwt  = 1
 VVyKHm  = 2
 VVqbC1  = 3
 VVA9BP  = 4
 VVxIAC  = 5
 VVolpx  = 6
 VVaKWL  = 7
 VVhrhO = 8
 VVfBsv = 9
 VV1Mh6 = 10
 VVKXp4 = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFAJVu(VVnHvF, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "PIcons Tools"
  self.pPath    = CC96Ar.VVwdi5()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVVC4T    = []
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  FFsw8F(self, self.Title)
  FF154z(self["keyRed"] , "OK = Zap")
  FF154z(self["keyGreen"] , "Current Service")
  FF154z(self["keyYellow"], "Page Options")
  FF154z(self["keyBlue"] , "Filter")
  CCG33Y.__init__(self, 5, 7, CFG.transpColorPicons)
  self["myAction"].actions.update(
  {
   "ok"  : self.VVzZVQ     ,
   "green"  : self.VVEvYu    ,
   "yellow" : self.VVGQlx     ,
   "blue"  : self.VVZP7R     ,
   "menu"  : self.VVoKAy     ,
   "info"  : self.VVDAdV    ,
   "pageUp" : BF(self.VVIjq5, True) ,
   "chanUp" : BF(self.VVIjq5, True) ,
   "pageDown" : BF(self.VVIjq5, False) ,
   "chanDown" : BF(self.VVIjq5, False) ,
   "0"   : self.VVviJw  ,
   "cancel" : self.close
  })
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FF6aqB(self)
  FFnLuC(self)
  FFo6oa(self["keyRed"], "#0a333333")
  self.VVHtEg()
  self.VVg7d3()
  FFG53m(self, BF(self.VVmQDs, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVoKAy(self):
  if not self.isBusy:
   VVegP0 = []
   VVegP0.append(("Statistics"           , "VV8cfz"    ))
   VVegP0.append(VVHMBI)
   VVegP0.append(("Suggest PIcons for Current Channel"     , "VVQ4WC"   ))
   VVegP0.append(("Set to Current Channel (copy file)"     , "VVuuMe_file"  ))
   VVegP0.append(("Set to Current Channel (as SymLink)"     , "VVuuMe_link"  ))
   VVegP0.append(VVHMBI)
   VVegP0.append(("Export Current File Names List"      , "VV8qg3" ))
   VVegP0.append(CC96Ar.VVsACl())
   VVegP0.append(VVHMBI)
   movTxt = "Move Unused PIcons to a Directory"
   delTxt = "DELETE Unused PIcons"
   if self.filterTitle == "PIcons without Channels":
    c = VVnKNv
    VVegP0.append((c + movTxt           , "VVo66H"  ))
    VVegP0.append((c + delTxt           , "VVqeSU" ))
   else:
    disTxt = " (Filter >> Unused PIcons)"
    VVegP0.append((movTxt + disTxt         ,       ))
    VVegP0.append((delTxt + disTxt         ,       ))
   VVegP0.append(VVHMBI)
   VVegP0.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVJsBz"  ))
   VVegP0.append(VVHMBI)
   VVegP0 += CC96Ar.VVBM0S()
   VVegP0.append(VVHMBI)
   VVegP0.append(("Change Poster/Picon Transparency Color"    , "VV6xDt" ))
   VVegP0.append(("Keys Help"           , "VVqPqb"    ))
   FFJcY1(self, self.VVfx3d, width=1100, height=1050, title=self.Title, VVegP0=VVegP0)
 def VVfx3d(self, item=None):
  if item is not None:
   if   item == "VV8cfz"     : self.VV8cfz()
   elif item == "VVQ4WC"    : self.VVQ4WC()
   elif item == "VVuuMe_file"   : self.VVuuMe(0)
   elif item == "VVuuMe_link"   : self.VVuuMe(1)
   elif item == "VV8qg3"   : self.VV8qg3()
   elif item == "VVXWEs"   : CC96Ar.VVXWEs(self)
   elif item == "VVo66H"    : self.VVo66H()
   elif item == "VVqeSU"   : self.VVqeSU()
   elif item == "VVJsBz"   : self.VVJsBz()
   elif item == "VV23Du"   : CC96Ar.VV23Du(self)
   elif item == "findPiconBrokenSymLinks"  : CC96Ar.VVIphI(self, True)
   elif item == "FindAllBrokenSymLinks"  : CC96Ar.VVIphI(self, False)
   elif item == "VV6xDt"  : self.VV6xDt()
   elif item == "VVqPqb"      : FFHU3T(self, "_help_picons", "PIcons Tools (Keys Help)")
 def VVGQlx(self):
  if not self.isBusy:
   VVegP0 = []
   VVegP0.append(("Go to First PIcon"  , "VVng3z"  ))
   VVegP0.append(("Go to Last PIcon"   , "VVhSal"  ))
   VVegP0.append(VVHMBI)
   VVegP0.append(("Sort by Channel Name"     , "sortByChan" ))
   VVegP0.append(("Sort by File Name"  , "sortByFile" ))
   VVegP0.append(VVHMBI)
   VVegP0.append(("Find from File List .." , "VVHVqA" ))
   FFJcY1(self, self.VVP6V6, title=self.Title, VVegP0=VVegP0)
 def VVP6V6(self, item=None):
  if item is not None:
   if   item == "VVng3z"   : self.VVng3z()
   elif item == "VVhSal"   : self.VVhSal()
   elif item == "sortByChan"  : self.VVRbEF(2)
   elif item == "sortByFile"  : self.VVRbEF(0)
   elif item == "VVHVqA"  : self.VVHVqA()
 def VVHVqA(self):
  VVegP0 = []
  for item in self.VVVC4T:
   VVegP0.append((item[0], item[0]))
  FFJcY1(self, self.VVM78t, title='PIcons ".png" Files', VVegP0=VVegP0, VV4p4D=True)
 def VVM78t(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVUsey(ndx)
 def VVzZVQ(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVNg4h()
   if refCode:
    FFGrAa(self, refCode)
    self.VVQaM0()
    self.VVL8IZ()
 def VVIjq5(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVQaM0()
   self.VVL8IZ()
  except:
   pass
 def VVEvYu(self):
  if self["keyGreen"].getVisible():
   self.VVUsey(self.curChanIndex)
 def VVRbEF(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFG53m(self, BF(self.VVmQDs, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVuuMe(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVNg4h()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVegP0 = []
     VVegP0.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVegP0.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFJcY1(self, BF(self.VVIEGS, mode, curChF, selPiconF), VVegP0=VVegP0, title="Current Channel PIcon (already exists)")
    else:
     self.VVIEGS(mode, curChF, selPiconF, "overwrite")
   else:
    FFnHzu(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFnHzu(self, "Could not read current channel info. !", title=title)
 def VVIEGS(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFG53m(self, BF(self.VVmQDs, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVo66H(self):
  defDir = FFxJSp(CC96Ar.VVwdi5() + "picons_backup")
  os.system(FFNxGN("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(BF(self.VV6fMC, defDir), BF(CCr5c7
         , mode=CCr5c7.VVT9mm, VV3Cmf=CC96Ar.VVwdi5()))
 def VV6fMC(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CC96Ar.VVwdi5():
    FFnHzu(self, "Cannot move to same directory !", title=title)
   else:
    if not FFxJSp(path) == FFxJSp(defDir):
     self.VVbIY3(defDir)
    FFWBJu(self, BF(FFG53m, self, BF(self.VVCjNR, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVVC4T), path), title=title)
  else:
   self.VVbIY3(defDir)
 def VVCjNR(self, title, defDir, toPath):
  if not iMove:
   self.VVbIY3(defDir)
   FFnHzu(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FFxJSp(toPath)
  pPath = CC96Ar.VVwdi5()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVVC4T:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVVC4T)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFJRXg(self, txt, title=title, VVvi08="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVPWu8("all")
 def VVbIY3(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVqeSU(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVVC4T)
  FFWBJu(self, BF(FFG53m, self, BF(self.VVJTDa, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FFJHIK(tot)), title=title)
 def VVJTDa(self, title):
  pPath = CC96Ar.VVwdi5()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVVC4T:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVVC4T)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FF6TiS(str(totErr), VVsIVN)
  FFJRXg(self, txt, title=title)
 def VVJsBz(self):
  lines = FF5Sgm("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FFWBJu(self, BF(self.VVkqBU, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FFJHIK(tot)), VVARnJ=True)
  else:
   FFcZi2(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVkqBU(self, fList):
  os.system(FFNxGN("find -L '%s' -type l -delete" % self.pPath))
  FFcZi2(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVDAdV(self):
  FFG53m(self, self.VVOlXH)
 def VVOlXH(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVNg4h()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FF6TiS("PIcon Directory:\n", VVOEUI)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FF61aD(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FF61aD(path)
   txt += FF6TiS("PIcon File:\n", VVOEUI)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FF6TiS("Found %d SymLink%s to this file from:\n" % (tot, FFJHIK(tot)), VVOEUI)
     for fPath in slLst:
      txt += "  %s\n" % FF6TiS(fPath, VVsvZg)
     txt += "\n"
   if chName:
    txt += FF6TiS("Channel:\n", VVOEUI)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FF6TiS(chName, VVUdsq)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FF6TiS("Remarks:\n", VVOEUI)
    txt += "  %s\n" % FF6TiS("Unused", VVsIVN)
  else:
   txt = "No info found"
  FFiqcT(self, fncMode=CC6biu.VV20Jv, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVNg4h(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalItems:
   fName, fType, chName, sat, inDB = self.VVVC4T[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFWJ2v(sat)
  return fName, refCode, chName, sat, inDB
 def VVQaM0(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVVC4T):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVL8IZ(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVNg4h()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalItems)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FF6TiS("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVOEUI))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVNg4h()[1]))
  if self.curChanIptvRef : typ = "Stream Relay" if FFabwQ(self.curChanIptvRef) else "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FF6TiS(self.curChanName, VVBfw8)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
  filName, refCode, chName, sat, inDB = self.VVNg4h()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VV8cfz(self):
  VVCpBm, VVnYkd = FF1mjb()
  sTypeNameDict = {}
  for key, val in VVnYkd.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVVC4T:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VVnYkd: sTypeDict[VVnYkd[stNum]] = sTypeDict.get(VVnYkd[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFN7zW("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVzto2 = []
  c = "#b#11003333#"
  VVzto2.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalItems, totUsedFiles + totUsedLinks)))
  VVzto2.append((c + "Files" , "%d\tUsed = %s" % (self.totalItems - totSymLinks, totUsedFiles)))
  VVzto2.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVzto2.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVzto2.append((c + "Not In Database (lamedb)" , str(self.totalItems - totInDB)))
  VVzto2.append((c + "Satellites"    , str(len(self.nsList))))
  VVzto2.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVzto2.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVzto2.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVzto2.extend(sTypeRows)
  FFqiz1(self, None, title=self.Title, VVVC4T=VVzto2, VVwwGj=28, VVTrrJ="#00003333", VVcd71="#00222222")
 def VV8qg3(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FFxJSp(CFG.exportedTablesPath.getValue()), txt, FFxsfY())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVVC4T:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FFcZi2(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVZP7R(self):
  if not self.isBusy:
   VVegP0 = []
   VVegP0.append(("All"         , "all"   ))
   VVegP0.append(VVHMBI)
   VVegP0.append(("Used by Channels"      , "used"  ))
   VVegP0.append(("Unused PIcons"      , "unused"  ))
   VVegP0.append(("IPTV PIcons"       , "iptv"  ))
   VVegP0.append(VVHMBI)
   VVegP0.append(("PIcons Files"       , "pFiles"  ))
   VVegP0.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVegP0.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVegP0.append(("By Files Date ..."     , "pDate"  ))
   VVegP0.append(("By Service Type ..."     , "servType" ))
   if self.nsList:
    VVegP0.append(FFQJnR("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FF99jt(val)
      VVegP0.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCSAYR(self)
   filterObj.VV6OVY(VVegP0, self.nsList, self.VVF4TI)
 def VVF4TI(self, item=None):
  if item is not None:
   self.VVPWu8(item)
 def VVPWu8(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVwsmq   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVXLwt   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVyKHm  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVolpx   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVqbC1  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVA9BP  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVxIAC  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VV1Mh6 , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVKXp4 , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVaKWL   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVhrhO , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVxIAC:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FF5Sgm("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFjyTm(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFtMfC(self, "Not found", 1000)
     return
   elif mode == self.VV1Mh6:
    self.VVQbsa(mode)
    return
   elif mode == self.VVKXp4:
    self.VV3tpZ(mode)
    return
   elif mode == self.VVfBsv:
    return
   else:
    words, asPrefix = CCSAYR.VVaVMf(words)
   if not words and mode in (self.VVaKWL, self.VVhrhO):
    FFtMfC(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFG53m(self, BF(self.VVmQDs, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVQbsa(self, mode):
  VVegP0 = []
  VVegP0.append(("Today"   , "today" ))
  VVegP0.append(("Since Yesterday" , "yest" ))
  VVegP0.append(("Since 7 days"  , "week" ))
  FFJcY1(self, BF(self.VVlalC, mode), VVegP0=VVegP0, title="Filter by Added/Modified Date")
 def VVlalC(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFRAMp(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFRAMp(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFRAMp(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FFG53m(self, BF(self.VVmQDs, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VV3tpZ(self, mode):
  VVCpBm, VVnYkd = FF1mjb()
  lst = set()
  for key, val in VVnYkd.items():
   lst.add(val)
  VVegP0 = []
  for item in lst:
   VVegP0.append((item, item))
  VVegP0.sort(key=lambda x: x[0])
  FFJcY1(self, BF(self.VVKoh9, mode), VVegP0=VVegP0, title="Filter by Service Type")
 def VVKoh9(self, mode, item=None):
  if item:
   VVCpBm, VVnYkd = FF1mjb()
   sTypeList = []
   for key, val in VVnYkd.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FFG53m(self, BF(self.VVmQDs, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVQ4WC(self):
  self.session.open(CCDe3n, barTheme=CCDe3n.VVzwEk
      , titlePrefix = ""
      , fncToRun  = self.VViiCT
      , VVuJdT = self.VVlvmc)
 def VViiCT(self, VVEkKt):
  VVlShi, err = CCcecd.VV4wpk(self, CCcecd.VVEkB2, VVITXJ=False, VV6Oa0=False)
  files = []
  words = []
  if not VVEkKt or VVEkKt.isCancelled:
   return
  VVEkKt.VVyzJx = []
  VVEkKt.VVQWYw(len(VVlShi))
  if VVlShi:
   VV9Xp9 = CCDbht()
   curCh = VV9Xp9.VVpSN0(self.curChanName)
   for refCode in VVlShi:
    if not VVEkKt or VVEkKt.isCancelled:
     return
    VVEkKt.VVHjIy(1, True)
    chName, sat, inDB = VVlShi.get(refCode, ("", "", 0))
    ratio = CC96Ar.VVD5cG(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CC96Ar.VVPDkv(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFjyTm(f)
       fil = f.replace(".png", "")
       if not fil in VVEkKt.VVyzJx:
        VVEkKt.VVyzJx.append(fil)
 def VVlvmc(self, VVLnvr, VVyzJx, threadCounter, threadTotal, threadErr):
  if VVyzJx : FFG53m(self, BF(self.VVmQDs, mode=self.VVfBsv, words=VVyzJx), title="Loading ...")
  else   : FFtMfC(self, "Not found", 2000)
 def VVmQDs(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VVzV55(isFirstTime):
   return
  self.isBusy = True
  VV6Oa0 = True if isFirstTime else False
  VVlShi, err = CCcecd.VV4wpk(self, CCcecd.VVEkB2, VVITXJ=False, VV6Oa0=VV6Oa0)
  if err:
   self.close()
  iptvRefList = self.VVpL90()
  tList = []
  for fName, fType in CC96Ar.VVNp49(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVlShi:
    if fName in VVlShi:
     chName, sat, inDB = VVlShi.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVwsmq:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVXLwt  and chName         : isAdd = True
   elif mode == self.VVyKHm and not chName        : isAdd = True
   elif mode == self.VVqbC1  and fType == 0        : isAdd = True
   elif mode == self.VVA9BP  and fType == 1        : isAdd = True
   elif mode == self.VVxIAC  and fName in words       : isAdd = True
   elif mode == self.VVfBsv and fName in words       : isAdd = True
   elif mode == self.VVolpx  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVaKWL  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVhrhO:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VV1Mh6:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVKXp4:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVVC4T   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FFtMfC(self)
  else:
   self.isBusy = False
   FFtMfC(self, "Not found", 1000)
   return
  self.VVVC4T.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVQaM0()
  self.totalItems = len(self.VVVC4T)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self.isBusy = False
  self.VVcpxm(True)
 def VVzV55(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CC96Ar.VVNp49(self.pPath):
    if fName:
     return True
   if isFirstTime : FFnHzu(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFtMfC(self, "Not found", 1000)
  else:
   FFnHzu(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVpL90(self):
  VVzto2 = {}
  files  = CCCu2Z.VVfoZV()
  if files:
   for path in files:
    txt = FFu1EI(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVzto2[refCode] = item[1]
  return VVzto2
 def VVPwpG(self):
  self.VVpafX()
  f1, f2 = self.VVDaEC()
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVVC4T[ndx]
   fName = self.VVVC4T[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FF6TiS(chName, VVUdsq))
    else : lbl.setText("-")
   except:
    lbl.setText(FF6TiS(chName, VVlagI))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVD5cG(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVsACl():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVXWEs"   )
 @staticmethod
 def VVBM0S():
  VVegP0 = []
  VVegP0.append(("Find SymLinks (to PIcon Directory)"   , "VV23Du"   ))
  VVegP0.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVegP0.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVegP0
 @staticmethod
 def VVXWEs(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(SELF)
  png, path = CC96Ar.VVtefF(refCode)
  if path : CC96Ar.VVSdwi(SELF, png, path)
  else : FFnHzu(SELF, "No PIcon found for current channel in:\n\n%s" % CC96Ar.VVwdi5())
 @staticmethod
 def VV23Du(SELF):
  if VVBfw8:
   sed1 = FFmjg3("->", VVBfw8)
   sed2 = FFmjg3("picon", VVsIVN)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVlagI, VVZ51O)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFlo7E(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFdsA4(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVIphI(SELF, isPIcon):
  sed1 = FFmjg3("->", VVlagI)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFmjg3("picon", VVsIVN)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFlo7E(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFdsA4(), grep, sed1, sed2))
 @staticmethod
 def VVNp49(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVwdi5():
  path = CFG.PIconsPath.getValue()
  return FFxJSp(path)
 @staticmethod
 def VVtefF(refCode, chName=None):
  if FF2IUY(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFiRgM(refCode)
  allPath, fName, refCodeFile, pList = CC96Ar.VVPDkv(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVSdwi(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFmjg3("%s%s" % (dest, png), VVUdsq))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFmjg3(errTxt, VVSGHr))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFSCk3(SELF, cmd)
 @staticmethod
 def VVPDkv(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CC96Ar.VVwdi5()
   pList = []
   lst = FFT5mp(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FF2AUs(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFjyTm(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCDh36():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVSvm2  = None
  self.VVSpKh = ""
  self.VVEU1a  = noService
  self.VVNLBX = 0
  self.VVoMUn  = noService
  self.VVpYwm = 0
  self.VVLiYt  = "-"
  self.VVfNPo = 0
  self.VV1xPr  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVY3Qi(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVSvm2 = frontEndStatus
     self.VVAHux()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVAHux(self):
  if self.VVSvm2:
   val = self.VVSvm2.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVSpKh = "%3.02f dB" % (val / 100.0)
   else         : self.VVSpKh = ""
   val = self.VVSvm2.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVNLBX = int(val)
   self.VVEU1a  = "%d%%" % val
   val = self.VVSvm2.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVpYwm = int(val)
   self.VVoMUn  = "%d%%" % val
   val = self.VVSvm2.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVLiYt  = "%d" % val
   val = int(val * 100 / 500)
   self.VVfNPo = min(500, val)
   val = self.VVSvm2.get("tuner_locked", 0)
   if val == 1 : self.VV1xPr = "Locked"
   else  : self.VV1xPr = "Not locked"
 def VVaVn9(self)   : return self.VVSpKh
 def VV9gUt(self)   : return self.VVEU1a
 def VVG4eC(self)  : return self.VVNLBX
 def VVVjRq(self)   : return self.VVoMUn
 def VVeRME(self)  : return self.VVpYwm
 def VVaNmV(self)   : return self.VVLiYt
 def VV6VY9(self)  : return self.VVfNPo
 def VV7ZW7(self)   : return self.VV1xPr
 def VVsK0q(self) : return self.serviceName
class CCxkcu():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVz00L(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFSeor(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVcnbC(self.ORPOS  , mod=1   )
      self.sat2  = self.VVcnbC(self.ORPOS  , mod=2   )
      self.freq  = self.VVcnbC(self.FREQ  , mod=3   )
      self.sr   = self.VVcnbC(self.SR   , mod=4   )
      self.inv  = self.VVcnbC(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVcnbC(self.POL  , self.D_POL )
      self.fec  = self.VVcnbC(self.FEC  , self.D_FEC )
      self.syst  = self.VVcnbC(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVcnbC("modulation" , self.D_MOD )
       self.rolof = self.VVcnbC("rolloff"  , self.D_ROLOF )
       self.pil = self.VVcnbC("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVcnbC("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVcnbC("pls_code"  )
       self.iStId = self.VVcnbC("is_id"   )
       self.t2PlId = self.VVcnbC("t2mi_plp_id" )
       self.t2PId = self.VVcnbC("t2mi_pid"  )
 def VVcnbC(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FF99jt(val)
  elif mod == 2   : return FF9TiB(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VVcvQt(self, refCode):
  txt = ""
  self.VVz00L(refCode)
  if self.data:
   def VVcOV6(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVcOV6("System"   , self.syst)
    txt += VVcOV6("Satellite"  , self.sat2)
    txt += VVcOV6("Frequency"  , self.freq)
    txt += VVcOV6("Inversion"  , self.inv)
    txt += VVcOV6("Symbol Rate"  , self.sr)
    txt += VVcOV6("Polarization" , self.pol)
    txt += VVcOV6("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVcOV6("Modulation" , self.mod)
     txt += VVcOV6("Roll-Off" , self.rolof)
     txt += VVcOV6("Pilot"  , self.pil)
     txt += VVcOV6("Input Stream", self.iStId)
     txt += VVcOV6("T2MI PLP ID" , self.t2PlId)
     txt += VVcOV6("T2MI PID" , self.t2PId)
     txt += VVcOV6("PLS Mode" , self.plsMod)
     txt += VVcOV6("PLS Code" , self.plsCod)
   else:
    txt += VVcOV6("System"   , self.txMedia)
    txt += VVcOV6("Frequency"  , self.freq)
  return txt, self.namespace
 def VVMlvc(self, refCode):
  txt = "Transpoder : ?"
  self.VVz00L(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVyO6x(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFSeor(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVcnbC(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVcnbC(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVcnbC(self.SYST, self.D_SYS_S)
     freq = self.VVcnbC(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVcnbC(self.POL , self.D_POL)
      fec = self.VVcnbC(self.FEC , self.D_FEC)
      sr = self.VVcnbC(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVKvS6(self, refCode):
  self.data = None
  self.VVz00L(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCzWmm():
 def __init__(self, VV0dXq, path, VVuJdT=None, curRowNum=-1):
  self.VV0dXq  = VV0dXq
  self.origFile   = path
  self.Title    = "File Editor: " + FFjyTm(path)
  self.VVuJdT  = VVuJdT
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  response = os.system(FFNxGN("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVU4gI(curRowNum)
  else:
   FFnHzu(self.VV0dXq, "Error while preparing edit!")
 def VVU4gI(self, curRowNum):
  VVzto2 = self.VVXAlm()
  VVdn6T = ("Save Changes" , self.VVWIQj   , [])
  VV91FP  = ("Edit Line"  , self.VVAxqG    , [])
  VVljWo = ("Go to Line Num" , self.VVDxoy   , [])
  VVDB15 = ("Line Options" , self.VVdIr3   , [])
  VVqfcE = (""    , self.VVNS4r , [])
  VVs5Sk = self.VV8det
  VV1BNd  = self.VVviRz
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVsZoP  = (CENTER  , LEFT  )
  VVR0r4 = FFqiz1(self.VV0dXq, None, title=self.Title, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VVdn6T=VVdn6T, VV91FP=VV91FP, VVljWo=VVljWo, VVDB15=VVDB15, VVs5Sk=VVs5Sk, VV1BNd=VV1BNd, VVqfcE=VVqfcE, VVSwEr=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
    , VVXbiY   = "#11001111"
    , VVVy8H   = "#11001111"
    , VVvi08   = "#11001111"
    , VVTrrJ  = "#05333333"
    , VVcd71  = "#00222222"
    , VVVygK  = "#11331133"
    )
  VVR0r4.VVwqjr(curRowNum)
 def VVDxoy(self, VVR0r4, title, txt, colList):
  totRows = VVR0r4.VVsBGq()
  lineNum = VVR0r4.VVVZYd() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FFYvs0(self.VV0dXq, BF(self.VVO9UW, VVR0r4, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VVO9UW(self, VVR0r4, lineNum, totRows, VVbYOE):
  if VVbYOE:
   VVbYOE = VVbYOE.strip()
   if VVbYOE.isdigit():
    num = FF3qV5(int(VVbYOE) - 1, 0, totRows)
    VVR0r4.VVwqjr(num)
    self.lastLineNum = num + 1
   else:
    FFtMfC(VVR0r4, "Incorrect number", 1500)
 def VVdIr3(self, VVR0r4, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVR0r4.VV6qIs()
  VVegP0 = []
  VVegP0.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVegP0.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVGiBY"  ))
  VVegP0.append(VVHMBI)
  VVegP0.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVClf2:
   VVegP0.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVegP0.append(VVHMBI)
  VVegP0.append(  ("Delete Line"         , "deleteLine"   ))
  FFJcY1(self.VV0dXq, BF(self.VVJGnm, VVR0r4, lineNum), VVegP0=VVegP0, title="Line Options")
 def VVJGnm(self, VVR0r4, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VV6Hcz("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVR0r4)
   elif item == "VVGiBY"  : self.VVGiBY(VVR0r4, lineNum)
   elif item == "copyToClipboard"  : self.VVKRQS(VVR0r4, lineNum)
   elif item == "pasteFromClipboard" : self.VVk2Xy(VVR0r4, lineNum)
   elif item == "deleteLine"   : self.VV6Hcz("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVR0r4)
 def VVviRz(self, VVR0r4):
  VVR0r4.VVFthC()
 def VVNS4r(self, VVR0r4, title, txt, colList):
  if   self.insertMode == 1: VVR0r4.VV2xJG()
  elif self.insertMode == 2: VVR0r4.VVuIdh()
  self.insertMode = 0
 def VVGiBY(self, VVR0r4, lineNum):
  if lineNum == VVR0r4.VV6qIs():
   self.insertMode = 1
   self.VV6Hcz("echo '' >> '%s'" % self.tmpFile, VVR0r4)
  else:
   self.insertMode = 2
   self.VV6Hcz("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVR0r4)
 def VVKRQS(self, VVR0r4, lineNum):
  global VVClf2
  VVClf2 = FFN7zW("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVR0r4.VVsu20("Copied to clipboard")
 def VVWIQj(self, VVR0r4, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFNxGN("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFNxGN("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVR0r4.VVsu20("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVR0r4.VVFthC()
    else:
     FFnHzu(self.VV0dXq, "Cannot save file!")
   else:
    FFnHzu(self.VV0dXq, "Cannot create backup copy of original file!")
 def VV8det(self, VVR0r4):
  if self.fileChanged:
   FFWBJu(self.VV0dXq, BF(self.VVlhf3, VVR0r4), "Cancel changes ?")
  else:
   finalOK = os.system(FFNxGN("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVlhf3(VVR0r4)
 def VVlhf3(self, VVR0r4):
  VVR0r4.cancel()
  FFO0bd(self.tmpFile)
  if self.VVuJdT:
   self.VVuJdT(self.fileSaved)
 def VVAxqG(self, VVR0r4, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVZ51O + "ORIGINAL TEXT:\n" + VVsvZg + lineTxt
  FFYvs0(self.VV0dXq, BF(self.VVzrOC, lineNum, VVR0r4), title="File Line", defaultText=lineTxt, message=message)
 def VVzrOC(self, lineNum, VVR0r4, VVbYOE):
  if not VVbYOE is None:
   if VVR0r4.VV6qIs() <= 1:
    self.VV6Hcz("echo %s > '%s'" % (VVbYOE, self.tmpFile), VVR0r4)
   else:
    self.VVZfSH(VVR0r4, lineNum, VVbYOE)
 def VVk2Xy(self, VVR0r4, lineNum):
  if lineNum == VVR0r4.VV6qIs() and VVR0r4.VV6qIs() == 1:
   self.VV6Hcz("echo %s >> '%s'" % (VVClf2, self.tmpFile), VVR0r4)
  else:
   self.VVZfSH(VVR0r4, lineNum, VVClf2)
 def VVZfSH(self, VVR0r4, lineNum, newTxt):
  VVR0r4.VV7IKK("Saving ...")
  lines = FF5DO4(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVR0r4.VVbUHV()
  VVzto2 = self.VVXAlm()
  VVR0r4.VVwzoo(VVzto2)
 def VV6Hcz(self, cmd, VVR0r4):
  tCons = CCXMpW()
  tCons.ePopen(cmd, BF(self.VVSjtQ, VVR0r4))
  self.fileChanged = True
  VVR0r4.VVbUHV()
 def VVSjtQ(self, VVR0r4, result, retval):
  VVzto2 = self.VVXAlm()
  VVR0r4.VVwzoo(VVzto2)
 def VVXAlm(self):
  if fileExists(self.tmpFile):
   lines = FF5DO4(self.tmpFile)
   VVzto2 = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVzto2.append((str(ndx), line.strip()))
   if not VVzto2:
    VVzto2.append((str(1), ""))
   return VVzto2
  else:
   FFlkXm(self.VV0dXq, self.tmpFile)
class CCSAYR():
 def __init__(self, callingSELF, VVXbiY="#22003344", VVVy8H="#22002233"):
  self.callingSELF = callingSELF
  self.VVegP0  = []
  self.satList  = []
  self.VVXbiY  = VVXbiY
  self.VVVy8H   = VVVy8H
 def VVnKMp(self, VVuJdT):
  self.VVegP0 = []
  VVegP0, VVcbKg = CCSAYR.VVy9Xb(self.callingSELF, False, True)
  if VVegP0:
   self.VVegP0 += VVegP0
   self.VV5Gl8(VVuJdT, VVcbKg)
 def VV4Lnf(self, mode, VVR0r4, satCol, VVuJdT, inFilterFnc=None):
  VVR0r4.VV7IKK("Loading Filters ...")
  self.VVegP0 = []
  self.VVegP0.append(("All Services" , "all"))
  if mode == 1:
   self.VVegP0.append(VVHMBI)
   self.VVegP0.append(("Parental Control", "parentalControl"))
   self.VVegP0.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVegP0.append(VVHMBI)
   self.VVegP0.append(("Selected Transponder"   , "selectedTP" ))
   self.VVegP0.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVV4tw(VVR0r4, satCol)
  VVegP0, VVcbKg = CCSAYR.VVy9Xb(self.callingSELF, True, False)
  if VVegP0:
   VVegP0.insert(0, FFQJnR("Custom Words"))
   self.VVegP0 += VVegP0
  VVR0r4.VVRZ9B()
  self.VV5Gl8(VVuJdT, VVcbKg, inFilterFnc)
 def VV6OVY(self, VVegP0, sats, VVuJdT, inFilterFnc=None):
  self.VVegP0 = VVegP0
  VVegP0, VVcbKg = CCSAYR.VVy9Xb(self.callingSELF, True, False)
  if VVegP0:
   self.VVegP0.append(FFQJnR("Custom Words"))
   self.VVegP0 += VVegP0
  self.VV5Gl8(VVuJdT, VVcbKg, inFilterFnc)
 def VV5Gl8(self, VVuJdT, VVcbKg, inFilterFnc=None):
  VVzqGT  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVV5x7 = ("Edit Filter"  , BF(self.VVvOCn, VVcbKg))
  VVZKXi  = ("Filter Help"  , BF(self.VVDXlp, VVcbKg))
  FFJcY1(self.callingSELF, BF(self.VVIrHQ, VVuJdT), VVegP0=self.VVegP0, title="Select Filter", VVzqGT=VVzqGT, VVV5x7=VVV5x7, VVZKXi=VVZKXi, VVk6EI=True, VVXbiY=self.VVXbiY, VVVy8H=self.VVVy8H)
 def VVIrHQ(self, VVuJdT, item):
  if item:
   VVuJdT(item)
 def VVvOCn(self, VVcbKg, VVsxjbObj, sel):
  if fileExists(VVcbKg) : CCzWmm(self.callingSELF, VVcbKg, VVuJdT=None)
  else       : FFlkXm(self.callingSELF, VVcbKg)
  VVsxjbObj.cancel()
 def VVDXlp(self, VVcbKg, VVsxjbObj, sel):
  FFHU3T(self.callingSELF, "_help_service_filter", "Service Filter")
 def VVV4tw(self, VVR0r4, satColNum):
  if not self.satList:
   satList = VVR0r4.VV4ZZO(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFWJ2v(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FFQJnR("Satellites"))
  if self.VVegP0:
   self.VVegP0 += self.satList
 @staticmethod
 def VVy9Xb(SELF, addTag, VVozbc):
  FFaCeZ()
  fileName  = "ajpanel_services_filter"
  VVcbKg = VVAVra + fileName
  VVegP0  = []
  if not fileExists(VVcbKg):
   os.system(FFNxGN("cp -f '%s' '%s'" % (VVeop3 + fileName, VVcbKg)))
  fileFound = False
  if fileExists(VVcbKg):
   fileFound = True
   lines = FF5DO4(VVcbKg)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVegP0.append((line, "__w__" + line))
       else  : VVegP0.append((line, line))
  if VVozbc:
   if   not fileFound : FFlkXm(SELF, VVcbKg)
   elif not VVegP0 : FFiIsE(SELF, VVcbKg)
  return VVegP0, VVcbKg
 @staticmethod
 def VVaVMf(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CCeaGv():
 def __init__(self, callingSELF, VVR0r4, addSep=True):
  self.callingSELF = callingSELF
  self.VVR0r4 = VVR0r4
  self.VVegP0 = []
  iMulSel = self.VVR0r4.VVIeoE()
  if iMulSel : self.VVegP0.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVegP0.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVR0r4.VVkGfp()
  self.VVegP0.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVegP0.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVegP0.append(VVHMBI)
 def VVxIpf(self, extraMenu, cbFncDict, width=1000, okFnc=None):
  if extraMenu:
   self.VVegP0.extend(extraMenu)
  FFJcY1(self.callingSELF, BF(self.VV8M5h, cbFncDict, okFnc), width=width, title="Options", VVegP0=self.VVegP0)
 def VV8M5h(self, cbFncDict, okFnc, item=None):
  if item:
   if   item == "multSelEnab" : self.VVR0r4.VVHKEm(True)
   elif item == "MultSelDisab" : self.VVR0r4.VVHKEm(False)
   elif item == "selectAll" : self.VVR0r4.VVMAwS()
   elif item == "unselectAll" : self.VVR0r4.VVBnDy()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
   if okFnc:
    okFnc()
class CCP4yf(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAJVu(VVQZV2, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFsw8F(self)
  FF154z(self["keyRed"]  , "Exit")
  FF154z(self["keyGreen"]  , "Save")
  FF154z(self["keyYellow"] , "Refresh")
  FF154z(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVPVx9  ,
   "green" : self.VVjuZ9 ,
   "yellow": self.VVTgKK  ,
   "blue" : self.VVEwXJ   ,
   "up" : self.VV7Q5E    ,
   "down" : self.VVNA9M   ,
   "left" : self.VVITAJ   ,
   "right" : self.VVHgAf   ,
   "cancel": self.VVPVx9
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VVoCo0)
  self.onClose.append(self.onExit)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  self.VVTgKK()
  self.VVPP8U()
  FFnLuC(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVc5rT)
  except:
   self.timer.callback.append(self.VVc5rT)
  self.timer.start(1000, False)
  self.VVc5rT()
 def onExit(self):
  self.timer.stop()
 def VVPVx9(self) : self.close(True)
 def VV8Uts(self) : self.close(False)
 def VVEwXJ(self):
  self.session.openWithCallback(self.VVxxyO, BF(CCKGYR))
 def VVxxyO(self, closeAll):
  if closeAll:
   self.close()
 def VVc5rT(self):
  self["curTime"].setText(str(FFrOxn(iTime())))
 def VV7Q5E(self):
  self.VVJ0na(1)
 def VVNA9M(self):
  self.VVJ0na(-1)
 def VVITAJ(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVPP8U()
 def VVHgAf(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVPP8U()
 def VVJ0na(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVWfJy(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVWfJy(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVWfJy(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VV0vQv(year)):
   days += 1
  return days
 def VV0vQv(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVPP8U(self):
  for obj in self.list:
   FFo6oa(obj, "#11404040")
  FFo6oa(self.list[self.index], "#11ff8000")
 def VVTgKK(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVjuZ9(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCXMpW()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVkXKI)
 def VVkXKI(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFcZi2(self, "Nothing returned from the system!")
  else:
   FFcZi2(self, str(result))
class CCKGYR(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAJVu(VV95UA, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFsw8F(self, addLabel=True)
  FF154z(self["keyRed"]  , "Exit")
  FF154z(self["keyGreen"]  , "Sync")
  FF154z(self["keyYellow"] , "Refresh")
  FF154z(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVPVx9   ,
   "green" : self.VVDzZo  ,
   "yellow": self.VV0sz6 ,
   "blue" : self.VVenif  ,
   "cancel": self.VVPVx9
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVHKtt()
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  FFnLuC(self)
  FFDxKA(self.VVNNJG)
 def VVNNJG(self):
  self.VVrvSb()
  self.VVOURg(False)
 def VVPVx9(self)  : self.close(True)
 def VVenif(self) : self.close(False)
 def VVHKtt(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVrvSb(self):
  self.VVVcFE()
  self.VV7tI4()
  self.VVmz2j()
  self.VVXKJu()
 def VV0sz6(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVHKtt()
   self.VVrvSb()
   FFDxKA(self.VVNNJG)
 def VVDzZo(self):
  if len(self["keyGreen"].getText()) > 0:
   FFWBJu(self, self.VVaTtq, "Synchronize with Internet Date/Time ?")
 def VVaTtq(self):
  self.VVrvSb()
  FFDxKA(BF(self.VVOURg, True))
 def VVVcFE(self)  : self["keyRed"].show()
 def VVUApw(self)  : self["keyGreen"].show()
 def VVDsPe(self) : self["keyYellow"].show()
 def VVAE36(self)  : self["keyBlue"].show()
 def VV7tI4(self)  : self["keyGreen"].hide()
 def VVmz2j(self) : self["keyYellow"].hide()
 def VVXKJu(self)  : self["keyBlue"].hide()
 def VVOURg(self, sync):
  localTime = FF9ucJ()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVc6rn(server)
   if epoch_time is not None:
    ntpTime = FFrOxn(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCXMpW()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VVkXKI, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVDsPe()
  self.VVAE36()
  if ok:
   self.VVUApw()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVkXKI(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVOURg(False)
  except:
   pass
 def VVc6rn(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFpySX():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCqwei(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFAJVu(VVDWFj, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FFsw8F(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FFDxKA(self.VVox1X)
 def VVox1X(self):
  if FFpySX(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFo6oa(self["myBody"], color)
   FFo6oa(self["myLabel"], color)
  except:
   pass
class CChWWt(Screen):
 VVaEJ0 = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFF92P()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFAJVu(VVVnfS, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CC9PY9(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CC9PY9(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CC9PY9(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCDh36()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFsw8F(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close      ,
   "up"  : self.VV7Q5E       ,
   "down"  : self.VVNA9M      ,
   "left"  : self.VVITAJ      ,
   "right"  : self.VVHgAf      ,
   "info"  : self.VVKzWH     ,
   "epg"  : self.VVKzWH     ,
   "menu"  : self.VVqPqb      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVuSMf, -1)  ,
   "next"  : BF(self.VVuSMf, 1)  ,
   "pageUp" : BF(self.VVDc0K, True) ,
   "chanUp" : BF(self.VVDc0K, True) ,
   "pageDown" : BF(self.VVDc0K, False) ,
   "chanDown" : BF(self.VVDc0K, False) ,
   "0"   : BF(self.VVuSMf, 0)  ,
   "1"   : BF(self.VVvL5u, pos=1) ,
   "2"   : BF(self.VVvL5u, pos=2) ,
   "3"   : BF(self.VVvL5u, pos=3) ,
   "4"   : BF(self.VVvL5u, pos=4) ,
   "5"   : BF(self.VVvL5u, pos=5) ,
   "6"   : BF(self.VVvL5u, pos=6) ,
   "7"   : BF(self.VVvL5u, pos=7) ,
   "8"   : BF(self.VVvL5u, pos=8) ,
   "9"   : BF(self.VVvL5u, pos=9) ,
  }, -1)
  self.onShown.append(self.VVoCo0)
  self.onClose.append(self.onExit)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  if not CChWWt.VVaEJ0:
   CChWWt.VVaEJ0 = self
  self.sliderSNR.VVTLGV()
  self.sliderAGC.VVTLGV()
  self.sliderBER.VVTLGV(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVvL5u()
  self.VVaP9C()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVzAuj)
  except:
   self.timer.callback.append(self.VVzAuj)
  self.timer.start(500, False)
 def VVaP9C(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVY3Qi(service)
  serviceName = self.tunerInfo.VVsK0q()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self)
  tp = CCxkcu()
  tpTxt, satTxt = tp.VVMlvc(refCode)
  if tpTxt == "?" :
   tpTxt = FF6TiS("NO SIGNAL", VVnKNv)
  self["myTPInfo"].setText(tpTxt + "  " + FF6TiS(satTxt, VVpkep))
 def VVzAuj(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVY3Qi(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVaVn9())
   self["mySNR"].setText(self.tunerInfo.VV9gUt())
   self["myAGC"].setText(self.tunerInfo.VVVjRq())
   self["myBER"].setText(self.tunerInfo.VVaNmV())
   self.sliderSNR.VVZYfW(self.tunerInfo.VVG4eC())
   self.sliderAGC.VVZYfW(self.tunerInfo.VVeRME())
   self.sliderBER.VVZYfW(self.tunerInfo.VV6VY9())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVZYfW(0)
   self.sliderAGC.VVZYfW(0)
   self.sliderBER.VVZYfW(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self)
    if state and not state == "Tuned":
     FFtMfC(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVKzWH(self):
  FFiqcT(self, fncMode=CC6biu.VVngWh)
 def VVqPqb(self):
  FFHU3T(self, "_help_signal", "Signal Monitor (Keys)")
 def VV7Q5E(self)  : self.VVvL5u(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVNA9M(self) : self.VVvL5u(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVITAJ(self) : self.VVvL5u(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVHgAf(self) : self.VVvL5u(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVvL5u(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FFCfiF(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVuSMf(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FF3qV5(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FFCfiF(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CChWWt.VVaEJ0 = None
 def VVDc0K(self, isUp):
  FFtMfC(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVaP9C()
  except:
   pass
class CC9PY9(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVTLGV(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFo6oa(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVeop3 +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFo6oa(self.covObj, self.covColor)
   else:
    FFo6oa(self.covObj, "#00006688")
    self.isColormode = True
  self.VVZYfW(0)
 def VVZYfW(self, val):
  val  = FF3qV5(val, self.minN, self.maxN)
  width = int(FFXM7k(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FF3qV5(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCDe3n(Screen):
 VVzwEk    = 0
 VVEpKA = 1
 VV9Wn8 = 2
 def __init__(self, session, titlePrefix="Processing ...", endTitle="Finishing ...", fncToRun=None, VVuJdT=None, barTheme=VVzwEk, titleBg="#0a042328", bodyBg="#0a042328"):
  ratio = self.VVYXn0(barTheme)
  self.skin, self.skinParam = FFAJVu(VVCOjl, 900, 200, 30, 40, 30, titleBg, bodyBg, 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.endTitle  = endTitle
  self.fncToRun  = fncToRun
  self.VVuJdT = VVuJdT
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVyzJx = None
  self.timer   = eTimer()
  self.myThread  = None
  FFsw8F(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], { "cancel" : self.cancel }, -1)
  self.onShown.append(self.VVoCo0)
  self.onClose.append(self.onExit)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  self.VVDtxo()
  self["myProgBarVal"].setText("0%")
  FFo6oa(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVtOCo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVtOCo)
  except:
   self.timer.callback.append(self.VVtOCo)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVQWYw(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VV4wDL(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVyzJx), self.counter, self.maxValue, catName)
 def VVoXWq(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVc4KL(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VVERp8(self, tot, evName):
  self.newTitle = "Translated: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, evName)
 def VVyH4l(self, action, tot, name):
  self.newTitle = "%s: %d   ... %d/%d >> %s" % (action, tot, self.counter, self.maxValue, name)
 def VVbPGC(self, tot, name):
  self.newTitle = "Added: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, name)
 def VVKrKU(self, txt):
  self.newTitle = txt
 def VVHjIy(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVyzJx), self.counter, self.maxValue)
  except:
   pass
 def VV9j20(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVM4Se(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VV2RjU(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFtMfC(self, "Cancelling ...")
  self.isCancelled = True
  self.VV4ocC(False)
 def VV4ocC(self, isDone):
  FFDxKA(BF(self.VVlwda, isDone))
 def VVlwda(self, isDone):
  if self.VVuJdT:
   self.VVuJdT(isDone, self.VVyzJx, self.counter, self.maxValue, self.isError)
  self.close()
 def VVtOCo(self):
  val = FF3qV5(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFXM7k(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self["myTitle"].setText("  %s  " % self.endTitle)
    self.VV4ocC(True)
 def VVDtxo(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVEpKA, self.VV9Wn8):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVYXn0(self, barTheme):
  if   barTheme == self.VVEpKA : return 0.7
  if   barTheme == self.VV9Wn8 : return 0.5
  else             : return 1
class CCXMpW(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVuJdT = {}
  self.commandRunning = False
  self.VVMRua  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVuJdT, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVuJdT[name] = VVuJdT
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVMRua:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVNDrf, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVg1sR , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVNDrf, name))
    self.appContainers[name].appClosed.append(BF(self.VVg1sR , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVg1sR(name, retval)
  return True
 def VVNDrf(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FF6TiS("[UN-DECODED STRING]", VVnKNv))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVg1sR(self, name, retval):
  if not self.VVMRua:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVuJdT[name]:
   self.VVuJdT[name](self.appResults[name], retval)
  del self.VVuJdT[name]
 def VV3X7Y(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCHOmo(Screen):
 def __init__(self, session, title="", VVb1hE=None, VVdXTj=False, VVfE3s=False, VVOAUy=False, VVSiFo=False, VVEtLW=False, VV7FEJ=False, VVwZYa=VVXWIl, VVhgup=None, VVoWXZ=False, VVIUog=None, VV9R3L="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFAJVu(VVinJE, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFsw8F(self, addScrollLabel=True)
  if not VV9R3L:
   VV9R3L = "Processing ..."
  self["myLabel"].setText("   %s" % VV9R3L)
  self.VVdXTj   = VVdXTj
  self.VVfE3s   = VVfE3s
  self.VVOAUy   = VVOAUy
  self.VVSiFo  = VVSiFo
  self.VVEtLW = VVEtLW
  self.VV7FEJ = VV7FEJ
  self.VVwZYa   = VVwZYa
  self.VVhgup = VVhgup
  self.VVoWXZ  = VVoWXZ
  self.VVIUog  = VVIUog
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCXMpW()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFyqg5()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVb1hE, str):
   self.VVb1hE = [VVb1hE]
  else:
   self.VVb1hE = VVb1hE
  if self.VVOAUy or self.VVSiFo:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVtc24, VVtc24)
   self.VVb1hE.append("echo -e '\n%s\n' %s" % (restartNote, FFmjg3(restartNote, VVBfw8)))
   if self.VVOAUy:
    self.VVb1hE.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVb1hE.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVEtLW:
   FFtMfC(self, "Processing ...")
  self.onLayoutFinish.append(self.VVsEAO)
  self.onClose.append(self.VVPj6Z)
 def VVsEAO(self):
  self["myLabel"].VV8dj1(outputFileToSave="console" if self.enableSaveRes else "")
  if self.VVdXTj:
   self["myLabel"].VVzVRx()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VV0Ltk()
  else:
   self.VVom57()
 def VV0Ltk(self):
  if FFpySX():
   self["myLabel"].setText("Processing ...")
   self.VVom57()
  else:
   self["myLabel"].setText(FF6TiS("\n   No connection to internet!", VVsIVN))
 def VVom57(self):
  allOK = self.container.ePopen(self.VVb1hE[0], self.VVmPQO, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVmPQO("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VV7FEJ or self.VVOAUy or self.VVSiFo:
    self["myLabel"].setText(FFqjvC("STARTED", VVBfw8) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVIUog:
   colorWhite = CCbPmL.VV4viU(VVZ51O)
   color  = CCbPmL.VV4viU(self.VVIUog[0])
   words  = self.VVIUog[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVwZYa=self.VVwZYa)
 def VVmPQO(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVb1hE):
   allOK = self.container.ePopen(self.VVb1hE[self.cmdNum], self.VVmPQO, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVmPQO("Cannot connect to Console!", -1)
  else:
   if self.VVEtLW and FFfrnp(self):
    FFtMfC(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VV7FEJ:
    self["myLabel"].appendText("\n" + FFqjvC("FINISHED", VVBfw8), self.VVwZYa)
   if self.VVdXTj or self.VVfE3s:
    self["myLabel"].VVzVRx()
   if self.VVhgup is not None:
    self.VVhgup()
   if not retval and self.VVoWXZ:
    self.VVPj6Z()
 def VVPj6Z(self):
  if self.container.VV3X7Y():
   self.container.killAll()
class CCEQiY(Screen):
 def __init__(self, session, VVb1hE=None, VVEtLW=False):
  self.skin, self.skinParam = FFAJVu(VVinJE, 1650, 950, 40, 20, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVAVra + "ajpanel_terminal.history"
  self.customCommandsFile = VVAVra + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFN7zW("pwd") or "/home/root"
  self.container   = CCXMpW()
  self.commandsList  = []
  self.exitBtnText  = "Exit = Interrupt"
  FFsw8F(self, title="Terminal", addScrollLabel=True)
  FF154z(self["keyRed"] , self.exitBtnText)
  FF154z(self["keyGreen"] , "OK = History")
  FF154z(self["keyYellow"], "Menu = Custom Cmds")
  FF154z(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok" : self.VVtDHz ,
   "cancel": self.VVQCD2  ,
   "menu" : self.VVVR2y ,
   "last" : self.VVLeVn  ,
   "next" : self.VVLeVn  ,
   "1"  : self.VVLeVn  ,
   "2"  : self.VVLeVn  ,
   "3"  : self.VVLeVn  ,
   "4"  : self.VVLeVn  ,
   "5"  : self.VVLeVn  ,
   "6"  : self.VVLeVn  ,
   "7"  : self.VVLeVn  ,
   "8"  : self.VVLeVn  ,
   "9"  : self.VVLeVn  ,
   "0"  : self.VVLeVn
  })
  self.onLayoutFinish.append(self.VVoCo0)
  self.onClose.append(self.VVcXsI)
 def VVoCo0(self):
  self["myLabel"].VV8dj1(isResizable=False, outputFileToSave="terminal")
  FFD09G(self["keyRed"]  , "#00ff8000")
  FFo6oa(self["keyRed"]  , self.skinParam["titleColor"])
  FFo6oa(self["keyGreen"]  , self.skinParam["titleColor"])
  FFo6oa(self["keyYellow"] , self.skinParam["titleColor"])
  FFo6oa(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVBBF4(FFN7zW("date"), 5)
  result = FFN7zW("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVx9eo()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVeop3 + "LinuxCommands.lst"
   newTemplate = VVeop3 + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFNxGN("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFNxGN("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVcXsI(self):
  if self.container.VV3X7Y():
   self.container.killAll()
   self.VVBBF4("Process killed\n", 4)
   self.VVx9eo()
 def VVQCD2(self):
  if self.container.VV3X7Y():
   self.VVcXsI()
  else:
   FFWBJu(self, self.close, "Exit ?", VV6Lpq=False)
 def VVx9eo(self):
  self.VVBBF4(self.prompt, 1)
  self["keyRed"].hide()
 def VVBBF4(self, txt, mode):
  if   mode == 1 : color = VVBfw8
  elif mode == 2 : color = VVOEUI
  elif mode == 3 : color = VVZ51O
  elif mode == 4 : color = VVsIVN
  elif mode == 5 : color = VVsvZg
  elif mode == 6 : color = VVPYB5
  else   : color = VVZ51O
  try:
   self["myLabel"].appendText(FF6TiS(txt, color))
  except:
   pass
 def VVtDHz(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVi2tr() == "":
   self.VVkpTx("cd /tmp")
   self.VVkpTx("ls")
  VVzto2 = []
  if fileExists(self.commandHistoryFile):
   lines  = FF5DO4(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVzto2.append((str(c), line, str(lNum)))
   self.VVibPo(VVzto2, title, self.commandHistoryFile, isHistory=True)
  else:
   FFlkXm(self, self.commandHistoryFile, title=title)
 def VVi2tr(self):
  lastLine = FFN7zW("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVkpTx(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVVR2y(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FF5DO4(self.customCommandsFile)
   lastLineIsSep = False
   VVzto2 = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVzto2.append((str(c), line, str(lNum)))
   self.VVibPo(VVzto2, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFlkXm(self, self.customCommandsFile, title=title)
 def VVibPo(self, VVzto2, title, filePath=None, isHistory=False):
  if VVzto2:
   VVTrrJ = "#05333333"
   if isHistory: VVXbiY = VVVy8H = VVvi08 = "#11000020"
   else  : VVXbiY = VVVy8H = VVvi08 = "#06002020"
   VV91FP   = ("Send"   , BF(self.VVpTIU, isHistory)  , [])
   VVdn6T  = ("Modify & Send" , self.VVjnHK     , [])
   if isHistory:
    VVljWo = ("Clear History" , self.VVQJet     , [])
    VVDB15 = None
   elif filePath:
    VVljWo = ("Options"  , self.VVEJ8A      , [])
    VVDB15 = ("Edit File"  , BF(self.VVPzts, filePath) , [])
   header  = ("No." , "Commands", "LineNum" )
   widths  = (7  , 93   , 0    )
   VVsZoP = (CENTER , LEFT   , CENTER )
   VVR0r4 = FFqiz1(self, None, title=title, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VV91FP=VV91FP, VVdn6T=VVdn6T, VVljWo=VVljWo, VVDB15=VVDB15, lastFindConfigObj=CFG.lastFindTerminal, VVSwEr=True, searchCol=1
         , VVXbiY=VVXbiY, VVVy8H=VVVy8H, VVvi08=VVvi08, VVbSmQ="#05ffff00", VVTrrJ=VVTrrJ)
   if not isHistory:
    VVR0r4.VVwqjr(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FFiIsE(self, filePath, title=title)
 def VVEJ8A(self, VVR0r4, title, txt, colList):
  mSel = CCeaGv(self, VVR0r4)
  if VVR0r4.VV9Jt5:
   totSel = VVR0r4.VVkGfp()
   totTxt = str(totSel)
   txt = "Send %s Command%s" % (FF6TiS(totTxt, VVBfw8) if totSel else totTxt, FFJHIK(totSel))
   VVegP0 = [(txt, "send")] if totSel else [(txt,)]
  else:
   VVegP0 = [("Send current line", "send")]
  cbFncDict = {"send": BF(self.VVpTIU, False, VVR0r4, title, txt, colList)}
  mSel.VVxIpf(VVegP0, cbFncDict, okFnc=BF(self.VVugNC, VVR0r4))
 def VVugNC(self, VVR0r4):
  if VVR0r4.VV9Jt5 : VVR0r4.VVFthC()
  else        : VVR0r4.VVbUHV()
 def VVpTIU(self, isHistory, VVR0r4, title, txt, colList):
  if VVR0r4.VV9Jt5:
   lst = VVR0r4.VVYpZO(1)
   curNdx = VVR0r4.VVKweo()
  else:
   lst = [colList[1]]
   curNdx = VVR0r4.VVVZYd()
  if not isHistory:
   FFCfiF(CFG.lastTerminalCustCmdLineNum, curNdx)
  self.commandsList = lst
  VVR0r4.cancel()
  FFDxKA(self.VV9cz7)
 def VV9cz7(self):
  if self.commandsList:
   cmd = self.commandsList[0]
   self.commandsList.pop(0)
   if not iMatch("^[a-zA-Z0-9_]", cmd):
    self.VVBBF4("\n%s\n" % cmd, 6)
    self.VVBBF4(self.prompt, 1)
    self.VV9cz7()
   else:
    self.VVsfKN(cmd)
 def VVsfKN(self, cmd):
  tot = len(self.commandsList)
  self["keyRed"].setText("%s%s" % (self.exitBtnText, " (%s)" % tot if tot > 0 else ""))
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVBBF4(cmd, 2)
   self.VVBBF4("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVBBF4(ch, 0)
   self.VVBBF4("\nor\n", 4)
   self.VVBBF4("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVx9eo()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FF6TiS(parts[0].strip(), VVOEUI)
    right = FF6TiS("#" + parts[1].strip(), VVPYB5)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVBBF4(txt, 2)
   lastLine = self.VVi2tr()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVkpTx(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVmPQO, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFnHzu(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVBBF4(data, 3)
 def VVmPQO(self, data, retval):
  if not retval == 0:
   self.VVBBF4("Exit Code : %d\n" % retval, 4)
  self.VVx9eo()
  if self.commandsList:
   self.VV9cz7()
 def VVjnHK(self, VVR0r4, title, txt, colList):
  if VVR0r4.VVeSEs():
   cmd = colList[1]
   self.VVRi74(VVR0r4, cmd)
 def VVQJet(self, VVR0r4, title, txt, colList):
  FFWBJu(self, BF(self.VV3rWu, VVR0r4), "Reset History File ?", title="Command History")
 def VV3rWu(self, VVR0r4):
  os.system(FFNxGN("echo '' > %s" % self.commandHistoryFile))
  VVR0r4.cancel()
 def VVPzts(self, filePath, VVR0r4, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCzWmm(self, filePath, VVuJdT=BF(self.VVw1bg, VVR0r4), curRowNum=rowNum)
  else     : FFlkXm(self, filePath)
 def VVw1bg(self, VVR0r4, fileChanged):
  if fileChanged:
   VVR0r4.cancel()
   FFDxKA(self.VVVR2y)
 def VVLeVn(self):
  self.VVRi74(None, self.lastCommand)
 def VVRi74(self, VVR0r4, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFYvs0(self, BF(self.VVAe7q, VVR0r4), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVAe7q(self, VVR0r4, cmd):
  if cmd and len(cmd) > 0:
   self.VVsfKN(cmd)
   if VVR0r4:
    VVR0r4.cancel()
class CCuB4X(Screen):
 def __init__(self, session, title="", message="", VVwZYa=VVXWIl, width=1400, height=800, VVhATy=False, VVvi08=None, VVwwGj=30, titleFontSize=50, outputFileToSave=""):
  self.skin, self.skinParam = FFAJVu(VVinJE, width, height, titleFontSize, 30, 20, "#22002020", "#22001122", VVwwGj)
  self.session   = session
  FFsw8F(self, title, addScrollLabel=True)
  self.VVwZYa   = VVwZYa
  self.VVhATy   = VVhATy
  self.VVvi08   = VVvi08
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  self["myLabel"].VV8dj1(VVhATy=self.VVhATy, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVwZYa)
  if self.VVvi08:
   FFo6oa(self["myBody"], self.VVvi08)
   FFo6oa(self["myLabel"], self.VVvi08)
   FFTnVH(self["myLabel"], self.VVvi08)
  self["myLabel"].VVzVRx()
class CCqH3G(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFAJVu(VV168T, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFsw8F(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FFeKhX(self["errPic"], "err")
class CCyHS0(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFAJVu(VVP9BS, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FFsw8F(self, " ", addCloser=True)
class CCBMOM():
 def __init__(self, session, txt, timeout=1500):
  self.win = session.instantiateDialog(CCyHS0, txt, 24)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  FFmknE(self.win["myWinTitle"], "#440000", 2)
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVoosd)
  except:
   self.timer.callback.append(self.VVoosd)
  self.timer.start(timeout, True)
 def VVoosd(self):
  self.session.deleteDialog(self.win)
class CCBXuV():
 VVYRJh    = 0
 VVurHd  = 1
 VVnxol   = ""
 VVIFnD    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVR0r4   = None
  self.timer     = eTimer()
  self.VVD3jh   = 0
  self.VVtyap  = 1
  self.VV8Vbn  = 2
  self.VVoBVI   = 3
  self.VV65Wx   = 4
  VVzto2 = self.VVKbpR()
  if VVzto2:
   self.VVR0r4 = self.VVSbVp(VVzto2)
  if not VVzto2 and mode == self.VVYRJh:
   self.VVbCAY("Download list is empty !")
   self.cancel()
  if mode == self.VVurHd:
   FFG53m(self.VVR0r4 or self.SELF, BF(self.VVaXCU, startDnld, decodedUrl), title="Checking Server ...")
  self.VVK0uP(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVK0uP)
  except:
   self.timer.callback.append(self.VVK0uP)
  self.timer.start(1000, False)
 def VVSbVp(self, VVzto2):
  VVzto2.sort(key=lambda x: int(x[0]))
  VVs5Sk = self.VVl7N2
  VV91FP  = ("Play"  , self.VVL397 , [])
  VVBSYf = (""   , self.VV74N5  , [])
  VVIqI1 = ("Stop"  , self.VVe440  , [])
  VVdn6T = ("Resume"  , self.VVUGBi , [])
  VVljWo = ("Options" , self.VVoKAy  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVsZoP  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFqiz1(self.SELF, None, title=self.Title, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VV91FP=VV91FP, VVBSYf=VVBSYf, VVs5Sk=VVs5Sk, VVIqI1=VVIqI1, VVdn6T=VVdn6T, VVljWo=VVljWo, lastFindConfigObj=CFG.lastFindIptv, VVXbiY="#11220022", VVVy8H="#11110011", VVvi08="#11110011", VVbSmQ="#00ffff00", VVTrrJ="#00223025", VVcd71="#0a333333", VVVygK="#0a400040", VVSwEr=True, searchCol=1)
 def VVKbpR(self):
  lines = CCBXuV.VVcLex()
  VVzto2 = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVEr0o(decodedUrl)
      if fName:
       if   FF2xh4(decodedUrl) : sType = "Movie"
       elif FFA3h4(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVNzlR(decodedUrl, fName)
       if size > -1: sizeTxt = CCr5c7.VVJv7c(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVzto2.append((str(len(VVzto2) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVzto2
 def VVPEKE(self):
  VVzto2 = self.VVKbpR()
  if VVzto2:
   if self.VVR0r4 : self.VVR0r4.VVwzoo(VVzto2, VVHKttMsg=False)
   else     : self.VVR0r4 = self.VVSbVp(VVzto2)
  else:
   self.cancel()
 def VVK0uP(self, force=False):
  if self.VVR0r4:
   thrListUrls = self.VV0VBw()
   VVzto2 = []
   changed = False
   for ndx, row in enumerate(self.VVR0r4.VVtxRM()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVD3jh
    if m3u8Log:
     percent = CCBXuV.VVG9SO(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVoBVI , "%.2f %%" % percent
      else   : flag, progr = self.VV65Wx , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFREV4(mPath)
     if curSize > -1:
      fSize = CCr5c7.VVJv7c(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCr5c7.VVJv7c(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFREV4(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVoBVI , "%.2f %%" % percent
       else   : flag, progr = self.VV65Wx , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCr5c7.VVJv7c(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VV8Vbn
     if m3u8Log :
      if not speed and not force : flag = self.VVtyap
      elif curSize == -1   : self.VVU97z(False)
    elif flag == self.VVD3jh  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVD3jh  : color2 = "#f#00555555#"
    elif flag == self.VVtyap : color2 = "#f#0000FFFF#"
    elif flag == self.VV8Vbn : color2 = "#f#0000FFFF#"
    elif flag == self.VVoBVI  : color2 = "#f#00FF8000#"
    elif flag == self.VV65Wx  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVDiVw(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVzto2.append(row)
   if changed or force:
    self.VVR0r4.VVwzoo(VVzto2, VVHKttMsg=False)
 def VVDiVw(self, flag):
  tDict = self.VVsCie()
  return tDict.get(flag, "?")
 def VVidRK(self, state):
  for flag, txt in self.VVsCie().items():
   if txt == state:
    return flag
  return -1
 def VVsCie(self):
  return { self.VVD3jh: "Not started", self.VVtyap: "Connecting", self.VV8Vbn: "Downloading", self.VVoBVI: "Stopped", self.VV65Wx: "Completed" }
 def VVmrDr(self, title):
  colList = self.VVR0r4.VVVPDl()
  path = colList[6]
  url  = colList[8]
  if self.VVUimn() : self.VVbCAY("Cannot delete !\n\nFile is downloading.")
  else      : FFWBJu(self.SELF, BF(self.VV2yr5, path, url), "Delete ?\n\n%s" % path, title=title)
 def VV2yr5(self, path, url):
  m3u8Log = self.VVR0r4.VVVPDl()[12]
  if m3u8Log : os.system(FFNxGN("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFNxGN("rm -r '%s'" % path))
  self.VVD3OT(False)
  self.VVPEKE()
 def VVD3OT(self, VVozbc=True):
  if self.VVUimn():
   FFtMfC(self.VVR0r4, self.VVDiVw(self.VV8Vbn), 500)
  else:
   colList  = self.VVR0r4.VVVPDl()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VVidRK(state) in (self.VVD3jh, self.VV65Wx, self.VVoBVI):
    lines = CCBXuV.VVcLex()
    newLines = []
    found = False
    for line in lines:
     if CCBXuV.VV5FfX(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VV5ZLE(newLines)
     self.VVPEKE()
     FFtMfC(self.VVR0r4, "Removed.", 1000)
    else:
     FFtMfC(self.VVR0r4, "Not found.", 1000)
   elif VVozbc:
    self.VVbCAY("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VViRmT(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFWBJu(self.SELF, BF(self.VVrM7t, flag), ques, title=title)
 def VVrM7t(self, flag):
  list = []
  for ndx, row in enumerate(self.VVR0r4.VVtxRM()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVidRK(state)
   if   flag == flagVal == self.VV65Wx: list.append(decodedUrl)
   elif flag == flagVal == self.VVD3jh : list.append(decodedUrl)
  lines = CCBXuV.VVcLex()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VV5ZLE(newLines)
   self.VVPEKE()
   FFtMfC(self.VVR0r4, "%d removed." % totRem, 1000)
  else:
   FFtMfC(self.VVR0r4, "Not found.", 1000)
 def VVNpBB(self):
  colList  = self.VVR0r4.VVVPDl()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFtMfC(self.VVR0r4, "Poster exists", 1500)
  else    : FFG53m(self.VVR0r4, BF(self.VV9eix, decodedUrl, path, png), title="Checking Server ...")
 def VV9eix(self, decodedUrl, path, png):
  err = self.VVnvRB(decodedUrl, path, png)
  if err:
   FFnHzu(self.SELF, err, title="Poster Download")
 def VVnvRB(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCwh19.VVNGLS(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCCu2Z.VVERnQ(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCCu2Z.VVex4B(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCCu2Z.VVU8hy(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFHXM5(pUrl, "ajpanel_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   os.system(FFNxGN("mv -f '%s' '%s'" % (tPath, png)))
   CCDdSC.VVvctb(self.SELF, VVQyig=png, showGrnMsg="Downloaded")
   return ""
 def VV74N5(self, VVR0r4, title, txt, colList):
  def VVCvCu(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVcOV6(key, val) : return "\n%s:\n%s\n" % (FF6TiS(key, VVpkep), val.strip())
  heads  = self.VVR0r4.VVZqSH()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVCvCu(heads[i]  , CCr5c7.VVJv7c(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVCvCu("Downloaded" , CCr5c7.VVJv7c(int(curSize), mode=0))
   else:
    txt += VVCvCu(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVcOV6(heads[i], colList[i])
  FFJRXg(self.SELF, txt, title=title)
 def VVL397(self, VVR0r4, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCr5c7.VVU4yQ(self.SELF, path)
  else    : FFtMfC(self.VVR0r4, "File not found", 1000)
 def VVl7N2(self, VVR0r4):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVR0r4:
   self.VVR0r4.cancel()
  del self
 def VVoKAy(self, VVR0r4, title, txt, colList):
  c1, c2, c3 = VVPN93, VVsIVN, VVpkep
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVegP0 = []
  VVegP0.append((c1 + "Remove current row"       , "VVD3OT" ))
  VVegP0.append(VVHMBI)
  VVegP0.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVegP0.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVegP0.append(VVHMBI)
  VVegP0.append((c2 + "Delete the file (and remove from list)"  , "VVmrDr"))
  VVegP0.append(VVHMBI)
  VVegP0.append((resumeTxt + " Auto Resume"       , "VVRpkE" ))
  VVegP0.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVegP0.append(VVHMBI)
  t = "Download Movie Poster "
  if FF2xh4(decodedUrl): VVegP0.append((c3 + "%s(from server)" % t , "VVNpBB"  ))
  else      : VVegP0.append(("%s... Movies only" % t ,      ))
  if fileExists(path) : VVegP0.append((c3 + "Open in File Manager" , "inFileMan,%s" % path ))
  else    : VVegP0.append(("Open in File Manager"  ,      ))
  FFJcY1(self.SELF, BF(self.VV4jXS, VVR0r4), VVegP0=VVegP0, title=self.Title, VV4p4D=True, width=800, VVk6EI=True, VVXbiY="#1a001122", VVVy8H="#1a001122")
 def VV4jXS(self, VVR0r4, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVD3OT"  : self.VVD3OT()
   elif ref == "remFinished"   : self.VViRmT(self.VV65Wx, txt)
   elif ref == "remPending"   : self.VViRmT(self.VVD3jh, txt)
   elif ref == "VVmrDr" : self.VVmrDr(txt)
   elif ref == "VVNpBB"  : self.VVNpBB()
   elif ref == "VVRpkE"  : FFCfiF(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FFCfiF(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CCr5c7, mode=CCr5c7.VVyS6s, jumpToFile=path)
    else    : FFtMfC(VVR0r4, "Path not found !", 1500)
 def VVaXCU(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCwh19.VVNGLS(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVbCAY("Could not get download link !\n\nTry again later.")
     return
  for line in CCBXuV.VVcLex():
   if CCBXuV.VV5FfX(decodedUrl, line):
    if self.VVR0r4:
     self.VVDAVu(decodedUrl)
     FFDxKA(BF(FFtMfC, self.VVR0r4, "Already listed !", 2000))
    break
  else:
   params = self.VVeemn(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVbCAY(params[0])
   elif len(params) == 2:
    FFWBJu(self.SELF, BF(self.VV2hwC, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCr5c7.VVJv7c(fSize)
    FFWBJu(self.SELF, BF(self.VVlzjG, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVlzjG(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCBXuV.VVXg5U(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVPEKE()
  if self.VVR0r4:
   self.VVR0r4.VVuIdh()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCBXuV.VVIFnD, path, decodedUrl)
   self.VVFQjy(threadName, url, decodedUrl, path, resp)
 def VVDAVu(self, decodedUrl):
  if self.VVR0r4:
   for ndx, row in enumerate(self.VVR0r4.VVtxRM()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVR0r4:
     self.VVR0r4.VVwqjr(ndx)
     break
 def VVeemn(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVEr0o(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVNzlR(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCwh19.VVNGLS(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCwh19.VVqqlL()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCBXuV.VVFKg3(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCBXuV.VVDWXq(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VV2hwC(self, resp, decodedUrl):
  if not os.system(FFNxGN("which ffmpeg")) == 0:
   FFWBJu(self.SELF, BF(CCCu2Z.VVFJ8M, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVEr0o(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVfJ9w(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFWBJu(self.SELF, BF(self.VVwFTa, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVwFTa(rTxt, rUrl)
  else:
   self.VVbCAY("Cannot process m3u8 file !")
 def VVfJ9w(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVegP0 = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCCu2Z.VVnoeh(rUrl, fPath)
   VVegP0.append((resol, fullUrl))
  if VVegP0:
   FFJcY1(self.SELF, self.VVzM3b, VVegP0=VVegP0, title="Resolution", VV4p4D=True, VVk6EI=True)
  else:
   self.VVbCAY("Cannot get Resolutions list from server !")
 def VVzM3b(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFWBJu(self.SELF, BF(FFDxKA, BF(self.VVkvN3, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFDxKA(BF(self.VVkvN3, resolUrl))
 def VVkvN3(self, resolUrl):
  txt, err = CCwh19.VVviU3(resolUrl)
  if err : self.VVbCAY(err)
  else : self.VVwFTa(txt, resolUrl)
 def VVGx66(self, logF, decodedUrl):
  found = False
  lines = CCBXuV.VVcLex()
  with open(CCBXuV.VVXg5U(), "w") as f:
   for line in lines:
    if CCBXuV.VV5FfX(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCBXuV.VVXg5U(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVPEKE()
  if self.VVR0r4:
   self.VVR0r4.VVuIdh()
 def VVwFTa(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCCu2Z.VVnoeh(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVbCAY("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVGx66(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFNxGN("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCBXuV.VVIFnD, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVG9SO(dnldLog):
  if fileExists(dnldLog):
   dur = CCBXuV.VVWbCf(dnldLog)
   if dur > -1:
    tim = CCBXuV.VVnPgb(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVWbCf(dnldLog):
  lines = FF5Sgm("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVnPgb(dnldLog):
  lines = FF5Sgm("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVNzlR(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFA3h4(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFNxGN("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVFQjy(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVR0r4.VVVPDl()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VVl4mn, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVl4mn(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVnxol == path:
       break
     else:
      break
  except:
   return
  if CCBXuV.VVnxol:
   CCBXuV.VVnxol = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFREV4(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVeemn(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVl4mn(url, decodedUrl, path, resp, totFileSize, True)
 def VVe440(self, VVR0r4, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVbkQJ() : FFtMfC(self.VVR0r4, self.VVDiVw(self.VV65Wx), 500)
  elif not self.VVUimn() : FFtMfC(self.VVR0r4, self.VVDiVw(self.VVoBVI), 500)
  elif m3u8Log      : FFWBJu(self.SELF, self.VVU97z, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VV0VBw():
    CCBXuV.VVnxol = colList[6]
    FFtMfC(self.VVR0r4, "Stopping ...", 1000)
   else:
    FFtMfC(self.VVR0r4, "Stopped", 500)
 def VVU97z(self, withMsg=True):
  if withMsg:
   FFtMfC(self.VVR0r4, "Stopping ...", 1000)
  os.system(FFNxGN("killall -INT ffmpeg"))
 def VVUGBi(self, *args):
  if   self.VVbkQJ() : FFtMfC(self.VVR0r4, self.VVDiVw(self.VV65Wx) , 500)
  elif self.VVUimn() : FFtMfC(self.VVR0r4, self.VVDiVw(self.VV8Vbn), 500)
  else:
   resume = False
   m3u8Log = self.VVR0r4.VVVPDl()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFWBJu(self.SELF, BF(self.VVhwEf, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVjzIE():
    resume = True
   if resume: FFG53m(self.VVR0r4, BF(self.VVOpDP), title="Checking Server ...")
   else  : FFtMfC(self.VVR0r4, "Cannot resume !", 500)
 def VVhwEf(self, m3u8Log):
  os.system(FFNxGN("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFG53m(self.VVR0r4, BF(self.VVOpDP), title="Checking Server ...")
 def VVOpDP(self):
  colList  = self.VVR0r4.VVVPDl()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCwh19.VVNGLS(decodedUrl)
   if url:
    decodedUrl = self.VVPJnK(decodedUrl, url)
   else:
    self.VVbCAY("Could not get download link !\n\nTry again later.")
    return
  curSize = FFREV4(path)
  params = self.VVeemn(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVbCAY(params[0])
   return
  elif len(params) == 2:
   self.VV2hwC(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVPJnK(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCBXuV.VVIFnD, path, decodedUrl)
  if resumable: self.VVFQjy(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVbCAY("Cannot resume from server !")
 def VVEr0o(self, decodedUrl):
  fileExt = CCCu2Z.VVgZiB(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FFa4u4(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVbCAY(self, txt):
  FFnHzu(self.SELF, txt, title=self.Title)
 def VV0VBw(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCBXuV.VVIFnD, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVUimn(self):
  decodedUrl = self.VVR0r4.VVVPDl()[9]
  return decodedUrl in self.VV0VBw()
 def VVbkQJ(self):
  colList = self.VVR0r4.VVVPDl()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFREV4(path)) == size
 def VVjzIE(self):
  colList = self.VVR0r4.VVVPDl()
  path = colList[6]
  size = int(colList[7])
  curSize = FFREV4(path)
  if curSize > -1:
   size -= curSize
  err = CCBXuV.VVDWXq(size)
  if err:
   FFnHzu(self.SELF, err, title=self.Title)
   return False
  return True
 def VV5ZLE(self, list):
  with open(CCBXuV.VVXg5U(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVPJnK(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCBXuV.VVcLex()
  url = decodedUrl
  with open(CCBXuV.VVXg5U(), "w") as f:
   for line in lines:
    if CCBXuV.VV5FfX(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVPEKE()
  return url
 @staticmethod
 def VVcLex():
  list = []
  if fileExists(CCBXuV.VVXg5U()):
   for line in FF5DO4(CCBXuV.VVXg5U()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VV5FfX(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVDWXq(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCr5c7.VVPnvT(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCr5c7.VVJv7c(size), CCr5c7.VVJv7c(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVXWpM(SELF):
  tot = CCBXuV.VVm4rW()
  if tot:
   FFnHzu(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVm4rW():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCBXuV.VVIFnD):
    c += 1
  return c
 @staticmethod
 def VVRszV():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCBXuV.VVIFnD, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVGcd9():
  return len(CCBXuV.VVcLex()) == 0
 @staticmethod
 def VVSxGL():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVy7F4():
  mPoints = CCBXuV.VVSxGL()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFNxGN("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVXg5U():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVmWLp(SELF):
  CCBXuV.VVlMxU(SELF, CCBXuV.VVYRJh)
 @staticmethod
 def VVhgw4(SELF):
  CCBXuV.VVlMxU(SELF, CCBXuV.VVurHd, startDnld=True)
 @staticmethod
 def VVL8YB(SELF, url):
  CCBXuV.VVlMxU(SELF, CCBXuV.VVurHd, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVWcAB(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(SELF)
  added, skipped = CCBXuV.VVWTb4([decodedUrl])
  FFtMfC(SELF, "Added", 1000)
 @staticmethod
 def VVWTb4(list):
  added = skipped = 0
  for line in CCBXuV.VVcLex():
   for ndx, url in enumerate(list):
    if url and CCBXuV.VV5FfX(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCBXuV.VVXg5U(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVlMxU(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CC6kXN.VVv4ri(SELF):
   return
  if mode == CCBXuV.VVYRJh and CCBXuV.VVGcd9():
   FFnHzu(SELF, "Download list is empty !", title=title)
  else:
   inst = CCBXuV(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVFKg3(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCM2Fd(Screen, CCM7WN):
 VVUYe0 = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, isFromExternal=False, enableDownloadMenu=True, enableOpenInFMan=True):
  self.skin, self.skinParam = FFAJVu(VVfjZk, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCM7WN.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.enableOpenInFMan  = enableOpenInFMan
  self.iptvTableParams  = iptvTableParams
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FFsw8F(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVuMJ4())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVu0DR       ,
   "info"  : self.VVKzWH      ,
   "epg"  : self.VVKzWH      ,
   "menu"  : self.VV7zzI     ,
   "cancel" : self.cancel       ,
   "red"  : self.VVENjM   ,
   "green"  : self.VVmdbr  ,
   "blue"  : self.VVm2pH      ,
   "yellow" : self.VV4muK ,
   "left"  : BF(self.VV2hzU, -1)    ,
   "right"  : BF(self.VV2hzU,  1)    ,
   "play"  : self.VVZXCP      ,
   "pause"  : self.VVZXCP      ,
   "playPause" : self.VVZXCP      ,
   "stop"  : self.VVZXCP      ,
   "rewind" : self.VVwD8f      ,
   "forward" : self.VVY4gH      ,
   "rewindDm" : self.VVwD8f      ,
   "forwardDm" : self.VVY4gH      ,
   "last"  : self.VV2Btz      ,
   "next"  : self.VVElmE      ,
   "pageUp" : BF(self.VVsWLY, True)  ,
   "pageDown" : BF(self.VVsWLY, False)  ,
   "chanUp" : BF(self.VVsWLY, True)  ,
   "chanDown" : BF(self.VVsWLY, False)  ,
   "up"  : BF(self.VVsWLY, True)  ,
   "down"  : BF(self.VVsWLY, False)  ,
   "audio"  : BF(self.VVcVzE, True)  ,
   "subtitle" : BF(self.VVcVzE, False)  ,
   "text"  : self.VV04ch  ,
   "0"   : BF(self.VVea7I , 10)   ,
   "1"   : BF(self.VVea7I , 1)   ,
   "2"   : BF(self.VVea7I , 2)   ,
   "3"   : BF(self.VVea7I , 3)   ,
   "4"   : BF(self.VVea7I , 4)   ,
   "5"   : BF(self.VVea7I , 5)   ,
   "6"   : BF(self.VVea7I , 6)   ,
   "7"   : BF(self.VVea7I , 7)   ,
   "8"   : BF(self.VVea7I , 8)   ,
   "9"   : BF(self.VVea7I , 9)
  }, -1)
  self.onShown.append(self.VVoCo0)
  self.onClose.append(self.onExit)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FF6aqB(self)
  if not CCM2Fd.VVUYe0:
   CCM2Fd.VVUYe0 = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFeKhX(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFeKhX(self["myPlayRpt"], "rpt")
  self.VVyi9P()
  self.instance.move(ePoint(40, 40))
  self.VVyN2c(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVioIC)
  except:
   self.timer.callback.append(self.VVioIC)
  self.timer.start(250, False)
  self.VVioIC("Checking ...")
  self.VVs0pv()
 def VVmdbr(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self)
  self.lastSubtitle = CCsETK.VVpDkk()
  if "chCode" in iptvRef:
   if CC6kXN.VVv4ri(self):
    self.VVs0pv(True)
  else:
   self.VVioIC("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVyi9P(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVahTx()
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VVnKNv + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FFo6oa(self["myTitle"], tColor)
  FFo6oa(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFo6oa(self["myPlay%s" % item], tColor)
  picFile = CC6biu.VVvYZX(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CC6biu.VVPtQu(self)
  cl = CCSdHC.VV302x(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VVioIC(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCBXuV.VVm4rW()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVahTx()
  if evName:
   evName = "    %s    " % FF6TiS(evName, VVsvZg)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVaPhi():
   FFD09G(self["myPlayBlu"], "#00FFFFFF")
   FFo6oa(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFD09G(self["myPlayBlu"], "#00FFFF88")
   FFo6oa(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FFo6oa(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FF3qV5(percVal, 0, 100)
   width = int(FFXM7k(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FFo6oa(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFD09G(self["myPlayMsg"], "#0000ffff")
   else  : FFD09G(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFD09G(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFD09G(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVBH2V()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VV4p6Z(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CCsETK.VVqFbQ(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VV2Btz()
  state = self.VVW33W()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFD09G(self["myPlayMsg"], "#0000ff00")
  else     : FFD09G(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVahTx(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFZRjy(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCM2Fd.VVBYam(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CC6biu.VVKJhs(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CCxkcu()
   tpTxt, satTxt = tp.VVMlvc(refCode)
   self.satInfo_TP = tpTxt + "  " + FF6TiS(satTxt, VVJCMd)
  evName = evNameNext = ""
  evLst = CC2gVv.VVTRuo(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFIO7o(info, iServiceInformation.sVideoWidth) or -1
   h = FFIO7o(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFIO7o(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CC6biu.VVE6rQ(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VVBYam(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFFSaa(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFFSaa(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFFSaa(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VV7zzI(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVahTx()
  FF2xh4Series = FFa4u4(decodedUrl)
  VVegP0 = []
  if self.isFromExternal:
   VVegP0.append((VVJCMd + "IPTV Menu", "iptv"))
   VVegP0.append(VVHMBI)
  if isIptv and not "&end=" in decodedUrl and not FF2xh4Series:
   uType, uHost, uUser, uPass, uId, uChName = CCCu2Z.VVERnQ(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVegP0.append((VVJCMd + "Catchup Programs", "catchup" ))
    VVegP0.append(VVHMBI)
  if refCode:
   c = VVnKNv
   VVegP0.append((c + "Stop Current Service"  , "stop"  ))
   VVegP0.append((c + "Restart Current Service" , "restart"  ))
   txt = "Replay with ..."
   if isDvb: VVegP0.append((txt     ,    ))
   else : VVegP0.append((c + txt    , "replayWith" ))
   VVegP0.append(VVHMBI)
  if FF2xh4Series:
   VVegP0.append((VVJCMd + "File Size (on server)", "fileSize" ))
   VVegP0.append(VVHMBI)
  if self.enableDownloadMenu:
   c = VVJCMd
   addSep = False
   if isIptv and FF2xh4Series:
    VVegP0.append((c + "Start Download"   , "dload_cur" ))
    VVegP0.append((c + "Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCBXuV.VVGcd9():
    VVegP0.append((VVJCMd + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVegP0.append(VVHMBI)
  fPath, fDir, fName = CCr5c7.VVt1SH(self)
  if fPath:
   c = VVSTv2
   if self.enableOpenInFMan and not CCr5c7.VV84kR:
    VVegP0.append((c + "Open path in File Manager", "VVZxUF"))
   VVegP0.append((c + "Add to Bouquet"             , "VVxPDR" ))
   VVegP0.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVM8tv"  ))
   VVegP0.append(VVHMBI)
  if isDvb:
   VVegP0.append((VVJCMd + "Signal Monitor", "sigMon"   ))
  if posTxt and durTxt:
   VVegP0.append((VVpkep + "Start Subtitle", "VVYUP9"))
   VVegP0.append(VVHMBI)
  if CFG.playerPos.getValue() : VVegP0.append(("Move Bar to Bottom"  , "botm"    ))
  else      : VVegP0.append(("Move Bar to Top"  , "top"     ))
  VVegP0.append(("Help"             , "help"    ))
  FFJcY1(self, self.VVlsFJ, VVegP0=VVegP0, width=600, title="Options")
 def VVlsFJ(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VV4muK()
   elif item == "stop"     : self.VVqDzG(0)
   elif item == "restart"    : self.VVqDzG(1)
   elif item == "replayWith"   : self.VV5TGJ()
   elif item == "fileSize"    : FFG53m(self, BF(CC6biu.VVLbYm, self), title="Checking Server")
   elif item == "dload_cur"   : CCBXuV.VVhgw4(self)
   elif item == "addToDload"   : CCBXuV.VVWcAB(self)
   elif item == "dload_stat"   : CCBXuV.VVmWLp(self)
   elif item == "VVZxUF" : self.close("close_openInFileMan")
   elif item == "VVxPDR" : self.VVxPDR()
   elif item == "VVYUP9"  : self.VVHWrT()
   elif item == "VVM8tv"  : self.VVM8tv()
   elif item == "botm"     : self.VVyN2c(0)
   elif item == "top"     : self.VVyN2c(1)
   elif item == "sigMon"    : self.VVENjM()
   elif item == "help"     : FFHU3T(self, "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCM2Fd.VVUYe0 = None
 def VVqDzG(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVyi9P()
   elif typ == 1:
    self.VVioIC("Restarting Service ...")
    FFDxKA(BF(self.VVVhd3, serv))
 def VVVhd3(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self)
  if "&end=" in decodedUrl: BF(self.VVs0pv, True)
  else     : self.session.nav.playService(serv)
 def VV5TGJ(self):
  FFJcY1(self, self.VVvauC, VVegP0=CCr5c7.VVkZbk(), width=650, title="Select Player", VVXbiY="#11220000", VVVy8H="#11220000")
 def VVvauC(self, rType=None):
  if rType:
   FFg1na(self, eServiceReference(rType + ":" + self.session.nav.getCurrentlyPlayingServiceReference().toString().split(":", 1)[1]))
 def VVxPDR(self):
  fPath, fDir, fName = CCr5c7.VVt1SH(self)
  if fPath: picker = CCu3Fm(self, self, "Add Current Movie to a Bouquet", BF(self.VVoqZY, [fPath]))
  else : FFtMfC(self, "Path not found !", 1500)
 def VVoqZY(self, pathLst):
  return CCu3Fm.VVw7o5(pathLst)
 def VVM8tv(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCM2Fd.VVBYam(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVioIC(txt, highlight=ok)
 def VVyN2c(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FFCfiF(CFG.playerPos, pos)
 def VVENjM(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CC6biu.VVKJhs(serv)
   if isDvb: self.close("close_sig")
   else : self.VVioIC("No Signal for Current Service")
 def VVHWrT(self):
  self.session.openWithCallback(self.VVQuQY, BF(CCsETK))
 def VV04ch(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVahTx()
   if posTxt and durTxt: self.VVHWrT()
   else    : self.VVioIC("No duration Info. !")
 def VVQuQY(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VVsWLY(True)
  elif reason == "subtZapDn" : self.VVsWLY(False)
  elif reason == "pause"  : self.VVZXCP()
  elif reason == "audio"  : self.VVcVzE(True)
  elif reason == "subtitle" : self.VVcVzE(False)
  elif reason == "rewind"     : self.VVwD8f()
  elif reason == "forward" : self.VVY4gH()
  elif reason == "rewindDm" : self.VVwD8f()
  elif reason == "forwardDm" : self.VVY4gH()
  else      : txt = reason
  if txt:
   FFtMfC(self, txt, 2000)
 def VVu0DR(self):
  if self.isManualSeek:
   self.VVXiVt()
   self.VV4p6Z(self.manualSeekPts)
  elif self.shown:
   if CCsETK.VVhn9w(self): self.VVHWrT()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVXiVt()
  else    : self.close()
 def VVKzWH(self):
  FFiqcT(self, fncMode=CC6biu.VVsVTC)
 def VVZXCP(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVioIC("Toggling Play/Pause ...")
 def VVXiVt(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VV2hzU(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCM2Fd.VVBYam(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVmRds()
   else:
    self.manualSeekSec += direc * self.VVmRds()
    self.manualSeekSec = FF3qV5(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFXM7k(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFFSaa(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVea7I(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVuMJ4())
   FFCfiF(CFG.playerJumpMin, self.jumpMinutes)
  self.VVioIC("Changed Seek Time to : %d%s" % (val, self.VVDjaA()))
 def VVuMJ4(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVDjaA())
 def VVDjaA(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVDBWc(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVmRds(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVBH2V(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVm2pH(self):
  cList = self.VVaPhi()
  if cList:
   VVegP0 = []
   for pts, what in cList:
    txt = FFFSaa(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVegP0.append((txt, pts))
   FFJcY1(self, self.VVVUQa, VVegP0=VVegP0, title="Cut List")
  else:
   self.VVioIC("No Cut-List for this channel !")
 def VVVUQa(self, item=None):
  if item:
   self.VV4p6Z(item)
 def VVaPhi(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVY4gH(self) : self.VV7vEK(1)
 def VVwD8f(self) : self.VV7vEK(-1)
 def VV7vEK(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCM2Fd.VVBYam(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVmRds() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVDBWc())
    self.VVioIC(txt)
  except:
   self.VVioIC("Cannot jump")
 def VV4p6Z(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVioIC("Changing Time ...")
 def VV2Btz(self):
  self.VVqDzG(1)
  self.VVioIC("Replaying ...")
  self.VVXiVt()
 def VVElmE(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCM2Fd.VVBYam(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVioIC("Jumping to end ...")
  except:
   pass
 def VVW33W(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVsWLY(self, isUp):
  if self.enableZapping:
   self.VVioIC("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVXiVt()
   if self.iptvTableParams:
    FFDxKA(BF(self.VVsc7U, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self)
    if "/timeshift/" in decodedUrl:
     self.VVioIC("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVNjJq()
  else:
   self.VVioIC("Zap Disabled !")
 def VVNjJq(self):
  self.lastPlayPos = 0
  self.VVyi9P()
  self.VVs0pv()
 def VVsc7U(self, isUp):
  CCCu2Z_inatance, VVR0r4, mode = self.iptvTableParams
  if isUp : VVR0r4.VV3oZQ()
  else : VVR0r4.VVn3d0()
  colList = VVR0r4.VVVPDl()
  if mode == "localIptv":
   chName, chUrl = CCCu2Z_inatance.VViNSU(VVR0r4, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCCu2Z_inatance.VVcx5m(VVR0r4, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCCu2Z_inatance.VV7VCM(mode, VVR0r4, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCCu2Z_inatance.VVW5yl(mode, VVR0r4, colList)
  else:
   self.VVioIC("Cannot Zap")
   return
  FFGrAa(self, chUrl, VVMo36=False)
  self.VVNjJq()
 def VVs0pv(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCM2Fd.VVBYam(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self)
   if not self.VV7eRj(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVioIC("Refreshing Portal")
   FFDxKA(self.VVvD3W)
  except:
   pass
 def VVvD3W(self):
  self.restoreLastPlayPos = self.VVEJxa()
 def VV4muK(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self)
  if not decodedUrl or FFa4u4(decodedUrl):
   self.VVioIC("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCCu2Z.VVERnQ(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVioIC("Reading Program List ...")
   ok_fnc = BF(self.VV9acT, refCode, chName, streamId, uHost, uUser, uPass)
   FFDxKA(BF(CCCu2Z.VVDAXv, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVioIC("Cannot process this channel")
 def VV9acT(self, refCode, chName, streamId, uHost, uUser, uPass, VVR0r4, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVR0r4.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVioIC("Changing Program ...")
   FFDxKA(BF(self.VVjC22, chUrl))
  else:
   self.VVioIC("Incorrect Timestamp !")
 def VVjC22(self, chUrl):
  FFGrAa(self, chUrl, VVMo36=False)
  self.lastPlayPos = 0
  self.VVyi9P()
 def VVcVzE(self, isAudio):
  try:
   VVcxBI = InfoBar.instance
   if VVcxBI:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVcxBI)
    else  : self.session.open(SubtitleSelection, VVcxBI)
  except:
   pass
 @staticmethod
 def VVNRD5(session, mode=None):
  if   mode == "close_sig"   : FFyGv4(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CCCu2Z)
  elif mode == "close_openInFileMan" : session.open(CCr5c7, gotoMovie=True)
 @staticmethod
 def VV8elw(session, isFromExternal=False, **kwargs):
  session.openWithCallback(BF(CCM2Fd.VVNRD5, session), CCM2Fd, isFromExternal=isFromExternal, **kwargs)
class CCawWb(Screen):
 def __init__(self, session, title="", VVFNjG="Continue?", VV6Lpq=True, VVARnJ=False):
  self.skin, self.skinParam = FFAJVu(VVoC9G, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVFNjG = VVFNjG
  self.VVARnJ = VVARnJ
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VV6Lpq : VVegP0 = [no , yes]
  else   : VVegP0 = [yes, no ]
  FFsw8F(self, title, VVegP0=VVegP0, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVu0DR ,
   "cancel": self.cancel ,
   "red" : self.cancel ,
  }, -1)
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVFNjG)
  if self.VVARnJ:
   self["myLabel"].instance.setHAlign(0)
  self.VVPoVV()
  FFCoOh(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FF9mPY(self["myMenu"])
  FFzEDc(self, self["myMenu"])
 def VVu0DR(self):
  item = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVPoVV(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCUQPd(Screen):
 def __init__(self, session, title="", VVegP0=None, width=1000, height=850, VVwwGj=30, barText="", minRows=1, OKBtnFnc=None, infoBtnFnc=None, VVKP6N=None, VVzqGT=None, VVV5x7=None, VVZKXi=None, VV4p4D=False, VVk6EI=False, yellowBasePath=None, rcuSearch=True, VVXbiY="#22003344", VVVy8H="#22002233"):
  self.skin, self.skinParam = FFAJVu(VVtBbU, width, height, 50, 40, 30, VVXbiY, VVVy8H, VVwwGj, barHeight=40, topRightBtns=3 if infoBtnFnc else 0)
  self.session   = session
  self.VVegP0   = VVegP0
  self.barText   = barText
  self.minRows   = minRows
  self.OKBtnFnc   = OKBtnFnc
  self.infoBtnFnc   = infoBtnFnc
  self.VVKP6N   = VVKP6N
  self.VVzqGT  = VVzqGT
  self.VVV5x7  = ("Delete File", BF(self.VVoT52, yellowBasePath)) if not yellowBasePath is None else VVV5x7
  self.VVZKXi   = VVZKXi
  self.VV4p4D  = VV4p4D
  self.VVk6EI  = VVk6EI
  self.Title    = title
  FFsw8F(self, title, VVegP0=VVegP0)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVu0DR    ,
   "cancel" : self.cancel    ,
   "info"  : self.VVb2po   ,
   "red"  : self.VVREjd   ,
   "green"  : self.VV45Xb   ,
   "yellow" : self.VVB5lw   ,
   "blue"  : self.VVkvkE   ,
   "pageUp" : self.VVDgBr ,
   "chanUp" : self.VVDgBr ,
   "pageDown" : self.VVH5zb  ,
   "chanDown" : self.VVH5zb  ,
   "0"   : BF(self.VV9V1P, 0) ,
   "1"   : BF(self.VV9V1P, 1) ,
   "2"   : BF(self.VV9V1P, 2) ,
   "3"   : BF(self.VV9V1P, 3) ,
   "4"   : BF(self.VV9V1P, 4) ,
   "5"   : BF(self.VV9V1P, 5) ,
   "6"   : BF(self.VV9V1P, 6) ,
   "7"   : BF(self.VV9V1P, 7) ,
   "8"   : BF(self.VV9V1P, 8) ,
   "9"   : BF(self.VV9V1P, 9)
  }, -1)
  if rcuSearch:
   FF0zxL(self, self["myMenu"], isMenu=True)
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FFCoOh(self["myMenu"])
  FFUSMR(self, minRows=self.minRows)
  FF6aqB(self)
  self.VVx5dI(self["keyRed"]  , self.VVKP6N )
  self.VVx5dI(self["keyGreen"] , self.VVzqGT )
  self.VVx5dI(self["keyYellow"] , self.VVV5x7 )
  self.VVx5dI(self["keyBlue"]  , self.VVZKXi )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFnLuC(self)
 def VVx5dI(self, btnObj, btnFnc):
  if btnFnc:
   FF154z(btnObj, btnFnc[0])
 def VVXwu9(self, fnc=None):
  self.VVzqGT = fnc
  if fnc : self.VVx5dI(self["keyGreen"], self.VVzqGT)
  else : self["keyGreen"].hide()
 def VV9V1P(self, digit):
  digit = str(digit)
  VVegP0 = self["myMenu"].list
  for ndx, item in enumerate(VVegP0):
   if len(item) == 2:
    span = iSearch(r"^\[(\d)\]\s.+", FF2AUs(item[0]), IGNORECASE)
    if span and span.group(1) == digit:
     self.VVc7DL(ndx)
     self.VVu0DR()
     break
 def VVu0DR(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if item is not None:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VV4p4D: self.close((txt, ref, ndx))
    else     : self.close(item)
 def VVb2po(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if self.infoBtnFnc and item:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   self.infoBtnFnc(self, txt, ref, ndx)
 def cancel(self):
  self.close(None)
 def VVREjd(self)  : self.VV5jsY(self.VVKP6N)
 def VV45Xb(self) : self.VV5jsY(self.VVzqGT)
 def VVB5lw(self) : self.VV5jsY(self.VVV5x7)
 def VVkvkE(self) : self.VV5jsY(self.VVZKXi)
 def VV5jsY(self, btnFnc):
  if btnFnc:
   item = self["myMenu"].l.getCurrentSelection()[1]
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVk6EI:
    self.cancel()
 def VVc7DL(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VVRGNt(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVegP0 = self["myMenu"].list
  VVegP0.pop(ndx)
  if len(VVegP0) > 0: self["myMenu"].setList(VVegP0)
  else    : self.close()
 def VVoT52(self, basePath, menuObj, fName):
  FFWBJu(self, BF(self.VVS93v, basePath + fName), "Delete this file ?\n\n%s" % fName, title=self.Title)
 def VVS93v(self, path):
  FFO0bd(path)
  if fileExists(path) : FFtMfC(self, "Not deleted", 1000)
  else    : self.VVRGNt()
 def VVjgJn(self, VVegP0):
  if len(VVegP0) > 0:
   newList = []
   for item in VVegP0:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFUSMR(self, minRows=self.minRows)
  else:
   self.close("")
 def VVzxEM(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FFUSMR(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVW5VR(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVDgBr(self) : self["myMenu"].moveToIndex(0)
 def VVH5zb(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCbfio(Screen):
 def __init__(self, session, title="", width=1600, height=900, vMargin=5, header=None, VVVC4T=None, VVsZoP=None, VVx2iV=None, VVwwGj=26, VVSwEr=False, VVLnTw=0, VV91FP=None, VVBSYf=None, VVIqI1=None, VVdn6T=None, VVljWo=None, VVDB15=None, VV1BNd=None, VVqfcE=None, VVs5Sk=None, VVwmtP=-1, VVPDqC=0, searchCol=0, lastFindConfigObj=None, VVXbiY=None, VVVy8H=None, VVDqI1="#00dddddd", VVvi08="#11002233", VVbSmQ="#00ff8833", VVTrrJ="#11111111", VVcd71="#0a555555", VVaCfW="#0affffff", VVVygK="#11552200", VVMz1U="#0055ff55", VVMz1URev="#0000bbff"):
  self.skin, self.skinParam = FFAJVu(VVQQVG, width, height, 50, 10, vMargin, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFsw8F(self, title)
  self.Title     = title
  self.header     = header
  self.VVVC4T     = VVVC4T
  self.totalCols    = len(VVVC4T[0])
  self.VVLnTw   = VVLnTw
  self.lastSortModeIsReverese = False
  self.VVSwEr   = VVSwEr
  self.VVaBjk   = 0.01
  self.VVtwBs   = 0.02
  self.VV3Pwl = 0.03
  self.VVA3Ks  = 1
  self.VVx2iV = VVx2iV
  self.colWidthPixels   = []
  self.VV91FP   = VV91FP
  self.OKButtonObj   = None
  self.VVBSYf   = VVBSYf
  self.VVIqI1   = VVIqI1
  self.VVdn6T   = VVdn6T
  self.VVljWo  = VVljWo
  self.VVDB15   = VVDB15
  self.VV1BNd    = VV1BNd
  self.VVqfcE   = VVqfcE
  self.tableRefreshCB   = None
  self.VVs5Sk  = VVs5Sk
  self.VVwmtP    = VVwmtP
  self.VVPDqC   = VVPDqC
  self.searchCol    = searchCol
  self.VVsZoP    = VVsZoP
  self.keyPressed    = -1
  self.VVwwGj    = FFtS1n(VVwwGj)
  self.VVLEkl    = FFlCly(self.VVwwGj, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVXbiY    = VVXbiY
  self.VVVy8H      = VVVy8H
  self.VVDqI1    = FFXhEg(VVDqI1)
  self.VVvi08    = FFXhEg(VVvi08)
  self.VVbSmQ    = FFXhEg(VVbSmQ)
  self.VVTrrJ    = FFXhEg(VVTrrJ)
  self.VVcd71   = FFXhEg(VVcd71)
  self.VVaCfW    = FFXhEg(VVaCfW)
  self.VVVygK    = FFXhEg(VVVygK)
  self.VVMz1U   = FFXhEg(VVMz1U)
  self.VVMz1URev  = FFXhEg(VVMz1URev)
  self.VV9Jt5  = False
  self.selectedItems   = 0
  self.VVvUEV   = FFXhEg("#01fefe01")
  self.VVlQ8L   = FFXhEg("#11400040")
  self.VVyvQ7  = self.VVvUEV
  self.VVAh7N  = self.VVTrrJ
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVPDqC:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   if self.VVPDqC == 1: self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VV8Zm9  ,
   "red"  : self.VVLfxy  ,
   "green"  : self.VVzbL8 ,
   "yellow" : self.VViyKs ,
   "blue"  : self.VVbRfl  ,
   "menu"  : self.VVR0hY ,
   "info"  : self.VV1dxz  ,
   "cancel" : self.VVoRxz  ,
   "up"  : self.VVn3d0    ,
   "down"  : self.VV3oZQ  ,
   "left"  : self.VVunAJ   ,
   "right"  : self.VVCKqL  ,
   "next"  : self.VV63La  ,
   "last"  : self.VVnnPB  ,
   "home"  : self.VVHqSA  ,
   "pageUp" : self.VVHqSA  ,
   "chanUp" : self.VVHqSA  ,
   "end"  : self.VVuIdh  ,
   "pageDown" : self.VVuIdh  ,
   "chanDown" : self.VVuIdh
  }, -1)
  FF0zxL(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FF6aqB(self)
  try:
   self.VVza0v()
  except Exception as e:
   FFnHzu(self, str(e), title=self.Title)
   self.close(None)
 def VVza0v(self):
  FFnLuC(self)
  if self.VVXbiY:
   FFo6oa(self["myTitle"], self.VVXbiY)
  if self.VVVy8H:
   FFo6oa(self["myBody"] , self.VVVy8H)
   FFo6oa(self["myTableH"] , self.VVVy8H)
   FFo6oa(self["myTable"] , self.VVVy8H)
   FFo6oa(self["myBar"]  , self.VVVy8H)
  self.VVx5dI(self.VVIqI1  , self["keyRed"])
  self.VVx5dI(self.VVdn6T  , self["keyGreen"])
  self.VVx5dI(self.VVljWo , self["keyYellow"])
  self.VVx5dI(self.VVDB15  , self["keyBlue"])
  if self.VV91FP:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj and self.VV91FP[0]:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VV91FP[0])
    FFo6oa(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVLEkl)
  self["myTableH"].l.setFont(0, gFont(VV07pp, self.VVwwGj))
  self["myTable"].l.setItemHeight(self.VVLEkl)
  self["myTable"].l.setFont(0, gFont(VV07pp, self.VVwwGj))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVLEkl)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVLEkl))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVLEkl)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVLEkl
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVLEkl * len(self.VVVC4T) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVx2iV:
   self.VVx2iV = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVx2iV)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVsZoP:
   self.VVsZoP = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVsZoP
   self.VVsZoP = []
   for item in tmpList:
    self.VVsZoP.append(item | RT_VALIGN_CENTER)
  self.VVeA4a()
  if self.VV1BNd:
   self.VV1BNd(self)
 def VVx5dI(self, btnFnc, btn):
  if btnFnc : FF154z(btn, btnFnc[0])
  else  : FF154z(btn, "")
 def VVLF9P(self, waitTxt):
  FFG53m(self, self.VVeA4a, title=waitTxt)
 def VVeA4a(self, onlyHeader=False):
  try:
   if self.header:
    sortedFg = self.VVMz1URev if self.lastSortModeIsReverese else self.VVMz1U
    self["myTableH"].setList([self.VV6Bux(0, self.header, self.VVaCfW, self.VVVygK, self.VVaCfW, self.VVVygK, sortedFg)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVVC4T):
    self["myTable"].list.append(self.VV6Bux(c, row, self.VVDqI1, self.VVvi08, self.VVbSmQ, self.VVTrrJ, None))
   self.VVVC4T = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVwmtP > -1:
    self["myTable"].moveToIndex(self.VVwmtP )
   self.VVg4vg()
   if self.VVPDqC:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVLEkl * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
     FFOgS2(self, width, newH)
   if self.VVqfcE:
    self.VV5jsY(self.VVqfcE, None)
   if self.tableRefreshCB:
    self.VV5jsY(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FFnHzu(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VV6Bux(self, keyIndex, columns, VVDqI1, VVvi08, VVbSmQ, VVTrrJ, VVMz1U):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVMz1U and ndx == self.VVLnTw : textColor = VVMz1U
   else           : textColor = VVDqI1
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFXhEg(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVvi08 = c
    entry = span.group(3)
   if self.VVsZoP[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVLEkl)
           , font   = 0
           , flags   = self.VVsZoP[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVvi08
           , color_sel  = VVbSmQ
           , backcolor_sel = VVTrrJ
           , border_width = 1
           , border_color = self.VVcd71
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VV1dxz(self):
  rowData = self.VVifYH()
  if rowData:
   title, txt, colList = rowData
   if self.VVBSYf:
    fnc  = self.VVBSYf[1]
    params = self.VVBSYf[2]
    fnc(self, title, txt, colList)
   else:
    FFJRXg(self, txt, title)
 def VV8Zm9(self):
  if   self.VV9Jt5 : self.VVJiBU(self.VVVZYd(), mode=2)
  elif self.VV91FP  : self.VV5jsY(self.VV91FP, None)
  else      : self.VV1dxz()
 def VVLfxy(self) : self.VV5jsY(self.VVIqI1 , self["keyRed"])
 def VVzbL8(self) : self.VV5jsY(self.VVdn6T , self["keyGreen"])
 def VViyKs(self): self.VV5jsY(self.VVljWo , self["keyYellow"])
 def VVbRfl(self) : self.VV5jsY(self.VVDB15 , self["keyBlue"])
 def VV5jsY(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFtMfC(self, buttonFnc[3])
    FFDxKA(BF(self.VVzLPC, buttonFnc))
   else:
    self.VVzLPC(buttonFnc)
 def VVzLPC(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVifYH()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVJiBU(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][9] == self.VVvUEV
   newRow = self.VVVPDl()
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VV6Bux(ndx, newRow, self.VVDqI1, self.VVvi08, self.VVbSmQ, self.VVTrrJ, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VV6Bux(ndx, newRow, self.VVvUEV, self.VVlQ8L, self.VVyvQ7, self.VVAh7N, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   if self.VVVZYd() < len(self["myTable"].list) - 1:
    self.VV3oZQ()
   else:
    self.VVg4vg()
 def VVMAwS(self)  : FFG53m(self, BF(self.VV1eIU, True ), title="Selecting all ..."  )
 def VVBnDy(self) : FFG53m(self, BF(self.VV1eIU, False), title="Unselecting all ...")
 def VV1eIU(self, isSel=True):
  if isSel:
   fg, bg = self.VVvUEV, self.VVlQ8L
   self.selectedItems = len(self["myTable"].list)
   self.VVHKEm(True)
  else:
   fg, bg = self.VVDqI1, self.VVvi08
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][9] == self.VVvUEV
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     param = list(self["myTable"].list[ndx][col])
     param[8]  = fg
     param[9]  = fg
     param[10] = bg
     self["myTable"].list[ndx][col] = tuple(param)
  self["myTable"].l.invalidate()
 def VVifYH(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVx2iV[i] > 1 or self.VVx2iV[i] == self.VVaBjk or self.VVx2iV[i] == self.VV3Pwl:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VVoRxz(self):
  if self.VVs5Sk : self.VVs5Sk(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VVUbIN(self):
  return self["myTitle"].getText().strip()
 def VVZqSH(self):
  return self.header
 def VVUlFx(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVE4O1(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFD09G(self["myBar"], color)
 def VV7IKK(self, txt):
  FFtMfC(self, txt)
 def VVsu20(self, txt, Time=1000):
  FFtMfC(self, txt, Time)
 def VVbUHV(self): self["keyGreen"].show()
 def VVFthC(self): self["keyGreen"].hide()
 def VVeSEs(self): return self["keyGreen"].visible
 def VVRZ9B(self):
  FFtMfC(self)
 def VVwfvv(self, fnc):
  self["myTable"].onSelectionChanged.append(fnc)
 def VV6qIs(self):
  return len(self["myTable"].list)
 def VVVZYd(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVsBGq(self):
  return len(self["myTable"].list)
 def VVHKEm(self, isOn):
  self.VV9Jt5 = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VVDB15: self["keyBlue"].hide()
   if self.VV91FP and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVDB15: self["keyBlue"].show()
   if self.VV91FP and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VV91FP[0])
   self.VVBnDy()
  FFo6oa(self["myTitle"], color)
  FFo6oa(self["myBar"]  , color)
 def VVIeoE(self):
  return self.VV9Jt5
 def VVkGfp(self):
  return self.selectedItems
 def VV2xJG(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVg4vg()
 def VVPC54(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVDjHI(self):
  txt  = "Total Rows\t: %d\n\n" % self.VV6qIs()
  txt += FFqjvC("Total Unique Items", VVsIVN)
  for i in range(self.totalCols):
   if self.VVx2iV[i - 1] > 1 or self.VVx2iV[i - 1] == self.VVaBjk or self.VVx2iV[i - 1] == self.VV3Pwl:
    name, tot = self.VVPC54(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFJRXg(self, txt)
 def VV5xX4(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVVPDl(self):
  return self.VV9JtZ(self["myTable"].l.getCurrentSelectionIndex())
 def VV9JtZ(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVwzoo(self, newList, newTitle="", VVHKttMsg=True, tableRefreshCB=None):
  if newTitle:
   self.VVUlFx(newTitle)
  if newList:
   self.VVVC4T = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VVSwEr and self.VVLnTw == 0:
    isNum = True
   else:
    for cols in self.VVVC4T:
     if not FFGQm9(cols[self.VVLnTw]): break
    else:
     isNum = True
   if isNum: self.VVVC4T.sort(key=lambda x: int(x[self.VVLnTw])  , reverse=self.lastSortModeIsReverese)
   else : self.VVVC4T.sort(key=lambda x: x[self.VVLnTw].lower() , reverse=self.lastSortModeIsReverese)
   if VVHKttMsg : self.VVLF9P("Refreshing ...")
   else   : self.VVeA4a()
  else:
   FFnHzu(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VVkySl(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VV6Bux(self.VVsBGq(), row, self.VVDqI1, self.VVvi08, self.VVbSmQ, self.VVTrrJ, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VVuIdh()
 def VVWDEt(self):
  self["myTable"].list.pop(self.VVVZYd())
  self["myTable"].l.setList(self["myTable"].list)
 def VVkf6n(self, data):
  ndx = self.VVVZYd()
  newRow = self.VV6Bux(ndx, data, self.VVDqI1, self.VVvi08, self.VVbSmQ, self.VVTrrJ, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVg4vg()
   return True
  else:
   return False
 def VVsr2V(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VV6Bux(ndx, data, self.VVDqI1, self.VVvi08, self.VVbSmQ, self.VVTrrJ, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVyz8q()
 def VVyz8q(self):
  self["myTable"].l.setList(self["myTable"].list)
 def VVOzcm(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VVRgyb(self, colNum, textToFind, VVozbc=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVg4vg()
    break
  else:
   if VVozbc:
    FFtMfC(self, "Not found", 1000)
 def VVzatv(self, colDict, VVozbc=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVg4vg()
    return
  if VVozbc:
   FFtMfC(self, "Not found", 1000)
 def VV4ZZO(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVxT1o(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFGQm9(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVYpZO(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVvUEV:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVKweo(self):
  if self.selectedItems:
   for ndx, row in enumerate(self["myTable"].list):
    if row[1][9] == self.VVvUEV:
     return ndx
  return -1
 def VVFwt1(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVvUEV:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VVFcPL(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VVvUEV: return True
  else        : return False
 def VVtxRM(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVR0hY(self):
  if not self["keyMenu"].getVisible() or self.VVPDqC:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVVZYd()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVegP01, VVcbKg = CCSAYR.VVy9Xb(self, False, False)
  VVegP0 = []
  VVegP0.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVegP0.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVegP0.append(("Find ...\t\t%s" % (FF6TiS(txt, VVOEUI) if txt else ""), "findNew"   ))
  VVegP0.append(itemOf(bool(VVegP01)    , "Find (from Filter) ..."   , "filter"   ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Table Statistcis"             , "tableStat"  ))
  VVegP0.append(VVHMBI)
  VVegP0.append((FF6TiS("Export Table to .html"     , VVsIVN) , "VVZmS4" ))
  VVegP0.append((FF6TiS("Export Table to .csv"     , VVsIVN) , "VVUQ38" ))
  VVegP0.append((FF6TiS("Export Table to .txt (Tab Separated)", VVsIVN) , "VVCqMU" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVx2iV[i] > 1 or self.VVx2iV[i] == self.VVtwBs:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVegP0.append(VVHMBI)
   if tot == 1 : VVegP0.append(("Sort", sList[0][1]))
   else  : VVegP0 += sList
  VVZKXi = ("Keys Help", self.FFqiz1Help)
  FFJcY1(self, self.VVvj8R, VVegP0=VVegP0, title=self.VVUbIN(), VVZKXi=VVZKXi)
 def VVvj8R(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVEN3Y()
   elif item == "findPrev"  : self.VVEN3Y(isPrev=True)
   elif item == "findNew"  : self.VVdaLy()
   elif item == "filter"  : self.VV47rA()
   elif item == "tableStat" : self.VVDjHI()
   elif item == "VVZmS4": FFG53m(self, self.VVZmS4, title=title)
   elif item == "VVUQ38" : FFG53m(self, self.VVUQ38 , title=title)
   elif item == "VVCqMU" : FFG53m(self, self.VVCqMU , title=title)
   else:
    if self.VVLnTw == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVLnTw, self.lastSortModeIsReverese = item, False
    if self.VVSwEr and self.VVLnTw == 0 or self.VVxT1o(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVeA4a(onlyHeader=True)
 def FFqiz1Help(self, menuInstance, path):
  FFHU3T(self, "_help_table", "Table (Keys Help)")
 def VVn3d0(self):
  self["myTable"].up()
  self.VVg4vg()
 def VV3oZQ(self):
  self["myTable"].down()
  self.VVg4vg()
 def VVunAJ(self):
  self["myTable"].pageUp()
  self.VVg4vg()
 def VVCKqL(self):
  self["myTable"].pageDown()
  self.VVg4vg()
 def VVHqSA(self):
  self["myTable"].moveToIndex(0)
  self.VVg4vg()
 def VVuIdh(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVg4vg()
 def VVwqjr(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVg4vg()
 def VV63La(self):
  if self.lastFindConfigObj.getValue():
   if self.VVVZYd() == len(self["myTable"].list) - 1 : FFtMfC(self, "End reached", 1000)
   else              : self.VVEN3Y()
  else:
   FFtMfC(self, 'Set "Find" in Menu', 1500)
 def VVnnPB(self):
  if self.lastFindConfigObj.getValue():
   if self.VVVZYd() == 0 : FFtMfC(self, "Top reached", 1000)
   else       : self.VVEN3Y(isPrev=True)
  else:
   FFtMfC(self, 'Set "Find" in Menu', 1500)
 def VVrIW7(self, txt):
  FFCfiF(self.lastFindConfigObj, txt)
 def VVdaLy(self):
  FFYvs0(self, self.VVgrO4, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VVgrO4(self, VVbYOE):
  if not VVbYOE is None:
   txt = VVbYOE.strip()
   self.VVrIW7(txt)
   if VVbYOE: self.VVEN3Y(reset=True)
   else  : FFtMfC(self, "Nothing to find !", 1500)
 def VV47rA(self):
  VVegP0, VVcbKg = CCSAYR.VVy9Xb(self, False, False)
  VVV5x7 = ("Edit Filter", BF(self.VVAnbV, VVcbKg))
  if VVegP0 : FFJcY1(self, self.VVRQZZ, VVegP0=VVegP0, VVV5x7=VVV5x7, title="Find from Filter")
  else  : FFtMfC(self, "Filter Error !", 1500)
 def VVRQZZ(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VVrIW7(txt)
    self.VVEN3Y(reset=True)
   else:
    FFtMfC(self, "No entry !", 1500)
 def VVAnbV(self, VVcbKg, VVsxjbObj, sel):
  if fileExists(VVcbKg) : CCzWmm(self, VVcbKg, VVuJdT=None)
  else       : FFlkXm(self, VVcbKg)
  VVsxjbObj.cancel()
 def VVEN3Y(self, reset=False, isPrev=False):
  curRow = self.VVVZYd()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCSAYR.VVaVMf(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VVwqjr(i)
      break
    elif any(x in line for x in tupl):
     self.VVwqjr(i)
     break
   else:
    FFtMfC(self, "Not found", 1000)
  else:
   FFtMfC(self, "Check your query", 1500)
 def VVCqMU(self):
  expFile = self.VVzfNX() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VV15Vh()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VV9JtZ(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVx2iV[ndx] > self.VVA3Ks or self.VVx2iV[ndx] == self.VV3Pwl:
      col = self.VVQjxa(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVXRXS(expFile)
 def VVUQ38(self):
  expFile = self.VVzfNX() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VV15Vh()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VV9JtZ(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVx2iV[ndx] > self.VVA3Ks or self.VVx2iV[ndx] == self.VV3Pwl:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VVQjxa(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVXRXS(expFile)
 def VVZmS4(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVUbIN(), PLUGIN_NAME, VVVsnC)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVUbIN()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VV15Vh()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVx2iV:
   colgroup += '   <colgroup>'
   for w in self.VVx2iV:
    if w > self.VVA3Ks or w == self.VV3Pwl:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVzfNX() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VV9JtZ(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVx2iV[ndx] > self.VVA3Ks or self.VVx2iV[ndx] == self.VV3Pwl:
      col = self.VVQjxa(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVXRXS(expFile)
 def VV15Vh(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVx2iV[ndx] > self.VVA3Ks or self.VVx2iV[ndx] == self.VV3Pwl:
     newRow.append(col.strip())
  return newRow
 def VVQjxa(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FF2AUs(col)
 def VVzfNX(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVUbIN())
  fileName = fileName.replace("__", "_")
  path  = FFxJSp(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFxsfY()
  return expFile
 def VVXRXS(self, expFile):
  FFcZi2(self, "File exported to:\n\n%s" % expFile, title=self.VVUbIN())
 def VVg4vg(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCSdHC():
 def __init__(self, pixmapObj, picPath, VVvi08=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VVvi08  = VVvi08 or "#2200002a"
 def VVgdlS(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVoB97)
    except:
     self.picLoad.PictureData.get().append(self.VVoB97)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VVvi08])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVoB97(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVN4p9(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VV302x(pixmapObj, path, VVvi08=None):
  cl = CCSdHC(pixmapObj, path, VVvi08)
  ok = cl.VVgdlS()
  if ok: return cl
  else : return None
class CCDdSC(Screen):
 def __init__(self, session, title="", VVQyig=None, showGrnMsg="", fileList=None, curIndex=0, cbFnc=None):
  scrW, scrH = FFF92P()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FFAJVu(VVg0pw, w, h, 30, 0, 0, "#22000060", "#2200002a", 30, topRightBtns=3)
  self.session  = session
  self.Title   = title
  self["myPic"]  = Pixmap()
  self.VVQyig = VVQyig
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.cbFnc   = cbFnc
  self.picViewer  = None
  FFsw8F(self)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "info" : self.VVOySr  ,
   "up" : BF(self.VVwC3L, -1),
   "down" : BF(self.VVwC3L,  1),
   "left" : BF(self.VVwC3L, -1),
   "right" : BF(self.VVwC3L,  1)
  }, -1)
  self.onShown.append(self.VVoCo0)
  self.onClose.append(self.onExit)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FF6aqB(self)
  self.VV88Vw()
  self.picViewer = CCSdHC.VV302x(self["myPic"], self.VVQyig)
  if self.picViewer:
   if self.showGrnMsg:
    FFtMfC(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFnHzu(self, "Cannot view picture file:\n\n%s" % self.VVQyig)
   self.close()
 def onExit(self):
  if self.picViewer: self.picViewer.VVN4p9()
  if self.cbFnc: self.cbFnc(self.VVQyig)
 def VVwC3L(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.VVQyig = FFxJSp(os.path.dirname(self.VVQyig)) + fName
    self.picViewer.picPath = self.VVQyig
    self.picViewer.VVgdlS()
    self.VV88Vw()
 def VVOySr(self):
  txt = "%s:\n  %s" % (FF6TiS("Path", VVpkep), self.VVQyig)
  size, sizeTxt, resTxt, form, mode = CCmMzJ.VVav1t(self.VVQyig)
  if any((size, sizeTxt, resTxt, form, mode)):
   txt += "\n\n%s:\n" % FF6TiS("Properties", VVpkep)
   if sizeTxt: txt += "  File Size\t: %s\n" % sizeTxt
   if resTxt : txt += "  Dimensions\t: %s\n" % resTxt
   if form   : txt += "  Format\t: %s\n"  % form
   if mode   : txt += "  Mode\t: %s\n"   % mode
  FFJRXg(self, txt, title="File Information")
 def VV88Vw(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VVQyig)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VVvctb(SELF, VVQyig, title="", showGrnMsg="", fileList=None, curIndex=0, cbFnc=None):
  SELF.session.open(BF(CCDdSC, title=title, VVQyig=VVQyig, showGrnMsg=showGrnMsg, fileList=fileList, curIndex=curIndex, cbFnc=cbFnc))
class CC5wI4(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FFAJVu(VVX7Sq, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FFsw8F(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VVoCo0)
  self.onClose.append(self.onExit)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  res = os.system(FFNxGN("showiframe %s" % self.mviFile))
  if not res == 0:
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VVULDq(SELF, mviFile):
  SELF.session.openWithCallback(BF(CC5wI4.VV7mL0, SELF), CC5wI4, mviFile)
 @staticmethod
 def VV7mL0(SELF, reason=None):
  if reason == -1: FFnHzu(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CCAqEA(Screen, ConfigListScreen):
 VV8Gfi = "ajpanel_update_url"
 def __init__(self, session):
  self.skin, self.skinParam = FFAJVu(VVOWvY, 1400, 1050, 50, 15, 15, "#11201010", "#11101010", 27, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFsw8F(self, title=self.Title)
  FF154z(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("File Manage Exit-Button Action"        , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  lst.append(getConfigListEntry(VVtc24 *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Local Movies and IPTV Download Path"       , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VVtc24 *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VVtc24 *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VV8E29()
  self.onShown.append(self.VVoCo0)
 def VV8E29(self):
  kList = {
    "ok" : self.VVu0DR   ,
    "green" : self.VVjkVt ,
    "menu" : self.VVMZKm ,
    "cancel": self.VVBQKD ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVpZaY, 0)
     kList["chanDown"] = BF(self["config"].VVpZaY, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FF6aqB(self)
  FFCoOh(self["config"])
  FFUSMR(self, self["config"])
  FFnLuC(self)
  self["config"].onSelectionChanged.append(self.VV4CsE)
  FFo6oa(self["keyRed"], "#11000000")
  self["keyRed"].show()
  self.VV4CsE()
 def VV4CsE(self):
  cfg = self["config"].getCurrent()[1]
  if   isinstance(cfg, ConfigDirectory): txt = "Change Path"
  else         : txt = "Show Choices"
  self["keyRed"].setText("OK = %s" % txt)
 def VVu0DR(self):
  title, item = self["config"].getCurrent()
  if item:
   if   item == CFG.iptvHostsMode   : self.VV9BcP()
   elif item == CFG.MovieDownloadPath   : self.VVBX6t(item, self["config"].getCurrent()[0])
   elif isinstance(item, ConfigDirectory) : self.VVdpUU(item)
   else         : CCAqEA.VVLGjH(self, item, title)
 @staticmethod
 def VVLGjH(SELF, confItem, title, lst=None, cbFnc=None):
  isBool = isinstance(confItem, ConfigYesNo)
  isLst  = isinstance(confItem, ConfigSelection)
  isTxt  = isinstance(confItem, ConfigText)
  if not lst:
   if   isBool : lst = [(True, "ON"), (False, "OFF")]
   elif isLst : lst = confItem.choices.choices
   else  : return
  curNdx = defNdx = -1
  VVegP0 = []
  for ndx, item in enumerate(lst):
   if len(item) == 1:
    val, txt = ("dum",VVtc24)
   else:
    val, txt = item
    if   val == confItem.value : curNdx, txt = ndx, VVOEUI + txt
    elif val == confItem.default: defNdx, txt = ndx, VVBfw8 + txt
   VVegP0.append((txt, val))
  if defNdx == -1: defNdx = curNdx
  VVZKXi  = ("Current", BF(CCAqEA.VVwvQx, curNdx))
  VVV5x7 = ("Default", BF(CCAqEA.VVwvQx, defNdx))
  menuInstance = FFJcY1(SELF, BF(CCAqEA.VVTnsD, confItem, cbFnc), VVegP0=VVegP0, width=1200, VVV5x7=VVV5x7, VVZKXi=VVZKXi, title=title, VVXbiY="#33221111", VVVy8H="#33110011")
  menuInstance.VVc7DL(curNdx)
 @staticmethod
 def VVTnsD(confItem, cbFnc, item=None):
  if not item is None:
   FFCfiF(confItem, item)
   if cbFnc:
    cbFnc()
 @staticmethod
 def VVwvQx(ndx, VVsxjbObj, item):
  VVsxjbObj.VVc7DL(ndx)
 @staticmethod
 def VV8rL2(confItem, lst):
  for ndx, item in enumerate(lst):
   if item[0] == confItem.value:
    return ndx
  return -1
 def VVBX6t(self, item, title):
  tot = CCBXuV.VVm4rW()
  if tot : FFnHzu(self, "Cannot change while downloading.", title=title)
  else : self.VVdpUU(item)
 def VV9BcP(self):
  VVegP0 = []
  VVegP0.append(("Auto Find" , "auto"))
  VVegP0.append(("Custom Path" , "cust"))
  FFJcY1(self, self.VVTqrq, VVegP0=VVegP0, title="IPTV Hosts Files Path")
 def VVTqrq(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVrV5t)
   elif item == "cust":
    VVzto2 = self.VVQrbh()
    if VVzto2 : self.VVElTc(VVzto2)
    else  : self.session.openWithCallback(self.VVGAf8, BF(CCr5c7, mode=CCr5c7.VVT9mm, VV3Cmf="/"))
 def VVElTc(self, VVzto2):
  VVs5Sk = self.VVctWM
  VVIqI1 = ("Remove"  , self.VV261J , [])
  VVljWo = ("Add "  , self.VVkYOo, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VVsZoP  = (LEFT   , LEFT  )
  FFqiz1(self, None, title="IPTV Hosts Search Paths", header=header, VVVC4T=VVzto2, width=1200, height=700, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=26, VVs5Sk=VVs5Sk, VVIqI1=VVIqI1, VVljWo=VVljWo
    , VVXbiY="#11220000", VVVy8H="#11110000", VVvi08="#11110011", VVbSmQ="#00ffff00", VVTrrJ="#00223025", VVcd71="#0a333333", VVVygK="#0a400040")
 def VVctWM(self, VVR0r4):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVN9NZ)
  VVR0r4.cancel()
 def VVGAf8(self, path):
  if path:
   FFCfiF(CFG.iptvHostsDirs, FFxJSp(path.strip()))
   VVzto2 = self.VVQrbh()
   if VVzto2 : self.VVElTc(VVzto2)
   else  : FFtMfC(self, "Cannot add dir", 1500)
 def VV8Zoi(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVrV5t:
   return []
  return lst
 def VVQrbh(self):
  lst = self.VV8Zoi()
  if lst:
   VVzto2 = []
   for Dir in lst:
    VVzto2.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVzto2.sort(key=lambda x: x[0].lower())
   return VVzto2
  else:
   return []
 def VVkYOo(self, VVR0r4, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VVAUzQ, VVR0r4)
         , BF(CCr5c7, mode=CCr5c7.VVT9mm, VV3Cmf=sDir))
 def VVAUzQ(self, VVR0r4, path):
  if path:
   path = FFxJSp(path.strip())
   if self.VVw70m(VVR0r4, path):
    FFtMfC(VVR0r4, "Already added", 1500)
   else:
    lst = self.VV8Zoi()
    lst.append(path)
    FFCfiF(CFG.iptvHostsDirs, ",".join(lst))
    VVzto2 = self.VVQrbh()
    VVR0r4.VVwzoo(VVzto2, tableRefreshCB=BF(self.VVRMhQ, path))
 def VVRMhQ(self, path, VVR0r4, title, txt, colList):
  self.VVw70m(VVR0r4, path)
 def VVw70m(self, VVR0r4, path):
  for ndx, row in enumerate(VVR0r4.VVtxRM()):
   if row[0].strip() == path.strip():
    VVR0r4.VVwqjr(ndx)
    return True
  return False
 def VV261J(self, VVR0r4, title, txt, colList):
  path = colList[0]
  FFWBJu(self, BF(self.VVY9BG, VVR0r4), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVY9BG(self, VVR0r4):
  row = VVR0r4.VVVPDl()
  path, rem = row[0], row[1]
  VVzto2 = []
  lst = []
  for ndx, row in enumerate(VVR0r4.VVtxRM()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVzto2.append((tPath, tRem))
  if len(VVzto2) > 0:
   FFCfiF(CFG.iptvHostsDirs, ",".join(lst))
   VVR0r4.VVwzoo(VVzto2)
   FFtMfC(VVR0r4, "Deleted", 1500)
  else:
   FFCfiF(CFG.iptvHostsMode, VVrV5t)
   FFCfiF(CFG.iptvHostsDirs, "")
   VVR0r4.cancel()
   FFDxKA(BF(FFtMfC, self, "Changed to Auto-Find", 1500))
 def VVdpUU(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VVaieV, configObj)
         , BF(CCr5c7, mode=CCr5c7.VVT9mm, VV3Cmf=sDir))
 def VVaieV(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVBQKD(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFWBJu(self, self.VVjkVt, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVjkVt(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVWytP()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVMZKm(self):
  VVegP0 = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVegP0.append((txt    , "VVUpQT"   ))
  else        : VVegP0.append((txt    ,       ))
  VVegP0.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Reset %s Settings" % PLUGIN_NAME      , "VVRYHo"   ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Backup %s Settings" % PLUGIN_NAME      , "VVu5lH"  ))
  VVegP0.append(("Restore %s Settings" % PLUGIN_NAME     , "VVgNEB"  ))
  if fileExists(VVAVra + CCAqEA.VV8Gfi):
   VVegP0.append(VVHMBI)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVegP0.append(('%s Checking for Update' % txt1     , txt2     ))
   VVegP0.append(("Reinstall %s" % PLUGIN_NAME      , "VV9sKX"  ))
   VVegP0.append(("Update %s" % PLUGIN_NAME      , "VVAn3A"   ))
  FFJcY1(self, self.VVZt6A, VVegP0=VVegP0, title="Config. Options")
 def VVZt6A(self, item=None):
  if item:
   if   item == "VVUpQT"  : FFWBJu(self, self.VVUpQT , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CCbPmL)
   elif item == "VVRYHo"  : FFWBJu(self, BF(self.VVRYHo, True), "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VVu5lH" : self.VVu5lH()
   elif item == "VVgNEB" : FFG53m(self, self.VVgNEB, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FFCfiF(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FFCfiF(CFG.checkForUpdateAtStartup, False)
   elif item == "VV9sKX" : FFG53m(self, BF(self.VVSQnv, True ), "Checking Server ...")
   elif item == "VVAn3A"  : FFG53m(self, BF(self.VVSQnv, False), "Checking Server ...")
 def VVu5lH(self):
  path = "%sajpanel_settings_%s" % (VVAVra, FFxsfY())
  os.system("grep .%s. %ssettings > %s" % (PLUGIN_NAME, VVMOat, path))
  FFcZi2(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVgNEB(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name  = "ajpanel_settings_"
  files = FF5Sgm("find / %s -iname '%s*' | grep %s" % (FFdsA4(1), name, name))
  if files:
   err = CCr5c7.VVlY6G(files)
   if err:
    FFWBJu(self, BF(self.VVnDsS, title), "No valid settings files found !\n\nLocate Manually ?", title=title)
   else:
    files = sorted(files, key=lambda t: -os.stat(t).st_mtime)
    VVegP0 = []
    for line in files:
     VVegP0.append((line, line))
    FFJcY1(self, BF(self.VVCYBQ, title), title=title, VVegP0=VVegP0, width=1200, yellowBasePath="")
  else:
   FFnHzu(self, "No settings files found !", title=title)
 def VVnDsS(self, title, path=None):
  sDir = "/"
  for path in (VVAVra, "/media/usb/", "/media/hdd/", "/media/"):
   if pathExists(path):
    sDir = path
    break
  self.session.openWithCallback(BF(self.VVCYBQ, title), BF(CCr5c7, patternMode="ajpSet", VV3Cmf=sDir))
 def VVCYBQ(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FF5DO4(path)
    self.VVRYHo()
    for line in lines:
     name, _, val = line.partition("=")
     try:
      confItem = eval(name)
      if confItem is not None:
       if   isinstance(confItem, ConfigInteger)  : val = int(val)
       elif isinstance(confItem, ConfigSelectionNumber): val = int(val)
       elif isinstance(confItem, ConfigYesNo)   : val = { "true": True, "false": False }.get(val.lower())
       if not val is None:
        confItem.setValue(val)
        confItem.save()
     except:
      pass
    self.VVWytP()
    FFaCeZ()
    FFtMfC(self, "Apllied", 1500, isGrn=True)
   else:
    FFlkXm(self, path, title=title)
 def VVUpQT(self):
  newPath = FFxJSp(VVAVra)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVWytP()
 @staticmethod
 def VV5kmb():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVRYHo(self, exit=False):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVWytP()
  if exit:
   self.close()
 def VVWytP(self):
  configfile.save()
  global VVAVra
  VVAVra = CFG.backupPath.getValue()
  FFHzqE()
 def VVSQnv(self, force):
  pre = "Reinstall" if force else "Update"
  title = "%s %s (from server)" % (pre, PLUGIN_NAME)
  curVer, webVer, url, isHigher, err = CCAqEA.VVIIjd()
  if   err    : FFnHzu(self, err, title)
  elif isHigher or force : FFWBJu(self, BF(FFG53m, self, BF(self.VVu9mR, webVer, url, title, force)), "%s v%s and Restart ?" % ("Reinstall" if force else "Upgrade to", webVer), title=title)
  else     : FFcZi2(self, FF6TiS("No update required.", VVUdsq) + "\n\nCurrent Version = v%s\n\nWeb Version = v%s" % (curVer, webVer), title)
 def VVu9mR(self, webVer, url, title, force):
  fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if FFdjjI() == "dpkg" else "ipk")
  path, err = FFHXM5(url + fName, fName, timeout=2)
  if path:
   if force: cmd = FFiwac(VVw4vm, path)
   else : cmd = FFiwac(VVFhZO, path)
   if cmd:
    cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
    FFYyBc(self, cmd, title=title)
   else:
    FFw6dW(self, title=title)
  else:
   FFnHzu(self, err, title=title)
 @staticmethod
 def VVIIjd():
  span = iSearch(r"v*(\d.\d.\d)", VVVsnC, IGNORECASE)
  if span : curVer = span.group(1)
  else : return "", "", "", False, "Incorrect local version format !"
  path = VVAVra + CCAqEA.VV8Gfi
  if fileExists(path):
   span = iSearch(r"(http.+)", FFu1EI(path), IGNORECASE)
   if span : url = FFxJSp(span.group(1))
   else : return curVer, "", "", False, err
  else:
   return curVer, "", "", False, "Update File not found:\n\n%s" % path
  path, err = FFHXM5(url + "version", "ajpanel_tmp.ver", timeout=2)
  if err:
   return curVer, "", url, False, err
  if fileExists(path):
   txt  = FFu1EI(path).strip().replace(" ", "")
   span = iSearch(r"v*(\d.\d.\d)", txt.partition("=")[2], IGNORECASE)
   if span:
    webVer = span.group(1)
    webTup = tuple(map(int, (webVer.split("."))))
    curTup = tuple(map(int, (curVer.split("."))))
    return curVer, webVer, url, True if webTup > curTup else False, ""
   else:
    return curVer, "", url, False, "Incorrect version format (from server) !"
  else:
   return curVer, "", url, False, "Cannot download Version File !"
class CCbPmL(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFAJVu(VVAUOK, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = COLOR_SCHEME_NUM
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFsw8F(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVocIH("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVocIH("\c00888888", i) + sp + "GREY\n"
   txt += self.VVocIH("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVocIH("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVocIH("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVocIH("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVocIH("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVocIH("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVocIH("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVocIH("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVocIH("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVocIH("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVu0DR ,
   "green" : self.VVu0DR ,
   "left" : self.VVITAJ ,
   "right" : self.VVHgAf ,
   "cancel": self.close
  }, -1)
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  self.VVkYrH()
 def VVu0DR(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFWBJu(self, self.VVCF5q, "Change to : %s" % txt, title=self.Title)
 def VVCF5q(self):
  FFCfiF(CFG.mixedColorScheme, self.cursorPos)
  global COLOR_SCHEME_NUM
  COLOR_SCHEME_NUM = self.cursorPos
  self.VV34nM()
  self.close()
 def VVITAJ(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVkYrH()
 def VVHgAf(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVkYrH()
 def VVkYrH(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVocIH(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VV4viU(color):
  if VVBfw8: return "\\" + color
  else    : return ""
 @staticmethod
 def VV34nM():
  global VVPYB5, VVsvZg, VVSGHr, VVnKNv, VVsIVN, VVPN93, VVoRk2, VVEanD, VVUdsq, VVSTv2, VVBfw8, VVpkep, VVOEUI, VVJCMd, VVlagI, VVZ51O
  VVZ51O   = CCbPmL.VVocIH("\c00FFFFFF", COLOR_SCHEME_NUM)
  VVsvZg    = CCbPmL.VVocIH("\c00888888", COLOR_SCHEME_NUM)
  VVPYB5  = CCbPmL.VVocIH("\c005A5A5A", COLOR_SCHEME_NUM)
  VVEanD    = CCbPmL.VVocIH("\c00FF0000", COLOR_SCHEME_NUM)
  VVSGHr   = CCbPmL.VVocIH("\c00FF5000", COLOR_SCHEME_NUM)
  VVnKNv   = CCbPmL.VVocIH("\c00FFBB66", COLOR_SCHEME_NUM)
  VVBfw8   = CCbPmL.VVocIH("\c00FFFF00", COLOR_SCHEME_NUM)
  VVpkep = CCbPmL.VVocIH("\c00FFFFAA", COLOR_SCHEME_NUM)
  VVUdsq   = CCbPmL.VVocIH("\c0000FF00", COLOR_SCHEME_NUM)
  VVSTv2  = CCbPmL.VVocIH("\c00AAFFAA", COLOR_SCHEME_NUM)
  VVoRk2    = CCbPmL.VVocIH("\c000066FF", COLOR_SCHEME_NUM)
  VVOEUI    = CCbPmL.VVocIH("\c0000FFFF", COLOR_SCHEME_NUM)
  VVJCMd  = CCbPmL.VVocIH("\c00AAFFFF", COLOR_SCHEME_NUM)  #
  VVlagI   = CCbPmL.VVocIH("\c00FA55E7", COLOR_SCHEME_NUM)
  VVsIVN    = CCbPmL.VVocIH("\c00FF8F5F", COLOR_SCHEME_NUM)
  VVPN93  = CCbPmL.VVocIH("\c00FFC0C0", COLOR_SCHEME_NUM)
CCbPmL.VV34nM()
class CCfSCG(Screen):
 def __init__(self, session, path, VVMRua):
  self.skin, self.skinParam = FFAJVu(VV95UA, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVf6Kt   = path
  self.VVWMQA   = ""
  self.VVBJaY   = ""
  self.VVMRua    = VVMRua
  self.VV4d6j    = ""
  self.VVLBWc  = ""
  self.VVN0BJ    = False
  self.VVrG67  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VVBhTf  = "enigma2-plugin-extensions-"
  self.VVKJ49  = "enigma2-plugin-systemplugins-"
  self.VVnRv4 = "enigma2-"
  self.VV9CrY  = 0
  self.VVeINJ  = 1
  self.VVGlJt  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVimvy = "DEBIAN"
  else        : self.VVimvy = "CONTROL"
  self.controlPath = self.Path + self.VVimvy
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVMRua:
   self.packageExt  = ".deb"
   self.VVvi08  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVvi08  = "#11001020"
  FFsw8F(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FF154z(self["keyRed"] , "Create")
  FF154z(self["keyGreen"] , "Post Install")
  FF154z(self["keyYellow"], "Installation Path")
  FF154z(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVZLG6  ,
   "green"   : self.VVlVX8 ,
   "yellow"  : self.VVLA6n  ,
   "blue"   : self.VVXkSr  ,
   "cancel"  : self.VVPVx9
  }, -1)
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FFnLuC(self)
  if self.VVvi08:
   FFo6oa(self["myBody"], self.VVvi08)
   FFo6oa(self["myLabel"], self.VVvi08)
  self.VVxN0o(True)
  self.VV3rzz(True)
 def VV3rzz(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVCdc1()
  if isFirstTime:
   if   package.startswith(self.VVBhTf) : self.VVf6Kt = VVZvBa + self.VV4d6j + "/"
   elif package.startswith(self.VVKJ49) : self.VVf6Kt = VVvMcE + self.VV4d6j + "/"
   else            : self.VVf6Kt = self.Path
  if self.VVN0BJ : myColor = VVsIVN
  else    : myColor = VVZ51O
  txt  = ""
  txt += "Source Path\t: %s\n" % FF6TiS(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FF6TiS(self.VVf6Kt, VVBfw8)
  if self.VVBJaY : txt += "Package File\t: %s\n" % FF6TiS(self.VVBJaY, VVsvZg)
  elif errTxt   : txt += "Warning\t: %s\n"  % FF6TiS("Check Control File fields : %s" % errTxt, VVSGHr)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FF6TiS("Restart GUI", VVsIVN)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FF6TiS("Reboot Device", VVsIVN)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FF6TiS("Post Install", VVUdsq), act)
  if not errTxt and VVSGHr in controlInfo:
   txt += "Warning\t: %s\n" % FF6TiS("Errors in control file may affect the result package.", VVSGHr)
  txt += "\nControl File\t: %s\n" % FF6TiS(self.controlFile, VVsvZg)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVlVX8(self):
  if self["keyGreen"].getVisible():
   VVegP0 = []
   VVegP0.append(("No Action"    , "noAction"  ))
   VVegP0.append(("Restart GUI"    , "VVOAUy"  ))
   VVegP0.append(("Reboot Device"   , "rebootDev"  ))
   FFJcY1(self, self.VVHRow, title="Package Installation Option (after completing installation)", VVegP0=VVegP0)
 def VVHRow(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVOAUy"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVxN0o(False)
   self.VV3rzz()
 def VVLA6n(self):
  rootPath = FF6TiS("/%s/" % self.VV4d6j, VVpkep)
  VVegP0 = []
  VVegP0.append(("Current Path"        , "toCurrent"  ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Extension Path"       , "toExtensions" ))
  VVegP0.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVegP0.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFJcY1(self, self.VVhMKw, title="Installation Path", VVegP0=VVegP0)
 def VVhMKw(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VV0Uhf(FFRlhS(self.Path, True))
   elif item == "toExtensions"  : self.VV0Uhf(VVZvBa)
   elif item == "toSystemPlugins" : self.VV0Uhf(VVvMcE)
   elif item == "toRootPath"  : self.VV0Uhf("/")
   elif item == "toRoot"   : self.VV0Uhf("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVpSHt, BF(CCr5c7, mode=CCr5c7.VVT9mm, VV3Cmf=VVAVra))
 def VVpSHt(self, path):
  if len(path) > 0:
   self.VV0Uhf(path)
 def VV0Uhf(self, parent, withPackageName=True):
  if withPackageName : self.VVf6Kt = parent + self.VV4d6j + "/"
  else    : self.VVf6Kt = "/"
  mode = self.VVFRyy()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVGfvL(mode), self.controlFile))
  self.VV3rzz()
 def VVXkSr(self):
  if fileExists(self.controlFile):
   lines = FF5DO4(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFYvs0(self, self.VVQFYs, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFnHzu(self, "Version not found or incorrectly set !")
  else:
   FFlkXm(self, self.controlFile)
 def VVQFYs(self, VVbYOE):
  if VVbYOE:
   version, color = self.VVOEXT(VVbYOE, False)
   if color == VVOEUI:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVbYOE, self.controlFile))
    self.VV3rzz()
   else:
    FFnHzu(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVPVx9(self):
  if self.newControlPath:
   if self.VVN0BJ:
    self.VVnjBd()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FF6TiS(self.newControlPath, VVsvZg)
    txt += FF6TiS("Do you want to keep these files ?", VVBfw8)
    FFWBJu(self, self.close, txt, callBack_No=self.VVnjBd, title="Create Package", VVARnJ=True)
  else:
   self.close()
 def VVnjBd(self):
  os.system(FFNxGN("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVGfvL(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VVLBWc
  if package.startswith(self.VVnRv4):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VVnRv4, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VVeINJ : prefix = self.VVBhTf
  elif mode == self.VVGlJt : prefix = self.VVKJ49
  return (prefix + name).lower()
 def VVFRyy(self):
  if   self.VVf6Kt.startswith(VVZvBa) : return self.VVeINJ
  elif self.VVf6Kt.startswith(VVvMcE) : return self.VVGlJt
  else            : return self.VV9CrY
 def VVxN0o(self, isFirstTime):
  self.VV4d6j   = FFjyTm(self.Path)
  self.VV4d6j   = "_".join(self.VV4d6j.split())
  self.VVLBWc = self.VV4d6j.lower()
  self.VVN0BJ = self.VVLBWc == VVaDqM.lower()
  if self.VVN0BJ and self.VVLBWc.endswith("ajpan"):
   self.VVLBWc += "el"
  if self.VVN0BJ : self.VVWMQA = VVAVra
  else    : self.VVWMQA = CFG.packageOutputPath.getValue()
  self.VVWMQA = FFxJSp(self.VVWMQA)
  if not pathExists(self.controlPath):
   os.system(FFNxGN("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VVFRyy()
  if fileExists(self.controlFile):
   lines = FF5DO4(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VVN0BJ : version, descripton, maintainer = VVVsnC , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VV4d6j , self.VV4d6j
   txt = ""
   txt += "Package: %s\n"  % self.VVGfvL(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VVN0BJ : t = PLUGIN_NAME
  else    : t = self.VV4d6j
  self.VVoBDN(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVoBDN(self.postrmFile, "echo 'Package removed.'\n")
  if self.VVN0BJ : self.VVoBDN(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVVsnC))
  else    : self.VVoBDN(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VV4d6j)
  if isFirstTime and not mode == self.VV9CrY:
   self.postInstAcion = 1
  txt = self.VVyYfb(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFu1EI(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VVyYfb(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  os.system(FFNxGN("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
 def VVoBDN(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VVyYfb(self, action):
  sep  = "echo '%s'\n" % VVtc24
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VVCdc1(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FF5DO4(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FF6TiS(line, VVSGHr)
     elif not line.startswith(" ")    : line = FF6TiS(line, VVSGHr)
     else          : line = FF6TiS(line, VVOEUI)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVOEUI
   else   : color = VVSGHr
   descr = FF6TiS(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVSGHr
     elif line.startswith((" ", "\t")) : color = VVSGHr
     elif line.startswith("#")   : color = VVsvZg
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVOEXT(val, True)
      elif key == "Version"  : version, color = self.VVOEXT(val, False)
      elif key == "Maintainer" : maint  , color = val, VVOEUI
      elif key == "Architecture" : arch  , color = val, VVOEUI
      else:
       color = VVOEUI
      if not key == "OE" and not key.istitle():
       color = VVSGHr
     else:
      color = VVsIVN
     txt += FF6TiS(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVBJaY = self.VVWMQA + packageName
   self.VVrG67 = True
   errTxt = ""
  else:
   self.VVBJaY  = ""
   self.VVrG67 = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVOEXT(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVOEUI
  else          : return val, VVSGHr
 def VVZLG6(self):
  if not self.VVrG67:
   FFnHzu(self, "Please fix Control File errors first.")
   return
  if self.VVMRua: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFRlhS(self.VVf6Kt, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VV4d6j
  symlinkTo  = FFhn59(self.Path)
  dataDir   = self.VVf6Kt.rstrip("/")
  removePorjDir = FFNxGN("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFNxGN("rm -f '%s'" % self.VVBJaY) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFZKBU()
  if self.VVMRua:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FF3XrD("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVN0BJ:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVf6Kt == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVimvy)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVBJaY, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVBJaY
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVBJaY, FFmjg3(result  , VVUdsq))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVf6Kt, FFmjg3(instPath, VVOEUI))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFmjg3(failed, VVSGHr))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFYyBc(self, cmd)
class CCu3Fm():
 VVl7yE  = "666"
 VVGX2e   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.menuInstance   = None
  self.VV4qSS()
 def VV4qSS(self):
  VVegP0 = CCu3Fm.VVo7xX()
  if VVegP0:
   VVV5x7 = ("Create New", self.VVAlqh)
   self.menuInstance = FFJcY1(self.SELF, self.VVydhw, VVegP0=VVegP0, title=self.Title, VVV5x7=VVV5x7, VV4p4D=True, VVXbiY="#22222233", VVVy8H="#22222233")
  else:
   self.VVAlqh()
 def VVydhw(self, item):
  if item:
   bName, bRef, ndx = item
   self.VVBtv4(bName, bRef)
  else:
   CCu3Fm.VV7A3f(self)
 def VVAlqh(self, VVsxjbObj=None, item=None):
  FFYvs0(self.SELF, BF(self.VVvY5p), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVvY5p(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.menuInstance:
     self.menuInstance.cancel()
    self.VVBtv4(bName, "")
   else:
    FFtMfC(self.menuInstance, "Incorrect Bouquet Name !", 2000)
    CCu3Fm.VV7A3f(self)
 def VVBtv4(self, bName, bRef):
  FFG53m(self.waitMsgSELF, BF(self.VV4dSZ, bName, bRef), title="Adding Services ...")
 def VV4dSZ(self, bName, bRef):
  CCu3Fm.VVCuKe(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VV7A3f(classObj):
  del classObj
 @staticmethod
 def VVCuKe(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FFnHzu(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVMOat + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFlkXm(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CCu3Fm.VVyYIw(bRef)
   bPath = VVMOat + bFile
  else:
   fName = CCCu2Z.VV8ga2(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVMOat + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVMOat + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  CCu3Fm.VV9EsP(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   CCu3Fm.VV9EsP(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CC96Ar.VVwdi5()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       os.system(FFNxGN("cp -f '%s' '%s'" % (poster, picon)))
       os.system(CC6biu.VVfDUr(picon))
       break
  FFmB3r()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FFJRXg(SELF, txt, title=title)
 @staticmethod
 def VVo7xX(mode=2, showTitle=True, prefix=""):
  VVegP0 = []
  if mode in (0, 2): VVegP0.extend(CCu3Fm.VVCUeP(0, showTitle, prefix))
  if mode in (1, 2): VVegP0.extend(CCu3Fm.VVCUeP(1, showTitle, prefix))
  return VVegP0
 @staticmethod
 def VVCUeP(mode, showTitle, prefix):
  VVegP0 = []
  lst = CCu3Fm.VVi6on(mode)
  if lst:
   if showTitle:
    VVegP0.append(FFQJnR("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVegP0.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVegP0.append((item[0], item[1].toString()))
  return VVegP0
 @staticmethod
 def VVfpE8():
  bLise = CCu3Fm.VVi6on(0)
  bLise.extend(CCu3Fm.VVi6on(1))
  return bLise
 @staticmethod
 def VVi6on(mode=0):
  bList = []
  VVcxBI = InfoBar.instance
  VVHQTD = VVcxBI and VVcxBI.servicelist
  if VVHQTD:
   curMode = VVHQTD.mode
   CCu3Fm.VVLE1M(VVHQTD, mode)
   bList.extend(VVHQTD.getBouquetList() or [])
   CCu3Fm.VVLE1M(VVHQTD, curMode)
  return bList
 @staticmethod
 def VVLE1M(VVHQTD, mode):
  if not mode == VVHQTD.mode:
   if   mode == 0: VVHQTD.setModeTv()
   elif mode == 1: VVHQTD.setModeRadio()
 @staticmethod
 def VV9EsP(fPath):
  with open(fPath, "rb+") as f:
   try:
    f.seek(-1, 2)
    if ord(f.read(1)) not in (10, 13):
     f.write(b"\n")
   except:
    pass
 @staticmethod
 def VVyYIw(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : ""
 @staticmethod
 def VVwd5l():
  try:
   fName = CCu3Fm.VVyYIw(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVMOat, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VVKht1():
  path = CCu3Fm.VVwd5l()
  if path:
   txt = FFu1EI(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VVQwOu():
  return FFXd2v(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VVf1LL():
  lst = []
  for b in CCu3Fm.VVfpE8():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVMOat + CCu3Fm.VVyYIw(bRef)
   if fileExists(path):
    lines = FF5DO4(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VVEF7a(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VVSBzQ(SID="", stripRType=False):
  if SID : patt = CCu3Fm.VVEF7a(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CCu3Fm.VVfpE8():
   for service in FFXd2v(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVanvk():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CCu3Fm.VVfpE8():
   for service in FFXd2v(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVvdTT(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VVw7o5(pathLst):
  refLst = CCu3Fm.VVSBzQ(CCu3Fm.VVl7yE, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CCu3Fm.VVvdTT(rType, CCu3Fm.VVl7yE, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CCr5c7(Screen):
 VVyS6s   = 0
 VViEDa  = 1
 VVT9mm  = 2
 VVyWWJ = 3
 VVDKIH    = 20
 VV84kR  = None
 VVjXla   = 0
 VVv5OO   = 1
 VVoNBE   = 2
 def __init__(self, session, VV3Cmf="/", mode=VVyS6s, VVx0dP="Select", height=920, VVwwGj=30, gotoMovie=False, jumpToFile="", patternMode=""):
  self.VVXbiY = "#22001111"
  self.VVVy8H  = "#22000000"
  self.skin, self.skinParam = FFAJVu(VVtBbU, 1400, height, 30, 40, 20, self.VVXbiY, self.VVVy8H, 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFsw8F(self)
  FF154z(self["keyRed"] , "Exit")
  FF154z(self["keyYellow"], "More Options")
  FF154z(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVx0dP = VVx0dP
  self.jumpToFile   = jumpToFile
  self.patternMode  = patternMode
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = "#06003333"
  self.multiSelectState = False
  CCr5c7.VV84kR = self
  VVXziI = None
  if patternMode:
   self.mode = self.VVyWWJ
   if   patternMode == "srt"   : VVXziI = ("^.*\.srt$"    , IGNORECASE)
   elif patternMode == "ajpSet": VVXziI = ("^.*\/ajpanel_settings_" , 0    )
   elif patternMode == "poster": VVXziI = ("^.*\.(jpg|png)$"    , IGNORECASE)
   elif patternMode == "movies": VVXziI = ("^.*\.(%s)$" % "|".join(CCAnG2.VVXWgC()["mov"]), IGNORECASE)
   else      : VVXziI = None
  if self.mode in (self.VVT9mm, self.VVyWWJ):
   FF154z(self["keyRed"], "Cancel")
  if   self.jumpToFile       : VVolId, self.VV3Cmf = True , FFRlhS(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VVolId, self.VV3Cmf = True , CCr5c7.VVt1SH(self)[1] or "/"
  elif self.mode == self.VVyS6s  : VVolId, self.VV3Cmf = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVT9mm : VVolId, self.VV3Cmf = False, VV3Cmf
  elif self.mode == self.VVyWWJ : VVolId, self.VV3Cmf = True , VV3Cmf
  else           : VVolId, self.VV3Cmf = True , VV3Cmf
  self.VV3Cmf = FFxJSp(self.VV3Cmf)
  self["myMenu"] = CCAnG2(  directory   = None
         , VVXziI = VVXziI
         , VVolId   = VVolId
         , VV8HdX = True
         , VVLqGp = True
         , VVRFau   = self.skinParam["width"]
         , VVwwGj   = self.skinParam["bodyFontSize"]
         , VVLEkl  = self.skinParam["bodyLineH"] )
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVu0DR    ,
   "red" : self.VV6ZOE   ,
   "green" : self.VVMf0T,
   "yellow": self.VVyA7z  ,
   "blue" : self.VVVJS6 ,
   "menu" : self.VVTtp7  ,
   "info" : self.VVnEnh  ,
   "cancel": self.VVIcAf    ,
   "pageUp": self.VVQzJt   ,
   "chanUp": self.VVQzJt
  }, -1)
  FF0zxL(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVPP8U)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  CCr5c7.VV84kR = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVPP8U)
  FF6aqB(self)
  FFCoOh(self["myMenu"], bg=self.cursorBG)
  FFnLuC(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVT9mm, self.VVyWWJ):
   FF154z(self["keyGreen"], self.VVx0dP)
   self.VV5HtB(self.VVv5OO)
  self.VVPP8U()
  if self.VVBRQ8(self.VV3Cmf) > self.bigDirSize: FFG53m(self, self.VV6tlX, title="Changing directory...")
  else              : self.VV6tlX()
 def VV6tlX(self):
  if self.jumpToFile : self.VVGIlA(self.jumpToFile)
  elif self.gotoMovie : self.VVM9l3(chDir=False)
  else    : self["myMenu"].VVrDTR(self.VV3Cmf)
 def VVwqjr(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVetkj(self):
  FFG53m(self, self.VVBtdo, title="Refreshing list ...")
 def VVBtdo(self):
  isSel = self["myMenu"].VVH1Ch()
  if not isSel:
   self.VVAYmK(False)
  FFrn02()
 def VVBRQ8(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VVu0DR(self):
  if self.multiSelectState:
   ok = self["myMenu"].VVHnFM()
   if ok : self["keyBlue"].setText(self.VVtW1X())
   else : FFtMfC(self, "Cannot select item", 500)
  elif self["myMenu"].VV3zEI(): self.VVhDH3()
  else       : self.VVEAY5()
 def VVQzJt(self):
  if self.multiSelectState:
   FFtMfC(self, "Disable Multi-Select first", 1000)
  else:
   self["myMenu"].moveToIndex(0)
   if self["myMenu"].VVFHrM():
    self.VVhDH3()
 def VVhDH3(self, isDirUp=False):
  if self["myMenu"].VV3zEI():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVwZjb(self.VVsxjb())
   if self.VVBRQ8(path) > self.bigDirSize : FFG53m(self, self.VVebHr, title="Changing directory...")
   else           : self.VVebHr()
 def VVebHr(self):
  self["myMenu"].descent()
  self.VVPP8U()
 def VVIcAf(self):
  if   self.multiSelectState     : self.VVAYmK(False, True)
  elif CFG.FileManagerExit.getValue() == "e" : self.VV6ZOE()
  else          : self.VVQzJt()
 def VV6ZOE(self):
  if not FFfrnp(self):
   self.close("")
 def VVMf0T(self):
  path = self.VVwZjb(self.VVsxjb())
  if self.mode == self.VVT9mm:
   self.close(path)
  elif self.mode == self.VVyWWJ:
   if os.path.isfile(path) : self.close(path)
   else     : FFtMfC(self, "Cannot access this file", 1000)
 def VVnEnh(self):
  FFG53m(self, self.VVUy1T, title="Calculating size ...")
 def VVUy1T(self):
  path = self.VVwZjb(self.VVsxjb())
  param = self.VVbanT(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFN7zW("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCr5c7.VVHFaI(path)
     freeSize = CCr5c7.VVPnvT(path)
     size = totSize - freeSize
     totSize  = CCr5c7.VVJv7c(totSize)
     freeSize = CCr5c7.VVJv7c(freeSize)
    else:
     size = FFWXwG(path)
   usedSize = CCr5c7.VVJv7c(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FF6TiS(pathTxt, VVsIVN) + "\n"
   if slBroken : fileTime = self.VVGj9z(path)
   else  : fileTime = self.VVU3C3(path)
   def VVCvCu(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVCvCu("Path"    , pathTxt)
   txt += VVCvCu("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVCvCu("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVCvCu("Total Size"   , "%s" % totSize)
    txt += VVCvCu("Used Size"   , "%s" % usedSize)
    txt += VVCvCu("Free Size"   , "%s" % freeSize)
   else:
    txt += VVCvCu("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVCvCu("Owner"    , owner)
   txt += VVCvCu("Group"    , group)
   txt += VVCvCu("Perm. (User)"  , permUser)
   txt += VVCvCu("Perm. (Group)"  , permGroup)
   txt += VVCvCu("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVCvCu("Perm. (Ext.)" , permExtra)
   txt += VVCvCu("iNode"    , iNode)
   txt += VVCvCu("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVtc24, VVtc24)
    txt += hLinkedFiles
   txt += self.VVNXuk(path)
  else:
   FFnHzu(self, "Cannot access information !")
  if len(txt) > 0:
   FFJRXg(self, txt)
 def VVbanT(self, path):
  path = path.strip()
  path = FFhn59(path)
  result = FFN7zW("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VV4J6l(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VV4J6l(perm, 1, 4)
   permGroup = VV4J6l(perm, 4, 7)
   permOther = VV4J6l(perm, 7, 10)
   permExtra = VV4J6l(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FF5whR("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVNXuk(self, path):
  txt  = ""
  res  = FFN7zW("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FF6TiS("File Attributes:", VVlagI), txt)
  return txt
 def VVU3C3(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFrOxn(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFrOxn(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFrOxn(os.path.getctime(path))
  return txt
 def VVGj9z(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFN7zW("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFN7zW("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFN7zW("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVwZjb(self, currentSel):
  currentDir  = self["myMenu"].VVsWoI()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VV3zEI():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVsxjb(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VVPP8U(self):
  path = self.VVwZjb(self.VVsxjb())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVKhAP()
  if self.mode == self.VVyS6s:
   if len(path) > 0: self["keyMenu"].show()
   else   : self["keyMenu"].hide()
  if self.mode == self.VVyWWJ:
   path = self.VVwZjb(self.VVsxjb())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVTtp7(self):
  color1 = VVPN93
  color2 = VVpkep
  color3 = VVJCMd
  totSel = 0
  menuW = 1000
  title = "Options"
  VVegP0= []
  if self.multiSelectState:
   menuW = 850
   totSel = self["myMenu"].VVSvKs()
   if totSel > 0:
    if iTar:
     txt1 = "Archive to .tar.gz"
     txt2 = " (Preserve Path Structure)"
     title = "Options  (%d item%s)" % (totSel, FFJHIK(totSel))
     VVegP0.append((color1 + txt1     , "VVGLAZ1" ))
     VVegP0.append((color1 + txt1 + txt2   , "VVGLAZ2" ))
     VVegP0.append(VVHMBI)
    VVegP0.append(("[6] Copy"       , "copyBulk" ))
    VVegP0.append(("[7] Move"       , "moveBulk" ))
    VVegP0.append(("[8] %sDELETE" % VVsIVN , "VV8GB3" ))
   else:
    FFtMfC(self, "Nothing selected", 700)
    return
  elif self.mode in (self.VVT9mm, self.VVyWWJ):
   VVegP0.append(("Properties"           , "properties" ))
   VVegP0.append(VVHMBI)
   VVegP0.append((color3 + "Create New Directory (in current directory)" , "createNewDir"))
  else:
   menuW = 1000
   path  = self.VVwZjb(self.VVsxjb())
   isEditable = self["myMenu"].VVdpPD()
   VVegP0.append(("Properties", "properties"))
   if os.path.isdir(path):
    if isEditable:
     VVegP0.append(VVHMBI)
     VVegP0.append((color1 + "Archiving / Packaging", "VVxvUh_dir"))
   elif os.path.isfile(path):
    selFile = self.VVsxjb()
    isArch = selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar"))
    if not isArch:
     VVegP0.append((color1 + "Archive ...", "VVxvUh_file"))
    isText = False
    txt = ""
    if   isArch            : VVegP0.extend(self.VVuh6O(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith(".m3u")       : VVegP0.extend(self.VV2gbL(True))
    elif selFile.endswith(".sh"):
     VVegP0.extend(self.VVBE6s(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CCr5c7.VVy14F(path):
     VVegP0.append(VVHMBI)
     VVegP0.append((color2 + "View"     , "textView_def"))
     VVegP0.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVegP0.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVsQQU(path) == "pic":
     VVegP0.append(VVHMBI)
     VVegP0.append((color2 + "Set as PIcon for current channel" , "VVvMV2" ))
     if FF63FC("ffmpeg") and selFile.lower().endswith((".jpg", ".png")):
      VVegP0.append(VVHMBI)
      VVegP0.append((color2 + "Convert to MVI (1280 x 720 )" , "VVCVijHd"   ))
      VVegP0.append((color2 + "Convert to MVI (1920 x 1080)" , "VVCVijFhd"   ))
    elif selFile.endswith(CCr5c7.VV5goT()):
     if selFile.endswith(".mvi"):
      if FF63FC("showiframe"):
       VVegP0.append(VVHMBI)
       VVegP0.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVegP0.append(VVHMBI)
      VVegP0.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVegP0.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
      VVegP0.append((color2 + "Play with ..."       , "playWith"    ))
    if isText:
     VVegP0.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVegP0.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVegP0.append((color1 + "Convert Line-Breaks to Unix Format..." , "VVAUDi" ))
    if len(txt) > 0:
     VVegP0.append(VVHMBI)
     VVegP0.append((color1 + txt, "VVEAY5"))
   VVegP0.append(VVHMBI)
   VVegP0.append(("[4] Create SymLink", "VV7m61"))
   if isEditable:
    VVegP0.append(("[5] Rename"      , "VV7xaS" ))
    VVegP0.append(("[6] Copy"       , "copyFileOrDir" ))
    VVegP0.append(("[7] Move"       , "moveFileOrDir" ))
    VVegP0.append(("[8] %sDELETE" % VVsIVN , "VVXqQn" ))
    if fileExists(path):
     VVegP0.append(VVHMBI)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVegP0.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVegP0.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVegP0.append((chmodTxt + "777)", "chmod777"))
   VVegP0.append(VVHMBI)
   VVegP0.append((color3 + "Create New File (in current directory)"  , "createNewFile" ))
   VVegP0.append((color3 + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCr5c7.VVt1SH(self)
   if fPath:
    VVegP0.append(VVHMBI)
    VVegP0.append((color2 + "Go to Current Movie Dir", "VVM9l3"))
  FFJcY1(self, self.VVjh3y, width=menuW, height=1050, title=title, VVegP0=VVegP0, rcuSearch=False, VVXbiY="#00101020", VVVy8H="#00101A2A")
 def VVjh3y(self, item=None):
  if item is not None:
   path = self.VVwZjb(self.VVsxjb())
   selFile = self.VVsxjb()
   if   item == "VVGLAZ1"    : self.VVGLAZ(False)
   if   item == "VVGLAZ2"    : self.VVGLAZ(True)
   elif item == "copyBulk"     : self.VVMcLk(False)
   elif item == "moveBulk"     : self.VVMcLk(True)
   elif item == "VV8GB3"    : self.VV8GB3()
   elif item == "properties"    : self.VVnEnh()
   elif item == "VVxvUh_dir" : self.VVxvUh(path, True)
   elif item == "VVxvUh_file" : self.VVxvUh(path, False)
   elif item == "VVMY2j"  : self.VVMY2j(path)
   elif item == "VVgw5s"  : self.VVgw5s(path)
   elif item.startswith("extract_")  : self.VVqDZS(path, selFile, item)
   elif item.startswith("script_")   : self.VVxoCK(path, selFile, item)
   elif item.startswith("m3u_")   : self.VVINC5(path, selFile, item)
   elif item.startswith("textView_def") : FF1QId(self, path)
   elif item.startswith("textView_enc") : self.VVceR9(path)
   elif item.startswith("text_Edit")  : FFG53m(self, BF(CCzWmm, self, path), title="Opening File ...")
   elif item.startswith("textSave_encUtf8"): self.VVKsP1(path, "Save as UTF-8"   , True)
   elif item.startswith("textSave_encOthr"): self.VVKsP1(path, "Save as Other Encoding", False)
   elif item.startswith("VVAUDi") : self.VVAUDi(path)
   elif item == "viewAsBootlogo"   : self.VVGj0P(path, True)
   elif item == "addMovieToBouquet"  : self.VVFPj4(path, False)
   elif item == "addAllMoviesToBouquet" : self.VVFPj4(path, True)
   elif item == "playWith"     : self.VV24oI(path)
   elif item == "VVvMV2" : self.VVvMV2(path)
   elif item == "VVCVijHd"   : FFG53m(self, BF(self.VVCVij, path, False))
   elif item == "VVCVijFhd"   : FFG53m(self, BF(self.VVCVij, path, True))
   elif item == "VV7m61"   : self.VV7m61(path, selFile)
   elif item == "VV7xaS"   : self.VV7xaS(path, selFile)
   elif item == "copyFileOrDir"   : self.VVLcQZ(path, False)
   elif item == "moveFileOrDir"   : self.VVLcQZ(path, True)
   elif item == "VVXqQn"   : self.VVXqQn(path, selFile)
   elif item == "chmod644"     : self.VVzvQs(path, selFile, "644")
   elif item == "chmod755"     : self.VVzvQs(path, selFile, "755")
   elif item == "chmod777"     : self.VVzvQs(path, selFile, "777")
   elif item == "createNewFile"   : self.VVC1Gg(path, True)
   elif item == "createNewDir"    : self.VVC1Gg(path, False)
   elif item == "VVM9l3"   : self.VVM9l3()
   elif item == "VVEAY5"    : self.VVEAY5()
 def VVEAY5(self):
  if self.mode == self.VVyWWJ and not self.patternMode == "poster":
   return
  selFile = self.VVsxjb()
  path  = self.VVwZjb(selFile)
  if os.path.isfile(path):
   VVb1hE  = []
   category = self["myMenu"].VVsQQU(path)
   if   category == "pic"      : self.VVo50e(path)
   elif category == "txt"      : FF1QId(self, path)
   elif category in ("tar", "zip", "rar")  : self.VV1ZRm(path, selFile)
   elif category == "scr"      : self.VVKKZ1(path, selFile)
   elif category == "m3u"      : self.VVFfSB(path, selFile)
   elif category in ("ipk", "deb")    : self.VVKrJH(path, selFile)
   elif category in ("mov", "mus")    : self.VVGj0P(path)
   elif not CCr5c7.VVy14F(path) : FF1QId(self, path)
 def VVo50e(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VVsQQU(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CCDdSC.VVvctb(self, path, fileList=lst, curIndex=curIndex, cbFnc=self.VVj2Pu)
 def VVj2Pu(self, path):
  self.VVGIlA(path)
 def VVGj0P(self, path, asLogo=False):
  if asLogo : CC5wI4.VVULDq(self, path)
  else  : FFG53m(self, BF(self.VVU4yQ, self, path), title="Playing Media ...")
 def VVVJS6(self):
  if self["keyBlue"].getVisible():
   VVVC4T = self.VVVPAB()
   if VVVC4T:
    path = self.VVwZjb(self.VVsxjb())
    enableGreenBtn = False if path in self.VVVPAB() else True
    newList = []
    for line in VVVC4T:
     newList.append((line, line))
    VVKP6N  = ("Delete"    , self.VVEU0d    )
    VVzqGT  = ("Add Current Dir"   , BF(self.VVZdDT, path) ) if enableGreenBtn else None
    VVV5x7 = ("Move Up"     , self.VV5ULS    )
    VVZKXi  = ("Move Down"   , self.VV3unU    )
    self.bookmarkMenu = FFJcY1(self, self.VVBSgI, width=1200, title="Bookmarks", VVegP0=newList, minRows=10 ,VVKP6N=VVKP6N, VVzqGT=VVzqGT, VVV5x7=VVV5x7, VVZKXi=VVZKXi, VVXbiY="#00000022", VVVy8H="#00000022")
 def VVEU0d(self, menuInstance=None, path=None):
  VVVC4T = self.VVVPAB()
  if VVVC4T:
   while path in VVVC4T:
    VVVC4T.remove(path)
   self.VVp79V(VVVC4T)
  if self.bookmarkMenu:
   self.bookmarkMenu.VVjgJn(VVVC4T)
   self.bookmarkMenu.VVXwu9(("Add Current Dir", BF(self.VVZdDT, path)))
  else:
   FFtMfC(self, "Removed", 800)
  self.VVKhAP()
 def VVZdDT(self, path, menuInstance=None, item=None):
  VVVC4T = self.VVVPAB()
  if len(VVVC4T) >= self.VVDKIH:
   FFnHzu(SELF, "Max bookmarks reached (max=%d)." % self.VVDKIH)
  elif not path in VVVC4T:
   newList = [path] + VVVC4T
   self.VVp79V(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VVjgJn(newList)
    self.bookmarkMenu.VVXwu9()
   else:
    FFtMfC(self, "Added", 800)
  self.VVKhAP()
 def VV5ULS(self, VVsxjbObj, path):
  if self.bookmarkMenu:
   VVVC4T = self.bookmarkMenu.VVW5VR(True)
   if VVVC4T:
    self.VVp79V(VVVC4T)
 def VV3unU(self, VVsxjbObj, path):
  if self.bookmarkMenu:
   VVVC4T = self.bookmarkMenu.VVW5VR(False)
   if VVVC4T:
    self.VVp79V(VVVC4T)
 def VVBSgI(self, folder=None):
  if folder:
   folder = FFxJSp(folder)
   self["myMenu"].VVrDTR(folder)
   self["myMenu"].moveToIndex(0)
  self.VVPP8U()
 def VVVPAB(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VVeds7(self):
  return True if VVVPAB() else False
 def VVp79V(self, VVVC4T):
  line = ",".join(VVVC4T)
  FFCfiF(CFG.browserBookmarks, line)
 def VVGIlA(self, path):
  if fileExists(path):
   fDir  = FFxJSp(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVrDTR(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFtMfC(self, "Not found", 1000)
 def VVM9l3(self, chDir=True):
  fPath, fDir, fName = CCr5c7.VVt1SH(self)
  self.VVGIlA(fPath)
 def VVyA7z(self):
  path = self.VVwZjb(self.VVsxjb())
  isAdd = False if path in self.VVVPAB() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  c1, c2 , c3 = VVOEUI, VVSTv2, VVpkep
  VVegP0 = []
  VVegP0.append(("Find Files ..." , "find"))
  VVegP0.append(("Sort ..."   , "sort"))
  VVegP0.append(VVHMBI)
  if isAdd: VVegP0.append((c1 + "Add %s Dir to Bookmarks"  % dirTxt, "addBM"))
  else : VVegP0.append((c1 + "Remove %s Dir from Bookmarks" % dirTxt, "remBM"))
  VVegP0.append(VVHMBI)
  VVegP0.append(    (c2 + 'Set %s Dir as "Startup Dir"' % dirTxt, "start"))
  if self.mode == self.VVyS6s:
   VVegP0.append(VVHMBI)
   if self.multiSelectState: VVegP0.append( (c3 + "Disable Multi-Select ", "multiOff"))
   else     : VVegP0.append( (c3 + "Enable Multi-Select"  , "multiOn" ))
   VVegP0.append(       (c3 + "Select all"    , "selAll"  ))
  FFJcY1(self, BF(self.VVCxEg, path), width=750, title="More Options", VVegP0=VVegP0, VVXbiY="#00221111", VVVy8H="#00221111")
 def VVCxEg(self, path, item):
  if item:
   if   item == "find"  : self.VV9l5x(path)
   elif item == "sort"  : self.VVRzCD()
   elif item == "addBM" : self.VVZdDT(path)
   elif item == "remBM" : self.VVEU0d(None, path)
   elif item == "start" : self.VV7uU1(path)
   elif item == "multiOn" : self.VVAYmK(True)
   elif item == "multiOff" : self.VVAYmK(False)
   elif item == "selAll" : self.VVAYmK(True, True)
 def VVAYmK(self, isOn, isAll=False):
  self.multiSelectState = isOn
  if isAll or not isOn:
   FFG53m(self, BF(self["myMenu"].VV5JkW, isOn), title="Selecting ..." if isOn else "Unselecting ...")
  self.VV5HtB(self.VVoNBE if isOn else self.VVjXla)
 def VV5HtB(self, mode=0):
  if   mode == self.VVv5OO : titBg, bodBg = "#22220000", "#22000022"
  elif mode == self.VVoNBE: titBg, bodBg = "#01883366", "#11220000"
  else        : titBg, bodBg = self.VVXbiY, self.VVVy8H
  FFo6oa(self["myTitle"], titBg)
  FFo6oa(self["myBar"], titBg)
  FFo6oa(self["myBody"], bodBg)
  FFo6oa(self["myMenu"], bodBg)
  if self.multiSelectState: bg, txt = "#01883366", self.VVtW1X()
  else     : bg, txt = BAR_BUTTONS_COLORS[3], "Bookmarks"
  FF154z(self["keyBlue"], txt)
  FFo6oa(self["keyBlue"], bg)
  self.VVKhAP()
 def VVtW1X(self):
  return "Selected Items = %d" % self["myMenu"].VVSvKs()
 def VVKhAP(self):
  if self.VVVPAB() or self.multiSelectState: self["keyBlue"].show()
  else            : self["keyBlue"].hide()
 def VV9l5x(self, path):
  VVegP0 = []
  VVegP0.append(("Find in Current Directory"    , "findCur"  ))
  VVegP0.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVegP0.append(("Find in all Storage Systems"    , "findAll"  ))
  FFJcY1(self, BF(self.VVZcCt, path), width=700, title="Find File/Pattern", VVegP0=VVegP0, VV4p4D=True, VVk6EI=True, VVXbiY="#00221111", VVVy8H="#00221111")
 def VVZcCt(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VVuOK9(0, path, title)
   elif item == "findCurR" : self.VVuOK9(1, path, title)
   elif item == "findAll" : self.VVuOK9(2, path, title)
 def VVuOK9(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FFYvs0(self, BF(self.VVuYDc, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVuYDc(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FFCfiF(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FFtMfC(self, "No entery", 1500)
   elif badLst  : FFtMfC(self, "Too many file !", 1500)
   else   : FFG53m(self, BF(self.VVZqod, mode, path, title, filePatt), title="Searching ...", clearMsg=False)
 def VVZqod(self, mode, path, title, filePatt):
  FFtMfC(self)
  lst = FF5Sgm(FFBAbA("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   err = CCr5c7.VVlY6G(lst)
   if err:
    FFnHzu(self, err)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VVBSYf = (""     , self.VVeRzg , [])
    VVdn6T = ("Go to File Location", self.VVzlzp  , [])
    FFqiz1(self, None, title="%s : %s" % (title, filePatt), header=header, VVVC4T=lst, VVx2iV=widths, VVwwGj=26, VVBSYf=VVBSYf, VVdn6T=VVdn6T)
  else:
   FFtMfC(self, "Not found !", 2000)
 def VVzlzp(self, VVR0r4, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVR0r4.cancel()
   self.VVGIlA(path)
  else:
   FFtMfC(VVR0r4, "Path not found !", 1000)
 def VVeRzg(self, VVR0r4, title, txt, colList):
  txt = "%s\n%s\n\n" % (FF6TiS("File:"  , VVpkep), colList[0])
  txt += "%s\n%s"  % (FF6TiS("Directory:", VVpkep), FFxJSp(colList[1]))
  FFJRXg(VVR0r4, txt, title=title)
 def VVRzCD(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVT4Lm()
  VVegP0 = []
  VVegP0.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVegP0.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVegP0.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVegP0.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVZKXi = ("Mix", BF(self.VVeA5X, True))
  FFJcY1(self, BF(self.VVK4s2, False), barText=txt, width=650, title="Sort Options", VVegP0=VVegP0, VVZKXi=VVZKXi, VVk6EI=True, VVXbiY="#00221111", VVVy8H="#00221111")
 def VVeA5X(self, isMix, menuInstance, item):
  self.VVK4s2(True, item)
 def VVK4s2(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVT4Lm()
   title = "Sorting ... "
   if   item == "nameAlp": FFG53m(self, BF(self["myMenu"].VVy41P, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FFG53m(self, BF(self["myMenu"].VVy41P, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FFG53m(self, BF(self["myMenu"].VVy41P, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FFG53m(self, BF(self["myMenu"].VVy41P, typeMode , isMix, False), title=title)
 def VV7uU1(self, path):
  if not os.path.isdir(path):
   path = FFRlhS(path, True)
  FFCfiF(CFG.browserStartPath, path)
  FFtMfC(self, "Done", 500)
 def VVGEAo(self, selFile, VVFNjG, command):
  FFWBJu(self, BF(FFYyBc, self, command, VVhgup=self.VVetkj), "%s\n\n%s" % (VVFNjG, selFile))
 def VVuh6O(self, path, calledFromMenu):
  destPath = self.VV4mJa(path)
  lastPart = FFjyTm(destPath)
  VVegP0 = []
  if calledFromMenu:
   VVegP0.append(VVHMBI)
   color = VVpkep
  else:
   color = ""
  VVegP0.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVegP0.append(VVHMBI)
  VVegP0.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVegP0.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVegP0.append((color + "Extract Here"            , "extract_here"  ))
  if iTar and iZip:
   if path.endswith(".zip"):
    if not calledFromMenu: VVegP0.append(VVHMBI)
    VVegP0.append((color + "Convert .zip to .tar.gz"       , "VVMY2j" ))
   elif path.endswith(".tar.gz"):
    if not calledFromMenu: VVegP0.append(VVHMBI)
    VVegP0.append((color + "Convert .tar.gz to .zip"       , "VVgw5s" ))
  return VVegP0
 def VV1ZRm(self, path, selFile):
  FFJcY1(self, BF(self.VVqDZS, path, selFile), title="Compressed File Options", VVegP0=self.VVuh6O(path, False))
 def VVqDZS(self, path, selFile, item=None):
  if item is not None:
   parent  = FFRlhS(path, False)
   destPath = self.VV4mJa(path)
   lastPart = FFjyTm(destPath)
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVtc24
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FF3XrD("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FF3XrD("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVtc24, VVtc24)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFlo7E(self, cmd)
   elif path.endswith(".zip"):
    if item == "VVMY2j" : self.VVMY2j(path)
    else       : self.VVYPKX(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "VVgw5s" and path.endswith(".tar.gz"):
    self.VVgw5s(path)
   elif path.endswith(".rar"):
    self.VV2weI(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFNxGN("mkdir '%s'"   % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVGEAo(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVGEAo(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FFRlhS(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVGEAo(selFile, "Extract Here ?"      , cmd)
 def VV4mJa(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVYPKX(self, item, path, parent, destPath, VVFNjG):
  FFWBJu(self, BF(self.VV3DTG, item, path, parent, destPath), VVFNjG)
 def VV3DTG(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVtc24
  cmd  = FF3XrD("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFmjg3(destPath, VVUdsq))
  cmd +=   sep
  cmd += "fi;"
  FFvkVo(self, cmd, VVhgup=self.VVetkj)
 def VV2weI(self, item, path, parent, destPath, VVFNjG):
  FFWBJu(self, BF(self.VVWgw7, item, path, parent, destPath), VVFNjG)
 def VVWgw7(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FFxJSp(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVtc24
  cmd  = FF3XrD("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFmjg3(destPath, VVUdsq))
  cmd +=   sep
  cmd += "fi;"
  FFvkVo(self, cmd, VVhgup=self.VVetkj)
 def VVBE6s(self, addSep=False):
  VVegP0 = []
  if addSep:
   VVegP0.append(VVHMBI)
  VVegP0.append((VVpkep + "View Script File"  , "script_View"  ))
  VVegP0.append((VVpkep + "Execute Script File" , "script_Execute" ))
  VVegP0.append((VVpkep + "Edit"     , "script_Edit" ))
  return VVegP0
 def VVKKZ1(self, path, selFile):
  FFJcY1(self, BF(self.VVxoCK, path, selFile), title="Script File Options", VVegP0=self.VVBE6s())
 def VVxoCK(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FF1QId(self, path)
   elif item == "script_Execute" : self.VVGEAo(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCzWmm(self, path)
 def VV2gbL(self, addSep=False):
  VVegP0 = []
  if addSep:
   VVegP0.append(VVHMBI)
  VVegP0.append((VVpkep + "Browse IPTV Channels"  , "m3u_Browse" ))
  VVegP0.append((VVpkep + "Edit"      , "m3u_Edit" ))
  VVegP0.append((VVpkep + "View"      , "m3u_View" ))
  return VVegP0
 def VVFfSB(self, path, selFile):
  FFJcY1(self, BF(self.VVINC5, path, selFile), title="M3U/M3U8 File Options", VVegP0=self.VV2gbL())
 def VVINC5(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFG53m(self, BF(self.session.open, CCCu2Z, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCzWmm(self, path)
   elif item == "m3u_View"  : FF1QId(self, path)
 def VVceR9(self, path):
  if fileExists(path) : FFG53m(self, BF(CCBlwj.VVy65L, self, path, BF(self.VVn1ri, path)), title="Loading Codecs ...", clearMsg=False)
  else    : FFlkXm(self, path)
 def VVn1ri(self, path, item=None):
  if item:
   FF1QId(self, path, encLst=item)
 def VVKsP1(self, path, title, asUtf8):
  if fileExists(path) : FFG53m(self, BF(CCBlwj.VVy65L, self, path, BF(self.VVas0U, path, title, asUtf8), title="Original Encoding"), clearMsg=False, title="Loading Codecs ...")
  else    : FFlkXm(self, path)
 def VVas0U(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8 : self.VVlPym(path, title, fromEnc, "UTF-8")
   else  : CCBlwj.VVy65L(self, path,  BF(self.VVlPym, path, title, fromEnc), onlyWorkingEnc=False, title="Convert to Encoding")
 def VVlPym(self, path, title, fromEnc, toEnc):
  if toEnc:
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FF6TiS("Successful\n\n", VVUdsq)
      txt += FF6TiS("From Encoding (%s):\n" % fromEnc, VVBfw8)
      txt += "%s\n\n" % path
      txt += FF6TiS("To Encoding (%s):\n" % toEnc, VVBfw8)
      txt += "%s\n\n" % outFile
      FFJRXg(self, txt, title=title)
    except:
     FFnHzu(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FFtMfC(self, "Cannot open file", 2000)
  self.VVetkj()
 def VVAUDi(self, path):
  title = "File Line-Break Conversion"
  FFWBJu(self, BF(self.VVNNWv, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVNNWv(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FF6TiS("File converted:", VVUdsq), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FFcZi2(self, txt, title=title)
  else:
   FFlkXm(self, path, title=title)
 def VVzvQs(self, path, selFile, newChmod):
  FFWBJu(self, BF(self.VVKczi, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVKczi(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VV56tq)
  result = FFN7zW(cmd)
  if result == "Successful" : FFcZi2(self, result)
  else      : FFnHzu(self, result)
 def VV7m61(self, path, selFile):
  parent = FFRlhS(path, False)
  self.session.openWithCallback(self.VVbQKX, BF(CCr5c7, mode=CCr5c7.VVT9mm, VV3Cmf=parent, VVx0dP="Create Symlink here"))
 def VVbQKX(self, newPath):
  if len(newPath) > 0:
   target = self.VVwZjb(self.VVsxjb())
   target = FFhn59(target)
   linkName = FFjyTm(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFxJSp(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFnHzu(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFWBJu(self, BF(self.VVSnKh, target, link), "Create Soft Link ?\n\n%s" % txt, VVARnJ=True)
 def VVSnKh(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VV56tq)
  result = FFN7zW(cmd)
  if result == "Successful" : FFcZi2(self, result)
  else      : FFnHzu(self, result)
 def VV7xaS(self, path, selFile):
  lastPart = FFjyTm(path)
  FFYvs0(self, BF(self.VVusOZ, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVusOZ(self, path, selFile, VVbYOE):
  if VVbYOE:
   parent = FFRlhS(path, True)
   if os.path.isdir(path):
    path = FFhn59(path)
   newName = parent + VVbYOE
   cmd = "mv '%s' '%s' %s" % (path, newName, VV56tq)
   if VVbYOE:
    if selFile != VVbYOE:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFWBJu(self, BF(self.VVbRSF, cmd), message, title="Rename file?")
    else:
     FFnHzu(self, "Cannot use same name!", title="Rename")
 def VVbRSF(self, cmd):
  result = FFN7zW(cmd)
  if "Fail" in result:
   FFnHzu(self, result)
  self.VVetkj()
 def VVGLAZ(self, preserve):
  title="Archive to .tar.gz"
  self.session.open(CCDe3n, barTheme=CCDe3n.VVEpKA, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVv0u1, title, preserve)
      , VVuJdT = BF(self.VVqvwn, title))
 def VVv0u1(self, title, preserve, VVEkKt):
  totSel = self["myMenu"].VVSvKs()
  totOk = totFail = 0
  VVEkKt.VVQWYw(totSel)
  VVEkKt.VVyzJx = ["", totSel, totOk, totFail, ""]
  VVEkKt.VVKrKU("Prepareing targz file")
  curDir = self["myMenu"].VVsWoI()
  lastPart = FFjyTm(curDir) or "archive"
  outF = os.path.join(curDir, lastPart + ".tar.gz")
  c = 0
  while fileExists(outF):
   c += 1
   outF = os.path.join(curDir, lastPart + "_%d.tar.gz" % c)
  totOk = totFail = 0
  path = ""
  try:
   with iTar.open(outF, mode="w:gz") as tarF:
    for row in self["myMenu"].list:
     if not VVEkKt or VVEkKt.isCancelled:
      return
     if row[2][6]:
      VVEkKt.VVHjIy(1)
      name  = FFhn59(row[0][0])
      lastPath = FFjyTm(name)
      path  = os.path.join(curDir, name)
      tarF.add(path, arcname=None if preserve else lastPath)
      totOk += 1
      if VVEkKt:
       VVEkKt.VVyzJx = [outF, totSel, totOk, totFail, path]
       VVEkKt.VVbPGC(totOk, lastPath)
  except:
   totFail += 1
   if VVEkKt:
    VVEkKt.VVyzJx = [outF, totSel, totOk, totFail, path]
 def VVqvwn(self, title, VVLnvr, VVyzJx, threadCounter, threadTotal, threadErr):
  outF, totSel, totOk, totFail, path = VVyzJx
  txt  = "%s:\n%s\n\n"   % (FF6TiS("Output File", VVUdsq), outF)
  txt += "Total\t: %d\n"  % totSel
  txt += "Archived\t: %d\n" % totOk
  if totFail   : txt += FF6TiS("Failed\t: %d\n" % totFail, VVsIVN)
  if not VVLnvr: txt += "%s\n%s" % (FF6TiS("\nCancelled while copying:", VVsIVN), path)
  FFJRXg(self, txt, title=title)
  self.VVetkj()
 def VVMcLk(self, isMove):
  self.session.openWithCallback(BF(self.VVatSw, isMove), BF(CCr5c7, mode=CCr5c7.VVT9mm, VV3Cmf=self["myMenu"].VVsWoI(), VVx0dP="Move to here" if isMove else "Paste here"))
 def VVatSw(self, isMove, newPath):
  if newPath:
   if isMove : title, action = "Move Items", "Moved"
   else  : title, action = "Copy Items", "Copied"
   self.session.open(CCDe3n, barTheme=CCDe3n.VVEpKA, titleBg="#22003344", bodyBg="#22001122"
       , titlePrefix = title
       , fncToRun  = BF(self.VVJHKs, title, action, isMove, newPath)
       , VVuJdT = BF(self.VVAsuk, title, action, isMove, newPath))
 def VVJHKs(self, title, action, isMove, newPath, VVEkKt):
  curDir = self["myMenu"].VVsWoI()
  totOk = totFail = 0
  totSel = self["myMenu"].VVSvKs()
  if isMove: cmd = "mv -f"
  else  : cmd = "cp -frp"
  VVEkKt.VVQWYw(totSel)
  VVEkKt.VVyzJx = [totSel, totOk, totFail, ""]
  for row in self["myMenu"].list:
   if not VVEkKt or VVEkKt.isCancelled:
    return
   if row[2][6]:
    VVEkKt.VVHjIy(1)
    VVEkKt.VVyH4l(action, totOk, FFjyTm(row[0][0]))
    path = os.path.join(curDir, row[0][0])
    lastPart = FFjyTm(path)
    if os.path.isdir(path): path = FFhn59(path)
    dest = os.path.join(newPath, lastPart)
    res = os.system(FFNxGN("%s '%s' '%s'" % (cmd, path, dest)))
    if res == 0 : totOk += 1
    else  : totFail += 1
    if VVEkKt:
     VVEkKt.VVyzJx = [totSel, totOk, totFail, path]
     VVEkKt.VVyH4l(action, totOk, FFjyTm(row[0][0]))
 def VVAsuk(self, title, action, isMove, newPath, VVLnvr, VVyzJx, threadCounter, threadTotal, threadErr):
  totSel, totOk, totFail, path = VVyzJx
  txt  = "Total\t: %d\n" % totSel
  txt += "%s\t: %d\n"  % (action, totOk)
  if totFail   : txt += FF6TiS("Failed\t: %d\n" % totFail, VVsIVN)
  if not VVLnvr: txt += "%s\n%s" % (FF6TiS("\nCancelled while copying:", VVsIVN), path)
  FFJRXg(self, txt, title=title)
  self.VVetkj()
 def VV8GB3(self):
  tot = self["myMenu"].VVSvKs()
  FFWBJu(self, BF(FFG53m, self, self.VV68TD, title="Deleting ...", clearMsg=False), "Delete %d item%s ?" % (tot, FFJHIK(tot)), title="Delete Selection")
 def VV68TD(self):
  path = self["myMenu"].VVsWoI()
  for row in self["myMenu"].list:
   if row[2][6]:
    FFZqpj(os.path.join(path, row[0][0]))
  FFtMfC(self)
  self.VVetkj()
 def VVLcQZ(self, path, isMove):
  self.session.openWithCallback(BF(self.VVHv55, isMove, path), BF(CCr5c7, mode=CCr5c7.VVT9mm, VV3Cmf=FFRlhS(path, False), VVx0dP="Move to here" if isMove else "Paste here"))
 def VVHv55(self, isMove, path, newPath):
  if len(newPath) > 0:
   lastPart = FFjyTm(path)
   if os.path.isdir(path): path = FFhn59(path)
   newPath = FFxJSp(newPath)
   dest = newPath + lastPart
   if os.path.isdir(path) and os.path.isdir(dest):
    if isMove:
     FFnHzu(self, 'Same directory already exists:\n\n%s\n\n( Try to copy then delete the source )' % dest)
     return
    else:
     dest = newPath
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -frp"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFWBJu(self, BF(FFSCk3, self, cmd, VVhgup=self.VVetkj), txt, VVARnJ=True)
   else:
    FFnHzu(self, "Cannot %s to same directory !" % action.lower())
 def VVXqQn(self, path, fileName):
  path = FFhn59(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFWBJu(self, BF(FFG53m, self, BF(self.VV68cw, path), title="Deleting ...", clearMsg=False), "%s\n\nDelete %s ?" % (path, pathType), title="Delete %s" % pathType)
 def VV68cw(self, path):
  FFZqpj(path)
  FFtMfC(self)
  self.VVetkj()
 def VVC1Gg(self, path, isFile):
  dirName = FFxJSp(os.path.dirname(path))
  if isFile : objName, VVbYOE = "File"  , self.edited_newFile
  else  : objName, VVbYOE = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFYvs0(self, BF(self.VVvbEJ, dirName, isFile, title), title=title, defaultText=VVbYOE, message="Enter %s Name:" % objName)
 def VVvbEJ(self, dirName, isFile, title, VVbYOE):
  if VVbYOE:
   if isFile : self.edited_newFile = VVbYOE
   else  : self.edited_newDir  = VVbYOE
   path = dirName + VVbYOE
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VV56tq)
    else  : cmd = "mkdir '%s' %s" % (path, VV56tq)
    result = FFN7zW(cmd)
    if "Fail" in result:
     FFnHzu(self, result)
    self.VVetkj()
   else:
    FFnHzu(self, "Name already exists !\n\n%s" % path, title)
 def VVKrJH(self, path, selFile):
  c1, c2, c3 = VVSTv2, VVpkep, VVPN93
  VVegP0 = []
  VVegP0.append((c1 + "List Package Files"         , "VVHw6h"     ))
  VVegP0.append((c1 + "Package Information"         , "VV5OpT"     ))
  VVegP0.append(VVHMBI)
  VVegP0.append((c2 + "Install Package"          , "VVrvwh_CheckVersion" ))
  VVegP0.append((c2 + "Install Package (force reinstall)"     , "VVrvwh_ForceReinstall" ))
  VVegP0.append((c2 + "Install Package (force overwrite)"     , "VVrvwh_ForceOverwrite" ))
  VVegP0.append((c2 + "Install Package (force downgrade)"     , "VVrvwh_ForceDowngrade" ))
  VVegP0.append((c2 + "Install Package (ignore failed dependencies)"  , "VVrvwh_IgnoreDepends" ))
  VVegP0.append(VVHMBI)
  VVegP0.append((c3 + "Remove Related Package"        , "VVYb9c_ExistingPackage" ))
  VVegP0.append((c3 + "Remove Related Package (force remove)"    , "VVYb9c_ForceRemove"  ))
  VVegP0.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VVYb9c_IgnoreDepends" ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Extract Files"           , "VVYENG"     ))
  VVegP0.append(("Unbuild Package"           , "VV9FFB"     ))
  FFJcY1(self, BF(self.VVD61h, path, selFile), VVegP0=VVegP0)
 def VVD61h(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVHw6h"      : self.VVHw6h(path, selFile)
   elif item == "VV5OpT"      : self.VV5OpT(path)
   elif item == "VVrvwh_CheckVersion"  : self.VVrvwh(path, selFile, VVerzX     )
   elif item == "VVrvwh_ForceReinstall" : self.VVrvwh(path, selFile, VVw4vm )
   elif item == "VVrvwh_ForceOverwrite" : self.VVrvwh(path, selFile, VVFhZO )
   elif item == "VVrvwh_ForceDowngrade" : self.VVrvwh(path, selFile, VVpj31 )
   elif item == "VVrvwh_IgnoreDepends" : self.VVrvwh(path, selFile, VVjszN )
   elif item == "VVYb9c_ExistingPackage" : self.VVYb9c(path, selFile, VVUSd3     )
   elif item == "VVYb9c_ForceRemove"  : self.VVYb9c(path, selFile, VVUCVW  )
   elif item == "VVYb9c_IgnoreDepends"  : self.VVYb9c(path, selFile, VVM72P )
   elif item == "VVYENG"     : self.VVYENG(path, selFile)
   elif item == "VV9FFB"     : self.VV9FFB(path, selFile)
   else           : self.close()
 def VVHw6h(self, path, selFile):
  if FF63FC("ar") : cmd = "allOK='1';"
  else    : cmd  = FFZKBU()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVtc24, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVtc24, VVtc24)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFKG3v(self, cmd, VVhgup=self.VVetkj)
 def VVYENG(self, path, selFile):
  lastPart = FFjyTm(path)
  dest  = FFRlhS(path, True) + selFile[:-4]
  cmd  =  FFZKBU()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFNxGN("mkdir '%s'" % dest) + ";"
  cmd +=    FFNxGN("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFmjg3(dest, VVUdsq))
  cmd += "fi;"
  FFYyBc(self, cmd, VVhgup=self.VVetkj)
 def VV9FFB(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVftjM = os.path.splitext(path)[0]
  else        : VVftjM = path + "_"
  if path.endswith(".deb")   : VVimvy = "DEBIAN"
  else        : VVimvy = "CONTROL"
  cmd  = FFZKBU()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVftjM, FFlMiq())
  cmd += "  mkdir '%s';"    % VVftjM
  cmd += "  CONTPATH='%s/%s';"  % (VVftjM, VVimvy)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVftjM
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVftjM, VVftjM)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVftjM
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVftjM, VVftjM)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVftjM
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVftjM
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVftjM, FFmjg3(VVftjM, VVUdsq))
  cmd += "fi;"
  FFYyBc(self, cmd, VVhgup=self.VVetkj)
 def VV5OpT(self, path):
  listCmd  = FFQz9o(VVXp23, "")
  infoCmd  = FFiwac(VViz0h , "")
  filesCmd = FFiwac(VV3b1m, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FF7nYK(VVBfw8)
   notInst = "Package not installed."
   cmd  = FFBxX8("File Info", VVBfw8)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFBxX8("System Info", VVBfw8)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFmjg3(notInst, VVsIVN))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFBxX8("Related Files", VVBfw8)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFlo7E(self, cmd)
  else:
   FFw6dW(self)
 def VVrvwh(self, path, selFile, cmdOpt):
  cmd = FFiwac(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFWBJu(self, BF(FFYyBc, self, cmd, VVhgup=FFrn02), "Install Package ?\n\n%s" % selFile)
  else:
   FFw6dW(self)
 def VVYb9c(self, path, selFile, cmdOpt):
  listCmd  = FFQz9o(VVXp23, "")
  infoCmd  = FFiwac(VViz0h, "")
  instRemCmd = FFiwac(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFmjg3(errTxt, VVsIVN))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFmjg3(cannotTxt, VVsIVN))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFmjg3(tryTxt, VVsIVN))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFWBJu(self, BF(FFYyBc, self, cmd, VVhgup=FFrn02), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFw6dW(self)
 def VVsw1l(self, path):
  hostName = FFN7zW("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVxvUh(self, path, isDir):
  txt1 = "Archive to "
  txt2 = "Archive (Preserve Path Structure) to "
  VVegP0 = []
  VVegP0.append(("%s.tar"  % txt1 , "archDir_tar"  ))
  VVegP0.append(("%s.tar.gz" % txt1 , "archDir_tar_gz" ))
  VVegP0.append(("%s.tar.xz" % txt1 , "archDir_tar_xz" ))
  VVegP0.append(("%s.tar.bz2" % txt1 , "archDir_tar_bz2" ))
  VVegP0.append(("%s.zip"  % txt1 , "archDir_zip"  ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("%s.tar"  % txt2 , "archPath_tar" ))
  VVegP0.append(("%s.tar.gz" % txt2 , "archPath_tar_gz" ))
  VVegP0.append(("%s.tar.xz" % txt2 , "archPath_tar_xz" ))
  VVegP0.append(("%s.tar.bz2" % txt2 , "archPath_tar_bz2"))
  VVegP0.append(("%s.zip"  % txt2 , "archPath_zip" ))
  if isDir and not self.multiSelectState:
   VVegP0.append(VVHMBI)
   VVegP0.append(('Convert to ".ipk" Package', "convertDirToIpk" ))
   VVegP0.append(('Convert to ".deb" Package', "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFJcY1(self, BF(self.VVuKLT, path, isDir, title), VVegP0=VVegP0, title=title, VVXbiY=c1, VVVy8H=c2)
 def VVuKLT(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VV2NZb(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz"   : self.VV2NZb(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VV2NZb(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VV2NZb(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"    : self.VV2NZb(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"    : self.VV2NZb(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz"   : self.VV2NZb(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VV2NZb(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VV2NZb(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"    : self.VV2NZb(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk"   : self.VVCFTz(path, False)
   elif item == "convertDirToDeb"   : self.VVCFTz(path, True)
 def VVCFTz(self, path, VVMRua):
  self.session.openWithCallback(self.VVetkj, BF(CCfSCG, path=path, VVMRua=VVMRua))
 def VV2NZb(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FFRlhS(path, True)
  lastPart = FFjyTm(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FF3XrD("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FF3XrD("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FF3XrD("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVtc24
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFNxGN("rm -f '%s'" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFmjg3(failed, VVnKNv))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFmjg3(srcTxt, VVOEUI))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFmjg3("Output", VVUdsq))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFmjg3(failed, VVSGHr))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFKG3v(self, cmd, VVhgup=self.VVetkj, title=title)
 def VVFPj4(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CCr5c7.VVMYpt(FFRlhS(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CCu3Fm(self, self, title, BF(self.VVoqZY, pathLst))
 def VVoqZY(self, pathLst):
  return CCu3Fm.VVw7o5(pathLst)
 def VVMY2j(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VVdIUI, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFWBJu(self, BF(FFG53m, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFG53m(self, fnc, title=txt)
  else:
   FFnHzu(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VVdIUI(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, "w:gz") as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFJRXg(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VVetkj()
  else:
   FFO0bd(tarPath)
   FFnHzu(self, "Error while converting.", title=title)
 def VVgw5s(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVfryf, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFWBJu(self, BF(FFG53m, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFG53m(self, fnc, title=txt)
  else:
   FFnHzu(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVfryf(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFJRXg(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VVetkj()
  else:
   FFO0bd(zipPath)
   FFnHzu(self, "Error while converting.", title=title)
 def VVCVij(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FFxJSp(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  os.system(FFNxGN("rm -f '%s' '%s'" % (m1v, mvi)))
  res = os.system(FFNxGN("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)))
  if res == 0 and fileExists(m1v):
   res = os.system(FFNxGN("mv -f '%s' '%s'" % (m1v, mvi)))
   self.VVetkj()
   FFcZi2(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FFnHzu(self, "Cannot convert this file !", title=title)
 def VVvMV2(self, path):
  title = "Set as PIcon for current channel"
  pPath = CC96Ar.VVwdi5()
  if pathExists(pPath):
   if CCmMzJ.VV0T6t(self, title, False, cbFnc=BF(self.VVvMV2, path)):
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self)
    picon = "%s%s.png" % (pPath, refCode.strip(":").replace(":", "_").upper())
    VVegP0 = []
    for item in ((50,30),(96,64),(100,60),(220,132),(400,160),(400,240),(500,300)):
     VVegP0.append(("%d x %d" % (item), item))
    infoBtnFnc = self.VV5M8J
    VVZKXi = ("Stretch", BF(self.VVP3Li, title, path, picon))
    menuInstance = FFJcY1(self, BF(self.VVze58, title, path, picon, False), VVegP0=VVegP0, width=700, title='PIcon Max. Size', infoBtnFnc=infoBtnFnc, VVZKXi=VVZKXi, barText="OK = Fit within size")
    menuInstance.VVc7DL(3)
  else:
   FFnHzu(self, "PIcons path not found:\n\n%s\n\n( You can change it in Settings )" % pPath, title=title)
 def VVP3Li(self, title, path, picon, VVsxjbObj, item):
  self.VVze58(title, path, picon, True, item)
  VVsxjbObj.cancel()
 def VVze58(self, title, path, picon, stretch, sz=None):
  if sz:
   try:
    from PIL import Image
    im = Image.open(path)
    if stretch: im = im.resize(sz, Image.ANTIALIAS)
    else   : im.thumbnail(sz)
    im.save(picon)
    FFiqcT(self, fncMode=CC6biu.VVn9lJ)
   except Exception as e:
    FFnHzu(self, "Image Processing error:\n\n%s" % e)
 def VV5M8J(self, menuInstance, txt, ref, ndx):
  FFHU3T(self, "_help_resize", "Picture File Resizing")
 @staticmethod
 def VVkZbk():
  lst = (("1"  , "DVB Stream"  , True)
   , ("4097", "servicemp3"  , True)
   , ("5001", "GST Player"  , os.path.exists("/usr/bin/gstplayer"))
   , ("5002", "Ext-3 EPlayer" , os.path.exists("/usr/bin/exteplayer3"))
   , ("8193", "eServiceUri" , os.path.exists("/usr/bin/apt-get")))
  defRt = CFG.iptvAddToBouquetRefType.getValue()
  VVegP0 = []
  for ndx, (rt, txt, ok) in enumerate(lst):
   txt = "%s\t... %s" % ((VVSTv2 if rt == defRt else "") + txt, rt)
   if ok: VVegP0.append((txt, rt))
   else : VVegP0.append((txt, ))
   if ndx < 4 and ndx % 2: VVegP0.append(VVHMBI)
  return VVegP0
 def VV24oI(self, path):
  FFJcY1(self, BF(self.VVAk6k, path), VVegP0=CCr5c7.VVkZbk(), width=650, title="Select Player", VVXbiY="#11220000", VVVy8H="#11220000")
 def VVAk6k(self, path, rType=None):
  if rType:
   FFG53m(self, BF(self.VVU4yQ, self, path, rType), title="Playing Media ...")
 @staticmethod
 def VVU4yQ(SELF, path, rType=""):
  try:
   if   rType     : prefix = rType
   elif path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCM2Fd.VV8elw(SELF.session, enableZapping= False, enableDownloadMenu=False, enableOpenInFMan=False)
  except:
   pass
 @staticmethod
 def VVt1SH(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FFxJSp(fDir), fName
  return "", "", ""
 @staticmethod
 def VVHFaI(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVPnvT(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVJv7c(size, mode=0):
  txt = CCr5c7.VVoX3u(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVoX3u(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VVy14F(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VVKo2B(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FFnHzu(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VV5goT():
  tDict = CCAnG2.VVXWgC()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVMYpt(path):
  lst = []
  for ext in CCr5c7.VV5goT():
   lst.extend(FFT5mp(path, "*.%s" % ext))
  return sorted(lst, key=FF6NUe(FFAqgR))
 @staticmethod
 def VVlrmK(path):
  res = os.system("tar -tzf '%s' >/dev/null" % path)
  return res == 0
 @staticmethod
 def VV3dPe(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
 @staticmethod
 def VVlY6G(lst, fromFind=True):
  if len(lst) == 1 and lst[0] == VVmwUY:
   return VVmwUY
  elif fromFind:
   for line in lst:
    span = iSearch(r"find:\s*(.+):\s*Input\/output error", line, IGNORECASE)
    if span:
     return 'Filesystem Error in:\n\n%s' % span.group(1)
  return ""
class CCAnG2(MenuList):
 VVc5DI   = 0
 VVAdmY   = 1
 VVM3Y1   = 2
 VVhETZ   = 3
 VVcmIR   = 4
 VVPbIT   = 5
 VVxm3f   = 6
 VVkGat   = 7
 VVi65e   = "<List of Storage Devices>"
 VV27n6  = "<Parent Directory>"
 VVdkAB   = 0
 VVKhjc   = 1
 VVjpz3 = 2
 VV1xyt  = 3
 VVdJ71   = 4
 VVhehQ   = 5
 FILE_TYPE_LINK   = 6
 VV6OvL  = 7
 PROHIBITED_FILES  = ["/%s/" % x for x in ("DEBIAN","bin","boot","dev","etc","hdd","home","lib","media","mnt","network","proc","run","sbin","sys","tmp","usr","var")]
 def __init__(self, VVLqGp=False, directory="/", VV2b5D=True, VVolId=True, VV8HdX=True, VVXziI=None, VVJxgS=False, VVBtqU=False, VVZPbQ=False, isTop=False, VVeHKr=None, VVRFau=1000, VVwwGj=30, VVLEkl=30):
  MenuList.__init__(self, list, VVLqGp, eListboxPythonMultiContent)
  self.VV2b5D  = VV2b5D
  self.VVolId    = VVolId
  self.VV8HdX  = VV8HdX
  self.VVXziI  = VVXziI
  self.VVJxgS   = VVJxgS
  self.VVBtqU   = VVBtqU or []
  self.VVZPbQ   = VVZPbQ or []
  self.isTop     = isTop
  self.additional_extensions = VVeHKr
  self.VVRFau    = VVRFau
  self.VVwwGj    = VVwwGj
  self.VVLEkl    = VVLEkl
  self.EXTENSIONS    = CCAnG2.VVXWgC()
  self.VVV82e   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.multiSelect_color  = FFXhEg("#11ff4444")
  self.l.setFont(0, gFont(VV07pp, self.VVwwGj))
  self.l.setItemHeight(self.VVLEkl)
  self.png_mem   = self.VVsPya("mem")
  self.png_usb   = self.VVsPya("usb")
  self.png_fil   = self.VVsPya("fil")
  self.png_dir   = self.VVsPya("dir")
  self.png_dirup   = self.VVsPya("dirup")
  self.png_srv   = self.VVsPya("srv")
  self.png_slwfil   = self.VVsPya("slwfil")
  self.png_slbfil   = self.VVsPya("slbfil")
  self.png_slwdir   = self.VVsPya("slwdir")
  self.VVFapN()
  self.VVrDTR(directory)
 def VVsPya(self, category):
  return LoadPixmap("%s%s.png" % (VVeop3, category), getDesktop(0))
 @staticmethod
 def VVXWgC():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","stream","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VV8JOc(self, name, absolute=None, isDir=False, typ=None, png=None):
  if absolute and isDir:
   path = absolute
   path = FFhn59(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FF6TiS(" -> " , VVBfw8) + FF6TiS(os.readlink(path), VVUdsq)
  tableRow = [ (absolute, isDir, typ) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVLEkl + 10, 0, self.VVRFau, self.VVLEkl, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVejcx: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVLEkl-4, self.VVLEkl-4, png, None, None, VVejcx))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVLEkl-4, self.VVLEkl-4, png, None, None))
  return tableRow
 def VVsQQU(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVFapN(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VV55T6(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVL4sr(self, file):
  if os.path.realpath(file) == file:
   return self.VV55T6(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VV55T6(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VV55T6(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVHnFM(self):
  ndx = self.l.getCurrentSelectionIndex()
  row = self.list[ndx]
  bg = self.multiSelect_color if row[2][6] == None else None
  ndx = self.getSelectionIndex()
  if ndx < len(self.list) - 1:
   self.moveToIndex(self.getSelectionIndex() + 1)
  iconData = self.VVFf1F(row, bg)
  if iconData:
   row[2] = iconData
   self.l.setList(self.list)
   return True
  else:
   return False
 def VV5JkW(self, isSel):
  bg = self.multiSelect_color if isSel else None
  for ndx, row in enumerate(self.list):
   iconData = self.VVFf1F(row, bg)
   if iconData:
    row[2] = iconData
  self.l.setList(self.list)
 def VVFf1F(self, row, bg):
  if self.VV6lyk(row):
   iconData = list(row[2])
   iconData[6] = bg
   iconData[7] = bg
   return tuple(iconData)
  else:
   return None
 def VV6lyk(self, row):
  if not row[0][0] in self.mountpoints:
   if   row[0][2] in (self.VVhehQ, self.FILE_TYPE_LINK): return True
   elif row[0][2] == self.VVdJ71:
    if   VVh0o2           : return True
    elif not row[0][0] in self.PROHIBITED_FILES    : return True
  return False
 def VVdpPD(self):
  return self.VV6lyk(self.list[self.l.getCurrentSelectionIndex()])
 def VVSvKs(self):
  tot = 0
  for row in self.list:
   if row[2][6]:
    tot += 1
  return tot
 def VVQW1r(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True : return None
  else      : return self.VVV82e.info(l[0][0]).getEvent(l[0][0])
 def VVYPWG(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVrDTR(self, directory, selItem=None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VV8HdX:
    self.current_mountpoint = self.VVL4sr(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VV8HdX:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVZPbQ and not self.VVYPWG(path, self.VVBtqU):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VV8JOc(name=p.description, absolute=path, isDir=True, typ=self.VVdkAB, png=png))
    path = "/"
    if path not in self.VVZPbQ and not self.VVYPWG(path, self.VVBtqU):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VV8JOc(name="INTERNAL FLASH", absolute="/", isDir=True, typ=self.VVKhjc, png=self.png_mem))
  elif self.VVJxgS:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVV82e = eServiceCenter.getInstance()
   list = VVV82e.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VV2b5D and not self.isTop:
   if directory == self.current_mountpoint and self.VV8HdX:
    self.list.append(self.VV8JOc(name=self.VVi65e, absolute=None, isDir=True, typ=self.VVjpz3, png=self.png_dirup))
   elif (directory != "/") and not (self.VVZPbQ and self.VV55T6(directory) in self.VVZPbQ):
    self.list.append(self.VV8JOc(name=self.VV27n6, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, typ=self.VV1xyt, png=self.png_dirup))
  if self.VV2b5D:
   for x in directories:
    if not (self.VVZPbQ and self.VV55T6(x) in self.VVZPbQ) and not self.VVYPWG(x, self.VVBtqU):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VV8JOc(name=name, absolute=x, isDir=True, typ=self.FILE_TYPE_LINK if os.path.islink(FFhn59(x)) else self.VVdJ71, png=png))
  if self.VVolId:
   for x in files:
    if self.VVJxgS:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FF6TiS(" -> " , VVBfw8) + FF6TiS(target, VVUdsq)
       else:
        png = self.png_slbfil
        name += FF6TiS(" -> " , VVBfw8) + FF6TiS(target, VVSGHr)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVsQQU(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVeop3, category))
    if (self.VVXziI is None) or iCompile(self.VVXziI[0], flags=self.VVXziI[1]).search(path):
     self.list.append(self.VV8JOc(name=name, absolute=x , isDir=False, typ=self.VVhehQ, png=png))
  if self.VV8HdX and len(self.list) == 0:
   self.list.append(self.VV8JOc(name=FF6TiS("No USB connected", VVsvZg), absolute=None, isDir=False, typ=self.VV6OvL, png=self.png_usb))
  self.l.setList(self.list)
  self.VVy41P()
  if selItem is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference): p = p.getPath()
    if p == selItem: self.moveToIndex(i)
    i += 1
 def VVsWoI(self):
  return self.current_directory
 def VV3zEI(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VVFHrM(self):
  return self.VV5TPH() and self.VVsWoI()
 def VV5TPH(self):
  return self.list[0][1][7] in (self.VVi65e, self.VV27n6)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVrDTR(self.getSelection()[0], self.current_directory)
 def VVrLyP(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VV6Xmn(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VV8XZq)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VV8XZq)
 def VVH1Ch(self):
  tDict = {}
  for row in self.list:
   if row[2][6]:
    tDict[row[0][0]] = 1
  self.VVrDTR(self.current_directory, self.VVrLyP())
  isSel = 0
  if tDict:
   for row in self.list:
    if tDict.get(row[0][0], 0):
     row[2] = list(row[2])
     row[2][6] = row[2][7] = self.multiSelect_color
     row[2] = tuple(row[2])
     isSel = 1
   self.l.setList(self.list)
  return isSel
 def VV8XZq(self, action, device):
  self.VVFapN()
  if self.current_directory is None:
   self.VVH1Ch()
 def VVT4Lm(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVc5DI : nameAlpMode, nameAlpTxt = self.VVAdmY, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVc5DI, sAZ
  if mode == self.VVM3Y1 : nameNumMode, nameNumTxt = self.VVhETZ, s90
  else       : nameNumMode, nameNumTxt = self.VVM3Y1, s09
  if mode == self.VVcmIR : dateMode, dateTxt = self.VVPbIT, sON
  else       : dateMode, dateTxt = self.VVcmIR, sNO
  if mode == self.VVxm3f : typeMode, typeTxt = self.VVkGat, sZA
  else       : typeMode, typeTxt = self.VVxm3f, sAZ
  if   mode in (self.VVc5DI, self.VVAdmY): txt = "Name (%s)" % (sAZ if mode == self.VVc5DI else sZA)
  elif mode in (self.VVM3Y1, self.VVhETZ): txt = "Name (%s)" % (s09 if mode == self.VVc5DI else s90)
  elif mode in (self.VVcmIR, self.VVPbIT): txt = "Date (%s)" % (sNO if mode == self.VVcmIR else sON)
  elif mode in (self.VVxm3f, self.VVkGat): txt = "Type (%s)" % (sAZ if mode == self.VVxm3f else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VVy41P(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FFCfiF(CFG.browserSortMode, mode)
   FFCfiF(CFG.browserSortMix, isMix)
  if self.list:
   if self.VV5TPH() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVc5DI, self.VVAdmY):
    rev = True if mode == self.VVAdmY else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVM3Y1, self.VVhETZ):
    rev = True if mode == self.VVhETZ else False
    self.list = sorted(self.list[item0:], key=FF6NUe(BF(self.VVBuwR, isMix, rev)), reverse=rev)
   elif mode in (self.VVcmIR, self.VVPbIT):
    rev = True if mode == self.VVPbIT else False
    self.list = sorted(self.list[item0:], key=FF6NUe(BF(self.VVEViD, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VVkGat else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VVBuwR(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FFAqgR(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FFt4mY(dir2, dir1) or FFAqgR(name1, name2)
 def VVEViD(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FFt4mY(stat2.st_ctime, stat1.st_ctime)
    else : return FFt4mY(dir2, dir1) or FFt4mY(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CCHuHv(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FFAJVu(VVh7Ze, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVVC4T   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVarf6(defFG, "#00FFFFFF")
  self.defBG   = self.VVarf6(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFsw8F(self, self.Title)
  self["keyRed"].show()
  FF154z(self["keyGreen"] , "< > Transp.")
  FF154z(self["keyYellow"], "Foreground")
  FF154z(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVGBSS     ,
   "green"   : self.VVGBSS     ,
   "yellow"  : BF(self.VV5oB4, False)  ,
   "blue"   : BF(self.VV5oB4, True)  ,
   "up"   : self.VV7Q5E       ,
   "down"   : self.VVNA9M      ,
   "left"   : self.VVITAJ      ,
   "right"   : self.VVHgAf      ,
   "last"   : BF(self.VV4XDR, -5) ,
   "next"   : BF(self.VV4XDR, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVoCo0)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFo6oa(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFo6oa(self["keyRed"] , c)
  FFo6oa(self["keyGreen"] , c)
  self.VV1yfs()
  self.VV5iyB()
  FFD09G(self["myColorTst"], self.defFG)
  FFo6oa(self["myColorTst"], self.defBG)
 def VVarf6(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VV5iyB(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVys5m(0, 0)
     return
 def VVGBSS(self):
  self.close(self.defFG, self.defBG)
 def VV7Q5E(self): self.VVys5m(-1, 0)
 def VVNA9M(self): self.VVys5m(1, 0)
 def VVITAJ(self): self.VVys5m(0, -1)
 def VVHgAf(self): self.VVys5m(0, 1)
 def VVys5m(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VV1NcP()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VV967r()
 def VV1yfs(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VV967r(self):
  color = self.VV1NcP()
  if self.isBgMode: FFo6oa(self["myColorTst"], color)
  else   : FFD09G(self["myColorTst"], color)
 def VV5oB4(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VV1yfs()
   self.VV5iyB()
 def VV4XDR(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVys5m(0, 0)
 def VVN2n1(self):
  return hex(self.transp)[2:].zfill(2)
 def VV1NcP(self):
  return ("#%s%s" % (self.VVN2n1(), self.colors[self.curRow][self.curCol])).upper()
class CCsETK(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFAJVu(VV9oFo, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FFsw8F(self, title="%s%s%s" % (self.Title, " " * 10, FF6TiS("Change values with Up , Down, < , 0 , >", VVsvZg)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVu0DR      ,
   "cancel" : self.VVJFui      ,
   "info"  : self.VVzANI    ,
   "red"  : self.VVyP8p  ,
   "green"  : self.VVVzfV   ,
   "yellow" : BF(self.VVklNJ, 0)  ,
   "blue"  : self.VVVoOU    ,
   "menu"  : self.VVPKe4      ,
   "left"  : self.VVITAJ      ,
   "right"  : self.VVHgAf      ,
   "last"  : self.VVwuEk     ,
   "next"  : self.VVo573     ,
   "0"   : self.VV8IJv    ,
   "up"  : self.VV7Q5E       ,
   "down"  : self.VVNA9M      ,
   "pageUp" : BF(self.VViXy7, True) ,
   "pageDown" : BF(self.VViXy7, False) ,
   "chanUp" : BF(self.VViXy7, True) ,
   "chanDown" : BF(self.VViXy7, False) ,
   "play"  : BF(self.VVsdWP, "pause")  ,
   "pause"  : BF(self.VVsdWP, "pause")  ,
   "playPause" : BF(self.VVsdWP, "pause")  ,
   "stop"  : BF(self.VVsdWP, "pause")  ,
   "audio"  : BF(self.VVsdWP, "audio")  ,
   "subtitle" : BF(self.VVsdWP, "subtitle") ,
   "rewind" : BF(self.VVsdWP, "rewind" ) ,
   "forward" : BF(self.VVsdWP, "forward" ) ,
   "rewindDm" : BF(self.VVsdWP, "rewindDm") ,
   "forwardDm" : BF(self.VVsdWP, "forwardDm")
  }, -1)
  self.VVxJyC()
  self.onShown.append(self.VVoCo0)
  self.onClose.append(self.VVkYDK)
 def VVxJyC(self):
  lst = []
  for fil in FFT5mp(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VVRvDu:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VVoCo0(self):
  self.onShown.remove(self.VVoCo0)
  FFnLuC(self)
  FF6aqB(self)
  for i in range(3):
   self["mySubt%d" % i].instance.setNoWrap(True)
   self["mySubt%d" % i].hide()
  self.VVg528()
  self.VVuFMq()
  self.VVYUP9()
 def VVkYDK(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VVAI3U(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FFo6oa(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VVP2QM()
 def VVg528(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FFo6oa(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VVu0DR(self):
  if self.settingShown:
   confItem = self.VVQgPp()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVegP0 = []
   if isinstance(lst[0], tuple):
    for item in lst: VVegP0.append((item[1], item[0]))
   else:
    for item in lst: VVegP0.append((item, item))
   menuInstance = FFJcY1(self, self.VV9C5w, VVegP0=VVegP0, width=700, title=title, VVXbiY="#33221111", VVVy8H="#33110011")
   menuInstance.VVc7DL(confItem.getIndex())
  else:
   self.close("subtExit")
 def VV9C5w(self, item=None):
  if item:
   self.VVQgPp()[self.CursorPos].setValue(item)
   self.VVP2QM()
   self.VVuFMq()
   self.VVSHR0(True)
 def VVJFui(self):
  for confItem in self.VVQgPp():
   if confItem.isChanged():
    FFWBJu(self, self.VVhNxk, "Save Changes ?", callBack_No=self.VV3E8w, title=self.Title)
    break
  else:
   if self.settingShown: self.VVg528()
   else    : self.close("subtExit")
 def VVPKe4(self):
  if self.settingShown: self.VV1pIq()
  else    : self.VVAI3U()
 def VVITAJ(self): self.VVbvO9(-1)
 def VVHgAf(self): self.VVbvO9(1)
 def VVbvO9(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VVO81b()
   if pos == -1: ndx = self.VV5KbI(posVal)
   else  : ndx = self.VV18o1(posVal)
   if   ndx < 0      : FFtMfC(self, "Not found" , 500)
   elif ndx == 0      : FFtMfC(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FFtMfC(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVqLGW(frmSec)
    if allow:
     self.VVklNJ(delay, True)
     self.VVSHR0(force=True)
    else:
     FFtMfC(self, "Delay out of range", 800)
 def VViXy7(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VVsdWP(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVwuEk(self) : self.VV9SuB(5)
 def VVo573(self) : self.VV9SuB(6)
 def VV8IJv(self) : self.VV9SuB(-1)
 def VV7Q5E(self):
  if self.settingShown: self.VV9SuB(1)
  else    : self.VViXy7(True)
 def VVNA9M(self):
  if self.settingShown: self.VV9SuB(0)
  else    : self.VViXy7(False)
 def VV9SuB(self, direction):
  if self.settingShown:
   confItem = self.VVQgPp()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VVP2QM()
   self.VVuFMq()
   self.VVSHR0(True)
 def VVQgPp(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VV3E8w(self):
  for confItem in self.VVQgPp(): confItem.cancel()
  self.VVP2QM()
  self.VVuFMq()
  self.VVg528()
 def VVyP8p(self):
  if self.settingShown:
   FFWBJu(self, self.VV8BIM, "Reset Subtitle Settings to default ?", title=self.Title)
 def VV8BIM(self):
  for confItem in self.VVQgPp(): confItem.setValue(confItem.default)
  self.VVhNxk()
  self.VVP2QM()
  self.VVuFMq()
 def VVklNJ(self, delay, force=False):
  if self.settingShown or force:
   FFCfiF(CFG.subtDelaySec, delay)
   self.VVEggG()
   self.VVP2QM()
   self.VVuFMq()
   if self.settingShown:
    FFtMfC(self, 'Reset to "0"', 800, isGrn=True)
 def VVVzfV(self):
  if self.settingShown:
   self.VVhNxk()
   self.VVg528()
 def VVhNxk(self):
  for confItem in self.VVQgPp(): confItem.save()
  configfile.save()
  self.VVEggG()
  FFtMfC(self, "Saved", 1000, isGrn=True)
 def VVP2QM(self):
  cfgLst = self.VVQgPp()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VVuFMq(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FF7ym2(path, fnt, isRepl=1)
  else:
   fnt = VV07pp
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFXM7k(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFD09G(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FFo6oa(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    inst.setNoWrap(True)
    lineH = FFlCly(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFXM7k(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFF92P()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  FFOgS2(self, winW, winH)
 def VVzANI(self):
  sp = "    "
  txt  = "%s\n"   % FF6TiS("Subtitle File:", VVpkep)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FF6TiS("Subtitle Settings:", VVpkep)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VVO81b()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FFFSaa(frmSec1)
   time2 = FFFSaa(toSec2)
   txt += "\n"
   txt += "%s\n"       % FF6TiS("Timing:", VVpkep)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FFFSaa(durVal)
   txt += sp + "Progress\t: %s\n" % FFFSaa(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FF6TiS("Subtitle end reached.", VVnKNv)
  FFJRXg(self, txt, title="Current Subtitle")
 def VVYUP9(self, path="", delay=0, enc=""):
  FFG53m(self, BF(self.VVS4sU, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VVS4sU(self, path="", delay=0, enc=""):
  FFtMfC(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVNzHS(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VVP2QM()
     self.VVAE9T()
   else:
    path, delay, enc = CCsETK.VVUQfp(self)
    if path:
     self.VVYUP9(path=path, delay=delay, enc=enc)
    else:
     self.VV1pIq()
  except:
   pass
 def VVAE9T(self):
  posVal, durVal = self.VVO81b()
  if self.VVROYi(posVal):
   return
  CCsETK.VVqFbQ(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVSHR0)
  except:
   self.timerUpdate.callback.append(self.VVSHR0)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVmbnq)
  except:
   self.timerEndText.callback.append(self.VVmbnq)
  FFtMfC(self, "Subtitle started", 700, isGrn=True)
 def VVROYi(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CCsETK.VVqvFz(self)
   FFO0bd(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VV1pIq(self):
  c1, c2, c3, c4, c5 = "", VVpkep, VVJCMd, VVPN93, VVnKNv
  VVegP0 = []
  VVegP0.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVegP0.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVegP0.append(VVHMBI)
  VVegP0.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVegP0.append(VVHMBI)
  VVegP0.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVegP0.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVegP0.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVegP0.append(VVHMBI)
   VVegP0.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVegP0.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVegP0.append(VVHMBI)
   VVegP0.append(("Help (Keys)"        , "help"  ))
  FFJcY1(self, self.VVPCb8, VVegP0=VVegP0, width=700, title='Find Subtitle ".srt" File', VVXbiY="#33221111", VVVy8H="#33110011")
 def VVPCb8(self, item=None):
  if item:
   if   item == "allSrt"   : self.VVwmWz(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VVwmWz(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    sDir = "/"
    for path in (CFG.lastFileManFindSrt.getValue(), CFG.MovieDownloadPath.getValue(), "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VVckXq, BF(CCr5c7, patternMode="srt", VV3Cmf=sDir))
   elif item.startswith("sugSrt") : self.VVwmWz(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FFG53m(self, BF(CCBlwj.VVy65L, self, self.lastSubtFile, self.VVRRZI, defEnc=self.lastSubtEnc), title="Loading Codecs ...", clearMsg=False)
    else             : FFtMfC(self, "SRT File error", 1000)
   elif item == "disab":
    FFO0bd(CCsETK.VVqvFz(self))
    self.close("subtExit")
   elif item == "help"    : FFHU3T(self, "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VVRRZI(self, item=None):
  if item:
   FFG53m(self, BF(self.VVYUP9, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VVckXq(self, path):
  if path:
   FFCfiF(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VVYUP9(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VVwmWz(self, defSrt="", mode=0, coeff=0.25):
  FFG53m(self, BF(self.VVzmJi, defSrt, mode=mode, coeff=coeff), title="Searching for srt files", clearMsg=False)
 def VVzmJi(self, defSrt="", mode=0, coeff=0.25):
  FFtMfC(self)
  if mode == 1:
   srtList = CCsETK.VVuecr(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FF5Sgm('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFdsA4(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVFiZe(srtList, coeff)
     if err:
      if self.settingShown: FFtMfC(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVzto2 = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FFxJSp(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVzto2.append((fName, Dir))
   VV91FP  = ("Select"    , self.VVp1if     , [])
   VVs5Sk = self.VVd1Ck
   VVBSYf = (""     , self.VVx1Yp       , [])
   VVqfcE = (""     , BF(self.VVPwhy, defSrt, False) , [])
   VVdn6T = ("Find Current File" , BF(self.VVPwhy, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FFqiz1(self, None, title=title, header=header, VVVC4T=VVzto2, VVx2iV=widths, VVwwGj=28, VV91FP=VV91FP, VVs5Sk=VVs5Sk, VVBSYf=VVBSYf, VVqfcE=VVqfcE, VVdn6T=VVdn6T, lastFindConfigObj=CFG.lastFindSubtitle
     , VVXbiY="#11002222", VVVy8H="#33001111", VVvi08="#33001111", VVbSmQ="#11ffff00", VVTrrJ="#11445544", VVcd71="#22222222", VVVygK="#11002233")
  elif self.settingShown : FFtMfC(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVd1Ck(self, VVR0r4):
  VVR0r4.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VVx1Yp(self, VVR0r4, title, txt, colList):
  fName, Dir = colList
  FFJRXg(VVR0r4, "%s\n\n%s%s" % (FF6TiS("Path:", VVpkep), Dir, fName), title=title)
 def VVPwhy(self, path, VVozbc, VVR0r4, title, txt, colList):
  for ndx, row in enumerate(VVR0r4.VVtxRM()):
   if path == row[1].strip() + row[0].strip():
    VVR0r4.VVwqjr(ndx)
    break
  else:
   if VVozbc:
    FFtMfC(VVR0r4, "Not in list !", 1000)
 def VVp1if(self, VVR0r4, title, txt, colList):
  VVR0r4.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VVYUP9(path=path)
 def VVFiZe(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CC2gVv.VVjWEY(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   if evName and CFG.epgLangTitle.getValue():
    CC2gVv.VVskcb(evName, "en")[0] or evName
   lst, err = CCsETK.VV84zu(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVNzHS(self, path, enc=None):
  if not fileExists(path):
   return [], "File not found"
  if (FFREV4(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FF5DO4(path, encLst=enc if enc else None)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVS8FC(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VV9VxE(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVEggG()
  return subtList, ""
 def VV9VxE(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VVS8FC(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVEggG(self):
  path = CCsETK.VVqvFz(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVSHR0(self, force=False):
  posVal, durVal = self.VVO81b()
  if self.VVROYi(posVal):
   return
  curIndex = self.VVpNKu(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVmbnq()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFD09G(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VVO81b(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCM2Fd.VVBYam(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CC2gVv.VVjWEY(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VVpNKu(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VV5KbI(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VV18o1(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVmbnq(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFD09G(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVVoOU(self):
  FFG53m(self, self.VVQAfi, title="Loading Lines ...", clearMsg=False)
 def VVQAfi(self):
  FFtMfC(self)
  VVzto2 = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVzto2.append((cap, FFFSaa(frm), str(frm), firstLine))
  if VVzto2:
   title = "Select Current Subtitle Line"
   VV1BNd  = self.VVwJ3J
   VVs5Sk = self.VVhfds
   VV91FP  = ("Select"   , self.VVSLS9 , [title])
   VVdn6T = ("Current Line" , self.VVodaF , [True])
   VVljWo = ("Reset Delay" , self.VV107O , [])
   VVDB15 = ("New Delay"  , self.VVVFZv   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VVsZoP  = (CENTER , CENTER, CENTER , LEFT    )
   VVR0r4 = FFqiz1(self, None, title=title, header=header, VVVC4T=VVzto2, VVsZoP=VVsZoP, VVx2iV=widths, VVwwGj=28, VV1BNd=VV1BNd, VVs5Sk=VVs5Sk, VV91FP=VV91FP, VVdn6T=VVdn6T, VVljWo=VVljWo, VVDB15=VVDB15
          , VVXbiY="#33002222", VVVy8H="#33001111", VVvi08="#33110011", VVbSmQ="#11ffff00", VVTrrJ="#0a334455", VVcd71="#22222222", VVVygK="#33002233")
  else:
   FFtMfC(self, "Cannot read lines !", 2000)
 def VVwJ3J(self, VVR0r4):
  self.subtLinesTable = VVR0r4
  if CFG.subtDelaySec.getValue():
   VVR0r4["keyYellow"].show()
   VVR0r4["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVR0r4["keyYellow"].hide()
  VVR0r4["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FFo6oa(VVR0r4["keyBlue"], "#22222222")
  VVR0r4.VVwfvv(BF(self.VVcxhk, VVR0r4))
  self.VVodaF(VVR0r4, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVgI0b)
  except:
   self.timerSubtLines.callback.append(self.VVgI0b)
  self.timerSubtLines.start(1000, False)
 def VVhfds(self, VVR0r4):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVR0r4.cancel()
 def VVgI0b(self):
  if self.subtLinesTable:
   VVR0r4 = self.subtLinesTable
   posVal, durVal = self.VVO81b()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVpNKu(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVR0r4.VV9JtZ(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVR0r4.VVsr2V(self.subtLinesTableNdx, row)
     row = VVR0r4.VV9JtZ(curIndex)
     row[0] = color + row[0]
     VVR0r4.VVsr2V(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VVSLS9(self, VVR0r4, Title):
  delay, color, allow = self.VVLARh(VVR0r4)
  if allow:
   self.VVhfds(VVR0r4)
   self.VVklNJ(delay, True)
  else:
   FFtMfC(VVR0r4, "Delay out of range", 1500)
 def VVodaF(self, VVR0r4, VVozbc, onlyColor=False):
  if VVR0r4:
   posVal, durVal = self.VVO81b()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVpNKu(posVal)
    if curIndex > -1:
     VVR0r4.VVwqjr(curIndex)
    else:
     ndx = self.VV5KbI(posVal)
     if ndx > -1:
      VVR0r4.VVwqjr(ndx)
 def VV107O(self, VVR0r4, title, txt, colList):
  if VVR0r4["keyYellow"].getVisible():
   self.VVklNJ(0, True)
   VVR0r4["keyYellow"].hide()
   self.VVodaF(VVR0r4, False)
 def VVcxhk(self, VVR0r4):
  delay, color, allow = self.VVLARh(VVR0r4)
  VVR0r4["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VVLARh(self, VVR0r4):
  lineTime = float(VVR0r4.VVVPDl()[2].strip())
  return self.VVqLGW(lineTime)
 def VVqLGW(self, lineTime):
  posVal, durVal = self.VVO81b()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VVSTv2
   else     : allow, color = False, VVnKNv
   delay = FF3qV5(val, -600, 600)
  return delay, color, allow
 def VVVFZv(self, VVR0r4, title, txt, colList):
  pass
 @staticmethod
 def VVhn9w(SELF):
  path, delay, enc = CCsETK.VVUQfp(SELF)
  return True if path else False
 @staticmethod
 def VVUQfp(SELF):
  path, delay, enc = CCsETK.VVJD7g(SELF)
  if not path:
   path = CCsETK.VVo3t2(SELF)
  return path, delay, enc
 @staticmethod
 def VVJD7g(SELF):
  srtCfgPath = CCsETK.VVqvFz(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FF5DO4(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVqvFz(SELF):
  fPath, fDir, fName = CCr5c7.VVt1SH(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CC2gVv.VVjWEY(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFZRjy(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VVo3t2(SELF):
  bestRatio = 0
  fPath, fDir, fName = CCr5c7.VVt1SH(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CCsETK.VVuecr(SELF)
    bLst, err = CCsETK.VV84zu(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVuecr(SELF):
  fPath, fDir, fName = CCr5c7.VVt1SH(SELF)
  if pathExists(fDir):
   files = FFT5mp(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VV84zu(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVpDkk():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVqFbQ(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CCsETK.VVg1eM()
 @staticmethod
 def VVg1eM():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CCfDKH(ScrollLabel):
 def __init__(self, parentSELF, text="", VVoKEy=True):
  ScrollLabel.__init__(self, text)
  self.VVoKEy   = VVoKEy
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VVYNWn  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVwwGj    = None
  self.parentW    = None
  self.parentH    = None
  self.firstTime    = True
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VVN2is ,
   "green"   : self.VVUEXo ,
   "yellow"  : self.VVIvVU ,
   "blue"   : self.VViSWm ,
   "up"   : self.pageUp   ,
   "down"   : self.pageDown   ,
   "left"   : self.pageUp   ,
   "right"   : self.pageDown   ,
   "last"   : BF(self.VVDZCx, 0) ,
   "0"    : BF(self.VVDZCx, 1) ,
   "next"   : BF(self.VVDZCx, 2) ,
   "pageUp"  : self.VVmjLr   ,
   "chanUp"  : self.VVmjLr   ,
   "pageDown"  : self.VVwK9Z   ,
   "chanDown"  : self.VVwK9Z
  }, -1)
 def VV8dj1(self, isResizable=True, VVhATy=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFD09G(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFo6oa(self.parentSELF["keyRedTop"], "#113A5365")
  FFnLuC(self.parentSELF, True)
  self.isResizable = isResizable
  if VVhATy:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVwwGj  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFo6oa(self, color)
 def VV8ZEE(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  lineheight  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  lines   = int(self.long_text.size().height() / lineheight)
  margin   = int(lineheight / 6)
  self.pageHeight = int(lines * lineheight)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  self.setText(self.message)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVYNWn - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVhno1()
 def pageUp(self):
  if self.VVYNWn > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVYNWn > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVmjLr(self):
  self.setPos(0)
 def VVwK9Z(self):
  self.setPos(self.VVYNWn-self.pageHeight)
 def VVLxz2(self):
  return self.VVYNWn <= self.pageHeight or self.curPos == self.VVYNWn - self.pageHeight
 def getText(self):
  return self.message
 def VVhno1(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVYNWn, 3))
   start = int((100 - vis) * self.curPos / (self.VVYNWn - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVwZYa=VVXWIl):
  old_VVLxz2 = self.VVLxz2()
  self.message = str(text)
  if self.pageHeight:
   self.long_text.setText(self.message)
   h = self.parentSELF.skinParam["bodyLineH"] * (len(self.message.splitlines()) + 1) - self.parentSELF.skinParam["marginTop"]
   h = max(h, self.long_text.calculateSize().height())
   self.VVYNWn = h if h > 0 else self.pageHeight
   if self.VVoKEy and self.VVYNWn > self.pageHeight:
    self.scrollbar.show()
    self.VVhno1()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVYNWn))
   if   VVwZYa == VVaZwj: self.setPos(0)
   elif VVwZYa == VVC4tc : self.VVwK9Z()
   elif old_VVLxz2    : self.VVwK9Z()
   if self.firstTime and len(self.message) > 0:
    self.firstTime = False
    self.setText(self.message, VVwZYa=VVwZYa)
 def appendText(self, text, VVwZYa=VVC4tc):
  self.setText(self.message + str(text), VVwZYa=VVwZYa)
 def VVIvVU(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVReYG(size)
 def VViSWm(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVReYG(size)
 def VVUEXo(self):
  self.VVReYG(self.VVwwGj)
 def VVReYG(self, VVwwGj):
  self.long_text.setFont(gFont(self.fontFamily, VVwwGj))
  self.setText(self.message, VVwZYa=VVXWIl)
  self.VVzVRx(calledFromFontSizer=True)
 def VVDZCx(self, align):
  self.long_text.setHAlign(align)
 def VVN2is(self):
  VVegP0 = []
  VVegP0.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Align Left"  , "left" ))
  VVegP0.append(("Align Center"  , "center" ))
  VVegP0.append(("Align Right"  , "right" ))
  if self.outputFileToSave:
   VVegP0.append(VVHMBI)
   VVegP0.append((FF6TiS("Save to File", VVpkep), "save" ))
  VVegP0.append(VVHMBI)
  VVegP0.append(("Keys (Shortcuts)" , "help" ))
  FFJcY1(self.parentSELF, self.VVBI9s, VVegP0=VVegP0, title="Text Option", width=500)
 def VVBI9s(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VVDZCx(0)
   elif item == "center" : self.VVDZCx(1)
   elif item == "right" : self.VVDZCx(2)
   elif item == "save"  : self.VVKqIj()
   elif item == "help"  : FFHU3T(self.parentSELF, "_help_txt", "Text Viewer (Keys)")
 def VVKqIj(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FFxJSp(expPath), self.outputFileToSave, FFxsfY())
   with open(outF, "w") as f:
    f.write(FF2AUs(self.message))
   FFcZi2(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFnHzu(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVzVRx(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVYNWn > 0 and self.pageHeight > 0:
   if self.VVYNWn < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVYNWn
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
