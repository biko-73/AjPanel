import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile
except: iMove = iCopyfile = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VV9qD9   = "v7.2.0"
VVMNa9    = "06-10-2022"
EASY_MODE    = 0
VVhhXf   = 0
VVqNGp   = 0
VVD9rK  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVaET3  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVXneu    = "/media/usb/"
VVQSjO    = "/usr/share/enigma2/picon/"
VVG2da = "/etc/enigma2/blacklist"
VVPZMJ   = "/etc/enigma2/"
VVS5Ek  = "ajpanel_update_url"
VVRq46   = "AJPan"
VVHClL  = "AUTO FIND"
VVmmlq  = "Custom"
VVRscb    = ""
VVMkfG = "Regular"
VVNwaK = "Fixed"
VVvCFn  = "AJP_Main"
VVaqQL = "AJP_Terminal"
VVNr4r = "AJP_System"
VVqTEg  = VVMkfG
VVn31f      = "-" * 80
VVc27s    = ("-" * 100, )
VVmICA    = ""
VV9ECk   = " && echo 'Successful' || echo 'Failed!'"
VVSzAX    = []
VVGEJv  = "Cannot continue (No Enough Memory) !"
VVxnW2  = False
VVxD6t  = False
VV4GLW = False
VV4Y67     = 0
VVZJjb    = 1
VVqa87    = 2
VV5PZD   = 3
VVzHOH    = 4
VVLTt8    = 5
VVZQMO = 6
VVkUAl = 7
VVzj07  = 8
VVAPDu   = 9
VVQ7RG  = 10
VVrWSS  = 11
WINDOW_SERVER_PIC_BROWSER = 12
VVih7X    = 13
VVgwrw   = 14
VVzq9n   = 15
VVBtm6    = 16
VVDsOp    = 17
VVVqvs  = 18
WINDOW_NO_BODY    = 19
VVr6rx   = 0
VVewqn   = 1
VVTsDD   = 2
def FFHfGO():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVqTEg
  if VVvCFn in lst and CFG.fontPathMain.getValue(): VVqTEg = VVvCFn
  else               : VVqTEg = VVMkfG
  return lst
 else:
  return [VVMkfG]
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[ ("v", "Virtual Keyboard"), ("s", "System Default") ])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[ ("d", "Directory Up"), ("e", "Exit File Manage") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices=[ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVHClL, visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.PIconsPath     = ConfigDirectory(default=VVQSjO, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVXneu, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
tmp = [("srt", "FORM SRT FILE"), ("#00FFFF", "Aqua"), ("#000000", "Black"), ("#0000FF", "Blue"), ("#FF00FF", "Fuchsia"), ("#808080", "Gray"), ("#008000", "Green"), ("#00FF00", "Lime"), ("#800000", "Maroon"), ("#000080", "Navy"), ("#808000", "Olive"), ("#800080", "Purple"), ("#FF0000", "Red"), ("#C0C0C0", "Silver"), ("#008080", "Teal"), ("#FFFFFF", "White"), ("#FFFF00", "Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVqTEg, choices=[(x,  x) for x in FFHfGO()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[ ("0", "Left"), ("1", "Center"), ("2", "Right") ])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FFnWSc():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVcEpc  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVhufn = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVcEpc  : return 0
  elif VVhufn : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
COLOR_SCHEME_NUM = FFnWSc()
VVB3E5 = VVycQx = VVpQzP = VV8DG7 = VVwtwf = VVwhxm = VVEirQ = VVKoYn = VVhAfh = VV80mJ = VVrhVl = VVJ6nn = VVhW2e = VV2RHA = VVDDRU = VVGCti = ""
def FFhYxV()  : FFcCHJ(FFVwxl())
def FFKDDY()  : FFcCHJ(FFGp80())
def FFDcD9(tDict): FFcCHJ(iDumps(tDict, indent=4, sort_keys=True))
def FFEx6C(*args): FFbkPl(True, True, *args)
def FFcCHJ(*args) : FFbkPl(True , False , *args)
def FFb3EM(*args): FFbkPl(False, False, *args)
def FFbkPl(addSep=True, isArray=True, *args):
 if VVhhXf:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(key.ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFZzph(*args):
 if VVhhXf:
  path = "/tmp/ajpanel_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FFb3EM("Added to : %s" % path)
def FFfjXg(txt, isAppend=True, ignoreErr=False):
 if VVhhXf:
  tm = FFh2Ho()
  err = ""
  if not ignoreErr:
   err = FFGp80()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFcCHJ(err)
  FFcCHJ("Output Log File : %s" % fileName)
def FFGp80():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFh2Ho()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFVwxl():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVeOhN = 0
def FFDYvQ():
 global VVeOhN
 VVeOhN = iTime()
def FFc3gt(txt=""):
 FFcCHJ(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VVeOhN)).rstrip("0"), txt))
VVSzAX = []
def FF1LZP(win):
 global VVSzAX
 if not win in VVSzAX:
  VVSzAX.append(win)
def FFsT0V(*args):
 global VVSzAX
 for win in VVSzAX:
  try:
   win.close()
  except:
   pass
 VVSzAX = []
def FF1d5o():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVWAfo = FF1d5o()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFvnmw()    : return PluginDescriptor(fnc=FFW2Ks, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FF01Fk()      : return getDescriptor(FFyXta , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFbT2s()     : return getDescriptor(FFZ1eR  , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFshui()  : return getDescriptor(FFCpRe, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FF26tG() : return getDescriptor(FFEtLF , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FFi5GR()  : return getDescriptor(FFVlDk , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFia2N()  : return getDescriptor(FFIPP0  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFftR3()    : return getDescriptor(FFcVGm, [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFbT2s() , FF01Fk() , FFvnmw() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFshui())
  result.append(FF26tG())
  result.append(FFi5GR())
  result.append(FFia2N())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFftR3())
 return result
def FFW2Ks(reason, **kwargs):
 if reason == 0:
  FFVEyh()
  if "session" in kwargs:
   session = kwargs["session"]
   FF2e5f(session)
   CCljOF(session)
def FFyXta(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFZ1eR, PLUGIN_NAME, 45)]
 else:
  return []
def FFZ1eR(session, **kwargs):
 session.open(Main_Menu)
def FFCpRe(session, **kwargs):
 session.open(CC5DZc)
def FFEtLF(session, **kwargs):
 session.open(CC0A1M)
def FFVlDk(session, **kwargs):
 CCDmyf.VVtxwR(session, isFromExternal=True)
def FFIPP0(session, **kwargs):
 FFXRBr(session, reopen=True)
def FFcVGm(session, **kwargs):
 session.open(CChafy, fncMode=CChafy.VVAtR5)
def FFM274():
 FF4djp(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFshui(), FF26tG(), FFi5GR(), FFia2N() ])
 FF4djp(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFftR3() ])
def FF4djp(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VVHz12 = None
def FFVEyh():
 try:
  global VVHz12
  if VVHz12 is None:
   VVHz12    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFpMmR
  ChannelContextMenu.FFRthd = FFRthd
 except:
  pass
def FFpMmR(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVHz12(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , BF(SELF.FFRthd, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , BF(SELF.FFRthd, title1, csel, isFind=True))))
def FFRthd(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFJ0rg(refCode)
 except:
  pass
 self.session.open(BF(CCD0SJ, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FF2e5f(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = BF(FFj1WY, session, "lok")
 hk.actions['longCancel'] = BF(FFj1WY, session, "lesc")
 hk.actions['longRed']  = BF(FFj1WY, session, "lred")
def FFj1WY(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CC4zab.VVG6an:
    CC4zab.VVG6an.close()
   if not CCDmyf.VVek82:
    CCDmyf.VVtxwR(session, isFromExternal=True)
  except:
   pass
def FF72vQ(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FF0Q0u(SELF, title="", addLabel=False, addScrollLabel=False, VVMYdC=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FF3zTd()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCzOJn(SELF)
 if VVMYdC:
  SELF["myMenu"] = MenuList(VVMYdC)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVqqT1        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFINwU(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFeywP, SELF, "0") ,
  "1" : BF(FFeywP, SELF, "1") ,
  "2" : BF(FFeywP, SELF, "2") ,
  "3" : BF(FFeywP, SELF, "3") ,
  "4" : BF(FFeywP, SELF, "4") ,
  "5" : BF(FFeywP, SELF, "5") ,
  "6" : BF(FFeywP, SELF, "6") ,
  "7" : BF(FFeywP, SELF, "7") ,
  "8" : BF(FFeywP, SELF, "8") ,
  "9" : BF(FFeywP, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFAy3W, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFeywP(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVGCti:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVGCti + SELF.keyPressed + VVycQx)
    txt = VVycQx + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFAcfo(SELF, txt)
def FFAy3W(SELF, tableObj, colNum):
 FFAcfo(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VVjS0j(i)
     break
 except:
  pass
def FFzp0C(SELF, setMenuAction=True):
 if setMenuAction:
  global VVmICA
  VVmICA = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FF3zTd():
 return ("  %s" % VVmICA)
def FF970D(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FF3RM7(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFSOpM(color):
 return parseColor(color).argb()
def FFCE16(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFaCb6(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFuFCB(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFrfWO(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVGCti)
 else:
  return ""
def FFEL4q(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVn31f, word, VVn31f, VVGCti)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVn31f, word, VVn31f)
def FFXe6i(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVGCti
def FFHmje(color):
 if color: return "echo -e '%s' %s;" % (VVn31f, FFrfWO(VVn31f, VVrhVl))
 else : return "echo -e '%s';" % VVn31f
def FF9bzo(title, color):
 title = "%s\n%s\n%s\n" % (VVn31f, title, VVn31f)
 return FFXe6i(title, color)
def FF4IYg(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FF3Wvr(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFC8Ey(callBackFunction):
 tCons = CCKdbR()
 tCons.ePopen("echo", BF(FFEDZx, callBackFunction))
def FFEDZx(callBackFunction, result, retval):
 callBackFunction()
def FFZmix(SELF, fnc, title="Processing ...", clearMsg=True):
 FFAcfo(SELF, title)
 tCons = CCKdbR()
 tCons.ePopen("echo", BF(FFH4SZ, SELF, fnc, clearMsg))
def FFH4SZ(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFAcfo(SELF)
def FFPjNy(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVGEJv
  else       : return ""
def FFEUax(cmd):
 txt = FFPjNy(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFY14S(cmd):
 lines = FFEUax(cmd)
 if lines: return lines[0]
 else : return ""
def FF0H0y(SELF, cmd):
 lines = FFEUax(cmd)
 VVbdQX = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVbdQX.append((key, val))
  elif line:
   VVbdQX.append((line, ""))
 if VVbdQX:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFMPky(SELF, None, header=header, VVL1iO=VVbdQX, VVLkOa=widths, VVJfxh=28)
 else:
  FFlXTd(SELF, cmd)
def FFlXTd(    SELF, cmd, **kwargs): SELF.session.open(CCvLX1, VVOBG5=cmd, VVfqvf=True, VVr1DU=VVewqn, **kwargs)
def FFEJxo(  SELF, cmd, **kwargs): SELF.session.open(CCvLX1, VVOBG5=cmd, **kwargs)
def FFaGWF(   SELF, cmd, **kwargs): SELF.session.open(CCvLX1, VVOBG5=cmd, VVhIhd=True, VVrAxc=True, VVr1DU=VVewqn, **kwargs)
def FFitBw(  SELF, cmd, **kwargs): SELF.session.open(CCvLX1, VVOBG5=cmd, VVhIhd=True, VVrAxc=True, VVr1DU=VVTsDD, **kwargs)
def FFrhsY(  SELF, cmd, **kwargs): SELF.session.open(CCvLX1, VVOBG5=cmd, VVaU0K=True , **kwargs)
def FF8XqZ( SELF, cmd, **kwargs): SELF.session.open(CCvLX1, VVOBG5=cmd, VVQkfz=True   , **kwargs)
def FFSyy7( SELF, cmd, **kwargs): SELF.session.open(CCvLX1, VVOBG5=cmd, VV1P59=True  , **kwargs)
def FFVKmy(cmd):
 return cmd + " > /dev/null 2>&1"
def FFy6bC(cmd):
 return cmd + " 2> /dev/null"
def FFrViP():
 return " > /dev/null 2>&1"
def FFqrNW(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFcbot(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFwr6I():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFY14S(cmd)
VVOEW0     = 0
VVlqUC      = 1
VV8UyW   = 2
VVF4LK      = 3
VV4LAz      = 4
VVOVp4     = 5
VVuVG6     = 6
VVIf8A = 7
VVz9Zr = 8
VVpCbq = 9
VV5bJt  = 10
VVa96X     = 11
VVDj0x  = 12
VVYhjR  = 13
def FF7FNT(parmNum, grepTxt):
 if   parmNum == VVOEW0  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVlqUC   : param = ["list"   , "apt list" ]
 elif parmNum == VV8UyW: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFwr6I()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FF9JgI(parmNum, package):
 if   parmNum == VVF4LK      : param = ["info"      , "apt show"         ]
 elif parmNum == VV4LAz      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVOVp4     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVuVG6     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVIf8A : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVz9Zr : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VVpCbq : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VV5bJt  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVa96X     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVDj0x  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVYhjR  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFwr6I()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FF0m4B():
 result = FFY14S("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FF9JgI(VVuVG6 , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFVKmy("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFVKmy("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFrfWO(failed1, VVrhVl))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFrfWO(failed2, VVrhVl))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFrfWO(failed3, VVpQzP))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFcB05(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FF9JgI(VVuVG6 , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFVKmy("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFrfWO(failed1, VVrhVl))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFrfWO(failed2, VVpQzP))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFPbOp(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFVKmy('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFVKmy("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFQgne(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCSqSs.VVDAl3()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FFgYB4(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFQgne(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFVPiE(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFehaw(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFQgne(path, maxSize=maxSize, encLst=encLst)
  if lines: FF4gok(SELF, lines, title=title, VVr1DU=VVewqn)
  else : FFm1Rb(SELF, path, title=title)
 else:
  FF6iwf(SELF, path, title)
def FFqh4M(SELF, path, title):
 if fileExists(path):
  txt = FFQgne(path)
  txt = txt.replace("#W#", VVGCti)
  txt = txt.replace("#Y#", VVJ6nn)
  txt = txt.replace("#G#", VVycQx)
  txt = txt.replace("#C#", VVhW2e)
  txt = txt.replace("#P#", VVwtwf)
  FF4gok(SELF, txt, title=title)
 else:
  FF6iwf(SELF, path, title)
def FFi8R0(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FF9E33(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FF5sxC(parent)
 else    : return FFS9Oz(parent)
def FFUGmb(path):
 return os.path.basename(os.path.normpath(path))
def FFehaw(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FF2PD3(path):
 try:
  os.remove(path)
 except:
  pass
def FF5sxC(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFS9Oz(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FF4aRg():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVD9rK)
 paths.append(VVD9rK.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFi8R0(ba)
 for p in list:
  p = ba + p + VVD9rK
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVRq46, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVD9rK, VVRq46 , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVN3PN, VVlId3 = FF4aRg()
def FFaSmH():
 def VVwZ8n(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VV1yyN   = VVwZ8n(CFG.backupPath, CCaoCm.VVIb7e())
 VVs6Xc   = VVwZ8n(CFG.downloadedPackagesPath, t)
 VV165t  = VVwZ8n(CFG.exportedTablesPath, t)
 VVKC08  = VVwZ8n(CFG.exportedPIconsPath, t)
 VVTTVU   = VVwZ8n(CFG.packageOutputPath, t)
 global VVXneu
 VVXneu = FF5sxC(CFG.backupPath.getValue())
 if VV1yyN or VVTTVU or VVs6Xc or VV165t or VVKC08 or oldMovieDownloadPath:
  configfile.save()
 return VV1yyN, VVTTVU, VVs6Xc, VV165t, VVKC08, oldMovieDownloadPath
def FF60Iv(path):
 path = FFS9Oz(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FF3zFx(SELF, pathList, tarFileName, addTimeStamp=True):
 VVL1iO = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVL1iO.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVL1iO.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVL1iO.append(path)
 if not VVL1iO:
  FFu1fZ(SELF, "Files not found!")
 elif not pathExists(VVXneu):
  FFu1fZ(SELF, "Path not found!\n\n%s" % VVXneu)
 else:
  VVVgGW = FF5sxC(VVXneu)
  tarFileName = "%s%s" % (VVVgGW, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFcOP9())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVL1iO:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVn31f
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFrfWO(tarFileName, VVhAfh))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFrfWO(failed, VVhAfh))
  cmd += "fi;"
  cmd +=  sep
  FFEJxo(SELF, cmd)
def FFKT7W(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFwUhu(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFwUhu(SELF["keyInfo"], "info")
def FFwUhu(barObj, fName):
 path = "%s%s%s" % (VVlId3, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFwqep(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFGSRq(satNum)
  return satName
def FFGSRq(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFYM1A(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFwqep(val)
  else  : sat = FFGSRq(val)
 return sat
def FFtFKL(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFwqep(num)
 except:
  pass
 return sat
def FFUIzI(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFR3hA(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFhyVK(info, iServiceInformation.sServiceref)
   prov = FFhyVK(info, iServiceInformation.sProvider)
   state = str(FFhyVK(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFQ9UD(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFfknX(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFhyVK(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFQWno(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFJ0rg(refCode):
 info = FF97yF(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFVUlP(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FF1qvC(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FF97yF(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVcQ52 = eServiceCenter.getInstance()
  if VVcQ52:
   info = VVcQ52.info(service)
 return info
def FFI9Ee(SELF, refCode, VVtcz9=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFQaed(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVtcz9:
   FFduuq(SELF, isFromSession)
 try:
  VVGXkF = InfoBar.instance
  if VVGXkF:
   VVZe0z = VVGXkF.servicelist
   if VVZe0z:
    servRef = eServiceReference(refCode)
    VVZe0z.saveChannel(servRef)
 except:
  pass
def FFQaed(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCEwD2()
    if pr.VVy3E7(refCode, chName, decodedUrl, iptvRef):
     pr.VVWlEn(SELF, isFromSession)
def FFQ9UD(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFnRfV(url): return FFBuQd(url) or FFAQER(url)
def FFBuQd(url)  : return any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFAQER(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFfknX(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFxspG(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFxspG(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFfLv9(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FF6R75(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFl7mx(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FF9U3V(txt):
 try:
  return FF6R75(FFl7mx(txt)) == txt
 except:
  return False
def FFFgxj(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FF5sxC(newPath), patt))
def FFduuq(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: CCDmyf.VVtxwR(session, isFromExternal=isFromSession)
 else      : FFXRBr(session, reopen=True)
def FFXRBr(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FFXRBr, session), CC4zab)
  except:
   try:
    FF2TDl(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFJN2c(refCode):
 tp = CChwwz()
 if tp.VVFpqU(refCode) : return True
 else        : return False
def FFR0a2(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFSSJm(True)
     return True
 return False
def FFSSJm(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FFQyzj()
def FFQyzj():
 VVGXkF = InfoBar.instance
 if VVGXkF:
  VVZe0z = VVGXkF.servicelist
  if VVZe0z:
   VVZe0z.setMode()
def FFsJR6(root):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVcQ52 = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVcQ52.info(service)
    lst.append((service.toString(), info.getName(service)))
 except:
  pass
 return lst
def FFhcDs():
 VVU8J6 = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVyF1f = list(VVU8J6)
 return VVyF1f, VVU8J6
def FFaAOh():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFeqiy(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FF2ogC(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFddDI():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFcOP9():
 return FFddDI().replace(" ", "_").replace("-", "").replace(":", "")
def FFZcBU(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFh2Ho():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFmy2V(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CC0A1M.VVpVfO(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CC0A1M.VVnS9E(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFVKmy("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFFN8J(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FFmxIl(num):
 return "s" if num > 1 else ""
def FFCk9k(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FF8vMy(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FF0EnI(a, b):
 return (a > b) - (a < b)
def FF03SQ(a, b):
 def VVVls4(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VVVls4(a)
 b = VVVls4(b)
 return (a > b) - (a < b)
def FFYDEV(mycmp):
 class CCeuXI(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CCeuXI
def FF5VuW(SELF, message, title="", VV2r3B=None):
 SELF.session.openWithCallback(VV2r3B, CCdySx, title=title, message=message, VVh63k=True)
def FF4gok(SELF, message, title="", VVr1DU=VVewqn, VV2r3B=None, **kwargs):
 SELF.session.openWithCallback(VV2r3B, CCdySx, title=title, message=message, VVr1DU=VVr1DU, **kwargs)
def FFu1fZ(SELF, message, title="")  : FF2TDl(SELF.session, message, title)
def FF6iwf(SELF, path, title="") : FF2TDl(SELF.session, "File not found !\n\n%s" % path, title)
def FFm1Rb(SELF, path, title="") : FF2TDl(SELF.session, "File is empty !\n\n%s"  % path, title)
def FF0x3g(SELF, title="")  : FF2TDl(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FF2TDl(session, message, title="") : session.open(BF(CC9Izs, title=title, message=message))
def FFSAou(SELF, VV2r3B, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VV2r3B, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VV2r3B, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFu1fZ(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFlOO5(SELF, callBack_Yes, VVbvpB, callBack_No=None, title="", VV6ttc=False, VVxvUW=True):
 return SELF.session.openWithCallback(BF(FF9OP3, callBack_Yes, callBack_No)
          , BF(CChHGv, title=title, VVbvpB=VVbvpB, VVxvUW=VVxvUW, VV6ttc=VV6ttc))
def FF9OP3(callBack_Yes, callBack_No, FFlOO5ed):
 if FFlOO5ed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFAcfo(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FFaCb6(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFDjIx(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFz45k(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VVu5n0 = eTimer()
def FFDjIx(SELF, milliSeconds=1000):
 SELF.onClose.append(BF(FFiRyN, SELF))
 fnc = BF(FFiRyN, SELF)
 try:
  t = VVu5n0.timeout.connect(fnc)
 except:
  VVu5n0.callback.append(fnc)
 VVu5n0.start(milliSeconds, 1)
def FFiRyN(SELF):
 VVu5n0.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFMPky(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCrcNA, **kwargs))
  else   : win = SELF.session.open(BF(CCrcNA, **kwargs))
  FF1LZP(win)
  return win
 except:
  return None
def FFcKE0(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CCg6yd, **kwargs))
 FF1LZP(win)
 return win
def FFYdlI(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFfM6H(SELF, **kwargs):
 SELF.session.open(CChafy, **kwargs)
def FFyHsQ(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFjTr6(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFEfAQ(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVqTEg, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFIvVk(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFEfAQ(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = (max(minRows, len(menuObj.list))) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFB0L6():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFhgll(VVJfxh):
 screenSize  = FFB0L6()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVJfxh)
 return bodyFontSize
def FFdLhG(VVJfxh, extraSpace):
 font = gFont(VVqTEg, VVJfxh)
 VVIJkE = fontRenderClass.getInstance().getLineHeight(font) or (VVJfxh * 1.25)
 return int(VVIJkE + VVIJkE * extraSpace)
def FFTWzO(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True):
 screenSize = FFB0L6()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVqTEg, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFdLhG(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVqTEg, titleFontSize, alignLeftCenter)
 if winType == VV4Y67 or winType == VVZJjb:
  if winType == VVZJjb : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVVqvs:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == VVDsOp:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVqTEg, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d"    position="1,%d" size="%d,%d" zPosition="6" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VVih7X:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FF5VuWL = b2Left2 + timeW + marginLeft
  FF5VuWW = b2Left3 - marginLeft - FF5VuWL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FF5VuWL , b2Top, FF5VuWW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVgwrw:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVzHOH:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVqa87:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VV5PZD:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVqTEg, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVqTEg, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVQ7RG:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVqTEg, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVzq9n:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVqTEg, fontH, alignCenter)
 elif winType in (VVrWSS, WINDOW_SERVER_PIC_BROWSER):
  if winType == VVrWSS: totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  else         : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - boxT) / totRows)
  picH = int(boxH * picR)
  lblH = int(boxH * lblR) - 2
  lblT = boxT + picH + 2
  lblFont = int(lblH * 0.65)
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVrWSS:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h , fg, bg[i]  , VVqTEg, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h , fg, bg[i+3], VVqTEg, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVqTEg, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVqTEg, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h , fg, bg, VVqTEg, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h , fg, bg, VVqTEg, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00FFFF00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2, transpBG)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVqTEg, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVBtm6:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVLTt8:
  tmp += '<widget name="myPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (marginLeft, bodyTop, bodyW, bodyH)
 else:
  if   winType == VVkUAl : align = alignLeftCenter
  elif winType == VVZQMO : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVAPDu:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVqTEg
  if usefixedFont and winType == VVZQMO:
   fLst = FFHfGO()
   if   VVaqQL in fLst and CFG.fontPathTerm.getValue(): fontName = VVaqQL
   elif VVNwaK in fLst         : fontName = VVNwaK
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVJfxh = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVqTEg, VVJfxh, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVjLdB = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVqTEg, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVjLdB[i], VVqTEg, barFont, alignCenter)
   left += btnW + gap
 if winType == VVZQMO:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVjLdB = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVjLdB[i], VVqTEg, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFTWzO(VV4Y67, 800, 950, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.VVLKPg = ""
  self.themsList  = []
  s = "  "
  VVMYdC = []
  if VVqNGp:
   VVMYdC.append(("-- MY TEST --"    , "myTest"   ))
  VVMYdC.append((s + "File Manager"     , "FileManager"  ))
  VVMYdC.append(VVc27s)
  VVMYdC.append((s + "Services/Channels"   , "ChannelsTools" ))
  VVMYdC.append((s + "IPTV"       , "IptvTools"  ))
  VVMYdC.append((s + "PIcons"      , "PIconsTools"  ))
  VVMYdC.append((s + "SoftCam"      , "SoftCam"   ))
  VVMYdC.append(VVc27s)
  VVMYdC.append((s + "Plugins"      , "PluginsTools" ))
  VVMYdC.append((s + "Terminal"      , "Terminal"  ))
  VVMYdC.append((s + "Backup & Restore"    , "BackupRestore" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append((s + "Date/Time"     , "Date_Time"  ))
  VVMYdC.append((s + "Check Internet Connection" , "CheckInternet" ))
  self.totalItems = len(VVMYdC)
  FF0Q0u(self, VVMYdC=VVMYdC)
  FF970D(self["keyRed"] , "Exit")
  FF970D(self["keyGreen"] , "Settings")
  FF970D(self["keyYellow"], "Dev. Info.")
  FF970D(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close      ,
   "green"   : self.VV6nUe     ,
   "yellow"  : self.VVLJ6U     ,
   "blue"   : self.VVLCP8     ,
   "info"   : self.VVLCP8     ,
   "next"   : self.VVNqNz     ,
   "menu"   : self.VVN0hy   ,
   "0"    : BF(self.VVlgjx, 0)  ,
   "1"    : BF(self.VVV5qI, 1)   ,
   "2"    : BF(self.VVV5qI, 2)   ,
   "3"    : BF(self.VVV5qI, 3)   ,
   "4"    : BF(self.VVV5qI, 4)   ,
   "5"    : BF(self.VVV5qI, 5)   ,
   "6"    : BF(self.VVV5qI, 6)   ,
   "7"    : BF(self.VVV5qI, 7)   ,
   "8"    : BF(self.VVV5qI, 8)   ,
   "9"    : BF(self.VVV5qI, 9)
  })
  self.onShown.append(self.VViGDa)
  self.onClose.append(self.onExit)
  global VVxnW2, VVxD6t, VV4GLW
  VVxnW2 = VVxD6t = VV4GLW = False
 def VVqqT1(self):
  item = FFzp0C(self)
  self.VVV5qI(item)
 def VVV5qI(self, item):
  if item is not None:
   if item in range(1, 9):
    self["myMenu"].moveToIndex(item + 1)
    item = FFzp0C(self)
   if   item == "myTest"     : self.VVjFvQ()
   elif item in ("FileManager"  , 1) : self.session.open(CC5DZc)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCFb9t)
   elif item in ("IptvTools"  , 3) : self.session.open(CC0A1M)
   elif item in ("PIconsTools"  , 4) : self.VVZ8eD()
   elif item in ("SoftCam"   , 5) : self.session.open(CC9IhO)
   elif item in ("PluginsTools" , 6) : self.session.open(CClZ50)
   elif item in ("Terminal"  , 7) : self.session.open(CCm19w)
   elif item in ("BackupRestore" , 8) : self.session.open(CCLP9M)
   elif item in ("Date_Time"  , 9) : self.session.open(CCFZqx)
   elif item in ("CheckInternet" , 10) : self.session.open(CCWlYX)
   else         : self.close()
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FF4IYg(self["myMenu"])
  FFIvVk(self)
  FFyHsQ(self)
  title = "  %s - %s" % (PLUGIN_NAME, VV9qD9)
  self["myTitle"].setText(title)
  VV1yyN, VVTTVU, VVs6Xc, VV165t, VVKC08, oldMovieDownloadPath = FFaSmH()
  self.VVQTxl()
  if VV1yyN or VVTTVU or VVs6Xc or VV165t or VVKC08 or oldMovieDownloadPath:
   VV1fOZ = lambda path, subj: "%s:\n%s\n\n" % (subj, FFXe6i(path, VV8DG7)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VV1fOZ(VV1yyN   , "Backup/Restore Path"    )
   txt += VV1fOZ(VVTTVU  , "Created Package Files (IPK/DEB)" )
   txt += VV1fOZ(VVs6Xc  , "Download Packages (from feeds)" )
   txt += VV1fOZ(VV165t , "Exported Tables"     )
   txt += VV1fOZ(VVKC08 , "Exported PIcons"     )
   txt += VV1fOZ(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FF4gok(self, txt, title="Settings Paths")
  if (EASY_MODE or VVhhXf or VVqNGp):
   FFaCb6(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFAcfo(self, "Welcome", 300)
  FFC8Ey(BF(self.VVU3Bv, title))
 def VVU3Bv(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCaoCm.VVSXLi()
   if url:
    newWebVer = CCaoCm.VVDh0E(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFVKmy("rm /tmp/ajpanel*"))
  global VVxnW2, VVxD6t, VV4GLW
  VVxnW2 = VVxD6t = VV4GLW = False
 def VVlgjx(self, digit):
  self.VVLKPg += str(digit)
  ln = len(self.VVLKPg)
  global VVxnW2, VV4GLW
  if ln == 4:
   if self.VVLKPg == "0" * ln:
    VVxnW2 = True
    FFaCb6(self["myTitle"], "#800080")
   else:
    self.VVLKPg = "x"
  elif self.VVLKPg == "0" * 8:
   VV4GLW = True
 def VVNqNz(self):
  self.VVLKPg += ">"
  if self.VVLKPg == "0" * 4 + ">" * 2:
   global VVxD6t
   VVxD6t = True
   FFaCb6(self["myTitle"], "#dd5588")
 def VVZ8eD(self):
  found = False
  pPath = CC2wnB.VV6OCP()
  if pathExists(pPath):
   for fName, fType in CC2wnB.VVa0Bw(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CC2wnB)
  else:
   VVMYdC = []
   VVMYdC.append(("PIcons Tools" , "CC2wnB" ))
   VVMYdC.append(VVc27s)
   VVMYdC.append(CC2wnB.VV73ej())
   VVMYdC.append(VVc27s)
   VVMYdC += CC2wnB.VVpF1T()
   FFcKE0(self, self.VVQNua, VVMYdC=VVMYdC)
 def VVQNua(self, item=None):
  if item:
   if   item == "CC2wnB"   : self.session.open(CC2wnB)
   elif item == "VV7tbL"  : CC2wnB.VV7tbL(self)
   elif item == "VVdcHQ"  : CC2wnB.VVdcHQ(self)
   elif item == "findPiconBrokenSymLinks" : CC2wnB.VVBSOH(self, True)
   elif item == "FindAllBrokenSymLinks" : CC2wnB.VVBSOH(self, False)
 def VV6nUe(self):
  self.session.open(CCaoCm)
 def VVLJ6U(self):
  self.session.open(CCld2v)
 def VVLCP8(self):
  changeLogFile = VVlId3 + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FFgYB4(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFXe6i("\n%s\n%s\n%s" % (VVn31f, line, VVn31f), VVrhVl, VVGCti)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FFXe6i(line, VVycQx, VVGCti)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FF4gok(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VV9qD9, PLUGIN_DESCRIPTION), VVJfxh=26)
 def VVN0hy(self):
  title = "Style Changer"
  c1, c2, c3, c4 = VV80mJ, VV8DG7, VVJ6nn, VVwhxm
  VVMYdC = []
  VVMYdC.append((c1 + "Change Title Colors"    , "title"  ))
  VVMYdC.append((c1 + "Change Menu Area Colors"   , "body"  ))
  VVMYdC.append((c1 + "Change Menu Pointer Colors"  , "cursor"  ))
  VVMYdC.append((c1 + "Change Bottom Bar Colors"  , "bar"   ))
  VVMYdC.append((c2 + "Reset Colors"     , "resetColor" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append((c3 + "Change %s Font" % PLUGIN_NAME , "mainFont" ))
  VVMYdC.append((c3 + "Change Termianl Font"    , "termFont" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append((c4 + "Change System Font"     , "sysFont"  ))
  FFcKE0(self, BF(self.VVmkxA, title), VVMYdC=VVMYdC, width=800, title=title)
 def VVmkxA(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VV9Mck()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VV0ttU, tDict, item), CC3Y09, defFG=fg, defBG=bg)
   elif item == "resetColor" : FFlOO5(self, self.VVvTTh, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVBCK5(VVvCFn  )
   elif item == "termFont"  : self.VVBCK5(VVaqQL)
   elif item == "sysFont"  : self.VVBCK5(VVNr4r  )
 def VVwgDf(self):
  return VVXneu + "ajpanel_colors"
 def VV9Mck(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVwgDf()
  if fileExists(p):
   txt = FFQgne(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VV0ttU(self, tDict, item, fg, bg):
  if fg:
   self.VVjXOY(item, fg)
   self.VVUPB4(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVQUNW(tDict)
 def VVQUNW(self, tDict):
   p = self.VVwgDf()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVjXOY(self, item, fg):
  if   item == "title" : FFCE16(self["myTitle"], fg)
  elif item == "body"  :
   FFCE16(self["myMenu"], fg)
   FFCE16(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FFaCb6(self["myBar"], fg)
   FFCE16(self["keyRed"], fg)
   FFCE16(self["keyGreen"], fg)
   FFCE16(self["keyYellow"], fg)
   FFCE16(self["keyBlue"], fg)
 def VVUPB4(self, item, bg):
  if   item == "title" : FFaCb6(self["myTitle"], bg)
  elif item == "body"  :
   FFaCb6(self["myMenu"], bg)
   FFaCb6(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFaCb6(self["myBar"], bg)
 def VVvTTh(self):
  os.system(FFVKmy("rm %s" % self.VVwgDf()))
  self.close()
 def VVQTxl(self):
  tDict = self.VV9Mck()
  self.VVkO0z(tDict, "title")
  self.VVkO0z(tDict, "body")
  self.VVkO0z(tDict, "cursor")
  self.VVkO0z(tDict, "bar")
 def VVkO0z(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVjXOY(name, fg)
  if bg: self.VVUPB4(name, bg)
 def VVBCK5(self, name):
  if   name == VVvCFn : fPath, title = CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif name == VVaqQL: fPath, title = CFG.fontPathTerm.getValue(), "Terminal "
  elif name == VVNr4r : fPath, title = CFG.fontPathSys.getValue() , "System"
  title  = "Change %s Font" % title
  VVMYdC = []
  default = None
  fntPath = resolveFilename(SCOPE_FONTS)
  for path in FFFgxj(fntPath, "*.[tToO][tT][fF]"):
   VVMYdC.append((os.path.splitext(os.path.basename(path))[0], path))
  txt = " (Requires GUI Restart)" if name == VVNr4r else ""
  VVMYdC.sort(key=lambda x: x[0].lower())
  VVMYdC.insert(0, VVc27s)
  VVMYdC.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if fPath:
   for ndx, item in enumerate(VVMYdC):
    if len(item) == 2 and item[1] == fPath:
     VVMYdC[ndx] = (VVhAfh + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVMYdC[curIndex] = (VVhAfh + VVMYdC[curIndex][0], VVMYdC[curIndex][1])
  if VVMYdC:
   menuInstance = FFcKE0(self, BF(self.VVLdvQ, name, title), title=title, VVMYdC=VVMYdC, VVI8Pk="#00221111", VV2s6D="#00221111")
   menuInstance.VVRBpj(curIndex)
  else:
   FFu1fZ(self, "No fonts found in:\n\n%s" % fntPath, title=title)
 def VVLdvQ(self, name, title, item):
  if item:
   path = "" if item == "DEFAULT" else item
   if   name == VVvCFn : FF72vQ(CFG.fontPathMain, path)
   elif name == VVaqQL: FF72vQ(CFG.fontPathTerm, path)
   elif name == VVNr4r : FF72vQ(CFG.fontPathSys , path)
   err = Main_Menu.VVTEfD(name)
   if err          : FFu1fZ(self, err, title=title)
   elif name == VVvCFn   : self.close()
   elif name == VVaqQL  : FFAcfo(self, "Terminal font applied", 1500, isGrn=True)
   elif name == VVNr4r and path : FFAcfo(self, "System font applied", 1500, isGrn=True)
   elif name == VVNr4r   : FFlOO5(self, BF(Main_Menu.VVQkfz, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VVQkfz(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVTEfD(name):
  if   name == VVvCFn : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VVaqQL: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VVNr4r : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FFHfGO()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VVNr4r:
   nameLst = []
   for nm in FFHfGO():
    if not nm in (VVvCFn, VVaqQL):
     nameLst.append(nm)
  else:
   nameLst = [name]
  for fntName in nameLst:
   totDone = 0
   try:
    addFont(path, fntName, 100, repl)
    totDone += 1
   except:
    try:
     addFont(path, fntName, 100, repl, 0)
     totDone += 1
    except:
     pass
  if totDone > 0: FFHfGO()
  else    : return "Could not add font"
 def VVjFvQ(self):
  CCDmyf.VVtxwR(self.session)
class CCSqSs():
 @staticmethod
 def VVDAl3():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVtdya(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFMPky(SELF, None, VVL1iO=lst, VVJfxh=30, VVVz9Q=True)
 @staticmethod
 def VVcaEq(path, SELF=None):
  for enc in CCSqSs.VVDAl3():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFu1fZ(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVRJTe(SELF, path, cbFnc, defEnc="utf8", onlyWorkingEnc=True, title="Select Encoding"):
  FFAcfo(SELF)
  lst = CCSqSs.VVJgIR(path, onlyWorkingEnc=onlyWorkingEnc)
  if lst:
   VVMYdC = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if defEnc == enc:
     txt = FFXe6i(txt, VVhAfh)
    VVMYdC.append((txt, enc))
   if onlyWorkingEnc: VVI8Pk, VV2s6D = "#22003344", "#22002233"
   else    : VVI8Pk, VV2s6D = "#22220000", "#22220000"
   FFcKE0(SELF, cbFnc, title=title, VVMYdC=VVMYdC, width=900, VVI8Pk=VVI8Pk, VV2s6D=VV2s6D)
  else:
   FFAcfo(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVJgIR(path, onlyWorkingEnc=True):
  encLst = []
  cPath = VVlId3 + "codecs"
  if fileExists(cPath):
   lines = FFgYB4(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCSqSs.VVDAl3())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if onlyWorkingEnc:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CCld2v(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFTWzO(VV4Y67, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVMYdC = []
  VVMYdC.append(("Settings File"        , "SettingsFile"   ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Box Info"          , "VV7otE"    ))
  VVMYdC.append(("Tuners Info"         , "VVTV2n"   ))
  VVMYdC.append(("Python Version"        , "VVZ4LX"   ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Screen Size"         , "ScreenSize"    ))
  VVMYdC.append(("Language/Locale"        , "Locale"     ))
  VVMYdC.append(("Processor"         , "Processor"    ))
  VVMYdC.append(("Operating System"        , "OperatingSystem"   ))
  VVMYdC.append(("Drivers"          , "drivers"     ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("System Users"         , "SystemUsers"    ))
  VVMYdC.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVMYdC.append(("Uptime"          , "Uptime"     ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Host Name"         , "HostName"    ))
  VVMYdC.append(("MAC Address"         , "MACAddress"    ))
  VVMYdC.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVMYdC.append(("Network Status"        , "NetworkStatus"   ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Disk Usage"         , "VVOYPb"    ))
  VVMYdC.append(("Mount Points"         , "MountPoints"    ))
  VVMYdC.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVMYdC.append(("USB Devices"         , "USB_Devices"    ))
  VVMYdC.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVMYdC.append(("Directory Size"        , "DirectorySize"   ))
  VVMYdC.append(("Memory"          , "Memory"     ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVMYdC.append(("Running Processes"       , "RunningProcesses"  ))
  VVMYdC.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FF0Q0u(self, VVMYdC=VVMYdC, title="Device Information")
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FF4IYg(self["myMenu"])
  FFIvVk(self)
 def VVqqT1(self):
  global VVmICA
  VVmICA = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCBGBj)
   elif item == "VV7otE"    : self.VV7otE()
   elif item == "VVTV2n"   : self.VVTV2n()
   elif item == "VVZ4LX"   : self.VVZ4LX()
   elif item == "ScreenSize"    : FF4gok(self, "Width\t: %s\nHeight\t: %s" % (FFB0L6()[0], FFB0L6()[1]))
   elif item == "Locale"     : CCSqSs.VVtdya(self)
   elif item == "Processor"    : self.VVIUXQ()
   elif item == "OperatingSystem"   : FFlXTd(self, "uname -a"        )
   elif item == "drivers"     : self.VVWuKK()
   elif item == "SystemUsers"    : FFlXTd(self, "id"          )
   elif item == "LoggedInUsers"   : FFlXTd(self, "who -a"         )
   elif item == "Uptime"     : FFlXTd(self, "uptime"         )
   elif item == "HostName"     : FFlXTd(self, "hostname"        )
   elif item == "MACAddress"    : self.VVox5i()
   elif item == "NetworkConfiguration"  : FFlXTd(self, "ifconfig %s %s" % (FFrfWO("HWaddr", VVDDRU), FFrfWO("addr:", VVrhVl)))
   elif item == "NetworkStatus"   : FFlXTd(self, "netstat -tulpn"       )
   elif item == "VVOYPb"    : self.VVOYPb()
   elif item == "MountPoints"    : FFlXTd(self, "mount %s" % (FFrfWO(" on ", VVrhVl)))
   elif item == "FileSystemTable"   : FFlXTd(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFlXTd(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFlXTd(self, "blkid"         )
   elif item == "DirectorySize"   : FFlXTd(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVHois="Reading size ...")
   elif item == "Memory"     : FFlXTd(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVLhyS()
   elif item == "RunningProcesses"   : FFlXTd(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFlXTd(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVQbot()
   else         : self.close()
 def VVox5i(self):
  res = FFPjNy("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FF4gok(self, txt)
  else:
   FFlXTd(self, "ip link")
 def VVRCvV(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFEUax(cmd)
  return lines
 def VV7KKu(self, lines, headerRepl, widths, VV28Ef):
  VVbdQX = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVbdQX.append(parts)
  if VVbdQX and len(header) == len(widths):
   VVbdQX.sort(key=lambda x: x[0].lower())
   FFMPky(self, None, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=28, VVVz9Q=True)
   return True
  else:
   return False
 def VVOYPb(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFPjNy(cmd)
  if not "invalid option" in txt:
   lines  = self.VVRCvV(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VV28Ef = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VV7KKu(lines, headerRepl, widths, VV28Ef)
  else:
   cmd = "df -h"
   lines  = self.VVRCvV(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VV28Ef = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VV7KKu(lines, headerRepl, widths, VV28Ef)
  if not allOK:
   lines = FFEUax(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFS9Oz(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVhAfh:
     note = "\n%s" % FFXe6i("Green = Mounted Partitions", VVhAfh)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVrhVl
     elif line.endswith(mountList) : color = VVhAfh
     else       : color = VVycQx
     txt += FFXe6i(line, color) + "\n"
    FF4gok(self, txt + note)
   else:
    FFu1fZ(self, "Not data from system !")
 def VVLhyS(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVRCvV(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VV28Ef = (LEFT , CENTER, LEFT )
  allOK = self.VV7KKu(lines, headerRepl, widths, VV28Ef)
  if not allOK:
   FFlXTd(self, cmd)
 def VVWuKK(self):
  cmd = FF7FNT(VV8UyW, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFlXTd(self, cmd)
  else : FF0x3g(self)
 def VVIUXQ(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFlXTd(self, cmd)
 def VVQbot(self):
  cmd = FF7FNT(VVlqUC, "| grep secondstage")
  if cmd : FFlXTd(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FF0x3g(self)
 def VV7otE(self):
  c = VVhAfh
  VVL1iO = []
  VVL1iO.append((FFXe6i("Box Type"  , c), FFXe6i(self.VVY1F7("boxtype").upper(), c)))
  VVL1iO.append((FFXe6i("Board Version", c), FFXe6i(self.VVY1F7("board_revision") , c)))
  VVL1iO.append((FFXe6i("Chipset"  , c), FFXe6i(self.VVY1F7("chipset")  , c)))
  VVL1iO.append((FFXe6i("S/N"   , c), FFXe6i(self.VVY1F7("sn")    , c)))
  VVL1iO.append((FFXe6i("Version"  , c), FFXe6i(self.VVY1F7("version")  , c)))
  VVEqbI   = []
  VVeZUD = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVeZUD = SystemInfo[key]
     else:
      VVEqbI.append((FFXe6i(str(key), VVhW2e), FFXe6i(str(SystemInfo[key]), VVhW2e)))
  except:
   pass
  if VVeZUD:
   VVcUnQ = self.VVl3ZG(VVeZUD)
   if VVcUnQ:
    VVcUnQ.sort(key=lambda x: x[0].lower())
    VVL1iO += VVcUnQ
  if VVEqbI:
   VVEqbI.sort(key=lambda x: x[0].lower())
   VVL1iO += VVEqbI
  if VVL1iO:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFMPky(self, None, header=header, VVL1iO=VVL1iO, VVLkOa=widths, VVJfxh=28, VVVz9Q=True)
  else:
   FF4gok(self, "Could not read info!")
 def VVY1F7(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFgYB4(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVl3ZG(self, mbDict):
  try:
   mbList = list(mbDict)
   VVL1iO = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVL1iO.append((FFXe6i(subject, VVrhVl), FFXe6i(value, VVrhVl)))
  except:
   pass
  return VVL1iO
 def VVTV2n(self):
  txt = self.VVg8xe("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVg8xe("/proc/bus/nim_sockets")
  if not txt: txt = self.VV2uw1()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FF4gok(self, txt)
 def VV2uw1(self):
  txt = ""
  VV1fOZ = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VV1fOZ("Slot Name" , slot.getSlotName())
     txt += FFXe6i(slotName, VVrhVl)
     txt += VV1fOZ("Description"  , slot.getFullDescription())
     txt += VV1fOZ("Frontend ID"  , slot.frontend_id)
     txt += VV1fOZ("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVg8xe(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFgYB4(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFXe6i(line, VVrhVl)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVZ4LX(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FF4gok(self, txt)
 @staticmethod
 def VVEe8p():
  def VV1fOZ(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VV1fOZ(v,0), "/etc/issue.net": VV1fOZ(v,1), "/etc/image-version": VV1fOZ(v,2)}
  for p1, d in v.items():
   img = CCld2v.VVZZnT(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VV1fOZ(v,0), p + "Plugins/": VV1fOZ(v,1), VVaET3: VV1fOZ(v,2), VVD9rK: VV1fOZ(v,3)}
  for p1, d in v.items():
   img = CCld2v.VVilLg(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VVZZnT(path, d):
  if fileExists(path):
   txt = FFQgne(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVilLg(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CCBGBj(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFTWzO(VV4Y67, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVMYdC = []
  VVMYdC.append(("Settings (All)"   , "Settings_All"   ))
  VVMYdC.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVMYdC.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVMYdC.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVMYdC.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVMYdC.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVMYdC.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VVxD6t:
   VVMYdC.append(VVc27s)
   VVMYdC.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVMYdC.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FF0Q0u(self, VVMYdC=VVMYdC)
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FF4IYg(self["myMenu"])
  FFIvVk(self)
 def VVqqT1(self):
  global VVmICA
  VVmICA = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %ssettings" % VVPZMJ
   grep = " | grep "
   if   item == "Settings_All"    : FFlXTd(self, cmd                )
   elif item == "Settings_HotKeys"   : FFlXTd(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_ajp"    : FFlXTd(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME     )
   elif item == "Settings_FHDG_17"   : FFlXTd(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFlXTd(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFlXTd(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFlXTd(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFlXTd(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFlXTd(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CC9IhO(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFTWzO(VV4Y67, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVEr6h, VVQZYv, VVTk8G, camCommand = CC9IhO.VV4jkq()
  self.VVQZYv = VVQZYv
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VVQZYv:
   c = VV80mJ if VVTk8G else VV2RHA
   if   "oscam" in VVQZYv : camName, oC = "OSCam", c
   elif "ncam"  in VVQZYv : camName, nC = "NCam" , c
  VVMYdC = []
  VVMYdC.append(("OSCam Files" , "OSCamFiles"  ))
  VVMYdC.append(("NCam Files" , "NCamFiles"  ))
  VVMYdC.append(("CCcam Files" , "CCcamFiles"  ))
  VVMYdC.append(VVc27s)
  VVMYdC.append((VVJ6nn + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VVwknV" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVMYdC.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVMYdC.append(VVc27s)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  if VVQZYv: VVMYdC.append((c + txt  , "camInfo" ))
  else  : VVMYdC.append((txt  ,    ))
  VVMYdC.append(VVc27s)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VVQZYv:
   for item in camLst: VVMYdC.append(item)
  else:
   for item in camLst: VVMYdC.append((item[0], ))
  FF0Q0u(self, VVMYdC=VVMYdC)
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FF4IYg(self["myMenu"])
  FFIvVk(self)
 def VVqqT1(self):
  global VVmICA
  VVmICA = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCGFZZ, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCGFZZ, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCGFZZ, "cccam"))
   elif item == "VVwknV" : self.VVwknV()
   elif item == "OSCamReaders"  : self.VV1VT5("os")
   elif item == "NSCamReaders"  : self.VV1VT5("n")
   elif item == "camInfo"   : FF0H0y(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CC9IhO.VVn6Fl(self.session, CCsiDy.VVllO6)
   elif item == "camLiveReaders" : CC9IhO.VVn6Fl(self.session, CCsiDy.VV3cRQ)
   elif item == "camLiveLog"  : CC9IhO.VVn6Fl(self.session, CCsiDy.VVCKLQ)
   else       : self.close()
 def VVwknV(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVXneu, FFcOP9())
  if fileExists(path):
   lines = FFgYB4("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VV1fOZ = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VV1fOZ("label"    , "CCcam-Line-%d" % ndx))
      f.write(VV1fOZ("description"  , "CCcam-Line-%d" % ndx))
      f.write(VV1fOZ("protocol"   , "cccam"))
      f.write(VV1fOZ("device"    , "%s,%s" % (host, port)))
      f.write(VV1fOZ("user"    , User))
      f.write(VV1fOZ("password"   , Pass))
      f.write(VV1fOZ("fallback"   , "1"))
      f.write(VV1fOZ("group"    , "64"))
      f.write(VV1fOZ("cccversion"   , "2.3.2"))
      f.write(VV1fOZ("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FF5VuW(self, "Output = %d Reader%s in:\n\n%s" % (tot, FFmxIl(tot), outFile))
   else:
    FFAcfo(self, "No valid CCcam lines", 1500)
  else:
   FFAcfo(self, "%s not found" % path, 1500)
 def VV1VT5(self, camPrefix):
  VVbdQX = self.VV6SuF(camPrefix)
  if VVbdQX:
   VVbdQX.sort(key=lambda x: int(x[0]))
   if self.VVQZYv and self.VVQZYv.startswith(camPrefix):
    VVgAHl = ("Toggle State", self.VVq7NL, [camPrefix], "Changing State ...")
   else:
    VVgAHl = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VV28Ef  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFMPky(self, None, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VVgAHl=VVgAHl, VVMVWT=True)
 def VV6SuF(self, camPrefix):
  readersFile = self.VVEr6h + camPrefix + "cam.server"
  VVbdQX = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFgYB4(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVbdQX.append((str(len(VVbdQX) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVbdQX:
    FFu1fZ(self, "No readers found !")
  else:
   FF6iwf(self, readersFile)
  return VVbdQX
 def VVq7NL(self, VVoyO8, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVEr6h, camPrefix)
  readerState  = VVoyO8.VVnbNr(1)
  readerLabel  = VVoyO8.VVnbNr(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CC9IhO.VVNKyA(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVoyO8.VV4uR4()
    FFu1fZ(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVbdQX = self.VV6SuF(camPrefix)
   if VVbdQX:
    VVoyO8.VVKBif(VVbdQX)
  else:
   VVoyO8.VV4uR4()
 @staticmethod
 def VVNKyA(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFgYB4(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFu1fZ(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFu1fZ(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FF6iwf(SELF, confFile)
   return None
  if not iRequest:
   FFu1fZ(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CC9IhO.VViIgt(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FFu1fZ(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VViIgt(SELF):
  if iElem:
   return True
  else:
   FFu1fZ(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVn6Fl(session, VVO3G3):
  VVEr6h, VVQZYv, VVTk8G, camCommand = CC9IhO.VV4jkq()
  if VVQZYv:
   runLog = False
   if   VVO3G3 == CCsiDy.VVllO6 : runLog = True
   elif VVO3G3 == CCsiDy.VV3cRQ : runLog = True
   elif not VVTk8G          : FF2TDl(session, message="SoftCam not started yet!")
   elif fileExists(VVTk8G)        : runLog = True
   else             : FF2TDl(session, message="File not found !\n\n%s" % VVTk8G)
   if runLog:
    session.open(BF(CCsiDy, VVEr6h=VVEr6h, VVQZYv=VVQZYv, VVTk8G=VVTk8G, VVO3G3=VVO3G3))
  else:
   FF2TDl(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VV4jkq():
  VVEr6h = "/etc/tuxbox/config/"
  VVQZYv = None
  VVTk8G  = None
  camCommand = FFY14S("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VVQZYv = "oscam"
   elif camCmd.startswith("ncam") : VVQZYv = "ncam"
  if VVQZYv:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFQgne(path), IGNORECASE)
     if span:
      VVEr6h = FF5sxC(span.group(1))
      break
   else:
    path = FFY14S(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FF5sxC(path)
    if pathExists(path):
     VVEr6h = path
   tFile = FF5sxC(VVEr6h) + VVQZYv + ".conf"
   tFile = FFY14S("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVTk8G = tFile
  return VVEr6h, VVQZYv, VVTk8G, camCommand
class CCGFZZ(Screen):
 def __init__(self, VVT3N8, session, args=0):
  self.skin, self.skinParam = FFTWzO(VV4Y67, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVEr6h, VVQZYv, VVTk8G, camCommand = CC9IhO.VV4jkq()
  if   VVT3N8 == "ncam" : self.prefix = "n"
  elif VVT3N8 == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVMYdC = []
  if self.prefix == "":
   VVMYdC.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVMYdC.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVMYdC.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVMYdC.append(("constant.cw"         , "x_constant_cw" ))
   VVMYdC.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVMYdC.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVMYdC.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVMYdC.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVMYdC.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVMYdC.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVMYdC.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVMYdC.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVMYdC.append(VVc27s)
   VVMYdC.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVMYdC.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVMYdC.append(VVc27s)
   VVMYdC.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVMYdC.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVMYdC.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FF0Q0u(self, VVMYdC=VVMYdC)
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FF4IYg(self["myMenu"])
  FFIvVk(self)
 def VVqqT1(self):
  global VVmICA
  VVmICA = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFVPiE(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFVPiE(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFVPiE(self, self.VVEr6h + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFVPiE(self, self.VVEr6h + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVhnkW("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVhnkW("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVhnkW("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVhnkW("cam.provid"        )
   elif item == "x_cam_server"  : self.VVhnkW("cam.server"        )
   elif item == "x_cam_services" : self.VVhnkW("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVhnkW("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVhnkW("cam.user"        )
   elif item == "x_VVn31f"   : pass
   elif item == "x_SoftCam_Key" : self.VVwpkB()
   elif item == "x_CCcam_cfg"  : FFVPiE(self, self.VVEr6h + "CCcam.cfg"    )
   elif item == "x_VVn31f"   : pass
   elif item == "x_cam_log"  : FFVPiE(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFVPiE(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFVPiE(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVhnkW(self, fileName):
  FFVPiE(self, self.VVEr6h + self.prefix + fileName)
 def VVwpkB(self):
  path = self.VVEr6h + "SoftCam.Key"
  if fileExists(path) : FFVPiE(self, path)
  else    : FFVPiE(self, path.replace(".Key", ".key"))
class CCsiDy(Screen):
 VVllO6  = 0
 VV3cRQ = 1
 VVCKLQ = 2
 def __init__(self, session, VVEr6h="", VVQZYv="", VVTk8G="", VVO3G3=VVllO6):
  self.skin, self.skinParam = FFTWzO(VVZQMO, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVTk8G   = VVTk8G
  self.VVO3G3  = VVO3G3
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVEr6h + VVQZYv + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVQZYv : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVEr6h, self.camPrefix)
  if self.VVO3G3 == self.VVllO6:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVO3G3 == self.VV3cRQ:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FF0Q0u(self, self.Title, addScrollLabel=True)
  FF970D(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVSXhE
  self.onShown.append(self.VViGDa)
  self.onClose.append(self.onExit)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  self["myLabel"].VVmdiX(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFyHsQ(self)
  self.VVSXhE()
 def onExit(self):
  self.timer.stop()
 def VVsfp0(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVbJgo)
  except:
   self.timer.callback.append(self.VVbJgo)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFAcfo(self, "Started", 1000)
 def VVy0iR(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVbJgo)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFAcfo(self, "Stopped", 1000)
 def VVSXhE(self):
  if self.timerRunning:
   self.VVy0iR()
  else:
   self.VVsfp0()
   if self.VVO3G3 == self.VVllO6 or self.VVO3G3 == self.VV3cRQ:
    if self.VVO3G3 == self.VVllO6 : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CC9IhO.VVNKyA(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFC8Ey(self.VVmpFY)
    else:
     self.close()
   else:
    self.VVkql7()
 def VVbJgo(self):
  if self.timerRunning:
   if   self.VVO3G3 == self.VVllO6 : self.VVynDn()
   elif self.VVO3G3 == self.VV3cRQ : self.VVynDn()
   else            : self.VVkql7()
 def VVkql7(self):
  if fileExists(self.VVTk8G):
   fTime = FF2ogC(os.path.getmtime(self.VVTk8G))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVZljc(), VVr1DU=VVTsDD)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVTk8G)
 def VVmpFY(self):
  self.VVynDn()
 def VVynDn(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFXe6i("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVwtwf))
   self.camWebIfErrorFound = True
   self.VVy0iR()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVO3G3 == self.VVllO6 : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFXe6i("Error while parsing data elements !\n\nError = %s" % str(e), VVpQzP)
   self.camWebIfErrorFound = True
   self.VVy0iR()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVvsha(root)
  self["myLabel"].setText(txt, VVr1DU=VVTsDD)
  self["myBar"].setText("Last Update : %s" % FFddDI())
 def VVvsha(self, rootElement):
  def VV1fOZ(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVO3G3 == self.VVllO6:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFXe6i(status, VVhAfh)
    else          : status = FFXe6i(status, VVpQzP)
    txt += VVn31f + "\n"
    txt += VV1fOZ("Name"  , name)
    txt += VV1fOZ("Description" , desc)
    txt += VV1fOZ("IP/Port"  , "%s : %s" % (ip, port))
    txt += VV1fOZ("Protocol" , protocol)
    txt += VV1fOZ("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFXe6i("Yes", VVhAfh)
    else    : enabTxt = FFXe6i("No", VVpQzP)
    txt += VVn31f + "\n"
    txt += VV1fOZ("Label"  , label)
    txt += VV1fOZ("Protocol" , protocol)
    txt += VV1fOZ("Enabled" , enabTxt)
  return txt
 def VVZljc(self):
  lines = FFEUax("tail -n %d %s" % (100, self.VVTk8G))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VVwhxm + line[:19] + VVycQx + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVEirQ + "WebIf" + VVycQx)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VVhW2e + h1 + h2 + VVycQx + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VVhAfh + span.group(2) + VVJ6nn + span.group(3) + VVycQx + span.group(4)
    line = self.VVPdoU(line, VVJ6nn, ("(webif)", ))
    line = self.VVPdoU(line, VVJ6nn, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VVPdoU(line, VVhAfh, ("OSCam", "NCam", "log switched"))
    line = self.VVPdoU(line, VV8DG7, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVrhVl + line[ndx + 3:] + VVycQx
   elif line.startswith("----") or ">>" in line:
    line = FFXe6i(line, VVGCti)
   txt += line + "\n"
  return txt
 def VVPdoU(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVycQx + t3
  return line
class CCLP9M(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFTWzO(VV4Y67, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVMYdC = []
  VVMYdC.append(("Backup Channels"    , "VVqcsJ"   ))
  VVMYdC.append(("Restore Channels"    , "Restore_Channels"  ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Backup SoftCAM Files"   , "VV0uiv" ))
  VVMYdC.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVMYdC.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVMYdC.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Backup Network Settings"  , "VVerVk"   ))
  VVMYdC.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVxD6t:
   VVMYdC.append(VVc27s)
   VVMYdC.append((VVwtwf + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VVwHE4"   ))
   VVMYdC.append((VVhAfh + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVMNa9) , "createMyIpk"   ))
   VVMYdC.append((VVhAfh + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVMNa9) , "createMyDeb"   ))
   VVMYdC.append((VVhW2e + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVMYdC.append((VVhW2e + "Decode %s Crash Report"   % PLUGIN_NAME     , "VVcdli" ))
  FF0Q0u(self, VVMYdC=VVMYdC)
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FF4IYg(self["myMenu"])
  FFIvVk(self)
 def VVqqT1(self):
  global VVmICA
  VVmICA = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVqcsJ"    : self.VVqcsJ()
   elif item == "Restore_Channels"    : self.VVHMjm("channels_backup*.tar.gz", self.VVBgdp, isChan=True)
   elif item == "VV0uiv"   : self.VV0uiv()
   elif item == "Restore_SoftCAM_Files"  : self.VVHMjm("softcam_backup*.tar.gz", self.VVmWZs)
   elif item == "Backup_TunerDiSEqC"   : self.VVZY3i("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVHMjm("tuner_backup*.backup", BF(self.VVgq7m, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVZY3i("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVHMjm("hotkey_*backup*.backup", BF(self.VVgq7m, "misc"))
   elif item == "VVerVk"    : self.VVerVk()
   elif item == "Restore_Network"    : self.VVHMjm("network_backup*.tar.gz", self.VVfrwD)
   elif item == "VVwHE4"     : FFlOO5(self, BF(FFZmix, self, BF(CCLP9M.VVwHE4, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VV1LQ1(False)
   elif item == "createMyDeb"     : self.VV1LQ1(True)
   elif item == "createMyTar"     : self.VVgijL()
   elif item == "VVcdli"   : self.VVcdli()
 @staticmethod
 def VVwHE4(SELF):
  OBF_Path = VVN3PN + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVN3PN, VV9qD9, VVMNa9)
   if err : FFu1fZ(SELF, err)
   else : FF4gok(SELF, txt)
  else:
   FF6iwf(SELF, OBF_Path)
 def VV1LQ1(self, VVchL9):
  OBF_Path = VVN3PN + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFu1fZ(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVN3PN)
  os.system("mv -f %s %s" % (VVN3PN + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVN3PN + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVN3PN + "plugin.py"))
  self.session.openWithCallback(self.VVXN3p, BF(CCk4eB, path=VVN3PN, VVchL9=VVchL9))
 def VVXN3p(self):
  os.system("mv -f %s %s" % (VVN3PN + "OBF/main.py"  , VVN3PN))
  os.system("mv -f %s %s" % (VVN3PN + "OBF/plugin.py" , VVN3PN))
 def VVcdli(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFu1fZ(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFu1fZ(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVBKnZ("%s*.list" % path)
  if err:
   FF6iwf(self, path + "*.list")
   return
  srcF, err = self.VVBKnZ("%s*main_final.py" % path)
  if err:
   FF6iwf(self, path + "*.final.py")
   return
  VVL1iO = []
  for f in files:
   f = os.path.basename(f)
   VVL1iO.append((f, f))
  FFcKE0(self, BF(self.VV38Mw, path, codF, srcF), VVMYdC=VVL1iO)
 def VV38Mw(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FF6iwf(self, logF)
   else     : FFZmix(self, BF(self.VVBRrf, logF, codF, srcF))
 def VVBRrf(self, logF, codF, srcF):
  lst  = []
  lines = FFgYB4(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFu1fZ(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVmufw(lst, logF, newLogF)
  totSrc  = self.VVmufw(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FF4gok(self, txt)
 def VVBKnZ(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVmufw(self, lst, f1, f2):
  txt = FFQgne(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVgijL(self):
  VVL1iO = []
  VVL1iO.append("%s%s" % (VVN3PN, "*.py"))
  VVL1iO.append("%s%s" % (VVN3PN, "*.png"))
  VVL1iO.append("%s%s" % (VVN3PN, "*.xml"))
  VVL1iO.append("%s"  % (VVlId3))
  FF3zFx(self, VVL1iO, "%s_%s" % (PLUGIN_NAME, VV9qD9), addTimeStamp=False)
 def VVqcsJ(self):
  path1 = VVPZMJ
  path2 = "/etc/tuxbox/"
  VVL1iO = []
  VVL1iO.append("%s%s" % (path1, "*.tv"))
  VVL1iO.append("%s%s" % (path1, "*.radio"))
  VVL1iO.append("%s%s" % (path1, "*list"))
  VVL1iO.append("%s%s" % (path1, "lamedb*"))
  VVL1iO.append("%s%s" % (path2, "*.xml"))
  FF3zFx(self, VVL1iO, self.VVekbq("channels_backup"), addTimeStamp=True)
 def VV0uiv(self):
  VVL1iO = []
  VVL1iO.append("/etc/tuxbox/config/")
  VVL1iO.append("/usr/keys/")
  VVL1iO.append("/usr/scam/")
  VVL1iO.append("/etc/CCcam.cfg")
  FF3zFx(self, VVL1iO, self.VVekbq("softcam_backup"), addTimeStamp=True)
 def VVerVk(self):
  VVL1iO = []
  VVL1iO.append("/etc/hostname")
  VVL1iO.append("/etc/default_gw")
  VVL1iO.append("/etc/resolv.conf")
  VVL1iO.append("/etc/wpa_supplicant*.conf")
  VVL1iO.append("/etc/network/interfaces")
  VVL1iO.append("%snameserversdns.conf" % VVPZMJ)
  FF3zFx(self, VVL1iO, self.VVekbq("network_backup"), addTimeStamp=True)
 def VVekbq(self, fName):
  img = CCld2v.VVEe8p()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVBgdp(self, fileName=None):
  if fileName:
   FFlOO5(self, BF(FFZmix, self, BF(self.VVu91t, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VVu91t(self, fileName):
  path = "%s%s" % (VVXneu, fileName)
  if fileExists(path):
   if CC5DZc.VVlfBg(path):
    VVfppQ , VVa8UD = CCFb9t.VVVYKr()
    VVNKS2, VVzBW2 = CCFb9t.VVNufk()
    cmd  = FFVKmy("cd %s" % VVPZMJ) + ";"
    cmd += FFVKmy("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VVa8UD, VVzBW2))+ ";"
    cmd += "tar -xzf '%s' -C /" % path
    res = os.system(cmd)
    FFSSJm()
    if res == 0 : FF5VuW(self, "Channels Restored.")
    else  : FFu1fZ(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FFu1fZ(self, "Invalid tar file:\n\n%s" % path)
  else:
   FF6iwf(self, path)
 def VVmWZs(self, fileName=None):
  if fileName:
   FFlOO5(self, BF(self.VV71q3, fileName), "Overwrite SoftCAM files ?")
 def VV71q3(self, fileName):
  fileName = "%s%s" % (VVXneu, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVn31f
   note = "You may need to restart your SoftCAM."
   FFitBw(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFrfWO(note, VVrhVl), sep))
  else:
   FF6iwf(self, fileName)
 def VVfrwD(self, fileName=None):
  if fileName:
   FFlOO5(self, BF(self.VVIaAS, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVIaAS(self, fileName):
  fileName = "%s%s" % (VVXneu, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFrhsY(self,  cmd)
  else:
   FF6iwf(self, fileName)
 def VVHMjm(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FF3zTd()
  if pathExists(VVXneu):
   myFiles = FFFgxj(VVXneu, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVL1iO = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVL1iO.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VVAfNY = ("Sat. List", self.VVI75s)
    elif isChan and iTar: VVAfNY = ("Bouquets Importer", CCjA2r.VVdPGu)
    else    : VVAfNY = None
    VVyvO2 = ("Delete File", self.VVHVMC)
    FFcKE0(self, callBackFunction, title=title, width=1200, VVMYdC=VVL1iO, VVAfNY=VVAfNY, VVyvO2=VVyvO2)
   else:
    FFu1fZ(self, "No files found in:\n\n%s" % VVXneu, title)
  else:
   FFu1fZ(self, "Path not found:\n\n%s" % VVXneu, title)
 def VVHVMC(self, VVVCbtObj, path):
  FFlOO5(self, BF(self.VVqkSk, VVVCbtObj, path), "Delete this file ?\n\n%s" % path)
 def VVqkSk(self, VVVCbtObj, path):
  path = VVXneu + path
  FF2PD3(path)
  if fileExists(path) : FFAcfo(VVVCbtObj, "Not deleted", 1000)
  else    : VVVCbtObj.VVLcYB()
 def VVZY3i(self, filePrefix, wordsFilter):
  settingFile = "%ssettings" % VVPZMJ
  tCons = CCKdbR()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VVsBob, filePrefix))
 def VVsBob(self, filePrefix, result, retval):
  title = FF3zTd()
  if pathExists(VVXneu):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFu1fZ(self, "Cannot read settings file", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVXneu, filePrefix, self.VVekbq(""), FFcOP9())
    try:
     VVL1iO = str(result.strip()).split()
     if VVL1iO:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVL1iO:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVn31f, FFXe6i(fName, VVrhVl), VVn31f)
       FF4gok(self, txt, title=title, VVr1DU=VVTsDD)
      else:
       FFu1fZ(self, "File creation failed!", title)
     else:
      FFu1fZ(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFVKmy("rm %s" % fName))
     FFu1fZ(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFVKmy("rm %s" % fName))
     FFu1fZ(self, "Error while writing file.")
  else:
   FFu1fZ(self, "Path not found:\n\n%s" % VVXneu, title)
 def VVgq7m(self, mode, path=None):
  if path:
   path = "%s%s" % (VVXneu, path)
   if fileExists(path):
    lines = FFgYB4(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFlOO5(self, BF(self.VVIHCP, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFm1Rb(self, path, title=FF3zTd())
   else:
    FF6iwf(self, path)
 def VVIHCP(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVOBG5 = []
  VVOBG5.append("echo -e 'Reading current settings ...'")
  VVOBG5.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVOBG5.append("echo -e 'Preparing new settings ...'")
  VVOBG5.append(settingsLines)
  VVOBG5.append("echo -e 'Applying new settings ...'")
  VVOBG5.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFSyy7(self, VVOBG5)
 def VVI75s(self, VVVCbtObj, path):
  if not path:
   return
  path = VVXneu + path
  if not fileExists(path):
   FF6iwf(self, path)
   return
  txt = FFQgne(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVL1iO  = []
   for item in satList:
    VVL1iO.append("%s\t%s" % (item[0], FFwqep(item[1])))
   FF4gok(self, VVL1iO, title="  Satellites List")
  else:
   FFu1fZ(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCjA2r():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VVdPGu(SELF, fName):
  bi = CCjA2r(SELF)
  bi.instance = bi
  bi.VVudxZ(SELF, fName)
 @staticmethod
 def VVdyfg(SELF):
  bi = CCjA2r(SELF)
  bi.instance = bi
  bi.VVza0T()
 def VVudxZ(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVXneu + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FFZmix(waitObg, self.VVKt00, title="Reading bouquets ...")
  else      : self.VVx77I(self.filePath)
 def VVGEG2(self, txt) : FFu1fZ(self.SELF, txt, title=self.Title)
 def VVe3Eu(self, txt)  : FFAcfo(self, txt, 1500)
 def VVx77I(self, path) : FF6iwf(self.SELF, path, title=self.Title)
 def VVza0T(self):
  if pathExists(VVXneu):
   lst = FFFgxj(VVXneu, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VVNgQC())
   if len(lst) > 0:
    VVMYdC = []
    for item in lst:
     item = os.path.basename(item)
     txt = FFXe6i(item, VVJ6nn) if item.endswith(".zip") else item
     VVMYdC.append((txt, item))
    VVMYdC.sort(key=lambda x: x[1].lower())
    OKBtnFnc = self.VVCVnQ
    FFcKE0(self.SELF, self.VVDhTP, title=self.Title, width=1200, VVMYdC=VVMYdC, OKBtnFnc=OKBtnFnc, VVI8Pk="#22111111", VV2s6D="#22111111")
   else:
    self.VVGEG2("No valid backup files found in:\n\n%s" % VVXneu)
  else:
   self.VVGEG2("Backup Directory not found:\n\n%s" % VVXneu)
 def VVCVnQ(self, item=None):
  if item:
   menuInstance, txt, fName, ndx = item
   self.VVudxZ(menuInstance, fName)
 def VVDhTP(self, item=None):
  if not item and self.instance:
   del self.instance
 def VVNgQC(self):
  files = FFFgxj(VVXneu, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VVKt00(self):
  lines, err = CCjA2r.VVXHRR(self.filePath, "bouquets.tv")
  if err:
   self.VVGEG2(err)
   return
  bTvSortLst  = self.VVzUV5(lines)
  lines, err = CCjA2r.VVXHRR(self.filePath, "bouquets.radio")
  if err:
   self.VVGEG2(err)
   return
  bRadSortLst = self.VVzUV5(lines)
  VVbdQX = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VVymVm(f, mode, len(VVbdQX), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVbdQX.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VVymVm(f, mode, len(VVbdQX), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VVymVm(f, mode, len(VVbdQX), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVbdQX.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VVymVm(f, mode, len(VVbdQX), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVbdQX:
   VVbdQX.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVbdQX): VVbdQX[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVbdQX):
     if key == os.path.basename(row[9]):
      VVbdQX = VVbdQX[:ndx+1] + lst + VVbdQX[ndx+1:]
      break
   for ndx, item in enumerate(VVbdQX): VVbdQX[ndx][0] = str(ndx + 1)
   VVjLdB = "#11000600"
   VVhqvZ  = ("Show Services" , self.VVOuhp  , [], "Reading ..." )
   VVUZua = ("Options"  , self.VVeP2d, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 43   , 7  , 7   , 7  , 7  , 7   , 7   , 8   ,  0.01 )
   VV28Ef  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER ,  LEFT )
   FFMPky(self.SELF, None, title=self.Title, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=24, VVhqvZ=VVhqvZ, VVUZua=VVUZua, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVI8Pk=VVjLdB, VV2s6D=VVjLdB, VVjLdB=VVjLdB, VV58S5="#11ffffff", VVaZj9="#00004455", VVBGyD="#0a282828")
  else:
   self.VVGEG2("No valid bouquets in:\n\n%s" % self.filePath)
 def VVzUV5(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VVeP2d(self, VVoyO8, title, txt, colList):
  mSel = CCvNaQ(self.SELF, VVoyO8)
  if VVoyO8.VVdP3d:
   totSel = VVoyO8.VVlPPo()
   if totSel: VVMYdC = [("Import %s Bouquet%s" % (FFXe6i(str(totSel), VVhAfh), FFmxIl(totSel)), "imp")]
   else  : VVMYdC = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FFXe6i(bName, VVhAfh)
   VVMYdC = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FFZmix, VVoyO8, BF(CCjA2r.VVTsgB, self.SELF, VVoyO8, self.filePath))}
  mSel.VVUtfc(VVMYdC, cbFncDict)
 def VVOuhp(self, VVoyO8, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CCjA2r.VVXHRR(self.filePath, "lamedb")
   if err:
    self.VVGEG2(err)
    return
   dbServLst = CCFb9t.VVO6Sa(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totLoc, totMrk, totBnb, fName = VVoyO8.VV3wWK()
   lines, err = CCjA2r.VVXHRR(self.filePath, os.path.basename(fName))
   if err:
    self.VVGEG2(err)
    return
   VVbdQX = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVbdQX.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVbdQX.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVbdQX.append((span.group(1).strip() or "-", "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVbdQX.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVbdQX.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CCFb9t.VVGegm(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVbdQX.append((name.strip() or "-", FFYM1A(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVbdQX):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CCjA2r.VVXHRR(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVbdQX[ndx] = (bName, descr)
   if VVbdQX:
    VVjLdB = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VV28Ef = (LEFT  , CENTER)
    FFMPky(self.SELF, None, title="Services in : %s" % bName, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=28, VVI8Pk=VVjLdB, VV2s6D=VVjLdB, VVjLdB=VVjLdB, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FFAcfo(VVoyO8, err, 1500)
  else : VVoyO8.VV4uR4()
 def VVymVm(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VVGEG2("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VV3eCd(var):
   return str(var) if var else VVB3E5 + str(var)
  totItem = VVrhVl + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VVwtwf   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVJ6nn, "Sub-B."
  else  : bColor, totBnb = ""      , VV3eCd(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VV3eCd(totDVB), VV3eCd(totIptv), VV3eCd(totLoc), VV3eCd(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VVTsgB(SELF, VVoyO8, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVPZMJ + "bouquets.tv"
  radBouquetFile = VVPZMJ + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FF6iwf(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FF6iwf(SELF, radBouquetFile, title=title)
   return
  isMulti = VVoyO8.VVdP3d
  if isMulti : rows = VVoyO8.VVs7PD()
  else  : rows = [VVoyO8.VV3wWK()]
  for num, bName, bMode, totItem, totDVB, totIptv, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FFu1fZ(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FF3RM7(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FF3RM7(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVPZMJ + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVPZMJ + newFile
    CCjA2r.VVdSf4(archPath, fName, VVPZMJ, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   CC3Jx1.VVF3UC(tvBouquetFile)
   CC3Jx1.VVF3UC(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CCjA2r.VVL32N(SELF, archPath, bList)
   FFSSJm()
  txt  = FFXe6i("Added:\n", VVJ6nn)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FFXe6i("Imported to lamedab:\n", VVJ6nn)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FFXe6i("Missing from archived lamedb:\n", VVwtwf)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FF4gok(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVL32N(SELF, archPath, bList):
  VVfppQ, err = CCFb9t.VVspmq(SELF, VVldMD=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CCFb9t.VVnmkM(VVfppQ, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FFgYB4(VVPZMJ + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CCFb9t.VVGegm(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CCFb9t.VVIbtc(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CCjA2r.VVwPjd(archPath, dbName)
   CCjA2r.VVdSf4(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CCFb9t.VVnmkM(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CCFb9t.VVnmkM(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CCFb9t.VVnmkM(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CCFb9t.VVnmkM(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FF2PD3(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VVfppQ + ".tmp"
   lines   = FFgYB4(VVfppQ)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   os.system(FFVKmy("mv -f '%s' '%s'" % (tmpDbFile, VVfppQ)))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VVqOXW(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VVwPjd(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVdSf4(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VVXHRR(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CClZ50(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFTWzO(VV4Y67, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVMYdC = []
  VVMYdC.append(("Plugins Browser List"       , "VVLn03"   ))
  VVMYdC.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVMYdC.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Download/Install Packages (from image feeds)" , "downloadInstallPackages"  ))
  VVMYdC.append(("Remove Packages (show all)"     , "VVMZkmsAll"   ))
  VVMYdC.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Update List of Available Packages"   , "VVvxQs"   ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Packaging Tool"        , "VVOhmk"    ))
  VVMYdC.append(("Packages Feeds"        , "packagesFeeds"    ))
  FF0Q0u(self, VVMYdC=VVMYdC)
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FF4IYg(self["myMenu"])
  FFIvVk(self)
 def VVqqT1(self):
  global VVmICA
  VVmICA = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVLn03"   : self.VVLn03()
   elif item == "pluginsMenus"     : self.VVY3PN(0)
   elif item == "pluginsStartup"    : self.VVY3PN(1)
   elif item == "pluginsDirList"    : self.VVLIgQ()
   elif item == "downloadInstallPackages"  : FFZmix(self, BF(self.VVwuky, 0, ""))
   elif item == "VVMZkmsAll"   : FFZmix(self, BF(self.VVwuky, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFZmix(self, BF(self.VVwuky, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVvxQs"   : self.VVvxQs()
   elif item == "VVOhmk"    : self.VVOhmk()
   elif item == "packagesFeeds"    : self.VVx8OV()
   else          : self.close()
 def VVLIgQ(self):
  extDirs  = FFi8R0(VVD9rK)
  sysDirs  = FFi8R0(VVaET3)
  VVL1iO  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVL1iO.append((item, VVD9rK + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVL1iO.append((item, VVaET3 + item))
  if VVL1iO:
   VVL1iO.sort(key=lambda x: x[0].lower())
   VVUZua = ("Package Info.", self.VVH7Jh, [])
   VVR0s7 = ("Open in File Manager", BF(self.VVZh5l, 1), [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFMPky(self, None, header=header, VVL1iO=VVL1iO, VVLkOa=widths, VVJfxh=28, VVUZua=VVUZua, VVR0s7=VVR0s7)
  else:
   FFu1fZ(self, "Nothing found!")
 def VVH7Jh(self, VVoyO8, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVD9rK) : loc = "extensions"
  elif path.startswith(VVaET3) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVoDzQ(package)
  else:
   FFu1fZ(self, "No info!")
 def VVx8OV(self):
  pkg = FFwr6I()
  if pkg : FFlXTd(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FF0x3g(self)
 def VVLn03(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VV1fOZ(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVn31f + "\n"
    txt += VV1fOZ("Number"   , str(c))
    txt += VV1fOZ("Name"   , FFXe6i(str(p.name), VVrhVl))
    txt += VV1fOZ("Path"  , p.path  )
    txt += VV1fOZ("Description" , p.description )
    txt += VV1fOZ("Icon"  , p.iconstr  )
    txt += VV1fOZ("Wakeup Fnc" , p.wakeupfnc )
    txt += VV1fOZ("NeedsRestart", p.needsRestart)
    txt += VV1fOZ("Internal" , p.internal )
    txt += VV1fOZ("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FF4gok(self, txt)
 def VVY3PN(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VVL1iO = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VVL1iO.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VVL1iO:
   VVL1iO.sort(key=lambda x: x[0].lower())
   VVR0s7 = ("Open in File Manager", BF(self.VVZh5l, 4), [])
   header   = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths   = (19  , 25 , 20  , 27   , 9  )
   FFMPky(self, None, title=title, header=header, VVL1iO=VVL1iO, VVLkOa=widths, VVJfxh=26, VVR0s7=VVR0s7)
  else:
   FFu1fZ(self, "Nothing Found", title=title)
 def VVZh5l(self, pathColNum, VVoyO8, title, txt, colList):
  path = colList[pathColNum].strip()
  if pathExists(path) : self.session.open(CC5DZc, mode=CC5DZc.VV7Flf, VVYwJg=path)
  else    : FFAcfo(VVoyO8, "Path not found !", 1500)
 def VVvxQs(self):
  cmd = FF7FNT(VVOEW0, "")
  if cmd : FFrhsY(self, cmd, checkNetAccess=True)
  else : FF0x3g(self)
 def VVOhmk(self):
  pkg = FFwr6I()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FF5VuW(self, txt)
 def VVwuky(self, mode, grep, VVoyO8=None, title=""):
  if   mode == 0: cmd = FF7FNT(VVlqUC    , grep)
  elif mode == 1: cmd = FF7FNT(VV8UyW , grep)
  elif mode == 2: cmd = FF7FNT(VV8UyW , grep)
  if not cmd:
   FF0x3g(self)
   return
  VVbdQX = FFEUax(cmd)
  if not VVbdQX:
   if VVoyO8: VVoyO8.VV4uR4()
   FFu1fZ(self, "No packages found!")
   return
  elif len(VVbdQX) == 1 and VVbdQX[0] == VVGEJv:
   FFu1fZ(self, VVGEJv)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVL1iO  = []
  for item in VVbdQX:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVL1iO.append((name, package, version))
  if mode > 0:
   extensions = FFEUax("ls %s -l | grep '^d' | awk '{print $9}'" % VVD9rK)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVL1iO:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVL1iO.append((name, VVD9rK + item, "-"))
   systemPlugins = FFEUax("ls %s -l | grep '^d' | awk '{print $9}'" % VVaET3)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVL1iO:
      if item.lower() == row[0].lower():
       break
     else:
      VVL1iO.append((item, VVaET3 + item, "-"))
  if not VVL1iO:
   FFu1fZ(self, "No packages found!")
   return
  if VVoyO8:
   VVL1iO.sort(key=lambda x: x[0].lower())
   VVoyO8.VVKBif(VVL1iO, title)
  else:
   widths = (20, 50, 30)
   VVgAHl = None
   VVR0s7 = None
   if mode == 0:
    VV1mml = ("Install" , self.VVaehh   , [])
    VVgAHl = ("Download" , self.VVzMXl   , [])
    VVR0s7 = ("Filter"  , self.VV4r7T , [])
   elif mode == 1:
    VV1mml = ("Uninstall", self.VVMZkm, [])
   elif mode == 2:
    VV1mml = ("Uninstall", self.VVMZkm, [])
    widths= (18, 57, 25)
   VVL1iO.sort(key=lambda x: x[0].lower())
   VVUZua = ("Package Info.", self.VVYnP4, [])
   header   = ("Name" ,"Package" , "Version" )
   FFMPky(self, None, header=header, VVL1iO=VVL1iO, VVLkOa=widths, VVJfxh=28, VV1mml=VV1mml, VVgAHl=VVgAHl, VVUZua=VVUZua, VVR0s7=VVR0s7, VVoJlH=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVI8Pk="#22110011", VV2s6D="#22191111", VVjLdB="#22191111", VVaZj9="#00003030", VVBGyD="#00333333")
 def VVYnP4(self, VVoyO8, title, txt, colList):
  package = colList[1]
  self.VVoDzQ(package)
 def VV4r7T(self, VVoyO8, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVMYdC = []
  VVMYdC.append(("All Packages", "all"))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVMYdC.append(VVc27s)
  for word in words:
   VVMYdC.append((word, word))
  FFcKE0(self, BF(self.VV29l4, VVoyO8), VVMYdC=VVMYdC, title="Select Filter")
 def VV29l4(self, VVoyO8, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFZmix(VVoyO8, BF(self.VVwuky, 0, grep, VVoyO8, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVMZkm(self, VVoyO8, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVD9rK, VVaET3)):
   FFlOO5(self, BF(self.VVnopn, VVoyO8, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVMYdC = []
   VVMYdC.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVMYdC.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVMYdC.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFcKE0(self, BF(self.VVj7OT, VVoyO8, package), VVMYdC=VVMYdC)
 def VVnopn(self, VVoyO8, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VV9ECk)
  FFrhsY(self, cmd, VVY0RJ=BF(self.VVMYmE, VVoyO8))
 def VVj7OT(self, VVoyO8, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVa96X
   elif item == "remove_ForceRemove"  : cmdOpt = VVDj0x
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVYhjR
   FFlOO5(self, BF(self.VVbwY6, VVoyO8, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVbwY6(self, VVoyO8, package, cmdOpt):
  self.lastSelectedRow = VVoyO8.VVr4DQ()
  cmd = FF9JgI(cmdOpt, package)
  if cmd : FFrhsY(self, cmd, VVY0RJ=BF(self.VVMYmE, VVoyO8))
  else : FF0x3g(self)
 def VVMYmE(self, VVoyO8):
  VVoyO8.cancel()
  FFaAOh()
 def VVaehh(self, VVoyO8, title, txt, colList):
  package  = colList[1]
  VVMYdC = []
  VVMYdC.append(("Install Package"         , "install_CheckVersion" ))
  VVMYdC.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVMYdC.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VVMYdC.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVMYdC.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFcKE0(self, BF(self.VVzMWa, package), VVMYdC=VVMYdC)
 def VVzMWa(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVuVG6
   elif item == "install_ForceReinstall" : cmdOpt = VVIf8A
   elif item == "install_ForceOverwrite" : cmdOpt = VVz9Zr
   elif item == "install_ForceDowngrade" : cmdOpt = VVpCbq
   elif item == "install_IgnoreDepends" : cmdOpt = VV5bJt
   FFlOO5(self, BF(self.VV3fEk, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VV3fEk(self, package, cmdOpt):
  cmd = FF9JgI(cmdOpt, package)
  if cmd : FFrhsY(self, cmd, VVY0RJ=FFaAOh, checkNetAccess=True)
  else : FF0x3g(self)
 def VVzMXl(self, VVoyO8, title, txt, colList):
  package  = colList[1]
  FFlOO5(self, BF(self.VVViJe, package), "Download Package ?\n\n%s" % package)
 def VVViJe(self, package):
  if FFPbOp():
   cmd = FF9JgI(VVOVp4, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFrfWO(success, VVhAfh))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFrfWO(fail, VVpQzP))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFrhsY(self, cmd, VV3BLh=[VVpQzP, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FF0x3g(self)
  else:
   FFu1fZ(self, "No internet connection !")
 def VVoDzQ(self, package):
  infoCmd  = FF9JgI(VVF4LK, package)
  filesCmd = FF9JgI(VV4LAz, package)
  listInstCmd = FF7FNT(VV8UyW, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFHmje(VVrhVl)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFrfWO(notInst, VVwtwf))
   cmd += "else "
   cmd +=   FFEL4q("System Info", VVrhVl)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFEL4q("Related Files", VVrhVl)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFaGWF(self, cmd)
  else:
   FF0x3g(self)
class CCkToA():
 def VVFFXJ(self, isRef):
  self.shareIsRef   = isRef
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VVWHdo()
 def VVWHdo(self):
  files = FFFgxj(VVXneu, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVMYdC = []
   for fil in files:
    VVMYdC.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVI8Pk, VV2s6D = "#22221133", "#22221133"
   else    : VVI8Pk, VV2s6D = "#22003344", "#22002233"
   VVAfNY  = ("Add new File", self.VVJbR6)
   VVyvO2 = ("Delete File", self.VVurJ1)
   FFcKE0(self, self.VVXGXX, VVMYdC=VVMYdC, width=1100, VVAfNY=VVAfNY, VVyvO2=VVyvO2, minRows=4, VVI8Pk=VVI8Pk, VV2s6D=VV2s6D)
  else:
   FFlOO5(self, self.VVhGnO, "No files found.\n\nCreate a new file ?")
 def VVhGnO(self):
  path = self.VV0wOX()
  if fileExists(path) : self.VVWHdo()
  else    : FFAcfo(self, "Cannot create file", 1500)
 def VVJbR6(self, menuInstance, path):
  path = self.VV0wOX()
  menuInstance.VV3HJz((os.path.basename(path), path), isSort=True)
 def VV0wOX(self):
  path = "%s%s%s.xml" % (VVXneu, self.shareFilePrefix, FFcOP9())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VVurJ1(self, menuInstance, path):
  FFlOO5(self, BF(self.VV2Qk5, menuInstance, path), "Delete this file ?\n\n%s" % path)
 def VV2Qk5(self, menuInstance, path):
  FF2PD3(path)
  if fileExists(path) : FFAcfo(menuInstance, "Not deleted", 1000)
  else    : menuInstance.VVLcYB()
 def VVXGXX(self, path=None):
  if path:
   FFZmix(self, BF(self.VV7UnH, path))
 def VV7UnH(self, path):
  if not fileExists(path):
   FF6iwf(self, path)
   return
  elif not CC5DZc.VVb7pn(self, path, FF3zTd()):
   return
  else:
   self.shareFilePath = path
  if not CC9IhO.VViIgt(self):
   return
  tree = CCFb9t.VVLG7C(self, self.shareFilePath)
  if not tree:
   return
  refLst = CC3Jx1.VV7nhB()
  def VV1fOZ(refCode):
   if   FFJN2c(refCode): return FFXe6i("DVB", VV80mJ)
   elif refCode in refLst     : return FFXe6i("IPTV", VV80mJ)
   else         : return ""
  VVbdQX= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VVl4kF(ch)
   if ok:
    srcTxt = VV1fOZ(srcRef)
    dstTxt = VV1fOZ(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVbdQX:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVbdQX.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVbdQX:
   if self.shareIsRef : VVI8Pk, VV2s6D, optTxt = "#22221133", "#22221133", "Share Reference"
   else    : VVI8Pk, VV2s6D, optTxt = "#1a003344", "#1a002233", "Copy EPG/PIcons"
   VV3Q2h = (""    , BF(self.VVQ8Ca, dupl), [])
   VVDAgH = (""    , self.VVaFuy    , [])
   VV1mml = ("Delete Entry" , self.VVgJxi   , [])
   VVgAHl = ("Add Entry"  , self.VV4Dne   , [])
   VVUZua = (optTxt   , self.VVKQP9  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VV28Ef = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVoyO8 = FFMPky(self, None, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=24, VV3Q2h=VV3Q2h, VVDAgH=VVDAgH, VV1mml=VV1mml, VVgAHl=VVgAHl, VVUZua=VVUZua, VVMVWT=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVI8Pk=VVI8Pk, VV2s6D=VV2s6D, VVjLdB=VV2s6D, VV58S5="#00ffffaa", VVaZj9="#0a000000")
  else:
   FFu1fZ(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VVQ8Ca(self, dupl, VVoyO8, title, txt, colList):
  if dupl:
   VVoyO8.VVdbDB("Skipped %d duplicate%s" % (dupl, FFmxIl(dupl)), 2000)
 def VVaFuy(self, VVoyO8, title, txt, colList):
  def VV1fOZ(key, val): return "%s\t: %s\n" % (key, val or FFXe6i("?", VV8DG7))
  Keys = VVoyO8.VVROug()
  Vals = VVoyO8.VV3wWK()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VV1fOZ(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VVhAfh, VV8DG7
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FF4gok(self, txt + txt1, title=title)
 def VVl4kF(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VVgJxi(self, VVoyO8, title, txt, colList):
  if VVoyO8.VVr4DQ() == 0 and VVoyO8.VV03io() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FFlOO5(self, BF(self.VVPPvw, isLast, VVoyO8), ques)
 def VVPPvw(self, isLast, VVoyO8):
  if isLast:
   FF2PD3(self.shareFilePath)
   VVoyO8.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVoyO8.VV3wWK()
   if self.VV6enP(srcName, srcRef, dstName, dstRef):
    VVoyO8.VVY64Q()
    VVoyO8.VV79WN()
    FFAcfo(VVoyO8, "Deleted", 500, isGrn=True)
   else:
    FFAcfo(VVoyO8, "Cannot delete from file", 2000)
 def VV4Dne(self, VVoyO8, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VVMCgM(VVoyO8, isDvb=True)
  else    : self.VVfMYq(VVoyO8, "Source Channel", "#22003344", "#22002233")
 def VVfMYq(self, mainTableInst, title, VVI8Pk, VV2s6D):
  FFcKE0(self, BF(self.VVk1Sw, mainTableInst, title), VVMYdC=[("DVB", "DVB"), ("IPTV", "IPTV")], title=title + " Type", width=800, VVI8Pk=VVI8Pk, VV2s6D=VV2s6D)
 def VVk1Sw(self, mainTableInst, title, item=None):
  if item:
   FFZmix(mainTableInst, BF(self.VVQIs3, mainTableInst, title, item), clearMsg=False)
 def VVQIs3(self, mainTableInst, title, item):
  FFAcfo(mainTableInst)
  if item == "DVB": self.VVMCgM(mainTableInst, isDvb=True)
  else   : self.VVMCgM(mainTableInst, isDvb=False)
 def VVbzw9(self, mainTableInst, chType, VVoyO8, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVoyO8.VVr4DQ()
  if   chType == "DVB" : FF72vQ(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FF72vQ(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVVGfF()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FFu1fZ(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VVeRwV(srcName, srcRef, dstName, dstRef):
      mainTableInst.VVKMAo((str(mainTableInst.VV03io() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FFAcfo(mainTableInst, "Added", 500, isGrn=True)
     else:
      FFAcfo(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FFAcfo(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VVMCgM(mainTableInst, isDvb=False)
   else    : FFC8Ey(BF(self.VVfMYq, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVoyO8.cancel()
 def VVZhrg(self, item, VVoyO8, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVoyO8.VVjS0j(ndx)
 def VVMCgM(self, VVoyO8, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VVbzw9, VVoyO8, typ)
  doneFnc = BF(self.VVZhrg, typ)
  if isDvb: CCkToA.VVFTDD(VVoyO8 , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CCkToA.VVBz80(VVoyO8, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VVFTDD(SELF, title, okFnc, doneFnc=None):
  FFZmix(SELF, BF(CCkToA.VVRgmr, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVRgmr(SELF, title, okFnc, doneFnc=None):
  VVbdQX, err = CCFb9t.VVmPx6(SELF, CCFb9t.VVH1Zz)
  if VVbdQX:
   color = "#0a000022"
   VVbdQX.sort(key=lambda x: x[0].lower())
   VVhqvZ = ("Select" , okFnc, [])
   VV3Q2h= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VV28Ef = (LEFT  , LEFT  , CENTER, LEFT    )
   FFMPky(SELF, None, title=title, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VVI8Pk=color, VV2s6D=color, VVjLdB=color, VVhqvZ=VVhqvZ, VV3Q2h=VV3Q2h, lastFindConfigObj=CFG.lastFindServices)
  else:
   FFu1fZ(SELF, "No DVB Services !")
 @staticmethod
 def VVBz80(SELF, title, okFnc, doneFnc=None):
  FFZmix(SELF, BF(CCkToA.VV136I, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VV136I(SELF, title, okFnc, doneFnc=None):
  VVbdQX = CCkToA.VVRomH()
  if VVbdQX:
   color = "#0a112211"
   VVbdQX.sort(key=lambda x: x[0].lower())
   VVhqvZ = ("Select" , okFnc, [])
   VV3Q2h= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FFMPky(SELF, None, title=title, header=header, VVL1iO=VVbdQX, VVLkOa=widths, VVJfxh=26, VVI8Pk=color, VV2s6D=color, VVjLdB=color, VVhqvZ=VVhqvZ, VV3Q2h=VV3Q2h, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFu1fZ(SELF, "No IPTV Services !")
 @staticmethod
 def VVRomH():
  VVbdQX = []
  files  = CC0A1M.VVGgNf()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFQgne(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VV2B8y = span.group(1)
    else : VV2B8y = ""
    VV2B8y_lCase = VV2B8y.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVbdQX.append((chName, VV2B8y, url, refCode))
  return VVbdQX
 def VVeRwV(self, srcName, srcRef, dstName, dstRef):
  tree = CCFb9t.VVLG7C(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VVo4m8(tree, root)
  return True
 def VV6enP(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CCFb9t.VVLG7C(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VVl4kF(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VVo4m8(tree, root)
  return found
 def VVo4m8(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CCFb9t.VVvAkT(xmlTxt)
  parser = CCFb9t.CCWaev()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VVKQP9(self, VVoyO8, title, txt, colList):
  VVMYdC = []
  if self.shareIsRef:
   FFlOO5(self, BF(FFZmix, VVoyO8, BF(self.VVIzCQ, VVoyO8)), "Copy all References from Source to Destination ?")
  else:
   VVMYdC.append(("Copy EPG\t (All List)" , "epg"  ))
   VVMYdC.append(("Copy Picons\t (All List)" , "picon" ))
   FFcKE0(self, BF(self.VVdBz7, VVoyO8), VVMYdC=VVMYdC, width=1000)
 def VVdBz7(self, VVoyO8, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VVdhdB  , "EPG"
   elif item == "picon": fnc, txt = self.VVFhFd , "PIcons"
   title = "Copy %s" % txt
   tot   = VVoyO8.VV03io()
   FFlOO5(self, BF(FFZmix, VVoyO8, BF(fnc, VVoyO8, title)), "Overwrite %s for %d Service%s ?" % (FFXe6i(txt, VVrhVl), tot, FFmxIl(tot)), title=title)
 def VVIzCQ(self, VVoyO8):
  files = CC0A1M.VVGgNf()
  totChange = 0
  if files:
   for path in files:
    txt = FFQgne(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVoyO8.VVVGfF():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFSSJm()
  tot = VVoyO8.VV03io()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FF4gok(self, txt)
 def VVFhFd(self, VVoyO8, title):
  if not iCopyfile:
   FFu1fZ(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CC2wnB.VV6OCP()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVoyO8.VVVGfF():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVoyO8.VV03io()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FF4gok(self, txt, title=title)
 def VVdhdB(self, VVoyO8, title):
  from enigma import eEPGCache
  totFound = totEvents = totSuccess = totInvalid = 0
  epgInst = eEPGCache.getInstance()
  if not epgInst:
   FFu1fZ(self, "Cannot access EPG Cache !", title=title)
   return
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVoyO8.VVVGfF():
   if remark == "0":
    evList = epgInst.lookupEvent(["BDTSE", (srcRef, 0, -1, 20160)])
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CChafy.VVxaKS(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CCkToA.VVlPWO()
  txt  = "Services\t: %d\n"  % VVoyO8.VV03io()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  FF4gok(self, txt, title=title)
 class CCWaev(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VVLG7C(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CCFb9t.CCWaev())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FFXe6i("XML Parse Error in:", VV8DG7), path)
   txt += "%s\n%s\n\n" % (FFXe6i("Error:", VV8DG7), str(e))
   FF4gok(SELF, txt, VVjLdB="#11220000", title=title)
   return None
 @staticmethod
 def VVvAkT(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
 @staticmethod
 def VVlPWO():
  try:
   from enigma import eEPGCache
   epgInst = eEPGCache.getInstance()
   if epgInst and hasattr(eEPGCache, "save"):
    epgInst.save()
  except:
   pass
class CCFb9t(Screen, CCkToA):
 VVI5ub  = 0
 VVB3ES = 1
 VV8C4z  = 2
 VVRjwd  = 3
 VVxOvm = 4
 VVbejM = 5
 VVmwIK = 6
 VVH1Zz   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FFTWzO(VV4Y67, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVJFtR = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVMYdC = self.VVeXxb()
  FF0Q0u(self, VVMYdC=VVMYdC, title="Services/Channels")
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self["myMenu"].setList(self.VVeXxb())
  FF4IYg(self["myMenu"])
  FFIvVk(self)
 def VVeXxb(self):
  VVMYdC = []
  c = VV80mJ
  VVMYdC.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVMYdC.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVMYdC.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVMYdC.append(VVc27s)
  c = VVJ6nn
  VVMYdC.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVMYdC.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVMYdC.append((VV8DG7 + "More tables ..."     , "VVPpzg"    ))
  c = VV2RHA
  VVMYdC.append(VVc27s)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVMYdC.append((c + txt          , "VVdyfg"  ))
  else : VVMYdC.append((txt           ,          ))
  VVMYdC.append((c + 'Export Services to "channels.xml"'    , "VVy968"      ))
  VVMYdC.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VVwhxm
  VVMYdC.append(VVc27s)
  VVMYdC.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVMYdC.append((c + "Invalid Services Cleaner"       , "VVYYtH"    ))
  c = VVwhxm
  VVMYdC.append(VVc27s)
  VVMYdC.append((c + "Delete Channels with no names"     , "VVy4oU"    ))
  VVMYdC.append((c + "Delete Empty Bouquets"       , "VV9CuD"     ))
  VVMYdC.append(VVc27s)
  VVfppQ, VVa8UD = CCFb9t.VVVYKr()
  if fileExists(VVfppQ):
   enab = fileExists(VVa8UD)
   if enab: VVMYdC.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVMYdC.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVMYdC.append(("Reset Parental Control Settings"      , "VVUfT1"    ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Reload Channels and Bouquets"       , "VVPhfU"      ))
  return VVMYdC
 def VVqqT1(self):
  global VVmICA
  VVmICA = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCDmyf.VVtxwR(self.session)
   elif item == "openSignal"       : FFXRBr(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFfM6H(self, fncMode=CChafy.VVAtR5)
   elif item == "lameDB_allChannels_with_refCode"  : FFZmix(self, self.VVAysm)
   elif item == "lameDB_allChannels_with_tranaponder" : FFZmix(self, self.VVTBxs)
   elif item == "VVPpzg"     : self.VVPpzg()
   elif item == "VVdyfg"  : CCjA2r.VVdyfg(self)
   elif item == "VVy968"      : self.VVy968()
   elif item == "copyEpgPicons"      : self.VVFFXJ(False)
   elif item == "SatellitesCleaner"     : FFZmix(self, self.FFZmix_SatellitesCleaner)
   elif item == "VVYYtH"    : FFZmix(self, BF(self.VVYYtH))
   elif item == "VVy4oU"    : FFZmix(self, self.VVy4oU)
   elif item == "VV9CuD"     : self.VV9CuD(self)
   elif item == "enableHiddenChannels"     : self.VVrqGU(True)
   elif item == "disableHiddenChannels"    : self.VVrqGU(False)
   elif item == "VVUfT1"    : FFlOO5(self, self.VVUfT1, "Reset and Restart ?")
   elif item == "VVPhfU"      : FFZmix(self, BF(CCFb9t.VVPhfU, self))
 def VVPpzg(self):
  VVMYdC = []
  VVMYdC.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVMYdC.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVMYdC.append(("Services with PIcons for the System"  , "VVPAoO"     ))
  VVMYdC.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVMYdC.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"     ))
  FFcKE0(self, self.VVOAC3, VVMYdC=VVMYdC, title="Service Information", VVglYk=True)
 def VVOAC3(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FFZmix(self, BF(self.VVt9GL, title))
   elif ref == "parentalControlChannels"   : FFZmix(self, BF(self.VVuSgY, title))
   elif ref == "showHiddenChannels"    : FFZmix(self, BF(self.VVwE8b, title))
   elif ref == "VVPAoO"    : FFZmix(self, BF(self.VV3k22, title))
   elif ref == "servicesWithMissingPIcons"   : FFZmix(self, BF(self.VVEHuj, title))
   elif ref == "TranspondersStats"     : FFZmix(self, BF(self.VVzlQG, title))
   elif ref == "SatellitesXmlStats"    : FFZmix(self, BF(self.VVXjdb, title))
 def VVy968(self):
  VVMYdC = []
  VVMYdC.append(("All DVB-S/C/T Services", "all"))
  VVMYdC.extend(CC3Jx1.VVJfY4())
  FFcKE0(self, self.VVpXGL, VVMYdC=VVMYdC, title="", VVglYk=True)
 def VVpXGL(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCFb9t.VVAwcV("1:7:")
   else   : lst = FFsJR6(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFYM1A(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFQ9UD(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FF5sxC(CFG.exportedTablesPath.getValue()), FFcOP9())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FF5VuW(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFAcfo(self, "No Services found !", 1500)
 @staticmethod
 def VVPhfU(SELF):
  FFSSJm()
  FF5VuW(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVAysm(self):
  self.VVJFtR = None
  self.lastfilterUsed  = None
  self.filterObj   = CCfZNJ(self)
  VVbdQX, err = CCFb9t.VVmPx6(self, self.VVI5ub)
  if VVbdQX:
   VVbdQX.sort(key=lambda x: x[0].lower())
   VVhqvZ  = ("Zap"   , self.VVMNij     , [])
   VVDAgH = (""    , self.VVYEEp   , [])
   VVUZua = ("Options"  , self.VVWsHK , [])
   VVgAHl = ("Current Service", self.VVl71o , [])
   VVR0s7 = ("Filter"   , self.VV8WLA  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VV28Ef  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFMPky(self, None, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VVhqvZ=VVhqvZ, VVDAgH=VVDAgH, VVgAHl=VVgAHl, VVUZua=VVUZua, VVR0s7=VVR0s7, lastFindConfigObj=CFG.lastFindServices)
 def VVTBxs(self):
  self.VVJFtR = None
  self.lastfilterUsed  = None
  self.filterObj   = CCfZNJ(self)
  VVbdQX, err = CCFb9t.VVmPx6(self, self.VVB3ES)
  if VVbdQX:
   VVbdQX.sort(key=lambda x: x[0].lower())
   VVhqvZ  = ("Zap"   , self.VVMNij      , [])
   VVDAgH = (""    , self.VVYEEp    , [])
   VVgAHl = ("Current Service", self.VVl71o  , [])
   VVUZua = ("Options"  , self.VVBYJ7 , [])
   VVR0s7 = ("Filter"   , self.VVJbFI  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VV28Ef  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFMPky(self, None, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VVhqvZ=VVhqvZ, VVDAgH=VVDAgH, VVgAHl=VVgAHl, VVUZua=VVUZua, VVR0s7=VVR0s7, lastFindConfigObj=CFG.lastFindServices)
 def VVWsHK(self, VVoyO8, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CCvNaQ(self, VVoyO8)
  VVMYdC = []
  isMulti = VVoyO8.VVdP3d
  if isMulti:
   refCodeList = VVoyO8.VV1mal(3)
   if refCodeList:
    VVMYdC.append(("Add Selection to Parental Control"    , "parentalControl_sel_add"  ))
    VVMYdC.append(("Remove Selection from Parental Control"   , "parentalControl_sel_remove" ))
    VVMYdC.append(VVc27s)
    VVMYdC.append(("Add Selection to Hidden Services"    , "hiddenServices_sel_add"  ))
    VVMYdC.append(("Remove Selection from Hidden Services"   , "hiddenServices_sel_remove" ))
    VVMYdC.append(VVc27s)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVMYdC.append((txt1, "parentalControl_add" ))
    VVMYdC.append((txt2,       ))
   else:
    VVMYdC.append((txt1,       ))
    VVMYdC.append((txt2, "parentalControl_remove"))
   VVMYdC.append(VVc27s)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVMYdC.append((txt1, "hiddenServices_add" ))
    VVMYdC.append((txt2,       ))
   else:
    VVMYdC.append((txt1,       ))
    VVMYdC.append((txt2, "hiddenServices_remove" ))
   VVMYdC.append(VVc27s)
  cbFncDict = { "parentalControl_add"   : BF(self.VV8Yxh, VVoyO8, refCode, True)
     , "parentalControl_remove"  : BF(self.VV8Yxh, VVoyO8, refCode, False)
     , "hiddenServices_add"   : BF(self.VVSEKm, VVoyO8, refCode, True)
     , "hiddenServices_remove"  : BF(self.VVSEKm, VVoyO8, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVwAQa, VVoyO8, True)
     , "parentalControl_sel_remove" : BF(self.VVwAQa, VVoyO8, False)
     , "hiddenServices_sel_add"  : BF(self.VVreKb, VVoyO8, True)
     , "hiddenServices_sel_remove" : BF(self.VVreKb, VVoyO8, False)
     }
  VVMYdC1, cbFncDict1 = CCFb9t.VV4Vo2(self, VVoyO8, servName, 3)
  VVMYdC.extend(VVMYdC1)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VVUtfc(VVMYdC, cbFncDict)
 def VVBYJ7(self, VVoyO8, title, txt, colList):
  servName = colList[0]
  mSel = CCvNaQ(self, VVoyO8)
  VVMYdC, cbFncDict = CCFb9t.VV4Vo2(self, VVoyO8, servName, 3)
  mSel.VVUtfc(VVMYdC, cbFncDict)
 @staticmethod
 def VV4Vo2(SELF, VVoyO8, servName, refCodeCol):
  tot = VVoyO8.VVlPPo()
  if tot > 0:
   sTxt = FFXe6i("%d Service%s" % (tot, FFmxIl(tot)), VVJ6nn)
   VVMYdC = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FF3RM7(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FFXe6i(servName, VVJ6nn)
   VVMYdC = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CCFb9t.VVICui, SELF, VVoyO8, refCodeCol, True)
     , "addToBouquet_one" : BF(CCFb9t.VVICui, SELF, VVoyO8, refCodeCol, False)
     }
  return VVMYdC, cbFncDict
 @staticmethod
 def VVICui(SELF, VVoyO8, refCodeCol, isMulti):
  picker = CC3Jx1(SELF, VVoyO8, "Add to Bouquet", BF(CCFb9t.VVkQS2, VVoyO8, refCodeCol, isMulti))
 @staticmethod
 def VVkQS2(VVoyO8, refCodeCol, isMulti):
  if isMulti : refCodeList = VVoyO8.VV1mal(refCodeCol)
  else  : refCodeList = [VVoyO8.VV3wWK()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VV8Yxh(self, VVoyO8, refCode, isAddToBlackList):
  VVoyO8.VVySY5("Processing ...")
  FFC8Ey(BF(self.VVcqni, VVoyO8, [refCode], isAddToBlackList))
 def VVwAQa(self, VVoyO8, isAddToBlackList):
  refCodeList = VVoyO8.VV1mal(3)
  if not refCodeList:
   FFu1fZ(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVoyO8.VVySY5("Processing ...")
  FFC8Ey(BF(self.VVcqni, VVoyO8, refCodeList, isAddToBlackList))
 def VVcqni(self, VVoyO8, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVG2da, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVG2da):
   lines = FFgYB4(VVG2da)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVG2da, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVoyO8.VVdP3d
   if isMulti:
    self.VVcixk(VVoyO8, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVhWtl(VVoyO8, refCode)
    VVoyO8.VV4uR4()
  else:
   VVoyO8.VVdbDB("No changes")
 def VVSEKm(self, VVoyO8, refCode, isHide):
  title = "Change Hidden State"
  if FFJN2c(refCode):
   VVoyO8.VVySY5("Processing ...")
   ret = FFR0a2(refCode, isHide)
   if ret : FFZmix(self, BF(self.VVhWtl, VVoyO8, refCode))
   else : FFu1fZ(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFu1fZ(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVhWtl(self, VVoyO8, refCode):
  VVbdQX, err = CCFb9t.VVmPx6(self, self.VVI5ub, VVkWoH=[3, [refCode], False])
  done = False
  if VVbdQX:
   data = VVbdQX[0]
   if data[3] == refCode:
    done = VVoyO8.VVlQTg(data)
  if not done:
   self.VVuiKd(VVoyO8, VVoyO8.VVA691(), self.VVI5ub)
  VVoyO8.VV4uR4()
 def VVcixk(self, VVoyO8, totRefCodes):
  VVbdQX, err = CCFb9t.VVmPx6(self, self.VVI5ub, VVkWoH=self.VVJFtR)
  VVoyO8.VVKBif(VVbdQX)
  VVoyO8.VVRw1e(False)
  VVoyO8.VVdbDB("%d Processed" % totRefCodes)
 def VVreKb(self, VVoyO8, isHide):
  refCodeList = VVoyO8.VV1mal(3)
  if not refCodeList:
   FFu1fZ(self, "Nothing selected", title="Change Hidden State")
   return
  VVoyO8.VVySY5("Processing ...")
  FFC8Ey(BF(self.VV3i0h, VVoyO8, refCodeList, isHide))
 def VV3i0h(self, VVoyO8, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFR0a2(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFSSJm(True)
   self.VVcixk(VVoyO8, len(refCodeList))
  else:
   VVoyO8.VVdbDB("No changes")
 def VV8WLA(self, VVoyO8, title, txt, colList):
  inFilterFnc = BF(self.VVPdP8, VVoyO8) if self.VVJFtR else None
  self.filterObj.VV9AUz(1, VVoyO8, 2, BF(self.VVq3Fo, VVoyO8), inFilterFnc=inFilterFnc)
 def VVq3Fo(self, VVoyO8, item):
  self.VVfl7a(VVoyO8, False, item, 2, self.VVI5ub)
 def VVPdP8(self, VVoyO8, menuInstance, item):
  self.VVfl7a(VVoyO8, True, item, 2, self.VVI5ub)
 def VVJbFI(self, VVoyO8, title, txt, colList):
  inFilterFnc = BF(self.VVO4re, VVoyO8) if self.VVJFtR else None
  self.filterObj.VV9AUz(2, VVoyO8, 4, BF(self.VVn8ew, VVoyO8), inFilterFnc=inFilterFnc)
 def VVn8ew(self, VVoyO8, item):
  self.VVfl7a(VVoyO8, False, item, 4, self.VVB3ES)
 def VVO4re(self, VVoyO8, menuInstance, item):
  self.VVfl7a(VVoyO8, True, item, 4, self.VVB3ES)
 def VV21DU(self, VVoyO8, title, txt, colList):
  inFilterFnc = BF(self.VVFzMI, VVoyO8) if self.VVJFtR else None
  self.filterObj.VV9AUz(0, VVoyO8, 4, BF(self.VVzYo6, VVoyO8), inFilterFnc=inFilterFnc)
 def VVzYo6(self, VVoyO8, item):
  self.VVfl7a(VVoyO8, False, item, 4, self.VV8C4z)
 def VVFzMI(self, VVoyO8, menuInstance, item):
  self.VVfl7a(VVoyO8, True, item, 4, self.VV8C4z)
 def VVfl7a(self, VVoyO8, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVoyO8.VVnbNr(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVJFtR = None
  else:
   words, asPrefix = CCfZNJ.VVGe34(words)
   self.VVJFtR = [col, words, asPrefix]
  if words: FFZmix(VVoyO8, BF(self.VVuiKd, VVoyO8, title, mode), clearMsg=False)
  else : FFAcfo(VVoyO8, "Incorrect filter", 2000)
 def VVuiKd(self, VVoyO8, title, mode):
  VVbdQX, err = CCFb9t.VVmPx6(self, mode, VVkWoH=self.VVJFtR, VVit1y=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVoyO8.VVVGfF():
    try:
     ndx = VVbdQX.index(tuple(list(map(str.strip, row))))
     lst.append(VVbdQX[ndx])
    except:
     pass
   VVbdQX = lst
  if VVbdQX:
   VVbdQX.sort(key=lambda x: x[0].lower())
   VVoyO8.VVKBif(VVbdQX, title)
  else:
   FFAcfo(VVoyO8, "Not found!", 1500)
 def VVgztx(self, title, VVL1iO, VVhqvZ=None, VVDAgH=None, VV1mml=None, VVgAHl=None, VVUZua=None, VVR0s7=None):
  VVgAHl = ("Current Service", self.VVl71o, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VV28Ef = (LEFT  , LEFT  , CENTER, LEFT    )
  FFMPky(self, None, title=title, header=header, VVL1iO=VVL1iO, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VVhqvZ=VVhqvZ, VVDAgH=VVDAgH, VV1mml=VV1mml, VVgAHl=VVgAHl, VVUZua=VVUZua, VVR0s7=VVR0s7, lastFindConfigObj=CFG.lastFindServices)
 def VVl71o(self, VVoyO8, title, txt, colList):
  self.VVbkxP(VVoyO8)
 def VVMxla(self, VVoyO8, title, txt, colList):
  self.VVbkxP(VVoyO8, True)
 def VVbkxP(self, VVoyO8, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVoyO8.VVvFYl(colDict, VVe3Eu=True)
   else:
    VVoyO8.VVawt3(3, refCode, True)
   return
  FFu1fZ(self, "Colud not read current Reference Code !")
 def VVt9GL(self, title):
  self.VVJFtR = None
  self.lastfilterUsed  = None
  self.filterObj   = CCfZNJ(self)
  VVbdQX, err = CCFb9t.VVmPx6(self, self.VV8C4z)
  if VVbdQX:
   VVbdQX.sort(key=lambda x: x[0].lower())
   VVDAgH = (""    , self.VVOYLZ , []      )
   VVgAHl = ("Current Service", self.VVMxla  , []      )
   VVR0s7 = ("Filter"   , self.VV21DU   , [], "Loading Filters ..." )
   VVhqvZ  = ("Zap"   , self.VVplw9      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VV28Ef  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFMPky(self, None, title=title, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VVhqvZ=VVhqvZ, VVDAgH=VVDAgH, VVgAHl=VVgAHl, VVR0s7=VVR0s7, lastFindConfigObj=CFG.lastFindServices)
 def VVOYLZ(self, VVoyO8, title, txt, colList):
  refCode  = self.VVItnZ(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFfM6H(self, fncMode=CChafy.VVItcW, refCode=refCode, chName=chName, text=txt)
 def VVplw9(self, VVoyO8, title, txt, colList):
  refCode = self.VVItnZ(colList)
  FFI9Ee(self, refCode)
 def VVMNij(self, VVoyO8, title, txt, colList):
  FFI9Ee(self, colList[3])
 def VVItnZ(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVnmkM(VVfppQ, mode=0):
  lines = FFgYB4(VVfppQ, encLst=["UTF-8"])
  return CCFb9t.VVO6Sa(lines, mode)
 @staticmethod
 def VVO6Sa(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VVmPx6(SELF, mode, VVkWoH=None, VVit1y=True, VVldMD=True):
  VVfppQ, err = CCFb9t.VVspmq(SELF, VVldMD)
  if err:
   return None, err
  asPrefix = False
  if VVkWoH:
   filterCol = VVkWoH[0]
   filterWords = VVkWoH[1]
   asPrefix = VVkWoH[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCFb9t.VVI5ub:
   blackList = None
   if fileExists(VVG2da):
    blackList = FFgYB4(VVG2da)
    if blackList:
     blackList = set(blackList)
  elif mode == CCFb9t.VVB3ES:
   tp = CChwwz()
  VVyF1f, VVU8J6 = FFhcDs()
  if mode in (CCFb9t.VVbejM, CCFb9t.VVmwIK):
   VVbdQX = {}
  else:
   VVbdQX = []
  tagFound = False
  with ioOpen(VVfppQ, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFGSRq(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCFb9t.VV8C4z:
       if sTypeInt in VVyF1f:
        STYPE = VVU8J6[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVbdQX.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVbdQX.append(tRow)
       else:
        VVbdQX.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCFb9t.VVH1Zz:
        VVbdQX.append((chName, chProv, sat, refCode))
       elif mode == CCFb9t.VVbejM:
        VVbdQX[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCFb9t.VVmwIK:
        VVbdQX[chName] = refCode
       elif mode == CCFb9t.VVI5ub:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVbdQX.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVbdQX.append(tRow)
        else:
         VVbdQX.append(tRow)
       elif mode == CCFb9t.VVB3ES:
        if sTypeInt in VVyF1f:
         STYPE = VVU8J6[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVuPu7(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVbdQX.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVbdQX.append(tRow)
        else:
         VVbdQX.append(tRow)
       elif mode == CCFb9t.VVRjwd:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVbdQX.append((chName, chProv, sat, refCode))
       elif mode == CCFb9t.VVxOvm:
        VVbdQX.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVbdQX and VVit1y:
   FFu1fZ(SELF, "No services found!")
  return VVbdQX, ""
 def VVuSgY(self, title):
  if fileExists(VVG2da):
   lines = FFgYB4(VVG2da)
   if lines:
    newRows = []
    VVbdQX, err = CCFb9t.VVmPx6(self, self.VVxOvm)
    if VVbdQX:
     lines = set(lines)
     for item in VVbdQX:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVbdQX = newRows
      VVbdQX.sort(key=lambda x: x[0].lower())
      VVDAgH = ("", self.VVYEEp, [])
      VVhqvZ = ("Zap", self.VVMNij, [])
      self.VVgztx(title, VVbdQX, VVhqvZ=VVhqvZ, VVDAgH=VVDAgH)
     else:
      FF4gok(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVbdQX)))
   else:
    FF5VuW(self, "No active Parental Control services.", FF3zTd())
  else:
   FF6iwf(self, VVG2da)
 def VVwE8b(self, title):
  VVbdQX, err = CCFb9t.VVmPx6(self, self.VVRjwd)
  if VVbdQX:
   VVbdQX.sort(key=lambda x: x[0].lower())
   VVDAgH = ("" , self.VVYEEp, [])
   VVhqvZ  = ("Zap", self.VVMNij, [])
   self.VVgztx(title, VVbdQX, VVhqvZ=VVhqvZ, VVDAgH=VVDAgH)
  elif err:
   pass
  else:
   FF5VuW(self, "No hidden services.", FF3zTd())
 def VVYYtH(self):
  title = "Services unused in Tuner Configuration"
  VVfppQ, err = CCFb9t.VVspmq(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CCFb9t.VV6d56()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VVsZsC(str(item[0]))
    nsLst.add(ns)
  sysLst = CCFb9t.VVAwcV("1:7:")
  tpLst  = CCFb9t.VVnmkM(VVfppQ, mode=1)
  VVbdQX = []
  for refCode, chName in sysLst:
   servID = CCFb9t.VVGegm(refCode)
   tpID = CCFb9t.VVIbtc(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVbdQX.append((chName, FFYM1A(refCode, False), refCode, servID))
  if VVbdQX:
   VVbdQX.sort(key=lambda x: x[0].lower())
   VVUZua = ("Options"   , BF(self.VVxRnD, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VV28Ef  = (LEFT  , CENTER , LEFT   , CENTER   )
   FFMPky(self, None, title=title, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VVUZua=VVUZua, VVI8Pk="#0a001122", VV2s6D="#0a001122", VVjLdB="#0a001122", VVaZj9="#00004455", VVBGyD="#0a333333", VVFIzs="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FF5VuW(self, "No invalid service found !", title=title)
 def VVxRnD(self, Title, VVoyO8, title, txt, colList):
  mSel = CCvNaQ(self, VVoyO8)
  isMulti = VVoyO8.VVdP3d
  if isMulti : txt = "Remove %s Services" % FFXe6i(str(VVoyO8.VVlPPo()), VV8DG7)
  else  : txt = "Remove : %s" % FFXe6i(VVoyO8.VV3wWK()[0], VV8DG7)
  VVMYdC = [(txt, "del")]
  cbFncDict = {"del": BF(FFZmix, VVoyO8, BF(self.VVqjtC, VVoyO8, Title))}
  mSel.VVUtfc(VVMYdC, cbFncDict)
 def VVqjtC(self, VVoyO8, title):
  VVfppQ, err = CCFb9t.VVspmq(self, title=title)
  if err:
   return
  isMulti = VVoyO8.VVdP3d
  skipLst = []
  if isMulti : skipLst = VVoyO8.VV1mal(3)
  else  : skipLst = [VVoyO8.VV3wWK()[3]]
  tpLst = CCFb9t.VVnmkM(VVfppQ, mode=0)
  servLst = CCFb9t.VVnmkM(VVfppQ, mode=10)
  tmpDbFile = VVfppQ + ".tmp"
  lines   = FFgYB4(VVfppQ)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  os.system(FFVKmy("mv -f '%s' '%s'" % (tmpDbFile, VVfppQ)))
  VVbdQX = []
  for row in VVoyO8.VVVGfF():
   if not row[3] in skipLst:
    VVbdQX.append(row)
  FFSSJm()
  FF4gok(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVbdQX:
   VVoyO8.VVKBif(VVbdQX, title)
   VVoyO8.VVRw1e(False)
  else:
   VVoyO8.cancel()
 def VVzlQG(self, title):
  VVfppQ, err = CCFb9t.VVspmq(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VV6Q8F(VVfppQ)
  txt = FFXe6i("Total Transponders:\n\n", VVhW2e)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFXe6i("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVhW2e)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFUIzI(item), satList.count(item))
  FF4gok(self, txt, title)
 def VV6Q8F(self, VVfppQ):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVfppQ, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVXjdb(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FF6iwf(self, path, title=title)
   return
  elif not CC5DZc.VVb7pn(self, path, title):
   return
  if not CC9IhO.VViIgt(self):
   return
  tree = CCFb9t.VVLG7C(self, path, title=title)
  if not tree:
   return
  VVbdQX = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FFGSRq(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVbdQX.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVbdQX:
   VVbdQX.sort(key=lambda x: int(x[1]))
   VVgAHl = ("Current Satellite", BF(self.VV5K5U, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VV28Ef  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FFMPky(self, None, title=title, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=25, VVWa5f=1, VVgAHl=VVgAHl, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFu1fZ(self, "No data found !", title=title)
 def VV5K5U(self, satCol, VVoyO8, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self)
  sat = FFYM1A(refCode, False)
  for ndx, row in enumerate(VVoyO8.VVVGfF()):
   if sat == row[satCol].strip():
    VVoyO8.VVjS0j(ndx)
    break
  else:
   FFAcfo(VVoyO8, "No listed !", 1500)
 def FFZmix_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FFu1fZ(self, "No Satellites found !")
   return
  usedSats = CCFb9t.VV6d56()
  VVbdQX = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVbdQX.append((sat[1], posTxt, FFGSRq(sat[0]), tuners, str(posVal)))
  if VVbdQX:
   VVjLdB = "#11222222"
   VVbdQX.sort(key=lambda x: int(x[1]))
   VVgAHl = ("Current Satellite" , BF(self.VV5K5U, 2) , [])
   VVUZua = ("Options"   , self.VVNTbZ  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VV28Ef  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FFMPky(self, None, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=28, VVgAHl=VVgAHl, VVUZua=VVUZua, VVI8Pk=VVjLdB, VV2s6D=VVjLdB, VVjLdB=VVjLdB, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFu1fZ(self, "No data found !")
 def VVNTbZ(self, VVoyO8, title, txt, colList):
  mSel = CCvNaQ(self, VVoyO8)
  isMulti = VVoyO8.VVdP3d
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FFXe6i(str(VVoyO8.VVlPPo()), VV8DG7)
  else  : txt = "Remove ALL Services on : %s" % FFXe6i(VVoyO8.VV3wWK()[0], VV8DG7)
  VVMYdC = []
  VVMYdC.append((txt, "deleteSat"))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Delete Empty Bouquets", "VV9CuD"))
  cbFncDict = { "deleteSat"   : BF(FFZmix, VVoyO8, BF(self.VVHVSR, VVoyO8))
     , "VV9CuD" : BF(self.VV9CuD, VVoyO8)
     }
  mSel.VVUtfc(VVMYdC, cbFncDict)
 def VVHVSR(self, VVoyO8):
  posLst = []
  isMulti = VVoyO8.VVdP3d
  posLst = []
  if isMulti : posLst = VVoyO8.VV1mal(4)
  else  : posLst = [VVoyO8.VV3wWK()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VVsZsC(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VV8MaY(nsLst)
  FFSSJm(True)
  FF4gok(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VV9CuD(self, winObj):
  title = "Delete Empty Bouquets"
  FFlOO5(self, BF(FFZmix, winObj, BF(self.VVNjUi, title)), "Delete bouquets with no services ?", title=title)
 def VVNjUi(self, title):
  bList = CC3Jx1.VVPCFM()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CC3Jx1.VVneYd(bRef)
    bPath = VVPZMJ + bFile
    FF2PD3(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVPZMJ + fil
     if fileExists(path):
      lines = FFgYB4(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFSSJm(True)
  if bNames: txt = "%s\n\n%s" % (FFXe6i("Deleted Bouquets:", VVJ6nn), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FF4gok(self, txt, title=title)
 def VVsZsC(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VV8MaY(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVPZMJ)
  for srcF in files:
   if fileExists(srcF):
    lines = FFgYB4(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFVUlP(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VV3k22(self, title)   : self.VVPAoO(title, True)
 def VVEHuj(self, title) : self.VVPAoO(title, False)
 def VVPAoO(self, title, isWithPIcons):
  piconsPath = CC2wnB.VV6OCP()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CC2wnB.VVa0Bw(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVbdQX, err = CCFb9t.VVmPx6(self, self.VVxOvm)
    if VVbdQX:
     channels = []
     for (chName, chProv, sat, refCode) in VVbdQX:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FF1qvC(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVbdQX)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VV1fOZ(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VV1fOZ("PIcons Path"  , piconsPath)
     txt += VV1fOZ("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VV1fOZ("Total services" , totalServices)
     txt += VV1fOZ("With PIcons"  , totalWithPIcons)
     txt += VV1fOZ("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FF4gok(self, txt)
     else:
      VVDAgH     = (""      , self.VVYEEp , [])
      if isWithPIcons : VVR0s7 = ("Export Current PIcon", self.VVVIeU  , [])
      else   : VVR0s7 = None
      VVUZua     = ("Statistics", FF4gok, [txt])
      VVhqvZ      = ("Zap", self.VVMNij, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVgztx(title, channels, VVhqvZ=VVhqvZ, VVDAgH=VVDAgH, VVUZua=VVUZua, VVR0s7=VVR0s7)
   else:
    FFu1fZ(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFu1fZ(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVYEEp(self, VVoyO8, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFfM6H(self, fncMode=CChafy.VVItcW, refCode=refCode, chName=chName, text=txt)
 def VVVIeU(self, VVoyO8, title, txt, colList):
  png, path = CC2wnB.VVSgaB(colList[3], colList[0])
  if path:
   CC2wnB.VV7Yh8(self, png, path)
 @staticmethod
 def VVVYKr():
  VVfppQ  = "%slamedb" % VVPZMJ
  VVa8UD = "%slamedb.disabled" % VVPZMJ
  return VVfppQ, VVa8UD
 @staticmethod
 def VVNufk():
  VVNKS2  = "%slamedb5" % VVPZMJ
  VVzBW2 = "%slamedb5.disabled" % VVPZMJ
  return VVNKS2, VVzBW2
 def VVrqGU(self, isEnable):
  VVfppQ, VVa8UD = CCFb9t.VVVYKr()
  if isEnable and not fileExists(VVa8UD):
   FF5VuW(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVfppQ):
   FFu1fZ(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFlOO5(self, BF(self.VVoT0c, isEnable), "%s Hidden Channels ?" % word)
 def VVoT0c(self, isEnable):
  VVfppQ , VVa8UD = CCFb9t.VVVYKr()
  VVNKS2, VVzBW2 = CCFb9t.VVNufk()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVa8UD, VVa8UD, VVfppQ)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVzBW2, VVzBW2, VVNKS2)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (VVfppQ  , VVfppQ , VVa8UD)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (VVNKS2 , VVNKS2, VVzBW2)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVa8UD, VVfppQ )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVzBW2, VVNKS2)
  res = os.system(cmd)
  FFSSJm()
  if res == 0 : FF5VuW(self, "Hidden List %s" % word)
  else  : FFu1fZ(self, "Error while restoring:\n\n%s" % fileName)
 def VVUfT1(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %ssettings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVPZMJ
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %ssettings" % VVPZMJ
  FFSyy7(self, cmd)
 def VVy4oU(self):
  VVfppQ, err = CCFb9t.VVspmq(self)
  if err:
   return
  tmpFile = "/tmp/ajpanel_lamedb"
  FF2PD3(tmpFile)
  totChan = totRemoved = 0
  lines = FFgYB4(VVfppQ, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FFlOO5(self, BF(FFZmix, self, BF(self.VVGdeu, tmpFile, VVfppQ, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FFmxIl(totRemoved), totChan, FFmxIl(totChan))
      , callBack_No=BF(self.VVGLDy, tmpFile))
  else:
   FF4gok(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVGdeu(self, tmpFile, VVfppQ, totRemoved, totChan):
  os.system(FFVKmy("mv -f '%s' '%s'" % (tmpFile, VVfppQ)))
  FFSSJm()
  FF4gok(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VVGLDy(self, tmpFile):
  FF2PD3(tmpFile)
 @staticmethod
 def VVspmq(SELF, VVldMD=True, title=""):
  VVfppQ, VVa8UD = CCFb9t.VVVYKr()
  if   not fileExists(VVfppQ)       : err = "File not found !\n\n%s" % VVfppQ
  elif not CC5DZc.VVb7pn(SELF, VVfppQ) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VVldMD:
   FFu1fZ(SELF, err, title=title)
  return VVfppQ, err
 @staticmethod
 def VVIbtc(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VVGegm(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VVAwcV(servTypes):
  VVcQ52  = eServiceCenter.getInstance()
  VVUpD0   = '%s ORDER BY name' % servTypes
  VVXSvN   = eServiceReference(VVUpD0)
  VVuccN = VVcQ52.list(VVXSvN)
  if VVuccN: return VVuccN.getContent("CN", False)
  else     : return []
 @staticmethod
 def VV6d56():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CChafy(Screen):
 VVAtR5  = 0
 VVEvyh   = 1
 VVwn7t   = 2
 VVItcW    = 3
 VVF32o    = 4
 VVPUuq   = 5
 VV7aH7   = 6
 VVRMLS    = 7
 VV80u3   = 8
 VVUT3c   = 9
 VVXptl   = 10
 VV0Ata   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFTWzO(VVZQMO, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVAtR5)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FFXe6i("%s\n", VVB3E5) % VVn31f
  self.picViewer  = None
  FF0Q0u(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVOOkz })
  self["myPicF"]  = Label()
  self["myPicB"]  = Label()
  self["myPic"]  = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VViGDa)
  self.onClose.append(self.onExit)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  self["myLabel"].VVmdiX(outputFileToSave="chann_info")
  if   self.fncMode == self.VVAtR5 : fnc = self.VV4CDo
  elif self.fncMode == self.VVEvyh  : fnc = self.VV4CDo
  elif self.fncMode == self.VVwn7t  : fnc = self.VV4CDo
  elif self.fncMode == self.VVItcW  : fnc = self.VVlRef
  elif self.fncMode == self.VVF32o  : fnc = self.VVy0Zo
  elif self.fncMode == self.VVPUuq  : fnc = self.VV9AfO
  elif self.fncMode == self.VV7aH7  : fnc = self.VVIuAZ
  elif self.fncMode == self.VVRMLS  : fnc = self.VVQIzj
  elif self.fncMode == self.VV80u3  : fnc = self.VVuiNb
  elif self.fncMode == self.VVUT3c : fnc = self.VVIWxi
  elif self.fncMode == self.VVXptl  : fnc = self.VVp3MF
  elif self.fncMode == self.VV0Ata : fnc = self.VVLGgv
  self["myLabel"].setText("\n   Reading Info ...")
  FFC8Ey(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVe1XB()
 def VVsblq(self, err):
  self["myLabel"].setText(err)
  FFaCb6(self["myTitle"], "#22200000")
  FFaCb6(self["myBody"], "#22200000")
  self["myLabel"].VV23bO("#22200000")
  self["myLabel"].VVq6UY()
 def VV4CDo(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self)
  self.refCode = refCode
  self.VVVluj(chName)
 def VVlRef(self):
  self.VVVluj(self.chName)
 def VVy0Zo(self):
  self.VVVluj(self.chName)
 def VV9AfO(self):
  self.VVVluj(self.chName)
 def VVIuAZ(self):
  self.VVVluj("Picon Info")
 def VVQIzj(self):
  self.VVVluj(self.chName)
 def VVuiNb(self):
  self.VVVluj(self.chName)
 def VVIWxi(self):
  self.VVVluj(self.chName)
 def VVp3MF(self):
  self.chUrl = self.refCode + self.callingSELF.VVvtNX(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVVluj(self.chName)
 def VVLGgv(self):
  self.VVVluj(self.chName)
 def VVVluj(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFR3hA(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVBTDS(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFXe6i(self.VVhf6f(tUrl), VVycQx)
  if not self.epg:
   epg = self.VVDWpM(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVGHVi(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CC2wnB.VVSgaB(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVGHVi(path)
  self.VV5UuV()
  self.VVDTrI()
  self["myLabel"].setText(self.text or "   No active service", VVr1DU=VVewqn)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVq6UY(minHeight=minH)
 def VVDTrI(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFQ9UD(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VV6tz6(FFxspG(url))
  if epg:
   self.text += "\n" + FF9bzo("EPG:", VVJ6nn) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VV5UuV()
 def VV5UuV(self):
  if not self.piconShown and self.picUrl:
   path, err = FFmy2V(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVGHVi(path)
    if self.piconShown and self.refCode:
     self.VVqjM0(path, self.refCode)
 def VVqjM0(self, path, refCode):
  if path and fileExists(path) and os.system(FFVKmy("which ffmpeg")) == 0:
   pPath = CC2wnB.VV6OCP()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CChafy.VVA5VG(path)
    cmd += FFVKmy("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVGHVi(self, path):
  if path and fileExists(path):
   err, w, h = self.VVAjZd(path)
   if not err:
    if h > w:
     self.VVkZBf(self["myPicF"], w, h, True)
     self.VVkZBf(self["myPicB"], w, h, False)
     self.VVkZBf(self["myPic"] , w, h, False)
   self.picViewer = CCA2G7.VVoo99(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VVkZBf(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVAjZd(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFY14S(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVBTDS(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFXe6i(chName, VVJ6nn)
  txt += self.VV1fOZ(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFXe6i(state, VVwtwf)
   txt += "State\t: %s\n" % state
  w = FFhyVK(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFhyVK(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVvDds(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VV1fOZ(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VV1fOZ(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VV1fOZ(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VV8Tt4()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVJ6jf()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CChafy.VVtAo5(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFXe6i("IPTV", VVhW2e)
   txt += self.VVfXrz(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVpuQn(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CChwwz()
    tpTxt, namespace = tp.VV4Uc9(refCode)
    if tpTxt:
     txt += FFXe6i("Tuner:\n", VVJ6nn)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFXe6i("Codes:\n", VVJ6nn)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VV1fOZ(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VV1fOZ(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VV1fOZ(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VV1fOZ(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VV1fOZ(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VV1fOZ(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VV1fOZ(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VV1fOZ(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VV1fOZ(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVvDds(info):
  if info:
   aspect = FFhyVK(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VV1fOZ(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFhyVK(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVIBLi(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVIBLi(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VV8Tt4(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VVJ6jf(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVpuQn(self, refCode, iptvRef, chName):
  refCode = FFQWno(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFQgne(VVPZMJ + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFQgne(VVPZMJ + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VVL1iO = []
  tmpRefCode = FFxspG(refCode)
  for item in fList:
   path = VVPZMJ + item
   if fileExists(path):
    txt = FFQgne(path)
    if tmpRefCode in FFxspG(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVL1iO.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VVL1iO:
   if len(VVL1iO) == 1:
    txt += "%s\t: %s%s\n" % (FFXe6i("Bouquet", VVJ6nn), VVL1iO[0][0], " (%s)" % VVL1iO[0][1] if VVxnW2 else "")
   else:
    txt += FFXe6i("Bouquets:\n", VVJ6nn)
    for ndx, item in enumerate(VVL1iO):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVxnW2 else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVDWpM(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVwC65(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVwC65(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVwC65(event, 0)
     except:
      pass
  return epg
 def VVwC65(self, event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CChafy.VVyRUj(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = CChafy.VV5zH1(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FFXe6i(evName, VVJ6nn)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FFXe6i(evNameTransl, VVJ6nn))
    if evTime           : txt += "Start Time\t: %s\n" % FF2ogC(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FF2ogC(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFZcBU(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFZcBU(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFZcBU(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFXe6i(evShort, VV2RHA)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFXe6i(evDesc , VV2RHA)
    if txt:
     txt = FFXe6i("\n%s\n%s Event:\n%s\n" % (VVn31f, ("Current", "Next")[evNum], VVn31f), VVJ6nn) + txt
  return txt
 def VVfXrz(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFfknX(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCMCGp()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVpwES(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFXe6i("URL:", VVhW2e) + "\n%s\n" % self.VVhf6f(decodedUrl)
  else:
   txt = "\n"
   txt += FFXe6i("Reference:", VVhW2e) + "\n%s\n" % refCode
  return txt
 def VVhf6f(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VVxD6t:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").replace("%3A", ":").strip()
 def VV6tz6(self, decodedUrl):
  if not FFPbOp():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CC0A1M.VVpVfO(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CC0A1M.VVKC2S(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVe2ru(tDict)
   elif uType == "movie" : epg, picUrl = CChafy.VVAlJc(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVe2ru(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CC0A1M.VVcM1V(item, "title"    , is_base64=True )
     lang    = CC0A1M.VVcM1V(item, "lang"         ).upper()
     description   = CC0A1M.VVcM1V(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CC0A1M.VVcM1V(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CC0A1M.VVcM1V(item, "start_timestamp"      )
     stop_timestamp  = CC0A1M.VVcM1V(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CC0A1M.VVcM1V(item, "stop_timestamp"       )
     now_playing   = CC0A1M.VVcM1V(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVGCti, ""
      else     : color, txt = VVwtwf , "    (CURRENT EVENT)"
      epg += FFXe6i("_" * 32 + "\n", VVB3E5)
      epg += FFXe6i("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFXe6i(description, VVycQx)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVxaKS(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVAlJc(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CC0A1M.VVcM1V(item, "movie_image" )
    genre  = CC0A1M.VVcM1V(item, "genre"   ) or "-"
    plot  = CC0A1M.VVcM1V(item, "plot"   ) or "-"
    cast  = CC0A1M.VVcM1V(item, "cast"   ) or "-"
    rating  = CC0A1M.VVcM1V(item, "rating"   ) or "-"
    director = CC0A1M.VVcM1V(item, "director"  ) or "-"
    releasedate = CC0A1M.VVcM1V(item, "releasedate" ) or "-"
    duration = CC0A1M.VVcM1V(item, "duration"  ) or "-"
    try:
     lang = CC0A1M.VVcM1V(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFXe6i(cast, VVycQx)
    epg += "Plot:\n%s"    % FFXe6i(CChafy.VV5zH1(plot), VVycQx)
   except:
    pass
  return epg, movie_image
 @staticmethod
 def VV5zH1(evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = CChafy.VVhK3F(evTxt, lang)
   return CChafy.VVrjhX(txt).strip() or evTxt
 def VVOOkz(self):
  if VVxD6t:
   def VV1fOZ(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VV1fOZ(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCMCGp()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVpwES(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VV1fOZ(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (VVn31f, txt))
   FFAcfo(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVrjhX(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VVnhYY(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   try:
    from enigma import eEPGCache
    eCache = eEPGCache.getInstance()
    if eCache:
     event = eCache.lookupEventTime(serv, -1, 0)
     if event: return CChafy.VVyRUj(event)
   except:
    pass
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event: return CChafy.VVyRUj(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVyRUj(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CChafy.VVoUNS(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVVr99(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   try:
    from enigma import eEPGCache
    eCache = eEPGCache.getInstance()
    if eCache:
     for evNum in range(2):
      event = eCache.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CChafy.VVyRUj(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FF2ogC(evTime)
       evEndTxt  = FF2ogC(evEnd)
       evDurTxt  = FFZcBU(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FFZcBU(evPos)
        evRem = evEnd - now
        evRemTxt = FFZcBU(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FFZcBU(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VVhK3F(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFfLv9(txt))
   txt, err = CC0A1M.VVKC2S(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFxspG(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVxaKS(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VVljjl(SELF):
  if not CCf0Mb.VVMQrW(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(SELF)
  err = url =  fSize = resumable = ""
  if FFnRfV(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCMCGp.VVReMj(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCMCGp.VVZaQK(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFu1fZ(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CC5DZc.VVmkPo(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFXe6i(" (M3U/M3U8 File)", VVycQx)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CC0kPO.VVLPzh(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VV3eCd(subj, val):
   return "%s\n%s\n\n" % (FFXe6i("%s:" % subj, VVJ6nn), val)
  title = "File Size"
  txt  = VV3eCd(title , fSize or "?")
  txt += VV3eCd("Name" , chName)
  txt += VV3eCd("URL" , url)
  if resumable: txt += VV3eCd("Supports Download-Resume", resumable)
  if err  : txt += FFXe6i("Error:\n", VVwtwf) + err
  FF4gok(SELF, txt, title=title)
 @staticmethod
 def VVtAo5(SELF):
  fPath, fDir, fName = CC5DZc.VVektX(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVoUNS(event):
  genre = PR = ""
  try:
   genre  = CChafy.VV6P97(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CChafy.VVZMl8(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVZMl8(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VV6P97(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CChafy.VVnYzW()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVnYzW():
  path = VVlId3 + "genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFQgne(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFQgne(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVA5VG(path):
  return "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
 @staticmethod
 def VVmNEw(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CC2wnB.VV6OCP() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VVKPDn(serv):
  isLocal = isIptv = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if FFQ9UD(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFVUlP(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCMCGp():
 def __init__(self):
  self.VVBAgU   = ""
  self.VVJNaw    = ""
  self.VVVuHm   = ""
  self.VVJT1V = ""
  self.VVxLLi  = ""
  self.VVIgQM = 0
  self.VVbbJo    = ""
  self.VVUNYk   = "#f#11ffffaa#User"
  self.VVPdIS   = "#f#11aaffff#Server"
 def VVvVYO(self, url, mac, ph1="", VVe3Eu=True):
  self.VVBAgU   = ""
  self.VVJNaw    = ""
  self.VVVuHm   = ""
  self.VVJT1V = ""
  self.VVxLLi  = ""
  self.VVIgQM = 0
  self.VVbbJo    = {"s": "/server/load.php", "p": "/portal.php"}.get(ph1, "")
  host = self.VVjVSE(url)
  if not host:
   if VVe3Eu:
    self.VVGEG2("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVx4Gv(mac)
  if not host:
   if VVe3Eu:
    self.VVGEG2("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVBAgU = host
  self.VVJNaw  = mac
  return True
 def VVjVSE(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVx4Gv(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVkU6b(self):
  res, err = self.VV0zaN(self.VVzGac())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VVBAgU:
   self.VVBAgU = self.VVBAgU.replace(urlPath, "")
   res, err = self.VV0zaN(self.VVzGac())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CC0A1M.VVcM1V(tDict["js"], "token")
    rand  = CC0A1M.VVcM1V(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVH3mP(self, VVe3Eu=True):
  if not self.VVbbJo:
   self.VVbbJo = self.VVLvGY()
  err = blkMsg = FF5VuWTxt = ""
  try:
   token, rand, err = self.VVkU6b()
   if token:
    self.VVVuHm = token
    self.VVJT1V = rand
    if rand:
     self.VVIgQM = 2
    prof, retTxt = self.VVjLHE(True)
    if prof:
     self.VVxLLi = retTxt
     if "device_id mismatch" in retTxt:
      self.VVIgQM = 3
      prof, retTxt = self.VVjLHE(False)
      if retTxt:
       self.VVxLLi = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FF5VuWTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FF5VuWTxt: tErr += "\n%s" % FF5VuWTxt
  if VVe3Eu:
   self.VVGEG2(tErr)
  return "", "", tErr
 def VVLvGY(self):
  try:
   import requests
   res = requests.get("%s/c/xpcom.common.js" % self.VVBAgU, headers=CCMCGp.VVZaQK(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       return span.group(1)
  except:
   pass
  return ""
 def VVjLHE(self, capMac):
  res, err = self.VV0zaN(self.VVo6s5(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CC0A1M.VVcM1V(tDict["js"], "block_%s" % word)
    FF5VuWTxt = CC0A1M.VVcM1V(tDict["js"], word)
    return tDict, FF5VuWTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVo6s5(self, capMac):
  param = ""
  if self.VVxLLi or self.VVJT1V:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVJNaw.upper() if capMac else self.VVJNaw.lower(), self.VVJT1V))
  return self.VVSPkq() + "type=stb&action=get_profile" + param
 exec(FFl7mx("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gID0gIiZhdXRoX3NlY29uZF9zdGVwPTEmaHdfdmVyc2lvbj0yLjE3LUlCLTAwJmh3X3ZlcnNpb25fMj02MiZzbj0lcyZkZXZpY2VfaWQ9JXMmZGV2aWNlX2lkMj0lcyZzaWduYXR1cmU9JXMiICUgKElkWzBdLCBJZFsxXSwgSWRbMV0sIElkWzJdKQ0KIHJldHVybiBwYXJhbSArICcmbWV0cmljcz17Im1hYyI6IiVzIiwic24iOiIlcyIsInR5cGUiOiJTVEIiLCJtb2RlbCI6Ik1BRzI1MCIsInJhbmRvbSI6IiVzIn0nICUgKElkWzNdLCBJZFswXSwgSWRbNF0pDQpkZWYgZ2V0TW9yZUF1dGhfSURzKHNlbGYsIG0sIHIpOg0KIGltcG9ydCBoYXNobGliDQogbWFjVXRmOCA9IG0uZW5jb2RlKCd1dGYtOCcpDQogcyA9IGhhc2hsaWIubWQ1KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKClbOjEzXQ0KIHJldHVybiBzLCBoYXNobGliLnNoYTI1NihtYWNVdGY4KS5oZXhkaWdlc3QoKS51cHBlcigpLCBoYXNobGliLnNoYTI1NigocyArIG0pLmVuY29kZSgndXRmLTgnKSkuaGV4ZGlnZXN0KCkudXBwZXIoKSwgbSwgcg=="))
 def VVSvDf(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVEtfy()
  if len(rows) < 10:
   rows = self.VVLCge()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVBAgU ))
   rows.append(("MAC (from URL)" , self.VVJNaw ))
   rows.append(("Token"   , self.VVVuHm ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVUNYk  , "MAC" , self.VVJNaw ))
   rows.append(("2", self.VVPdIS, "Host" , self.VVBAgU ))
   rows.append(("2", self.VVPdIS, "Token" , self.VVVuHm ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVpvHZ(self, isPhp=True, VVe3Eu=False):
  token, profile, tErr = self.VVH3mP(VVe3Eu)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VVxgxN()
  res, err = self.VV0zaN(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CC0A1M.VVcM1V(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFfLv9(span.group(2))
     pass1 = FFfLv9(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VVEtfy(self):
  m3u_Url, host, user1, pass1, err = self.VVpvHZ()
  rows = []
  if m3u_Url:
   res, err = self.VV0zaN(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FF2ogC(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVUNYk, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FF2ogC(int(val))
      else      : val = str(val)
      rows.append(("2", self.VVPdIS, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVLCge(self):
  token, profile, tErr = self.VVH3mP()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FF9U3V(val): val = FFl7mx(val.decode("UTF-8"))
     else     : val = self.VVJNaw
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FF2ogC(int(parts[1]))
      if parts[2] : ends = FF2ogC(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FF2ogC(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVvtNX(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVH3mP(VVe3Eu=False)
  if not token:
   return ""
  crLinkUrl = self.VVphSE(mode, chCm, epNum, epId)
  res, err = self.VV0zaN(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CC0A1M.VVcM1V(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVSPkq(self):
  return self.VVBAgU + (self.VVbbJo or "/server/load.php") + "?"
 def VVzGac(self):
  return self.VVSPkq() + "type=stb&action=handshake&token=&mac=%s" % self.VVJNaw
 def VVo6KX(self, mode):
  url = self.VVSPkq() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVHkUE(self, catID):
  return self.VVSPkq() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VV0xx6(self, mode, catID, page):
  url = self.VVSPkq() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVIICa(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VVSPkq() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVpABz(self, mode, catID):
  return self.VVSPkq() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVphSE(self, mode, chCm, serCode, serId):
  url = self.VVSPkq() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=false" % (mode, chCm)
  return url
 def VVxgxN(self):
  return self.VVSPkq() + "type=itv&action=create_link"
 def VVqBmW(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VV1u2M(catID, stID, chNum)
  query = self.VV7V3f(mode, self.VVbbJo[1:2], FF6R75(host), FF6R75(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VV7V3f(self, mode, ph1, host, mac, serCode, serId, chCm):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVpwES(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VV7V3f(mode, ph1, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFl7mx(host)
  mac   = FFl7mx(mac)
  valid = False
  if self.VVjVSE(playHost) and self.VVjVSE(host) and self.VVjVSE(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query
 def VV0zaN(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCMCGp.VVZaQK()
   if self.VVVuHm:
    headers["Authorization"] = "Bearer %s" % self.VVVuHm
   if useCookies : cookies = {"mac": self.VVJNaw, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok :
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVsdyN(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCMCGp.VVZaQK(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVZaQK():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VVglPY(host, mac, tType, action, keysList=[]):
  myPortal = CCMCGp()
  ph1 = "s"
  pref = "/portal.php" if par == "p" else "/server/load.php"
  ok = myPortal.VVvVYO(host, mac, ph1)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVH3mP(VVe3Eu=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s%s?type=%s&action=%s" % (host, ph1, tType, action)
  res, err = myPortal.VV0zaN(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VV1zvj(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VV1zvj(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVGEG2(self, err, title="Portal Browser"):
  FFu1fZ(self, str(err), title=title)
 def VVMWwT(self, mode):
  if   mode in ("itv"  , CC0A1M.VV5OCW , CC0A1M.VVNqui)  : return "Live"
  elif mode in ("vod"  , CC0A1M.VV4DQN , CC0A1M.VVR9Np)  : return "VOD"
  elif mode in ("series" , CC0A1M.VVHjam , CC0A1M.VVbbs0) : return "Series"
  else                          : return "IPTV"
 def VVrhbR(self, mode, searchName):
  return 'Find in %s : %s' % (self.VVMWwT(mode), FFXe6i(searchName, VVycQx))
 def VVit8t(self, catchup=False):
  VVMYdC = []
  VVMYdC.append(("Live"    , "live"  ))
  VVMYdC.append(("VOD"    , "vod"   ))
  VVMYdC.append(("Series"   , "series"  ))
  if catchup:
   VVMYdC.append(VVc27s)
   VVMYdC.append(("Catch-up TV" , "catchup"  ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Account Info." , "accountInfo" ))
  return VVMYdC
 @staticmethod
 def VVjXgS(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCMCGp()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVpwES(decodedUrl)
  if valid:
   ok = p.VVvVYO(host, mac, ph1, VVe3Eu=False)
   if ok:
    m3u_Url, host, user1, pass1, err = p.VVpvHZ(isPhp=False, VVe3Eu=False)
    streamId = CCMCGp.VVY7Dd(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err
 @staticmethod
 def VVY7Dd(decodedUrl):
  p = CCMCGp()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVpwES(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFl7mx(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVReMj(decodedUrl):
  p = CCMCGp()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVpwES(decodedUrl)
  if valid:
   if CCMCGp.VVkDUo(chCm):
    return FFxspG(chCm)
   else:
    ok = p.VVvVYO(host, mac, ph1, VVe3Eu=False)
    if ok:
     try:
      chUrl = p.VVvtNX(mode, chCm, epNum, epId)
      return FFxspG(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VVkDUo(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
class CCEwD2(CCMCGp):
 def __init__(self):
  CCMCGp.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVy3E7(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVpwES(decodedUrl)
  if valid:
   if self.VVvVYO(host, mac, ph1, VVe3Eu=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVWlEn(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVvtNX(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CCMCGp.VVkDUo(self.chCm):
   chUrl = FFxspG(self.chCm)
   chUrl = FFfLv9(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVeJFS(chUrl)
  bPath = CC3Jx1.VVcSuS()
  if newIptvRef:
   if passedSELF:
    FFI9Ee(passedSELF, newIptvRef, VVtcz9=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFI9Ee(self, newIptvRef, VVtcz9=False, fromPrtalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VV0fmf(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VVeJFS(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VV0fmf(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("&ph1=s", "&ph1=p", "&ph1=")
   for param in params: newPar = newPar.replace(param, "")
   lines = FFgYB4(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for param in params: filePar = filePar.replace(param, "")
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFSSJm()
class CCljOF(CCEwD2):
 def __init__(self, passedSession):
  CCEwD2.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVTEfD(VVvCFn  )
  Main_Menu.VVTEfD(VVaqQL)
  Main_Menu.VVTEfD(VVNr4r  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVV27z, iPlayableService.evEOF: self.VVZF4n, iPlayableService.evEnd: self.VVgtnw})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VV6b4e)
  except:
   self.timer2.callback.append(self.VV6b4e)
  self.timer2.start(3000, False)
  self.VV6b4e()
 def VV6b4e(self):
  if not CFG.downloadMonitor.getValue():
   self.VVmm93()
   return
  lst = CC0kPO.VVX0Zz()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFehaw(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CC0kPO.VVo1Ex(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin:
    self.dnldWin = self.passedSession.instantiateDialog(CCAUKk, txt, 30)
    self.dnldWin.instance.move(ePoint(30, 20))
    self.dnldWin.show()
    FFjTr6(self.dnldWin["myWinTitle"], "#440000", 1)
   else:
    self.dnldWin["myWinTitle"].setText(txt)
  elif self.dnldWin:
   self.VVmm93()
 def VVmm93(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVV27z(self):
  self.startTime = iTime()
 def VVZF4n(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self.passedSession, isFromSession=True)
    if iptvRef and not FFnRfV(decodedUrl):
     self.isFromEOF = True
     CCfA4C(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVgtnw(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVfDD7)
  except:
   self.timer1.callback.append(self.VVfDD7)
  self.timer1.start(100, True)
 def VVfDD7(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVy3E7(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCDmyf.VVek82:
       self.isFromEOF = False
       self.VVWlEn(self.passedSession, isFromSession=True)
class CCfLea():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Z0-9]+\s*\|*[|:-]\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-z0-9\/\-._:|\]\[]+[\])|:](.+)")
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "xxi", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.adultWords2 = ("\u042d\u0440\u043e\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0435", "dla doros\u0142ych")
 def VVMLC0(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CC0A1M.VVtpMb(name):
   return CC0A1M.VVipgr(name)
  name = self.VV9nr8(name)
  return name.strip() or name
 def VV9nr8(self, name):
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    return span.group(1) or span.group(2)
  return name
 def VVYsaO(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VV9nr8(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVK7g4(self, name):
  if self.hideAdult:
   if any(x in name.lower() for x in self.adultWords):
    return ""
   elif any(x in name.encode('ascii', 'backslashreplace').decode('utf-8').lower() for x in self.adultWords2):
    return ""
  return name.strip()
 def VVwZ5s(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVgRGT(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCf0Mb(CCMCGp):
 def __init__(self):
  CCMCGp.__init__(self)
 def VVxIQh(self):
  if CCf0Mb.VVMQrW(self):
   FFZmix(self, BF(self.VV8c1V, 2), title="Searching ...")
 def VVsrUr(self, winSession, url, mac):
  if CCf0Mb.VVMQrW(self):
   if self.VVvVYO(url, mac):
    FFZmix(winSession, self.VVLLk7, title="Checking Server ...")
   else:
    FFu1fZ(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVX3L9(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CCSqSs.VVcaEq(path, self)
   if enc == -1:
    return
   self.session.open(CC54zA, barTheme=CC54zA.VVlVsr
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVYQmz, path, enc)
       , VV2r3B = BF(self.VVGk8j, menuInstance, path))
 def VVYQmz(self, path, enc, VVeDSa):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVeDSa.VVvPX7(totLines)
  VVeDSa.VVinQh = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVeDSa or VVeDSa.isCancelled:
     return
    VVeDSa.VVs1tz(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVjVSE(url)
     mac  = self.VVx4Gv(mac)
     if host and mac and VVeDSa:
      VVeDSa.VVinQh.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVjVSE(url)
      mac  = self.VVx4Gv(mac)
      if host and mac and not mac.startswith("AC") and VVeDSa:
       VVeDSa.VVinQh.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVGk8j(self, menuInstance, path, VVw6fk, VVinQh, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVinQh:
   VV1mml  = ("Home Menu"  , FFsT0V            , [])
   VVUZua = ("Edit File"  , BF(self.VVgBNd, path)       , [])
   VVgAHl = ("M3U Options" , self.VV8gCq         , [])
   VVR0s7 = ("Check & Filter" , BF(self.VVsigs, menuInstance, path), [])
   VVhqvZ  = ("Select"   , self.VVeJcO      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VV28Ef  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVoyO8 = FFMPky(self, None, title=title, header=header, VVL1iO=VVinQh, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VVhqvZ=VVhqvZ, VV1mml=VV1mml, VVgAHl=VVgAHl, VVUZua=VVUZua, VVR0s7=VVR0s7, VVI8Pk="#0a001122", VV2s6D="#0a001122", VVjLdB="#0a001122", VVaZj9="#00004455", VVBGyD="#0a333333", VVFIzs="#11331100", VVMVWT=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VVw6fk:
    FFAcfo(VVoyO8, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVw6fk:
    FFu1fZ(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VV8gCq(self, VVoyO8, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVMYdC = []
  VVMYdC.append(("Browse as M3U"  , "browse"))
  VVMYdC.append(("Download M3U File" , "downld"))
  FFcKE0(self, BF(self.VVCC3A, VVoyO8, host, mac), title=title, VVMYdC=VVMYdC, width=600, VVglYk=True)
 def VVCC3A(self, VVoyO8, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FFZmix(VVoyO8, BF(self.VVfWZD, VVoyO8, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFlOO5(self, BF(FFZmix, VVoyO8, BF(self.VVfWZD, VVoyO8, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVfWZD(self, VVoyO8, title, host, mac, item):
  p = CCMCGp()
  m3u_Url = ""
  ok = p.VVvVYO(host, mac, VVe3Eu=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VVpvHZ(VVe3Eu=False)
  if m3u_Url:
   if   item == "browse": self.VVgWgu(title, m3u_Url)
   elif item == "downld": self.VVAD1A(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FFu1fZ(self, err or "No response from Server !", title=title)
 def VVeJcO(self, VVoyO8, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVsrUr(VVoyO8, url, mac)
 def VVgBNd(self, path, VVoyO8, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCV79S(self, path, VV2r3B=BF(self.VVYK7D, VVoyO8), curRowNum=rowNum)
  else    : FF6iwf(self, path)
 def VVsigs(self, menuInstance, path, VVoyO8, title, txt, colList):
  self.session.open(CC54zA, barTheme=CC54zA.VVIWtA
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVLJ76, VVoyO8)
      , VV2r3B = BF(self.VVoKSe, menuInstance, VVoyO8, path))
 def VVLJ76(self, VVoyO8, VVeDSa):
  VVeDSa.VVinQh = []
  VVeDSa.VVvPX7(VVoyO8.VV03io())
  for row in VVoyO8.VVVGfF():
   if not VVeDSa or VVeDSa.isCancelled:
    return
   VVeDSa.VVs1tz(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVvVYO(host, mac, VVe3Eu=False):
    token, profile, tErr = self.VVH3mP(VVe3Eu=False)
    if token and VVeDSa and not VVeDSa.isCancelled:
     res, err = self.VV0zaN(self.VVo6KX("itv"))
     if res and VVeDSa and not VVeDSa.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVeDSa.VVs1tz(0, showFound=True)
       VVeDSa.VVinQh.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVeDSa:
    return
 def VVoKSe(self, menuInstance, VVoyO8, path, VVw6fk, VVinQh, threadCounter, threadTotal, threadErr):
  if VVinQh:
   VVoyO8.close()
   menuInstance.close()
   newPath = "%s_OK_%s.txt" % (path, FFcOP9())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVinQh:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FFXe6i(str(threadCounter), VVwtwf)
    skipped = FFXe6i(str(threadTotal - threadCounter), VVwtwf)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVinQh)
   txt += "%s\n\n%s"    %  (FFXe6i("Result File:", VVJ6nn), newPath)
   FF4gok(self, txt, title="Accessible Portals")
  elif VVw6fk:
   FFu1fZ(self, "No portal access found !", title="Accessible Portals")
 def VVyk5l(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFl7mx(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVLLk7(self):
  token, profile, tErr = self.VVH3mP()
  if token:
   dots = "." * self.VVIgQM
   dots += "+" if self.VVbbJo[1:2] == "p" else ""
   VVMYdC  = self.VVit8t()
   OKBtnFnc = self.VVp2dM
   VVM2qe = ("Home Menu", FFsT0V)
   VVyvO2= ("Add to Menu", BF(CC0A1M.VVkcgJ, self, True, self.VVBAgU + "\t" + self.VVJNaw))
   VVtkPa = ("Bookmark Server", BF(CC0A1M.VVV8dQ, self, True, self.VVBAgU + "\t" + self.VVJNaw))
   FFcKE0(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVJNaw, dots), VVMYdC=VVMYdC, OKBtnFnc=OKBtnFnc, VVM2qe=VVM2qe, VVyvO2=VVyvO2, VVtkPa=VVtkPa)
 def VVp2dM(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFZmix(menuInstance, BF(self.VVc88S, mode), title="Reading Categories ...")
   else : FFZmix(menuInstance, BF(self.VVNEsS, menuInstance, title), title="Reading Account ...")
 def VVNEsS(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VVSvDf(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVJNaw)
  VV1mml  = ("Home Menu" , FFsT0V         , [])
  VVgAHl  = None
  if VVxnW2:
   VVgAHl = ("Get JS"  , BF(self.VVKgnD, self.VVBAgU), [])
  if totCols == 2:
   VVR0s7 = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVR0s7 = ("More Info.", BF(self.VVRGJ4, menuInstance)  , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFMPky(self, None, title=title, width=1200, header=header, VVL1iO=rows, VVLkOa=widths, VVJfxh=26, VV1mml=VV1mml, VVgAHl=VVgAHl, VVR0s7=VVR0s7, VVI8Pk="#0a00292B", VV2s6D="#0a002126", VVjLdB="#0a002126", VVaZj9="#00000000", searchCol=searchCol)
 def VVKgnD(self, url, VVoyO8, title, txt, colList):
  FFZmix(VVoyO8, BF(self.VV2Qcf, url), title="Getting JS ...")
 def VV2Qcf(self, url):
  txt = "// Host\t: %s\n" % url
  verOK = False
  ver, err = self.VV7zA8("%s/c/version.js" % url)
  if err:
   txt += err
  else:
   txt += "// Version\t: %s\n\n" % ver
   js, err = self.VV7zA8("%s/c/xpcom.common.js" % url)
   if err: txt += err
   else  : txt += "%s" % js
  FF4gok(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VV7zA8(self, url):
  res, err = self.VV0zaN(url)
  if err:
   return "", "Error: %s" % err
  else:
   cont = res.headers.get("content-type")
   if "javascript" in cont : return res.text, ""
   else     : return "", "\nError: content-type = %s" % cont
 def VVRGJ4(self, menuInstance, VVoyO8, title, txt, colList):
  VVoyO8.cancel()
  FFZmix(menuInstance, BF(self.VVNEsS, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVc88S(self, mode):
  token, profile, tErr = self.VVH3mP()
  if not token:
   return
  res, err = self.VV0zaN(self.VVo6KX(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     VVAP1F = CCfLea()
     chList = tDict["js"]
     for item in chList:
      Id   = CC0A1M.VVcM1V(item, "id"       )
      Title  = CC0A1M.VVcM1V(item, "title"      )
      censored = CC0A1M.VVcM1V(item, "censored"     )
      Title = VVAP1F.VVK7g4(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVxnW2:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVMWwT(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVI8Pk, VV2s6D, VVjLdB, VVaZj9 = self.VV3ix7(mode)
   mName = self.VVMWwT(mode)
   VVhqvZ   = ("Show List"   , BF(self.VVpHkJ, mode)   , [])
   VV1mml  = ("Home Menu"   , FFsT0V        , [])
   if mode in ("vod", "series"):
    VVUZua = ("Find in %s" % mName , BF(self.VVfp81, mode, False), [])
    VVR0s7 = ("Find in Selected" , BF(self.VVfp81, mode, True) , [])
   else:
    VVUZua = None
    VVR0s7 = None
   header   = None
   widths   = (100   , 0  )
   FFMPky(self, None, title=title, width=1200, header=header, VVL1iO=list, VVLkOa=widths, VVJfxh=30, VV1mml=VV1mml, VVUZua=VVUZua, VVR0s7=VVR0s7, VVhqvZ=VVhqvZ, VVI8Pk=VVI8Pk, VV2s6D=VV2s6D, VVjLdB=VVjLdB, VVaZj9=VVaZj9, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVxLLi:
     txt += "\n\n( %s )" % self.VVxLLi
   else:
    txt = "Could not get Categories from server!"
   FFu1fZ(self, txt, title=title)
 def VVb4LN(self, mode, VVoyO8, title, txt, colList):
  FFZmix(VVoyO8, BF(self.VV9ZXm, mode, VVoyO8, title, txt, colList), title="Downloading ...")
 def VV9ZXm(self, mode, VVoyO8, title, txt, colList):
  token, profile, tErr = self.VVH3mP()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VV0zaN(self.VVHkUE(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CC0A1M.VVcM1V(item, "id"    )
      actors   = CC0A1M.VVcM1V(item, "actors"   )
      added   = CC0A1M.VVcM1V(item, "added"   )
      age    = CC0A1M.VVcM1V(item, "age"   )
      category_id  = CC0A1M.VVcM1V(item, "category_id" )
      description  = CC0A1M.VVcM1V(item, "description" )
      director  = CC0A1M.VVcM1V(item, "director"  )
      genres_str  = CC0A1M.VVcM1V(item, "genres_str"  )
      name   = CC0A1M.VVcM1V(item, "name"   )
      path   = CC0A1M.VVcM1V(item, "path"   )
      screenshot_uri = CC0A1M.VVcM1V(item, "screenshot_uri" )
      series   = CC0A1M.VVcM1V(item, "series"   )
      cmd    = CC0A1M.VVcM1V(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VVhqvZ  = ("Play"    , BF(self.VVgNF5, mode)       , [])
   VVDAgH = (""     , BF(self.VV3tdk, mode)     , [])
   VV1mml = ("Home Menu"   , FFsT0V            , [])
   VVgAHl = ("Download Options" , BF(self.VVELWJ, mode, "sp", seriesName) , [])
   VVUZua = ("Options"   , BF(self.VVl9qk, "pEp", mode, seriesName) , [])
   VVR0s7 = ("Posters Mode"  , BF(self.VVqdwx, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VV28Ef  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFMPky(self, None, title=seriesName, width=1200, header=header, VVL1iO=list, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VVhqvZ=VVhqvZ, VVDAgH=VVDAgH, VV1mml=VV1mml, VVgAHl=VVgAHl, VVUZua=VVUZua, VVR0s7=VVR0s7, lastFindConfigObj=CFG.lastFindIptv, VVI8Pk="#0a00292B", VV2s6D="#0a002126", VVjLdB="#0a002126", VVaZj9="#00000000")
  else:
   FFu1fZ(self, "Could not get Episodes from server!", title=seriesName)
 def VVfp81(self, mode, searchInCat, VVoyO8, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVMYdC = []
  VVMYdC.append(("Keyboard"  , "manualEntry"))
  VVMYdC.append(("From Filter" , "fromFilter"))
  FFcKE0(self, BF(self.VVxRab, VVoyO8, mode, searchCatId), title="Input Type", VVMYdC=VVMYdC, width=400)
 def VVxRab(self, VVoyO8, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFSAou(self, BF(self.VVeQz8, VVoyO8, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCfZNJ(self)
    filterObj.VVoTGH(BF(self.VVeQz8, VVoyO8, mode, searchCatId))
 def VVeQz8(self, VVoyO8, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FF72vQ(CFG.lastFindIptv, searchName)
   title = self.VVrhbR(mode, searchName)
   if "," in searchName : FFu1fZ(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FFu1fZ(self, "Enter at least 3 characters.", title=title)
   else     :
    VVAP1F = CCfLea()
    if CFG.hideIptvServerAdultWords.getValue() and VVAP1F.VVwZ5s([searchName]):
     FFu1fZ(self, VVAP1F.VVgRGT(), title=title)
    else:
     self.VVGKB0(mode, searchName, "", searchName, searchCatId)
 def VVpHkJ(self, mode, VVoyO8, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVGKB0(mode, bName, catID, "", "")
 def VVGKB0(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CC54zA, barTheme=CC54zA.VVlVsr
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVEp68, mode, bName, catID, searchName, searchCatId)
      , VV2r3B = BF(self.VV1s3X, mode, bName, catID, searchName, searchCatId))
 def VV1s3X(self, mode, bName, catID, searchName, searchCatId, VVw6fk, VVinQh, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVrhbR(mode, searchName)
  else   : title = "%s : %s" % (self.VVMWwT(mode), bName)
  if VVinQh:
   VVgAHl = None
   VVUZua = None
   if mode == "series":
    VVI8Pk, VV2s6D, VVjLdB, VVaZj9 = self.VV3ix7("series2")
    VVhqvZ  = ("Episodes"   , BF(self.VVb4LN, mode)           , [])
   else:
    VVI8Pk, VV2s6D, VVjLdB, VVaZj9 = self.VV3ix7("")
    VVhqvZ  = ("Play"    , BF(self.VVgNF5, mode)           , [])
    VVgAHl = ("Download Options" , BF(self.VVELWJ, mode, "vp" if mode == "vod" else "", "") , [])
    VVUZua = ("Options"   , BF(self.VVl9qk, "pCh", mode, bName)      , [])
   VVDAgH = (""      , BF(self.VVsWKB, mode)         , [])
   VV1mml = ("Home Menu"    , FFsT0V                , [])
   VVR0s7 = ("Posters Mode"   , BF(self.VVqdwx, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Category/Genre" , "Logo")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25    , 6  )
   VV28Ef  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT    , CENTER)
   VVoyO8 = FFMPky(self, None, title=title, header=header, VVL1iO=VVinQh, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VV1mml=VV1mml, VVgAHl=VVgAHl, VVUZua=VVUZua, VVR0s7=VVR0s7, lastFindConfigObj=CFG.lastFindIptv, VVhqvZ=VVhqvZ, VVDAgH=VVDAgH, VVI8Pk=VVI8Pk, VV2s6D=VV2s6D, VVjLdB=VVjLdB, VVaZj9=VVaZj9, VVMVWT=True, searchCol=1)
   if not VVw6fk:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVoyO8.VV7PwH(VVoyO8.VVA691() + tot)
    if threadErr: FFAcfo(VVoyO8, "Error while reading !", 2000)
    else  : FFAcfo(VVoyO8, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFu1fZ(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFu1fZ(self, "Could not get list from server !", title=title)
 def VVsWKB(self, mode, VVoyO8, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFfM6H(self, fncMode=CChafy.VV0Ata, portalHost=self.VVBAgU, portalMac=self.VVJNaw, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVqbU7(mode, VVoyO8, title, txt, colList)
 def VV3tdk(self, mode, VVoyO8, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFXe6i(colList[10], VVycQx)
  txt += "Description:\n%s" % FFXe6i(colList[11], VVycQx)
  self.VVqbU7(mode, VVoyO8, title, txt, colList)
 def VVqbU7(self, mode, VVoyO8, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV9owg(mode, colList)
  refCode, chUrl = self.VVqBmW(self.VVBAgU, self.VVJNaw, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFfM6H(self, fncMode=CChafy.VVXptl, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVEp68(self, mode, bName, catID, searchName, searchCatId, VVeDSa):
  try:
   token, profile, tErr = self.VVH3mP()
   if not token:
    return
   if VVeDSa.isCancelled:
    return
   VVeDSa.VVinQh, total_items, max_page_items, err = self.VVquKd(mode, catID, 1, 1, searchName, searchCatId)
   if VVeDSa.isCancelled:
    return
   if VVeDSa.VVinQh and total_items > -1 and max_page_items > -1:
    VVeDSa.VVvPX7(total_items)
    VVeDSa.VVs1tz(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVeDSa.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVquKd(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVeDSa.VV0BdM()
     if VVeDSa.isCancelled:
      return
     if list:
      VVeDSa.VVinQh += list
      VVeDSa.VVs1tz(len(list), True)
  except:
   pass
 def VVquKd(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVIICa(mode, searchName, searchCatId, page)
  else   : url = self.VV0xx6(mode, catID, page)
  res, err = self.VV0zaN(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VV88s7(CC0A1M.VVcM1V(item, "total_items" ))
     max_page_items = self.VV88s7(CC0A1M.VVcM1V(item, "max_page_items" ))
     VVAP1F = CCfLea()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CC0A1M.VVcM1V(item, "id"    )
      name   = CC0A1M.VVcM1V(item, "name"   )
      o_name   = CC0A1M.VVcM1V(item, "o_name"   )
      tv_genre_id  = CC0A1M.VVcM1V(item, "tv_genre_id" )
      number   = CC0A1M.VVcM1V(item, "number"   ) or str(counter)
      logo   = CC0A1M.VVcM1V(item, "logo"   )
      screenshot_uri = CC0A1M.VVcM1V(item, "screenshot_uri" )
      cmd    = CC0A1M.VVcM1V(item, "cmd"   )
      censored  = CC0A1M.VVcM1V(item, "censored"  )
      genres_str  = CC0A1M.VVcM1V(item, "genres_str"  )
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       span = iSearch(r"stream=(.+)&", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
       else:
        span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      isIcon = "Yes" if picon else ""
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVBAgU + picon).replace(sp * 2, sp)
      counter += 1
      name = VVAP1F.VVMLC0(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd, genres_str, isIcon))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VV88s7(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVgNF5(self, mode, VVoyO8, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV9owg(mode, colList)
  refCode, chUrl = self.VVqBmW(self.VVBAgU, self.VVJNaw, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVtpMb(chName):
   FFAcfo(VVoyO8, "This is a marker!", 300)
  else:
   FFZmix(VVoyO8, BF(self.VVghzE, mode, VVoyO8, chUrl), title="Playing ...")
 def VVghzE(self, mode, VVoyO8, chUrl):
  FFI9Ee(self, chUrl, VVtcz9=False)
  CCDmyf.VVtxwR(self.session, iptvTableParams=(self, VVoyO8, mode))
 def VV9opw(self, mode, VVoyO8, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV9owg(mode, colList)
  refCode, chUrl = self.VVqBmW(self.VVBAgU, self.VVJNaw, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VV9owg(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVMQrW(SELF):
  try:
   import requests
   return True
  except:
   title = 'Install "Requests"'
   VVMYdC = []
   VVMYdC.append((title        , "inst" ))
   VVMYdC.append(("Update Packages then %s" % title , "updInst" ))
   FFcKE0(SELF, BF(CCf0Mb.VV4Eyg, SELF), title='This requires Python "Requests" library', VVMYdC=VVMYdC)
   return False
 @staticmethod
 def VV4Eyg(SELF, item=None):
  if item:
   from sys import version_info
   cmdUpd = FF7FNT(VVOEW0, "")
   if cmdUpd:
    cmdInst = FF9JgI(VVuVG6, "python-requests")
    if version_info[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFrhsY(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library')
   else:
    FF0x3g(SELF)
class CC0A1M(Screen, CCf0Mb, CCkToA):
 VVRxCP    = 0
 VV44PO    = 1
 VVrbX2    = 2
 VV8148    = 3
 VVNfv0     = 4
 VVA3rM     = 5
 VVQxJH     = 6
 VVvvbC     = 7
 VVm86O     = 8
 VVyLUQ      = 9
 VVOAFD     = 10
 VVuMHG     = 11
 VVx0Zt     = 12
 VVU4Rk     = 13
 VV9xeO      = 14
 VVbQuP      = 15
 VVbsjm      = 16
 VVYOXb      = 17
 VVRarc      = 18
 VVAWu6    = 0
 VV5OCW   = 1
 VV4DQN   = 2
 VVHjam   = 3
 VVBnzb  = 4
 VVmzst  = 5
 VVNqui   = 6
 VVR9Np   = 7
 VVbbs0  = 8
 VVgnjV  = 9
 VV2MWB  = 10
 VVdLpu = 0
 VVu9kN = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFTWzO(VV4Y67, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVoyO8    = None
  self.tableTitle     = "IPTV Channels List"
  self.VVrKIdData    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CC0A1M.VVGgNf(atLeastOne=True)
  CCf0Mb.__init__(self)
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VVwhxm
  VVMYdC = []
  if isFav1: VVMYdC.append((c +  "Favourite Playlist Server"   , "VV0ppJ" ))
  if isFav2: VVMYdC.append((c +  "Favourite Portal Server"    , "VVVj4uPortal" ))
  VVMYdC.append(("IPTV Server Browser (from Playlists)"     , "VVrKId_fromPlayList" ))
  VVMYdC.append(("IPTV Server Browser (from Portal List)"    , "VVrKId_fromMac"  ))
  VVMYdC.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VVrKId_fromM3u"  ))
  qUrl, iptvRef = self.VVgqF5()
  item = "IPTV Server Browser (from Current Channel)"
  if qUrl or "chCode" in iptvRef : VVMYdC.append((item     , "VVrKId_fromCurrChan" ))
  else       : VVMYdC.append((item     ,       ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("M3U/M3U8 File Browser"        , "VV7XcY"   ))
  if self.iptvFileAvailable:
   VVMYdC.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVMYdC.append(VVc27s)
  item1 = "Update Current Bouquet EPG (from IPTV Server)"
  item2 = "Update Current Bouquet PIcons (from IPTV Server)"
  if qUrl or "chCode" in iptvRef:
   VVMYdC.append((item1            , "refreshIptvEPG"   ))
   VVMYdC.append((item2            , "refreshIptvPicons"  ))
  else:
   VVMYdC.append((item1            ,       ))
   VVMYdC.append((item2            ,       ))
  if self.iptvFileAvailable:
   VVMYdC.append(VVc27s)
   c1, c2 = VV2RHA, VVJ6nn
   t1 = FFXe6i("auto-match names", VVwhxm)
   t2 = FFXe6i("from xml file"  , VVwhxm)
   VVMYdC.append((c1 + "Count Available IPTV Channels"    , "VVg8rC"    ))
   VVMYdC.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVMYdC.append(VVc27s)
   VVMYdC.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVMYdC.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VV6cBO" ))
   VVMYdC.append((VV8DG7 + "More Reference Tools ..."  , "VVPlOd"   ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Reload Channels and Bouquets"       , "VVPhfU"   ))
  VVMYdC.append(VVc27s)
  if not CC0kPO.VVCfZp():
   VVMYdC.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVMYdC.append(("Download Manager ... No donwloads"    ,       ))
  FF0Q0u(self, title="IPTV", VVMYdC=VVMYdC)
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FF4IYg(self["myMenu"])
  FFIvVk(self)
  FF1LZP(self)
  if self.m3uOrM3u8File:
   self.VVan2u(self.m3uOrM3u8File)
 def VVV5qI(self, item):
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVNqvg"   : self.VVNqvg()
   elif item == "VV7bkk" : FFlOO5(self, self.VV7bkk, "Change Current List References to Unique Codes ?")
   elif item == "VVBfXi_rows" : FFlOO5(self, BF(FFZmix, self.VVoyO8, self.VVBfXi), "Change Current List References to Identical Codes ?")
   elif item == "VVcrol"   : self.VVcrol(tTitle)
   elif item == "VVeacT"   : self.VVeacT(tTitle)
   elif item == "VV0ppJ" : self.VVVj4u(False)
   elif item == "VVVj4uPortal" : self.VVVj4u(True)
   elif item == "VVrKId_fromPlayList" : FFZmix(self, BF(self.VV8c1V, 1), title=title)
   elif item == "VVrKId_fromM3u"  : FFZmix(self, BF(self.VVmsY9, 0), title=title)
   elif item == "VVrKId_fromMac"  : self.VVxIQh()
   elif item == "VVrKId_fromCurrChan" : self.VVYF5C()
   elif item == "VV7XcY"   : self.VV7XcY()
   elif item == "iptvTable_all"   : FFZmix(self, BF(self.VV3dPC, self.VVRxCP), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VViwDl()
   elif item == "refreshIptvPicons"  : self.VVI2wl()
   elif item == "VVg8rC"    : FFZmix(self, self.VVg8rC)
   elif item == "copyEpgPicons"   : self.VVFFXJ(False)
   elif item == "renumIptvRef_fromFile" : self.VVFFXJ(True)
   elif item == "VV6cBO" : FFlOO5(self, BF(FFZmix, self, self.VV6cBO), VVbvpB="Continue ?")
   elif item == "VVPlOd"    : self.VVPlOd()
   elif item == "VVPhfU"   : FFZmix(self, BF(CCFb9t.VVPhfU, self))
   elif item == "dload_stat"    : CC0kPO.VVNz38(self)
 def VV7XcY(self):
  if CCf0Mb.VVMQrW(self):
   FFZmix(self, BF(self.VVmsY9, 1), title="Searching ...")
 def VVqqT1(self):
  global VVmICA
  VVmICA = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVV5qI(item)
 def VV3dPC(self, mode):
  VVbdQX = self.VVWKEL(mode)
  if VVbdQX:
   VVgAHl = ("Current Service", self.VVhTAI , [])
   VVUZua = ("Options"  , self.VVbfdh   , [])
   VVR0s7 = ("Filter"   , self.VVeUWG   , [])
   VVhqvZ  = ("Play"   , BF(self.VVzS98)  , [])
   VVDAgH = (""    , self.VV6O5K    , [])
   VV3Q2h = (""    , self.VV1uQ2     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VV28Ef  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FFMPky(self, None, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26
     , VVhqvZ=VVhqvZ, VVgAHl=VVgAHl, VVUZua=VVUZua, VVR0s7=VVR0s7, VVDAgH=VVDAgH, VV3Q2h=VV3Q2h
     , VVI8Pk="#0a00292B", VV2s6D="#0a002126", VVjLdB="#0a002126", VVaZj9="#00000000", VVMVWT=True, searchCol=1)
  else:
   if mode == self.VVm86O: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFu1fZ(self, err)
 def VV1uQ2(self, VVoyO8, title, txt, colList):
  self.VVoyO8 = VVoyO8
 def VVbfdh(self, VVoyO8, title, txt, colList):
  VVMYdC = []
  VVMYdC.append(("Add Current List to a New Bouquet"    , "VVNqvg"  ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Change Current List References to Unique Codes" , "VV7bkk"))
  VVMYdC.append(("Change Current List References to Identical Codes", "VVBfXi_rows" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Share Reference with DVB Service (manual entry)" , "VVcrol"   ))
  VVMYdC.append(("Share Reference with DVB Service (auto-find)"  , "VVeacT"   ))
  FFcKE0(self, self.VVV5qI, title="IPTV Tools", VVMYdC=VVMYdC)
 def VVeUWG(self, VVoyO8, title, txt, colList):
  VVMYdC = []
  VVMYdC.append(("All"         , "all"   ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Prefix of Selected Channel"   , "sameName" ))
  VVMYdC.append(("Suggest Words from Selected Channel" , "partName" ))
  VVMYdC.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVMYdC.append(("Duplicate References"     , "depRef"  ))
  VVMYdC.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVMYdC.append(FFYdlI("Category"))
  VVMYdC.append(("Live TV"        , "live"  ))
  VVMYdC.append(("VOD"         , "vod"   ))
  VVMYdC.append(("Series"        , "series"  ))
  VVMYdC.append(("Uncategorised"      , "uncat"  ))
  VVMYdC.append(FFYdlI("Media"))
  VVMYdC.append(("Video"        , "video"  ))
  VVMYdC.append(("Audio"        , "audio"  ))
  VVMYdC.append(FFYdlI("File Type"))
  VVMYdC.append(("MKV"         , "MKV"   ))
  VVMYdC.append(("MP4"         , "MP4"   ))
  VVMYdC.append(("MP3"         , "MP3"   ))
  VVMYdC.append(("AVI"         , "AVI"   ))
  VVMYdC.append(("FLV"         , "FLV"   ))
  VVMYdC.extend(CC3Jx1.VVJfY4(prefix="__b__"))
  inFilterFnc = BF(self.VVAGWz, VVoyO8) if VVoyO8.VVA691().startswith("IPTV Filter ") else None
  filterObj = CCfZNJ(self)
  filterObj.VVj0C9(VVMYdC, VVMYdC, BF(self.VVTvW6, VVoyO8, False), inFilterFnc=inFilterFnc)
 def VVAGWz(self, VVoyO8, menuInstance, item):
  self.VVTvW6(VVoyO8, True, item)
 def VVTvW6(self, VVoyO8, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVoyO8.VVnbNr(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVRxCP , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VV44PO , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVrbX2 , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VV8148 , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVQxJH  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VVvvbC  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "live"    : mode, words, title = self.VVm86O  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVyLUQ   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVOAFD  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVuMHG  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVx0Zt  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVU4Rk  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VV9xeO   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVbQuP   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVbsjm   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVYOXb   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVRarc   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVNfv0  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVA3rM  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVrbX2:
   VVMYdC = []
   chName = VVoyO8.VVnbNr(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVMYdC.append((item, item))
    if not VVMYdC and chName:
     VVMYdC.append((chName, chName))
    FFcKE0(self, BF(self.VVWoBd, title), title="Words from Current Selection", VVMYdC=VVMYdC)
   else:
    VVoyO8.VVdbDB("Invalid Channel Name")
  else:
   words, asPrefix = CCfZNJ.VVGe34(words)
   if not words and mode in (self.VVNfv0, self.VVA3rM):
    FFAcfo(self.VVoyO8, "Incorrect filter", 2000)
   else:
    FFZmix(self.VVoyO8, BF(self.VVGmdN, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVWoBd(self, title, word=None):
  if word:
   words = [word.lower()]
   FFZmix(self.VVoyO8, BF(self.VVGmdN, self.VVrbX2, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVipgr(txt):
  return "#f#11ffff00#" + txt
 def VVGmdN(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVbdQX = self.VVrbSH(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVbdQX = self.VVWKEL(mode=mode, words=words, asPrefix=asPrefix)
  if VVbdQX : self.VVoyO8.VVKBif(VVbdQX, title)
  else  : self.VVoyO8.VVdbDB("Not found")
 def VVrbSH(self, mode=0, words=None, asPrefix=False):
  VVbdQX = []
  for row in self.VVoyO8.VVVGfF():
   row = list(map(str.strip, row))
   chNum, chName, VV2B8y, chType, refCode, url = row
   if self.VVtGRj(mode, refCode, FFxspG(url).lower(), chName, words, VV2B8y.lower(), asPrefix):
    VVbdQX.append(row)
  VVbdQX = self.VVpYRI(mode, VVbdQX)
  return VVbdQX
 def VVWKEL(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVbdQX = []
  files  = self.VVLnYI()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFQgne(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VV2B8y = span.group(1)
    else : VV2B8y = ""
    VV2B8y_lCase = VV2B8y.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVtpMb(chName): chNameMod = self.VVipgr(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VV2B8y, chType, refCode, url)
     if self.VVtGRj(mode, refCode, FFxspG(url).lower(), chName, words, VV2B8y_lCase, asPrefix):
      VVbdQX.append(row)
      chNum += 1
  VVbdQX = self.VVpYRI(mode, VVbdQX)
  return VVbdQX
 def VVpYRI(self, mode, VVbdQX):
  newRows = []
  if VVbdQX and mode == self.VVQxJH:
   from collections import Counter
   counted  = Counter(elem[4] for elem in VVbdQX)
   for item in VVbdQX:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVbdQX
 def VVtGRj(self, mode, refCode, tUrl, chName, words, VV2B8y_lCase, asPrefix):
  if   mode == self.VVRxCP : return True
  elif mode == self.VVQxJH : return True
  elif mode == self.VVvvbC  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VVx0Zt  : return CC0A1M.VVpVfO(tUrl, getAudVid=True) == "vid"
  elif mode == self.VVU4Rk  : return CC0A1M.VVpVfO(tUrl, getAudVid=True) == "aud"
  elif mode == self.VVm86O  : return CC0A1M.VVpVfO(tUrl, compareType="live")
  elif mode == self.VVyLUQ  : return CC0A1M.VVpVfO(tUrl, compareType="movie")
  elif mode == self.VVOAFD : return CC0A1M.VVpVfO(tUrl, compareType="series")
  elif mode == self.VVuMHG  : return CC0A1M.VVpVfO(tUrl, compareType="")
  elif mode == self.VV9xeO  : return CC0A1M.VVpVfO(tUrl, compareExt="mkv")
  elif mode == self.VVbQuP  : return CC0A1M.VVpVfO(tUrl, compareExt="mp4")
  elif mode == self.VVbsjm  : return CC0A1M.VVpVfO(tUrl, compareExt="mp3")
  elif mode == self.VVYOXb  : return CC0A1M.VVpVfO(tUrl, compareExt="avi")
  elif mode == self.VVRarc  : return CC0A1M.VVpVfO(tUrl, compareExt="flv")
  elif mode == self.VV44PO: return chName.lower().startswith(words[0])
  elif mode == self.VVrbX2: return words[0] in chName.lower()
  elif mode == self.VV8148: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVNfv0 : return words[0] == VV2B8y_lCase
  elif mode == self.VVA3rM :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVNqvg(self):
  picker = CC3Jx1(self, self.VVoyO8, "Add to Bouquet", self.VV3zIo)
 def VV3zIo(self):
  chUrlLst = []
  for row in self.VVoyO8.VVVGfF():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VVPlOd(self):
  c1 = VV80mJ
  t1 = FFXe6i("Bouquet", VVwhxm)
  t2 = FFXe6i("ALL", VVwhxm)
  refTxt = "(1/4097/5001/5002/8192/8193)"
  VVMYdC = []
  VVMYdC.append((c1 + "Check System Acceptable Reference Types" , "VVb3Ab"    ))
  if self.iptvFileAvailable:
   VVMYdC.append((c1 + "Check Reference Codes Format"  , "VVP9om"    ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(('Change %s Ref. Types to %s ..' % (t1, refTxt) , "VVRc3p" ))
  VVMYdC.append(('Change %s Ref. Types to %s ..' % (t2, refTxt) , "VVtZZe_all"  ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Change %s References to Unique Codes" % t2 , "VVt3Bt"  ))
  VVMYdC.append(("Change %s References to Identical Codes" % t2 , "VVBfXi_all"  ))
  OKBtnFnc = self.VVafgp
  FFcKE0(self, None, width=1200, title="Reference Tools", VVMYdC=VVMYdC, OKBtnFnc=OKBtnFnc)
 def VVafgp(self, item=None):
  if item:
   ques = "Continue ?"
   menuInstance, txt, item, ndx = item
   if   item == "VVb3Ab"    : FFZmix(menuInstance, self.VVb3Ab)
   elif item == "VVP9om"     : FFZmix(menuInstance, self.VVP9om)
   elif item == "VVRc3p" : self.VVRc3p(menuInstance)
   elif item == "VVtZZe_all"  : self.VVemte(menuInstance, None, None)
   elif item == "VVt3Bt"  : FFlOO5(self, BF(self.VVt3Bt , menuInstance, txt), title=txt, VVbvpB=ques)
   elif item == "VVBfXi_all"  : FFlOO5(self, BF(FFZmix, menuInstance, self.VVBfXi), title=txt, VVbvpB=ques)
 def VVemte(self, menuInstance, bName, bPath):
  txt = "Stream Type "
  VVMYdC = []
  VVMYdC.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVMYdC.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVMYdC.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVMYdC.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVMYdC.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVMYdC.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFcKE0(self, BF(self.VVklun, menuInstance, bName, bPath), width=750, title="Change Reference Types to:", VVMYdC=VVMYdC)
 def VVklun(self, menuInstance, bName, bPath, item=None):
  if item:
   if   item == "RT_1"  : self.VVU2do(menuInstance, bName, bPath, "1"   )
   elif item == "RT_4097" : self.VVU2do(menuInstance, bName, bPath, "4097")
   elif item == "RT_5001" : self.VVU2do(menuInstance, bName, bPath, "5001")
   elif item == "RT_5002" : self.VVU2do(menuInstance, bName, bPath, "5002")
   elif item == "RT_8192" : self.VVU2do(menuInstance, bName, bPath, "8192")
   elif item == "RT_8193" : self.VVU2do(menuInstance, bName, bPath, "8193")
 def VVRc3p(self, menuInstance):
  VVMYdC = CC3Jx1.VVJfY4()
  if VVMYdC:
   FFcKE0(self, BF(self.VVHP8Y, menuInstance), VVMYdC=VVMYdC, title="IPTV Bouquets", VVglYk=True)
  else:
   FFAcfo(menuInstance, "No bouquets Found !", 1500)
 def VVHP8Y(self, menuInstance, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVPZMJ + span.group(1)
    if fileExists(bPath): self.VVemte(menuInstance, bName, bPath)
    else    : FFAcfo(menuInstance, "Bouquet file not found!", 2000)
   else:
    FFAcfo(menuInstance, "Cannot process bouquet !", 2000)
 def VVU2do(self, menuInstance, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FFXe6i(bName, VVrhVl)
  else : title = "Change for %s" % FFXe6i("All IPTV Services", VVrhVl)
  FFlOO5(self, BF(FFZmix, menuInstance, BF(self.VVIIxn, menuInstance, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FFXe6i(rType, VVrhVl), title=title)
 def VVIIxn(self, menuInstance, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = self.VVLnYI()
  if files:
   newRType = rType + ":"
   piconPath = CC2wnB.VV6OCP()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CC5DZc.VVb7pn(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FFu1fZ(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           os.system(FFVKmy("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png")))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    os.system(FFVKmy(cmd))
  self.VVXDCe(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VVg8rC(self):
  totFiles = 0
  files  = self.VVLnYI()
  if files:
   totFiles = len(files)
  totChans = 0
  VVbdQX = self.VVWKEL()
  if VVbdQX:
   totChans = len(VVbdQX)
  FF4gok(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVP9om(self):
  files  = self.VVLnYI()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFQgne(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVhAfh
   else    : color = VVwtwf
   totInvalid = FFXe6i(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFXe6i("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FF4gok(self, txt, title="Check IPTV References")
 def VVb3Ab(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  chUrlLst  = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CC3Jx1.VVRn29(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVcesp = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVcesp:
   VVlw3z = FFsJR6(VVcesp)
   if VVlw3z:
    for service in VVlw3z:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVPZMJ + userBName
  bFile = VVPZMJ + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFVKmy("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFVKmy("rm -f '%s'" % path)
  os.system(cmd)
  FFSSJm()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVhAfh
    else     : res, color = "No" , VVwtwf
    txt += "    %s\t: %s\n" % (item, FFXe6i(res, color))
   FF4gok(self, txt, title=title)
  else:
   txt = FFu1fZ(self, "Could not complete the test on your system!", title=title)
 def VV6cBO(self):
  VV5OsR, err = CCFb9t.VVmPx6(self, CCFb9t.VVmwIK)
  if VV5OsR:
   totChannels = 0
   totChange = 0
   for path in self.VVLnYI():
    toSave = False
    txt = FFQgne(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VV5OsR.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVXDCe(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFu1fZ(self, 'No channels in "lamedb" !')
 def VVt3Bt(self, menuInstance, title):
  bFiles = self.VVLnYI()
  if bFiles:
   self.session.open(CC54zA, barTheme=CC54zA.VVIWtA
       , titlePrefix = "Renumbering References"
       , fncToRun  = BF(self.VVMZdA, bFiles)
       , VV2r3B = BF(self.VV1bpL, title))
  else:
   FFAcfo(menuInstance, "No bouquets files !", 1500)
 def VVMZdA(self, bFiles, VVeDSa):
  VVeDSa.VVinQh = ""
  VVeDSa.VVyj21("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FFgYB4(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVeDSa or VVeDSa.isCancelled:
   return
  elif not totLines:
   VVeDSa.VVinQh = "No IPTV Services !"
   return
  else:
   VVeDSa.VVvPX7(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVeDSa or VVeDSa.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FFgYB4(path)
    for ndx, line in enumerate(lines):
     if not VVeDSa or VVeDSa.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVeDSa:
       VVeDSa.VVyj21("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVeDSa:
       VVeDSa.VVs1tz(1)
      refCode, startId, startNS = CC3Jx1.VVN7nC(rType, CC3Jx1.VVSxuC, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVeDSa:
        VVeDSa.VVinQh = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VV1bpL(self, title, VVw6fk, VVinQh, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVinQh:
   txt += "\n\n%s\n%s" % (FFXe6i("Ended with Error:", VVwtwf), VVinQh)
  self.VVXDCe(True, title, txt)
 def VV7bkk(self):
  bFiles = self.VVLnYI()
  if not bFiles:
   FFAcfo(self.VVoyO8, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVoyO8.VVVGfF():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FFAcfo(self.VVoyO8, "Cannot read list", 1500)
   return
  self.session.open(CC54zA, barTheme=CC54zA.VVIWtA
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVjwEF, bFiles, tableRefList)
      , VV2r3B = BF(self.VV1bpL, "Change Current List References to Unique Codes"))
 def VVjwEF(self, bFiles, tableRefList, VVeDSa):
  VVeDSa.VVinQh = ""
  VVeDSa.VVyj21("Reading System References ...")
  refLst = CC3Jx1.VVwBgp(CC3Jx1.VVSxuC, stripRType=True)
  if not VVeDSa or VVeDSa.isCancelled:
   return
  VVeDSa.VVvPX7(len(tableRefList))
  rType  = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVeDSa or VVeDSa.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFQgne(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVeDSa or VVeDSa.isCancelled:
     return
    VVeDSa.VVyj21("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVeDSa or VVeDSa.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVeDSa.VVs1tz(1)
      refCode, startId, startNS = CC3Jx1.VVN7nC(rType, CC3Jx1.VVSxuC, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVeDSa:
        VVeDSa.VVinQh = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VVBfXi(self):
  list = None
  if self.VVoyO8:
   list = []
   for row in self.VVoyO8.VVVGfF():
    list.append(row[4] + row[5])
  files  = self.VVLnYI()
  totChange = 0
  if files:
   for path in files:
    lines = FFgYB4(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VVXDCe(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVXDCe(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFSSJm()
   if refreshTable and self.VVoyO8:
    VVbdQX = self.VVWKEL()
    if VVbdQX and self.VVoyO8:
     self.VVoyO8.VVKBif(VVbdQX, self.tableTitle)
     self.VVoyO8.VVdbDB(txt)
   FF4gok(self, txt, title=title)
  else:
   FF5VuW(self, "No changes.")
 def VVLnYI(self):
  return CC0A1M.VVGgNf()
 @staticmethod
 def VVGgNf(atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVPZMJ + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFQgne(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VV6O5K(self, VVoyO8, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFxspG(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFfM6H(self, fncMode=CChafy.VVRMLS, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VV58Hj(self, VVoyO8, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVzS98(self, VVoyO8, title, txt, colList):
  chName, chUrl = self.VV58Hj(VVoyO8, colList)
  self.VVxgsK(VVoyO8, chName, chUrl, "localIptv")
 def VVxi1m(self, mode, VVoyO8, colList):
  chName, chUrl, picUrl, refCode = self.VVeECa(mode, colList)
  return chName, chUrl
 def VVk48W(self, mode, VVoyO8, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVeECa(mode, colList)
  self.VVxgsK(VVoyO8, chName, chUrl, mode)
 def VVxgsK(self, VVoyO8, chName, chUrl, playerFlag):
  chName = FF3RM7(chName)
  if self.VVtpMb(chName):
   FFAcfo(VVoyO8, "This is a marker!", 300)
  else:
   FFZmix(VVoyO8, BF(self.VVqSsQ, VVoyO8, chUrl, playerFlag), title="Playing ...")
 def VVqSsQ(self, VVoyO8, chUrl, playerFlag):
  FFI9Ee(self, chUrl, VVtcz9=False)
  CCDmyf.VVtxwR(self.session, iptvTableParams=(self, VVoyO8, playerFlag))
 @staticmethod
 def VVtpMb(chName):
  mark = ("--", "__", "==", "##",  "**", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVhTAI(self, VVoyO8, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self)
  if refCode:
   url1 = FFxspG(origUrl.strip())
   for ndx, row in enumerate(VVoyO8.VVVGfF()):
    if refCode in row[4]:
     tableRow = FFxspG(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVoyO8.VVjS0j(ndx)
      break
   else:
    FFAcfo(VVoyO8, "No found", 1000)
 def VVmsY9(self, m3uMode):
  lines = self.VVn2I0(3)
  if lines:
   lines.sort()
   VVMYdC = []
   for line in lines:
    VVMYdC.append((line, line))
   if m3uMode == self.VVdLpu:
    title = "Browse Server from M3U URLs"
    VVtkPa = ("All to Playlist", self.VVkUbD)
   else:
    title = "M3U/M3U8 File Browser"
    VVtkPa = None
   OKBtnFnc = BF(self.VVgeX2, m3uMode, title)
   VVAfNY  = ("Show Full Path", self.VVQfmY)
   VVyvO2 = ("Delete File", self.VV1uMh)
   FFcKE0(self, None, title=title, VVMYdC=VVMYdC, width=1200, OKBtnFnc=OKBtnFnc, VVAfNY=VVAfNY, VVyvO2=VVyvO2, VVtkPa=VVtkPa, VVI8Pk="#11221122", VV2s6D="#11221122")
 def VVgeX2(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == self.VVdLpu:
    FFZmix(menuInstance, BF(self.VVzke6, title, path))
   else:
    self.VVgy0Q(menuInstance, path)
 def VVgy0Q(self, menuInstance, path=None):
  if path:
   VVMYdC = []
   VVMYdC.append(("All"         , "all"   ))
   VVMYdC.append(FFYdlI("Category"))
   VVMYdC.append(("Live TV"        , "live"  ))
   VVMYdC.append(("VOD"         , "vod"   ))
   VVMYdC.append(("Series"        , "series"  ))
   VVMYdC.append(("Uncategorised"      , "uncat"  ))
   VVMYdC.append(FFYdlI("Media"))
   VVMYdC.append(("Video"        , "video"  ))
   VVMYdC.append(("Audio"        , "audio"  ))
   VVMYdC.append(FFYdlI("File Type"))
   VVMYdC.append(("MKV"         , "MKV"   ))
   VVMYdC.append(("MP4"         , "MP4"   ))
   VVMYdC.append(("MP3"         , "MP3"   ))
   VVMYdC.append(("AVI"         , "AVI"   ))
   VVMYdC.append(("FLV"         , "FLV"   ))
   filterObj = CCfZNJ(self, VVI8Pk="#11552233", VV2s6D="#11552233")
   filterObj.VVj0C9(VVMYdC, [], BF(self.VV9iZU, menuInstance, path), inFilterFnc=None)
 def VV9iZU(self, menuInstance, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VVRxCP , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VVm86O  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VVyLUQ  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VVOAFD  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VVuMHG  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VVx0Zt  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VVU4Rk  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VV9xeO  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VVbQuP  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VVbsjm  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVYOXb  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VVRarc  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVA3rM  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CCfZNJ.VVGe34(words)
   if not mode == self.VVRxCP:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FFXe6i(fTitle, VVycQx)
   m3uFiletrParam = (mode, words, asPrefix, fTitle)
   FFZmix(menuInstance, BF(self.VVan2u, path, m3uFiletrParam))
 def VVan2u(self, srcPath, m3uFiletrParam):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFQgne(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  VVAP1F = CCfLea()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VVGEOF(propLine, "group-title") or "-"
   if not group == "-" and VVAP1F.VVMLC0(group):
    groups.add(group)
  VVbdQX = []
  if len(groups) > 0:
   title = "Groups" + m3uFiletrParam[3] if m3uFiletrParam else ""
   for group in groups:
    VVbdQX.append((group, group))
   VVbdQX.append(("ALL", ""))
   VVbdQX.sort(key=lambda x: x[0].lower())
   VVxRQ7 = self.VV0JmH
   VVhqvZ  = ("Select" , BF(self.VV3Fgb, srcPath, m3uFiletrParam), [])
   widths   = (100  , 0)
   VV28Ef  = (LEFT  , LEFT)
   FFMPky(self, None, title=title, width= 1000, header=None, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=30, VVhqvZ=VVhqvZ, VVxRQ7=VVxRQ7, lastFindConfigObj=CFG.lastFindIptv
     , VVI8Pk="#11110022", VV2s6D="#11110022", VVjLdB="#11110022", VVaZj9="#00444400")
  else:
   txt = FFQgne(srcPath)
   self.VVYlbn(txt, "", m3uFiletrParam)
 def VV3Fgb(self, srcPath, m3uFiletrParam, VVoyO8, title, txt, colList):
  group = colList[1]
  txt = FFQgne(srcPath)
  self.VVYlbn(txt, group, m3uFiletrParam)
 def VVYlbn(self, txt, filterGroup="", m3uFiletrParam=None):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFiletrParam[3] if m3uFiletrParam else ""
  if lst:
   self.session.open(CC54zA, barTheme=CC54zA.VVlVsr
       , titlePrefix = "Reading File Lines"
       , fncToRun  = BF(self.VV61yd, lst, filterGroup, m3uFiletrParam)
       , VV2r3B = BF(self.VVJuUM, title, bName))
  else:
   self.VVuMqt("Not valid lines found !", title)
 def VV61yd(self, lst, filterGroup, m3uFiletrParam, VVeDSa):
  VVeDSa.VVinQh = []
  VVeDSa.VVvPX7(len(lst))
  VVAP1F = CCfLea()
  num = 0
  for cols in lst:
   if not VVeDSa or VVeDSa.isCancelled:
    return
   VVeDSa.VVs1tz(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VVGEOF(propLine, "tvg-logo")
   group = self.VVGEOF(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not VVAP1F.VVMLC0(group) : skip = True
    elif chName and not VVAP1F.VVMLC0(chName) : skip = True
    elif m3uFiletrParam:
     mode, words, asPrefix, fTitle = m3uFiletrParam
     skip = not self.VVtGRj(mode, "", FFxspG(url).lower(), chName, words, "", asPrefix)
    if not skip and VVeDSa:
     num += 1
     VVeDSa.VVinQh.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if VVeDSa:
   VVeDSa.VVjNDz("Loading %d Channels" % len(VVeDSa.VVinQh))
 def VVJuUM(self, title, bName, VVw6fk, VVinQh, threadCounter, threadTotal, threadErr):
  if VVinQh:
   VVxRQ7 = self.VV0JmH
   VVhqvZ  = ("Select"   , BF(self.VVVxFJ, title)   , [])
   VVDAgH = (""    , self.VV0ZpU        , [])
   VVgAHl = ("Download PIcons", self.VVjK2W       , [])
   VVUZua = ("Options"  , BF(self.VVl9qk, "m3Ch", "", bName) , [])
   VVR0s7 = ("Posters Mode" , BF(self.VVqdwx, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VV28Ef  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFMPky(self, None, title=title, header=header, VVL1iO=VVinQh, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=28, VVhqvZ=VVhqvZ, VVxRQ7=VVxRQ7, VVDAgH=VVDAgH, VVgAHl=VVgAHl, VVUZua=VVUZua, VVR0s7=VVR0s7, lastFindConfigObj=CFG.lastFindIptv, VVMVWT=True, searchCol=1
     , VVI8Pk="#0a00192B", VV2s6D="#0a00192B", VVjLdB="#0a00192B", VVaZj9="#00000000")
  else:
   self.VVuMqt("Not found !", title)
 def VVjK2W(self, VVoyO8, title, txt, colList):
  self.VVmzQy(VVoyO8, "m3u/m3u8")
 def VVSEC8(self, rowNum, url, chName):
  refCode = self.VVbD2S(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFfLv9(url), chName)
  return chUrl
 def VVbD2S(self, rowNum, url, chName):
  span = iSearch(r"\/(\d{2,})", url, IGNORECASE)
  if span : stID = span.group(1)
  else : stID = "444"
  catID = "333"
  chNum = str(rowNum + 1)
  refCode = self.VV1u2M(catID, stID, chNum)
  return refCode
 def VVGEOF(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVVxFJ(self, Title, VVoyO8, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFZmix(VVoyO8, BF(self.VVOqLJ, Title, VVoyO8, colList), title="Checking Server ...")
  else:
   self.VVFCJA(VVoyO8, url, chName)
 def VVOqLJ(self, title, VVoyO8, colList):
  if not CCf0Mb.VVMQrW(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCMCGp.VVsdyN(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVMYdC = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CC0A1M.VVDRnn(url, fPath)
     VVMYdC.append((resol, fullUrl))
    if VVMYdC:
     if len(VVMYdC) > 1:
      FFcKE0(self, BF(self.VV9iqy, VVoyO8, chName), VVMYdC=VVMYdC, title="Resolution", VVglYk=True, VVKpZE=True)
     else:
      self.VVFCJA(VVoyO8, VVMYdC[0][1], chName)
    else:
     self.VVGEG2("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVYlbn(txt, filterGroup="")
      return
    self.VVFCJA(VVoyO8, url, chName)
   else:
    self.VVuMqt("Cannot process this channel !", title)
  else:
   self.VVuMqt(err, title)
 def VV9iqy(self, VVoyO8, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVFCJA(VVoyO8, resolUrl, chName)
 def VVFCJA(self, VVoyO8, url, chName):
  FFZmix(VVoyO8, BF(self.VVtnvO, VVoyO8, url, chName), title="Playing ...")
 def VVtnvO(self, VVoyO8, url, chName):
  chUrl = self.VVSEC8(VVoyO8.VVr4DQ(), url, chName)
  FFI9Ee(self, chUrl, VVtcz9=False)
  CCDmyf.VVtxwR(self.session, iptvTableParams=(self, VVoyO8, "m3u/m3u8"))
 def VVOfCC(self, VVoyO8, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVSEC8(VVoyO8.VVr4DQ(), url, chName)
  return chName, chUrl
 def VV0ZpU(self, VVoyO8, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFfM6H(self, fncMode=CChafy.VVRMLS, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVuMqt(self, err, title):
  FFu1fZ(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VV0JmH(self, VVoyO8):
  if self.m3uOrM3u8File:
   self.close()
  VVoyO8.cancel()
 def VVkUbD(self, VVVCbtObj, item=None):
  FFZmix(VVVCbtObj, BF(self.VVdI7G, VVVCbtObj, item))
 def VVdI7G(self, VVVCbtObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVVCbtObj.VVMYdC):
    path = item[1]
    if fileExists(path):
     enc = CCSqSs.VVcaEq(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VVQX84(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CC0A1M.VVHTQS()
    pListF = "%sPlaylist_%s.txt" % (path, FFcOP9())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVVCbtObj.VVMYdC)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FF4gok(self, txt, title=title)
   else:
    FFu1fZ(self, "Could not obtain URLs from this file list !", title=title)
 def VV8c1V(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VV6Zn0
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VVX3L9
  lines = self.VVn2I0(mode)
  if lines:
   lines.sort()
   VVMYdC = []
   for line in lines:
    VVMYdC.append((FFXe6i(line, VVJ6nn) if "Bookmarks" in line else line, line))
   VVyvO2 = ("Delete File", self.VV1uMh)
   VVAfNY  = ("Show Full Path", self.VVQfmY)
   FFcKE0(self, None, title=title, VVMYdC=VVMYdC, width=1200, OKBtnFnc=okFnc, VVAfNY =VVAfNY , VVyvO2=VVyvO2)
 def VVQfmY(self, menuInstance, url):
  FF4gok(self, url, title="Full Path")
 def VV1uMh(self, VVVCbtObj, path):
  FFlOO5(self, BF(self.VVMdg7, VVVCbtObj, path), "Delete this file ?\n\n%s" % path)
 def VVMdg7(self, VVVCbtObj, path):
  FF2PD3(path)
  if fileExists(path) : FFAcfo(VVVCbtObj, "Not deleted", 1000)
  else    : VVVCbtObj.VVLcYB()
 def VV6Zn0(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFZmix(menuInstance, BF(self.VVAsjV, menuInstance, path), title="Processing File ...")
 def VVAsjV(self, VVLTHJ, path):
  enc = CCSqSs.VVcaEq(path, self)
  if enc == -1:
   return
  VVbdQX = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FF5sxC(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC0A1M.VVNvtX(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVbdQX:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVbdQX.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVbdQX:
   title = "Playlist File : %s" % os.path.basename(path)
   VVhqvZ  = ("Start"    , BF(self.VVYLC8, "Playlist File")      , [])
   VV1mml = ("Home Menu"   , FFsT0V             , [])
   VVgAHl = ("Download M3U File" , self.VV7trw         , [])
   VVUZua = ("Edit File"   , BF(self.VVptml, path)        , [])
   VVR0s7 = ("Check & Filter"  , BF(self.VV8ExX, VVLTHJ, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VV28Ef  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFMPky(self, None, title=title, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VVhqvZ=VVhqvZ, VV1mml=VV1mml, VVR0s7=VVR0s7, VVgAHl=VVgAHl, VVUZua=VVUZua, VVI8Pk="#11001116", VV2s6D="#11001116", VVjLdB="#11001116", VVaZj9="#00003635", VVBGyD="#0a333333", VVFIzs="#11331100", VVMVWT=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FFu1fZ(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VV7trw(self, VVoyO8, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFlOO5(self, BF(FFZmix, VVoyO8, BF(self.VVAD1A, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVAD1A(self, title, url):
  path, err = FFmy2V(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFu1fZ(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFQgne(path)
   if '{"user_info":{"auth":0}}' in txt:
    FF2PD3(path)
    FFu1fZ(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FF2PD3(path)
    FFu1fZ(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CC0A1M.VVHTQS() + fName
    os.system(FFVKmy("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FF5VuW(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFu1fZ(self, "Could not download the M3U file!", title=errTitle)
 def VVYLC8(self, Title, VVoyO8, title, txt, colList):
  url = colList[6]
  FFZmix(VVoyO8, BF(self.VVgWgu, Title, url), title="Checking Server ...")
 def VVptml(self, path, VVoyO8, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCV79S(self, path, VV2r3B=BF(self.VVYK7D, VVoyO8), curRowNum=rowNum)
  else    : FF6iwf(self, path)
 def VVYK7D(self, VVoyO8, fileChanged):
  if fileChanged:
   VVoyO8.cancel()
 def VVcrol(self, title):
  curChName = self.VVoyO8.VVnbNr(1)
  FFSAou(self, BF(self.VVXAjb, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVXAjb(self, title, name):
  if name:
   VV5OsR, err = CCFb9t.VVmPx6(self, CCFb9t.VVxOvm, VVit1y=False, VVldMD=False)
   list = []
   if VV5OsR:
    VVAP1F = CCfLea()
    name = VVAP1F.VVYsaO(name)
    ratio = "1"
    for item in VV5OsR:
     if name in item[0].lower():
      list.append((item[0], FFtFKL(item[2]), item[3], ratio))
   if list : self.VV3h5O(list, title)
   else : FFu1fZ(self, "Not found:\n\n%s" % name, title=title)
 def VVeacT(self, title):
  curChName = self.VVoyO8.VVnbNr(1)
  self.session.open(CC54zA, barTheme=CC54zA.VVlVsr
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVsYQr
      , VV2r3B = BF(self.VVYIDE, title, curChName))
 def VVsYQr(self, VVeDSa):
  curChName = self.VVoyO8.VVnbNr(1)
  VV5OsR, err = CCFb9t.VVmPx6(self, CCFb9t.VVbejM, VVit1y=False, VVldMD=False)
  if not VV5OsR or not VVeDSa or VVeDSa.isCancelled:
   return
  VVeDSa.VVinQh = []
  VVeDSa.VVvPX7(len(VV5OsR))
  VVAP1F = CCfLea()
  curCh = VVAP1F.VVYsaO(curChName)
  for refCode in VV5OsR:
   chName, sat, inDB = VV5OsR.get(refCode, ("", "", 0))
   ratio = CC2wnB.VVHfrz(chName.lower(), curCh)
   if not VVeDSa or VVeDSa.isCancelled:
    return
   VVeDSa.VVs1tz(1, True)
   if VVeDSa and ratio > 50:
    VVeDSa.VVinQh.append((chName, FFtFKL(sat), refCode.replace("_", ":"), str(ratio)))
 def VVYIDE(self, title, curChName, VVw6fk, VVinQh, threadCounter, threadTotal, threadErr):
  if VVinQh: self.VV3h5O(VVinQh, title)
  elif VVw6fk: FFu1fZ(self, "No similar names found for:\n\n%s" % curChName, title)
 def VV3h5O(self, VVbdQX, title):
  curChName = self.VVoyO8.VVnbNr(1)
  VVi7uK = self.VVoyO8.VVnbNr(4)
  curUrl  = self.VVoyO8.VVnbNr(5)
  VVbdQX.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVhqvZ  = ("Share Sat/C/T Ref.", BF(self.VV3NMb, title, curChName, VVi7uK, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFMPky(self, None, title=title, header=header, VVL1iO=VVbdQX, VVLkOa=widths, VVJfxh=26, VVhqvZ=VVhqvZ, VVI8Pk="#0a00112B", VV2s6D="#0a001126", VVjLdB="#0a001126", VVaZj9="#00000000")
 def VV3NMb(self, newtitle, curChName, VVi7uK, curUrl, VVoyO8, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVi7uK, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFlOO5(self.VVoyO8, BF(FFZmix, self.VVoyO8, BF(self.VVgpom, VVoyO8, data)), ques, title=newtitle, VV6ttc=True)
 def VVgpom(self, VVoyO8, data):
  VVoyO8.cancel()
  title, curChName, VVi7uK, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVi7uK = VVi7uK.strip()
  newRefCode = newRefCode.strip()
  if not VVi7uK.endswith(":") : VVi7uK += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVi7uK, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVi7uK + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVLnYI():
    txt = FFQgne(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFSSJm()
    newRow = []
    for i in range(6):
     newRow.append(self.VVoyO8.VVnbNr(i))
    newRow[4] = newRefCode
    done = self.VVoyO8.VVlQTg(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFC8Ey(BF(FF5VuW , self, resTxt, title=title))
  elif resErr: FFC8Ey(BF(FFu1fZ, self, resErr, title=title))
 def VV8ExX(self, VVLTHJ, path, VVoyO8, title, txt, colList):
  self.session.open(CC54zA, barTheme=CC54zA.VVIWtA
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVqbPA, VVoyO8)
      , VV2r3B = BF(self.VV8xwx, VVLTHJ, path, VVoyO8))
 def VVqbPA(self, VVoyO8, VVeDSa):
  VVeDSa.VVvPX7(VVoyO8.VVSgrB())
  VVeDSa.VVinQh = []
  for row in VVoyO8.VVVGfF():
   if not VVeDSa or VVeDSa.isCancelled:
    return
   VVeDSa.VVs1tz(1, True)
   qUrl = self.VVcIXS(self.VVAWu6, row[6])
   txt, err = self.VVKC2S(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVcM1V(item, "auth") == "0":
       VVeDSa.VVinQh.append(qUrl)
    except:
     pass
 def VV8xwx(self, VVLTHJ, path, VVoyO8, VVw6fk, VVinQh, threadCounter, threadTotal, threadErr):
  if VVw6fk:
   list = VVinQh
   title = "Authorized Servers"
   if list:
    totChk = VVoyO8.VVSgrB()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFcOP9()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VV8c1V(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFXe6i(str(totAuth), VVhAfh)
     txt += "%s\n\n%s"    %  (FFXe6i("Result File:", VVJ6nn), newPath)
     FF4gok(self, txt, title=title)
     VVoyO8.close()
     VVLTHJ.close()
    else:
     FF5VuW(self, "All URLs are authorized.", title=title)
   else:
    FFu1fZ(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVKC2S(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVNvtX(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVpVfO(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CCgKzL.VVIw9Z()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVZVmc(decodedUrl):
  return CC0A1M.VVpVfO(decodedUrl, justRetDotExt=True)
 def VVcIXS(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVNvtX(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVAWu6   : return "%s"            % url
  elif mode == self.VV5OCW   : return "%s&action=get_live_categories"     % url
  elif mode == self.VV4DQN   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVHjam  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVBnzb  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVmzst : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVNqui   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVR9Np    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVbbs0  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VV2MWB : return "%s&action=get_live_streams"      % url
  elif mode == self.VVgnjV  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVcM1V(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FF2ogC(int(val))
    elif is_base64 : val = FFl7mx(val)
    elif isToHHMMSS : val = FFZcBU(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVzke6(self, title, path):
  if fileExists(path):
   enc = CCSqSs.VVcaEq(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VVQX84(line)
     if qUrl:
      break
   if qUrl : self.VVgWgu(title, qUrl)
   else : FFu1fZ(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFu1fZ(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVYF5C(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVgqF5()
  if qUrl or "chCode" in iptvRef:
   p = CCMCGp()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVpwES(iptvRef)
   if valid:
    self.VVsrUr(self, host, mac)
    return
   elif qUrl:
    FFZmix(self, BF(self.VVgWgu, title, qUrl), title="Checking Server ...")
    return
  FFu1fZ(self, "Error in current channel URL !", title=title)
 def VVgqF5(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self)
  qUrl = self.VVQX84(decodedUrl)
  return qUrl, iptvRef
 def VVQX84(self, url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVgWgu(self, title, url):
  self.VVrKIdData = {}
  qUrl = self.VVcIXS(self.VVAWu6, url)
  txt, err = self.VVKC2S(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVrKIdData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVrKIdData["username"    ] = self.VVcM1V(item, "username"        )
    self.VVrKIdData["password"    ] = self.VVcM1V(item, "password"        )
    self.VVrKIdData["message"    ] = self.VVcM1V(item, "message"        )
    self.VVrKIdData["auth"     ] = self.VVcM1V(item, "auth"         )
    self.VVrKIdData["status"    ] = self.VVcM1V(item, "status"        )
    self.VVrKIdData["exp_date"    ] = self.VVcM1V(item, "exp_date"    , isDate=True )
    self.VVrKIdData["is_trial"    ] = self.VVcM1V(item, "is_trial"        )
    self.VVrKIdData["active_cons"   ] = self.VVcM1V(item, "active_cons"       )
    self.VVrKIdData["created_at"   ] = self.VVcM1V(item, "created_at"   , isDate=True )
    self.VVrKIdData["max_connections"  ] = self.VVcM1V(item, "max_connections"      )
    self.VVrKIdData["allowed_output_formats"] = self.VVcM1V(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVrKIdData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVrKIdData["url"    ] = self.VVcM1V(item, "url"        )
    self.VVrKIdData["port"    ] = self.VVcM1V(item, "port"        )
    self.VVrKIdData["https_port"  ] = self.VVcM1V(item, "https_port"      )
    self.VVrKIdData["server_protocol" ] = self.VVcM1V(item, "server_protocol"     )
    self.VVrKIdData["rtmp_port"   ] = self.VVcM1V(item, "rtmp_port"       )
    self.VVrKIdData["timezone"   ] = self.VVcM1V(item, "timezone"       )
    self.VVrKIdData["timestamp_now"  ] = self.VVcM1V(item, "timestamp_now"  , isDate=True )
    self.VVrKIdData["time_now"   ] = self.VVcM1V(item, "time_now"       )
    VVMYdC  = self.VVit8t(True)
    OKBtnFnc = self.VVifkF
    VVM2qe = ("Home Menu", FFsT0V)
    VVyvO2= ("Add to Menu", BF(CC0A1M.VVkcgJ, self, False, self.VVrKIdData["playListURL"]))
    VVtkPa = ("Bookmark Server", BF(CC0A1M.VVV8dQ, self, False, self.VVrKIdData["playListURL"]))
    FFcKE0(self, None, title="IPTV Server Resources", VVMYdC=VVMYdC, OKBtnFnc=OKBtnFnc, VVM2qe=VVM2qe, VVyvO2=VVyvO2, VVtkPa=VVtkPa)
   else:
    err = "Could not get data from server !"
  if err:
   FFu1fZ(self, err, title=title)
  FFAcfo(self)
 def VVifkF(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFZmix(menuInstance, BF(self.VVipAs, self.VV5OCW  , title=title), title=wTxt)
   elif ref == "vod"   : FFZmix(menuInstance, BF(self.VVipAs, self.VV4DQN  , title=title), title=wTxt)
   elif ref == "series"  : FFZmix(menuInstance, BF(self.VVipAs, self.VVHjam , title=title), title=wTxt)
   elif ref == "catchup"  : FFZmix(menuInstance, BF(self.VVipAs, self.VVBnzb , title=title), title=wTxt)
   elif ref == "accountInfo" : FFZmix(menuInstance, BF(self.VVayfF           , title=title), title=wTxt)
 def VVayfF(self, title):
  rows = []
  for key, val in self.VVrKIdData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VVPdIS
   else:
    num, part = "1", self.VVUNYk
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VV1mml  = ("Home Menu", FFsT0V, [])
  VVgAHl  = None
  if VVxnW2:
   VVgAHl = ("Get JS" , BF(self.VVKgnD, "/".join(self.VVrKIdData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFMPky(self, None, title=title, width=1200, header=header, VVL1iO=rows, VVLkOa=widths, VVJfxh=26, VV1mml=VV1mml, VVgAHl=VVgAHl, VVI8Pk="#0a00292B", VV2s6D="#0a002126", VVjLdB="#0a002126", VVaZj9="#00000000", searchCol=2)
 def VVrEkq(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    VVAP1F = CCfLea()
    if mode in (self.VVNqui, self.VVgnjV):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVcM1V(item, "num"         )
      name     = self.VVcM1V(item, "name"        )
      stream_id    = self.VVcM1V(item, "stream_id"       )
      stream_icon    = self.VVcM1V(item, "stream_icon"       )
      epg_channel_id   = self.VVcM1V(item, "epg_channel_id"      )
      added     = self.VVcM1V(item, "added"    , isDate=True )
      is_adult    = self.VVcM1V(item, "is_adult"       )
      category_id    = self.VVcM1V(item, "category_id"       )
      tv_archive    = self.VVcM1V(item, "tv_archive"       )
      direct_source   = self.VVcM1V(item, "direct_source"      )
      tv_archive_duration  = self.VVcM1V(item, "tv_archive_duration"     )
      name = VVAP1F.VVMLC0(name, is_adult)
      if name:
       if mode == self.VVNqui or mode == self.VVgnjV and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVR9Np:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVcM1V(item, "num"         )
      name    = self.VVcM1V(item, "name"        )
      stream_id   = self.VVcM1V(item, "stream_id"       )
      stream_icon   = self.VVcM1V(item, "stream_icon"       )
      added    = self.VVcM1V(item, "added"    , isDate=True )
      is_adult   = self.VVcM1V(item, "is_adult"       )
      category_id   = self.VVcM1V(item, "category_id"       )
      container_extension = self.VVcM1V(item, "container_extension"     ) or "mp4"
      name = VVAP1F.VVMLC0(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VVbbs0:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVcM1V(item, "num"        )
      name    = self.VVcM1V(item, "name"       )
      series_id   = self.VVcM1V(item, "series_id"      )
      cover    = self.VVcM1V(item, "cover"       )
      genre    = self.VVcM1V(item, "genre"       )
      episode_run_time = self.VVcM1V(item, "episode_run_time"    )
      category_id   = self.VVcM1V(item, "category_id"      )
      container_extension = self.VVcM1V(item, "container_extension"    ) or "mp4"
      name = VVAP1F.VVMLC0(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVipAs(self, mode, title):
  cList, err = self.VVuNmZ(mode)
  if cList and mode == self.VVBnzb:
   cList = self.VV9z2T(cList)
  if err:
   FFu1fZ(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVI8Pk, VV2s6D, VVjLdB, VVaZj9 = self.VV3ix7(mode)
   mName = self.VVMWwT(mode)
   if   mode == self.VV5OCW  : fMode = self.VVNqui
   elif mode == self.VV4DQN  : fMode = self.VVR9Np
   elif mode == self.VVHjam : fMode = self.VVbbs0
   elif mode == self.VVBnzb : fMode = self.VVgnjV
   if mode == self.VVBnzb:
    VVUZua = None
    VVR0s7 = None
   else:
    VVUZua = ("Find in %s" % mName , BF(self.VVmzJp, fMode, True) , [])
    VVR0s7 = ("Find in Selected" , BF(self.VVmzJp, fMode, False) , [])
   VVhqvZ   = ("Show List"   , BF(self.VVO5VA, mode)  , [])
   VV1mml  = ("Home Menu"   , FFsT0V         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFMPky(self, None, title=title, width=1200, header=header, VVL1iO=cList, VVLkOa=widths, VVJfxh=30, VV1mml=VV1mml, VVUZua=VVUZua, VVR0s7=VVR0s7, VVhqvZ=VVhqvZ, VVI8Pk=VVI8Pk, VV2s6D=VV2s6D, VVjLdB=VVjLdB, VVaZj9=VVaZj9, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFu1fZ(self, "No list from server !", title=title)
  FFAcfo(self)
 def VVuNmZ(self, mode):
  qUrl  = self.VVcIXS(mode, self.VVrKIdData["playListURL"])
  txt, err = self.VVKC2S(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    VVAP1F = CCfLea()
    for item in tDict:
     category_id  = self.VVcM1V(item, "category_id"  )
     category_name = self.VVcM1V(item, "category_name" )
     parent_id  = self.VVcM1V(item, "parent_id"  )
     category_name = VVAP1F.VVK7g4(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VV9z2T(self, catList):
  mode  = self.VVgnjV
  qUrl  = self.VVcIXS(mode, self.VVrKIdData["playListURL"])
  txt, err = self.VVKC2S(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVrEkq(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVO5VA(self, mode, VVoyO8, title, txt, colList):
  title = colList[1]
  FFZmix(VVoyO8, BF(self.VVzIGq, mode, VVoyO8, title, txt, colList), title="Downloading ...")
 def VVzIGq(self, mode, VVoyO8, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVMWwT(mode) + " : "+ bName
  if   mode == self.VV5OCW  : mode = self.VVNqui
  elif mode == self.VV4DQN  : mode = self.VVR9Np
  elif mode == self.VVHjam : mode = self.VVbbs0
  elif mode == self.VVBnzb : mode = self.VVgnjV
  qUrl  = self.VVcIXS(mode, self.VVrKIdData["playListURL"], catID)
  txt, err = self.VVKC2S(qUrl)
  list  = []
  if not err and mode in (self.VVNqui, self.VVR9Np, self.VVbbs0, self.VVgnjV):
   list, err = self.VVrEkq(mode, txt)
  if err:
   FFu1fZ(self, err, title=title)
  elif list:
   VV1mml  = ("Home Menu"   , FFsT0V            , [])
   if mode in (self.VVNqui, self.VVgnjV):
    VVI8Pk, VV2s6D, VVjLdB, VVaZj9 = self.VV3ix7(mode)
    VVDAgH = (""     , BF(self.VVfZsG, mode)      , [])
    VVgAHl = ("Download Options" , BF(self.VVELWJ, mode, "", "")   , [])
    VVUZua = ("Options"   , BF(self.VVl9qk, "lv", mode, bName)   , [])
    VVR0s7 = ("Posters Mode"  , BF(self.VVqdwx, mode, False)     , [])
    if mode == self.VVNqui:
     VVhqvZ = ("Play"    , BF(self.VVk48W, mode)       , [])
    else:
     VVhqvZ = ("Programs"   , BF(self.VVaSXO, mode, bName) , [])
   elif mode == self.VVR9Np:
    VVI8Pk, VV2s6D, VVjLdB, VVaZj9 = self.VV3ix7(mode)
    VVhqvZ  = ("Play"    , BF(self.VVk48W, mode)       , [])
    VVDAgH = (""     , BF(self.VVfZsG, mode)      , [])
    VVgAHl = ("Download Options" , BF(self.VVELWJ, mode, "v", "")   , [])
    VVUZua = ("Options"   , BF(self.VVl9qk, "v", mode, bName)   , [])
    VVR0s7 = ("Posters Mode"  , BF(self.VVqdwx, mode, False)     , [])
   elif mode == self.VVbbs0:
    VVI8Pk, VV2s6D, VVjLdB, VVaZj9 = self.VV3ix7("series2")
    VVhqvZ  = ("Show Seasons"  , BF(self.VVjoPq, mode)       , [])
    VVDAgH = (""     , BF(self.VVUYND, mode)     , [])
    VVgAHl = None
    VVUZua = None
    VVR0s7 = ("Posters Mode"  , BF(self.VVqdwx, mode, True)      , [])
   header, widths, VV28Ef = self.VV5UZj(mode)
   FFMPky(self, None, title=title, header=header, VVL1iO=list, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VVhqvZ=VVhqvZ, VV1mml=VV1mml, VVgAHl=VVgAHl, VVUZua=VVUZua, VVR0s7=VVR0s7, lastFindConfigObj=CFG.lastFindIptv, VVDAgH=VVDAgH, VVI8Pk=VVI8Pk, VV2s6D=VV2s6D, VVjLdB=VVjLdB, VVaZj9=VVaZj9, VVMVWT=True, searchCol=1)
  else:
   FFu1fZ(self, "No Channels found !", title=title)
  FFAcfo(self)
 def VV5UZj(self, mode):
  if mode in (self.VVNqui, self.VVgnjV):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VV28Ef  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVR9Np:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VV28Ef  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VVbbs0:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VV28Ef  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VV28Ef
 def VVaSXO(self, mode, bName, VVoyO8, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVrKIdData["playListURL"]
  ok_fnc  = BF(self.VVJuqn, hostUrl, chName, catId, streamId)
  FFZmix(VVoyO8, BF(CC0A1M.VVXJ0U, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVJuqn(self, chUrl, chName, catId, streamId, VVoyO8, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC0A1M.VVNvtX(chUrl)
   chNum = "333"
   refCode = CC0A1M.VV1u2M(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFI9Ee(self, chUrl, VVtcz9=False)
   CCDmyf.VVtxwR(self.session)
  else:
   FFu1fZ(self, "Incorrect Timestamp", pTitle)
 def VVjoPq(self, mode, VVoyO8, title, txt, colList):
  title = colList[1]
  FFZmix(VVoyO8, BF(self.VVqNEy, mode, VVoyO8, title, txt, colList), title="Downloading ...")
 def VVqNEy(self, mode, VVoyO8, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVcIXS(self.VVmzst, self.VVrKIdData["playListURL"], series_id)
  txt, err = self.VVKC2S(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVcM1V(tDict["info"], "name"   )
      category_id = self.VVcM1V(tDict["info"], "category_id" )
      icon  = self.VVcM1V(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      VVAP1F = CCfLea()
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVcM1V(EP, "id"     )
        episode_num   = self.VVcM1V(EP, "episode_num"   )
        epTitle    = self.VVcM1V(EP, "title"     )
        container_extension = self.VVcM1V(EP, "container_extension" )
        seasonNum   = self.VVcM1V(EP, "season"    )
        epTitle = VVAP1F.VVMLC0(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFu1fZ(self, err, title=title)
  elif list:
   VV1mml = ("Home Menu"   , FFsT0V          , [])
   VVgAHl = ("Download Options" , BF(self.VVELWJ, mode, "s", title), [])
   VVUZua = ("Options"   , BF(self.VVl9qk, "s", mode, title) , [])
   VVR0s7 = ("Posters Mode"  , BF(self.VVqdwx, mode, False)   , [])
   VVDAgH = (""     , BF(self.VVfZsG, mode)    , [])
   VVhqvZ  = ("Play"    , BF(self.VVk48W, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VV28Ef  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFMPky(self, None, title=title, header=header, VVL1iO=list, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VV1mml=VV1mml, VVgAHl=VVgAHl, VVhqvZ=VVhqvZ, VVDAgH=VVDAgH, VVUZua=VVUZua, VVR0s7=VVR0s7, lastFindConfigObj=CFG.lastFindIptv, VVI8Pk="#0a00292B", VV2s6D="#0a002126", VVjLdB="#0a002126", VVaZj9="#00000000")
  else:
   FFu1fZ(self, "No Channels found !", title=title)
  FFAcfo(self)
 def VVmzJp(self, mode, isAll, VVoyO8, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVMYdC = []
  VVMYdC.append(("Keyboard"  , "manualEntry"))
  VVMYdC.append(("From Filter" , "fromFilter"))
  FFcKE0(self, BF(self.VV98Me, VVoyO8, mode, onlyCatID), title="Input Type", VVMYdC=VVMYdC, width=400)
 def VV98Me(self, VVoyO8, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFSAou(self, BF(self.VV5g9Y, VVoyO8, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCfZNJ(self)
    filterObj.VVoTGH(BF(self.VV5g9Y, VVoyO8, mode, onlyCatID))
 def VV5g9Y(self, VVoyO8, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FF72vQ(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CCfZNJ.VVGe34(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FFu1fZ(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FFu1fZ(self, "All words must be at least 3 characters !", title=title)
        return
     VVAP1F = CCfLea()
     if CFG.hideIptvServerAdultWords.getValue() and VVAP1F.VVwZ5s(words):
      FFu1fZ(self, VVAP1F.VVgRGT(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CC54zA, barTheme=CC54zA.VVlVsr
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVpfDk, VVoyO8, mode, onlyCatID, title, words, toFind, asPrefix, VVAP1F)
          , VV2r3B = BF(self.VVpwyW, mode, toFind, title))
   if not words:
    FFAcfo(VVoyO8, "Nothing to find !", 1500)
 def VVpfDk(self, VVoyO8, mode, onlyCatID, title, words, toFind, asPrefix, VVAP1F, VVeDSa):
  VVeDSa.VVvPX7(VVoyO8.VV03io() if onlyCatID is None else 1)
  VVeDSa.VVinQh = []
  for row in VVoyO8.VVVGfF():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVeDSa or VVeDSa.isCancelled:
    return
   VVeDSa.VVs1tz(1)
   VVeDSa.VV394z(catName)
   qUrl  = self.VVcIXS(mode, self.VVrKIdData["playListURL"], catID)
   txt, err = self.VVKC2S(qUrl)
   if not err:
    tList, err = self.VVrEkq(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = VVAP1F.VVMLC0(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       VVeDSa.VVinQh.append(item)
 def VVpwyW(self, mode, toFind, title, VVw6fk, VVinQh, threadCounter, threadTotal, threadErr):
  if VVinQh:
   title = self.VVrhbR(mode, toFind)
   if mode == self.VVNqui or mode == self.VVR9Np:
    if mode == self.VVR9Np : typ = "v"
    else          : typ = ""
    bName   = CC0A1M.VVnS9E(toFind)
    VVhqvZ  = ("Play"     , BF(self.VVk48W, mode)     , [])
    VVgAHl = ("Download Options" , BF(self.VVELWJ, mode, typ, "") , [])
    VVUZua = ("Options"   , BF(self.VVl9qk, "fnd", mode, bName), [])
    VVR0s7 = ("Posters Mode"  , BF(self.VVqdwx, mode, False)   , [])
   elif mode == self.VVbbs0:
    VVhqvZ  = ("Show Seasons"  , BF(self.VVjoPq, mode)     , [])
    VVUZua = None
    VVgAHl = None
    VVR0s7 = ("Posters Mode"  , BF(self.VVqdwx, mode, True)    , [])
   VVDAgH  = (""     , BF(self.VVfZsG, mode)    , [])
   VV1mml  = ("Home Menu"   , FFsT0V          , [])
   header, widths, VV28Ef = self.VV5UZj(mode)
   VVoyO8 = FFMPky(self, None, title=title, header=header, VVL1iO=VVinQh, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VVhqvZ=VVhqvZ, VV1mml=VV1mml, VVgAHl=VVgAHl, VVUZua=VVUZua, VVR0s7=VVR0s7, VVDAgH=VVDAgH, VVI8Pk="#0a00292B", VV2s6D="#0a002126", VVjLdB="#0a002126", VVaZj9="#00000000", VVMVWT=True, searchCol=1)
   if not VVw6fk:
    FFAcfo(VVoyO8, "Stopped" , 1000)
  else:
   if VVw6fk:
    FFu1fZ(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVeECa(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VVNqui, self.VVgnjV):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVR9Np:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FF3RM7(chName)
  url = self.VVrKIdData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVNvtX(url)
  refCode = self.VV1u2M(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVfZsG(self, mode, VVoyO8, title, txt, colList):
  FFZmix(VVoyO8, BF(self.VVdEoO, mode, VVoyO8, title, txt, colList))
 def VVdEoO(self, mode, VVoyO8, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVeECa(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFfM6H(self, fncMode=CChafy.VV80u3, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVUYND(self, mode, VVoyO8, title, txt, colList):
  FFZmix(VVoyO8, BF(self.VVAxFU, mode, VVoyO8, title, txt, colList))
 def VVAxFU(self, mode, VVoyO8, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFfM6H(self, fncMode=CChafy.VVUT3c, chName=name, text=txt, picUrl=Cover)
 def VVqdwx(self, mode, isSerNames, VVoyO8, title, txt, colList):
  if   mode in ("itv"  , CC0A1M.VVNqui, CC0A1M.VVgnjV): category = "live"
  elif mode in ("vod"  , CC0A1M.VVR9Np )          : category = "vod"
  elif mode in ("series" , CC0A1M.VVbbs0)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VVNqui : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVgnjV : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVR9Np  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVbbs0 : picCol, descCol, descTxt = 5, 0, "Season"
  FFZmix(VVoyO8, BF(self.session.open, CCXeSp, VVoyO8, category, nameCol, picCol, descCol, descTxt))
 def VVELWJ(self, mode, typ, seriesName, VVoyO8, title, txt, colList):
  VVMYdC = []
  isMulti = VVoyO8.VVdP3d
  tot  = VVoyO8.VVlPPo()
  if isMulti:
   if tot < 1:
    FFAcfo(VVoyO8, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVMYdC.append(("Download %s PIcon%s" % (name, FFmxIl(tot)), "dnldPicons" ))
  if typ:
   VVMYdC.append(VVc27s)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVMYdC.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVMYdC.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVMYdC.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CC0kPO.VVCfZp():
    VVMYdC.append(VVc27s)
    VVMYdC.append(("Download Manager"      , "dload_stat" ))
  FFcKE0(self, BF(self.VVO5Yw, VVoyO8, mode, typ, seriesName, colList), title="Download Options", VVMYdC=VVMYdC)
 def VVO5Yw(self, VVoyO8, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVmzQy(VVoyO8, mode)
   elif item == "dnldSel"  : self.VV8iBn(VVoyO8, mode, typ, colList, True)
   elif item == "addSel"  : self.VV8iBn(VVoyO8, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVhjxZ(VVoyO8, mode, typ, seriesName)
   elif item == "dload_stat" : CC0kPO.VVNz38(self)
 def VV8iBn(self, VVoyO8, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVUlzU(mode, typ, colList)
  if startDnld:
   CC0kPO.VVFabq(self, decodedUrl)
  else:
   self.VV1Kmr(VVoyO8, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVhjxZ(self, VVoyO8, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVoyO8.VVVGfF():
   chName, decodedUrl = self.VVUlzU(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VV1Kmr(VVoyO8, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VV1Kmr(self, VVoyO8, title, chName, decodedUrl_list, startDnld):
  FFlOO5(self, BF(self.VVJ480, VVoyO8, decodedUrl_list, startDnld), chName, title=title)
 def VVJ480(self, VVoyO8, decodedUrl_list, startDnld):
  added, skipped = CC0kPO.VV9UpJ(decodedUrl_list)
  FFAcfo(VVoyO8, "Added", 1000)
 def VVUlzU(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVeECa(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV9owg(mode, colList)
   refCode, chUrl = self.VVqBmW(self.VVBAgU, self.VVJNaw, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFfknX(chUrl)
  return chName, decodedUrl
 def VVmzQy(self, VVoyO8, mode):
  if os.system(FFVKmy("which ffmpeg")) == 0:
   self.session.open(CC54zA, barTheme=CC54zA.VVIWtA
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVjUD8, VVoyO8, mode)
       , VV2r3B = self.VV0Ny6)
  else:
   FFlOO5(self, BF(CC0A1M.VVtswM, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VV0Ny6(self, VVw6fk, VVinQh, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVinQh["proces"], VVinQh["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVinQh["ok"], VVinQh["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVinQh["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVinQh["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVinQh["badURL"]
  txt += "Download Failure\t: %d\n"   % VVinQh["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVinQh["path"]
  if not VVw6fk  : color = "#11402000"
  elif VVinQh["err"]: color = "#11201000"
  else     : color = None
  if VVinQh["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVinQh["err"], txt)
  title = "PIcons Download Result"
  if not VVw6fk:
   title += "  (cancelled)"
  FF4gok(self, txt, title=title, VVjLdB=color)
 def VVjUD8(self, VVoyO8, mode, VVeDSa):
  isMulti = VVoyO8.VVdP3d
  if isMulti : totRows = VVoyO8.VVlPPo()
  else  : totRows = VVoyO8.VV03io()
  VVeDSa.VVvPX7(totRows)
  VVeDSa.VV46nD(0)
  counter     = VVeDSa.counter
  maxValue    = VVeDSa.maxValue
  pPath     = CC2wnB.VV6OCP()
  VVeDSa.VVinQh = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for rowNum, row in enumerate(VVoyO8.VVVGfF()):
    if VVeDSa.isCancelled:
     break
    if not isMulti or VVoyO8.VVYiHp(rowNum):
     VVeDSa.VVinQh["proces"] += 1
     VVeDSa.VVs1tz(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV9owg(mode, row)
      refCode = CC0A1M.VV1u2M(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVbD2S(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVeECa(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVeDSa.VVinQh["attempt"] += 1
       path, err = FFmy2V(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVeDSa:
         VVeDSa.VVinQh["ok"] += 1
         VVeDSa.VV46nD(VVeDSa.VVinQh["ok"])
        if FFehaw(path) > 0:
         cmd = CChafy.VVA5VG(path)
         cmd += FFVKmy("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         if VVeDSa:
          VVeDSa.VVinQh["size0"] += 1
         FF2PD3(path)
       elif err:
        if VVeDSa:
         VVeDSa.VVinQh["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVeDSa:
          VVeDSa.VVinQh["err"] = err.title()
         break
      else:
       if VVeDSa:
        VVeDSa.VVinQh["exist"] += 1
     else:
      if VVeDSa:
       VVeDSa.VVinQh["badURL"] += 1
  except:
   pass
 def VVI2wl(self):
  title = "Download PIcons for Current Bouquet"
  if os.system(FFVKmy("which ffmpeg")) == 0:
   self.session.open(CC54zA, barTheme=CC54zA.VVIWtA
       , titlePrefix = ""
       , fncToRun  = self.VVz1Wa
       , VV2r3B = BF(self.VVyopM, title))
  else:
   FFlOO5(self, BF(CC0A1M.VVtswM, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VVz1Wa(self, VVeDSa):
  bName = CC3Jx1.VVEZDr()
  pPath = CC2wnB.VV6OCP()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVeDSa.VVinQh = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CC3Jx1.VVAVo4()
  if not VVeDSa or VVeDSa.isCancelled:
   return
  if not services or len(services) == 0:
   VVeDSa.VVinQh = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVeDSa.VVvPX7(totCh)
  VVeDSa.VV46nD(0)
  for serv in services:
   if not VVeDSa or VVeDSa.isCancelled:
    return
   VVeDSa.VVinQh = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVeDSa.VVs1tz(1)
   VVeDSa.VV46nD(totPic)
   fullRef  = serv[0]
   if FFQ9UD(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFfknX(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CCMCGp.VVjXgS(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CC0A1M.VVpVfO(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInv += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CC0A1M.VVKC2S(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CChafy.VVAlJc(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFmy2V(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVeDSa:
     VVeDSa.VV46nD(totPic)
    if FFehaw(path) > 0:
     cmd = CChafy.VVA5VG(path)
     cmd += FFVKmy("mv -f '%s' '%s'" % (path, pPath)) + ";"
     os.system(cmd)
     totPicOK += 1
    else:
     totSize0
     FF2PD3(path)
  if VVeDSa:
   VVeDSa.VVinQh = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVyopM(self, title, VVw6fk, VVinQh, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVinQh
  if err:
   FFu1fZ(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FFXe6i(str(totExist)  , VVwtwf)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFXe6i(str(totNotIptv)  , VVwtwf)
    if totServErr : txt += "Server Errors\t: %s\n" % FFXe6i(str(totServErr) + t1, VVwtwf)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FFXe6i(str(totParseErr) , VVwtwf)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FFXe6i(str(totInvServ)  , VVwtwf)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FFXe6i(str(totInvPicUrl) , VVwtwf)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FFXe6i(str(totSize0)  , VVwtwf)
   if not VVw6fk:
    title += "  (stopped)"
   FF4gok(self, txt, title=title)
 @staticmethod
 def VVtswM(SELF):
  cmd = FF9JgI(VVuVG6, "ffmpeg")
  if cmd : FFrhsY(SELF, cmd, title="Installing FFmpeg")
  else : FF0x3g(SELF)
 def VViwDl(self):
  self.session.open(CC54zA, barTheme=CC54zA.VVIWtA
      , titlePrefix = ""
      , fncToRun  = self.VVzQp3
      , VV2r3B = self.VV8Ont)
 def VVzQp3(self, VVeDSa):
  bName = CC3Jx1.VVEZDr()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVeDSa.VVinQh = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CC3Jx1.VVAVo4()
  if not VVeDSa or VVeDSa.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVeDSa.VVvPX7(totCh)
   for serv in services:
    if not VVeDSa or VVeDSa.isCancelled:
     return
    VVeDSa.VVs1tz(1)
    fullRef = serv[0]
    if FFQ9UD(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFfknX(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     if span:
      valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query, m3u_Url, host, user1, pass1, streamId, err = CCMCGp.VVjXgS(decodedUrl)
      if valid and mode == "itv" : uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
      else      : uHost = uUser = uPass = uId = uChName = ""
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CC0A1M.VVpVfO(m3u_Url)
     if VVeDSa:
      VVeDSa.VVqtMu(totEpgOK, uChName)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CC0A1M.VVySiQ(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CChafy.VVxaKS(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if VVeDSa:
     VVeDSa.VVinQh = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVeDSa.VVinQh = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VV8Ont(self, VVw6fk, VVinQh, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVinQh
  title = "IPTV EPG Import"
  if err:
   FFu1fZ(self, err, title=title)
  else:
   if VVw6fk and totEpgOK > 0:
    CCkToA.VVlPWO()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFXe6i(str(totNotIptv), VVwtwf)
    if totServErr : txt += "Server Errors\t: %s\n" % FFXe6i(str(totServErr) + t1, VVwtwf)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFXe6i(str(totInv), VVwtwf)
   if not VVw6fk:
    title += "  (stopped)"
   FF4gok(self, txt, title=title)
 @staticmethod
 def VVySiQ(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC0A1M.VVNvtX(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CC0A1M.VVKC2S(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CC0A1M.VVcM1V(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CC0A1M.VVcM1V(item, "lang"        ).upper()
    now_playing   = CC0A1M.VVcM1V(item, "now_playing"      )
    start    = CC0A1M.VVcM1V(item, "start"        )
    start_timestamp  = CC0A1M.VVcM1V(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CC0A1M.VVcM1V(item, "start_timestamp"     )
    stop_timestamp  = CC0A1M.VVcM1V(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CC0A1M.VVcM1V(item, "stop_timestamp"      )
    tTitle    = CC0A1M.VVcM1V(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VV1u2M(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CC0A1M.VVSIuw(catID, MAX_4b)
  TSID = CC0A1M.VVSIuw(chNum, MAX_4b)
  ONID = CC0A1M.VVSIuw(chNum, MAX_4b)
  NS  = CC0A1M.VVSIuw(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVSIuw(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVnS9E(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VV3ix7(mode):
  if   mode in ("itv"  , CC0A1M.VV5OCW)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CC0A1M.VV4DQN)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CC0A1M.VVHjam) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CC0A1M.VVBnzb) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CC0A1M.VVgnjV    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVn2I0(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVHClL:
   excl = FFcbot(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFu1fZ(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFEUax('find %s %s %s' % (path, excl, par))
  if not files:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFu1fZ(self, err)
  elif len(files) == 1 and files[0] == VVGEJv:
   FFu1fZ(self, VVGEJv)
  else:
   return files
 @staticmethod
 def VVHTQS():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FF5sxC(path)
  return "/"
 @staticmethod
 def VVXJ0U(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CC0A1M.VVySiQ(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FFu1fZ(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVI8Pk, VV2s6D, VVjLdB, VVaZj9 = CC0A1M.VV3ix7("")
   VV1mml = ("Home Menu" , FFsT0V, [])
   VVhqvZ  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VV28Ef  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFMPky(SELF, None, title="Programs for : " + chName, header=header, VVL1iO=pList, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=24, VVhqvZ=VVhqvZ, VV1mml=VV1mml, VVI8Pk=VVI8Pk, VV2s6D=VV2s6D, VVjLdB=VVjLdB, VVaZj9=VVaZj9)
  else:
   FFu1fZ(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVDRnn(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VVkcgJ(self, isPortal, line, VVVCbtObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FFlOO5(self, BF(self.VVR2OU, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FF72vQ(confItem, line)
   FF5VuW(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title, VV2r3B=FFsT0V)
 def VVR2OU(self, confItem):
  FF72vQ(confItem, "")
  FFsT0V()
 def VVVj4u(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VVsrUr(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FFZmix(self, BF(self.VVgWgu, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FFu1fZ(self, "Incorrect server data !")
 @staticmethod
 def VVV8dQ(SELF, isPortal, line, VVVCbtObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CC0A1M.VVHTQS()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFu1fZ(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FF5VuW(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFu1fZ(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVl9qk(self, source, mode, curBName, VVoyO8, title, txt, colList):
  isMulti = VVoyO8.VVdP3d
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVoyO8.VVlPPo()
   totTxt = "%d Service%s" % (tot, FFmxIl(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FFXe6i(totTxt, VVJ6nn)
  mSel = CCvNaQ(self, VVoyO8, addSep=False)
  VVMYdC, cbFncDict = [], None
  VVMYdC.append(VVc27s)
  if itemsOK:
   VVMYdC.append(("Add %s to New Bouquet : %s" % (totTxt, FFXe6i(curBName, VVhAfh)), "addToCur"))
   VVMYdC.append(("Add %s to Other Bouquet ..." % (totTxt)          , "addToNew"))
   cbFncDict = { "addToCur": BF(FFZmix, mSel.VVoyO8, BF(self.VVSHft,source, mode, curBName, VVoyO8, title), title="Adding Services ...")
      , "addToNew": BF(self.VVE0M6, source, mode, curBName, VVoyO8, title)
      }
  else:
   VVMYdC.append(("Add to Bouquet (nothing selected)", ))
  mSel.VVUtfc(VVMYdC, cbFncDict)
 def VVSHft(self, source, mode, curBName, VVoyO8, Title):
  chUrlLst = self.VVkSQh(source, mode, VVoyO8)
  CC3Jx1.VVRn29(self, Title, curBName, "", chUrlLst)
 def VVE0M6(self, source, mode, curBName, VVoyO8, Title):
  picker = CC3Jx1(self, VVoyO8, Title, BF(self.VVkSQh, source, mode, VVoyO8), defBName=curBName)
 def VVkSQh(self, source, mode, VVoyO8):
  totChange = 0
  isMulti = VVoyO8.VVdP3d
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVoyO8.VVVGfF()):
   if not isMulti or VVoyO8.VVYiHp(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV9owg(mode, row)
     refCode, chUrl = self.VVqBmW(self.VVBAgU, self.VVJNaw, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VVSEC8(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVeECa(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
class CCXeSp(Screen):
 def __init__(self, session, VVoyO8, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FFTWzO(WINDOW_SERVER_PIC_BROWSER, 1870, 1030, 50, 10, 10, "#33000000", "#33000000", 50, topRightBtns=2)
  self.session   = session
  self.Title    = "Server Browser"
  FF0Q0u(self, self.Title)
  self.VVoyO8  = VVoyO8
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.TOTAL_ROWS   = 2
  self.TOTAL_COLS   = 6
  self.PAGE_PICTURE  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.VVL1iO    = []
  self.totPosterUrls  = 0
  self.totalChannels  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVXneu, subPath)
  if not pathExists(self.pPath):
   os.system(FFVKmy("mkdir -p '%s'" % (self.pPath)))
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  for i in range(4):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVqqT1   ,
   "cancel"  : self.close   ,
   "menu"   : self.VVvr4A,
   "info"   : self.VVC7Zl ,
   "up"   : self.VVMgQm    ,
   "down"   : self.VVcAI8   ,
   "left"   : self.VVvyya   ,
   "right"   : self.VVF1i7   ,
   "next"   : self.VVVrpS  ,
   "last"   : self.VVk7uS
  }, -1)
  self.onShown.append(self.VViGDa)
  self.onClose.append(self.onExit)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FFKT7W(self)
  FFyHsQ(self)
  self.VV07be()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVvr4A(self):
  VVMYdC = []
  VVMYdC.append(("Show Poster/PIcon"      , "VV08gi"   ))
  VVMYdC.append(("Copy Poster/PIcon to Export-Directory" , "VVBGwd"  ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Cache details"       , "VVMPl1" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Change Poster/Picon Transparency Color" , "VVaa57" ))
  FFcKE0(self, self.VV7sER, title=self.Title, VVMYdC=VVMYdC)
 def VV7sER(self, item=None):
  if item is not None:
   if   item == "VVBGwd"   : self.VVBGwd()
   elif item == "VV08gi"   : self.VV08gi()
   elif item == "VVMPl1"  : FFZmix(self, self.VVMPl1, title="Calculating ...")
   elif item == "VVaa57" : self.VVaa57()
 def VVqqT1(self):
  self.VVoyO8.VVjS0j(self.curIndex)
  self.VVoyO8.VVO8C7()
 def VVC7Zl(self):
  self.VVoyO8.VVjS0j(self.curIndex)
  self.VVoyO8.VVxPcK()
 def VVaa57(self):
  fg = bg = CFG.transpColorPosters.getValue()
  self.session.openWithCallback(self.VVqcU4, CC3Y09, defFG=fg, defBG=bg, onlyBG=True)
 def VVqcU4(self, fg, bg):
  if bg:
   FF72vQ(CFG.transpColorPosters, bg)
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FFaCb6(self["myPosterRep%d%d" % (row, col)], bg)
 def VV07be(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
    self["myPosterLbl%d%d" % (row, col)].instance.setNoWrap(True)
  for colList in self.VVoyO8.VVVGfF():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = os.path.basename(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VVL1iO.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalChannels = len(self.VVL1iO)
  self.totalPages  = int(self.totalChannels / self.PAGE_PICTURE) + (self.totalChannels % self.PAGE_PICTURE > 0)
  self.VVV7s5(True)
  self.VV1Vyg(self.VVoyO8.VVr4DQ())
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV2vlF)
  except:
   self.timer.callback.append(self.VV2vlF)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VVPfhS)
  self.myThread.start()
 def VVPfhS(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VVL1iO):
    if not self.stopThread:
     if picUrl and not fName:
      fName = os.path.basename(picUrl)
      path, err = FFmy2V(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       os.system(FFVKmy("mv -f '%s' '%s'" % (path, self.pPath + fName)))
       self.VVL1iO[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VV2vlF(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVpQzP + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalChannels
  f1 = self.curPage * self.PAGE_PICTURE
  f2 = f1 + self.PAGE_PICTURE
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVL1iO[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VVL1iO[ndx] = (chName, subj, desc, fName, "")
     try:
      self["myPosterPic%d%d" % (row, col)].instance.setPixmapFromFile(path)
     except:
      pass
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVV7s5(self, force=False):
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVBpWj = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVBpWj: self.curPage = VVBpWj
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVYrFp()
  if self.curPage == VVBpWj:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPosterPic%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICTURE + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVnGSo()
  chName, subj, desc, fName, picUrl = self.VVL1iO[self.curIndex]
 def VVnGSo(self):
  chName, subj, desc, fName, picUrl = self.VVL1iO[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalChannels))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVYrFp(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
  last = self.totalChannels
  f1 = self.curPage * self.PAGE_PICTURE
  f2 = f1 + self.PAGE_PICTURE
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVL1iO[ndx]
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.setText(chName)
   lbl.show()
   pic.show()
   path = ""
   if fName:
    path = self.pPath + fName
   if not fileExists(path):
    path = VVlId3 + "iptv.png"
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
   except:
    pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVMgQm(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VV1fCn()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVV7s5()
 def VVcAI8(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV4I3e()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVV7s5()
 def VVvyya(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VV1fCn()
  else:
   self.curCol -= 1
   self.VVV7s5()
 def VVF1i7(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV4I3e()
  else:
   self.curCol += 1
   self.VVV7s5()
 def VVk7uS(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVV7s5(True)
 def VVVrpS(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVV7s5(True)
 def VV4I3e(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVV7s5(True)
 def VV1fCn(self):
  self.curPage = self.totalPages - 1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVV7s5(True)
 def VV1Vyg(self, ndx):
  self.curPage = int(ndx / self.PAGE_PICTURE)
  ndx     -= self.curPage * self.PAGE_PICTURE
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VVV7s5(True)
 def VV08gi(self):
  chName, subj, desc, fName, picUrl = self.VVL1iO[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCKf0K.VVAHGG(self, self.pPath + fName)
  else          : FFAcfo(self, "File not found", 1500)
 def VVBGwd(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VVL1iO[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   res = os.system(FFVKmy("cp -f '%s' '%s'" % (self.pPath + fName, dstF)))
   if res == 0 : FF5VuW(self, "File copied to:\n\n%s" % dstF, title=title)
   else  : FFu1fZ(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FFu1fZ(self, "No Poster/PIcon found", title=title)
 def VVMPl1(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVXneu, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FFY14S("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CC5DZc.VVmkPo(size)
   txt += "%s\n    %s\n\n" % (FFXe6i(path, VVJ6nn), size)
  mainPath = "%sPosters" % VVXneu
  totFiles = FFY14S("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = "" if not totFiles.isdigit() else " (%s files)" % totFiles
  txt += "%s\n    %s\n\n" % (FFXe6i("Total space used by Posters/PIcons%s:" % totFTxt, VVrhVl), CC5DZc.VVmkPo(totSize))
  mountPath = CC5DZc.VVydTn(mainPath)
  if pathExists(mountPath):
   totSize  = CC5DZc.VVbQpT(mountPath)
   freeSize = CC5DZc.VVcRWj(mountPath)
   usedSize = CC5DZc.VVmkPo(totSize - freeSize)
   totSize  = CC5DZc.VVmkPo(totSize)
   freeSize = CC5DZc.VVmkPo(freeSize)
   txt += "%s\n" % VVn31f
   txt += FFXe6i("Media Space:\n", VVwhxm)
   txt += "    Media Path\t: %s\n" % FFXe6i(mountPath, VV2RHA)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FF4gok(self, txt, title="Cache Used Size", height=1000)
class CCD0SJ(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFTWzO(VV4Y67, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVPcym  = 0
  self.VV5Czu = 1
  self.VV3H75  = 2
  VVMYdC = []
  VVMYdC.append(("Find in All Service (from filter)" , "VVE4Q9" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Find in All (Manual Entry)"   , "VVhjpS"    ))
  VVMYdC.append(("Find in TV"       , "VVAsSh"    ))
  VVMYdC.append(("Find in Radio"      , "VVEP8y"   ))
  if self.VVs1WE():
   VVMYdC.append(VVc27s)
   VVMYdC.append(("Hide Channel: %s" % self.servName , "VVo6Wy"   ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Zap History"       , "VVADyo"    ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("IPTV Tools"       , "iptv"      ))
  VVMYdC.append(("PIcons Tools"       , "PIconsTools"     ))
  VVMYdC.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FF0Q0u(self, VVMYdC=VVMYdC, title=title)
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FF4IYg(self["myMenu"])
  FFIvVk(self)
  if self.isFindMode:
   self.VVEpVi(self.VVad7e())
 def VVqqT1(self):
  global VVmICA
  VVmICA = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVhjpS"    : self.VVhjpS()
   elif item == "VVE4Q9" : self.VVE4Q9()
   elif item == "VVAsSh"    : self.VVAsSh()
   elif item == "VVEP8y"   : self.VVEP8y()
   elif item == "VVo6Wy"   : self.VVo6Wy()
   elif item == "VVADyo"    : self.VVADyo()
   elif item == "iptv"       : self.session.open(CC0A1M)
   elif item == "PIconsTools"     : self.session.open(CC2wnB)
   elif item == "ChannelsTools"    : self.session.open(CCFb9t)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVAsSh(self) : self.VVEpVi(self.VVPcym)
 def VVEP8y(self) : self.VVEpVi(self.VV5Czu)
 def VVhjpS(self) : self.VVEpVi(self.VV3H75)
 def VVEpVi(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFSAou(self, BF(self.VVbhYm, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VVE4Q9(self):
  filterObj = CCfZNJ(self)
  filterObj.VVoTGH(self.VVXyc0)
 def VVXyc0(self, item):
  self.VVbhYm(self.VV3H75, item)
 def VVs1WE(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFQ9UD(self.refCode)        : return False
  return True
 def VVbhYm(self, mode, VVi1Tz):
  FFZmix(self, BF(self.VVJXKN, mode, VVi1Tz), title="Searching ...")
 def VVJXKN(self, mode, VVi1Tz):
  if VVi1Tz:
   VVi1Tz = VVi1Tz.strip()
  if VVi1Tz:
   self.findTxt = VVi1Tz
   CFG.lastFindContextFind.setValue(VVi1Tz)
   if   mode == self.VVPcym  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VV5Czu : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVi1Tz)
   if len(title) > 55:
    title = title[:55] + ".."
   VVbdQX = self.VVQtRz(VVi1Tz, servTypes)
   if self.isFindMode or mode == self.VV3H75:
    VVbdQX += self.VV7hVr(VVi1Tz)
   if VVbdQX:
    VVbdQX.sort(key=lambda x: x[0].lower())
    VVxRQ7 = self.VVBrgz
    VVhqvZ  = ("Zap"   , self.VVs67M    , [])
    VVgAHl = ("Current Service", self.VVOjPX , [])
    VVUZua = ("Options"  , self.VVcjIZ , [])
    VVDAgH = (""    , self.VVkAfb , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VV28Ef  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFMPky(self, None, title=title, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VVhqvZ=VVhqvZ, VVxRQ7=VVxRQ7, VVgAHl=VVgAHl, VVUZua=VVUZua, VVDAgH=VVDAgH, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVEpVi(self.VVad7e())
    FF5VuW(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVQtRz(self, VVi1Tz, servTypes):
  VVL1iO = CCFb9t.VVAwcV(servTypes)
  VVbdQX = []
  if VVL1iO:
   VVyF1f, VVU8J6 = FFhcDs()
   tp = CChwwz()
   words, asPrefix = CCfZNJ.VVGe34(VVi1Tz)
   colorYellow  = CCFzcP.VVbZ7V(VVrhVl)
   colorWhite  = CCFzcP.VVbZ7V(VVGCti)
   for s in VVL1iO:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFYM1A(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVyF1f:
        STYPE = VVU8J6[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVuPu7(refCode)
       if not "-S" in syst:
        sat = syst
       VVbdQX.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVbdQX
 def VV7hVr(self, VVi1Tz):
  VVi1Tz = VVi1Tz.lower()
  VVbdQX = []
  colorYellow  = CCFzcP.VVbZ7V(VVrhVl)
  colorWhite  = CCFzcP.VVbZ7V(VVGCti)
  for b in CC3Jx1.VVT1MA():
   VV2B8y  = b[0]
   VVDbVE  = b[1].toString()
   VVcesp = eServiceReference(VVDbVE)
   VVlw3z = FFsJR6(VVcesp)
   for service in VVlw3z:
    refCode  = service[0]
    if FFQ9UD(refCode):
     servName = service[1]
     if VVi1Tz in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVi1Tz), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVbdQX.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVbdQX
 def VVad7e(self):
  VVGXkF = InfoBar.instance
  if VVGXkF:
   VVZe0z = VVGXkF.servicelist
   if VVZe0z:
    return VVZe0z.mode == 1
  return self.VV3H75
 def VVBrgz(self, VVoyO8):
  self.close()
  VVoyO8.cancel()
 def VVs67M(self, VVoyO8, title, txt, colList):
  FFI9Ee(VVoyO8, colList[2], VVtcz9=False, checkParentalControl=True)
 def VVOjPX(self, VVoyO8, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(VVoyO8)
  if refCode:
   VVoyO8.VVawt3(2, FFQWno(refCode, iptvRef, chName), True)
 def VVcjIZ(self, VVoyO8, title, txt, colList):
  servName = colList[0]
  mSel = CCvNaQ(self, VVoyO8)
  VVMYdC, cbFncDict = CCFb9t.VV4Vo2(self, VVoyO8, servName, 2)
  mSel.VVUtfc(VVMYdC, cbFncDict)
 def VVkAfb(self, VVoyO8, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFfM6H(self, fncMode=CChafy.VVF32o, refCode=refCode, chName=chName, text=txt)
 def VVo6Wy(self):
  FFlOO5(self, self.VVQLdw, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVQLdw(self):
  ret = FFR0a2(self.refCode, True)
  if ret:
   self.VV1PVF()
   self.close()
  else:
   FFAcfo(self, "Cannot change state" , 1000)
 def VV1PVF(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVkjXu()
  except:
   self.VVMsFx()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFQaed(self, serviceRef)
 def VVkjXu(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVGXkF = InfoBar.instance
   if VVGXkF:
    VVZe0z = VVGXkF.servicelist
    if VVZe0z:
     hList = VVZe0z.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVZe0z.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVZe0z.history  = newList
       VVZe0z.history_pos = pos
 def VVMsFx(self):
  VVGXkF = InfoBar.instance
  if VVGXkF:
   VVZe0z = VVGXkF.servicelist
   if VVZe0z:
    VVZe0z.history  = []
    VVZe0z.history_pos = 0
 def VVADyo(self):
  VVGXkF = InfoBar.instance
  VVbdQX = []
  if VVGXkF:
   VVZe0z = VVGXkF.servicelist
   if VVZe0z:
    VVyF1f, VVU8J6 = FFhcDs()
    for serv in VVZe0z.history:
     refCode = serv[-1].toString()
     chName = FFJ0rg(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FFQ9UD(refCode)
     if   isIptv or isLocal : sat = "-"
     else     : sat = FFYM1A(refCode, True)
     if isIptv : STYPE = "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVyF1f:
       STYPE = VVU8J6[sTypeInt]
     VVbdQX.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVbdQX:
   VVhqvZ  = ("Zap"   , self.VVJeyQ   , [])
   VVUZua = ("Clear History" , self.VViA6X   , [])
   VVDAgH = (""    , self.VVlV9b , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VV28Ef  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFMPky(self, None, title=title, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=28, VVhqvZ=VVhqvZ, VVUZua=VVUZua, VVDAgH=VVDAgH)
  else:
   FF5VuW(self, "Not found", title=title)
 def VVJeyQ(self, VVoyO8, title, txt, colList):
  FFI9Ee(VVoyO8, colList[3], VVtcz9=False, checkParentalControl=True)
 def VViA6X(self, VVoyO8, title, txt, colList):
  FFlOO5(self, BF(self.VVeGHE, VVoyO8), "Clear Zap History ?")
 def VVeGHE(self, VVoyO8):
  self.VVMsFx()
  VVoyO8.cancel()
 def VVlV9b(self, VVoyO8, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFfM6H(self, fncMode=CChafy.VVPUuq, refCode=refCode, chName=chName, text=txt)
class CC2wnB(Screen):
 VVnpCj   = 0
 VVLzGl  = 1
 VV3zak  = 2
 VVhWYF  = 3
 VV9e7X  = 4
 VVpmn1  = 5
 VVaksZ  = 6
 VVCCRi  = 7
 VVhNXg = 8
 VVb8tr = 9
 VVMcfu = 10
 VVwd3i = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFTWzO(VVrWSS, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FF0Q0u(self, self.Title)
  FF970D(self["keyRed"] , "OK = Zap")
  FF970D(self["keyGreen"] , "Current Service")
  FF970D(self["keyYellow"], "Page Options")
  FF970D(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CC2wnB.VV6OCP()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVL1iO    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVQSgG     ,
   "green"   : self.VV6Zjr    ,
   "yellow"  : self.VVB9G3     ,
   "blue"   : self.VVm7YC     ,
   "menu"   : self.VVCYJt     ,
   "info"   : self.VVoDKK    ,
   "up"   : self.VVMgQm       ,
   "down"   : self.VVcAI8      ,
   "left"   : self.VVvyya      ,
   "right"   : self.VVF1i7      ,
   "pageUp"  : BF(self.VVI8Ow, True) ,
   "chanUp"  : BF(self.VVI8Ow, True) ,
   "pageDown"  : BF(self.VVI8Ow, False) ,
   "chanDown"  : BF(self.VVI8Ow, False) ,
   "next"   : self.VVVrpS     ,
   "last"   : self.VVk7uS      ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FFKT7W(self)
  FFyHsQ(self)
  FFaCb6(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
    self["myPosterLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFZmix(self, BF(self.VVDujG, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVCYJt(self):
  if not self.isBusy:
   VVMYdC = []
   VVMYdC.append(("Statistics"           , "VVUCqY"    ))
   VVMYdC.append(VVc27s)
   VVMYdC.append(("Suggest PIcons for Current Channel"     , "VVDdJS"   ))
   VVMYdC.append(("Set to Current Channel (copy file)"     , "VVrd1R_file"  ))
   VVMYdC.append(("Set to Current Channel (as SymLink)"     , "VVrd1R_link"  ))
   VVMYdC.append(VVc27s)
   VVMYdC.append(("Export Current File Names List"      , "VVV8eB" ))
   VVMYdC.append(CC2wnB.VV73ej())
   VVMYdC.append(VVc27s)
   movTxt = "Move Unused PIcons to a Directory"
   delTxt = "DELETE Unused PIcons"
   if self.filterTitle == "PIcons without Channels":
    c = VV8DG7
    VVMYdC.append((c + movTxt           , "VVYQur"  ))
    VVMYdC.append((c + delTxt           , "VVGd3j" ))
   else:
    disTxt = " (Filter >> Unused PIcons)"
    VVMYdC.append((movTxt + disTxt         ,       ))
    VVMYdC.append((delTxt + disTxt         ,       ))
   VVMYdC.append(VVc27s)
   VVMYdC.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVUA7G"  ))
   VVMYdC.append(VVc27s)
   VVMYdC += CC2wnB.VVpF1T()
   VVMYdC.append(VVc27s)
   VVMYdC.append(("Change Poster/Picon Transparency Color"    , "VVaa57"  ))
   VVMYdC.append(("Keys Help"           , "VVXrlh"    ))
   FFcKE0(self, self.VVV5qI, width=1100, height=1050, title=self.Title, VVMYdC=VVMYdC)
 def VVV5qI(self, item=None):
  if item is not None:
   if   item == "VVUCqY"     : self.VVUCqY()
   elif item == "VVDdJS"    : self.VVDdJS()
   elif item == "VVrd1R_file"   : self.VVrd1R(0)
   elif item == "VVrd1R_link"   : self.VVrd1R(1)
   elif item == "VVV8eB"   : self.VVV8eB()
   elif item == "VV7tbL"   : CC2wnB.VV7tbL(self)
   elif item == "VVYQur"    : self.VVYQur()
   elif item == "VVGd3j"   : self.VVGd3j()
   elif item == "VVUA7G"   : self.VVUA7G()
   elif item == "VVdcHQ"   : CC2wnB.VVdcHQ(self)
   elif item == "findPiconBrokenSymLinks"  : CC2wnB.VVBSOH(self, True)
   elif item == "FindAllBrokenSymLinks"  : CC2wnB.VVBSOH(self, False)
   elif item == "VVaa57"   : self.VVaa57()
   elif item == "VVXrlh"      : self.VVXrlh()
 def VVB9G3(self):
  if not self.isBusy:
   VVMYdC = []
   VVMYdC.append(("Go to First PIcon"  , "VV4I3e"  ))
   VVMYdC.append(("Go to Last PIcon"   , "VV1fCn"  ))
   VVMYdC.append(VVc27s)
   VVMYdC.append(("Sort by Channel Name"     , "sortByChan" ))
   VVMYdC.append(("Sort by File Name"  , "sortByFile" ))
   VVMYdC.append(VVc27s)
   VVMYdC.append(("Find from File List .." , "VVhH67" ))
   FFcKE0(self, self.VVXj7S, title=self.Title, VVMYdC=VVMYdC)
 def VVXj7S(self, item=None):
  if item is not None:
   if   item == "VV4I3e"   : self.VV4I3e()
   elif item == "VV1fCn"   : self.VV1fCn()
   elif item == "sortByChan"  : self.VVTwWR(2)
   elif item == "sortByFile"  : self.VVTwWR(0)
   elif item == "VVhH67"  : self.VVhH67()
 def VVaa57(self):
  fg = bg = CFG.transpColorPicons.getValue()
  self.session.openWithCallback(self.VVqcU4, CC3Y09, defFG=fg, defBG=bg, onlyBG=True)
 def VVqcU4(self, fg, bg):
  if bg:
   FF72vQ(CFG.transpColorPicons, bg)
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FFaCb6(self["myPosterRep%d%d" % (row, col)], bg)
 def VVXrlh(self):
  FFqh4M(self, VVlId3 + "_help_picons", "PIcons Tools (Keys Help)")
 def VVMgQm(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VV1fCn()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVdLOq()
 def VVcAI8(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV4I3e()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVdLOq()
 def VVvyya(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VV1fCn()
  else:
   self.curCol -= 1
   self.VVdLOq()
 def VVF1i7(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VV4I3e()
  else:
   self.curCol += 1
   self.VVdLOq()
 def VVk7uS(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVdLOq(True)
 def VVVrpS(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVdLOq(True)
 def VV4I3e(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVdLOq(True)
 def VV1fCn(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVdLOq(True)
 def VVhH67(self):
  VVMYdC = []
  for item in self.VVL1iO:
   VVMYdC.append((item[0], item[0]))
  FFcKE0(self, self.VVmeDw, title='PIcons ".png" Files', VVMYdC=VVMYdC, VVglYk=True)
 def VVmeDw(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVId8h(ndx)
 def VVQSgG(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VV4C9a()
   if refCode:
    FFI9Ee(self, refCode)
    self.VVwOV4()
    self.VVfkuR()
 def VVI8Ow(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVwOV4()
   self.VVfkuR()
  except:
   pass
 def VV6Zjr(self):
  if self["keyGreen"].getVisible():
   self.VVId8h(self.curChanIndex)
 def VVId8h(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVdLOq(True)
  else:
   FFAcfo(self, "Not found", 1000)
 def VVTwWR(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFZmix(self, BF(self.VVDujG, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVrd1R(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VV4C9a()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVMYdC = []
     VVMYdC.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVMYdC.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFcKE0(self, BF(self.VVor9U, mode, curChF, selPiconF), VVMYdC=VVMYdC, title="Current Channel PIcon (already exists)")
    else:
     self.VVor9U(mode, curChF, selPiconF, "overwrite")
   else:
    FFu1fZ(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFu1fZ(self, "Could not read current channel info. !", title=title)
 def VVor9U(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFZmix(self, BF(self.VVDujG, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVYQur(self):
  defDir = FF5sxC(CC2wnB.VV6OCP() + "picons_backup")
  os.system(FFVKmy("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(BF(self.VVzKqm, defDir), BF(CC5DZc
         , mode=CC5DZc.VVi95q, VVYwJg=CC2wnB.VV6OCP()))
 def VVzKqm(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CC2wnB.VV6OCP():
    FFu1fZ(self, "Cannot move to same directory !", title=title)
   else:
    if not FF5sxC(path) == FF5sxC(defDir):
     self.VVhqza(defDir)
    FFlOO5(self, BF(FFZmix, self, BF(self.VVfKA8, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVL1iO), path), title=title)
  else:
   self.VVhqza(defDir)
 def VVfKA8(self, title, defDir, toPath):
  if not iMove:
   self.VVhqza(defDir)
   FFu1fZ(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FF5sxC(toPath)
  pPath = CC2wnB.VV6OCP()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVL1iO:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVL1iO)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FF4gok(self, txt, title=title, VVjLdB="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVftcm("all")
 def VVhqza(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVGd3j(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVL1iO)
  FFlOO5(self, BF(FFZmix, self, BF(self.VVpCWk, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FFmxIl(tot)), title=title)
 def VVpCWk(self, title):
  pPath = CC2wnB.VV6OCP()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVL1iO:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVL1iO)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFXe6i(str(totErr), VVwtwf)
  FF4gok(self, txt, title=title)
 def VVUA7G(self):
  lines = FFEUax("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FFlOO5(self, BF(self.VVR5EJ, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FFmxIl(tot)), VV6ttc=True)
  else:
   FF5VuW(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVR5EJ(self, fList):
  os.system(FFVKmy("find -L '%s' -type l -delete" % self.pPath))
  FF5VuW(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVoDKK(self):
  FFZmix(self, self.VV9z27)
 def VV9z27(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VV4C9a()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFXe6i("PIcon Directory:\n", VVhW2e)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FF60Iv(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FF60Iv(path)
   txt += FFXe6i("PIcon File:\n", VVhW2e)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FFXe6i("Found %d SymLink%s to this file from:\n" % (tot, FFmxIl(tot)), VVhW2e)
     for fPath in slLst:
      txt += "  %s\n" % FFXe6i(fPath, VVycQx)
     txt += "\n"
   if chName:
    txt += FFXe6i("Channel:\n", VVhW2e)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFXe6i(chName, VVhAfh)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FFXe6i("Remarks:\n", VVhW2e)
    txt += "  %s\n" % FFXe6i("Unused", VVwtwf)
  else:
   txt = "No info found"
  FFfM6H(self, fncMode=CChafy.VV7aH7, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VV4C9a(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVL1iO[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFtFKL(sat)
  return fName, refCode, chName, sat, inDB
 def VVwOV4(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVL1iO):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVfkuR(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VV4C9a()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFXe6i("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVhW2e))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VV4C9a()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFXe6i(self.curChanName, VVrhVl)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVUCqY(self):
  VVyF1f, VVU8J6 = FFhcDs()
  sTypeNameDict = {}
  for key, val in VVU8J6.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVL1iO:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VVU8J6: sTypeDict[VVU8J6[stNum]] = sTypeDict.get(VVU8J6[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFY14S("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVbdQX = []
  c = "#b#11003333#"
  VVbdQX.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalPIcons, totUsedFiles + totUsedLinks)))
  VVbdQX.append((c + "Files" , "%d\tUsed = %s" % (self.totalPIcons - totSymLinks, totUsedFiles)))
  VVbdQX.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVbdQX.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVbdQX.append((c + "Not In Database (lamedb)" , str(self.totalPIcons - totInDB)))
  VVbdQX.append((c + "Satellites"    , str(len(self.nsList))))
  VVbdQX.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVbdQX.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVbdQX.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVbdQX.extend(sTypeRows)
  FFMPky(self, None, title=self.Title, VVL1iO=VVbdQX, VVJfxh=28, VVaZj9="#00003333", VVBGyD="#00222222")
 def VVV8eB(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FF5sxC(CFG.exportedTablesPath.getValue()), txt, FFcOP9())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVL1iO:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FF5VuW(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVm7YC(self):
  if not self.isBusy:
   VVMYdC = []
   VVMYdC.append(("All"         , "all"   ))
   VVMYdC.append(VVc27s)
   VVMYdC.append(("Used by Channels"      , "used"  ))
   VVMYdC.append(("Unused PIcons"      , "unused"  ))
   VVMYdC.append(("IPTV PIcons"       , "iptv"  ))
   VVMYdC.append(VVc27s)
   VVMYdC.append(("PIcons Files"       , "pFiles"  ))
   VVMYdC.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVMYdC.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVMYdC.append(("By Files Date ..."     , "pDate"  ))
   VVMYdC.append(("By Service Type ..."     , "servType" ))
   if self.nsList:
    VVMYdC.append(FFYdlI("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFGSRq(val)
      VVMYdC.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCfZNJ(self)
   filterObj.VVj0C9(VVMYdC, self.nsList, self.VV9UU6)
 def VV9UU6(self, item=None):
  if item is not None:
   self.VVftcm(item)
 def VVftcm(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVnpCj   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVLzGl   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VV3zak  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVaksZ   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVhWYF  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VV9e7X  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVpmn1  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VVMcfu , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVwd3i , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVCCRi   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVhNXg , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVpmn1:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFEUax("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFUGmb(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFAcfo(self, "Not found", 1000)
     return
   elif mode == self.VVMcfu:
    self.VVm8ZX(mode)
    return
   elif mode == self.VVwd3i:
    self.VVgMNw(mode)
    return
   elif mode == self.VVb8tr:
    return
   else:
    words, asPrefix = CCfZNJ.VVGe34(words)
   if not words and mode in (self.VVCCRi, self.VVhNXg):
    FFAcfo(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFZmix(self, BF(self.VVDujG, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVm8ZX(self, mode):
  VVMYdC = []
  VVMYdC.append(("Today"   , "today" ))
  VVMYdC.append(("Since Yesterday" , "yest" ))
  VVMYdC.append(("Since 7 days"  , "week" ))
  FFcKE0(self, BF(self.VV6ds3, mode), VVMYdC=VVMYdC, title="Filter by Added/Modified Date")
 def VV6ds3(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFeqiy(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFeqiy(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFeqiy(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FFZmix(self, BF(self.VVDujG, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVgMNw(self, mode):
  VVyF1f, VVU8J6 = FFhcDs()
  lst = set()
  for key, val in VVU8J6.items():
   lst.add(val)
  VVMYdC = []
  for item in lst:
   VVMYdC.append((item, item))
  VVMYdC.sort(key=lambda x: x[0])
  FFcKE0(self, BF(self.VVh5IB, mode), VVMYdC=VVMYdC, title="Filter by Service Type")
 def VVh5IB(self, mode, item=None):
  if item:
   VVyF1f, VVU8J6 = FFhcDs()
   sTypeList = []
   for key, val in VVU8J6.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FFZmix(self, BF(self.VVDujG, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVDdJS(self):
  self.session.open(CC54zA, barTheme=CC54zA.VVlVsr
      , titlePrefix = ""
      , fncToRun  = self.VVpO7p
      , VV2r3B = self.VVRWhD)
 def VVpO7p(self, VVeDSa):
  VV5OsR, err = CCFb9t.VVmPx6(self, CCFb9t.VVbejM, VVit1y=False, VVldMD=False)
  files = []
  words = []
  if not VVeDSa or VVeDSa.isCancelled:
   return
  VVeDSa.VVinQh = []
  VVeDSa.VVvPX7(len(VV5OsR))
  if VV5OsR:
   VVAP1F = CCfLea()
   curCh = VVAP1F.VVYsaO(self.curChanName)
   for refCode in VV5OsR:
    if not VVeDSa or VVeDSa.isCancelled:
     return
    VVeDSa.VVs1tz(1, True)
    chName, sat, inDB = VV5OsR.get(refCode, ("", "", 0))
    ratio = CC2wnB.VVHfrz(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CC2wnB.VVJDPa(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFUGmb(f)
       fil = f.replace(".png", "")
       if not fil in VVeDSa.VVinQh:
        VVeDSa.VVinQh.append(fil)
 def VVRWhD(self, VVw6fk, VVinQh, threadCounter, threadTotal, threadErr):
  if VVinQh : FFZmix(self, BF(self.VVDujG, mode=self.VVb8tr, words=VVinQh), title="Loading ...")
  else   : FFAcfo(self, "Not found", 2000)
 def VVDujG(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VV8mRA(isFirstTime):
   return
  self.isBusy = True
  VVldMD = True if isFirstTime else False
  VV5OsR, err = CCFb9t.VVmPx6(self, CCFb9t.VVbejM, VVit1y=False, VVldMD=VVldMD)
  if err:
   self.close()
  iptvRefList = self.VVIJlp()
  tList = []
  for fName, fType in CC2wnB.VVa0Bw(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VV5OsR:
    if fName in VV5OsR:
     chName, sat, inDB = VV5OsR.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVnpCj:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVLzGl  and chName         : isAdd = True
   elif mode == self.VV3zak and not chName        : isAdd = True
   elif mode == self.VVhWYF  and fType == 0        : isAdd = True
   elif mode == self.VV9e7X  and fType == 1        : isAdd = True
   elif mode == self.VVpmn1  and fName in words       : isAdd = True
   elif mode == self.VVb8tr and fName in words       : isAdd = True
   elif mode == self.VVaksZ  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVCCRi  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVhNXg:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VVMcfu:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVwd3i:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVL1iO   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FFAcfo(self)
  else:
   self.isBusy = False
   FFAcfo(self, "Not found", 1000)
   return
  self.VVL1iO.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVwOV4()
  self.totalPIcons = len(self.VVL1iO)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVdLOq(True)
 def VV8mRA(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CC2wnB.VVa0Bw(self.pPath):
    if fName:
     return True
   if isFirstTime : FFu1fZ(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFAcfo(self, "Not found", 1000)
  else:
   FFu1fZ(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVIJlp(self):
  VVbdQX = {}
  files  = CC0A1M.VVGgNf()
  if files:
   for path in files:
    txt = FFQgne(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVbdQX[refCode] = item[1]
  return VVbdQX
 def VVdLOq(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVBpWj = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVBpWj: self.curPage = VVBpWj
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVYrFp()
  if self.curPage == VVBpWj:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPosterPic%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVfkuR()
  filName, refCode, chName, sat, inDB = self.VV4C9a()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVYrFp(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVL1iO[ndx]
   fName = self.VVL1iO[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFXe6i(chName, VVhAfh))
    else : lbl.setText("-")
   except:
    lbl.setText(FFXe6i(chName, VVDDRU))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVHfrz(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VV73ej():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VV7tbL"   )
 @staticmethod
 def VVpF1T():
  VVMYdC = []
  VVMYdC.append(("Find SymLinks (to PIcon Directory)"   , "VVdcHQ"   ))
  VVMYdC.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVMYdC.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVMYdC
 @staticmethod
 def VV7tbL(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(SELF)
  png, path = CC2wnB.VVSgaB(refCode)
  if path : CC2wnB.VV7Yh8(SELF, png, path)
  else : FFu1fZ(SELF, "No PIcon found for current channel in:\n\n%s" % CC2wnB.VV6OCP())
 @staticmethod
 def VVdcHQ(SELF):
  if VVrhVl:
   sed1 = FFrfWO("->", VVrhVl)
   sed2 = FFrfWO("picon", VVwtwf)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVDDRU, VVGCti)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFaGWF(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFcbot(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVBSOH(SELF, isPIcon):
  sed1 = FFrfWO("->", VVDDRU)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFrfWO("picon", VVwtwf)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFaGWF(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFcbot(), grep, sed1, sed2))
 @staticmethod
 def VVa0Bw(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VV6OCP():
  path = CFG.PIconsPath.getValue()
  return FF5sxC(path)
 @staticmethod
 def VVSgaB(refCode, chName=None):
  if FFQ9UD(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFfknX(refCode)
  allPath, fName, refCodeFile, pList = CC2wnB.VVJDPa(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VV7Yh8(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFrfWO("%s%s" % (dest, png), VVhAfh))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFrfWO(errTxt, VVpQzP))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFlXTd(SELF, cmd)
 @staticmethod
 def VVJDPa(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CC2wnB.VV6OCP()
   pList = []
   lst = FFFgxj(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FF3RM7(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFUGmb(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCpANi():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVkdeU  = None
  self.VVbAx1 = ""
  self.VVcRBz  = noService
  self.VVdIBi = 0
  self.VVlOtN  = noService
  self.VVW4F5 = 0
  self.VV1N6v  = "-"
  self.VVCtKE = 0
  self.VVTM99  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVUE4U(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVkdeU = frontEndStatus
     self.VVrdTK()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVrdTK(self):
  if self.VVkdeU:
   val = self.VVkdeU.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVbAx1 = "%3.02f dB" % (val / 100.0)
   else         : self.VVbAx1 = ""
   val = self.VVkdeU.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVdIBi = int(val)
   self.VVcRBz  = "%d%%" % val
   val = self.VVkdeU.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVW4F5 = int(val)
   self.VVlOtN  = "%d%%" % val
   val = self.VVkdeU.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VV1N6v  = "%d" % val
   val = int(val * 100 / 500)
   self.VVCtKE = min(500, val)
   val = self.VVkdeU.get("tuner_locked", 0)
   if val == 1 : self.VVTM99 = "Locked"
   else  : self.VVTM99 = "Not locked"
 def VVXNPb(self)   : return self.VVbAx1
 def VVHb2v(self)   : return self.VVcRBz
 def VVTdMT(self)  : return self.VVdIBi
 def VVhKFK(self)   : return self.VVlOtN
 def VVnxhs(self)  : return self.VVW4F5
 def VVxyNq(self)   : return self.VV1N6v
 def VVzHnH(self)  : return self.VVCtKE
 def VVWI2F(self)   : return self.VVTM99
 def VVeAtk(self) : return self.serviceName
class CChwwz():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVGcz8(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFVUlP(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVrUft(self.ORPOS  , mod=1   )
      self.sat2  = self.VVrUft(self.ORPOS  , mod=2   )
      self.freq  = self.VVrUft(self.FREQ  , mod=3   )
      self.sr   = self.VVrUft(self.SR   , mod=4   )
      self.inv  = self.VVrUft(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVrUft(self.POL  , self.D_POL )
      self.fec  = self.VVrUft(self.FEC  , self.D_FEC )
      self.syst  = self.VVrUft(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVrUft("modulation" , self.D_MOD )
       self.rolof = self.VVrUft("rolloff"  , self.D_ROLOF )
       self.pil = self.VVrUft("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVrUft("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVrUft("pls_code"  )
       self.iStId = self.VVrUft("is_id"   )
       self.t2PlId = self.VVrUft("t2mi_plp_id" )
       self.t2PId = self.VVrUft("t2mi_pid"  )
 def VVrUft(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFGSRq(val)
  elif mod == 2   : return FFwqep(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VV4Uc9(self, refCode):
  txt = ""
  self.VVGcz8(refCode)
  if self.data:
   def VV1fOZ(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VV1fOZ("System"   , self.syst)
    txt += VV1fOZ("Satellite"  , self.sat2)
    txt += VV1fOZ("Frequency"  , self.freq)
    txt += VV1fOZ("Inversion"  , self.inv)
    txt += VV1fOZ("Symbol Rate"  , self.sr)
    txt += VV1fOZ("Polarization" , self.pol)
    txt += VV1fOZ("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VV1fOZ("Modulation" , self.mod)
     txt += VV1fOZ("Roll-Off" , self.rolof)
     txt += VV1fOZ("Pilot"  , self.pil)
     txt += VV1fOZ("Input Stream", self.iStId)
     txt += VV1fOZ("T2MI PLP ID" , self.t2PlId)
     txt += VV1fOZ("T2MI PID" , self.t2PId)
     txt += VV1fOZ("PLS Mode" , self.plsMod)
     txt += VV1fOZ("PLS Code" , self.plsCod)
   else:
    txt += VV1fOZ("System"   , self.txMedia)
    txt += VV1fOZ("Frequency"  , self.freq)
  return txt, self.namespace
 def VVtp5D(self, refCode):
  txt = "Transpoder : ?"
  self.VVGcz8(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVuPu7(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFVUlP(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVrUft(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVrUft(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVrUft(self.SYST, self.D_SYS_S)
     freq = self.VVrUft(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVrUft(self.POL , self.D_POL)
      fec = self.VVrUft(self.FEC , self.D_FEC)
      sr = self.VVrUft(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVFpqU(self, refCode):
  self.data = None
  self.VVGcz8(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCV79S():
 def __init__(self, VVvtHb, path, VV2r3B=None, curRowNum=-1):
  self.VVvtHb  = VVvtHb
  self.origFile   = path
  self.Title    = "File Editor: " + FFUGmb(path)
  self.VV2r3B  = VV2r3B
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  response = os.system(FFVKmy("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVnOy2(curRowNum)
  else:
   FFu1fZ(self.VVvtHb, "Error while preparing edit!")
 def VVnOy2(self, curRowNum):
  VVbdQX = self.VVF9MU()
  VVgAHl = ("Save Changes" , self.VVgOc6   , [])
  VVhqvZ  = ("Edit Line"  , self.VVTT2L    , [])
  VVUZua = ("Go to Line Num" , self.VV8PS7   , [])
  VVR0s7 = ("Line Options" , self.VVbnj5   , [])
  VV3Q2h = (""    , self.VVQ63O , [])
  VVxRQ7 = self.VV4HSp
  VVcQZx  = self.VVdJWn
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VV28Ef  = (CENTER  , LEFT  )
  VVoyO8 = FFMPky(self.VVvtHb, None, title=self.Title, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VVgAHl=VVgAHl, VVhqvZ=VVhqvZ, VVUZua=VVUZua, VVR0s7=VVR0s7, VVxRQ7=VVxRQ7, VVcQZx=VVcQZx, VV3Q2h=VV3Q2h, VVMVWT=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
    , VVI8Pk   = "#11001111"
    , VV2s6D   = "#11001111"
    , VVjLdB   = "#11001111"
    , VVaZj9  = "#05333333"
    , VVBGyD  = "#00222222"
    , VVFIzs  = "#11331133"
    )
  VVoyO8.VVjS0j(curRowNum)
 def VV8PS7(self, VVoyO8, title, txt, colList):
  totRows = VVoyO8.VV03io()
  lineNum = VVoyO8.VVr4DQ() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FFSAou(self.VVvtHb, BF(self.VVgJ6v, VVoyO8, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VVgJ6v(self, VVoyO8, lineNum, totRows, VVO1nz):
  if VVO1nz:
   VVO1nz = VVO1nz.strip()
   if VVO1nz.isdigit():
    num = FFCk9k(int(VVO1nz) - 1, 0, totRows)
    VVoyO8.VVjS0j(num)
    self.lastLineNum = num + 1
   else:
    FFAcfo(VVoyO8, "Incorrect number", 1500)
 def VVbnj5(self, VVoyO8, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVoyO8.VVSgrB()
  VVMYdC = []
  VVMYdC.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVMYdC.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVevPf"  ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVRscb:
   VVMYdC.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(  ("Delete Line"         , "deleteLine"   ))
  FFcKE0(self.VVvtHb, BF(self.VVXF0q, VVoyO8, lineNum), VVMYdC=VVMYdC, title="Line Options")
 def VVXF0q(self, VVoyO8, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVskpA("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVoyO8)
   elif item == "VVevPf"  : self.VVevPf(VVoyO8, lineNum)
   elif item == "copyToClipboard"  : self.VVW5fw(VVoyO8, lineNum)
   elif item == "pasteFromClipboard" : self.VVXimv(VVoyO8, lineNum)
   elif item == "deleteLine"   : self.VVskpA("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVoyO8)
 def VVdJWn(self, VVoyO8):
  VVoyO8.VVTDlc()
 def VVQ63O(self, VVoyO8, title, txt, colList):
  if   self.insertMode == 1: VVoyO8.VV9Qxk()
  elif self.insertMode == 2: VVoyO8.VV9N96()
  self.insertMode = 0
 def VVevPf(self, VVoyO8, lineNum):
  if lineNum == VVoyO8.VVSgrB():
   self.insertMode = 1
   self.VVskpA("echo '' >> '%s'" % self.tmpFile, VVoyO8)
  else:
   self.insertMode = 2
   self.VVskpA("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVoyO8)
 def VVW5fw(self, VVoyO8, lineNum):
  global VVRscb
  VVRscb = FFY14S("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVoyO8.VVdbDB("Copied to clipboard")
 def VVgOc6(self, VVoyO8, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFVKmy("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFVKmy("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVoyO8.VVdbDB("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVoyO8.VVTDlc()
    else:
     FFu1fZ(self.VVvtHb, "Cannot save file!")
   else:
    FFu1fZ(self.VVvtHb, "Cannot create backup copy of original file!")
 def VV4HSp(self, VVoyO8):
  if self.fileChanged:
   FFlOO5(self.VVvtHb, BF(self.VVixuZ, VVoyO8), "Cancel changes ?")
  else:
   finalOK = os.system(FFVKmy("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVixuZ(VVoyO8)
 def VVixuZ(self, VVoyO8):
  VVoyO8.cancel()
  FF2PD3(self.tmpFile)
  if self.VV2r3B:
   self.VV2r3B(self.fileSaved)
 def VVTT2L(self, VVoyO8, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVGCti + "ORIGINAL TEXT:\n" + VVycQx + lineTxt
  FFSAou(self.VVvtHb, BF(self.VVmejM, lineNum, VVoyO8), title="File Line", defaultText=lineTxt, message=message)
 def VVmejM(self, lineNum, VVoyO8, VVO1nz):
  if not VVO1nz is None:
   if VVoyO8.VVSgrB() <= 1:
    self.VVskpA("echo %s > '%s'" % (VVO1nz, self.tmpFile), VVoyO8)
   else:
    self.VVxh8g(VVoyO8, lineNum, VVO1nz)
 def VVXimv(self, VVoyO8, lineNum):
  if lineNum == VVoyO8.VVSgrB() and VVoyO8.VVSgrB() == 1:
   self.VVskpA("echo %s >> '%s'" % (VVRscb, self.tmpFile), VVoyO8)
  else:
   self.VVxh8g(VVoyO8, lineNum, VVRscb)
 def VVxh8g(self, VVoyO8, lineNum, newTxt):
  VVoyO8.VVySY5("Saving ...")
  lines = FFgYB4(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVoyO8.VVZYmq()
  VVbdQX = self.VVF9MU()
  VVoyO8.VVKBif(VVbdQX)
 def VVskpA(self, cmd, VVoyO8):
  tCons = CCKdbR()
  tCons.ePopen(cmd, BF(self.VVfEiP, VVoyO8))
  self.fileChanged = True
  VVoyO8.VVZYmq()
 def VVfEiP(self, VVoyO8, result, retval):
  VVbdQX = self.VVF9MU()
  VVoyO8.VVKBif(VVbdQX)
 def VVF9MU(self):
  if fileExists(self.tmpFile):
   lines = FFgYB4(self.tmpFile)
   VVbdQX = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVbdQX.append((str(ndx), line.strip()))
   if not VVbdQX:
    VVbdQX.append((str(1), ""))
   return VVbdQX
  else:
   FF6iwf(self.VVvtHb, self.tmpFile)
class CCfZNJ():
 def __init__(self, callingSELF, VVI8Pk="#22003344", VV2s6D="#22002233"):
  self.callingSELF = callingSELF
  self.VVMYdC  = []
  self.satList  = []
  self.VVI8Pk  = VVI8Pk
  self.VV2s6D   = VV2s6D
 def VVoTGH(self, VV2r3B):
  self.VVMYdC = []
  VVMYdC, VVcjwH = CCfZNJ.VVg0Oq(self.callingSELF, False, True)
  if VVMYdC:
   self.VVMYdC += VVMYdC
   self.VVuVh0(VV2r3B, VVcjwH)
 def VV9AUz(self, mode, VVoyO8, satCol, VV2r3B, inFilterFnc=None):
  VVoyO8.VVySY5("Loading Filters ...")
  self.VVMYdC = []
  self.VVMYdC.append(("All Services" , "all"))
  if mode == 1:
   self.VVMYdC.append(VVc27s)
   self.VVMYdC.append(("Parental Control", "parentalControl"))
   self.VVMYdC.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVMYdC.append(VVc27s)
   self.VVMYdC.append(("Selected Transponder"   , "selectedTP" ))
   self.VVMYdC.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVIUBH(VVoyO8, satCol)
  VVMYdC, VVcjwH = CCfZNJ.VVg0Oq(self.callingSELF, True, False)
  if VVMYdC:
   VVMYdC.insert(0, FFYdlI("Custom Words"))
   self.VVMYdC += VVMYdC
  VVoyO8.VV4uR4()
  self.VVuVh0(VV2r3B, VVcjwH, inFilterFnc)
 def VVj0C9(self, VVMYdC, sats, VV2r3B, inFilterFnc=None):
  self.VVMYdC = VVMYdC
  VVMYdC, VVcjwH = CCfZNJ.VVg0Oq(self.callingSELF, True, False)
  if VVMYdC:
   self.VVMYdC.append(FFYdlI("Custom Words"))
   self.VVMYdC += VVMYdC
  self.VVuVh0(VV2r3B, VVcjwH, inFilterFnc)
 def VVuVh0(self, VV2r3B, VVcjwH, inFilterFnc=None):
  VVAfNY  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVyvO2 = ("Edit Filter"  , BF(self.VVPuvO, VVcjwH))
  VVtkPa  = ("Filter Help"  , BF(self.VVs6v3, VVcjwH))
  FFcKE0(self.callingSELF, BF(self.VVUfo3, VV2r3B), VVMYdC=self.VVMYdC, title="Select Filter", VVAfNY=VVAfNY, VVyvO2=VVyvO2, VVtkPa=VVtkPa, VVKpZE=True, VVI8Pk=self.VVI8Pk, VV2s6D=self.VV2s6D)
 def VVUfo3(self, VV2r3B, item):
  if item:
   VV2r3B(item)
 def VVPuvO(self, VVcjwH, VVVCbtObj, sel):
  if fileExists(VVcjwH) : CCV79S(self.callingSELF, VVcjwH, VV2r3B=None)
  else       : FF6iwf(self.callingSELF, VVcjwH)
  VVVCbtObj.cancel()
 def VVs6v3(self, VVcjwH, VVVCbtObj, sel):
  FFqh4M(self.callingSELF, VVlId3 + "_help_service_filter", "Service Filter")
 def VVIUBH(self, VVoyO8, satColNum):
  if not self.satList:
   satList = VVoyO8.VVfywU(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFtFKL(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FFYdlI("Satellites"))
  if self.VVMYdC:
   self.VVMYdC += self.satList
 @staticmethod
 def VVg0Oq(SELF, addTag, VVe3Eu):
  FFaSmH()
  fileName  = "ajpanel_services_filter"
  VVcjwH = VVXneu + fileName
  VVMYdC  = []
  if not fileExists(VVcjwH):
   os.system(FFVKmy("cp -f '%s' '%s'" % (VVlId3 + fileName, VVcjwH)))
  fileFound = False
  if fileExists(VVcjwH):
   fileFound = True
   lines = FFgYB4(VVcjwH)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVMYdC.append((line, "__w__" + line))
       else  : VVMYdC.append((line, line))
  if VVe3Eu:
   if   not fileFound : FF6iwf(SELF, VVcjwH)
   elif not VVMYdC : FFm1Rb(SELF, VVcjwH)
  return VVMYdC, VVcjwH
 @staticmethod
 def VVGe34(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CCvNaQ():
 def __init__(self, callingSELF, VVoyO8, addSep=True):
  self.callingSELF = callingSELF
  self.VVoyO8 = VVoyO8
  self.VVMYdC = []
  iMulSel = self.VVoyO8.VVb2bO()
  if iMulSel : self.VVMYdC.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVMYdC.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVoyO8.VVlPPo()
  self.VVMYdC.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVMYdC.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVMYdC.append(VVc27s)
 def VVUtfc(self, extraMenu, cbFncDict):
  if extraMenu:
   self.VVMYdC.extend(extraMenu)
  FFcKE0(self.callingSELF, BF(self.VVc8OC, cbFncDict), title="Options", VVMYdC=self.VVMYdC)
 def VVc8OC(self, cbFncDict, item=None):
  if item:
   if   item == "multSelEnab" : self.VVoyO8.VVRw1e(True)
   elif item == "MultSelDisab" : self.VVoyO8.VVRw1e(False)
   elif item == "selectAll" : self.VVoyO8.VVWteY()
   elif item == "unselectAll" : self.VVoyO8.VV6Sto()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
class CCFZqx(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFTWzO(VV5PZD, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF0Q0u(self)
  FF970D(self["keyRed"]  , "Exit")
  FF970D(self["keyGreen"]  , "Save")
  FF970D(self["keyYellow"] , "Refresh")
  FF970D(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV0YwQ  ,
   "green"   : self.VVrC0c ,
   "yellow"  : self.VVZFdD  ,
   "blue"   : self.VVoEE6   ,
   "up"   : self.VVMgQm    ,
   "down"   : self.VVcAI8   ,
   "left"   : self.VVvyya   ,
   "right"   : self.VVF1i7   ,
   "cancel"  : self.VV0YwQ
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VViGDa)
  self.onClose.append(self.onExit)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  self.VVZFdD()
  self.VV9xRt()
  FFyHsQ(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVpOBC)
  except:
   self.timer.callback.append(self.VVpOBC)
  self.timer.start(1000, False)
  self.VVpOBC()
 def onExit(self):
  self.timer.stop()
 def VV0YwQ(self) : self.close(True)
 def VVApkB(self) : self.close(False)
 def VVoEE6(self):
  self.session.openWithCallback(self.VVlBLR, BF(CCOzTk))
 def VVlBLR(self, closeAll):
  if closeAll:
   self.close()
 def VVpOBC(self):
  self["curTime"].setText(str(FF2ogC(iTime())))
 def VVMgQm(self):
  self.VVg88m(1)
 def VVcAI8(self):
  self.VVg88m(-1)
 def VVvyya(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VV9xRt()
 def VVF1i7(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VV9xRt()
 def VVg88m(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVVD42(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVVD42(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVVD42(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVU40j(year)):
   days += 1
  return days
 def VVU40j(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VV9xRt(self):
  for obj in self.list:
   FFaCb6(obj, "#11404040")
  FFaCb6(self.list[self.index], "#11ff8000")
 def VVZFdD(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVrC0c(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCKdbR()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVORKR)
 def VVORKR(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FF5VuW(self, "Nothing returned from the system!")
  else:
   FF5VuW(self, str(result))
class CCOzTk(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFTWzO(VVkUAl, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF0Q0u(self, addLabel=True)
  FF970D(self["keyRed"]  , "Exit")
  FF970D(self["keyGreen"]  , "Sync")
  FF970D(self["keyYellow"] , "Refresh")
  FF970D(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VV0YwQ   ,
   "green"   : self.VVDRAL  ,
   "yellow"  : self.VVMvwR ,
   "blue"   : self.VVtAdF  ,
   "cancel"  : self.VV0YwQ
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVCt4F()
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  FFyHsQ(self)
  FFC8Ey(self.refresh)
 def refresh(self):
  self.VVb8Wo()
  self.VVtkPh(False)
 def VV0YwQ(self)  : self.close(True)
 def VVtAdF(self) : self.close(False)
 def VVCt4F(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVb8Wo(self):
  self.VVahVu()
  self.VVinI6()
  self.VVs9gs()
  self.VVTCg8()
 def VVMvwR(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVCt4F()
   self.VVb8Wo()
   FFC8Ey(self.refresh)
 def VVDRAL(self):
  if len(self["keyGreen"].getText()) > 0:
   FFlOO5(self, self.VV2Kfs, "Synchronize with Internet Date/Time ?")
 def VV2Kfs(self):
  self.VVb8Wo()
  FFC8Ey(BF(self.VVtkPh, True))
 def VVahVu(self)  : self["keyRed"].show()
 def VVnZqa(self)  : self["keyGreen"].show()
 def VVS7dV(self) : self["keyYellow"].show()
 def VV2CDd(self)  : self["keyBlue"].show()
 def VVinI6(self)  : self["keyGreen"].hide()
 def VVs9gs(self) : self["keyYellow"].hide()
 def VVTCg8(self)  : self["keyBlue"].hide()
 def VVtkPh(self, sync):
  localTime = FFddDI()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VV0sGk(server)
   if epoch_time is not None:
    ntpTime = FF2ogC(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCKdbR()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VVORKR, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVS7dV()
  self.VV2CDd()
  if ok:
   self.VVnZqa()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVORKR(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVtkPh(False)
  except:
   pass
 def VV0sGk(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFPbOp():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCWlYX(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFTWzO(VVzj07, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FF0Q0u(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FFC8Ey(self.VVTj8z)
 def VVTj8z(self):
  if FFPbOp(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFaCb6(self["myBody"], color)
   FFaCb6(self["myLabel"], color)
  except:
   pass
class CC4zab(Screen):
 VVG6an = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFB0L6()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFTWzO(VVQ7RG, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CClZlw(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CClZlw(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CClZlw(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCpANi()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FF0Q0u(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close      ,
   "up"  : self.VVMgQm       ,
   "down"  : self.VVcAI8      ,
   "left"  : self.VVvyya      ,
   "right"  : self.VVF1i7      ,
   "info"  : self.VVEBSd     ,
   "epg"  : self.VVEBSd     ,
   "menu"  : self.VVXrlh      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VV5iLv, -1)  ,
   "next"  : BF(self.VV5iLv, 1)  ,
   "pageUp" : BF(self.VVFy8d, True) ,
   "chanUp" : BF(self.VVFy8d, True) ,
   "pageDown" : BF(self.VVFy8d, False) ,
   "chanDown" : BF(self.VVFy8d, False) ,
   "0"   : BF(self.VV5iLv, 0)  ,
   "1"   : BF(self.VV5MrH, pos=1) ,
   "2"   : BF(self.VV5MrH, pos=2) ,
   "3"   : BF(self.VV5MrH, pos=3) ,
   "4"   : BF(self.VV5MrH, pos=4) ,
   "5"   : BF(self.VV5MrH, pos=5) ,
   "6"   : BF(self.VV5MrH, pos=6) ,
   "7"   : BF(self.VV5MrH, pos=7) ,
   "8"   : BF(self.VV5MrH, pos=8) ,
   "9"   : BF(self.VV5MrH, pos=9) ,
  }, -1)
  self.onShown.append(self.VViGDa)
  self.onClose.append(self.onExit)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  if not CC4zab.VVG6an:
   CC4zab.VVG6an = self
  self.sliderSNR.VVqSwk()
  self.sliderAGC.VVqSwk()
  self.sliderBER.VVqSwk(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VV5MrH()
  self.VVNACm()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVigvS)
  except:
   self.timer.callback.append(self.VVigvS)
  self.timer.start(500, False)
 def VVNACm(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVUE4U(service)
  serviceName = self.tunerInfo.VVeAtk()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self)
  tp = CChwwz()
  tpTxt, satTxt = tp.VVtp5D(refCode)
  if tpTxt == "?" :
   tpTxt = FFXe6i("NO SIGNAL", VV8DG7)
  self["myTPInfo"].setText(tpTxt + "  " + FFXe6i(satTxt, VVJ6nn))
 def VVigvS(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVUE4U(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVXNPb())
   self["mySNR"].setText(self.tunerInfo.VVHb2v())
   self["myAGC"].setText(self.tunerInfo.VVhKFK())
   self["myBER"].setText(self.tunerInfo.VVxyNq())
   self.sliderSNR.VVCtqh(self.tunerInfo.VVTdMT())
   self.sliderAGC.VVCtqh(self.tunerInfo.VVnxhs())
   self.sliderBER.VVCtqh(self.tunerInfo.VVzHnH())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVCtqh(0)
   self.sliderAGC.VVCtqh(0)
   self.sliderBER.VVCtqh(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self)
    if state and not state == "Tuned":
     FFAcfo(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVEBSd(self):
  FFfM6H(self, fncMode=CChafy.VVEvyh)
 def VVXrlh(self):
  FFqh4M(self, VVlId3 + "_help_signal", "Signal Monitor (Keys)")
 def VVMgQm(self)  : self.VV5MrH(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVcAI8(self) : self.VV5MrH(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVvyya(self) : self.VV5MrH(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVF1i7(self) : self.VV5MrH(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VV5MrH(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FF72vQ(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VV5iLv(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFCk9k(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FF72vQ(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CC4zab.VVG6an = None
 def VVFy8d(self, isUp):
  FFAcfo(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVNACm()
  except:
   pass
class CClZlw(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVqSwk(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFaCb6(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVlId3 +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFaCb6(self.covObj, self.covColor)
   else:
    FFaCb6(self.covObj, "#00006688")
    self.isColormode = True
  self.VVCtqh(0)
 def VVCtqh(self, val):
  val  = FFCk9k(val, self.minN, self.maxN)
  width = int(FF8vMy(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFCk9k(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CC54zA(Screen):
 VVlVsr    = 0
 VVIWtA = 1
 VVsIjy = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VV2r3B=None, barTheme=VVlVsr):
  ratio = self.VVbtUG(barTheme)
  self.skin, self.skinParam = FFTWzO(VVzq9n, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VV2r3B = VV2r3B
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVinQh = None
  self.timer   = eTimer()
  self.myThread  = None
  FF0Q0u(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VViGDa)
  self.onClose.append(self.onExit)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  self.VVlwuy()
  self["myProgBarVal"].setText("0%")
  FFaCb6(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVUaYn()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVUaYn)
  except:
   self.timer.callback.append(self.VVUaYn)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVvPX7(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VV394z(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVinQh), self.counter, self.maxValue, catName)
 def VVqtMu(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VV46nD(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VVjNDz(self, title):
  self.newTitle = title
  try:
   self.VVUaYn()
  except:
   pass
 def VVyj21(self, txt):
  self.newTitle = txt
 def VVs1tz(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVinQh), self.counter, self.maxValue)
  except:
   pass
 def VV6FR6(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVSeXk(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VV0BdM(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFAcfo(self, "Cancelling ...")
  self.isCancelled = True
  self.VVpKB2(False)
 def VVpKB2(self, isDone):
  if self.VV2r3B:
   self.VV2r3B(isDone, self.VVinQh, self.counter, self.maxValue, self.isError)
  self.close()
 def VVUaYn(self):
  val = FFCk9k(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FF8vMy(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VVpKB2(True)
 def VVlwuy(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVIWtA, self.VVsIjy):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVbtUG(self, barTheme):
  if   barTheme == self.VVIWtA : return 0.7
  if   barTheme == self.VVsIjy : return 0.5
  else             : return 1
class CCKdbR(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VV2r3B = {}
  self.commandRunning = False
  self.VVchL9  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VV2r3B, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VV2r3B[name] = VV2r3B
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVchL9:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVVr4l, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVcCGe , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVVr4l, name))
    self.appContainers[name].appClosed.append(BF(self.VVcCGe , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVcCGe(name, retval)
  return True
 def VVVr4l(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FFXe6i("[UN-DECODED STRING]", VV8DG7))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVcCGe(self, name, retval):
  if not self.VVchL9:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VV2r3B[name]:
   self.VV2r3B[name](self.appResults[name], retval)
  del self.VV2r3B[name]
 def VV2GdB(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCvLX1(Screen):
 def __init__(self, session, title="", VVOBG5=None, VVfqvf=False, VVrAxc=False, VVQkfz=False, VV1P59=False, VVhIhd=False, VVaU0K=False, VVr1DU=VVr6rx, VVY0RJ=None, VVTij2=False, VV3BLh=None, VVHois="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFTWzO(VVZQMO, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FF0Q0u(self, addScrollLabel=True)
  if not VVHois:
   VVHois = "Processing ..."
  self["myLabel"].setText("   %s" % VVHois)
  self.VVfqvf   = VVfqvf
  self.VVrAxc   = VVrAxc
  self.VVQkfz   = VVQkfz
  self.VV1P59  = VV1P59
  self.VVhIhd = VVhIhd
  self.VVaU0K = VVaU0K
  self.VVr1DU   = VVr1DU
  self.VVY0RJ = VVY0RJ
  self.VVTij2  = VVTij2
  self.VV3BLh  = VV3BLh
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCKdbR()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FF3zTd()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVOBG5, str):
   self.VVOBG5 = [VVOBG5]
  else:
   self.VVOBG5 = VVOBG5
  if self.VVQkfz or self.VV1P59:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVn31f, VVn31f)
   self.VVOBG5.append("echo -e '\n%s\n' %s" % (restartNote, FFrfWO(restartNote, VVrhVl)))
   if self.VVQkfz:
    self.VVOBG5.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVOBG5.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVhIhd:
   FFAcfo(self, "Processing ...")
  self.onLayoutFinish.append(self.VV7Uvx)
  self.onClose.append(self.VVXFMz)
 def VV7Uvx(self):
  self["myLabel"].VVmdiX(outputFileToSave="console" if self.enableSaveRes else "")
  if self.VVfqvf:
   self["myLabel"].VVq6UY()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVM2YM()
  else:
   self.VVhbLN()
 def VVM2YM(self):
  if FFPbOp():
   self["myLabel"].setText("Processing ...")
   self.VVhbLN()
  else:
   self["myLabel"].setText(FFXe6i("\n   No connection to internet!", VVwtwf))
 def VVhbLN(self):
  allOK = self.container.ePopen(self.VVOBG5[0], self.VVIBhI, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVIBhI("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVaU0K or self.VVQkfz or self.VV1P59:
    self["myLabel"].setText(FF9bzo("STARTED", VVrhVl) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VV3BLh:
   colorWhite = CCFzcP.VVbZ7V(VVGCti)
   color  = CCFzcP.VVbZ7V(self.VV3BLh[0])
   words  = self.VV3BLh[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVr1DU=self.VVr1DU)
 def VVIBhI(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVOBG5):
   allOK = self.container.ePopen(self.VVOBG5[self.cmdNum], self.VVIBhI, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVIBhI("Cannot connect to Console!", -1)
  else:
   if self.VVhIhd and FFz45k(self):
    FFAcfo(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVaU0K:
    self["myLabel"].appendText("\n" + FF9bzo("FINISHED", VVrhVl), self.VVr1DU)
   if self.VVfqvf or self.VVrAxc:
    self["myLabel"].VVq6UY()
   if self.VVY0RJ is not None:
    self.VVY0RJ()
   if not retval and self.VVTij2:
    self.VVXFMz()
 def VVXFMz(self):
  if self.container.VV2GdB():
   self.container.killAll()
class CCm19w(Screen):
 def __init__(self, session, VVOBG5=None, VVhIhd=False):
  self.skin, self.skinParam = FFTWzO(VVZQMO, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVXneu + "ajpanel_terminal.history"
  self.customCommandsFile = VVXneu + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFY14S("pwd") or "/home/root"
  self.container   = CCKdbR()
  FF0Q0u(self, addScrollLabel=True)
  FF970D(self["keyRed"] , "Exit = Stop Command")
  FF970D(self["keyGreen"] , "OK = History")
  FF970D(self["keyYellow"], "Menu = Custom Cmds")
  FF970D(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVpln7 ,
   "cancel" : self.VVbGDY  ,
   "menu"  : self.VV1BFw ,
   "last"  : self.VVxxRY  ,
   "next"  : self.VVxxRY  ,
   "1"   : self.VVxxRY  ,
   "2"   : self.VVxxRY  ,
   "3"   : self.VVxxRY  ,
   "4"   : self.VVxxRY  ,
   "5"   : self.VVxxRY  ,
   "6"   : self.VVxxRY  ,
   "7"   : self.VVxxRY  ,
   "8"   : self.VVxxRY  ,
   "9"   : self.VVxxRY  ,
   "0"   : self.VVxxRY
  })
  self.onLayoutFinish.append(self.VViGDa)
  self.onClose.append(self.VVqC3m)
 def VViGDa(self):
  self["myLabel"].VVmdiX(isResizable=False, outputFileToSave="terminal")
  FFCE16(self["keyRed"]  , "#00ff8000")
  FFaCb6(self["keyRed"]  , self.skinParam["titleColor"])
  FFaCb6(self["keyGreen"]  , self.skinParam["titleColor"])
  FFaCb6(self["keyYellow"] , self.skinParam["titleColor"])
  FFaCb6(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVD3zU(FFY14S("date"), 5)
  result = FFY14S("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVFYUV()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVlId3 + "LinuxCommands.lst"
   newTemplate = VVlId3 + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFVKmy("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFVKmy("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVqC3m(self):
  if self.container.VV2GdB():
   self.container.killAll()
   self.VVD3zU("Process killed\n", 4)
   self.VVFYUV()
 def VVbGDY(self):
  if self.container.VV2GdB():
   self.VVqC3m()
  else:
   FFlOO5(self, self.close, "Exit ?", VVxvUW=False)
 def VVFYUV(self):
  self.VVD3zU(self.prompt, 1)
  self["keyRed"].hide()
 def VVD3zU(self, txt, mode):
  if   mode == 1 : color = VVrhVl
  elif mode == 2 : color = VVhW2e
  elif mode == 3 : color = VVGCti
  elif mode == 4 : color = VVwtwf
  elif mode == 5 : color = VVycQx
  elif mode == 6 : color = VVB3E5
  else   : color = VVGCti
  try:
   self["myLabel"].appendText(FFXe6i(txt, color))
  except:
   pass
 def VVQpRk(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVD3zU(cmd, 2)
   self.VVD3zU("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVD3zU(ch, 0)
   self.VVD3zU("\nor\n", 4)
   self.VVD3zU("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVFYUV()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFXe6i(parts[0].strip(), VVhW2e)
    right = FFXe6i("#" + parts[1].strip(), VVB3E5)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVD3zU(txt, 2)
   lastLine = self.VV6dK9()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VV47Hg(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVIBhI, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFu1fZ(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVD3zU(data, 3)
 def VVIBhI(self, data, retval):
  if not retval == 0:
   self.VVD3zU("Exit Code : %d\n" % retval, 4)
  self.VVFYUV()
 def VVpln7(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VV6dK9() == "":
   self.VV47Hg("cd /tmp")
   self.VV47Hg("ls")
  VVbdQX = []
  if fileExists(self.commandHistoryFile):
   lines  = FFgYB4(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVbdQX.append((str(c), line, str(lNum)))
   self.VVrdcE(VVbdQX, title, self.commandHistoryFile, isHistory=True)
  else:
   FF6iwf(self, self.commandHistoryFile, title=title)
 def VV6dK9(self):
  lastLine = FFY14S("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VV47Hg(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VV1BFw(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFgYB4(self.customCommandsFile)
   lastLineIsSep = False
   VVbdQX = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVbdQX.append((str(c), line, str(lNum)))
   self.VVrdcE(VVbdQX, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FF6iwf(self, self.customCommandsFile, title=title)
 def VVrdcE(self, VVbdQX, title, filePath=None, isHistory=False):
  if VVbdQX:
   VVaZj9 = "#05333333"
   if isHistory: VVI8Pk = VV2s6D = VVjLdB = "#11000020"
   else  : VVI8Pk = VV2s6D = VVjLdB = "#06002020"
   VVhqvZ   = ("Send"   , BF(self.VVz5Un, isHistory) , [])
   VVgAHl  = ("Modify & Send" , self.VV5u17     , [])
   if isHistory:
    VVUZua = ("Clear History" , self.VVYvtO     , [])
    VVR0s7 = None
   elif filePath:
    VVUZua = None
    VVR0s7 = ("Edit File"  , BF(self.VVJevx, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VV28Ef     = (CENTER  , LEFT   , CENTER )
   VVoyO8 = FFMPky(self, None, title=title, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VVhqvZ=VVhqvZ, VVgAHl=VVgAHl, VVUZua=VVUZua, VVR0s7=VVR0s7, lastFindConfigObj=CFG.lastFindTerminal, VVMVWT=True, searchCol=1
     , VVI8Pk   = VVI8Pk
     , VV2s6D   = VV2s6D
     , VVjLdB   = VVjLdB
     , VV58S5  = "#05ffff00"
     , VVaZj9  = VVaZj9
    )
   if not isHistory:
    VVoyO8.VVjS0j(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FFm1Rb(self, filePath, title=title)
 def VVz5Un(self, isHistory, VVoyO8, title, txt, colList):
  if not isHistory:
   FF72vQ(CFG.lastTerminalCustCmdLineNum, VVoyO8.VVr4DQ())
  cmd = colList[1].strip()
  VVoyO8.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVD3zU("\n%s\n" % cmd, 6)
   self.VVD3zU(self.prompt, 1)
  else:
   self.VVQpRk(cmd)
 def VV5u17(self, VVoyO8, title, txt, colList):
  cmd = colList[1]
  self.VVipzg(VVoyO8, cmd)
 def VVYvtO(self, VVoyO8, title, txt, colList):
  FFlOO5(self, BF(self.VVYQIc, VVoyO8), "Reset History File ?", title="Command History")
 def VVYQIc(self, VVoyO8):
  os.system(FFVKmy("echo '' > %s" % self.commandHistoryFile))
  VVoyO8.cancel()
 def VVJevx(self, filePath, VVoyO8, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCV79S(self, filePath, VV2r3B=BF(self.VVUgCO, VVoyO8), curRowNum=rowNum)
  else     : FF6iwf(self, filePath)
 def VVUgCO(self, VVoyO8, fileChanged):
  if fileChanged:
   VVoyO8.cancel()
   FFC8Ey(self.VV1BFw)
 def VVxxRY(self):
  self.VVipzg(None, self.lastCommand)
 def VVipzg(self, VVoyO8, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFSAou(self, BF(self.VVXk94, VVoyO8), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVXk94(self, VVoyO8, cmd):
  if cmd and len(cmd) > 0:
   self.VVQpRk(cmd)
   if VVoyO8:
    VVoyO8.cancel()
class CCdySx(Screen):
 def __init__(self, session, title="", message="", VVr1DU=VVr6rx, width=1400, height=800, VVh63k=False, VVjLdB=None, VVJfxh=30, outputFileToSave=""):
  self.skin, self.skinParam = FFTWzO(VVZQMO, width, height, 50, 30, 20, "#22002020", "#22001122", VVJfxh)
  self.session   = session
  FF0Q0u(self, title, addScrollLabel=True)
  self.VVr1DU   = VVr1DU
  self.VVh63k   = VVh63k
  self.VVjLdB   = VVjLdB
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  self["myLabel"].VVmdiX(VVh63k=self.VVh63k, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVr1DU)
  if self.VVjLdB:
   FFaCb6(self["myBody"], self.VVjLdB)
   FFaCb6(self["myLabel"], self.VVjLdB)
   FFuFCB(self["myLabel"], self.VVjLdB)
  self["myLabel"].VVq6UY()
class CC9Izs(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFTWzO(VVAPDu, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FF0Q0u(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FFwUhu(self["errPic"], "err")
class CCAUKk(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFTWzO(VVVqvs, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FF0Q0u(self, " ", addCloser=True)
class CCfA4C():
 def __init__(self, session, txt, timeout=1500):
  self.win = session.instantiateDialog(CCAUKk, txt, 24)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  FFjTr6(self.win["myWinTitle"], "#440000", 2)
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV6u62)
  except:
   self.timer.callback.append(self.VV6u62)
  self.timer.start(timeout, True)
 def VV6u62(self):
  self.session.deleteDialog(self.win)
class CC0kPO():
 VVLiB1    = 0
 VVUPiw  = 1
 VVzYBm   = ""
 VVJogP    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVoyO8   = None
  self.timer     = eTimer()
  self.VVkwQO   = 0
  self.VV4Ypc  = 1
  self.VVgnO7  = 2
  self.VVPNWO   = 3
  self.VVgIyX   = 4
  VVbdQX = self.VV51Nf()
  if VVbdQX:
   self.VVoyO8 = self.VVSjJ6(VVbdQX)
  if not VVbdQX and mode == self.VVLiB1:
   self.VVGEG2("Download list is empty !")
   self.cancel()
  if mode == self.VVUPiw:
   FFZmix(self.VVoyO8 or self.SELF, BF(self.VVCsLx, startDnld, decodedUrl), title="Checking Server ...")
  self.VVOcUM(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVOcUM)
  except:
   self.timer.callback.append(self.VVOcUM)
  self.timer.start(1000, False)
 def VVSjJ6(self, VVbdQX):
  VVbdQX.sort(key=lambda x: int(x[0]))
  VVxRQ7 = self.VVheR4
  VVhqvZ  = ("Play"  , self.VVvzix , [])
  VVDAgH = (""   , self.VV4bLC  , [])
  VV1mml = ("Stop"  , self.VV4ICA  , [])
  VVgAHl = ("Resume"  , self.VVOAdp , [])
  VVUZua = ("Options" , self.VVCYJt  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VV28Ef  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFMPky(self.SELF, None, title=self.Title, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VVhqvZ=VVhqvZ, VVDAgH=VVDAgH, VVxRQ7=VVxRQ7, VV1mml=VV1mml, VVgAHl=VVgAHl, VVUZua=VVUZua, lastFindConfigObj=CFG.lastFindIptv, VVI8Pk="#11220022", VV2s6D="#11110011", VVjLdB="#11110011", VV58S5="#00ffff00", VVaZj9="#00223025", VVBGyD="#0a333333", VVFIzs="#0a400040", VVMVWT=True, searchCol=1)
 def VV51Nf(self):
  lines = CC0kPO.VVF3U6()
  VVbdQX = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VV1mi8(decodedUrl)
      if fName:
       if   FFBuQd(decodedUrl) : sType = "Movie"
       elif FFAQER(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVYfvI(decodedUrl, fName)
       if size > -1: sizeTxt = CC5DZc.VVmkPo(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVbdQX.append((str(len(VVbdQX) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVbdQX
 def VVFfaF(self):
  VVbdQX = self.VV51Nf()
  if VVbdQX:
   if self.VVoyO8 : self.VVoyO8.VVKBif(VVbdQX, VVCt4FMsg=False)
   else     : self.VVoyO8 = self.VVSjJ6(VVbdQX)
  else:
   self.cancel()
 def VVOcUM(self, force=False):
  if self.VVoyO8:
   thrListUrls = self.VVVD0M()
   VVbdQX = []
   changed = False
   for ndx, row in enumerate(self.VVoyO8.VVVGfF()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVkwQO
    if m3u8Log:
     percent = CC0kPO.VVo1Ex(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVPNWO , "%.2f %%" % percent
      else   : flag, progr = self.VVgIyX , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFehaw(mPath)
     if curSize > -1:
      fSize = CC5DZc.VVmkPo(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CC5DZc.VVmkPo(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFehaw(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVPNWO , "%.2f %%" % percent
       else   : flag, progr = self.VVgIyX , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CC5DZc.VVmkPo(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VVgnO7
     if m3u8Log :
      if not speed and not force : flag = self.VV4Ypc
      elif curSize == -1   : self.VVwUI7(False)
    elif flag == self.VVkwQO  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVkwQO  : color2 = "#f#00555555#"
    elif flag == self.VV4Ypc : color2 = "#f#0000FFFF#"
    elif flag == self.VVgnO7 : color2 = "#f#0000FFFF#"
    elif flag == self.VVPNWO  : color2 = "#f#00FF8000#"
    elif flag == self.VVgIyX  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVATW1(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVbdQX.append(row)
   if changed or force:
    self.VVoyO8.VVKBif(VVbdQX, VVCt4FMsg=False)
 def VVATW1(self, flag):
  tDict = self.VVgDES()
  return tDict.get(flag, "?")
 def VV1piF(self, state):
  for flag, txt in self.VVgDES().items():
   if txt == state:
    return flag
  return -1
 def VVgDES(self):
  return { self.VVkwQO: "Not started", self.VV4Ypc: "Connecting", self.VVgnO7: "Downloading", self.VVPNWO: "Stopped", self.VVgIyX: "Completed" }
 def VVpZbi(self, title):
  colList = self.VVoyO8.VV3wWK()
  path = colList[6]
  url  = colList[8]
  if self.VVByzJ() : self.VVGEG2("Cannot delete !\n\nFile is downloading.")
  else      : FFlOO5(self.SELF, BF(self.VVBFUS, path, url), "Delete ?\n\n%s" % path, title=title)
 def VVBFUS(self, path, url):
  m3u8Log = self.VVoyO8.VV3wWK()[12]
  if m3u8Log : os.system(FFVKmy("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFVKmy("rm -r '%s'" % path))
  self.VVN6B5(False)
  self.VVFfaF()
 def VVN6B5(self, VVe3Eu=True):
  if self.VVByzJ():
   FFAcfo(self.VVoyO8, self.VVATW1(self.VVgnO7), 500)
  else:
   colList  = self.VVoyO8.VV3wWK()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VV1piF(state) in (self.VVkwQO, self.VVgIyX, self.VVPNWO):
    lines = CC0kPO.VVF3U6()
    newLines = []
    found = False
    for line in lines:
     if CC0kPO.VVnfN2(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVF2Qd(newLines)
     self.VVFfaF()
     FFAcfo(self.VVoyO8, "Removed.", 1000)
    else:
     FFAcfo(self.VVoyO8, "Not found.", 1000)
   elif VVe3Eu:
    self.VVGEG2("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VV2olr(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFlOO5(self.SELF, BF(self.VV5Phx, flag), ques, title=title)
 def VV5Phx(self, flag):
  list = []
  for ndx, row in enumerate(self.VVoyO8.VVVGfF()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VV1piF(state)
   if   flag == flagVal == self.VVgIyX: list.append(decodedUrl)
   elif flag == flagVal == self.VVkwQO : list.append(decodedUrl)
  lines = CC0kPO.VVF3U6()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVF2Qd(newLines)
   self.VVFfaF()
   FFAcfo(self.VVoyO8, "%d removed." % totRem, 1000)
  else:
   FFAcfo(self.VVoyO8, "Not found.", 1000)
 def VVjeDf(self):
  colList  = self.VVoyO8.VV3wWK()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFAcfo(self.VVoyO8, "Poster exists", 1500)
  else    : FFZmix(self.VVoyO8, BF(self.VVzX0c, decodedUrl, path, png), title="Checking Server ...")
 def VVzX0c(self, decodedUrl, path, png):
  err = self.VV1Ecp(decodedUrl, path, png)
  if err:
   FFu1fZ(self.SELF, err, title="Poster Download")
 def VV1Ecp(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCMCGp.VVReMj(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CC0A1M.VVpVfO(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CC0A1M.VVKC2S(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CC0A1M.VVcM1V(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFmy2V(pUrl, "ajpanel_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   os.system(FFVKmy("mv -f '%s' '%s'" % (tPath, png)))
   CCKf0K.VVAHGG(self.SELF, VVjDbt=png, showGrnMsg="Downloaded")
   return ""
 def VV4bLC(self, VVoyO8, title, txt, colList):
  def VV3eCd(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VV1fOZ(key, val) : return "\n%s:\n%s\n" % (FFXe6i(key, VVJ6nn), val.strip())
  heads  = self.VVoyO8.VVROug()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VV3eCd(heads[i]  , CC5DZc.VVmkPo(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VV3eCd("Downloaded" , CC5DZc.VVmkPo(int(curSize), mode=0))
   else:
    txt += VV3eCd(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VV1fOZ(heads[i], colList[i])
  FF4gok(self.SELF, txt, title=title)
 def VVvzix(self, VVoyO8, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CC5DZc.VVhhEZ(self.SELF, path)
  else    : FFAcfo(self.VVoyO8, "File not found", 1000)
 def VVheR4(self, VVoyO8):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVoyO8:
   self.VVoyO8.cancel()
  del self
 def VVCYJt(self, VVoyO8, title, txt, colList):
  c1, c2, c3 = VVwhxm, VVwtwf, VVJ6nn
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVMYdC = []
  VVMYdC.append((c1 + "Remove current row"       , "VVN6B5" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVMYdC.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVMYdC.append(VVc27s)
  VVMYdC.append((c2 + "Delete the file (and remove from list)"  , "VVpZbi"))
  VVMYdC.append(VVc27s)
  VVMYdC.append((resumeTxt + " Auto Resume"       , "VVS92O" ))
  VVMYdC.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVMYdC.append(VVc27s)
  t = "Download Movie Poster "
  if FFBuQd(decodedUrl): VVMYdC.append((c3 + "%s(from server)" % t , "VVjeDf"  ))
  else      : VVMYdC.append(("%s... Movies only" % t ,      ))
  if fileExists(path) : VVMYdC.append((c3 + "Open in File Manager" , "inFileMan,%s" % path ))
  else    : VVMYdC.append(("Open in File Manager"  ,      ))
  FFcKE0(self.SELF, BF(self.VVOGjA, VVoyO8), VVMYdC=VVMYdC, title=self.Title, VVglYk=True, width=800, VVKpZE=True, VVI8Pk="#1a001122", VV2s6D="#1a001122")
 def VVOGjA(self, VVoyO8, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVN6B5"  : self.VVN6B5()
   elif ref == "remFinished"   : self.VV2olr(self.VVgIyX, txt)
   elif ref == "remPending"   : self.VV2olr(self.VVkwQO, txt)
   elif ref == "VVpZbi" : self.VVpZbi(txt)
   elif ref == "VVjeDf"  : self.VVjeDf()
   elif ref == "VVS92O"  : FF72vQ(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FF72vQ(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CC5DZc, mode=CC5DZc.VV4RO2, jumpToFile=path)
    else    : FFAcfo(VVoyO8, "Path not found !", 1500)
 def VVCsLx(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCMCGp.VVReMj(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVGEG2("Could not get download link !\n\nTry again later.")
     return
  for line in CC0kPO.VVF3U6():
   if CC0kPO.VVnfN2(decodedUrl, line):
    if self.VVoyO8:
     self.VV14L3(decodedUrl)
     FFC8Ey(BF(FFAcfo, self.VVoyO8, "Already listed !", 2000))
    break
  else:
   params = self.VVfFNu(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVGEG2(params[0])
   elif len(params) == 2:
    FFlOO5(self.SELF, BF(self.VVNEvV, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CC5DZc.VVmkPo(fSize)
    FFlOO5(self.SELF, BF(self.VVa4pb, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVa4pb(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CC0kPO.VVms2U(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVFfaF()
  if self.VVoyO8:
   self.VVoyO8.VV9N96()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CC0kPO.VVJogP, path, decodedUrl)
   self.VVpUPn(threadName, url, decodedUrl, path, resp)
 def VV14L3(self, decodedUrl):
  if self.VVoyO8:
   for ndx, row in enumerate(self.VVoyO8.VVVGfF()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVoyO8:
     self.VVoyO8.VVjS0j(ndx)
     break
 def VVfFNu(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VV1mi8(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVYfvI(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCMCGp.VVReMj(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCMCGp.VVZaQK()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CC0kPO.VVLPzh(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CC0kPO.VVG1FR(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVNEvV(self, resp, decodedUrl):
  if not os.system(FFVKmy("which ffmpeg")) == 0:
   FFlOO5(self.SELF, BF(CC0A1M.VVtswM, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VV1mi8(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VV8G0E(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFlOO5(self.SELF, BF(self.VVu5aI, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVu5aI(rTxt, rUrl)
  else:
   self.VVGEG2("Cannot process m3u8 file !")
 def VV8G0E(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVMYdC = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CC0A1M.VVDRnn(rUrl, fPath)
   VVMYdC.append((resol, fullUrl))
  if VVMYdC:
   FFcKE0(self.SELF, self.VV9oHk, VVMYdC=VVMYdC, title="Resolution", VVglYk=True, VVKpZE=True)
  else:
   self.VVGEG2("Cannot get Resolutions list from server !")
 def VV9oHk(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFlOO5(self.SELF, BF(FFC8Ey, BF(self.VVDkKj, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFC8Ey(BF(self.VVDkKj, resolUrl))
 def VVDkKj(self, resolUrl):
  txt, err = CCMCGp.VVsdyN(resolUrl)
  if err : self.VVGEG2(err)
  else : self.VVu5aI(txt, resolUrl)
 def VVFsqm(self, logF, decodedUrl):
  found = False
  lines = CC0kPO.VVF3U6()
  with open(CC0kPO.VVms2U(), "w") as f:
   for line in lines:
    if CC0kPO.VVnfN2(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CC0kPO.VVms2U(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVFfaF()
  if self.VVoyO8:
   self.VVoyO8.VV9N96()
 def VVu5aI(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CC0A1M.VVDRnn(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVGEG2("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVFsqm(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFVKmy("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CC0kPO.VVJogP, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVo1Ex(dnldLog):
  if fileExists(dnldLog):
   dur = CC0kPO.VV43sY(dnldLog)
   if dur > -1:
    tim = CC0kPO.VVHSWV(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VV43sY(dnldLog):
  lines = FFEUax("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVHSWV(dnldLog):
  lines = FFEUax("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVYfvI(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFAQER(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFVKmy("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVpUPn(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVoyO8.VV3wWK()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VVXG46, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVXG46(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVzYBm == path:
       break
     else:
      break
  except:
   return
  if CC0kPO.VVzYBm:
   CC0kPO.VVzYBm = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFehaw(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVfFNu(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVXG46(url, decodedUrl, path, resp, totFileSize, True)
 def VV4ICA(self, VVoyO8, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVY4CP() : FFAcfo(self.VVoyO8, self.VVATW1(self.VVgIyX), 500)
  elif not self.VVByzJ() : FFAcfo(self.VVoyO8, self.VVATW1(self.VVPNWO), 500)
  elif m3u8Log      : FFlOO5(self.SELF, self.VVwUI7, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVVD0M():
    CC0kPO.VVzYBm = colList[6]
    FFAcfo(self.VVoyO8, "Stopping ...", 1000)
   else:
    FFAcfo(self.VVoyO8, "Stopped", 500)
 def VVwUI7(self, withMsg=True):
  if withMsg:
   FFAcfo(self.VVoyO8, "Stopping ...", 1000)
  os.system(FFVKmy("killall -INT ffmpeg"))
 def VVOAdp(self, *args):
  if   self.VVY4CP() : FFAcfo(self.VVoyO8, self.VVATW1(self.VVgIyX) , 500)
  elif self.VVByzJ() : FFAcfo(self.VVoyO8, self.VVATW1(self.VVgnO7), 500)
  else:
   resume = False
   m3u8Log = self.VVoyO8.VV3wWK()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFlOO5(self.SELF, BF(self.VVg4Jd, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVJIqC():
    resume = True
   if resume: FFZmix(self.VVoyO8, BF(self.VVRIpl), title="Checking Server ...")
   else  : FFAcfo(self.VVoyO8, "Cannot resume !", 500)
 def VVg4Jd(self, m3u8Log):
  os.system(FFVKmy("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFZmix(self.VVoyO8, BF(self.VVRIpl), title="Checking Server ...")
 def VVRIpl(self):
  colList  = self.VVoyO8.VV3wWK()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCMCGp.VVReMj(decodedUrl)
   if url:
    decodedUrl = self.VV7Ndq(decodedUrl, url)
   else:
    self.VVGEG2("Could not get download link !\n\nTry again later.")
    return
  curSize = FFehaw(path)
  params = self.VVfFNu(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVGEG2(params[0])
   return
  elif len(params) == 2:
   self.VVNEvV(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VV7Ndq(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CC0kPO.VVJogP, path, decodedUrl)
  if resumable: self.VVpUPn(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVGEG2("Cannot resume from server !")
 def VV1mi8(self, decodedUrl):
  fileExt = CC0A1M.VVZVmc(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FFnRfV(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVGEG2(self, txt):
  FFu1fZ(self.SELF, txt, title=self.Title)
 def VVVD0M(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CC0kPO.VVJogP, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVByzJ(self):
  decodedUrl = self.VVoyO8.VV3wWK()[9]
  return decodedUrl in self.VVVD0M()
 def VVY4CP(self):
  colList = self.VVoyO8.VV3wWK()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFehaw(path)) == size
 def VVJIqC(self):
  colList = self.VVoyO8.VV3wWK()
  path = colList[6]
  size = int(colList[7])
  curSize = FFehaw(path)
  if curSize > -1:
   size -= curSize
  err = CC0kPO.VVG1FR(size)
  if err:
   FFu1fZ(self.SELF, err, title=self.Title)
   return False
  return True
 def VVF2Qd(self, list):
  with open(CC0kPO.VVms2U(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VV7Ndq(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CC0kPO.VVF3U6()
  url = decodedUrl
  with open(CC0kPO.VVms2U(), "w") as f:
   for line in lines:
    if CC0kPO.VVnfN2(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVFfaF()
  return url
 @staticmethod
 def VVF3U6():
  list = []
  if fileExists(CC0kPO.VVms2U()):
   for line in FFgYB4(CC0kPO.VVms2U()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVnfN2(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVG1FR(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CC5DZc.VVcRWj(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CC5DZc.VVmkPo(size), CC5DZc.VVmkPo(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVisIF(SELF):
  tot = CC0kPO.VVSI1z()
  if tot:
   FFu1fZ(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVSI1z():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CC0kPO.VVJogP):
    c += 1
  return c
 @staticmethod
 def VVX0Zz():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CC0kPO.VVJogP, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVCfZp():
  return len(CC0kPO.VVF3U6()) == 0
 @staticmethod
 def VVhxEH():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVl4m6():
  mPoints = CC0kPO.VVhxEH()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFVKmy("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVms2U():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVNz38(SELF):
  CC0kPO.VVVRns(SELF, CC0kPO.VVLiB1)
 @staticmethod
 def VVh3IA(SELF):
  CC0kPO.VVVRns(SELF, CC0kPO.VVUPiw, startDnld=True)
 @staticmethod
 def VVFabq(SELF, url):
  CC0kPO.VVVRns(SELF, CC0kPO.VVUPiw, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVtBrk(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(SELF)
  added, skipped = CC0kPO.VV9UpJ([decodedUrl])
  FFAcfo(SELF, "Added", 1000)
 @staticmethod
 def VV9UpJ(list):
  added = skipped = 0
  for line in CC0kPO.VVF3U6():
   for ndx, url in enumerate(list):
    if url and CC0kPO.VVnfN2(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CC0kPO.VVms2U(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVVRns(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCf0Mb.VVMQrW(SELF):
   return
  if mode == CC0kPO.VVLiB1 and CC0kPO.VVCfZp():
   FFu1fZ(SELF, "Download list is empty !", title=title)
  else:
   inst = CC0kPO(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVLPzh(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCDmyf(Screen, CCEwD2):
 VVek82 = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, isFromExternal=False, enableDownloadMenu=True, enableOpenInFMan=True):
  self.skin, self.skinParam = FFTWzO(VVih7X, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCEwD2.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.enableOpenInFMan  = enableOpenInFMan
  self.iptvTableParams  = iptvTableParams
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FF0Q0u(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVQmjP())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVqqT1       ,
   "info"  : self.VVEBSd      ,
   "epg"  : self.VVEBSd      ,
   "menu"  : self.VVwnq0     ,
   "cancel" : self.cancel       ,
   "red"  : self.VVcTc2   ,
   "green"  : self.VVode3  ,
   "blue"  : self.VV78Hj      ,
   "yellow" : self.VVb9VF ,
   "left"  : BF(self.VVZrOq, -1)    ,
   "right"  : BF(self.VVZrOq,  1)    ,
   "play"  : self.VVX9zj      ,
   "pause"  : self.VVX9zj      ,
   "playPause" : self.VVX9zj      ,
   "stop"  : self.VVX9zj      ,
   "rewind" : self.VV5M9q      ,
   "forward" : self.VVwsD3      ,
   "rewindDm" : self.VV5M9q      ,
   "forwardDm" : self.VVwsD3      ,
   "last"  : self.VVvxjR      ,
   "next"  : self.VVZm08      ,
   "pageUp" : BF(self.VVollc, True)  ,
   "pageDown" : BF(self.VVollc, False)  ,
   "chanUp" : BF(self.VVollc, True)  ,
   "chanDown" : BF(self.VVollc, False)  ,
   "up"  : BF(self.VVollc, True)  ,
   "down"  : BF(self.VVollc, False)  ,
   "audio"  : BF(self.VVxKlU, True)  ,
   "subtitle" : BF(self.VVxKlU, False)  ,
   "text"  : self.VVtvgh  ,
   "0"   : BF(self.VVVc1D , 10)   ,
   "1"   : BF(self.VVVc1D , 1)   ,
   "2"   : BF(self.VVVc1D , 2)   ,
   "3"   : BF(self.VVVc1D , 3)   ,
   "4"   : BF(self.VVVc1D , 4)   ,
   "5"   : BF(self.VVVc1D , 5)   ,
   "6"   : BF(self.VVVc1D , 6)   ,
   "7"   : BF(self.VVVc1D , 7)   ,
   "8"   : BF(self.VVVc1D , 8)   ,
   "9"   : BF(self.VVVc1D , 9)
  }, -1)
  self.onShown.append(self.VViGDa)
  self.onClose.append(self.onExit)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FFKT7W(self)
  if not CCDmyf.VVek82:
   CCDmyf.VVek82 = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFwUhu(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFwUhu(self["myPlayRpt"], "rpt")
  self.VVJ0OQ()
  self.instance.move(ePoint(40, 40))
  self.VVMnqD(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVQ0Ki)
  except:
   self.timer.callback.append(self.VVQ0Ki)
  self.timer.start(250, False)
  self.VVQ0Ki("Checking ...")
  self.VVP384()
 def VVode3(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self)
  self.lastSubtitle = CCZZmO.VVPHP3()
  if "chCode" in iptvRef:
   if CCf0Mb.VVMQrW(self):
    self.VVP384(True)
  else:
   self.VVQ0Ki("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVJ0OQ(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVUK7n()
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VV8DG7 + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FFaCb6(self["myTitle"], tColor)
  FFaCb6(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFaCb6(self["myPlay%s" % item], tColor)
  picFile = CChafy.VVmNEw(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CChafy.VVtAo5(self)
  cl = CCA2G7.VVoo99(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VVQ0Ki(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CC0kPO.VVSI1z()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVUK7n()
  if evName:
   evName = "    %s    " % FFXe6i(evName, VVycQx)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVpbDb():
   FFCE16(self["myPlayBlu"], "#00FFFFFF")
   FFaCb6(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFCE16(self["myPlayBlu"], "#00FFFF88")
   FFaCb6(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FFaCb6(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FFCk9k(percVal, 0, 100)
   width = int(FF8vMy(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FFaCb6(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFCE16(self["myPlayMsg"], "#0000ffff")
   else  : FFCE16(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFCE16(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFCE16(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVX0kw()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VVBdqu(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CCZZmO.VVJerQ(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVvxjR()
  state = self.VVI8E8()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFCE16(self["myPlayMsg"], "#0000ff00")
  else     : FFCE16(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVUK7n(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFR3hA(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCDmyf.VVvsST(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CChafy.VVKPDn(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CChwwz()
   tpTxt, satTxt = tp.VVtp5D(refCode)
   self.satInfo_TP = tpTxt + "  " + FFXe6i(satTxt, VV2RHA)
  evName = evNameNext = ""
  evLst = CChafy.VVVr99(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFhyVK(info, iServiceInformation.sVideoWidth) or -1
   h = FFhyVK(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFhyVK(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CChafy.VVvDds(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VVvsST(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFZcBU(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFZcBU(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFZcBU(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVwnq0(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVUK7n()
  FFBuQdSeries = FFnRfV(decodedUrl)
  VVMYdC = []
  if self.isFromExternal:
   VVMYdC.append((VV2RHA + "IPTV Menu"   , "iptv" ))
   VVMYdC.append(VVc27s)
  if isIptv and not "&end=" in decodedUrl and not FFBuQdSeries:
   uType, uHost, uUser, uPass, uId, uChName = CC0A1M.VVpVfO(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVMYdC.append((VV2RHA + "Catchup Programs", "catchup" ))
    VVMYdC.append(VVc27s)
  if refCode:
   c = VV8DG7
   VVMYdC.append((c + "Stop Current Service"  , "stop"  ))
   VVMYdC.append((c + "Restart Current Service" , "restart"  ))
   VVMYdC.append(VVc27s)
  if FFBuQdSeries:
   VVMYdC.append((VV2RHA + "File Size (on server)", "fileSize" ))
   VVMYdC.append(VVc27s)
  if self.enableDownloadMenu:
   c = VV2RHA
   addSep = False
   if isIptv and FFBuQdSeries:
    VVMYdC.append((c + "Start Download"   , "dload_cur" ))
    VVMYdC.append((c + "Add to Download List"  , "addToDload" ))
    addSep = True
   if not CC0kPO.VVCfZp():
    VVMYdC.append((VV2RHA + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVMYdC.append(VVc27s)
  fPath, fDir, fName = CC5DZc.VVektX(self)
  if fPath:
   c = VV80mJ
   if self.enableOpenInFMan and not CC5DZc.VVwYMY:
    VVMYdC.append((c + "Open path in File Manager", "VVG4Db"))
   VVMYdC.append((c + "Add to Bouquet"             , "VVHF5R" ))
   VVMYdC.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVx4qY"  ))
   VVMYdC.append(VVc27s)
  if isDvb:
   VVMYdC.append((VV2RHA + "Signal Monitor", "sigMon"   ))
  if posTxt and durTxt:
   VVMYdC.append((VVJ6nn + "Start Subtitle", "VVCbch"))
   VVMYdC.append(VVc27s)
  if CFG.playerPos.getValue() : VVMYdC.append(("Move Bar to Bottom"  , "botm"    ))
  else      : VVMYdC.append(("Move Bar to Top"  , "top"     ))
  VVMYdC.append(("Help"             , "help"    ))
  FFcKE0(self, self.VViWoT, VVMYdC=VVMYdC, width=600, title="Options")
 def VViWoT(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VVb9VF()
   elif item == "stop"     : self.VVqDwJ(0)
   elif item == "restart"    : self.VVqDwJ(1)
   elif item == "fileSize"    : FFZmix(self, BF(CChafy.VVljjl, self), title="Checking Server")
   elif item == "dload_cur"   : CC0kPO.VVh3IA(self)
   elif item == "addToDload"   : CC0kPO.VVtBrk(self)
   elif item == "dload_stat"   : CC0kPO.VVNz38(self)
   elif item == "VVG4Db" : self.close("close_openInFileMan")
   elif item == "VVHF5R" : self.VVHF5R()
   elif item == "VVCbch"  : self.VVXBko()
   elif item == "VVx4qY"  : self.VVx4qY()
   elif item == "botm"     : self.VVMnqD(0)
   elif item == "top"     : self.VVMnqD(1)
   elif item == "sigMon"    : self.VVcTc2()
   elif item == "help"     : FFqh4M(self, VVlId3 + "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCDmyf.VVek82 = None
 def VVqDwJ(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVJ0OQ()
   elif typ == 1:
    self.VVQ0Ki("Restarting Service ...")
    FFC8Ey(BF(self.VVojZd, serv))
 def VVojZd(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self)
  if "&end=" in decodedUrl: BF(self.VVP384, True)
  else     : self.session.nav.playService(serv)
 def VVHF5R(self):
  fPath, fDir, fName = CC5DZc.VVektX(self)
  if fPath: picker = CC3Jx1(self, self, "Add Current Movie to a Bouquet", BF(self.VVa0rd, [fPath]))
  else : FFAcfo(self, "Path not found !", 1500)
 def VVa0rd(self, pathLst):
  return CC3Jx1.VV2Kfz(pathLst)
 def VVx4qY(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCDmyf.VVvsST(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVQ0Ki(txt, highlight=ok)
 def VVMnqD(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FF72vQ(CFG.playerPos, pos)
 def VVcTc2(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CChafy.VVKPDn(serv)
   if isDvb: self.close("close_sig")
   else : self.VVQ0Ki("No Signal for Current Service")
 def VVXBko(self):
  self.session.openWithCallback(self.VVDaSW, BF(CCZZmO))
 def VVtvgh(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVUK7n()
   if posTxt and durTxt: self.VVXBko()
   else    : self.VVQ0Ki("No duration Info. !")
 def VVDaSW(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VVollc(True)
  elif reason == "subtZapDn" : self.VVollc(False)
  elif reason == "pause"  : self.VVX9zj()
  elif reason == "audio"  : self.VVxKlU(True)
  elif reason == "subtitle" : self.VVxKlU(False)
  elif reason == "rewind"     : self.VV5M9q()
  elif reason == "forward" : self.VVwsD3()
  elif reason == "rewindDm" : self.VV5M9q()
  elif reason == "forwardDm" : self.VVwsD3()
  else      : txt = reason
  if txt:
   FFAcfo(self, txt, 2000)
 def VVqqT1(self):
  if self.isManualSeek:
   self.VV5gyA()
   self.VVBdqu(self.manualSeekPts)
  elif self.shown:
   if CCZZmO.VVoPuq(self): self.VVXBko()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VV5gyA()
  else    : self.close()
 def VVEBSd(self):
  FFfM6H(self, fncMode=CChafy.VVwn7t)
 def VVX9zj(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVQ0Ki("Toggling Play/Pause ...")
 def VV5gyA(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVZrOq(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCDmyf.VVvsST(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVzMyY()
   else:
    self.manualSeekSec += direc * self.VVzMyY()
    self.manualSeekSec = FFCk9k(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FF8vMy(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFZcBU(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVVc1D(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVQmjP())
   FF72vQ(CFG.playerJumpMin, self.jumpMinutes)
  self.VVQ0Ki("Changed Seek Time to : %d%s" % (val, self.VV3v94()))
 def VVQmjP(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VV3v94())
 def VV3v94(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVzNlx(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVzMyY(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVX0kw(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VV78Hj(self):
  cList = self.VVpbDb()
  if cList:
   VVMYdC = []
   for pts, what in cList:
    txt = FFZcBU(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVMYdC.append((txt, pts))
   FFcKE0(self, self.VVoeE5, VVMYdC=VVMYdC, title="Cut List")
  else:
   self.VVQ0Ki("No Cut-List for this channel !")
 def VVoeE5(self, item=None):
  if item:
   self.VVBdqu(item)
 def VVpbDb(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVwsD3(self) : self.VVP2tp(1)
 def VV5M9q(self) : self.VVP2tp(-1)
 def VVP2tp(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCDmyf.VVvsST(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVzMyY() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVzNlx())
    self.VVQ0Ki(txt)
  except:
   self.VVQ0Ki("Cannot jump")
 def VVBdqu(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVQ0Ki("Changing Time ...")
 def VVvxjR(self):
  self.VVqDwJ(1)
  self.VVQ0Ki("Replaying ...")
  self.VV5gyA()
 def VVZm08(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCDmyf.VVvsST(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVQ0Ki("Jumping to end ...")
  except:
   pass
 def VVI8E8(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVollc(self, isUp):
  if self.enableZapping:
   self.VVQ0Ki("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VV5gyA()
   if self.iptvTableParams:
    FFC8Ey(BF(self.VVweiB, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self)
    if "/timeshift/" in decodedUrl:
     self.VVQ0Ki("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVSrWH()
  else:
   self.VVQ0Ki("Zap Disabled !")
 def VVSrWH(self):
  self.lastPlayPos = 0
  self.VVJ0OQ()
  self.VVP384()
 def VVweiB(self, isUp):
  CC0A1M_inatance, VVoyO8, mode = self.iptvTableParams
  if isUp : VVoyO8.VV1w6n()
  else : VVoyO8.VVVb4I()
  colList = VVoyO8.VV3wWK()
  if mode == "localIptv":
   chName, chUrl = CC0A1M_inatance.VV58Hj(VVoyO8, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CC0A1M_inatance.VVOfCC(VVoyO8, colList)
  elif isinstance(mode, int):
   chName, chUrl = CC0A1M_inatance.VVxi1m(mode, VVoyO8, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CC0A1M_inatance.VV9opw(mode, VVoyO8, colList)
  else:
   self.VVQ0Ki("Cannot Zap")
   return
  FFI9Ee(self, chUrl, VVtcz9=False)
  self.VVSrWH()
 def VVP384(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCDmyf.VVvsST(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self)
   if not self.VVy3E7(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVQ0Ki("Refreshing Portal")
   FFC8Ey(self.VVhXbs)
  except:
   pass
 def VVhXbs(self):
  self.restoreLastPlayPos = self.VVWlEn()
 def VVb9VF(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self)
  if not decodedUrl or FFnRfV(decodedUrl):
   self.VVQ0Ki("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CC0A1M.VVpVfO(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVQ0Ki("Reading Program List ...")
   ok_fnc = BF(self.VV49Pm, refCode, chName, streamId, uHost, uUser, uPass)
   FFC8Ey(BF(CC0A1M.VVXJ0U, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVQ0Ki("Cannot process this channel")
 def VV49Pm(self, refCode, chName, streamId, uHost, uUser, uPass, VVoyO8, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVoyO8.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVQ0Ki("Changing Program ...")
   FFC8Ey(BF(self.VVHW5X, chUrl))
  else:
   self.VVQ0Ki("Incorrect Timestamp !")
 def VVHW5X(self, chUrl):
  FFI9Ee(self, chUrl, VVtcz9=False)
  self.lastPlayPos = 0
  self.VVJ0OQ()
 def VVxKlU(self, isAudio):
  try:
   VVGXkF = InfoBar.instance
   if VVGXkF:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVGXkF)
    else  : self.session.open(SubtitleSelection, VVGXkF)
  except:
   pass
 @staticmethod
 def VVVqXD(session, mode=None):
  if   mode == "close_sig"   : FFXRBr(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CC0A1M)
  elif mode == "close_openInFileMan" : session.open(CC5DZc, gotoMovie=True)
 @staticmethod
 def VVtxwR(session, isFromExternal=False, **kwargs):
  session.openWithCallback(BF(CCDmyf.VVVqXD, session), CCDmyf, isFromExternal=isFromExternal, **kwargs)
class CChHGv(Screen):
 def __init__(self, session, title="", VVbvpB="Continue?", VVxvUW=True, VV6ttc=False):
  self.skin, self.skinParam = FFTWzO(VVzHOH, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVbvpB = VVbvpB
  self.VV6ttc = VV6ttc
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVxvUW : VVMYdC = [no , yes]
  else   : VVMYdC = [yes, no ]
  FF0Q0u(self, title, VVMYdC=VVMYdC, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVqqT1 ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVbvpB)
  if self.VV6ttc:
   self["myLabel"].instance.setHAlign(0)
  self.VVkzPe()
  FF4IYg(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FF3Wvr(self["myMenu"])
  FFEfAQ(self, self["myMenu"])
 def VVqqT1(self):
  item = FFzp0C(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVkzPe(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCg6yd(Screen):
 def __init__(self, session, title="", VVMYdC=None, width=1000, height=0, VVJfxh=30, barText="", minRows=1, OKBtnFnc=None, VVM2qe=None, VVAfNY=None, VVyvO2=None, VVtkPa=None, VVglYk=False, VVKpZE=False, VVI8Pk="#22003344", VV2s6D="#22002233"):
  if height == 0: height = 850
  self.skin, self.skinParam = FFTWzO(VV4Y67, width, height, 50, 40, 30, VVI8Pk, VV2s6D, VVJfxh, barHeight=40)
  self.session   = session
  self.VVMYdC   = VVMYdC
  self.barText   = barText
  self.minRows   = minRows
  self.OKBtnFnc   = OKBtnFnc
  self.VVM2qe   = VVM2qe
  self.VVAfNY  = VVAfNY
  self.VVyvO2  = VVyvO2
  self.VVtkPa   = VVtkPa
  self.VVglYk  = VVglYk
  self.VVKpZE  = VVKpZE
  FF0Q0u(self, title, VVMYdC=VVMYdC)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVqqT1          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVFats         ,
   "green"  : self.VVk78X         ,
   "yellow" : self.VVudpX         ,
   "blue"  : self.VVmRqF         ,
   "pageUp" : self.VV1wjd       ,
   "chanUp" : self.VV1wjd       ,
   "pageDown" : self.VVf34R        ,
   "chanDown" : self.VVf34R
  }, -1)
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FF4IYg(self["myMenu"])
  FFIvVk(self, minRows=self.minRows)
  self.VVexxi(self["keyRed"]  , self.VVM2qe )
  self.VVexxi(self["keyGreen"] , self.VVAfNY )
  self.VVexxi(self["keyYellow"] , self.VVyvO2 )
  self.VVexxi(self["keyBlue"]  , self.VVtkPa )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFyHsQ(self)
 def VVexxi(self, btnObj, btnFnc):
  if btnFnc:
   FF970D(btnObj, btnFnc[0])
 def VVGqYd(self, fnc=None):
  self.VVAfNY = fnc
  if fnc : self.VVexxi(self["keyGreen"], self.VVAfNY)
  else : self["keyGreen"].hide()
 def VVqqT1(self):
  item = FFzp0C(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVglYk: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVFats(self)  : self.VVUReq(self.VVM2qe)
 def VVk78X(self) : self.VVUReq(self.VVAfNY)
 def VVudpX(self) : self.VVUReq(self.VVyvO2)
 def VVmRqF(self) : self.VVUReq(self.VVtkPa)
 def VVUReq(self, btnFnc):
  if btnFnc:
   item = FFzp0C(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVKpZE:
    self.cancel()
 def VVRBpj(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VVLcYB(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVMYdC = self["myMenu"].list
  VVMYdC.pop(ndx)
  if len(VVMYdC) > 0: self["myMenu"].setList(VVMYdC)
  else    : self.close()
 def VVUdLz(self, VVMYdC):
  if len(VVMYdC) > 0:
   newList = []
   for item in VVMYdC:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFIvVk(self, minRows=self.minRows)
  else:
   self.close("")
 def VV3HJz(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FFIvVk(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVCl3X(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VV1wjd(self):
  self["myMenu"].moveToIndex(0)
 def VVf34R(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCrcNA(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VVL1iO=None, VV28Ef=None, VVLkOa=None, VVJfxh=26, VVMVWT=False, VVWa5f=0, VVhqvZ=None, VVDAgH=None, VV1mml=None, VVgAHl=None, VVUZua=None, VVR0s7=None, VVcQZx=None, VV3Q2h=None, VVxRQ7=None, VVoJlH=-1, VVVz9Q=False, searchCol=0, lastFindConfigObj=None, VVI8Pk=None, VV2s6D=None, VVjLVu="#00dddddd", VVjLdB="#11002233", VV58S5="#00ff8833", VVaZj9="#11111111", VVBGyD="#0a555555", VVWn5B="#0affffff", VVFIzs="#11552200", VVWGqI="#0055ff55"):
  self.skin, self.skinParam = FFTWzO(VVqa87, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FF0Q0u(self, title)
  self.Title     = title
  self.header     = header
  self.VVL1iO     = VVL1iO
  self.totalCols    = len(VVL1iO[0])
  self.VVWa5f   = VVWa5f
  self.lastSortModeIsReverese = False
  self.VVMVWT   = VVMVWT
  self.VVS416   = 0.01
  self.VVCaG8   = 0.02
  self.VV8rw7 = 0.03
  self.VVo9Wx  = 1
  self.VVLkOa = VVLkOa
  self.colWidthPixels   = []
  self.VVhqvZ   = VVhqvZ
  self.OKButtonObj   = None
  self.VVDAgH   = VVDAgH
  self.VV1mml   = VV1mml
  self.VVgAHl   = VVgAHl
  self.VVUZua  = VVUZua
  self.VVR0s7   = VVR0s7
  self.VVcQZx    = VVcQZx
  self.VV3Q2h   = VV3Q2h
  self.tableRefreshCB   = None
  self.VVxRQ7  = VVxRQ7
  self.VVoJlH    = VVoJlH
  self.VVVz9Q   = VVVz9Q
  self.searchCol    = searchCol
  self.VV28Ef    = VV28Ef
  self.keyPressed    = -1
  self.VVJfxh    = FFhgll(VVJfxh)
  self.VVIJkE    = FFdLhG(self.VVJfxh, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVI8Pk    = VVI8Pk
  self.VV2s6D      = VV2s6D
  self.VVjLVu    = FFSOpM(VVjLVu)
  self.VVjLdB    = FFSOpM(VVjLdB)
  self.VV58S5    = FFSOpM(VV58S5)
  self.VVaZj9    = FFSOpM(VVaZj9)
  self.VVBGyD   = FFSOpM(VVBGyD)
  self.VVWn5B    = FFSOpM(VVWn5B)
  self.VVFIzs    = FFSOpM(VVFIzs)
  self.VVWGqI   = FFSOpM(VVWGqI)
  self.VVdP3d  = False
  self.selectedItems   = 0
  self.VVkPbF   = FFSOpM("#01fefe01")
  self.VV404a   = FFSOpM("#11400040")
  self.VVwjcY  = self.VVkPbF
  self.VVBULV  = self.VVaZj9
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVVz9Q:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVO8C7  ,
   "red"   : self.VVcT8s  ,
   "green"   : self.VVHTZb ,
   "yellow"  : self.VV9Ytd ,
   "blue"   : self.VVy7D3  ,
   "menu"   : self.VVPEad ,
   "info"   : self.VVxPcK  ,
   "cancel"  : self.VVAh0g  ,
   "up"   : self.VVVb4I    ,
   "down"   : self.VV1w6n  ,
   "left"   : self.VVk7uS   ,
   "right"   : self.VVVrpS  ,
   "next"   : self.VVJ1fG  ,
   "last"   : self.VVTUHP  ,
   "home"   : self.VV185D  ,
   "pageUp"  : self.VV185D  ,
   "chanUp"  : self.VV185D  ,
   "end"   : self.VV9N96  ,
   "pageDown"  : self.VV9N96  ,
   "chanDown"  : self.VV9N96
  }, -1)
  FFINwU(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FFKT7W(self)
  try:
   self.VVWQ4V()
  except Exception as e:
   FFu1fZ(self, str(e), title=self.Title)
   self.close(None)
 def VVWQ4V(self):
  FFyHsQ(self)
  if self.VVI8Pk:
   FFaCb6(self["myTitle"], self.VVI8Pk)
  if self.VV2s6D:
   FFaCb6(self["myBody"] , self.VV2s6D)
   FFaCb6(self["myTableH"] , self.VV2s6D)
   FFaCb6(self["myTable"] , self.VV2s6D)
   FFaCb6(self["myBar"]  , self.VV2s6D)
  self.VVexxi(self.VV1mml  , self["keyRed"])
  self.VVexxi(self.VVgAHl  , self["keyGreen"])
  self.VVexxi(self.VVUZua , self["keyYellow"])
  self.VVexxi(self.VVR0s7  , self["keyBlue"])
  if self.VVhqvZ:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVhqvZ[0])
    FFaCb6(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVIJkE)
  self["myTableH"].l.setFont(0, gFont(VVqTEg, self.VVJfxh))
  self["myTable"].l.setItemHeight(self.VVIJkE)
  self["myTable"].l.setFont(0, gFont(VVqTEg, self.VVJfxh))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVIJkE)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVIJkE))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVIJkE)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVIJkE
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVIJkE * len(self.VVL1iO) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVLkOa:
   self.VVLkOa = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVLkOa)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VV28Ef:
   self.VV28Ef = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VV28Ef
   self.VV28Ef = []
   for item in tmpList:
    self.VV28Ef.append(item | RT_VALIGN_CENTER)
  self.VVAQrP()
  if self.VVcQZx:
   self.VVcQZx(self)
 def VVexxi(self, btnFnc, btn):
  if btnFnc : FF970D(btn, btnFnc[0])
  else  : FF970D(btn, "")
 def VVcpFA(self, waitTxt):
  FFZmix(self, self.VVAQrP, title=waitTxt)
 def VVAQrP(self, onlyHeader=False):
  try:
   if self.header:
    self["myTableH"].setList([self.VVCGb5(0, self.header, self.VVWn5B, self.VVFIzs, self.VVWn5B, self.VVFIzs, self.VVWGqI)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVL1iO):
    self["myTable"].list.append(self.VVCGb5(c, row, self.VVjLVu, self.VVjLdB, self.VV58S5, self.VVaZj9, None))
   self.VVL1iO = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVoJlH > -1:
    self["myTable"].moveToIndex(self.VVoJlH )
   self.VVAzRV()
   if self.VVVz9Q:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVIJkE * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VV3Q2h:
    self.VVUReq(self.VV3Q2h, None)
   if self.tableRefreshCB:
    self.VVUReq(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FFu1fZ(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VVCGb5(self, keyIndex, columns, VVjLVu, VVjLdB, VV58S5, VVaZj9, VVWGqI):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVWGqI and ndx == self.VVWa5f : textColor = VVWGqI
   else           : textColor = VVjLVu
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFSOpM(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVjLdB = c
    entry = span.group(3)
   if self.VV28Ef[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVIJkE)
           , font   = 0
           , flags   = self.VV28Ef[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVjLdB
           , color_sel  = VV58S5
           , backcolor_sel = VVaZj9
           , border_width = 1
           , border_color = self.VVBGyD
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVxPcK(self):
  rowData = self.VVMySR()
  if rowData:
   title, txt, colList = rowData
   if self.VVDAgH:
    fnc  = self.VVDAgH[1]
    params = self.VVDAgH[2]
    fnc(self, title, txt, colList)
   else:
    FF4gok(self, txt, title)
 def VVO8C7(self):
  if   self.VVdP3d : self.VVeQJY(self.VVr4DQ(), mode=2)
  elif self.VVhqvZ  : self.VVUReq(self.VVhqvZ, None)
  else      : self.VVxPcK()
 def VVcT8s(self) : self.VVUReq(self.VV1mml , self["keyRed"])
 def VVHTZb(self) : self.VVUReq(self.VVgAHl , self["keyGreen"])
 def VV9Ytd(self): self.VVUReq(self.VVUZua , self["keyYellow"])
 def VVy7D3(self) : self.VVUReq(self.VVR0s7 , self["keyBlue"])
 def VVUReq(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFAcfo(self, buttonFnc[3])
    FFC8Ey(BF(self.VVpGvT, buttonFnc))
   else:
    self.VVpGvT(buttonFnc)
 def VVpGvT(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVMySR()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVeQJY(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][9] == self.VVkPbF
   newRow = self.VV3wWK()
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVCGb5(ndx, newRow, self.VVjLVu, self.VVjLdB, self.VV58S5, self.VVaZj9, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVCGb5(ndx, newRow, self.VVkPbF, self.VV404a, self.VVwjcY, self.VVBULV, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   if self.VVr4DQ() < len(self["myTable"].list) - 1:
    self.VV1w6n()
   else:
    self.VVAzRV()
 def VVWteY(self)  : FFZmix(self, BF(self.VVJhU8, True ), title="Selecting all ..."  )
 def VV6Sto(self) : FFZmix(self, BF(self.VVJhU8, False), title="Unselecting all ...")
 def VVJhU8(self, isSel=True):
  if isSel:
   fg, bg = self.VVkPbF, self.VV404a
   self.selectedItems = len(self["myTable"].list)
   self.VVRw1e(True)
  else:
   fg, bg = self.VVjLVu, self.VVjLdB
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][9] == self.VVkPbF
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     param = list(self["myTable"].list[ndx][col])
     param[8]  = fg
     param[9]  = fg
     param[10] = bg
     self["myTable"].list[ndx][col] = tuple(param)
  self["myTable"].l.invalidate()
 def VVMySR(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVLkOa[i] > 1 or self.VVLkOa[i] == self.VVS416 or self.VVLkOa[i] == self.VV8rw7:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VVAh0g(self):
  if self.VVxRQ7 : self.VVxRQ7(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VVA691(self):
  return self["myTitle"].getText().strip()
 def VVROug(self):
  return self.header
 def VV7PwH(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVEUZp(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFCE16(self["myBar"], color)
 def VVySY5(self, txt):
  FFAcfo(self, txt)
 def VVdbDB(self, txt, Time=1000):
  FFAcfo(self, txt, Time)
 def VVZYmq(self): self["keyGreen"].show()
 def VVTDlc(self): self["keyGreen"].hide()
 def VV4uR4(self):
  FFAcfo(self)
 def VVSw2q(self, fnc):
  self["myTable"].onSelectionChanged.append(fnc)
 def VVSgrB(self):
  return len(self["myTable"].list)
 def VVr4DQ(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VV03io(self):
  return len(self["myTable"].list)
 def VVRw1e(self, isOn):
  self.VVdP3d = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VVR0s7: self["keyBlue"].hide()
   if self.VVhqvZ and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVR0s7: self["keyBlue"].show()
   if self.VVhqvZ and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVhqvZ[0])
   self.VV6Sto()
  FFaCb6(self["myTitle"], color)
  FFaCb6(self["myBar"]  , color)
 def VVb2bO(self):
  return self.VVdP3d
 def VVlPPo(self):
  return self.selectedItems
 def VV9Qxk(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVAzRV()
 def VVbuc0(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVF0oO(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVSgrB()
  txt += FF9bzo("Total Unique Items", VVwtwf)
  for i in range(self.totalCols):
   if self.VVLkOa[i - 1] > 1 or self.VVLkOa[i - 1] == self.VVS416 or self.VVLkOa[i - 1] == self.VV8rw7:
    name, tot = self.VVbuc0(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FF4gok(self, txt)
 def VVnbNr(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VV3wWK(self):
  return self.VVyjPv(self["myTable"].l.getCurrentSelectionIndex())
 def VVyjPv(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVKBif(self, newList, newTitle="", VVCt4FMsg=True, tableRefreshCB=None):
  if newTitle:
   self.VV7PwH(newTitle)
  if newList:
   self.VVL1iO = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VVMVWT and self.VVWa5f == 0:
    isNum = True
   else:
    for cols in self.VVL1iO:
     if not FFFN8J(cols[self.VVWa5f]): break
    else:
     isNum = True
   if isNum: self.VVL1iO.sort(key=lambda x: int(x[self.VVWa5f])  , reverse=self.lastSortModeIsReverese)
   else : self.VVL1iO.sort(key=lambda x: x[self.VVWa5f].lower() , reverse=self.lastSortModeIsReverese)
   if VVCt4FMsg : self.VVcpFA("Refreshing ...")
   else   : self.VVAQrP()
  else:
   FFu1fZ(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VVKMAo(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VVCGb5(self.VV03io(), row, self.VVjLVu, self.VVjLdB, self.VV58S5, self.VVaZj9, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VV9N96()
 def VVY64Q(self):
  self["myTable"].list.pop(self.VVr4DQ())
  self["myTable"].l.setList(self["myTable"].list)
 def VVlQTg(self, data):
  ndx = self.VVr4DQ()
  newRow = self.VVCGb5(ndx, data, self.VVjLVu, self.VVjLdB, self.VV58S5, self.VVaZj9, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVAzRV()
   return True
  else:
   return False
 def VVUt87(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VVCGb5(ndx, data, self.VVjLVu, self.VVjLdB, self.VV58S5, self.VVaZj9, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVx4q6()
 def VVx4q6(self):
  self["myTable"].l.setList(self["myTable"].list)
 def VV79WN(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VVawt3(self, colNum, textToFind, VVe3Eu=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVAzRV()
    break
  else:
   if VVe3Eu:
    FFAcfo(self, "Not found", 1000)
 def VVvFYl(self, colDict, VVe3Eu=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVAzRV()
    return
  if VVe3Eu:
   FFAcfo(self, "Not found", 1000)
 def VVfywU(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVTN1X(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFFN8J(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VV1mal(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVkPbF:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVs7PD(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVkPbF:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VVYiHp(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VVkPbF: return True
  else        : return False
 def VVVGfF(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVPEad(self):
  if not self["keyMenu"].getVisible() or self.VVVz9Q:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVr4DQ()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVMYdC1, VVcjwH = CCfZNJ.VVg0Oq(self, False, False)
  VVMYdC = []
  VVMYdC.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVMYdC.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVMYdC.append(("Find ...\t\t%s" % (FFXe6i(txt, VVhW2e) if txt else ""), "findNew"   ))
  VVMYdC.append(itemOf(bool(VVMYdC1)    , "Find (from Filter) ..."   , "filter"   ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Table Statistcis"             , "tableStat"  ))
  VVMYdC.append(VVc27s)
  VVMYdC.append((FFXe6i("Export Table to .html"     , VVwtwf) , "VVPkOt" ))
  VVMYdC.append((FFXe6i("Export Table to .csv"     , VVwtwf) , "VVkTyJ" ))
  VVMYdC.append((FFXe6i("Export Table to .txt (Tab Separated)", VVwtwf) , "VVWDNM" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVLkOa[i] > 1 or self.VVLkOa[i] == self.VVCaG8:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVMYdC.append(VVc27s)
   if tot == 1 : VVMYdC.append(("Sort", sList[0][1]))
   else  : VVMYdC += sList
  VVtkPa = ("Keys Help", self.FFMPkyHelp)
  FFcKE0(self, self.VVIHUJ, VVMYdC=VVMYdC, title=self.VVA691(), VVtkPa=VVtkPa)
 def VVIHUJ(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVxPa2()
   elif item == "findPrev"  : self.VVxPa2(isPrev=True)
   elif item == "findNew"  : self.VV2dtd()
   elif item == "filter"  : self.VV2Jbj()
   elif item == "tableStat" : self.VVF0oO()
   elif item == "VVPkOt": FFZmix(self, self.VVPkOt, title=title)
   elif item == "VVkTyJ" : FFZmix(self, self.VVkTyJ , title=title)
   elif item == "VVWDNM" : FFZmix(self, self.VVWDNM , title=title)
   else:
    self.lastSortModeIsReverese = False
    if self.VVWa5f == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVWa5f = item
    if self.VVMVWT and self.VVWa5f == 0 or self.VVTN1X(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVAQrP(onlyHeader=True)
 def FFMPkyHelp(self, menuInstance, path):
  FFqh4M(self, VVlId3 + "_help_table", "Table (Keys Help)")
 def VVVb4I(self):
  self["myTable"].up()
  self.VVAzRV()
 def VV1w6n(self):
  self["myTable"].down()
  self.VVAzRV()
 def VVk7uS(self):
  self["myTable"].pageUp()
  self.VVAzRV()
 def VVVrpS(self):
  self["myTable"].pageDown()
  self.VVAzRV()
 def VV185D(self):
  self["myTable"].moveToIndex(0)
  self.VVAzRV()
 def VV9N96(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVAzRV()
 def VVjS0j(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVAzRV()
 def VVJ1fG(self):
  if self.lastFindConfigObj.getValue():
   if self.VVr4DQ() == len(self["myTable"].list) - 1 : FFAcfo(self, "End reached", 1000)
   else              : self.VVxPa2()
  else:
   FFAcfo(self, 'Set "Find" in Menu', 1500)
 def VVTUHP(self):
  if self.lastFindConfigObj.getValue():
   if self.VVr4DQ() == 0 : FFAcfo(self, "Top reached", 1000)
   else       : self.VVxPa2(isPrev=True)
  else:
   FFAcfo(self, 'Set "Find" in Menu', 1500)
 def VV9tfD(self, txt):
  FF72vQ(self.lastFindConfigObj, txt)
 def VV2dtd(self):
  FFSAou(self, self.VVps2N, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VVps2N(self, VVO1nz):
  if not VVO1nz is None:
   txt = VVO1nz.strip()
   self.VV9tfD(txt)
   if VVO1nz: self.VVxPa2(reset=True)
   else  : FFAcfo(self, "Nothing to find !", 1500)
 def VV2Jbj(self):
  VVMYdC, VVcjwH = CCfZNJ.VVg0Oq(self, False, False)
  VVyvO2 = ("Edit Filter", BF(self.VVPLnt, VVcjwH))
  if VVMYdC : FFcKE0(self, self.VVhqEG, VVMYdC=VVMYdC, VVyvO2=VVyvO2, title="Find from Filter")
  else  : FFAcfo(self, "Filter Error !", 1500)
 def VVhqEG(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VV9tfD(txt)
    self.VVxPa2(reset=True)
   else:
    FFAcfo(self, "No entry !", 1500)
 def VVPLnt(self, VVcjwH, VVVCbtObj, sel):
  if fileExists(VVcjwH) : CCV79S(self, VVcjwH, VV2r3B=None)
  else       : FF6iwf(self, VVcjwH)
  VVVCbtObj.cancel()
 def VVxPa2(self, reset=False, isPrev=False):
  curRow = self.VVr4DQ()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCfZNJ.VVGe34(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VVjS0j(i)
      break
    elif any(x in line for x in tupl):
     self.VVjS0j(i)
     break
   else:
    FFAcfo(self, "Not found", 1000)
  else:
   FFAcfo(self, "Check your query", 1500)
 def VVWDNM(self):
  expFile = self.VVd4ky() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVFe9g()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVyjPv(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVLkOa[ndx] > self.VVo9Wx or self.VVLkOa[ndx] == self.VV8rw7:
      col = self.VVSl2n(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVXcOX(expFile)
 def VVkTyJ(self):
  expFile = self.VVd4ky() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVFe9g()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVyjPv(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVLkOa[ndx] > self.VVo9Wx or self.VVLkOa[ndx] == self.VV8rw7:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VVSl2n(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVXcOX(expFile)
 def VVPkOt(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVA691(), PLUGIN_NAME, VV9qD9)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVA691()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVFe9g()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVLkOa:
   colgroup += '   <colgroup>'
   for w in self.VVLkOa:
    if w > self.VVo9Wx or w == self.VV8rw7:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVd4ky() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVyjPv(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVLkOa[ndx] > self.VVo9Wx or self.VVLkOa[ndx] == self.VV8rw7:
      col = self.VVSl2n(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVXcOX(expFile)
 def VVFe9g(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVLkOa[ndx] > self.VVo9Wx or self.VVLkOa[ndx] == self.VV8rw7:
     newRow.append(col.strip())
  return newRow
 def VVSl2n(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FF3RM7(col)
 def VVd4ky(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVA691())
  fileName = fileName.replace("__", "_")
  path  = FF5sxC(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFcOP9()
  return expFile
 def VVXcOX(self, expFile):
  FF5VuW(self, "File exported to:\n\n%s" % expFile, title=self.VVA691())
 def VVAzRV(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCA2G7():
 def __init__(self, pixmapObj, picPath, VVjLdB=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VVjLdB  = VVjLdB or "#2200002a"
 def VVYXsG(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVDB5Y)
    except:
     self.picLoad.PictureData.get().append(self.VVDB5Y)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VVjLdB])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVDB5Y(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVe1XB(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVoo99(pixmapObj, path, VVjLdB=None):
  cl = CCA2G7(pixmapObj, path, VVjLdB)
  ok = cl.VVYXsG()
  if ok: return cl
  else : return None
class CCKf0K(Screen):
 def __init__(self, session, title="", VVjDbt=None, showGrnMsg=""):
  self.skin, self.skinParam = FFTWzO(VVLTt8, 1600, 1000, 30, 40, 20, "#22000060", "#2200002a", 30)
  if not title:
   title = os.path.basename(VVjDbt),
  self.session = session
  FF0Q0u(self, title, addCloser=True)
  self["myPic"]  = Pixmap()
  self.VVjDbt = VVjDbt
  self.showGrnMsg  = showGrnMsg
  self.picViewer  = None
  self.onShown.append(self.VViGDa)
  self.onClose.append(self.onExit)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  self.picViewer = CCA2G7.VVoo99(self["myPic"], self.VVjDbt)
  if self.picViewer:
   if self.showGrnMsg:
    FFAcfo(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFu1fZ(self, "Cannot view picture file:\n\n%s" % self.VVjDbt)
   self.close()
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVe1XB()
 @staticmethod
 def VVAHGG(SELF, VVjDbt, title="", showGrnMsg=""):
  SELF.session.open(BF(CCKf0K, title=title, VVjDbt=VVjDbt, showGrnMsg=showGrnMsg))
class CCebnr(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FFTWzO(WINDOW_NO_BODY, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FF0Q0u(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VViGDa)
  self.onClose.append(self.onExit)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  res = os.system(FFVKmy("showiframe %s" % self.mviFile))
  if not res == 0:
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VV1oWQ(SELF, mviFile):
  SELF.session.openWithCallback(BF(CCebnr.VVwZVu, SELF), CCebnr, mviFile)
 @staticmethod
 def VVwZVu(SELF, reason=None):
  if reason == -1: FFu1fZ(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CCaoCm(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFTWzO(VVZJjb, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FF0Q0u(self, title=self.Title)
  FF970D(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("File Manage Exit-Button Action"        , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Signal & Player Cotroller Hotkey"       , CFG.hotkey_signal    ))
  if VV4GLW:
   lst.append(getConfigListEntry("EPG Translation Language"        , CFG.epgLanguage    ))
  lst.append(getConfigListEntry(VVn31f *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type"         , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Movie/Series Download Path"         , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VVn31f *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VVn31f *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons"            , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VV42cI()
  self.onShown.append(self.VViGDa)
 def VV42cI(self):
  kList = {
    "ok"  : self.VVqqT1    ,
    "green"  : self.VVt0LT  ,
    "menu"  : self.VVART7  ,
    "cancel" : self.VVBlgV  ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVmUum, 0)
     kList["chanDown"] = BF(self["config"].VVmUum, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FFKT7W(self)
  FF4IYg(self["config"])
  FFIvVk(self, self["config"])
  FFyHsQ(self)
 def VVqqT1(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsMode   : self.VVAqnE()
   elif item == CFG.MovieDownloadPath   : self.VV3Nri(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VVlPH0(item)
   elif item == CFG.backupPath    : self.VVlPH0(item)
   elif item == CFG.packageOutputPath  : self.VVlPH0(item)
   elif item == CFG.downloadedPackagesPath : self.VVlPH0(item)
   elif item == CFG.exportedTablesPath  : self.VVlPH0(item)
   elif item == CFG.exportedPIconsPath  : self.VVlPH0(item)
 def VV3Nri(self, item, title):
  tot = CC0kPO.VVSI1z()
  if tot : FFu1fZ(self, "Cannot change while downloading.", title=title)
  else : self.VVlPH0(item)
 def VVAqnE(self):
  VVMYdC = []
  VVMYdC.append(("Auto Find" , "auto"))
  VVMYdC.append(("Custom Path" , "cust"))
  FFcKE0(self, self.VVlBfg, VVMYdC=VVMYdC, title="IPTV Hosts Files Path")
 def VVlBfg(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVHClL)
   elif item == "cust":
    VVbdQX = self.VV11dE()
    if VVbdQX : self.VVKppT(VVbdQX)
    else  : self.session.openWithCallback(self.VVlgvL, BF(CC5DZc, mode=CC5DZc.VVi95q, VVYwJg="/"))
 def VVKppT(self, VVbdQX):
  VVxRQ7 = self.VVoUZ8
  VV1mml = ("Remove"  , self.VVkO2N , [])
  VVUZua = ("Add "  , self.VVTVBn, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VV28Ef  = (LEFT   , LEFT  )
  FFMPky(self, None, title="IPTV Hosts Search Paths", header=header, VVL1iO=VVbdQX, width=1200, height=700, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=26, VVxRQ7=VVxRQ7, VV1mml=VV1mml, VVUZua=VVUZua
    , VVI8Pk="#11220000", VV2s6D="#11110000", VVjLdB="#11110011", VV58S5="#00ffff00", VVaZj9="#00223025", VVBGyD="#0a333333", VVFIzs="#0a400040")
 def VVoUZ8(self, VVoyO8):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVmmlq)
  VVoyO8.cancel()
 def VVlgvL(self, path):
  if path:
   FF72vQ(CFG.iptvHostsDirs, FF5sxC(path.strip()))
   VVbdQX = self.VV11dE()
   if VVbdQX : self.VVKppT(VVbdQX)
   else  : FFAcfo(self, "Cannot add dir", 1500)
 def VVNW92(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVHClL:
   return []
  return lst
 def VV11dE(self):
  lst = self.VVNW92()
  if lst:
   VVbdQX = []
   for Dir in lst:
    VVbdQX.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVbdQX.sort(key=lambda x: x[0].lower())
   return VVbdQX
  else:
   return []
 def VVTVBn(self, VVoyO8, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VVO0ys, VVoyO8)
         , BF(CC5DZc, mode=CC5DZc.VVi95q, VVYwJg=sDir))
 def VVO0ys(self, VVoyO8, path):
  if path:
   path = FF5sxC(path.strip())
   if self.VVlS05(VVoyO8, path):
    FFAcfo(VVoyO8, "Already added", 1500)
   else:
    lst = self.VVNW92()
    lst.append(path)
    FF72vQ(CFG.iptvHostsDirs, ",".join(lst))
    VVbdQX = self.VV11dE()
    VVoyO8.VVKBif(VVbdQX, tableRefreshCB=BF(self.VVAkhA, path))
 def VVAkhA(self, path, VVoyO8, title, txt, colList):
  self.VVlS05(VVoyO8, path)
 def VVlS05(self, VVoyO8, path):
  for ndx, row in enumerate(VVoyO8.VVVGfF()):
   if row[0].strip() == path.strip():
    VVoyO8.VVjS0j(ndx)
    return True
  return False
 def VVkO2N(self, VVoyO8, title, txt, colList):
  path = colList[0]
  FFlOO5(self, BF(self.VV22A8, VVoyO8), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VV22A8(self, VVoyO8):
  row = VVoyO8.VV3wWK()
  path, rem = row[0], row[1]
  VVbdQX = []
  lst = []
  for ndx, row in enumerate(VVoyO8.VVVGfF()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVbdQX.append((tPath, tRem))
  if len(VVbdQX) > 0:
   FF72vQ(CFG.iptvHostsDirs, ",".join(lst))
   VVoyO8.VVKBif(VVbdQX)
   FFAcfo(VVoyO8, "Deleted", 1500)
  else:
   FF72vQ(CFG.iptvHostsMode, VVHClL)
   FF72vQ(CFG.iptvHostsDirs, "")
   VVoyO8.cancel()
   FFC8Ey(BF(FFAcfo, self, "Changed to Auto-Find", 1500))
 def VVlPH0(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VVivAH, configObj)
         , BF(CC5DZc, mode=CC5DZc.VVi95q, VVYwJg=sDir))
 def VVivAH(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVBlgV(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFlOO5(self, self.VVt0LT, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVt0LT(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVig3n()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVART7(self):
  VVMYdC = []
  VVMYdC.append(("Use Backup Path for Package/Download/Tables/PIcons"   , "VV32ZJ"   ))
  VVMYdC.append(("Reset %s Settings" % PLUGIN_NAME        , "VVLmkp"   ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Backup %s Settings" % PLUGIN_NAME        , "VVzghc"  ))
  VVMYdC.append(("Restore %s Settings" % PLUGIN_NAME       , "VV5zqf"  ))
  if fileExists(VVXneu + VVS5Ek):
   VVMYdC.append(VVc27s)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVMYdC.append(('%s Checking for Update' % txt1       , txt2     ))
   VVMYdC.append(("Reinstall %s" % PLUGIN_NAME        , "VV7zWJ"  ))
   VVMYdC.append(("Update %s" % PLUGIN_NAME        , "VVoGCx"   ))
  FFcKE0(self, self.VVilwd, VVMYdC=VVMYdC, title="Config. Options")
 def VVilwd(self, item=None):
  if item:
   if   item == "VV32ZJ"  : FFlOO5(self, self.VV32ZJ , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVLmkp"  : FFlOO5(self, self.VVLmkp, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCFzcP)
   elif item == "VVzghc" : self.VVzghc()
   elif item == "VV5zqf" : FFZmix(self, self.VV5zqf, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FF72vQ(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FF72vQ(CFG.checkForUpdateAtStartup, False)
   elif item == "VV7zWJ" : FFZmix(self, self.VV7zWJ , "Checking Server ...")
   elif item == "VVoGCx"  : FFZmix(self, self.VVoGCx  , "Checking Server ...")
 def VVzghc(self):
  path = "%sajpanel_settings_%s" % (VVXneu, FFcOP9())
  os.system("grep .%s. %ssettings > %s" % (PLUGIN_NAME, VVPZMJ, path))
  FF5VuW(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VV5zqf(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FFEUax("find / %s -iname '%s*' | grep %s" % (FFcbot(1), name, name))
  if lines:
   lines.sort()
   VVMYdC = []
   for line in lines:
    VVMYdC.append((line, line))
   FFcKE0(self, BF(self.VVnlCv, title), title=title, VVMYdC=VVMYdC, width=1200)
  else:
   FFu1fZ(self, "No settings files found !", title=title)
 def VVnlCv(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFgYB4(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVig3n()
    FFaSmH()
   else:
    FF6iwf(SELF, path, title=title)
 def VV32ZJ(self):
  newPath = FF5sxC(VVXneu)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVig3n()
 @staticmethod
 def VVIb7e():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVLmkp(self):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVig3n()
  self.close()
 def VVig3n(self):
  configfile.save()
  global VVXneu
  VVXneu = CFG.backupPath.getValue()
  FFM274()
 def VVoGCx(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVvZzn(title)
  if webVer:
   FFlOO5(self, BF(FFZmix, self, BF(self.VVgIqH, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VV7zWJ(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVvZzn(title, True)
  if webVer:
   FFlOO5(self, BF(FFZmix, self, BF(self.VVgIqH, webVer, title, True)), "Install and Restart ?", title=title)
 def VVgIqH(self, webVer, title, isReinst=False):
  url = self.VVSXLi(self, title)
  if url:
   VVchL9 = FFwr6I() == "dpkg"
   if VVchL9 == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVchL9 else "ipk")
   path, err = FFmy2V(url + fName, fName, timeout=2)
   if path:
    if isReinst : cmd = FF9JgI(VVIf8A, path)
    else  : cmd = FF9JgI(VVz9Zr, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFrhsY(self, cmd)
    else:
     FF0x3g(self, title=title)
   else:
    FFu1fZ(self, err, title=title)
 def VVvZzn(self, title, anyVer=False):
  url = self.VVSXLi(self, title)
  if not url:
   return ""
  path, err = FFmy2V(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFu1fZ(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFQgne(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFu1fZ(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VV9qD9.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFEUax(cmd)
   if list and curVer == list[0]:
    return webVer
  FF5VuW(self, FFXe6i("No update required.", VVhAfh) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVSXLi(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVXneu + VVS5Ek
  if fileExists(path):
   span = iSearch(r"(http.+)", FFQgne(path), IGNORECASE)
   if span : url = FF5sxC(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFu1fZ(SELF, err, title)
  return url
 @staticmethod
 def VVDh0E(url):
  path, err = FFmy2V(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFQgne(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VV9qD9.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFEUax(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCFzcP(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFTWzO(VVgwrw, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = COLOR_SCHEME_NUM
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FF0Q0u(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVOpAW("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVOpAW("\c00888888", i) + sp + "GREY\n"
   txt += self.VVOpAW("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVOpAW("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVOpAW("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVOpAW("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVOpAW("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVOpAW("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVOpAW("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVOpAW("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVOpAW("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVOpAW("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVqqT1 ,
   "green"   : self.VVqqT1 ,
   "left"   : self.VVvyya ,
   "right"   : self.VVF1i7 ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  self.VVHDuu()
 def VVqqT1(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFlOO5(self, self.VVdBWA, "Change to : %s" % txt, title=self.Title)
 def VVdBWA(self):
  FF72vQ(CFG.mixedColorScheme, self.cursorPos)
  global COLOR_SCHEME_NUM
  COLOR_SCHEME_NUM = self.cursorPos
  self.VVMPcL()
  self.close()
 def VVvyya(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVHDuu()
 def VVF1i7(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVHDuu()
 def VVHDuu(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVOpAW(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVbZ7V(color):
  if VVrhVl: return "\\" + color
  else    : return ""
 @staticmethod
 def VVMPcL():
  global VVB3E5, VVycQx, VVpQzP, VV8DG7, VVwtwf, VVwhxm, VVEirQ, VVKoYn, VVhAfh, VV80mJ, VVrhVl, VVJ6nn, VVhW2e, VV2RHA, VVDDRU, VVGCti
  VVGCti   = CCFzcP.VVOpAW("\c00FFFFFF", COLOR_SCHEME_NUM)
  VVycQx    = CCFzcP.VVOpAW("\c00888888", COLOR_SCHEME_NUM)
  VVB3E5  = CCFzcP.VVOpAW("\c005A5A5A", COLOR_SCHEME_NUM)
  VVKoYn    = CCFzcP.VVOpAW("\c00FF0000", COLOR_SCHEME_NUM)
  VVpQzP   = CCFzcP.VVOpAW("\c00FF5000", COLOR_SCHEME_NUM)
  VV8DG7   = CCFzcP.VVOpAW("\c00FFBB66", COLOR_SCHEME_NUM)
  VVrhVl   = CCFzcP.VVOpAW("\c00FFFF00", COLOR_SCHEME_NUM)
  VVJ6nn = CCFzcP.VVOpAW("\c00FFFFAA", COLOR_SCHEME_NUM)
  VVhAfh   = CCFzcP.VVOpAW("\c0000FF00", COLOR_SCHEME_NUM)
  VV80mJ  = CCFzcP.VVOpAW("\c00AAFFAA", COLOR_SCHEME_NUM)
  VVEirQ    = CCFzcP.VVOpAW("\c000066FF", COLOR_SCHEME_NUM)
  VVhW2e    = CCFzcP.VVOpAW("\c0000FFFF", COLOR_SCHEME_NUM)
  VV2RHA  = CCFzcP.VVOpAW("\c00AAFFFF", COLOR_SCHEME_NUM)  #
  VVDDRU   = CCFzcP.VVOpAW("\c00FA55E7", COLOR_SCHEME_NUM)
  VVwtwf    = CCFzcP.VVOpAW("\c00FF8F5F", COLOR_SCHEME_NUM)
  VVwhxm  = CCFzcP.VVOpAW("\c00FFC0C0", COLOR_SCHEME_NUM)
CCFzcP.VVMPcL()
class CCk4eB(Screen):
 def __init__(self, session, path, VVchL9):
  self.skin, self.skinParam = FFTWzO(VVkUAl, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVvlox   = path
  self.VVB9rY   = ""
  self.VVtBLL   = ""
  self.VVchL9    = VVchL9
  self.VVDvuS    = ""
  self.VVG9DX  = ""
  self.VV0iPC    = False
  self.VV6xm0  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VVjH8Z  = "enigma2-plugin-extensions-"
  self.VVpqp7  = "enigma2-plugin-systemplugins-"
  self.VVfv00 = "enigma2-"
  self.VV9kRe  = 0
  self.VVunLz  = 1
  self.VVUn7c  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVHLGe = "DEBIAN"
  else        : self.VVHLGe = "CONTROL"
  self.controlPath = self.Path + self.VVHLGe
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVchL9:
   self.packageExt  = ".deb"
   self.VVjLdB  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVjLdB  = "#11001020"
  FF0Q0u(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FF970D(self["keyRed"] , "Create")
  FF970D(self["keyGreen"] , "Post Install")
  FF970D(self["keyYellow"], "Installation Path")
  FF970D(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVT46x  ,
   "green"   : self.VVXOtq ,
   "yellow"  : self.VVtNzq  ,
   "blue"   : self.VVWvQa  ,
   "cancel"  : self.VV0YwQ
  }, -1)
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FFyHsQ(self)
  if self.VVjLdB:
   FFaCb6(self["myBody"], self.VVjLdB)
   FFaCb6(self["myLabel"], self.VVjLdB)
  self.VVckp7(True)
  self.VV8opU(True)
 def VV8opU(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVaf5l()
  if isFirstTime:
   if   package.startswith(self.VVjH8Z) : self.VVvlox = VVD9rK + self.VVDvuS + "/"
   elif package.startswith(self.VVpqp7) : self.VVvlox = VVaET3 + self.VVDvuS + "/"
   else            : self.VVvlox = self.Path
  if self.VV0iPC : myColor = VVwtwf
  else    : myColor = VVGCti
  txt  = ""
  txt += "Source Path\t: %s\n" % FFXe6i(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFXe6i(self.VVvlox, VVrhVl)
  if self.VVtBLL : txt += "Package File\t: %s\n" % FFXe6i(self.VVtBLL, VVycQx)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFXe6i("Check Control File fields : %s" % errTxt, VVpQzP)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFXe6i("Restart GUI", VVwtwf)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFXe6i("Reboot Device", VVwtwf)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FFXe6i("Post Install", VVhAfh), act)
  if not errTxt and VVpQzP in controlInfo:
   txt += "Warning\t: %s\n" % FFXe6i("Errors in control file may affect the result package.", VVpQzP)
  txt += "\nControl File\t: %s\n" % FFXe6i(self.controlFile, VVycQx)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVXOtq(self):
  if self["keyGreen"].getVisible():
   VVMYdC = []
   VVMYdC.append(("No Action"    , "noAction"  ))
   VVMYdC.append(("Restart GUI"    , "VVQkfz"  ))
   VVMYdC.append(("Reboot Device"   , "rebootDev"  ))
   FFcKE0(self, self.VVCkqY, title="Package Installation Option (after completing installation)", VVMYdC=VVMYdC)
 def VVCkqY(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVQkfz"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVckp7(False)
   self.VV8opU()
 def VVtNzq(self):
  rootPath = FFXe6i("/%s/" % self.VVDvuS, VVJ6nn)
  VVMYdC = []
  VVMYdC.append(("Current Path"        , "toCurrent"  ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Extension Path"       , "toExtensions" ))
  VVMYdC.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVMYdC.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFcKE0(self, self.VVNFMK, title="Installation Path", VVMYdC=VVMYdC)
 def VVNFMK(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVFAPv(FF9E33(self.Path, True))
   elif item == "toExtensions"  : self.VVFAPv(VVD9rK)
   elif item == "toSystemPlugins" : self.VVFAPv(VVaET3)
   elif item == "toRootPath"  : self.VVFAPv("/")
   elif item == "toRoot"   : self.VVFAPv("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVblrs, BF(CC5DZc, mode=CC5DZc.VVi95q, VVYwJg=VVXneu))
 def VVblrs(self, path):
  if len(path) > 0:
   self.VVFAPv(path)
 def VVFAPv(self, parent, withPackageName=True):
  if withPackageName : self.VVvlox = parent + self.VVDvuS + "/"
  else    : self.VVvlox = "/"
  mode = self.VVDjKr()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVirCz(mode), self.controlFile))
  self.VV8opU()
 def VVWvQa(self):
  if fileExists(self.controlFile):
   lines = FFgYB4(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFSAou(self, self.VVDI4q, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFu1fZ(self, "Version not found or incorrectly set !")
  else:
   FF6iwf(self, self.controlFile)
 def VVDI4q(self, VVO1nz):
  if VVO1nz:
   version, color = self.VVD4We(VVO1nz, False)
   if color == VVhW2e:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVO1nz, self.controlFile))
    self.VV8opU()
   else:
    FFu1fZ(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VV0YwQ(self):
  if self.newControlPath:
   if self.VV0iPC:
    self.VVwvME()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFXe6i(self.newControlPath, VVycQx)
    txt += FFXe6i("Do you want to keep these files ?", VVrhVl)
    FFlOO5(self, self.close, txt, callBack_No=self.VVwvME, title="Create Package", VV6ttc=True)
  else:
   self.close()
 def VVwvME(self):
  os.system(FFVKmy("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVirCz(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VVG9DX
  if package.startswith(self.VVfv00):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VVfv00, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VVunLz : prefix = self.VVjH8Z
  elif mode == self.VVUn7c : prefix = self.VVpqp7
  return (prefix + name).lower()
 def VVDjKr(self):
  if   self.VVvlox.startswith(VVD9rK) : return self.VVunLz
  elif self.VVvlox.startswith(VVaET3) : return self.VVUn7c
  else            : return self.VV9kRe
 def VVckp7(self, isFirstTime):
  self.VVDvuS   = FFUGmb(self.Path)
  self.VVDvuS   = "_".join(self.VVDvuS.split())
  self.VVG9DX = self.VVDvuS.lower()
  self.VV0iPC = self.VVG9DX == VVRq46.lower()
  if self.VV0iPC and self.VVG9DX.endswith("ajpan"):
   self.VVG9DX += "el"
  if self.VV0iPC : self.VVB9rY = VVXneu
  else    : self.VVB9rY = CFG.packageOutputPath.getValue()
  self.VVB9rY = FF5sxC(self.VVB9rY)
  if not pathExists(self.controlPath):
   os.system(FFVKmy("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VVDjKr()
  if fileExists(self.controlFile):
   lines = FFgYB4(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VV0iPC : version, descripton, maintainer = VV9qD9 , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVDvuS , self.VVDvuS
   txt = ""
   txt += "Package: %s\n"  % self.VVirCz(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VV0iPC : t = PLUGIN_NAME
  else    : t = self.VVDvuS
  self.VVNE12(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVNE12(self.postrmFile, "echo 'Package removed.'\n")
  if self.VV0iPC : self.VVNE12(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VV9qD9))
  else    : self.VVNE12(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVDvuS)
  if isFirstTime and not mode == self.VV9kRe:
   self.postInstAcion = 1
  txt = self.VVo1Vw(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFQgne(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VVo1Vw(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  os.system(FFVKmy("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
 def VVNE12(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VVo1Vw(self, action):
  sep  = "echo '%s'\n" % VVn31f
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VVaf5l(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFgYB4(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFXe6i(line, VVpQzP)
     elif not line.startswith(" ")    : line = FFXe6i(line, VVpQzP)
     else          : line = FFXe6i(line, VVhW2e)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVhW2e
   else   : color = VVpQzP
   descr = FFXe6i(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVpQzP
     elif line.startswith((" ", "\t")) : color = VVpQzP
     elif line.startswith("#")   : color = VVycQx
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVD4We(val, True)
      elif key == "Version"  : version, color = self.VVD4We(val, False)
      elif key == "Maintainer" : maint  , color = val, VVhW2e
      elif key == "Architecture" : arch  , color = val, VVhW2e
      else:
       color = VVhW2e
      if not key == "OE" and not key.istitle():
       color = VVpQzP
     else:
      color = VVwtwf
     txt += FFXe6i(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVtBLL = self.VVB9rY + packageName
   self.VV6xm0 = True
   errTxt = ""
  else:
   self.VVtBLL  = ""
   self.VV6xm0 = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVD4We(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVhW2e
  else          : return val, VVpQzP
 def VVT46x(self):
  if not self.VV6xm0:
   FFu1fZ(self, "Please fix Control File errors first.")
   return
  if self.VVchL9: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FF9E33(self.VVvlox, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVDvuS
  symlinkTo  = FFS9Oz(self.Path)
  dataDir   = self.VVvlox.rstrip("/")
  removePorjDir = FFVKmy("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFVKmy("rm -f '%s'" % self.VVtBLL) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FF0m4B()
  if self.VVchL9:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFcB05("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VV0iPC:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVvlox == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVHLGe)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVtBLL, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVtBLL
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVtBLL, FFrfWO(result  , VVhAfh))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVvlox, FFrfWO(instPath, VVhW2e))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFrfWO(failed, VVpQzP))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFrhsY(self, cmd)
class CC3Jx1():
 VV0Hcf  = "666"
 VVSxuC   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.menuInstance   = None
  self.VV9S9u()
 def VV9S9u(self):
  VVMYdC = CC3Jx1.VVJfY4()
  if VVMYdC:
   VVyvO2 = ("Create New", self.VV1SZ9)
   self.menuInstance = FFcKE0(self.SELF, self.VVnFFh, VVMYdC=VVMYdC, title=self.Title, VVyvO2=VVyvO2, VVglYk=True, VVI8Pk="#22222233", VV2s6D="#22222233")
  else:
   self.VV1SZ9()
 def VVnFFh(self, item):
  if item:
   bName, bRef, ndx = item
   self.VV09fm(bName, bRef)
  else:
   CC3Jx1.VVK8KK(self)
 def VV1SZ9(self, VVVCbtObj=None, item=None):
  FFSAou(self.SELF, BF(self.VV05ej), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VV05ej(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.menuInstance:
     self.menuInstance.cancel()
    self.VV09fm(bName, "")
   else:
    FFAcfo(self.menuInstance, "Incorrect Bouquet Name !", 2000)
    CC3Jx1.VVK8KK(self)
 def VV09fm(self, bName, bRef):
  FFZmix(self.waitMsgSELF, BF(self.VVQyYD, bName, bRef), title="Adding Services ...")
 def VVQyYD(self, bName, bRef):
  CC3Jx1.VVRn29(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVK8KK(classObj):
  del classObj
 @staticmethod
 def VVRn29(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FFu1fZ(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVPZMJ + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FF6iwf(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CC3Jx1.VVneYd(bRef)
   bPath = VVPZMJ + bFile
  else:
   fName = CC0A1M.VVnS9E(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVPZMJ + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVPZMJ + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  CC3Jx1.VVF3UC(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   CC3Jx1.VVF3UC(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CC2wnB.VV6OCP()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       os.system(FFVKmy("cp -f '%s' '%s'" % (poster, picon)))
       os.system(CChafy.VVA5VG(picon))
       break
  FFSSJm()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FF4gok(SELF, txt, title=title)
 @staticmethod
 def VVJfY4(mode=2, showTitle=True, prefix=""):
  VVMYdC = []
  if mode in (0, 2): VVMYdC.extend(CC3Jx1.VVbw4Y(0, showTitle, prefix))
  if mode in (1, 2): VVMYdC.extend(CC3Jx1.VVbw4Y(1, showTitle, prefix))
  return VVMYdC
 @staticmethod
 def VVbw4Y(mode, showTitle, prefix):
  VVMYdC = []
  lst = CC3Jx1.VVQkzJ(mode)
  if lst:
   if showTitle:
    VVMYdC.append(FFYdlI("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVMYdC.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVMYdC.append((item[0], item[1].toString()))
  return VVMYdC
 @staticmethod
 def VVT1MA():
  bLise = CC3Jx1.VVQkzJ(0)
  bLise.extend(CC3Jx1.VVQkzJ(1))
  return bLise
 @staticmethod
 def VVQkzJ(mode=0):
  bList = []
  VVGXkF = InfoBar.instance
  VVZe0z = VVGXkF and VVGXkF.servicelist
  if VVZe0z:
   curMode = VVZe0z.mode
   CC3Jx1.VV8Lb7(VVZe0z, mode)
   bList.extend(VVZe0z.getBouquetList() or [])
   CC3Jx1.VV8Lb7(VVZe0z, curMode)
  return bList
 @staticmethod
 def VV8Lb7(VVZe0z, mode):
  if not mode == VVZe0z.mode:
   if   mode == 0: VVZe0z.setModeTv()
   elif mode == 1: VVZe0z.setModeRadio()
 @staticmethod
 def VVF3UC(fPath):
  with open(fPath, "rb+") as f:
   try:
    f.seek(-1, 2)
    if ord(f.read(1)) not in (10, 13):
     f.write(b"\n")
   except:
    pass
 @staticmethod
 def VVneYd(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : ""
 @staticmethod
 def VVcSuS():
  try:
   fName = CC3Jx1.VVneYd(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVPZMJ, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VVEZDr():
  path = CC3Jx1.VVcSuS()
  if path:
   txt = FFQgne(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VVAVo4():
  return FFsJR6(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VVPCFM():
  lst = []
  for b in CC3Jx1.VVT1MA():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVPZMJ + CC3Jx1.VVneYd(bRef)
   if fileExists(path):
    lines = FFgYB4(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VVCLSe(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VVwBgp(SID="", stripRType=False):
  if SID : patt = CC3Jx1.VVCLSe(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CC3Jx1.VVT1MA():
   for service in FFsJR6(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VV7nhB():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CC3Jx1.VVT1MA():
   for service in FFsJR6(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVN7nC(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VV2Kfz(pathLst):
  refLst = CC3Jx1.VVwBgp(CC3Jx1.VV0Hcf, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CC3Jx1.VVN7nC(rType, CC3Jx1.VV0Hcf, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CC5DZc(Screen):
 VV4RO2   = 0
 VV7Flf  = 1
 VVi95q  = 2
 VVYFLK  = 3
 VVRzbc    = 20
 VVwYMY  = None
 def __init__(self, session, VVYwJg="/", mode=VV4RO2, VVGj9J="Select", height=920, VVJfxh=30, gotoMovie=False, jumpToFile=""):
  self.skin, self.skinParam = FFTWzO(VV4Y67, 1400, height, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FF0Q0u(self)
  FF970D(self["keyRed"] , "Exit" if mode == self.VV4RO2 else "Cancel")
  FF970D(self["keyYellow"], "More Options")
  FF970D(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVGj9J = VVGj9J
  self.jumpToFile   = jumpToFile
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = "#06003333"
  CC5DZc.VVwYMY = self
  if   self.jumpToFile       : VVznq5, self.VVYwJg = True , FF9E33(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VVznq5, self.VVYwJg = True , CC5DZc.VVektX(self)[1] or "/"
  elif self.mode == self.VV4RO2  : VVznq5, self.VVYwJg = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVi95q : VVznq5, self.VVYwJg = False, VVYwJg
  elif self.mode == self.VVYFLK : VVznq5, self.VVYwJg = True , VVYwJg
  else           : VVznq5, self.VVYwJg = True , VVYwJg
  self.VVYwJg = FF5sxC(self.VVYwJg)
  VVjiDQ = None
  if self.mode == self.VVYFLK:
   VVjiDQ = "^.*\.srt"
  self["myMenu"] = CCgKzL(  directory   = None
         , VVjiDQ = VVjiDQ
         , VVznq5   = VVznq5
         , VVYjjr = True
         , VV054x = True
         , VVOlpu   = self.skinParam["width"]
         , VVJfxh   = self.skinParam["bodyFontSize"]
         , VVIJkE  = self.skinParam["bodyLineH"]
         , VVgayn  = self.skinParam["bodyColor"]
         , pngBGColorSelStr = self.cursorBG)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVqqT1    ,
   "red"  : self.VVpCak   ,
   "green"  : self.VVXLeq,
   "yellow" : self.VVTw3U  ,
   "blue"  : self.VVHmaf ,
   "menu"  : self.VV6ObO  ,
   "info"  : self.VVCaWP  ,
   "cancel" : self.VV7KEv    ,
   "pageUp" : self.VV0ASk   ,
   "chanUp" : self.VV0ASk
  }, -1)
  FFINwU(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VV9xRt)
 def onExit(self):
  CC5DZc.VVwYMY = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VV9xRt)
  FFKT7W(self)
  FF4IYg(self["myMenu"], bg=self.cursorBG)
  FFyHsQ(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVi95q, self.VVYFLK):
   FF970D(self["keyGreen"], self.VVGj9J)
   color = "#22000022"
   FFaCb6(self["myBody"], color)
   FFaCb6(self["myMenu"], color)
   color = "#22220000"
   FFaCb6(self["myTitle"], color)
   FFaCb6(self["myBar"], color)
  self.VV9xRt()
  if self.VV6xrC(self.VVYwJg) > self.bigDirSize: FFZmix(self, self.VVqrCD, title="Changing directory...")
  else              : self.VVqrCD()
 def VVqrCD(self):
  if self.jumpToFile : self.VVB9hP(self.jumpToFile)
  elif self.gotoMovie : self.VVSkmO(chDir=False)
  else    : self["myMenu"].VVjfyN(self.VVYwJg)
 def VVjS0j(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VViTw0(self):
  self["myMenu"].refresh()
  FFaAOh()
 def VV6xrC(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VVqqT1(self):
  if self["myMenu"].VVL548() : self.VVlOic()
  else       : self.VVmc9c()
 def VV0ASk(self):
  self["myMenu"].moveToIndex(0)
  if self["myMenu"].VV8GwE():
   self.VVlOic()
 def VVlOic(self, isDirUp=False):
  if self["myMenu"].VVL548():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVxCjX(self.VVVCbt())
   if self.VV6xrC(path) > self.bigDirSize : FFZmix(self, self.VVQeVH, title="Changing directory...")
   else           : self.VVQeVH()
 def VVQeVH(self):
  self["myMenu"].descent()
  self.VV9xRt()
 def VV7KEv(self):
  if CFG.FileManagerExit.getValue() == "e": self.VVpCak()
  else         : self.VV0ASk()
 def VVpCak(self):
  if not FFz45k(self):
   self.close("")
 def VVXLeq(self):
  path = self.VVxCjX(self.VVVCbt())
  if self.mode == self.VVi95q:
   self.close(path)
  elif self.mode == self.VVYFLK:
   if os.path.isfile(path) : self.close(path)
   else     : FFAcfo(self, "Only .srt files", 1000)
 def VVCaWP(self):
  if not self.mode == self.VVYFLK:
   FFZmix(self, self.VVzAhx, title="Calculating size ...")
 def VVzAhx(self):
  path = self.VVxCjX(self.VVVCbt())
  param = self.VV3uUA(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFY14S("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CC5DZc.VVbQpT(path)
     freeSize = CC5DZc.VVcRWj(path)
     size = totSize - freeSize
     totSize  = CC5DZc.VVmkPo(totSize)
     freeSize = CC5DZc.VVmkPo(freeSize)
    else:
     size = FFY14S("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CC5DZc.VVmkPo(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFXe6i(pathTxt, VVwtwf) + "\n"
   if slBroken : fileTime = self.VV16nR(path)
   else  : fileTime = self.VVTueT(path)
   def VV3eCd(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VV3eCd("Path"    , pathTxt)
   txt += VV3eCd("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VV3eCd("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VV3eCd("Total Size"   , "%s" % totSize)
    txt += VV3eCd("Used Size"   , "%s" % usedSize)
    txt += VV3eCd("Free Size"   , "%s" % freeSize)
   else:
    txt += VV3eCd("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VV3eCd("Owner"    , owner)
   txt += VV3eCd("Group"    , group)
   txt += VV3eCd("Perm. (User)"  , permUser)
   txt += VV3eCd("Perm. (Group)"  , permGroup)
   txt += VV3eCd("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VV3eCd("Perm. (Ext.)" , permExtra)
   txt += VV3eCd("iNode"    , iNode)
   txt += VV3eCd("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVn31f, VVn31f)
    txt += hLinkedFiles
   txt += self.VVEuAj(path)
  else:
   FFu1fZ(self, "Cannot access information !")
  if len(txt) > 0:
   FF4gok(self, txt)
 def VV3uUA(self, path):
  path = path.strip()
  path = FFS9Oz(path)
  result = FFY14S("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVlzSA(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVlzSA(perm, 1, 4)
   permGroup = VVlzSA(perm, 4, 7)
   permOther = VVlzSA(perm, 7, 10)
   permExtra = VVlzSA(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFPjNy("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVEuAj(self, path):
  txt  = ""
  res  = FFY14S("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFXe6i("File Attributes:", VVDDRU), txt)
  return txt
 def VVTueT(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FF2ogC(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FF2ogC(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FF2ogC(os.path.getctime(path))
  return txt
 def VV16nR(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFY14S("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFY14S("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFY14S("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVxCjX(self, currentSel):
  currentDir  = self["myMenu"].VVy5TC()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVL548():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVVCbt(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VV9xRt(self):
  path = self.VVxCjX(self.VVVCbt())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVSQ8u()
  if self.mode == self.VV4RO2 and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
  if self.mode == self.VVYFLK and len(path) > 0 : self["keyInfo"].hide()
  else               : self["keyInfo"].show()
  if self.mode == self.VVYFLK:
   path = self.VVxCjX(self.VVVCbt())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVSQ8u(self):
  if self.VVI4Vo() : self["keyBlue"].show()
  else      : self["keyBlue"].hide()
 def VV6ObO(self):
  if self.mode == self.VV4RO2:
   color1  = VVwhxm
   color2  = VVJ6nn
   path  = self.VVxCjX(self.VVVCbt())
   VVMYdC = []
   VVMYdC.append(("Properties", "properties"))
   if os.path.isdir(path):
    if not self.VVtys1(path):
     VVMYdC.append(VVc27s)
     VVMYdC.append((color1 + "Archiving / Packaging", "VVCtOd_dir"))
   elif os.path.isfile(path):
    selFile = self.VVVCbt()
    isArch = selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar"))
    if not isArch:
     VVMYdC.append((color1 + "Archive ...", "VVCtOd_file"))
    isText = False
    txt = ""
    if   isArch            : VVMYdC.extend(self.VVeWqL(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith(".m3u")       : VVMYdC.extend(self.VVoeUS(True))
    elif selFile.endswith(".sh"):
     VVMYdC.extend(self.VVvoxu(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CC5DZc.VV6u9i(path):
     VVMYdC.append(VVc27s)
     VVMYdC.append((color2 + "View"     , "textView_def"))
     VVMYdC.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVMYdC.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVxkfz(path) == "pic":
     if selFile.lower().endswith((".jpg", ".png")) and FFqrNW("ffmpeg"):
      VVMYdC.append(VVc27s)
      VVMYdC.append((color2 + "Convert to MVI (1280 x 720 )", "VVcRl8Hd"))
      VVMYdC.append((color2 + "Convert to MVI (1920 x 1080)", "VVcRl8Fhd"))
    elif selFile.endswith(CC5DZc.VV4Gt6()):
     if selFile.endswith(".mvi"):
      if FFqrNW("showiframe"):
       VVMYdC.append(VVc27s)
       VVMYdC.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVMYdC.append(VVc27s)
      VVMYdC.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVMYdC.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
    if isText:
     VVMYdC.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVMYdC.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVMYdC.append((color1 + "Convert Line-Breaks to Unix Format..." , "VVF1rw" ))
    if len(txt) > 0:
     VVMYdC.append(VVc27s)
     VVMYdC.append((color1 + txt, "VVmc9c"))
   VVMYdC.append(VVc27s)
   VVMYdC.append(("Create SymLink", "VVYRmb"))
   if not self.VVtys1(path):
    VVMYdC.append(("Rename"      , "VVTzdh" ))
    VVMYdC.append(("Copy"       , "copyFileOrDir" ))
    VVMYdC.append(("Move"       , "moveFileOrDir" ))
    VVMYdC.append((VVpQzP + "DELETE" , "VVbjUQ" ))
    if fileExists(path):
     VVMYdC.append(VVc27s)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVMYdC.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVMYdC.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVMYdC.append((chmodTxt + "777)", "chmod777"))
   c = VV2RHA
   VVMYdC.append(VVc27s)
   VVMYdC.append((c + "Create New File (in current directory)"  , "createNewFile" ))
   VVMYdC.append((c + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CC5DZc.VVektX(self)
   if fPath:
    VVMYdC.append(VVc27s)
    VVMYdC.append((color2 + "Go to Current Movie Dir", "VVSkmO"))
   FFcKE0(self, self.VVeH2B, height=1050, title="Options", VVMYdC=VVMYdC, VVI8Pk="#00101020", VV2s6D="#00101A2A")
 def VVeH2B(self, item=None):
  if self.mode == self.VV4RO2:
   if item is not None:
    path = self.VVxCjX(self.VVVCbt())
    selFile = self.VVVCbt()
    if   item == "properties"    : self.VVCaWP()
    elif item == "VVCtOd_dir" : self.VVCtOd(path, True)
    elif item == "VVCtOd_file" : self.VVCtOd(path, False)
    elif item == "VV2Hm6"  : self.VV2Hm6(path)
    elif item == "VV6Vuc"  : self.VV6Vuc(path)
    elif item.startswith("extract_")  : self.VVNnJ2(path, selFile, item)
    elif item.startswith("script_")   : self.VV6W28(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVblnV(path, selFile, item)
    elif item.startswith("textView_def") : FFVPiE(self, path)
    elif item.startswith("textView_enc") : self.VVP7dY(path)
    elif item.startswith("text_Edit")  : FFZmix(self, BF(CCV79S, self, path), title="Opening File ...")
    elif item.startswith("textSave_encUtf8"): self.VVlYiy(path, "Save as UTF-8"   , True)
    elif item.startswith("textSave_encOthr"): self.VVlYiy(path, "Save as Other Encoding", False)
    elif item.startswith("VVF1rw") : self.VVF1rw(path)
    elif item == "viewAsBootlogo"   : self.VVinsH(path, True)
    elif item == "addMovieToBouquet"  : self.VVUy1u(path, False)
    elif item == "addAllMoviesToBouquet" : self.VVUy1u(path, True)
    elif item == "VVcRl8Hd"   : FFZmix(self, BF(self.VVcRl8, path, False))
    elif item == "VVcRl8Fhd"   : FFZmix(self, BF(self.VVcRl8, path, True))
    elif item == "VVYRmb"   : self.VVYRmb(path, selFile)
    elif item == "VVTzdh"   : self.VVTzdh(path, selFile)
    elif item == "copyFileOrDir"   : self.VVvsHC(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVvsHC(path, selFile, True)
    elif item == "VVbjUQ"   : self.VVbjUQ(path, selFile)
    elif item == "chmod644"     : self.VVBL7R(path, selFile, "644")
    elif item == "chmod755"     : self.VVBL7R(path, selFile, "755")
    elif item == "chmod777"     : self.VVBL7R(path, selFile, "777")
    elif item == "createNewFile"   : self.VV9XaB(path, True)
    elif item == "createNewDir"    : self.VV9XaB(path, False)
    elif item == "VVSkmO"   : self.VVSkmO()
    elif item == "VVmc9c"    : self.VVmc9c()
 def VVmc9c(self):
  if self.mode == self.VVYFLK:
   return
  selFile = self.VVVCbt()
  path  = self.VVxCjX(selFile)
  if os.path.isfile(path):
   VVOBG5  = []
   category = self["myMenu"].VVxkfz(path)
   if   category == "pic"      : CCKf0K.VVAHGG(self, path)
   elif category == "txt"      : FFVPiE(self, path)
   elif category in ("tar", "zip", "rar")  : self.VVOu2k(path, selFile)
   elif category == "scr"      : self.VVtr5d(path, selFile)
   elif category == "m3u"      : self.VVtBgs(path, selFile)
   elif category in ("ipk", "deb")    : self.VVQtyg(path, selFile)
   elif category in ("mov", "mus")    : self.VVinsH(path)
   elif not CC5DZc.VV6u9i(path) : FFVPiE(self, path)
 def VVinsH(self, path, asLogo=False):
  if asLogo : CCebnr.VV1oWQ(self, path)
  else  : FFZmix(self, BF(self.VVhhEZ,self, path), title="Playing Media ...")
 def VVHmaf(self):
  if self["keyBlue"].getVisible():
   VVL1iO = self.VVI4Vo()
   if VVL1iO:
    path = self.VVxCjX(self.VVVCbt())
    enableGreenBtn = False if path in self.VVI4Vo() else True
    newList = []
    for line in VVL1iO:
     newList.append((line, line))
    VVM2qe  = ("Delete"    , self.VVmvVd    )
    VVAfNY  = ("Add Current Dir"   , BF(self.VVRag7, path) ) if enableGreenBtn else None
    VVyvO2 = ("Move Up"     , self.VVDbjA    )
    VVtkPa  = ("Move Down"   , self.VVWUyE    )
    self.bookmarkMenu = FFcKE0(self, self.VV7tOz, width=1200, title="Bookmarks", VVMYdC=newList, minRows=10 ,VVM2qe=VVM2qe, VVAfNY=VVAfNY, VVyvO2=VVyvO2, VVtkPa=VVtkPa, VVI8Pk="#00000022", VV2s6D="#00000022")
 def VVmvVd(self, menuInstance=None, path=None):
  VVL1iO = self.VVI4Vo()
  if VVL1iO:
   while path in VVL1iO:
    VVL1iO.remove(path)
   self.VV0AoX(VVL1iO)
  if self.bookmarkMenu:
   self.bookmarkMenu.VVUdLz(VVL1iO)
   self.bookmarkMenu.VVGqYd(("Add Current Dir", BF(self.VVRag7, path)))
  else:
   FFAcfo(self, "Removed", 800)
  self.VVSQ8u()
 def VVRag7(self, path, menuInstance=None, item=None):
  VVL1iO = self.VVI4Vo()
  if len(VVL1iO) >= self.VVRzbc:
   FFu1fZ(SELF, "Max bookmarks reached (max=%d)." % self.VVRzbc)
  elif not path in VVL1iO:
   newList = [path] + VVL1iO
   self.VV0AoX(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VVUdLz(newList)
    self.bookmarkMenu.VVGqYd()
   else:
    FFAcfo(self, "Added", 800)
  self.VVSQ8u()
 def VVDbjA(self, VVVCbtObj, path):
  if self.bookmarkMenu:
   VVL1iO = self.bookmarkMenu.VVCl3X(True)
   if VVL1iO:
    self.VV0AoX(VVL1iO)
 def VVWUyE(self, VVVCbtObj, path):
  if self.bookmarkMenu:
   VVL1iO = self.bookmarkMenu.VVCl3X(False)
   if VVL1iO:
    self.VV0AoX(VVL1iO)
 def VV7tOz(self, folder=None):
  if folder:
   folder = FF5sxC(folder)
   self["myMenu"].VVjfyN(folder)
   self["myMenu"].moveToIndex(0)
  self.VV9xRt()
 def VVI4Vo(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VVBzpA(self):
  return True if VVI4Vo() else False
 def VV0AoX(self, VVL1iO):
  line = ",".join(VVL1iO)
  FF72vQ(CFG.browserBookmarks, line)
 def VVB9hP(self, path):
  if fileExists(path):
   fDir  = FF5sxC(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVjfyN(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFAcfo(self, "Not found", 1000)
 def VVSkmO(self, chDir=True):
  fPath, fDir, fName = CC5DZc.VVektX(self)
  self.VVB9hP(fPath)
 def VVTw3U(self):
  path = self.VVxCjX(self.VVVCbt())
  isAdd = False if path in self.VVI4Vo() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  VVMYdC = []
  VVMYdC.append(   ("Find Files ..."      , "find" ))
  VVMYdC.append(   ("Sort ..."        , "sort" ))
  VVMYdC.append(VVc27s)
  if isAdd: VVMYdC.append( ("Add %s Dir to Bookmarks" % dirTxt  , "addBM" ))
  else : VVMYdC.append( ("Remove %s Dir from Bookmarks" % dirTxt, "remBM" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(   ('Set %s Dir as "Startup Dir"' % dirTxt , "start" ))
  FFcKE0(self, BF(self.VVW68Q, path), width=750, title="More Options", VVMYdC=VVMYdC, VVI8Pk="#00221111", VV2s6D="#00221111")
 def VVW68Q(self, path, item):
  if item:
   if   item == "find" : self.VVeRzg(path)
   elif item == "sort" : self.VVfX5D()
   elif item == "addBM": self.VVRag7(path)
   elif item == "remBM": self.VVmvVd(None, path)
   elif item == "start": self.VVSLac(path)
 def VVeRzg(self, path):
  VVMYdC = []
  VVMYdC.append(("Find in Current Directory"    , "findCur"  ))
  VVMYdC.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVMYdC.append(("Find in all Storage Systems"    , "findAll"  ))
  FFcKE0(self, BF(self.VVnEOQ, path), width=700, title="Find File/Pattern", VVMYdC=VVMYdC, VVglYk=True, VVKpZE=True, VVI8Pk="#00221111", VV2s6D="#00221111")
 def VVnEOQ(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VVGo8n(0, path, title)
   elif item == "findCurR" : self.VVGo8n(1, path, title)
   elif item == "findAll" : self.VVGo8n(2, path, title)
 def VVGo8n(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FFSAou(self, BF(self.VVgqRs, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVgqRs(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FF72vQ(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FFAcfo(self, "No entery", 1500)
   elif badLst  : FFAcfo(self, "Too many file !", 1500)
   else   : FFZmix(self, BF(self.VVXhv0, mode, path, title, filePatt), title="Searching ...", clearMsg=False)
 def VVXhv0(self, mode, path, title, filePatt):
  FFAcfo(self)
  lst = FFEUax(FFy6bC("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   if len(lst) == 1 and lst[0] == VVGEJv:
    FFu1fZ(self, VVGEJv)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VVDAgH = (""     , self.VVfgAy , [])
    VVgAHl = ("Go to File Location", self.VVyMry  , [])
    FFMPky(self, None, title="%s : %s" % (title, filePatt), header=header, VVL1iO=lst, VVLkOa=widths, VVJfxh=26, VVDAgH=VVDAgH, VVgAHl=VVgAHl)
  else:
   FFAcfo(self, "Not found !", 2000)
 def VVyMry(self, VVoyO8, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVoyO8.cancel()
   self.VVB9hP(path)
  else:
   FFAcfo(VVoyO8, "Path not found !", 1000)
 def VVfgAy(self, VVoyO8, title, txt, colList):
  txt = "%s\n%s\n\n" % (FFXe6i("File:"  , VVJ6nn), colList[0])
  txt += "%s\n%s"  % (FFXe6i("Directory:", VVJ6nn), FF5sxC(colList[1]))
  FF4gok(VVoyO8, txt, title=title)
 def VVfX5D(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVSxiY()
  VVMYdC = []
  VVMYdC.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVMYdC.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVMYdC.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVMYdC.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVtkPa = ("Mix", BF(self.VVFM10, True))
  FFcKE0(self, BF(self.VVXuE1, False), barText=txt, width=650, title="Sort Options", VVMYdC=VVMYdC, VVtkPa=VVtkPa, VVKpZE=True, VVI8Pk="#00221111", VV2s6D="#00221111")
 def VVFM10(self, isMix, menuInstance, item):
  self.VVXuE1(True, item)
 def VVXuE1(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVSxiY()
   title = "Sorting ... "
   if   item == "nameAlp": FFZmix(self, BF(self["myMenu"].VVBU7p, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FFZmix(self, BF(self["myMenu"].VVBU7p, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FFZmix(self, BF(self["myMenu"].VVBU7p, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FFZmix(self, BF(self["myMenu"].VVBU7p, typeMode , isMix, False), title=title)
 def VVSLac(self, path):
  if not os.path.isdir(path):
   path = FF9E33(path, True)
  FF72vQ(CFG.browserStartPath, path)
  FFAcfo(self, "Done", 500)
 def VV8d5n(self, selFile, VVbvpB, command):
  FFlOO5(self, BF(FFrhsY, self, command, VVY0RJ=self.VViTw0), "%s\n\n%s" % (VVbvpB, selFile))
 def VVeWqL(self, path, calledFromMenu):
  destPath = self.VVCVhG(path)
  lastPart = FFUGmb(destPath)
  VVMYdC = []
  if calledFromMenu:
   VVMYdC.append(VVc27s)
   color = VVJ6nn
  else:
   color = ""
  VVMYdC.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVMYdC.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVMYdC.append((color + "Extract Here"            , "extract_here"  ))
  if iTar and iZip:
   if path.endswith(".zip"):
    if not calledFromMenu: VVMYdC.append(VVc27s)
    VVMYdC.append((color + "Convert .zip to .tar.gz"       , "VV2Hm6" ))
   elif path.endswith(".tar.gz"):
    if not calledFromMenu: VVMYdC.append(VVc27s)
    VVMYdC.append((color + "Convert .tar.gz to .zip"       , "VV6Vuc" ))
  return VVMYdC
 def VVOu2k(self, path, selFile):
  FFcKE0(self, BF(self.VVNnJ2, path, selFile), title="Compressed File Options", VVMYdC=self.VVeWqL(path, False))
 def VVNnJ2(self, path, selFile, item=None):
  if item is not None:
   parent  = FF9E33(path, False)
   destPath = self.VVCVhG(path)
   lastPart = FFUGmb(destPath)
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVn31f
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFcB05("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFcB05("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVn31f, VVn31f)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFaGWF(self, cmd)
   elif path.endswith(".zip"):
    if item == "VV2Hm6" : self.VV2Hm6(path)
    else       : self.VVDUXS(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "VV6Vuc" and path.endswith(".tar.gz"):
    self.VV6Vuc(path)
   elif path.endswith(".rar"):
    self.VVEYP9(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFVKmy("mkdir '%s'"   % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VV8d5n(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VV8d5n(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FF9E33(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VV8d5n(selFile, "Extract Here ?"      , cmd)
 def VVCVhG(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVDUXS(self, item, path, parent, destPath, VVbvpB):
  FFlOO5(self, BF(self.VVKZpN, item, path, parent, destPath), VVbvpB)
 def VVKZpN(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVn31f
  cmd  = FFcB05("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFrfWO(destPath, VVhAfh))
  cmd +=   sep
  cmd += "fi;"
  FFitBw(self, cmd, VVY0RJ=self.VViTw0)
 def VVEYP9(self, item, path, parent, destPath, VVbvpB):
  FFlOO5(self, BF(self.VV5fAh, item, path, parent, destPath), VVbvpB)
 def VV5fAh(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FF5sxC(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVn31f
  cmd  = FFcB05("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFrfWO(destPath, VVhAfh))
  cmd +=   sep
  cmd += "fi;"
  FFitBw(self, cmd, VVY0RJ=self.VViTw0)
 def VVvoxu(self, addSep=False):
  VVMYdC = []
  if addSep:
   VVMYdC.append(VVc27s)
  VVMYdC.append((VVJ6nn + "View Script File"  , "script_View"  ))
  VVMYdC.append((VVJ6nn + "Execute Script File" , "script_Execute" ))
  VVMYdC.append((VVJ6nn + "Edit"     , "script_Edit" ))
  return VVMYdC
 def VVtr5d(self, path, selFile):
  FFcKE0(self, BF(self.VV6W28, path, selFile), title="Script File Options", VVMYdC=self.VVvoxu())
 def VV6W28(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFVPiE(self, path)
   elif item == "script_Execute" : self.VV8d5n(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCV79S(self, path)
 def VVoeUS(self, addSep=False):
  VVMYdC = []
  if addSep:
   VVMYdC.append(VVc27s)
  VVMYdC.append((VVJ6nn + "Browse IPTV Channels"  , "m3u_Browse" ))
  VVMYdC.append((VVJ6nn + "Edit"      , "m3u_Edit" ))
  VVMYdC.append((VVJ6nn + "View"      , "m3u_View" ))
  return VVMYdC
 def VVtBgs(self, path, selFile):
  FFcKE0(self, BF(self.VVblnV, path, selFile), title="M3U/M3U8 File Options", VVMYdC=self.VVoeUS())
 def VVblnV(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFZmix(self, BF(self.session.open, CC0A1M, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCV79S(self, path)
   elif item == "m3u_View"  : FFVPiE(self, path)
 def VVP7dY(self, path):
  if fileExists(path) : FFZmix(self, BF(CCSqSs.VVRJTe, self, path, BF(self.VVdprs, path)), title="Loading Codecs ...", clearMsg=False)
  else    : FF6iwf(self, path)
 def VVdprs(self, path, item=None):
  if item:
   FFVPiE(self, path, encLst=item)
 def VVlYiy(self, path, title, asUtf8):
  if fileExists(path) : FFZmix(self, BF(CCSqSs.VVRJTe, self, path, BF(self.VVgPnI, path, title, asUtf8), title="Original Encoding"), clearMsg=False, title="Loading Codecs ...")
  else    : FF6iwf(self, path)
 def VVgPnI(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8 : self.VVu1M0(path, title, fromEnc, "UTF-8")
   else  : CCSqSs.VVRJTe(self, path,  BF(self.VVu1M0, path, title, fromEnc), onlyWorkingEnc=False, title="Convert to Encoding")
 def VVu1M0(self, path, title, fromEnc, toEnc):
  if toEnc:
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FFXe6i("Successful\n\n", VVhAfh)
      txt += FFXe6i("From Encoding (%s):\n" % fromEnc, VVrhVl)
      txt += "%s\n\n" % path
      txt += FFXe6i("To Encoding (%s):\n" % toEnc, VVrhVl)
      txt += "%s\n\n" % outFile
      FF4gok(self, txt, title=title)
    except:
     FFu1fZ(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FFAcfo(self, "Cannot open file", 2000)
  self.VViTw0()
 def VVF1rw(self, path):
  title = "File Line-Break Conversion"
  FFlOO5(self, BF(self.VVJPG7, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVJPG7(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FFXe6i("File converted:", VVhAfh), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FF5VuW(self, txt, title=title)
  else:
   FF6iwf(self, path, title=title)
 def VVBL7R(self, path, selFile, newChmod):
  FFlOO5(self, BF(self.VVibZs, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVibZs(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VV9ECk)
  result = FFY14S(cmd)
  if result == "Successful" : FF5VuW(self, result)
  else      : FFu1fZ(self, result)
 def VVYRmb(self, path, selFile):
  parent = FF9E33(path, False)
  self.session.openWithCallback(self.VVWVJe, BF(CC5DZc, mode=CC5DZc.VVi95q, VVYwJg=parent, VVGj9J="Create Symlink here"))
 def VVWVJe(self, newPath):
  if len(newPath) > 0:
   target = self.VVxCjX(self.VVVCbt())
   target = FFS9Oz(target)
   linkName = FFUGmb(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FF5sxC(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFu1fZ(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFlOO5(self, BF(self.VVl6lj, target, link), "Create Soft Link ?\n\n%s" % txt, VV6ttc=True)
 def VVl6lj(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VV9ECk)
  result = FFY14S(cmd)
  if result == "Successful" : FF5VuW(self, result)
  else      : FFu1fZ(self, result)
 def VVTzdh(self, path, selFile):
  lastPart = FFUGmb(path)
  FFSAou(self, BF(self.VVp1Xt, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVp1Xt(self, path, selFile, VVO1nz):
  if VVO1nz:
   parent = FF9E33(path, True)
   if os.path.isdir(path):
    path = FFS9Oz(path)
   newName = parent + VVO1nz
   cmd = "mv '%s' '%s' %s" % (path, newName, VV9ECk)
   if VVO1nz:
    if selFile != VVO1nz:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFlOO5(self, BF(self.VVN9XO, cmd), message, title="Rename file?")
    else:
     FFu1fZ(self, "Cannot use same name!", title="Rename")
 def VVN9XO(self, cmd):
  result = FFY14S(cmd)
  if "Fail" in result:
   FFu1fZ(self, result)
  self.VViTw0()
 def VVvsHC(self, path, selFile, isMove):
  if isMove : VVGj9J = "Move to here"
  else  : VVGj9J = "Paste here"
  parent = FF9E33(path, False)
  self.session.openWithCallback(BF(self.VVruXq, isMove, path, selFile)
         , BF(CC5DZc, mode=CC5DZc.VVi95q, VVYwJg=parent, VVGj9J=VVGj9J))
 def VVruXq(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = FFUGmb(path)
   if os.path.isdir(path):
    path = FFS9Oz(path)
   newPath = FF5sxC(newPath)
   dest = newPath + lastPart
   if os.path.isdir(path) and os.path.isdir(dest):
    if isMove:
     FFu1fZ(self, 'Same directory already exists:\n\n%s\n\n( Try to copy then delete the source )' % dest)
     return
    else:
     dest = newPath
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFlOO5(self, BF(FFlXTd, self, cmd, VVY0RJ=self.VViTw0), txt, VV6ttc=True)
   else:
    FFu1fZ(self, "Cannot %s to same directory !" % action.lower())
 def VVbjUQ(self, path, fileName):
  path = FFS9Oz(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFlOO5(self, BF(self.VVIFYe, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVIFYe(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VViTw0()
 def VVtys1(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVxnW2 and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VV9XaB(self, path, isFile):
  dirName = FF5sxC(os.path.dirname(path))
  if isFile : objName, VVO1nz = "File"  , self.edited_newFile
  else  : objName, VVO1nz = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFSAou(self, BF(self.VVUsd0, dirName, isFile, title), title=title, defaultText=VVO1nz, message="Enter %s Name:" % objName)
 def VVUsd0(self, dirName, isFile, title, VVO1nz):
  if VVO1nz:
   if isFile : self.edited_newFile = VVO1nz
   else  : self.edited_newDir  = VVO1nz
   path = dirName + VVO1nz
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VV9ECk)
    else  : cmd = "mkdir '%s' %s" % (path, VV9ECk)
    result = FFY14S(cmd)
    if "Fail" in result:
     FFu1fZ(self, result)
    self.VViTw0()
   else:
    FFu1fZ(self, "Name already exists !\n\n%s" % path, title)
 def VVQtyg(self, path, selFile):
  c1, c2, c3 = VV80mJ, VVJ6nn, VVwhxm
  VVMYdC = []
  VVMYdC.append((c1 + "List Package Files"         , "VVzoVk"     ))
  VVMYdC.append((c1 + "Package Information"         , "VVg7d2"     ))
  VVMYdC.append(VVc27s)
  VVMYdC.append((c2 + "Install Package"          , "VVeWV8_CheckVersion" ))
  VVMYdC.append((c2 + "Install Package (force reinstall)"     , "VVeWV8_ForceReinstall" ))
  VVMYdC.append((c2 + "Install Package (force overwrite)"     , "VVeWV8_ForceOverwrite" ))
  VVMYdC.append((c2 + "Install Package (force downgrade)"     , "VVeWV8_ForceDowngrade" ))
  VVMYdC.append((c2 + "Install Package (ignore failed dependencies)"  , "VVeWV8_IgnoreDepends" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append((c3 + "Remove Related Package"        , "VVCLi8_ExistingPackage" ))
  VVMYdC.append((c3 + "Remove Related Package (force remove)"    , "VVCLi8_ForceRemove"  ))
  VVMYdC.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VVCLi8_IgnoreDepends" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Extract Files"           , "VVR4r5"     ))
  VVMYdC.append(("Unbuild Package"           , "VVnDt9"     ))
  FFcKE0(self, BF(self.VVMTrc, path, selFile), VVMYdC=VVMYdC)
 def VVMTrc(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVzoVk"      : self.VVzoVk(path, selFile)
   elif item == "VVg7d2"      : self.VVg7d2(path)
   elif item == "VVeWV8_CheckVersion"  : self.VVeWV8(path, selFile, VVuVG6     )
   elif item == "VVeWV8_ForceReinstall" : self.VVeWV8(path, selFile, VVIf8A )
   elif item == "VVeWV8_ForceOverwrite" : self.VVeWV8(path, selFile, VVz9Zr )
   elif item == "VVeWV8_ForceDowngrade" : self.VVeWV8(path, selFile, VVpCbq )
   elif item == "VVeWV8_IgnoreDepends" : self.VVeWV8(path, selFile, VV5bJt )
   elif item == "VVCLi8_ExistingPackage" : self.VVCLi8(path, selFile, VVa96X     )
   elif item == "VVCLi8_ForceRemove"  : self.VVCLi8(path, selFile, VVDj0x  )
   elif item == "VVCLi8_IgnoreDepends"  : self.VVCLi8(path, selFile, VVYhjR )
   elif item == "VVR4r5"     : self.VVR4r5(path, selFile)
   elif item == "VVnDt9"     : self.VVnDt9(path, selFile)
   else           : self.close()
 def VVzoVk(self, path, selFile):
  if FFqrNW("ar") : cmd = "allOK='1';"
  else    : cmd  = FF0m4B()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVn31f, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVn31f, VVn31f)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFEJxo(self, cmd, VVY0RJ=self.VViTw0)
 def VVR4r5(self, path, selFile):
  lastPart = FFUGmb(path)
  dest  = FF9E33(path, True) + selFile[:-4]
  cmd  =  FF0m4B()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFVKmy("mkdir '%s'" % dest) + ";"
  cmd +=    FFVKmy("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFrfWO(dest, VVhAfh))
  cmd += "fi;"
  FFrhsY(self, cmd, VVY0RJ=self.VViTw0)
 def VVnDt9(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVVgGW = os.path.splitext(path)[0]
  else        : VVVgGW = path + "_"
  if path.endswith(".deb")   : VVHLGe = "DEBIAN"
  else        : VVHLGe = "CONTROL"
  cmd  = FF0m4B()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVVgGW, FFrViP())
  cmd += "  mkdir '%s';"    % VVVgGW
  cmd += "  CONTPATH='%s/%s';"  % (VVVgGW, VVHLGe)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVVgGW
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVVgGW, VVVgGW)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVVgGW
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVVgGW, VVVgGW)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVVgGW
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVVgGW
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVVgGW, FFrfWO(VVVgGW, VVhAfh))
  cmd += "fi;"
  FFrhsY(self, cmd, VVY0RJ=self.VViTw0)
 def VVg7d2(self, path):
  listCmd  = FF7FNT(VV8UyW, "")
  infoCmd  = FF9JgI(VVF4LK , "")
  filesCmd = FF9JgI(VV4LAz, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFHmje(VVrhVl)
   notInst = "Package not installed."
   cmd  = FFEL4q("File Info", VVrhVl)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFEL4q("System Info", VVrhVl)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFrfWO(notInst, VVwtwf))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFEL4q("Related Files", VVrhVl)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFaGWF(self, cmd)
  else:
   FF0x3g(self)
 def VVeWV8(self, path, selFile, cmdOpt):
  cmd = FF9JgI(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFlOO5(self, BF(FFrhsY, self, cmd, VVY0RJ=FFaAOh), "Install Package ?\n\n%s" % selFile)
  else:
   FF0x3g(self)
 def VVCLi8(self, path, selFile, cmdOpt):
  listCmd  = FF7FNT(VV8UyW, "")
  infoCmd  = FF9JgI(VVF4LK, "")
  instRemCmd = FF9JgI(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFrfWO(errTxt, VVwtwf))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFrfWO(cannotTxt, VVwtwf))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFrfWO(tryTxt, VVwtwf))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFlOO5(self, BF(FFrhsY, self, cmd, VVY0RJ=FFaAOh), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FF0x3g(self)
 def VVIQht(self, path):
  hostName = FFY14S("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVCtOd(self, path, isDir):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVMYdC = []
  VVMYdC.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVMYdC.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVMYdC.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVMYdC.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVMYdC.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVMYdC.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVMYdC.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVMYdC.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVMYdC.append(("%s.zip"  % Path   , "archPath_zip"  ))
  if isDir:
   VVMYdC.append(VVc27s)
   VVMYdC.append(('Convert to ".ipk" Package' , "convertDirToIpk" ))
   VVMYdC.append(('Convert to ".deb" Package' , "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFcKE0(self, BF(self.VVaTX9, path, isDir, title), VVMYdC=VVMYdC, title=title, VVI8Pk=c1, VV2s6D=c2)
 def VVaTX9(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VV82ae(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz"   : self.VV82ae(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VV82ae(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VV82ae(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"    : self.VV82ae(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"    : self.VV82ae(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz"   : self.VV82ae(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VV82ae(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VV82ae(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"    : self.VV82ae(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk"   : self.VV63QK(path, False)
   elif item == "convertDirToDeb"   : self.VV63QK(path, True)
   else         : self.close()
 def VV63QK(self, path, VVchL9):
  self.session.openWithCallback(self.VViTw0, BF(CCk4eB, path=path, VVchL9=VVchL9))
 def VV82ae(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FF9E33(path, True)
  lastPart = FFUGmb(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFcB05("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFcB05("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFcB05("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVn31f
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFVKmy("rm -f '%s'" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFrfWO(failed, VV8DG7))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFrfWO(srcTxt, VVhW2e))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFrfWO("Output", VVhAfh))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFrfWO(failed, VVpQzP))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFEJxo(self, cmd, VVY0RJ=self.VViTw0, title=title)
 def VVUy1u(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CC5DZc.VVUx1U(FF9E33(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CC3Jx1(self, self, title, BF(self.VVa0rd, pathLst))
 def VVa0rd(self, pathLst):
  return CC3Jx1.VV2Kfz(pathLst)
 def VV2Hm6(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VVqh9C, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFlOO5(self, BF(FFZmix, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFZmix(self, fnc, title=txt)
  else:
   FFu1fZ(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VVqh9C(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, 'w:gz') as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FF4gok(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VViTw0()
  else:
   FF2PD3(tarPath)
   FFu1fZ(self, "Error while converting.", title=title)
 def VV6Vuc(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVGDMB, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFlOO5(self, BF(FFZmix, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFZmix(self, fnc, title=txt)
  else:
   FFu1fZ(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVGDMB(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FF4gok(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VViTw0()
  else:
   FF2PD3(zipPath)
   FFu1fZ(self, "Error while converting.", title=title)
 def VVcRl8(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FF5sxC(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  os.system(FFVKmy("rm -f '%s' '%s'" % (m1v, mvi)))
  res = os.system(FFVKmy("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)))
  if res == 0 and fileExists(m1v):
   res = os.system(FFVKmy("mv -f '%s' '%s'" % (m1v, mvi)))
   self.VViTw0()
   FF5VuW(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FFu1fZ(self, "Cannot convert this file !", title=title)
 @staticmethod
 def VVhhEZ(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCDmyf.VVtxwR(SELF.session, enableZapping= False, enableDownloadMenu=False, enableOpenInFMan=False)
  except:
   pass
 @staticmethod
 def VVektX(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FF5sxC(fDir), fName
  return "", "", ""
 @staticmethod
 def VVbQpT(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVcRWj(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVmkPo(size, mode=0):
  txt = CC5DZc.VV18UH(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VV18UH(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VV6u9i(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VVb7pn(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FFu1fZ(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VV4Gt6():
  tDict = CCgKzL.VVIw9Z()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVUx1U(path):
  lst = []
  for ext in CC5DZc.VV4Gt6():
   lst.extend(FFFgxj(path, "*.%s" % ext))
  return sorted(lst, key=FFYDEV(FF03SQ))
 @staticmethod
 def VVlfBg(path):
  res = os.system("tar -tzf '%s' >/dev/null" % path)
  return res == 0
 @staticmethod
 def VVydTn(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
class CCgKzL(MenuList):
 VVijoF  = 0
 VVOGuL  = 1
 VVCKjq  = 2
 VVhefC  = 3
 VVcbU7  = 4
 VVbW5P  = 5
 VVp994  = 6
 VVTMkB  = 7
 VVwkeT  = "<List of Storage Devices>"
 VVvxXu = "<Parent Directory>"
 def __init__(self, VV054x=False, directory="/", VVrzeS=True, VVznq5=True, VVYjjr=True, VVjiDQ=None, VVlTlX=False, VVKL5b=False, VVioHn=False, isTop=False, VV6VfK=None, VVOlpu=1000, VVJfxh=30, VVIJkE=30, VVgayn="#00000000", pngBGColorSelStr="#06003333"):
  MenuList.__init__(self, list, VV054x, eListboxPythonMultiContent)
  self.VVrzeS  = VVrzeS
  self.VVznq5    = VVznq5
  self.VVYjjr  = VVYjjr
  self.VVjiDQ  = VVjiDQ
  self.VVlTlX   = VVlTlX
  self.VVKL5b   = VVKL5b or []
  self.VVioHn   = VVioHn or []
  self.isTop     = isTop
  self.additional_extensions = VV6VfK
  self.VVOlpu    = VVOlpu
  self.VVJfxh    = VVJfxh
  self.VVIJkE    = VVIJkE
  self.pngBGColor    = FFSOpM(VVgayn)
  self.pngBGColorSel   = FFSOpM(pngBGColorSelStr)
  self.EXTENSIONS    = CCgKzL.VVIw9Z()
  self.VVcQ52   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.l.setFont(0, gFont(VVqTEg, self.VVJfxh))
  self.l.setItemHeight(self.VVIJkE)
  self.png_mem   = self.VVZlZ8("mem")
  self.png_usb   = self.VVZlZ8("usb")
  self.png_fil   = self.VVZlZ8("fil")
  self.png_dir   = self.VVZlZ8("dir")
  self.png_dirup   = self.VVZlZ8("dirup")
  self.png_srv   = self.VVZlZ8("srv")
  self.png_slwfil   = self.VVZlZ8("slwfil")
  self.png_slbfil   = self.VVZlZ8("slbfil")
  self.png_slwdir   = self.VVZlZ8("slwdir")
  self.VVPRtB()
  self.VVjfyN(directory)
 def VVZlZ8(self, category):
  return LoadPixmap("%s%s.png" % (VVlId3, category), getDesktop(0))
 @staticmethod
 def VVIw9Z():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVY1v2(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFS9Oz(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFXe6i(" -> " , VVrhVl) + FFXe6i(os.readlink(path), VVhAfh)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVIJkE + 10, 0, self.VVOlpu, self.VVIJkE, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVWAfo: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVIJkE-4, self.VVIJkE-4, png, self.pngBGColor, self.pngBGColorSel, VVWAfo))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVIJkE-4, self.VVIJkE-4, png, self.pngBGColor, self.pngBGColorSel))
  return tableRow
 def VVxkfz(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVPRtB(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VVRlpR(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVborg(self, file):
  if os.path.realpath(file) == file:
   return self.VVRlpR(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVRlpR(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVRlpR(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVNtFX(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVcQ52.info(l[0][0]).getEvent(l[0][0])
 def VVZvu2(self):
  return self.list
 def VVtPl6(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVjfyN(self, directory, select = None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VVYjjr:
    self.current_mountpoint = self.VVborg(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VVYjjr:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVioHn and not self.VVtPl6(path, self.VVKL5b):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVY1v2(name=p.description, absolute=path, isDir=True, png=png))
    path = "/"
    if path not in self.VVioHn and not self.VVtPl6(path, self.VVKL5b):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVY1v2(name="INTERNAL FLASH", absolute="/", isDir=True, png=self.png_mem))
  elif self.VVlTlX:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVcQ52 = eServiceCenter.getInstance()
   list = VVcQ52.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVrzeS and not self.isTop:
   if directory == self.current_mountpoint and self.VVYjjr:
    self.list.append(self.VVY1v2(name=self.VVwkeT, absolute=None, isDir=True, png=self.png_dirup))
   elif (directory != "/") and not (self.VVioHn and self.VVRlpR(directory) in self.VVioHn):
    self.list.append(self.VVY1v2(name=self.VVvxXu, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, png=self.png_dirup))
  if self.VVrzeS:
   for x in directories:
    if not (self.VVioHn and self.VVRlpR(x) in self.VVioHn) and not self.VVtPl6(x, self.VVKL5b):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVY1v2(name=name, absolute=x, isDir=True, png=png))
  if self.VVznq5:
   for x in files:
    if self.VVlTlX:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFXe6i(" -> " , VVrhVl) + FFXe6i(target, VVhAfh)
       else:
        png = self.png_slbfil
        name += FFXe6i(" -> " , VVrhVl) + FFXe6i(target, VVpQzP)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVxkfz(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVlId3, category))
    if (self.VVjiDQ is None) or iCompile(self.VVjiDQ).search(path):
     self.list.append(self.VVY1v2(name=name, absolute=x , isDir=False, png=png))
  if self.VVYjjr and len(self.list) == 0:
   self.list.append(self.VVY1v2(name=FFXe6i("No USB connected", VVycQx), absolute=None, isDir=False, png=self.png_usb))
  self.l.setList(self.list)
  self.VVBU7p()
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVy5TC(self):
  return self.current_directory
 def VVL548(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VV8GwE(self):
  return self.VVEUPF() and self.VVy5TC()
 def VVEUPF(self):
  return self.list[0][1][7] in (self.VVwkeT, self.VVvxXu)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVjfyN(self.getSelection()[0], select = self.current_directory)
 def VVoPjk(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVouTx(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VV1n9y)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VV1n9y)
 def refresh(self):
  self.VVjfyN(self.current_directory, self.VVoPjk())
 def VV1n9y(self, action, device):
  self.VVPRtB()
  if self.current_directory is None:
   self.refresh()
 def VVSxiY(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVijoF : nameAlpMode, nameAlpTxt = self.VVOGuL, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVijoF, sAZ
  if mode == self.VVCKjq : nameNumMode, nameNumTxt = self.VVhefC, s90
  else       : nameNumMode, nameNumTxt = self.VVCKjq, s09
  if mode == self.VVcbU7 : dateMode, dateTxt = self.VVbW5P, sON
  else       : dateMode, dateTxt = self.VVcbU7, sNO
  if mode == self.VVp994 : typeMode, typeTxt = self.VVTMkB, sZA
  else       : typeMode, typeTxt = self.VVp994, sAZ
  if   mode in (self.VVijoF, self.VVOGuL): txt = "Name (%s)" % (sAZ if mode == self.VVijoF else sZA)
  elif mode in (self.VVCKjq, self.VVhefC): txt = "Name (%s)" % (s09 if mode == self.VVijoF else s90)
  elif mode in (self.VVcbU7, self.VVbW5P): txt = "Date (%s)" % (sNO if mode == self.VVcbU7 else sON)
  elif mode in (self.VVp994, self.VVTMkB): txt = "Type (%s)" % (sAZ if mode == self.VVp994 else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VVBU7p(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FF72vQ(CFG.browserSortMode, mode)
   FF72vQ(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVEUPF() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVijoF, self.VVOGuL):
    rev = True if mode == self.VVOGuL else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVCKjq, self.VVhefC):
    rev = True if mode == self.VVhefC else False
    self.list = sorted(self.list[item0:], key=FFYDEV(BF(self.VV13ml, isMix, rev)), reverse=rev)
   elif mode in (self.VVcbU7, self.VVbW5P):
    rev = True if mode == self.VVbW5P else False
    self.list = sorted(self.list[item0:], key=FFYDEV(BF(self.VVx1HS, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VVTMkB else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VV13ml(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FF03SQ(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FF0EnI(dir2, dir1) or FF03SQ(name1, name2)
 def VVx1HS(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FF0EnI(stat2.st_ctime, stat1.st_ctime)
    else : return FF0EnI(dir2, dir1) or FF0EnI(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CC3Y09(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FFTWzO(VVBtm6, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVL1iO   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVrCWC(defFG, "#00FFFFFF")
  self.defBG   = self.VVrCWC(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FF0Q0u(self, self.Title)
  self["keyRed"].show()
  FF970D(self["keyGreen"] , "< > Transp.")
  FF970D(self["keyYellow"], "Foreground")
  FF970D(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVtT8g     ,
   "green"   : self.VVtT8g     ,
   "yellow"  : BF(self.VVFrBW, False)  ,
   "blue"   : BF(self.VVFrBW, True)  ,
   "up"   : self.VVMgQm       ,
   "down"   : self.VVcAI8      ,
   "left"   : self.VVvyya      ,
   "right"   : self.VVF1i7      ,
   "last"   : BF(self.VV66dH, -5) ,
   "next"   : BF(self.VV66dH, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VViGDa)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFaCb6(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFaCb6(self["keyRed"] , c)
  FFaCb6(self["keyGreen"] , c)
  self.VVprQG()
  self.VVVz2k()
  FFCE16(self["myColorTst"], self.defFG)
  FFaCb6(self["myColorTst"], self.defBG)
 def VVrCWC(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVVz2k(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVLZ7W(0, 0)
     return
 def VVtT8g(self):
  self.close(self.defFG, self.defBG)
 def VVMgQm(self): self.VVLZ7W(-1, 0)
 def VVcAI8(self): self.VVLZ7W(1, 0)
 def VVvyya(self): self.VVLZ7W(0, -1)
 def VVF1i7(self): self.VVLZ7W(0, 1)
 def VVLZ7W(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVWUUe()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VV1bgq()
 def VVprQG(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VV1bgq(self):
  color = self.VVWUUe()
  if self.isBgMode: FFaCb6(self["myColorTst"], color)
  else   : FFCE16(self["myColorTst"], color)
 def VVFrBW(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VVprQG()
   self.VVVz2k()
 def VV66dH(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVLZ7W(0, 0)
 def VVpP9M(self):
  return hex(self.transp)[2:].zfill(2)
 def VVWUUe(self):
  return ("#%s%s" % (self.VVpP9M(), self.colors[self.curRow][self.curCol])).upper()
class CCZZmO(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFTWzO(VVDsOp, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FF0Q0u(self, title="%s%s%s" % (self.Title, " " * 10, FFXe6i("Change values with Up , Down, < , 0 , >", VVycQx)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVqqT1      ,
   "cancel" : self.VVOdz3      ,
   "info"  : self.VVX98K    ,
   "red"  : self.VVnmXg  ,
   "green"  : self.VVVF7N   ,
   "yellow" : BF(self.VVsVwS, 0)  ,
   "blue"  : self.VVF2zC    ,
   "menu"  : self.VVU30E      ,
   "left"  : self.VVvyya      ,
   "right"  : self.VVF1i7      ,
   "last"  : self.VVS7Xt     ,
   "next"  : self.VVPFBN     ,
   "0"   : self.VV77JW    ,
   "up"  : self.VVMgQm       ,
   "down"  : self.VVcAI8      ,
   "pageUp" : BF(self.VV1no1, True) ,
   "pageDown" : BF(self.VV1no1, False) ,
   "chanUp" : BF(self.VV1no1, True) ,
   "chanDown" : BF(self.VV1no1, False) ,
   "play"  : BF(self.VV7rpz, "pause")  ,
   "pause"  : BF(self.VV7rpz, "pause")  ,
   "playPause" : BF(self.VV7rpz, "pause")  ,
   "stop"  : BF(self.VV7rpz, "pause")  ,
   "audio"  : BF(self.VV7rpz, "audio")  ,
   "subtitle" : BF(self.VV7rpz, "subtitle") ,
   "rewind" : BF(self.VV7rpz, "rewind" ) ,
   "forward" : BF(self.VV7rpz, "forward" ) ,
   "rewindDm" : BF(self.VV7rpz, "rewindDm") ,
   "forwardDm" : BF(self.VV7rpz, "forwardDm")
  }, -1)
  self.VVBzkG()
  self.onShown.append(self.VViGDa)
  self.onClose.append(self.VV8Acm)
 def VVBzkG(self):
  lst = []
  for fil in FFFgxj(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VVMkfG:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VViGDa(self):
  self.onShown.remove(self.VViGDa)
  FFyHsQ(self)
  FFKT7W(self)
  for i in range(3):
   self["mySubt%d" % i].instance.setNoWrap(True)
   self["mySubt%d" % i].hide()
  self.VVO8lI()
  self.VVvGWK()
  self.VVCbch()
 def VV8Acm(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VVzwRx(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FFaCb6(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VVgkk8()
 def VVO8lI(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FFaCb6(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VVqqT1(self):
  if self.settingShown:
   confItem = self.VVmBFY()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVMYdC = []
   if isinstance(lst[0], tuple):
    for item in lst: VVMYdC.append((item[1], item[0]))
   else:
    for item in lst: VVMYdC.append((item, item))
   menuInstance = FFcKE0(self, self.VVcdWa, VVMYdC=VVMYdC, width=700, title=title, VVI8Pk="#33221111", VV2s6D="#33110011")
   menuInstance.VVRBpj(confItem.getIndex())
  else:
   self.close("subtExit")
 def VVcdWa(self, item=None):
  if item:
   self.VVmBFY()[self.CursorPos].setValue(item)
   self.VVgkk8()
   self.VVvGWK()
   self.VVETaP(True)
 def VVOdz3(self):
  for confItem in self.VVmBFY():
   if confItem.isChanged():
    FFlOO5(self, self.VVoDeO, "Save Changes ?", callBack_No=self.VVebXw, title=self.Title)
    break
  else:
   if self.settingShown: self.VVO8lI()
   else    : self.close("subtExit")
 def VVU30E(self):
  if self.settingShown: self.VVIJGd()
  else    : self.VVzwRx()
 def VVvyya(self): self.VV8cci(-1)
 def VVF1i7(self): self.VV8cci(1)
 def VV8cci(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VVzuYW()
   if pos == -1: ndx = self.VVwWSc(posVal)
   else  : ndx = self.VVOHqi(posVal)
   if   ndx < 0      : FFAcfo(self, "Not found" , 500)
   elif ndx == 0      : FFAcfo(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FFAcfo(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVgFcC(frmSec)
    if allow:
     self.VVsVwS(delay, True)
     self.VVETaP(force=True)
    else:
     FFAcfo(self, "Delay out of range", 800)
 def VV1no1(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VV7rpz(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVS7Xt(self) : self.VVmS8Q(5)
 def VVPFBN(self) : self.VVmS8Q(6)
 def VV77JW(self) : self.VVmS8Q(-1)
 def VVMgQm(self):
  if self.settingShown: self.VVmS8Q(1)
  else    : self.VV1no1(True)
 def VVcAI8(self):
  if self.settingShown: self.VVmS8Q(0)
  else    : self.VV1no1(False)
 def VVmS8Q(self, direction):
  if self.settingShown:
   confItem = self.VVmBFY()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VVgkk8()
   self.VVvGWK()
   self.VVETaP(True)
 def VVmBFY(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VVebXw(self):
  for confItem in self.VVmBFY(): confItem.cancel()
  self.VVgkk8()
  self.VVvGWK()
  self.VVO8lI()
 def VVnmXg(self):
  if self.settingShown:
   FFlOO5(self, self.VV3OVy, "Reset Subtitle Settings to default ?", title=self.Title)
 def VV3OVy(self):
  for confItem in self.VVmBFY(): confItem.setValue(confItem.default)
  self.VVoDeO()
  self.VVgkk8()
  self.VVvGWK()
 def VVsVwS(self, delay, force=False):
  if self.settingShown or force:
   FF72vQ(CFG.subtDelaySec, delay)
   self.VV5wjT()
   self.VVgkk8()
   self.VVvGWK()
   if self.settingShown:
    FFAcfo(self, 'Reset to "0"', 800, isGrn=True)
 def VVVF7N(self):
  if self.settingShown:
   self.VVoDeO()
   self.VVO8lI()
 def VVoDeO(self):
  for confItem in self.VVmBFY(): confItem.save()
  configfile.save()
  self.VV5wjT()
  FFAcfo(self, "Saved", 1000, isGrn=True)
 def VVgkk8(self):
  cfgLst = self.VVmBFY()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VVvGWK(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   addFont(path, fnt, 100, 1)
  else:
   fnt = VVqTEg
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FF8vMy(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFCE16(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FFaCb6(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    inst.setNoWrap(True)
    lineH = FFdLhG(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FF8vMy(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFB0L6()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  boxFSize = self["myInfoFrame"].instance.size()
  boxSize  = self["myInfoBody"].instance.size()
  self["myInfoFrame"].instance.move(ePoint(int((winW - boxFSize.width()) // 2), int((winH - boxFSize.height()) // 2)))
  self["myInfoBody"].instance.move(ePoint(int((winW - boxSize.width()) // 2) , int((winH - boxSize.height()) // 2)))
 def VVX98K(self):
  sp = "    "
  txt  = "%s\n"   % FFXe6i("Subtitle File:", VVJ6nn)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FFXe6i("Subtitle Settings:", VVJ6nn)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VVzuYW()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FFZcBU(frmSec1)
   time2 = FFZcBU(toSec2)
   txt += "\n"
   txt += "%s\n"       % FFXe6i("Timing:", VVJ6nn)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FFZcBU(durVal)
   txt += sp + "Progress\t: %s\n" % FFZcBU(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FFXe6i("Subtitle end reached.", VV8DG7)
  FF4gok(self, txt, title="Current Subtitle")
 def VVCbch(self, path="", delay=0, enc=""):
  FFZmix(self, BF(self.VVepaO, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VVepaO(self, path="", delay=0, enc=""):
  FFAcfo(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVLbBX(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VVgkk8()
     self.VVOv31()
   else:
    path, delay, enc = CCZZmO.VVLNJ6(self)
    if path:
     self.VVCbch(path=path, delay=delay, enc=enc)
    else:
     self.VVIJGd()
  except:
   pass
 def VVOv31(self):
  posVal, durVal = self.VVzuYW()
  if self.VVNtnd(posVal):
   return
  CCZZmO.VVJerQ(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVETaP)
  except:
   self.timerUpdate.callback.append(self.VVETaP)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVgPfQ)
  except:
   self.timerEndText.callback.append(self.VVgPfQ)
  FFAcfo(self, "Subtitle started", 700, isGrn=True)
 def VVNtnd(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CCZZmO.VVsVjd(self)
   FF2PD3(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VVIJGd(self):
  c1, c2, c3, c4, c5 = "", VVJ6nn, VV2RHA, VVwhxm, VV8DG7
  VVMYdC = []
  VVMYdC.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVMYdC.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVMYdC.append(VVc27s)
  VVMYdC.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVMYdC.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVMYdC.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVMYdC.append(VVc27s)
   VVMYdC.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVMYdC.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVMYdC.append(VVc27s)
   VVMYdC.append(("Help (Keys)"        , "help"  ))
  FFcKE0(self, self.VVRFl5, VVMYdC=VVMYdC, width=700, title='Find Subtitle ".srt" File', VVI8Pk="#33221111", VV2s6D="#33110011")
 def VVRFl5(self, item=None):
  if item:
   if   item == "allSrt"   : self.VVI9g8(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VVI9g8(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    dir1 = CFG.lastFileManFindSrt.getValue()
    dir2 = CFG.MovieDownloadPath.getValue()
    sDir = "/"
    for path in (dir1, dir2, "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VVmb0O, BF(CC5DZc, mode=CC5DZc.VVYFLK, VVYwJg=sDir))
   elif item.startswith("sugSrt") : self.VVI9g8(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FFZmix(self, BF(CCSqSs.VVRJTe, self, self.lastSubtFile, self.VVFZf9, defEnc=self.lastSubtEnc), title="Loading Codecs ...", clearMsg=False)
    else             : FFAcfo(self, "SRT File error", 1000)
   elif item == "disab":
    FF2PD3(CCZZmO.VVsVjd(self))
    self.close("subtExit")
   elif item == "help"    : FFqh4M(self, VVlId3 + "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VVFZf9(self, item=None):
  if item:
   FFZmix(self, BF(self.VVCbch, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VVmb0O(self, path):
  if path:
   FF72vQ(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VVCbch(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VVI9g8(self, defSrt="", mode=0, coeff=0.25):
  FFZmix(self, BF(self.VVoiae, defSrt, mode=mode, coeff=coeff), title="Searching for srt files", clearMsg=False)
 def VVoiae(self, defSrt="", mode=0, coeff=0.25):
  FFAcfo(self)
  if mode == 1:
   srtList = CCZZmO.VVlr0L(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FFEUax('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFcbot(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVjKjs(srtList, coeff)
     if err:
      if self.settingShown: FFAcfo(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVbdQX = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FF5sxC(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVbdQX.append((fName, Dir))
   VVhqvZ  = ("Select"    , self.VVkTll     , [])
   VVxRQ7 = self.VVMkIG
   VVDAgH = (""     , self.VVBknv       , [])
   VV3Q2h = (""     , BF(self.VVEkK6, defSrt, False) , [])
   VVgAHl = ("Find Current File" , BF(self.VVEkK6, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FFMPky(self, None, title=title, header=header, VVL1iO=VVbdQX, VVLkOa=widths, VVJfxh=28, VVhqvZ=VVhqvZ, VVxRQ7=VVxRQ7, VVDAgH=VVDAgH, VV3Q2h=VV3Q2h, VVgAHl=VVgAHl, lastFindConfigObj=CFG.lastFindSubtitle
     , VVI8Pk="#11002222", VV2s6D="#33001111", VVjLdB="#33001111", VV58S5="#11ffff00", VVaZj9="#11445544", VVBGyD="#22222222", VVFIzs="#11002233")
  elif self.settingShown : FFAcfo(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVMkIG(self, VVoyO8):
  VVoyO8.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VVBknv(self, VVoyO8, title, txt, colList):
  fName, Dir = colList
  FF4gok(VVoyO8, "%s\n\n%s%s" % (FFXe6i("Path:", VVJ6nn), Dir, fName), title=title)
 def VVEkK6(self, path, VVe3Eu, VVoyO8, title, txt, colList):
  for ndx, row in enumerate(VVoyO8.VVVGfF()):
   if path == row[1].strip() + row[0].strip():
    VVoyO8.VVjS0j(ndx)
    break
  else:
   if VVe3Eu:
    FFAcfo(VVoyO8, "Not in list !", 1000)
 def VVkTll(self, VVoyO8, title, txt, colList):
  VVoyO8.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VVCbch(path=path)
 def VVjKjs(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CChafy.VVnhYY(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName and not CFG.epgLanguage.getValue() == "off":
   evName = CChafy.VV5zH1(evName)
  if evName:
   lst, err = CCZZmO.VVZxye(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVLbBX(self, path, enc=None):
  if not fileExists(path):
   return [], "File not found"
  if (FFehaw(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FFgYB4(path, encLst=enc if enc else None)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVVUA9(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VVFYWL(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VV5wjT()
  return subtList, ""
 def VVFYWL(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VVVUA9(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VV5wjT(self):
  path = CCZZmO.VVsVjd(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVETaP(self, force=False):
  posVal, durVal = self.VVzuYW()
  if self.VVNtnd(posVal):
   return
  curIndex = self.VVfZds(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVgPfQ()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFCE16(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VVzuYW(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCDmyf.VVvsST(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CChafy.VVnhYY(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VVfZds(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VVwWSc(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VVOHqi(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVgPfQ(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFCE16(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVF2zC(self):
  FFZmix(self, self.VVPl3D, title="Loading Lines ...", clearMsg=False)
 def VVPl3D(self):
  FFAcfo(self)
  VVbdQX = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVbdQX.append((cap, FFZcBU(frm), str(frm), firstLine))
  if VVbdQX:
   title = "Select Current Subtitle Line"
   VVcQZx  = self.VVe3Xu
   VVxRQ7 = self.VVa3zS
   VVhqvZ  = ("Select"   , self.VVYGjy , [title])
   VVgAHl = ("Current Line" , self.VVvNnC , [True])
   VVUZua = ("Reset Delay" , self.VVCRyM , [])
   VVR0s7 = ("New Delay"  , self.VVe5BJ   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VV28Ef  = (CENTER , CENTER, CENTER , LEFT    )
   VVoyO8 = FFMPky(self, None, title=title, header=header, VVL1iO=VVbdQX, VV28Ef=VV28Ef, VVLkOa=widths, VVJfxh=28, VVcQZx=VVcQZx, VVxRQ7=VVxRQ7, VVhqvZ=VVhqvZ, VVgAHl=VVgAHl, VVUZua=VVUZua, VVR0s7=VVR0s7
          , VVI8Pk="#33002222", VV2s6D="#33001111", VVjLdB="#33110011", VV58S5="#11ffff00", VVaZj9="#0a334455", VVBGyD="#22222222", VVFIzs="#33002233")
  else:
   FFAcfo(self, "Cannot read lines !", 2000)
 def VVe3Xu(self, VVoyO8):
  self.subtLinesTable = VVoyO8
  if CFG.subtDelaySec.getValue():
   VVoyO8["keyYellow"].show()
   VVoyO8["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVoyO8["keyYellow"].hide()
  VVoyO8["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FFaCb6(VVoyO8["keyBlue"], "#22222222")
  VVoyO8.VVSw2q(BF(self.VVGUYo, VVoyO8))
  self.VVvNnC(VVoyO8, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVWXAG)
  except:
   self.timerSubtLines.callback.append(self.VVWXAG)
  self.timerSubtLines.start(1000, False)
 def VVa3zS(self, VVoyO8):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVoyO8.cancel()
 def VVWXAG(self):
  if self.subtLinesTable:
   VVoyO8 = self.subtLinesTable
   posVal, durVal = self.VVzuYW()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVfZds(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVoyO8.VVyjPv(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVoyO8.VVUt87(self.subtLinesTableNdx, row)
     row = VVoyO8.VVyjPv(curIndex)
     row[0] = color + row[0]
     VVoyO8.VVUt87(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VVYGjy(self, VVoyO8, Title):
  delay, color, allow = self.VVIDbX(VVoyO8)
  if allow:
   self.VVa3zS(VVoyO8)
   self.VVsVwS(delay, True)
  else:
   FFAcfo(VVoyO8, "Delay out of range", 1500)
 def VVvNnC(self, VVoyO8, VVe3Eu, onlyColor=False):
  if VVoyO8:
   posVal, durVal = self.VVzuYW()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVfZds(posVal)
    if curIndex > -1:
     VVoyO8.VVjS0j(curIndex)
    else:
     ndx = self.VVwWSc(posVal)
     if ndx > -1:
      VVoyO8.VVjS0j(ndx)
 def VVCRyM(self, VVoyO8, title, txt, colList):
  if VVoyO8["keyYellow"].getVisible():
   self.VVsVwS(0, True)
   VVoyO8["keyYellow"].hide()
   self.VVvNnC(VVoyO8, False)
 def VVGUYo(self, VVoyO8):
  delay, color, allow = self.VVIDbX(VVoyO8)
  VVoyO8["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VVIDbX(self, VVoyO8):
  lineTime = float(VVoyO8.VV3wWK()[2].strip())
  return self.VVgFcC(lineTime)
 def VVgFcC(self, lineTime):
  posVal, durVal = self.VVzuYW()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VV80mJ
   else     : allow, color = False, VV8DG7
   delay = FFCk9k(val, -600, 600)
  return delay, color, allow
 def VVe5BJ(self, VVoyO8, title, txt, colList):
  pass
 @staticmethod
 def VVoPuq(SELF):
  path, delay, enc = CCZZmO.VVLNJ6(SELF)
  return True if path else False
 @staticmethod
 def VVLNJ6(SELF):
  path, delay, enc = CCZZmO.VVZTjb(SELF)
  if not path:
   path = CCZZmO.VVhzkz(SELF)
  return path, delay, enc
 @staticmethod
 def VVZTjb(SELF):
  srtCfgPath = CCZZmO.VVsVjd(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FFgYB4(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVsVjd(SELF):
  fPath, fDir, fName = CC5DZc.VVektX(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CChafy.VVnhYY(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFR3hA(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VVhzkz(SELF):
  bestRatio = 0
  fPath, fDir, fName = CC5DZc.VVektX(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CCZZmO.VVlr0L(SELF)
    bLst, err = CCZZmO.VVZxye(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVlr0L(SELF):
  fPath, fDir, fName = CC5DZc.VVektX(SELF)
  if pathExists(fDir):
   files = FFFgxj(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VVZxye(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVPHP3():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVJerQ(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CCZZmO.VVzps7()
 @staticmethod
 def VVzps7():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CCzOJn(ScrollLabel):
 def __init__(self, parentSELF, text="", VVFBhi=True):
  ScrollLabel.__init__(self, text)
  self.VVFBhi   = VVFBhi
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VVWAX3  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVJfxh    = None
  self.parentW    = None
  self.parentH    = None
  self.firstTime    = True
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VV0TKR ,
   "green"   : self.VVWq8C ,
   "yellow"  : self.VVFqnw ,
   "blue"   : self.VVbeam ,
   "up"   : self.pageUp   ,
   "down"   : self.pageDown   ,
   "left"   : self.pageUp   ,
   "right"   : self.pageDown   ,
   "last"   : BF(self.VVcYz2, 0) ,
   "0"    : BF(self.VVcYz2, 1) ,
   "next"   : BF(self.VVcYz2, 2) ,
   "pageUp"  : self.VVt03Z   ,
   "chanUp"  : self.VVt03Z   ,
   "pageDown"  : self.VVBpWj   ,
   "chanDown"  : self.VVBpWj
  }, -1)
 def VVmdiX(self, isResizable=True, VVh63k=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFCE16(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFaCb6(self.parentSELF["keyRedTop"], "#113A5365")
  FFyHsQ(self.parentSELF, True)
  self.isResizable = isResizable
  if VVh63k:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVJfxh  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFaCb6(self, color)
 def VV23bO(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  lineheight  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  lines   = int(self.long_text.size().height() / lineheight)
  margin   = int(lineheight / 6)
  self.pageHeight = int(lines * lineheight)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  self.setText(self.message)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVWAX3 - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVJXZH()
 def pageUp(self):
  if self.VVWAX3 > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVWAX3 > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVt03Z(self):
  self.setPos(0)
 def VVBpWj(self):
  self.setPos(self.VVWAX3-self.pageHeight)
 def VV7Ost(self):
  return self.VVWAX3 <= self.pageHeight or self.curPos == self.VVWAX3 - self.pageHeight
 def getText(self):
  return self.message
 def VVJXZH(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVWAX3, 3))
   start = int((100 - vis) * self.curPos / (self.VVWAX3 - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVr1DU=VVr6rx):
  old_VV7Ost = self.VV7Ost()
  self.message = str(text)
  if self.pageHeight:
   self.long_text.setText(self.message)
   self.VVWAX3 = self.long_text.calculateSize().height()
   if self.VVFBhi and self.VVWAX3 > self.pageHeight:
    self.scrollbar.show()
    self.VVJXZH()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVWAX3))
   if   VVr1DU == VVewqn: self.setPos(0)
   elif VVr1DU == VVTsDD : self.VVBpWj()
   elif old_VV7Ost    : self.VVBpWj()
   if self.firstTime and len(self.message) > 0:
    self.firstTime = False
    self.setText(self.message, VVr1DU=VVr1DU)
 def appendText(self, text, VVr1DU=VVTsDD):
  self.setText(self.message + str(text), VVr1DU=VVr1DU)
 def VVFqnw(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVhLiV(size)
 def VVbeam(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVhLiV(size)
 def VVWq8C(self):
  self.VVhLiV(self.VVJfxh)
 def VVhLiV(self, VVJfxh):
  self.long_text.setFont(gFont(self.fontFamily, VVJfxh))
  self.setText(self.message, VVr1DU=VVr6rx)
  self.VVq6UY(calledFromFontSizer=True)
 def VVcYz2(self, align):
  self.long_text.setHAlign(align)
 def VV0TKR(self):
  VVMYdC = []
  VVMYdC.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Align Left"  , "left" ))
  VVMYdC.append(("Align Center"  , "center" ))
  VVMYdC.append(("Align Right"  , "right" ))
  if self.outputFileToSave:
   VVMYdC.append(VVc27s)
   VVMYdC.append((FFXe6i("Save to File", VVJ6nn), "save" ))
  VVMYdC.append(VVc27s)
  VVMYdC.append(("Keys (Shortcuts)" , "help" ))
  FFcKE0(self.parentSELF, self.VVsSdR, VVMYdC=VVMYdC, title="Text Option", width=500)
 def VVsSdR(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VVcYz2(0)
   elif item == "center" : self.VVcYz2(1)
   elif item == "right" : self.VVcYz2(2)
   elif item == "save"  : self.VVmErX()
   elif item == "help"  : FFqh4M(self.parentSELF, VVlId3 + "_help_txt", "Text Viewer (Keys)")
 def VVmErX(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FF5sxC(expPath), self.outputFileToSave, FFcOP9())
   with open(outF, "w") as f:
    f.write(FF3RM7(self.message))
   FF5VuW(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFu1fZ(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVq6UY(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVWAX3 > 0 and self.pageHeight > 0:
   if self.VVWAX3 < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVWAX3
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
