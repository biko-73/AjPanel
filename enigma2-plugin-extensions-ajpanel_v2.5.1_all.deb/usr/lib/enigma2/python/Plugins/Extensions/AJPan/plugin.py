import os
from json      import loads as jLoads
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import log
from time      import localtime, mktime, strftime
from time      import time as iTime
from datetime     import datetime
from base64      import b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVFjWv   = "v2.5.1"
VVXWXv    = "17-09-2021"
VV4OiA  = "AJ File Manager"
VV8fQQ   = "AJ Live Log (OSCam/NCam)"
EASY_MODE    = 0
VVTTyi   = 0
VVN3AN   = 0
VVCrBY  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVO2Lq  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVoi8H    = "/media/usb/"
VVx9ys    = "/usr/share/enigma2/picon/"
VVlT2l   = "/etc/enigma2/"
VVFvKy  = "ajpanel_update_url"
VVSjR1   = "AJPan"
VVnRzV    = ""
VVmgWy    = "Regular"
VVklh1      = "-" * 80;
VVGV45    = (VVklh1, )
VVaLC9    = ""
VV1uYF   = " && echo 'Successful' || echo 'Failed!'"
VVNJ3p    = []
VVZH9I     = 0
VV43mJ    = ""
VVqAV4  = False
VViQ7B  = False
VV2YUz     = 0
VVXfv4    = 1
VVUm8T    = 2
VV8LqE   = 3
VVCUG2    = 4
VV3kF9    = 5
VVV8lu = 6
VVnLZX = 7
VVOwis  = 8
VVDi9S   = 9
VV2aOg   = 10
VVJl51   = 11
VVkfbA  = 12
VVcN3H  = 13
VVKVKL    = 14
VVsoAu   = 15
VV2Nqk   = 16
VVrayu  = 15
VVhDR4   = 0
VVaGDj   = 1
VVkxAh   = 2
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu   = ConfigYesNo(default=False)
CFG.showInExtensionMenu  = ConfigYesNo(default=True)
CFG.showInChannelListMenu = ConfigYesNo(default=True)
CFG.keyboard    = ConfigSelection(default="v", choices = [ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal   = ConfigSelection(default="lesc", choices = [ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.iptvAddToBouquetRefType = ConfigSelection(default="4097", choices = [ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.PIconsPath    = ConfigDirectory(default=VVx9ys, visible_width=51)
CFG.backupPath    = ConfigDirectory(default=VVoi8H, visible_width=51)
CFG.packageOutputPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath  = ConfigText(default="/")
CFG.browserBookmarks   = ConfigText(default="/tmp/,/")
CFG.signalPos    = ConfigInteger(default=5, limits=(1, 9))
CFG.signalSize    = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme  = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup = ConfigYesNo(default=False)
CFG.playerJumpMin   = ConfigInteger(default=5, limits=(1, 10))
def FFcT3z():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVEInC  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVzSMs = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVEInC  : return 0
  elif VVzSMs : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VV0pPs = FFcT3z()
VVYh3b = VVqb5h = VV7KZt = VVdNwi = VVUYyn = VV74c8 = VVmHHA = VVFlyn = COLOR_CONS_BRIGHT_YELLOW = VVhJi6 = VVbXIp = VVI2d4 = ""
def FF8fwc(FF8fwcText="", addSep=True):
 if VVTTyi:
  txt = VVklh1 + "\n" if addSep else ""
  txt += ">>>> %s >>  %s" % (PLUGIN_NAME, str(FF8fwcText))
  os.system('echo -e "%s"' % txt)
def FFBCia(txt, isAppend=True):
 if VVTTyi:
  tm   = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
  err = ""
  try:
   from traceback import format_exc, format_stack
   trace = format_exc()
   if trace and len(trace) > 5:
    stack = format_stack()[:-1]
    sep = "*" * 70
    err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
    err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
  except:
   pass
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FF8fwc(err)
  FF8fwc("Output Log File : %s" % fileName)
VVNJ3p = []
def FFBLuo(win):
 global VVNJ3p
 if not win in VVNJ3p:
  VVNJ3p.append(win)
def FF3SS7(*args):
 global VVNJ3p
 for win in VVNJ3p:
  try:
   win.close()
  except:
   pass
 VVNJ3p = []
def FFKw17():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VV79xv = FFKw17()
def getDescriptor(fnc, where, name=PLUGIN_NAME):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=True, name=name, description=PLUGIN_DESCRIPTION, icon=icon)
def FFzdzB()     : return getDescriptor(FFspPd   , [ PluginDescriptor.WHERE_PLUGINMENU  ] )
def FFj7zr()  : return getDescriptor(FFspPd   , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] )
def FFPlHw()  : return getDescriptor(FFfxEr , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , VV4OiA)
def FFcC2Z() : return getDescriptor(FFydo2 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , VV8fQQ)
def FF1i2f()    : return getDescriptor(FFATPR  , [ PluginDescriptor.WHERE_SESSIONSTART  ] )
def FFPdsL()      : return getDescriptor(FFblrF  , [ PluginDescriptor.WHERE_MENU    ] )
def Plugins(**kwargs):
 result = [ FFzdzB() , FFPdsL() , FF1i2f() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFj7zr())
  result.append(FFPlHw())
  result.append(FFcC2Z())
 return result
def FFATPR(reason, **kwargs):
 if reason == 0:
  FFqiDF()
  session = kwargs["session"]
  if session:
   FF9xsc(session)
def FFblrF(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFspPd, PLUGIN_NAME, 45)]
 else:
  return []
def FFspPd(session, **kwargs):
 session.open(Main_Menu)
def FFfxEr(session, **kwargs):
 session.open(CCMIrG)
def FFydo2(session, **kwargs):
 FF5mdK(session, CCH5mf.VVvWKi)
def FF8E0M():
 pluginList  = iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU)
 descrPanel  = FFj7zr()
 descrFileMan = FFPlHw()
 descrCamLog  = FFcC2Z()
 try:
  if CFG.showInExtensionMenu.getValue():
   if not descrPanel    in pluginList : iPlugins.addPlugin(descrPanel)
   if not descrFileMan  in pluginList : iPlugins.addPlugin(descrFileMan)
   if not descrCamLog in pluginList : iPlugins.addPlugin(descrCamLog)
  else:
   if descrPanel   in pluginList  : iPlugins.removePlugin(descrPanel)
   if descrFileMan in pluginList  : iPlugins.removePlugin(descrFileMan)
   if descrCamLog  in pluginList  : iPlugins.removePlugin(descrCamLog)
 except:
  pass
VVtI8b = None
def FFqiDF():
 try:
  global VVtI8b
  if VVtI8b is None:
   VVtI8b    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFRJEO
  ChannelContextMenu.FFT7jB = FFT7jB
 except:
  pass
def FFRJEO(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVtI8b(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFT7jB, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFT7jB, title1, csel, isFind=True))))
def FFT7jB(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFi9ZT(refCode)
 except:
  pass
 self.session.open(boundFunction(CCezVa, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FF9xsc(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFPMFB, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFPMFB, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFPMFB, session, "lred")
def FFPMFB(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFD0vK(session, isFromSession=True)
def FFZrGE(SELF, title="", addLabel=False, addScrollLabel=False, VVXWOy=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFSb2Q()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 if SELF.skinParam["topRightBtns"] > 0:
  SELF["keyMenu2F"]  = Label()
  SELF["keyMenu2"]  = Label("Menu")
  if SELF.skinParam["topRightBtns"] > 1:
   SELF["keyMenu1F"] = Label()
   SELF["keyMenu1"] = Label("Info")
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCAGQP(SELF)
 if VVXWOy:
  SELF["myMenu"] = MenuList(VVXWOy)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVOF6C        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFzceg(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FFcsaP, SELF, "0") ,
  "1"    : boundFunction(FFcsaP, SELF, "1") ,
  "2"    : boundFunction(FFcsaP, SELF, "2") ,
  "3"    : boundFunction(FFcsaP, SELF, "3") ,
  "4"    : boundFunction(FFcsaP, SELF, "4") ,
  "5"    : boundFunction(FFcsaP, SELF, "5") ,
  "6"    : boundFunction(FFcsaP, SELF, "6") ,
  "7"    : boundFunction(FFcsaP, SELF, "7") ,
  "8"    : boundFunction(FFcsaP, SELF, "8") ,
  "9"    : boundFunction(FFcsaP, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFBQ61, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFcsaP(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVI2d4:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVI2d4 + SELF.keyPressed + VVqb5h)
    txt = VVqb5h + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFtXOm(SELF, txt)
def FFBQ61(SELF, tableObj, colNum):
 FFtXOm(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     tableObj.moveToIndex(i)
     SELF.VVSOUf()
     break
 except:
  pass
def FFU5pX(SELF, setMenuAction=True):
 if setMenuAction:
  global VVaLC9
  VVaLC9 = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFSb2Q():
 return ("  %s" % VVaLC9)
def FFnxzu(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFOCgm(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FF91hV(color):
 return parseColor(color).argb()
def FFTsrs(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFwL0h(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFFHq1(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FF3Nyd(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVI2d4)
 else:
  return ""
def FFsGXc(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVklh1, word, VVklh1, VVI2d4)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVklh1, word, VVklh1)
def FFW8xd(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVI2d4
def FFuLlr(color):
 if color: return "echo -e '%s' %s;" % (VVklh1, FF3Nyd(VVklh1, VVFlyn))
 else : return "echo -e '%s';" % VVklh1
def FFyty0(title, color):
 title = "%s\n%s\n%s\n" % (VVklh1, title, VVklh1)
 return FFW8xd(title, color)
def FFNsDm(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FF7chj(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FF1XIo(callBackFunction):
 tCons = CCLvxk()
 tCons.ePopen("echo", boundFunction(FFt2i0, callBackFunction))
def FFt2i0(callBackFunction, result, retval):
 callBackFunction()
def FFBV5V(SELF, fnc, title="Processing ...", clearMsg=True):
 FFtXOm(SELF, title)
 tCons = CCLvxk()
 tCons.ePopen("echo", boundFunction(FFPOOV, SELF, fnc, clearMsg))
def FFPOOV(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFtXOm(SELF)
def FFrSA4(cmd):
 from subprocess import Popen, PIPE
 process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
 stdout, stderr = process.communicate()
 stdout = stdout.strip()
 stderr = stderr.strip()
 if stderr : return stderr
 else  : return stdout
def FFUtqa(cmd):
 txt = FFrSA4(cmd)
 if txt:
  txt.strip()
  if "\n" in txt:
   txt = txt.splitlines()
   return list(map(str.strip, txt))
  else:
   return [txt]
 else:
  return []
def FFHvE5(cmd):
 lines = FFUtqa(cmd)
 if lines: return lines[0]
 else : return ""
def FFreYg(SELF, cmd):
 lines = FFUtqa(cmd)
 VVgBMX = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVgBMX.append((key, val))
  elif line:
   VVgBMX.append((line, ""))
 if VVgBMX:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFZUAl(SELF, None, header=header, VVXy7C=VVgBMX, VV08hy=widths, VVH2Qb=22)
 else:
  FF2NFl(SELF, cmd)
def FF2NFl(    SELF, cmd, **kwargs): SELF.session.open(CCfXPk, VVZwQE=cmd, VVUE41=True, VVTBXk=VVaGDj, **kwargs)
def FFkvWV(  SELF, cmd, **kwargs): SELF.session.open(CCfXPk, VVZwQE=cmd, **kwargs)
def FFAxIC(   SELF, cmd, **kwargs): SELF.session.open(CCfXPk, VVZwQE=cmd, VVvUA4=True, VVVMmG=True, VVTBXk=VVaGDj, **kwargs)
def FFwT7C(  SELF, cmd, **kwargs): SELF.session.open(CCfXPk, VVZwQE=cmd, VVvUA4=True, VVVMmG=True, VVTBXk=VVkxAh, **kwargs)
def FFb6xn(  SELF, cmd, **kwargs): SELF.session.open(CCfXPk, VVZwQE=cmd, VV68JP=True , **kwargs)
def FFZHfo( SELF, cmd, **kwargs): SELF.session.open(CCfXPk, VVZwQE=cmd, VVub9W=True   , **kwargs)
def FFxkJ6( SELF, cmd, **kwargs): SELF.session.open(CCfXPk, VVZwQE=cmd, VV1gNq=True  , **kwargs)
def FFLcOy(cmd):
 return cmd + " > /dev/null 2>&1"
def FFfno2():
 return " > /dev/null 2>&1"
def FFIqu7(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFx6OB(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "/bin"
    , "/boot"
    , "/dev"
    , "/hdd"
    , "/home"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/picon"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FFqtwu():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFHvE5(cmd)
VVlevY     = 0
VVVX1J      = 1
VVWSiA   = 2
VVPMTK      = 3
VVVFn3      = 4
VVHKMB     = 5
VVQ6yh     = 6
VVXTqa  = 7
VVF0Dt = 8
VVYEWw  = 9
VVgUUu     = 10
VVkVAT  = 11
VVn1In  = 12
def FFKs6c(parmNum, grepTxt):
 if   parmNum == VVlevY  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVVX1J   : param = ["list"   , "apt list" ]
 elif parmNum == VVWSiA: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FFqtwu()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FF2NxH(parmNum, package):
 if   parmNum == VVPMTK      : param = ["info"      ,"apt show"          ]
 elif parmNum == VVVFn3      : param = ["files"      ,"dpkg -L"          ]
 elif parmNum == VVHKMB     : param = ["download"     ,"apt-get download"        ]
 elif parmNum == VVQ6yh     : param = ["install"     ,"apt-get install -y"       ]
 elif parmNum == VVXTqa  : param = ["install --force-reinstall" ,"apt-get install --reinstall -y"    ]
 elif parmNum == VVF0Dt : param = ["install --force-downgrade" ,"apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVYEWw  : param = ["install --force-depends" ,"apt-get install --no-install-recommends -y" ]
 elif parmNum == VVgUUu     : param = ["remove"      ,"apt-get purge --auto-remove -y"    ]
 elif parmNum == VVkVAT  : param = ["remove --force-remove"  ,"dpkg --purge --force-all"      ]
 elif parmNum == VVn1In  : param = ["remove --force-depends"  ,"dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFqtwu()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FF6Afo():
 result = FFHvE5("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FF2NxH(VVQ6yh , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFLcOy("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFLcOy("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FF3Nyd(failed1, VVFlyn))
   cmd += "  echo -e '%s' %s;"  % (failed2, FF3Nyd(failed2, VVFlyn))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FF3Nyd(failed3, VV7KZt))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFUIFh(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FF2NxH(VVQ6yh , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFLcOy("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FF3Nyd(failed1, VVFlyn))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FF3Nyd(failed2, VV7KZt))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FF2qeK(timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect(("1.1.1.1", 53))
  return True
 except:
  return False
def FFteHI(path, maxSize=-1):
 from io import open as ioOpen
 encodings = (None, "utf-8", "ISO8859-15", 'iso6937', "windows-1250", "windows-1252")
 txt = ""
 for enc in encodings:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFUM2c(path, keepends=False, maxSize=-1):
 lines = FFteHI(path, maxSize)
 return lines.splitlines(keepends)
def FFW3ac(SELF, path):
 title = FFSb2Q()
 if fileExists(path):
  fSize = os.path.getsize(path)
  maxSize = 60000
  if (fSize > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFUM2c(path, maxSize=maxSize)
  if lines: FFKjl2(SELF, lines, title=title, VVTBXk=VVaGDj)
  else : FFqWYJ(SELF, path, title=title)
 else:
  FFV5mI(SELF, path, title)
def FFifNb(SELF, path, title):
 if fileExists(path):
  txt = FFteHI(path)
  txt = txt.replace("#W#", VVI2d4)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVqb5h)
  txt = txt.replace("#C#", VVhJi6)
  txt = txt.replace("#P#", VVdNwi)
  FFKjl2(SELF, txt, title=title)
 else:
  FFV5mI(SELF, path, title)
def FF0hai(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FF9zum(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FF89XU(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFTsBZ(parent)
 else    : return FFcHPD(parent)
def FFQzAx(path):
 try:
  return os.path.getsize(path)
 except:
  return 0
def FFTsBZ(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFcHPD(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FF5IDB():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVCrBY)
 paths.append(VVCrBY.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FF9zum(ba)
 for p in list:
  p = ba + p + VVCrBY
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVSjR1, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVCrBY, VVSjR1 , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVt4G6, VVhwNz = FF5IDB()
def FFnlPn():
 def VVpVWh(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 VVwfI3  = VVpVWh(CFG.backupPath, CClCHG.VVSnbX())
 VVPPZe  = VVpVWh(CFG.downloadedPackagesPath, t)
 VVDZ1a = VVpVWh(CFG.exportedTablesPath, t)
 VV3Gub = VVpVWh(CFG.exportedPIconsPath, t)
 VVXIRw  = VVpVWh(CFG.packageOutputPath, t)
 global VVoi8H
 VVoi8H = FFTsBZ(CFG.backupPath.getValue())
 if VVwfI3 or VVXIRw or VVPPZe or VVDZ1a or VV3Gub:
  configfile.save()
 return VVwfI3, VVXIRw, VVPPZe, VVDZ1a, VV3Gub
def FF6m1I(path):
 path = FFcHPD(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFdctT(SELF, pathList, tarFileName, addTimeStamp=True):
 VVXy7C = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVXy7C.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVXy7C.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVXy7C.append(path)
 if not VVXy7C:
  FFEW3v(SELF, "Files not found!")
 elif not pathExists(VVoi8H):
  FFEW3v(SELF, "Path not found!\n\n%s" % VVoi8H)
 else:
  VV4gX1 = FFTsBZ(VVoi8H)
  tarFileName = "%s%s" % (VV4gX1, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFtouN())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVXy7C:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVklh1
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FF3Nyd(tarFileName, VVmHHA))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FF3Nyd(failed, VVmHHA))
  cmd += "fi;"
  cmd +=  sep
  FFkvWV(SELF, cmd)
def FFPHv7(SELF, title, VVaRdA):
 SELF.session.open(boundFunction(CCMWbp, Title=title, VVaRdA=VVaRdA))
def FFoEjx(labelObj, VVaRdA):
 if VVaRdA and fileExists(VVaRdA):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VVcO3u(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VVcO3u)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VVaRdA)
   return True
  except:
   pass
 return False
def FFUZWq(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFwzNy(satNum)
  return satName
def FFwzNy(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFTI0M(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFUZWq(val)
  else  : sat = FFwzNy(val)
 return sat
def FFp5ev(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFUZWq(num)
 except:
  pass
 return sat
def FF0uha(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FF8KLs(SELF, isFromSession=None):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FF3WDL(info, iServiceInformation.sServiceref)
   prov = FF3WDL(info, iServiceInformation.sProvider)
   state = str(FF3WDL(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFF590(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFwwJ6(refCode)
 return info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FF3WDL(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FF726c(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFi9ZT(refCode):
 info = FFdpV0(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FF4GcA(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFsghU(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFdpV0(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVy14z = eServiceCenter.getInstance()
  if VVy14z:
   info = VVy14z.info(service)
 return info
def FFhRft(SELF, refCode, VVgeCS=True, checkParentalControl=False):
 if not refCode.endswith(":"):
  refCode += ":"
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  SELF.session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
  if VVgeCS:
   FFD0vK(SELF)
 try:
  VVDbSW = InfoBar.instance
  if VVDbSW:
   VVDkKf = VVDbSW.servicelist
   if VVDkKf:
    servRef = eServiceReference(refCode)
    VVDkKf.saveChannel(servRef)
 except:
  pass
def FFF590(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFwwJ6(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFzmJo(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFad9U(userBfile):
 txt = ""
 bFile = VVlT2l + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVlT2l + userBfile):
  fTxt = FFteHI(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFHvE5('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
 return
def FFzmJo(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FFNc1a(url):
 if iQuote : return iQuote(url)
 else  : return url
def FFD0vK(SELF, isFromSession=None):
 if isFromSession: session = SELF
 else   : session = SELF.session
 info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF8KLs(SELF, isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCq8j1)
 else      : FFD214(session, reopen=True)
def FFD214(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFD214, session), CC4Jdh)
  except:
   try:
    FFWdIU(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFiMfm(refCode):
 tp = CCLFki()
 if tp.VVWX7a(refCode) : return True
 else        : return False
def FFdZr6(refCode, isHide):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FF1Rf4():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FFqGJf():
 VVDbSW = InfoBar.instance
 if VVDbSW:
  VVDkKf = VVDbSW.servicelist
  if VVDkKf:
   return VVDkKf.getBouquetList()
 return None
def FFESB6(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVy14z = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVy14z.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FF0mQl():
 VVyD7q = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVT1Il = list(VVyD7q)
 return VVT1Il, VVyD7q
def FFigte():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FF5mdK(session, VVuvec):
 VVEJU8, VVjdds, VVcs7I, camCommand = FFVlZ6()
 if VVjdds:
  runLog = False
  if   VVuvec == CCH5mf.VV3mek : runLog = True
  elif VVuvec == CCH5mf.VV0AKh : runLog = True
  elif not VVcs7I          : FFWdIU(session, message="SoftCam not started yet!")
  elif fileExists(VVcs7I)        : runLog = True
  else             : FFWdIU(session, message="File not found !\n\n%s" % VVcs7I)
  if runLog:
   session.open(boundFunction(CCH5mf, VVEJU8=VVEJU8, VVjdds=VVjdds, VVcs7I=VVcs7I, VVuvec=VVuvec))
 else:
  FFWdIU(session, message="No active OSCam/NCam found !")
def FFVlZ6():
 VVEJU8 = "/etc/tuxbox/config/"
 VVjdds = None
 VVcs7I  = None
 camCommand = FFHvE5("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVjdds = "oscam"
 elif "ncam"  in camCommand : VVjdds = "ncam"
 if VVjdds:
  path = FFHvE5(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFTsBZ(path)
  if pathExists(path):
   VVEJU8 = path
  tFile = VVEJU8 + VVjdds + ".conf"
  tFile = FFHvE5("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVcs7I = tFile
 return VVEJU8, VVjdds, VVcs7I, camCommand
def FFnWMY(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFEhBS():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFtouN():
 return FFEhBS().replace(" ", "_").replace("-", "").replace(":", "")
def FF55bZ(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FF0NYM(url, outFile, timeout=3):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCzPop.VVspd4(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCzPop.VVshKZ(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFLcOy("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFUMrv(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFufQ4(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFwr4K():
 return int(FFrSA4("cat /proc/meminfo | grep MemFree | awk '{print $2}'"))
def FFJagV():
 global VVZH9I_TIME, VV43mJ
 VV43mJ  = int(FFwr4K())
 VVZH9I_TIME = iTime()
def FFNSxP():
 elapsed = iTime() - VVZH9I_TIME
 elapsed = "{:.6f}".format(elapsed).rstrip("0").rstrip(".")
 mem  = FFwr4K() - VV43mJ
 FF8fwc(">>>>>> Elapsed\t: {} seconds ... Memory\t: {} bytes".format(elapsed, mem))
def FFJjNb(SELF, message, title=""):
 SELF.session.open(boundFunction(CCmvvf, title=title, message=message, VVL4wo=True))
def FFKjl2(SELF, message, title="", VVTBXk=VVaGDj, **kwargs):
 SELF.session.open(boundFunction(CCmvvf, title=title, message=message, VVTBXk=VVTBXk, **kwargs))
def FFEW3v(SELF, message, title="")  : FFWdIU(SELF.session, message, title)
def FFV5mI(SELF, path, title="") : FFWdIU(SELF.session, "File not found !\n\n%s" % path, title)
def FFqWYJ(SELF, path, title="") : FFWdIU(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFVWVs(SELF, title="")  : FFWdIU(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFWdIU(session, message, title="") : session.open(boundFunction(CCf7Z4, title=title, message=message))
def FFiVZt(SELF, VV7s75, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VV7s75, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VV7s75, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VV7s75, boundFunction(CCt2jw, title=title, message=message, VV47ip=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFEW3v(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFUzhN(SELF, callBack_Yes, VVRCwb, callBack_No=None, title="", VVBim4=False):
 SELF.session.openWithCallback(boundFunction(FFNyuX, callBack_Yes, callBack_No)
        , boundFunction(CCwFhk, title=title, VVRCwb=VVRCwb, VVhUed=True, VVBim4=VVBim4))
def FFNyuX(callBack_Yes, callBack_No, FFUzhNed):
 if FFUzhNed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFtXOm(SELF, message="", milliSeconds=0):
 try:
  SELF["myInfoBody"].setText(str(message))
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFqFt6(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFulRq(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
myTimer = eTimer()
def FFqFt6(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFUZVK, SELF))
 try:
  myTimer_conn = myTimer.timeout.connect(boundFunction(FFUZVK, SELF))
 except:
  myTimer.callback.append(boundFunction(FFUZVK, SELF))
 myTimer.start(milliSeconds, 1)
def FFUZVK(SELF):
 myTimer.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFZUAl(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCn9YK, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCn9YK, **kwargs))
  FFBLuo(win)
  return win
 except:
  return None
def FFue1q(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCVfo3, **kwargs))
 FFBLuo(win)
 return win
def FFjswv(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   obj = SELF[name]
   SELF[name].instance.setBorderColor(parseColor("#000000"))
   SELF[name].instance.setBorderWidth(3)
   SELF[name].instance.setNoWrap(True)
  except:
   pass
def FFcCYZ(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVmgWy, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FF8cqd(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFcCYZ(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFV7UG():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FF1Slb(VVH2Qb):
 screenSize  = FFV7UG()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVH2Qb)
 return bodyFontSize
def FFsX3s(VVH2Qb, extraSpace):
 font = gFont(VVmgWy, VVH2Qb)
 VV7XV0 = fontRenderClass.getInstance().getLineHeight(font) or (VVH2Qb * 1.25)
 return int(VV7XV0 + VV7XV0 * extraSpace)
def FFy33A(fontName):
 fList = None
 try:
  from enigma import getFontFaces
  fList = getFontFaces()
 except:
  try:
   from skin import getFontFaces
   fList = getFontFaces()
  except:
   pass
 if fList and fontName in fList : return fontName
 else       : return VVmgWy
def FFQUXb(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFV7UG()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * VVrayu)
 bodyFontStr  = 'font="%s;%d"' % (VVmgWy, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFsX3s(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVmgWy, titleFontSize, alignLeftCenter)
 if winType == VV2YUz or winType == VVXfv4:
  if winType == VVXfv4 : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVKVKL:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.2)
  b2Left1 = marginLeft
  b2Left2 = b2Left1 + timeW + marginLeft
  b2Left3 = width - marginLeft - timeW
  infW = b2Left3 - b2Left2 - marginLeft
  tmp += '<widget name="myPlayBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="myPlayBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" />'   % (marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyColor)
  tmp += '<widget name="myPlayBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a005555" />' % (marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="myPlayBarM"  position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="myPlayVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="#0a002233" %s %s'   % (bodyFontStr, alignCenter)
  tmp += '<widget name="myPlayPos"  position="%d,%d" size="%d,%d" %s />' % (b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlayMsg"  position="%d,%d" size="%d,%d" %s />' % (b2Left2, b2Top, infW , barH, param)
  tmp += '<widget name="myPlayDur"  position="%d,%d" size="%d,%d" %s />' % (b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep"   position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  names = ["Jmp", "Skp", "Mrk", "Blu", "Inf"]
  b3W  = int((width - marginLeft * 6.0) / 5.0)
  left = marginLeft
  for i in range(5):
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" foregroundColor="#0affffff" backgroundColor="#11222222" %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter)
   left += b3W + marginLeft
 elif winType == VVsoAu:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVCUG2:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVUm8T:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VV8LqE:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVmgWy, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVmgWy, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VV2aOg:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFJjNbH = int(bodyH * 0.5)
  inpTop = bodyTop + FFJjNbH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFJjNbH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVmgWy, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVmgWy, mapF, alignCenter)
 elif winType == VVJl51:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVkfbA:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVmgWy, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VV2Nqk:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVmgWy, fontH, alignCenter)
 elif winType == VVcN3H:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVmgWy, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVmgWy, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVmgWy, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 else:
  if   winType == VVnLZX : align = alignLeftCenter
  elif winType == VVV8lu : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVDi9S:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VV3kF9:
   moreParams = ""
  else:
   fontStr = bodyFontStr
   if usefixedFont and winType == VVV8lu:
    fontStr = 'font="%s;%d"' % (FFy33A("Fixed"), bodyFontSize)
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" %s %s ' % (bodyColor, fontStr, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVH2Qb = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVmgWy, VVH2Qb, alignCenter)
 if topRightBtns > 0:
  btnW = int(ratioW * 80)
  btnH = int(titleH * 0.7)
  btnTop = int(titleH * 0.15)
  btnLeft = width - (btnW + btnTop)
  btnFont = int(btnH * 0.6)
  tmp += '<widget name="keyMenu2F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
  tmp += '<widget name="keyMenu2"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VVmgWy, btnFont, alignCenter)
  if topRightBtns > 1:
   btnLeft = btnLeft - btnW - 8
   tmp += '<widget name="keyMenu1F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="keyMenu1"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VVmgWy, btnFont, alignCenter)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVnGDQ = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVmgWy, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVnGDQ[i], VVmgWy, barFont, alignCenter)
   left += btnW + gap
 if winType == VVV8lu:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVnGDQ = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVnGDQ[i], VVmgWy, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFQUXb(VV2YUz, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.hiddenMenuPass = ""
  self.themsList  = []
  VVXWOy = []
  if VVN3AN:
   VVXWOy.append(("-- MY TEST --"    , "myTest"   ))
  VVXWOy.append(("File Manager"      , "FileManager"  ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Services/Channels"    , "ChannelsTools" ))
  VVXWOy.append(("IPTV"        , "IptvTools"  ))
  VVXWOy.append(("PIcons"       , "PIconsTools"  ))
  VVXWOy.append(("SoftCam"       , "SoftCam"   ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Plugins"       , "PluginsTools" ))
  VVXWOy.append(("Terminal"       , "Terminal"  ))
  VVXWOy.append(("Backup & Restore"     , "BackupRestore" ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Date/Time"      , "Date_Time"  ))
  VVXWOy.append(("Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVXWOy)
  FFZrGE(self, VVXWOy=VVXWOy)
  FFnxzu(self["keyRed"] , "Exit")
  FFnxzu(self["keyGreen"] , "Settings")
  FFnxzu(self["keyYellow"], "Dev. Info.")
  FFnxzu(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVKDpI       ,
   "yellow"  : self.VVSLIt       ,
   "blue"   : self.VV0ZZL       ,
   "info"   : self.VV0ZZL       ,
   "next"   : self.VVqHjS       ,
   "0"    : boundFunction(self.VVcvyU, 0) ,
   "1"    : boundFunction(self.VVzScv, 1)   ,
   "2"    : boundFunction(self.VVzScv, 2)   ,
   "3"    : boundFunction(self.VVzScv, 3)   ,
   "4"    : boundFunction(self.VVzScv, 4)   ,
   "5"    : boundFunction(self.VVzScv, 5)   ,
   "6"    : boundFunction(self.VVzScv, 6)   ,
   "7"    : boundFunction(self.VVzScv, 7)   ,
   "8"    : boundFunction(self.VVzScv, 8)   ,
   "9"    : boundFunction(self.VVzScv, 9)
  })
  self.onShown.append(self.VVqv5b)
  self.onClose.append(self.onExit)
  global VVqAV4, VViQ7B
  VVqAV4 = VViQ7B = False
 def VVOF6C(self):
  item = FFU5pX(self)
  self.VVzScv(item)
 def VVzScv(self, item):
  if item is not None:
   if   item == "myTest"     : self.VViYtg()
   elif item in ("FileManager"  , 1) : self.session.open(CCMIrG)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCfCKg)
   elif item in ("IptvTools"  , 3) : self.session.open(CCzPop)
   elif item in ("PIconsTools"  , 4) : self.VVBlGf()
   elif item in ("SoftCam"   , 5) : self.session.open(CC9rMs)
   elif item in ("PluginsTools" , 6) : self.session.open(CCPPjN)
   elif item in ("Terminal"  , 7) : self.session.open(CCs1DY)
   elif item in ("BackupRestore" , 8) : self.session.open(CCRYx1)
   elif item in ("Date_Time"  , 9) : self.session.open(CCSXBa)
   elif item in ("CheckInternet" , 10) : self.session.open(CCpFbI)
   else         : self.close()
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  FFNsDm(self["myMenu"])
  FF8cqd(self)
  FFjswv(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVFjWv)
  self["myTitle"].setText(title)
  VVwfI3, VVXIRw, VVPPZe, VVDZ1a, VV3Gub = FFnlPn()
  self.VVQUbG()
  if VVwfI3 or VVXIRw or VVPPZe or VVDZ1a or VV3Gub:
   VV269Y = lambda path, subj: "%s:\n%s\n\n" % (subj, FFW8xd(path, VV7KZt)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VV269Y(VVwfI3   , "Backup/Restore Path"    )
   txt += VV269Y(VVXIRw  , "Created Package Files (IPK/DEB)" )
   txt += VV269Y(VVPPZe  , "Download Packages (from feeds)" )
   txt += VV269Y(VVDZ1a , "Exported Tables"     )
   txt += VV269Y(VV3Gub , "Exported PIcons"     )
   txt += "\nYou can change paths from Settings.\n"
   FFKjl2(self, txt, title="Settings Paths")
  if (EASY_MODE or VVTTyi or VVN3AN):
   FFwL0h(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFtXOm(self, "Welcome", 300)
  FF1XIo(boundFunction(self.VVWx4B, title))
 def VVWx4B(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CClCHG.VV45Z4()
   if url:
    newWebVer = CClCHG.VVEjNJ(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFLcOy("rm /tmp/ajpanel*"))
 def VVcvyU(self, digit):
  self.hiddenMenuPass += str(digit)
  if len(self.hiddenMenuPass) == 4:
   if self.hiddenMenuPass == "0" * 4:
    global VVqAV4
    VVqAV4 = True
    FFwL0h(self["myTitle"], "#800080")
   else:
    self.hiddenMenuPass = "x"
 def VVqHjS(self):
  self.hiddenMenuPass += ">"
  if self.hiddenMenuPass == ("0" * 4) + ">>":
   global VViQ7B
   VViQ7B = True
   FFwL0h(self["myTitle"], "#dd5588")
 def VVBlGf(self):
  found = False
  pPath = CCgbc1.VVrn8y()
  if pathExists(pPath):
   for fName, fType in CCgbc1.VVgeVx(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCgbc1)
  else:
   VVXWOy = []
   VVXWOy.append(("PIcons Manager" , "CCgbc1" ))
   VVXWOy.append(VVGV45)
   VVXWOy.append(CCgbc1.VVQo0i())
   VVXWOy.append(VVGV45)
   VVXWOy += CCgbc1.VVujPD()
   FFue1q(self, self.VVeQOT, VVXWOy=VVXWOy)
 def VVeQOT(self, item=None):
  if item:
   if   item == "CCgbc1"   : self.session.open(CCgbc1)
   elif item == "VVHSXx"  : CCgbc1.VVHSXx(self)
   elif item == "VVjGWw"  : CCgbc1.VVjGWw(self)
   elif item == "findPiconBrokenSymLinks" : CCgbc1.VV10ew(self, True)
   elif item == "FindAllBrokenSymLinks" : CCgbc1.VV10ew(self, False)
 def VVKDpI(self):
  self.session.open(CClCHG)
 def VVSLIt(self):
  self.session.open(CCDziT)
 def VV0ZZL(self):
  changeLogFile = VVhwNz + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FFUM2c(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFW8xd("\n%s\n%s\n%s" % (VVklh1, line, VVklh1), VVdNwi, VVI2d4)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FFW8xd(line, VVqb5h, VVI2d4)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFKjl2(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVFjWv), VVH2Qb=26)
 def VVQUbG(self):
  p = VVoi8H + "ajpanel_colors"
  if fileExists(p):
   txt = FFteHI(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    try:
     if   txt == "main_title_fg" : FFTsrs(self["myTitle"], c)
     elif txt == "main_title_bg" : FFwL0h(self["myTitle"], c)
     elif txt == "main_body_fg" : FFTsrs(self["myMenu"], c)
     elif txt == "main_body_bg" :
      FFwL0h(self["myBody"], c)
      FFwL0h(self["myMenu"], c)
     elif txt == "main_cursor_fg" : self["myMenu"].instance.setForegroundColorSelected(parseColor(c))
     elif txt == "main_cursor_bg" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(c))
     elif txt == "main_bar_bg"  : FFwL0h(self["myBar"], c)
    except:
     pass
 def VViYtg(self):
  opt = 11
  if   opt ==  0 : FFJjNb(self, "This is My Message.", "Testing")
  elif opt == 11:
   pass
class CCDziT(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFQUXb(VV2YUz, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVXWOy = []
  VVXWOy.append(("Settings File"        , "SettingsFile"   ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Box Info"          , "VVgRgO"    ))
  VVXWOy.append(("Tuners Info"         , "VVwLEI"   ))
  VVXWOy.append(("Python Version"        , "VVF5Q3"   ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Screen Size"         , "ScreenSize"    ))
  VVXWOy.append(("Locale"          , "Locale"     ))
  VVXWOy.append(("Processor"         , "Processor"    ))
  VVXWOy.append(("Operating System"        , "OperatingSystem"   ))
  VVXWOy.append(("Drivers"          , "drivers"     ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("System Users"         , "SystemUsers"    ))
  VVXWOy.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVXWOy.append(("Uptime"          , "Uptime"     ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Host Name"         , "HostName"    ))
  VVXWOy.append(("MAC Address"         , "MACAddress"    ))
  VVXWOy.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVXWOy.append(("Network Status"        , "NetworkStatus"   ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Disk Usage"         , "VVRqCc"    ))
  VVXWOy.append(("Mount Points"         , "MountPoints"    ))
  VVXWOy.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVXWOy.append(("USB Devices"         , "USB_Devices"    ))
  VVXWOy.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVXWOy.append(("Directory Size"        , "DirectorySize"   ))
  VVXWOy.append(("Memory"          , "Memory"     ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVXWOy.append(("Running Processes"       , "RunningProcesses"  ))
  VVXWOy.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFZrGE(self, VVXWOy=VVXWOy, title="Device Information")
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  FFNsDm(self["myMenu"])
  FF8cqd(self)
 def VVOF6C(self):
  global VVaLC9
  VVaLC9 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCoIsW)
   elif item == "VVgRgO"    : self.VVgRgO()
   elif item == "VVwLEI"   : self.VVwLEI()
   elif item == "VVF5Q3"   : self.VVF5Q3()
   elif item == "ScreenSize"    : FFKjl2(self, "Width\t: %s\nHeight\t: %s" % (FFV7UG()[0], FFV7UG()[1]))
   elif item == "Locale"     : self.VVLG5r()
   elif item == "Processor"    : self.VVDU5N()
   elif item == "OperatingSystem"   : FF2NFl(self, "uname -a"        )
   elif item == "drivers"     : self.VVVA7R()
   elif item == "SystemUsers"    : FF2NFl(self, "id"          )
   elif item == "LoggedInUsers"   : FF2NFl(self, "who -a"         )
   elif item == "Uptime"     : FF2NFl(self, "uptime"         )
   elif item == "HostName"     : FF2NFl(self, "hostname"        )
   elif item == "MACAddress"    : self.VVLCHk()
   elif item == "NetworkConfiguration"  : FF2NFl(self, "ifconfig %s %s" % (FF3Nyd("HWaddr", VVbXIp), FF3Nyd("addr:", VVFlyn)))
   elif item == "NetworkStatus"   : FF2NFl(self, "netstat -tulpn"       )
   elif item == "VVRqCc"    : self.VVRqCc()
   elif item == "MountPoints"    : FF2NFl(self, "mount %s" % (FF3Nyd(" on ", VVFlyn)))
   elif item == "FileSystemTable"   : FF2NFl(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FF2NFl(self, "lsusb"         )
   elif item == "listBlockDevices"   : FF2NFl(self, "blkid"         )
   elif item == "DirectorySize"   : FF2NFl(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVegm6="Reading size ...")
   elif item == "Memory"     : FF2NFl(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VV3GYt()
   elif item == "RunningProcesses"   : FF2NFl(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FF2NFl(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVb6PP()
   else         : self.close()
 def VVLCHk(self):
  res = FFrSA4("ip link")
  list = iFindall("[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFKjl2(self, txt)
  else:
   FF2NFl(self, "ip link")
 def VVX2m8(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFUtqa(cmd)
  return lines
 def VVxnHi(self, lines, headerRepl, widths, VVqjzl):
  VVgBMX = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVgBMX.append(parts)
  if VVgBMX and len(header) == len(widths):
   VVgBMX.sort(key=lambda x: x[0].lower())
   FFZUAl(self, None, header=header, VVXy7C=VVgBMX, VVqjzl=VVqjzl, VV08hy=widths, VVH2Qb=22, VVD19W=True)
   return True
  else:
   return False
 def VVRqCc(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VVX2m8(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVqjzl = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVxnHi(lines, headerRepl, widths, VVqjzl)
  if not allOK:
   lines = FFUtqa(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFcHPD(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVmHHA:
     note = "\n%s" % FFW8xd("Green = Mounted Partitions", VVmHHA)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVFlyn
     elif line.endswith(mountList) : color = VVmHHA
     else       : color = VVqb5h
     txt += FFW8xd(line, color) + "\n"
    FFKjl2(self, txt + note)
   else:
    FFEW3v(self, "Not data from system !")
 def VV3GYt(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVX2m8(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVqjzl = (LEFT , CENTER, LEFT )
  allOK = self.VVxnHi(lines, headerRepl, widths, VVqjzl)
  if not allOK:
   FF2NFl(self, cmd)
 def VVLG5r(self):
  from locale import getdefaultlocale
  loc = getdefaultlocale()
  FFKjl2(self, "Language\t: %s\nEncoding\t: %s" % (loc[0], loc[1]))
 def VVVA7R(self):
  cmd = FFKs6c(VVWSiA, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FF2NFl(self, cmd)
  else : FFVWVs(self)
 def VVDU5N(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FF2NFl(self, cmd)
 def VVb6PP(self):
  cmd = FFKs6c(VVVX1J, "| grep secondstage")
  if cmd : FF2NFl(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFVWVs(self)
 def VVgRgO(self):
  c = VVmHHA
  VVXy7C = []
  VVXy7C.append((FFW8xd("Box Type"  , c), FFW8xd(self.VVVscU("boxtype").upper(), c)))
  VVXy7C.append((FFW8xd("Board Version", c), FFW8xd(self.VVVscU("board_revision") , c)))
  VVXy7C.append((FFW8xd("Chipset"  , c), FFW8xd(self.VVVscU("chipset")  , c)))
  VVXy7C.append((FFW8xd("S/N"   , c), FFW8xd(self.VVVscU("sn")    , c)))
  VVXy7C.append((FFW8xd("Version"  , c), FFW8xd(self.VVVscU("version")  , c)))
  VVcMAj   = []
  VVhKiZ = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVhKiZ = SystemInfo[key]
     else:
      VVcMAj.append((FFW8xd(str(key), VVhJi6), FFW8xd(str(SystemInfo[key]), VVhJi6)))
  except:
   pass
  if VVhKiZ:
   VVqZ6Q = self.VVqAq7(VVhKiZ)
   if VVqZ6Q:
    VVqZ6Q.sort(key=lambda x: x[0].lower())
    VVXy7C += VVqZ6Q
  if VVcMAj:
   VVcMAj.sort(key=lambda x: x[0].lower())
   VVXy7C += VVcMAj
  if VVXy7C:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFZUAl(self, None, header=header, VVXy7C=VVXy7C, VV08hy=widths, VVH2Qb=22, VVD19W=True)
  else:
   FFKjl2(self, "Could not read info!")
 def VVVscU(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFUM2c(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVqAq7(self, mbDict):
  try:
   mbList = list(mbDict)
   VVXy7C = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVXy7C.append((FFW8xd(subject, VVFlyn), FFW8xd(value, VVFlyn)))
  except:
   pass
  return VVXy7C
 def VVwLEI(self):
  txt = self.VVDtNz("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVDtNz("/proc/bus/nim_sockets")
  if not txt: txt = self.VVGOg4()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFKjl2(self, txt)
 def VVGOg4(self):
  txt = ""
  VV269Y = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VV269Y("Slot Name" , slot.getSlotName())
     txt += FFW8xd(slotName, VVFlyn)
     txt += VV269Y("Description"  , slot.getFullDescription())
     txt += VV269Y("Frontend ID"  , slot.frontend_id)
     txt += VV269Y("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVDtNz(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFUM2c(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFW8xd(line, VVFlyn)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVF5Q3(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFKjl2(self, txt)
class CCoIsW(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFQUXb(VV2YUz, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVXWOy = []
  VVXWOy.append(("Settings (All)"   , "Settings_All"   ))
  VVXWOy.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVXWOy.append(("Settings (FHDG-17)"  , "Settings_FHDG_17"  ))
  VVXWOy.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVXWOy.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVXWOy.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVXWOy.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVXWOy.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFZrGE(self, VVXWOy=VVXWOy)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  FFNsDm(self["myMenu"])
  FF8cqd(self)
 def VVOF6C(self):
  global VVaLC9
  VVaLC9 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FF2NFl(self, cmd                )
   elif item == "Settings_HotKeys"   : FF2NFl(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FF2NFl(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FF2NFl(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FF2NFl(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FF2NFl(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FF2NFl(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FF2NFl(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CC9rMs(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFQUXb(VV2YUz, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVEJU8, VVjdds, VVcs7I, camCommand = FFVlZ6()
  self.VVjdds = VVjdds
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVXWOy = []
  VVXWOy.append(("OSCam Files"        , "OSCamFiles"  ))
  VVXWOy.append(("NCam Files"        , "NCamFiles"  ))
  VVXWOy.append(("CCcam Files"        , "CCcamFiles"  ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVXWOy.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVXWOy.append(VVGV45)
  if VVjdds:
   if   "oscam" in VVjdds : camName = "OSCam"
   elif "ncam"  in VVjdds : camName = "NCam"
   VVXWOy.append((camName + " Info."      , "camInfo"   ))
   VVXWOy.append((camName + " Live Status"    , "camLiveStatus" ))
   VVXWOy.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVXWOy.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVXWOy.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFZrGE(self, VVXWOy=VVXWOy)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  FFNsDm(self["myMenu"])
  FF8cqd(self)
 def VVOF6C(self):
  global VVaLC9
  VVaLC9 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CC0pil, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CC0pil, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CC0pil, "cccam"))
   elif item == "OSCamReaders"  : self.VVAX3r("os")
   elif item == "NSCamReaders"  : self.VVAX3r("n")
   elif item == "camInfo"   : FFreYg(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FF5mdK(self.session, CCH5mf.VV3mek)
   elif item == "camLiveReaders" : FF5mdK(self.session, CCH5mf.VV0AKh)
   elif item == "camLiveLog"  : FF5mdK(self.session, CCH5mf.VVvWKi)
   else       : self.close()
 def VVAX3r(self, camPrefix):
  VVgBMX = self.VVfib8(camPrefix)
  if VVgBMX:
   VVgBMX.sort(key=lambda x: int(x[0]))
   if self.VVjdds and self.VVjdds.startswith(camPrefix):
    VVUhO3 = ("Toggle State", self.VVBO10, [camPrefix], "Changing State ...")
   else:
    VVUhO3 = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVqjzl  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFZUAl(self, None, header=header, VVXy7C=VVgBMX, VVqjzl=VVqjzl, VV08hy=widths, VVH2Qb=22, VVUhO3=VVUhO3, VVxpps=True)
 def VVfib8(self, camPrefix):
  readersFile = self.VVEJU8 + camPrefix + "cam.server"
  VVgBMX = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFUM2c(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVgBMX.append((str(len(VVgBMX) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVgBMX:
    FFEW3v(self, "No readers found !")
  else:
   FFV5mI(self, readersFile)
  return VVgBMX
 def VVBO10(self, VVShs0, camPrefix):
  configFile  = "%s%scam.conf" % (self.VVEJU8, camPrefix)
  readerState  = VVShs0.VVB4LN(1)
  readerLabel  = VVShs0.VVB4LN(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CC9rMs.VVDUru(self, camPrefix, configFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVShs0.VVGqtm()
    FFEW3v(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVgBMX = self.VVfib8(camPrefix)
   if VVgBMX:
    VVShs0.VVrhOZ(VVgBMX)
 @staticmethod
 def VVDUru(SELF, camPrefix, configFile, urlPart, urlAction):
  if fileExists(configFile):
   lines = FFUM2c(configFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFEW3v(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFEW3v(SELF, "SoftCAM Web Port not found in file:\n\n%s" % configFile)
    return None
  else:
   FFV5mI(SELF, configFile)
   return None
  if not iRequest:
   FFEW3v(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFEW3v(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFEW3v(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CC0pil(Screen):
 def __init__(self, VVOO7a, session, args=0):
  self.skin, self.skinParam = FFQUXb(VV2YUz, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVEJU8, VVjdds, VVcs7I, camCommand = FFVlZ6()
  if   VVOO7a == "ncam" : self.prefix = "n"
  elif VVOO7a == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVXWOy = []
  if self.prefix == "":
   VVXWOy.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVXWOy.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVXWOy.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVXWOy.append(("constant.cw"         , "x_constant_cw" ))
   VVXWOy.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVXWOy.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVXWOy.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVXWOy.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVXWOy.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVXWOy.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVXWOy.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVXWOy.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVXWOy.append(VVGV45)
   VVXWOy.append(("SoftCam.Key"         , "x_SoftCam_Key" ))
   VVXWOy.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVXWOy.append(VVGV45)
   VVXWOy.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVXWOy.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVXWOy.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFZrGE(self, VVXWOy=VVXWOy)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  FFNsDm(self["myMenu"])
  FF8cqd(self)
 def VVOF6C(self):
  global VVaLC9
  VVaLC9 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFW3ac(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFW3ac(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFW3ac(self, self.VVEJU8 + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFW3ac(self, self.VVEJU8 + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VV9w9E("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VV9w9E("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VV9w9E("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VV9w9E("cam.provid"        )
   elif item == "x_cam_server"  : self.VV9w9E("cam.server"        )
   elif item == "x_cam_services" : self.VV9w9E("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VV9w9E("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VV9w9E("cam.user"        )
   elif item == "x_VVklh1"   : pass
   elif item == "x_SoftCam_Key" : FFW3ac(self, self.VVEJU8 + "SoftCam.Key"   )
   elif item == "x_CCcam_cfg"  : FFW3ac(self, self.VVEJU8 + "CCcam.cfg"    )
   elif item == "x_VVklh1"   : pass
   elif item == "x_cam_log"  : FFW3ac(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFW3ac(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFW3ac(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VV9w9E(self, fileName):
  FFW3ac(self, self.VVEJU8 + self.prefix + fileName)
class CCH5mf(Screen):
 VV3mek  = 0
 VV0AKh = 1
 VVvWKi = 2
 def __init__(self, session, VVEJU8="", VVjdds="", VVcs7I="", VVuvec=VV3mek):
  self.skin, self.skinParam = FFQUXb(VVV8lu, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVcs7I   = VVcs7I
  self.VVuvec  = VVuvec
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVEJU8 + VVjdds + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVjdds : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.configFile  = "%s%scam.conf" % (VVEJU8, self.camPrefix)
  if self.VVuvec == self.VV3mek:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVuvec == self.VV0AKh:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFZrGE(self, self.Title, addScrollLabel=True)
  FFnxzu(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VV3ulr
  self.onShown.append(self.VVqv5b)
  self.onClose.append(self.onExit)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  self["myLabel"].VV0fFU(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFjswv(self)
  self.VV3ulr()
 def onExit(self):
  self.timer.stop()
 def VV4dpR(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVV0sT)
  except:
   self.timer.callback.append(self.VVV0sT)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFtXOm(self, "Started", 1000)
 def VVsplN(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVV0sT)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFtXOm(self, "Stopped", 1000)
 def VV3ulr(self):
  if self.timerRunning:
   self.VVsplN()
  else:
   self.VV4dpR()
   if self.VVuvec == self.VV3mek or self.VVuvec == self.VV0AKh:
    if self.VVuvec == self.VV3mek : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CC9rMs.VVDUru(self, self.camPrefix, self.configFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FF1XIo(self.VVgLwU)
    else:
     self.close()
   else:
    self.VVlfNW()
 def VVV0sT(self):
  if self.timerRunning:
   if   self.VVuvec == self.VV3mek : self.VVQD8s()
   elif self.VVuvec == self.VV0AKh : self.VVQD8s()
   else            : self.VVlfNW()
 def VVlfNW(self):
  if fileExists(self.VVcs7I):
   fTime = FFnWMY(os.path.getmtime(self.VVcs7I))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VV0ykp(), VVTBXk=VVkxAh)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVcs7I)
 def VVgLwU(self):
  self.VVQD8s()
 def VVQD8s(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFW8xd("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVdNwi))
   self.camWebIfErrorFound = True
   self.VVsplN()
   return
  page = page.decode('UTF-8')
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVuvec == self.VV3mek : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFW8xd("Error while parsing data elements !\n\nError = %s" % str(e), VV7KZt)
   self.camWebIfErrorFound = True
   self.VVsplN()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVLE0K(root)
  self["myLabel"].setText(txt, VVTBXk=VVkxAh)
  self["myBar"].setText("Last Update : %s" % FFEhBS())
 def VVLE0K(self, rootElement):
  def VV269Y(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVuvec == self.VV3mek:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFW8xd(status, VVmHHA)
    else          : status = FFW8xd(status, VV7KZt)
    txt += VVklh1 + "\n"
    txt += VV269Y("Name"  , name)
    txt += VV269Y("Description" , desc)
    txt += VV269Y("IP/Port"  , "%s : %s" % (ip, port))
    txt += VV269Y("Protocol" , protocol)
    txt += VV269Y("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFW8xd("Yes", VVmHHA)
    else    : enabTxt = FFW8xd("No", VV7KZt)
    txt += VVklh1 + "\n"
    txt += VV269Y("Label"  , label)
    txt += VV269Y("Protocol" , protocol)
    txt += VV269Y("Enabled" , enabTxt)
  return txt
 def VV0ykp(self):
  wordsDict = self.VV3DHA()
  color = [ VVFlyn, VVbXIp, VVmHHA, VV7KZt, VVhJi6, VVUYyn]
  lines = FFUtqa("tail -n %d %s" % (100, self.VVcs7I))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVdNwi + line[:19] + VVqb5h + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVI2d4 + line[ndx + 3:] + VVqb5h
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVFlyn + line[ndx + 8 : ndx1 + 4] + VVqb5h + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVqb5h)
   elif line.startswith("----") or ">>" in line:
    line = FFW8xd(line, VVFlyn)
   txt += line + "\n"
  return txt
 def VV3DHA(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFUM2c(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CCRYx1(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFQUXb(VV2YUz, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVXWOy = []
  VVXWOy.append(("Backup Channels"        , "VV4Qx4"   ))
  VVXWOy.append(("Restore Channels"        , "Restore_Channels"  ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Backup SoftCAM Files"       , "VVH7cF" ))
  VVXWOy.append(("Restore SoftCAM Files"      , "Restore_SoftCAM_Files" ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Backup Tuner Settings"      , "Backup_TunerDiSEqC"  ))
  VVXWOy.append(("Restore Tuner Settings"      , "Restore_TunerDiSEqC"  ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Backup HotKeys & FHDG17 Settings"    , "Backup_Hotkey_FHDG17" ))
  VVXWOy.append(("Restore HotKeys & FHDG17 Settings"   , "Restore_Hotkey_FHDG17" ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Backup Network Settings"      , "VVs1WT"   ))
  VVXWOy.append(("Restore Network Settings"      , "Restore_Network"   ))
  if VViQ7B:
   VVXWOy.append(VVGV45)
   VVXWOy.append((VVdNwi + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME , "VVTv7L"   ))
   VVXWOy.append((VVmHHA + "2- Create %s for IPK"   % PLUGIN_NAME , "createMyIpk"   ))
   VVXWOy.append((VVmHHA + "3- Create %s for DEB"   % PLUGIN_NAME , "createMyDeb"   ))
   VVXWOy.append((VVhJi6 + "Create %s TAR (Absolute Path)" % PLUGIN_NAME , "createMyTar"   ))
   VVXWOy.append((VVhJi6 + "Decode %s Crash Report"   % PLUGIN_NAME , "VV1xRd" ))
  FFZrGE(self, VVXWOy=VVXWOy)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  FFNsDm(self["myMenu"])
  FF8cqd(self)
 def VVOF6C(self):
  global VVaLC9
  VVaLC9 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV4Qx4"    : self.VV4Qx4()
   elif item == "Restore_Channels"    : self.VVHax8("channels_backup*.tar.gz", self.VVMaoU)
   elif item == "VVH7cF"   : self.VVH7cF()
   elif item == "Restore_SoftCAM_Files"  : self.VVHax8("softcam_backup*.tar.gz", self.VVEDlS)
   elif item == "Backup_TunerDiSEqC"   : self.VVR8wT("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVHax8("tuner_backup*.backup", boundFunction(self.VVNd8B, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVR8wT("hotkey_fhdg17_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVHax8("hotkey_fhdg17_backup*.backup", boundFunction(self.VVNd8B, "misc"))
   elif item == "VVs1WT"    : self.VVs1WT()
   elif item == "Restore_Network"    : self.VVHax8("network_backup*.tar.gz", self.VVMmDu)
   elif item == "VVTv7L"     : FFUzhN(self, boundFunction(FFBV5V, self, boundFunction(CCRYx1.VVTv7L, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVCMiv(False)
   elif item == "createMyDeb"     : self.VVCMiv(True)
   elif item == "createMyTar"     : self.VVohOn()
   elif item == "VV1xRd"   : self.VV1xRd()
 @staticmethod
 def VVTv7L(SELF):
  OBF_Path = VVt4G6 + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVt4G6, VVFjWv, VVXWXv)
   if err : FFEW3v(SELF, err)
   else : FFKjl2(SELF, txt)
  else:
   FFV5mI(SELF, OBF_Path)
 def VVCMiv(self, VVFOlr):
  OBF_Path = VVt4G6 + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFEW3v(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVt4G6)
  os.system("mv -f %s %s" % (VVt4G6 + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVt4G6 + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVt4G6 + "plugin.py"))
  self.session.openWithCallback(self.VVCMiv1, boundFunction(CCnXtk, path=VVt4G6, VVFOlr=VVFOlr))
 def VVCMiv1(self):
  os.system("mv -f %s %s" % (VVt4G6 + "OBF/main.py"  , VVt4G6))
  os.system("mv -f %s %s" % (VVt4G6 + "OBF/plugin.py" , VVt4G6))
 def VV1xRd(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFEW3v(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFEW3v(self, "No log files in:\n\n%s" % path)
   return
  VVXy7C = []
  for f in files:
   f = os.path.basename(f)
   VVXy7C.append((f, f))
  FFue1q(self, boundFunction(self.VVrAef, path), VVXWOy=VVXy7C)
 def VVrAef(self, path, item=None):
  if item:
   codF = ""
   cFiles = iGlob("%s*.list" % path)
   if cFiles:
    codF = cFiles[0]
    if fileExists(codF):
     logF = path + item
     if fileExists(logF):
      lst  = []
      lines = FFUM2c(codF)
      for line in lines:
       line = line.split(":")[1]
       parts = line.split("->")
       lst.append((parts[1].strip(), parts[0].strip()))
      if lst:
       logTxt = FFteHI(logF)
       for item in lst:
        logTxt = logTxt.replace(item[0], item[1])
       resF = logF + ".decoded.log"
       with open(resF, "w") as f:
        f.write(logTxt)
       FFJjNb(self, "Output File:\n\n%s" % resF)
      else: FFEW3v(self, "No codes in : %s" % codF)
     else: FFV5mI(self, logF)
   else: FFV5mI(self, codF)
 def VVohOn(self):
  VVXy7C = []
  VVXy7C.append("%s%s" % (VVt4G6, "*.py"))
  VVXy7C.append("%s%s" % (VVt4G6, "*.png"))
  VVXy7C.append("%s%s" % (VVt4G6, "*.xml"))
  VVXy7C.append("%s"  % (VVhwNz))
  FFdctT(self, VVXy7C, "%s_%s" % (PLUGIN_NAME, VVFjWv), addTimeStamp=False)
 def VV4Qx4(self):
  path1 = VVlT2l
  path2 = "/etc/tuxbox/"
  VVXy7C = []
  VVXy7C.append("%s%s" % (path1, "*.tv"))
  VVXy7C.append("%s%s" % (path1, "*.radio"))
  VVXy7C.append("%s%s" % (path1, "*list"))
  VVXy7C.append("%s%s" % (path1, "lamedb*"))
  VVXy7C.append("%s%s" % (path2, "*.xml"))
  FFdctT(self, VVXy7C, "channels_backup", addTimeStamp=True)
 def VVH7cF(self):
  VVXy7C = []
  VVXy7C.append("/etc/tuxbox/config/")
  VVXy7C.append("/usr/keys/")
  VVXy7C.append("/usr/scam/")
  VVXy7C.append("/etc/CCcam.cfg")
  FFdctT(self, VVXy7C, "softcam_backup", addTimeStamp=True)
 def VVs1WT(self):
  VVXy7C = []
  VVXy7C.append("/etc/hostname")
  VVXy7C.append("/etc/default_gw")
  VVXy7C.append("/etc/resolv.conf")
  VVXy7C.append("/etc/wpa_supplicant*.conf")
  VVXy7C.append("/etc/network/interfaces")
  VVXy7C.append("/etc/enigma2/nameserversdns.conf")
  FFdctT(self, VVXy7C, "network_backup", addTimeStamp=True)
 def VVMaoU(self, fileName):
  if fileName:
   FFUzhN(self, boundFunction(self.VVjWK6, fileName), "Overwrite current channels ?")
 def VVjWK6(self, fileName):
  path = "%s%s" % (VVoi8H, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCfCKg.VVqLz6()
   lamedb5File, diabled5File = CCfCKg.VVAddD()
   cmd = ""
   cmd += FFLcOy("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFLcOy("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FF1Rf4()
   if res == 0 : FFJjNb(self, "Channels Restored.")
   else  : FFEW3v(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFV5mI(self, path)
 def VVEDlS(self, fileName):
  if fileName:
   FFUzhN(self, boundFunction(self.VVTKkY, fileName), "Overwrite SoftCAM files ?")
 def VVTKkY(self, fileName):
  fileName = "%s%s" % (VVoi8H, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVklh1
   note = "You may need to restart your SoftCAM."
   FFwT7C(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FF3Nyd(note, VVFlyn), sep))
  else:
   FFV5mI(self, fileName)
 def VVMmDu(self, fileName):
  if fileName:
   FFUzhN(self, boundFunction(self.VVg1tx, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVg1tx(self, fileName):
  fileName = "%s%s" % (VVoi8H, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFb6xn(self,  cmd)
  else:
   FFV5mI(self, fileName)
 def VVHax8(self, pattern, callBackFunction, isTuner=False):
  title = FFSb2Q()
  if pathExists(VVoi8H):
   myFiles = iGlob("%s%s" % (VVoi8H, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVXy7C = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVXy7C.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VV2cC5 = ("Sat. List", self.VVkM6i)
    else  : VV2cC5 = None
    FFue1q(self, callBackFunction, title=title, VVXWOy=VVXy7C, VV2cC5=VV2cC5)
   else:
    FFEW3v(self, "No files found in:\n\n%s" % VVoi8H, title)
  else:
   FFEW3v(self, "Path not found:\n\n%s" % VVoi8H, title)
 def VVR8wT(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCLvxk()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVIJKb, filePrefix))
 def VVIJKb(self, filePrefix, result, retval):
  title = FFSb2Q()
  if pathExists(VVoi8H):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFEW3v(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVoi8H, filePrefix, FFtouN())
    try:
     VVXy7C = str(result.strip()).split()
     if VVXy7C:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVXy7C:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVklh1, FFW8xd(fName, VVFlyn), VVklh1)
       FFKjl2(self, txt, title=title, VVTBXk=VVkxAh)
      else:
       FFEW3v(self, "File creation failed!", title)
     else:
      FFEW3v(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFLcOy("rm %s" % fName))
     FFEW3v(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFLcOy("rm %s" % fName))
     FFEW3v(self, "Error while writing file.")
  else:
   FFEW3v(self, "Path not found:\n\n%s" % VVoi8H, title)
 def VVNd8B(self, mode, path):
  if path:
   path = "%s%s" % (VVoi8H, path)
   if fileExists(path):
    lines = FFUM2c(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys/FHDG17"
     FFUzhN(self, boundFunction(self.VVa0nz, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFqWYJ(self, path, title=FFSb2Q())
   else:
    FFV5mI(self, path)
 def VVa0nz(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVZwQE = []
  VVZwQE.append("echo -e 'Reading current settings ...'")
  VVZwQE.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVZwQE.append("echo -e 'Preparing new settings ...'")
  VVZwQE.append(settingsLines)
  VVZwQE.append("echo -e 'Applying new settings ...'")
  VVZwQE.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFxkJ6(self, VVZwQE)
 def VVkM6i(self, VVz4aFObj, path):
  if not path:
   return
  path = VVoi8H + path
  if not fileExists(path):
   FFV5mI(self, path)
   return
  txt = FFteHI(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVXy7C  = []
   for item in satList:
    VVXy7C.append("%s\t%s" % (item[0], FFUZWq(item[1])))
   FFKjl2(self, VVXy7C, title="  Satellites List")
  else:
   FFEW3v(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCPPjN(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFQUXb(VV2YUz, 850, 700, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVXWOy = []
  VVXWOy.append(("Plugins Browser List"       , "VV0jqP"   ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVXWOy.append(("Remove Packages (show all)"     , "VVj0z9sAll"   ))
  VVXWOy.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Update List of Available Packages"   , "VVa9Q9"   ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Packaging Tool"        , "VVXr3t"    ))
  VVXWOy.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFZrGE(self, VVXWOy=VVXWOy)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  FFNsDm(self["myMenu"])
  FF8cqd(self)
 def VVOF6C(self):
  global VVaLC9
  VVaLC9 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV0jqP"   : self.VV0jqP()
   elif item == "pluginsDirList"    : self.VViHV8()
   elif item == "downloadInstallPackages"  : FFBV5V(self, boundFunction(self.VVBaOU, 0, ""))
   elif item == "VVj0z9sAll"   : FFBV5V(self, boundFunction(self.VVBaOU, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFBV5V(self, boundFunction(self.VVBaOU, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVa9Q9"   : self.VVa9Q9()
   elif item == "VVXr3t"    : self.VVXr3t()
   elif item == "packagesFeeds"    : self.VVHSjs()
   else          : self.close()
 def VViHV8(self):
  extDirs  = FF9zum(VVCrBY)
  sysDirs  = FF9zum(VVO2Lq)
  VVXy7C  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVXy7C.append((item, VVCrBY + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVXy7C.append((item, VVO2Lq + item))
  if VVXy7C:
   VVXy7C = sorted(VVXy7C, key=lambda x: x[0].lower())
   VV6mer = ("Package Info.", self.VV747w, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFZUAl(self, None, header=header, VVXy7C=VVXy7C, VV08hy=widths, VVH2Qb=28, VV6mer=VV6mer)
  else:
   FFEW3v(self, "Nothing found!")
 def VV747w(self, VVShs0, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVCrBY) : loc = "extensions"
  elif path.startswith(VVO2Lq) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVTQa0(package)
  else:
   FFEW3v(self, "No info!")
 def VVHSjs(self):
  pkg = FFqtwu()
  if pkg : FF2NFl(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFVWVs(self)
 def VV0jqP(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VV269Y(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVklh1 + "\n"
    txt += VV269Y("Number"   , str(c))
    txt += VV269Y("Name"   , FFW8xd(str(p.name), VVFlyn))
    txt += VV269Y("Path"  , p.path  )
    txt += VV269Y("Description" , p.description )
    txt += VV269Y("Icon"  , p.iconstr  )
    txt += VV269Y("Wakeup Fnc" , p.wakeupfnc )
    txt += VV269Y("NeedsRestart", p.needsRestart)
    txt += VV269Y("Internal" , p.internal )
    txt += VV269Y("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFKjl2(self, txt)
 def VVa9Q9(self):
  cmd = FFKs6c(VVlevY, "")
  if cmd : FFb6xn(self, cmd, checkNetAccess=True)
  else : FFVWVs(self)
 def VVXr3t(self):
  pkg = FFqtwu()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFJjNb(self, txt)
 def VVBaOU(self, mode, grep, VVShs0=None, title=""):
  if   mode == 0: cmd = FFKs6c(VVVX1J    , grep)
  elif mode == 1: cmd = FFKs6c(VVWSiA , grep)
  elif mode == 2: cmd = FFKs6c(VVWSiA , grep)
  if not cmd:
   FFVWVs(self)
   return
  VVgBMX = FFUtqa(cmd)
  if not VVgBMX:
   if VVShs0: VVShs0.VVGqtm()
   FFEW3v(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVXy7C  = []
  for item in VVgBMX:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVXy7C.append((name, package, version))
  if mode > 0:
   extensions = FFUtqa("ls %s -l | grep '^d' | awk '{print $9}'" % VVCrBY)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVXy7C:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VVXy7C.append((name, VVCrBY + item, "-"))
   systemPlugins = FFUtqa("ls %s -l | grep '^d' | awk '{print $9}'" % VVO2Lq)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVXy7C:
      if item.lower() == row[0].lower():
       break
     else:
      VVXy7C.append((item, VVO2Lq + item, "-"))
  if not VVXy7C:
   FFEW3v(self, "No packages found!")
   return
  if VVShs0:
   VVXy7C.sort(key=lambda x: x[0].lower())
   VVShs0.VVrhOZ(VVXy7C, title)
  else:
   widths = (20, 50, 30)
   VVUhO3 = None
   VVeqJy = None
   if mode == 0:
    VVFZEv = ("Install" , self.VVhWj0   , [])
    VVUhO3 = ("Download" , self.VVuv7R   , [])
    VVeqJy = ("Filter"  , self.VV1VF3 , [])
   elif mode == 1:
    VVFZEv = ("Uninstall", self.VVj0z9, [])
   elif mode == 2:
    VVFZEv = ("Uninstall", self.VVj0z9, [])
    widths= (18, 57, 25)
   VVXy7C = sorted(VVXy7C, key=lambda x: x[0].lower())
   VV6mer = ("Package Info.", self.VVGyhp, [])
   header   = ("Name" ,"Package" , "Version" )
   FFZUAl(self, None, header=header, VVXy7C=VVXy7C, VV08hy=widths, VVH2Qb=24, VVFZEv=VVFZEv, VVUhO3=VVUhO3, VV6mer=VV6mer, VVeqJy=VVeqJy, VVeTRB=self.lastSelectedRow
     , VVrgKF="#22110011", VVr4tL="#22191111", VVnGDQ="#22191111", VVli9s="#00003030", VV9S0H="#00333333")
 def VVGyhp(self, VVShs0, title, txt, colList):
  package = colList[1]
  self.VVTQa0(package)
 def VV1VF3(self, VVShs0, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVXWOy = []
  VVXWOy.append(("All Packages", "all"))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVXWOy.append(VVGV45)
  for word in words:
   VVXWOy.append((word, word))
  FFue1q(self, boundFunction(self.VVlhKX, VVShs0), VVXWOy=VVXWOy, title="Select Filter")
 def VVlhKX(self, VVShs0, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFBV5V(VVShs0, boundFunction(self.VVBaOU, 0, grep, VVShs0, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVj0z9(self, VVShs0, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVCrBY, VVO2Lq)):
   FFUzhN(self, boundFunction(self.VVZdmE, VVShs0, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVXWOy = []
   VVXWOy.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVXWOy.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVXWOy.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFue1q(self, boundFunction(self.VVO4qa, VVShs0, package), VVXWOy=VVXWOy)
 def VVZdmE(self, VVShs0, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VV1uYF)
  FFb6xn(self, cmd, VVngoh=boundFunction(self.VVjiDF, VVShs0))
 def VVO4qa(self, VVShs0, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVgUUu
   elif item == "remove_ForceRemove"  : cmdOpt = VVkVAT
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVn1In
   FFUzhN(self, boundFunction(self.VV9yZU, VVShs0, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VV9yZU(self, VVShs0, package, cmdOpt):
  self.lastSelectedRow = VVShs0.VVYWtJ()
  cmd = FF2NxH(cmdOpt, package)
  if cmd : FFb6xn(self, cmd, VVngoh=boundFunction(self.VVjiDF, VVShs0))
  else : FFVWVs(self)
 def VVjiDF(self, VVShs0):
  VVShs0.cancel()
  FFigte()
 def VVhWj0(self, VVShs0, title, txt, colList):
  package  = colList[1]
  VVXWOy = []
  VVXWOy.append(("Install Package"         , "install_CheckVersion" ))
  VVXWOy.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVXWOy.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVXWOy.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFue1q(self, boundFunction(self.VVY7ZL, package), VVXWOy=VVXWOy)
 def VVY7ZL(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVQ6yh
   elif item == "install_ForceReinstall" : cmdOpt = VVXTqa
   elif item == "install_ForceDowngrade" : cmdOpt = VVF0Dt
   elif item == "install_IgnoreDepends" : cmdOpt = VVYEWw
   FFUzhN(self, boundFunction(self.VVIbob, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVIbob(self, package, cmdOpt):
  cmd = FF2NxH(cmdOpt, package)
  if cmd : FFb6xn(self, cmd, VVngoh=FFigte, checkNetAccess=True, enableSaveRes=True)
  else : FFVWVs(self)
 def VVuv7R(self, VVShs0, title, txt, colList):
  package  = colList[1]
  FFUzhN(self, boundFunction(self.VVOMqU, package), "Download Package ?\n\n%s" % package)
 def VVOMqU(self, package):
  if FF2qeK():
   cmd = FF2NxH(VVHKMB, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FF3Nyd(success, VVmHHA))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FF3Nyd(fail, VV7KZt))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFb6xn(self, cmd, VVFswX=[VV7KZt, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFVWVs(self)
  else:
   FFEW3v(self, "No internet connection !")
 def VVTQa0(self, package):
  infoCmd  = FF2NxH(VVPMTK, package)
  filesCmd = FF2NxH(VVVFn3, package)
  listInstCmd = FFKs6c(VVWSiA, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFuLlr(VVFlyn)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FF3Nyd(notInst, VVdNwi))
   cmd += "else "
   cmd +=   FFsGXc("System Info", VVFlyn)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFsGXc("Related Files", VVFlyn)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFAxIC(self, cmd)
  else:
   FFVWVs(self)
class CCfCKg(Screen):
 VVHdEp  = 0
 VVWSnu = 1
 VVaytQ  = 2
 VVPAIy  = 3
 VVBj8v = 4
 VVYPJZ = 5
 VVMHag = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFQUXb(VV2YUz, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VV6b4B = None
  self.lastfilterUsed  = None
  VVXWOy = self.VVMi5i()
  FFZrGE(self, VVXWOy=VVXWOy, title="Services/Channels")
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self["myMenu"].setList(self.VVMi5i())
  FFNsDm(self["myMenu"])
  FF8cqd(self)
 def VVMi5i(self):
  VVXWOy = []
  VVXWOy.append(("Current Service (Signal Monitor)"   , "currentServiceSignal"    ))
  VVXWOy.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Services (Reference)"      , "lameDB_allChannels_with_refCode"  ))
  VVXWOy.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVXWOy.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVXWOy.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVXWOy.append(("Services with PIcons for the System"  , "VV1mlG"     ))
  VVXWOy.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVXWOy.append(VVGV45)
  lamedbFile, disabledFile = CCfCKg.VVqLz6()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVXWOy.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVXWOy.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVXWOy.append(("Reset Parental Control Settings"   , "VVGCr5"    ))
  VVXWOy.append(("Delete Channels with no names"   , "VVgxmD"    ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Reload Channels and Bouquets"    , "VVw2U9"      ))
  return VVXWOy
 def VVOF6C(self):
  global VVaLC9
  VVaLC9 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFD0vK(self)
   elif item == "currentServiceInfo"     : self.session.open(CCnwAc)
   elif item == "TranspondersStats"     : FFBV5V(self, self.VVnj7q     )
   elif item == "lameDB_allChannels_with_refCode"  : FFBV5V(self, self.VVYHyH )
   elif item == "lameDB_allChannels_with_tranaponder" : FFBV5V(self, self.VVkniY)
   elif item == "lameDB_allChannels_with_details"  : FFBV5V(self, self.VVYxk9 )
   elif item == "parentalControlChannels"    : FFBV5V(self, self.VVBEjS   )
   elif item == "showHiddenChannels"     : FFBV5V(self, self.VVIFwZ     )
   elif item == "VV1mlG"     : FFBV5V(self, self.VVrxdP     )
   elif item == "servicesWithMissingPIcons"   : FFBV5V(self, self.VVKzf8   )
   elif item == "enableHiddenChannels"     : self.VVOey0(True)
   elif item == "disableHiddenChannels"    : self.VVOey0(False)
   elif item == "VVGCr5"    : FFUzhN(self, self.VVGCr5, "Reset and Restart ?" )
   elif item == "VVgxmD"    : FFBV5V(self, self.VVgxmD)
   elif item == "VVw2U9"      : FFBV5V(self, boundFunction(CCfCKg.VVw2U9, self))
   else            : self.close()
 @staticmethod
 def VVw2U9(SELF):
  FF1Rf4()
  FFJjNb(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVYHyH(self):
  self.VV6b4B = None
  self.lastfilterUsed  = None
  self.filterObj   = CCpZgp(self)
  VVgBMX = CCfCKg.VVdgTw(self, self.VVHdEp)
  if VVgBMX:
   VVgBMX.sort(key=lambda x: x[0].lower())
   VVcgcO  = ("Zap"   , self.VVaetC     , [])
   VVUv68 = (""    , self.VVvLAZ   , [])
   VV6mer = ("Options"  , self.VVtbr7 , [])
   VVUhO3 = ("Current Service", self.VVuj3y , [])
   VVeqJy = ("Filter"   , self.VVPO5z  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVqjzl  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFZUAl(self, None, header=header, VVXy7C=VVgBMX, VVqjzl=VVqjzl, VV08hy=widths, VVH2Qb=22, VVcgcO=VVcgcO, VVUv68=VVUv68, VVUhO3=VVUhO3, VV6mer=VV6mer, VVeqJy=VVeqJy)
 def VVkniY(self):
  self.VV6b4B = None
  self.lastfilterUsed  = None
  self.filterObj   = CCpZgp(self)
  VVgBMX = CCfCKg.VVdgTw(self, self.VVWSnu)
  if VVgBMX:
   VVgBMX.sort(key=lambda x: x[0].lower())
   VVcgcO  = ("Zap"   , self.VVaetC      , [])
   VVUv68 = (""    , self.VVvLAZ    , [])
   VVUhO3 = ("Current Service", self.VVuj3y  , [])
   VV6mer = ("Options"  , self.VVuHjw , [])
   VVeqJy = ("Filter"   , self.VVy8m6  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVqjzl  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFZUAl(self, None, header=header, VVXy7C=VVgBMX, VVqjzl=VVqjzl, VV08hy=widths, VVH2Qb=22, VVcgcO=VVcgcO, VVUv68=VVUv68, VVUhO3=VVUhO3, VV6mer=VV6mer, VVeqJy=VVeqJy)
 def VVtbr7(self, VVShs0, title, txt, colList):
  servName = colList[0]
  refCode  = colList[3]
  pcState  = colList[4]
  hidState = colList[5]
  mSel  = CCsg5m(self, VVShs0, 3)
  mSel.VV4Wtv(servName, refCode, pcState, hidState)
 def VVuHjw(self, VVShs0, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CCsg5m(self, VVShs0, 3)
  mSel.VVVkt5(servName, refCode)
 def VV5oSw(self, VVShs0, refCode, isAddToBlackList):
  self.VV6b4B = None
  self.lastfilterUsed  = None
  VVShs0.VVKDDX("Changing state ...")
  path = "/etc/enigma2/blacklist"
  if not fileExists(path):
   os.system("echo '' > %s" % path)
  if fileExists(path):
   if not refCode.endswith(":"):
    refCode += ":"
   if isAddToBlackList :
    os.system("sed -i '/%s/d' %s" % (refCode, path))
    os.system("echo '%s' >> %s" % (refCode, path))
   else:
    os.system("sed -i '/%s/d' %s" % (refCode, path))
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   if refCode.endswith(":"):
    refCode = refCode[:-1]
   FFBV5V(self, boundFunction(self.VVXRUD, VVShs0, refCode))
  else:
   FFV5mI(self, path)
 def VVw7PP(self, VVShs0, refCode, isHide):
  self.VV6b4B = None
  self.lastfilterUsed  = None
  VVShs0.VVKDDX("Changing state ...")
  if FFiMfm(refCode):
   ret = FFdZr6(refCode, isHide)
   if ret : FFBV5V(self, boundFunction(self.VVXRUD, VVShs0, refCode))
   else : FFEW3v(self, "Cannot Hide/Unhide this channel.")
  else:
   FFEW3v(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)")
 def VVXRUD(self, VVShs0, refCode):
  VVgBMX = CCfCKg.VVdgTw(self, self.VVHdEp, VVxXpq=[3, [refCode], False])
  done = False
  if VVgBMX:
   data = VVgBMX[0]
   if data[3] == refCode:
    done = VVShs0.VVoPzw(data)
  if not done:
   self.VV8Bok(VVShs0, VVShs0.VVD0uy(), self.VVHdEp)
  VVShs0.VVGqtm()
 def VVPO5z(self, VVShs0, title, txt, colList):
  self.filterObj.VVUUrd(1, VVShs0, 2, boundFunction(self.VV4Yc0, VVShs0))
 def VV4Yc0(self, VVShs0, item):
  self.VVLgck(VVShs0, item, 2, self.VVHdEp)
 def VVy8m6(self, VVShs0, title, txt, colList):
  self.filterObj.VVUUrd(2, VVShs0, 4, boundFunction(self.VVgGAc, VVShs0))
 def VVgGAc(self, VVShs0, item):
  self.VVLgck(VVShs0, item, 4, self.VVWSnu)
 def VVJenF(self, VVShs0, title, txt, colList):
  self.filterObj.VVUUrd(0, VVShs0, 4, boundFunction(self.VV32cd, VVShs0))
 def VV32cd(self, VVShs0, item):
  self.VVLgck(VVShs0, item, 4, self.VVaytQ)
 def VVLgck(self, VVShs0, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVShs0.VVB4LN(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VV6b4B = None
  else:
   words, asPrefix = CCpZgp.VV3cHn(words)
   self.VV6b4B = [col, words, asPrefix]
  if not words:
   FFtXOm(VVShs0, "Incorrect filter", 2000)
  else:
   VVShs0.VVKDDX("Reading Services ...")
   FFBV5V(self, boundFunction(self.VV8Bok, VVShs0, title, mode))
 def VV8Bok(self, VVShs0, title, mode):
  VVgBMX = CCfCKg.VVdgTw(self, mode, VVxXpq=self.VV6b4B, VVAvww=False)
  if VVgBMX:
   VVgBMX.sort(key=lambda x: x[0].lower())
   VVShs0.VVrhOZ(VVgBMX, title)
  else:
   VVShs0.VVGqtm()
   FFtXOm(VVShs0, "Not found!", 1500)
 def VVnSrU(self, VVXy7C, VVcgcO=None, VVUv68=None, VVFZEv=None, VVUhO3=None, VV6mer=None, VVeqJy=None):
  VVUhO3 = ("Current Service", self.VVuj3y, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVqjzl = (LEFT  , LEFT  , CENTER, LEFT    )
  FFZUAl(self, None, header=header, VVXy7C=VVXy7C, VVqjzl=VVqjzl, VV08hy=widths, VVH2Qb=24, VVcgcO=VVcgcO, VVUv68=VVUv68, VVFZEv=VVFZEv, VVUhO3=VVUhO3, VV6mer=VV6mer, VVeqJy=VVeqJy)
 def VVuj3y(self, VVShs0, title, txt, colList):
  self.VVlEoh(VVShs0)
 def VV11pB(self, VVShs0, title, txt, colList):
  self.VVlEoh(VVShs0, True)
 def VVlEoh(self, VVShs0, isFromDetails=False):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF8KLs(self)
  if refCode:
   if isFromDetails:
    chName  = info.getName()
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVShs0.VV1tKW(colDict, showErr=True)
   else:
    VVShs0.VVevA6(3, refCode, True)
   return
  FFEW3v(self, "Colud not read current Reference Code !")
 def VVYxk9(self):
  self.VV6b4B = None
  self.lastfilterUsed  = None
  self.filterObj   = CCpZgp(self)
  VVgBMX = CCfCKg.VVdgTw(self, self.VVaytQ)
  if VVgBMX:
   VVgBMX.sort(key=lambda x: x[0].lower())
   VVUv68 = (""    , self.VVbXW0 , []      )
   VVUhO3 = ("Current Service", self.VV11pB  , []      )
   VVeqJy = ("Filter"   , self.VVJenF   , [], "Loading Filters ..." )
   VVcgcO  = ("Zap"   , self.VVDMlB      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVqjzl  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFZUAl(self, None, header=header, VVXy7C=VVgBMX, VVqjzl=VVqjzl, VV08hy=widths, VVH2Qb=24, VVcgcO=VVcgcO, VVUv68=VVUv68, VVUhO3=VVUhO3, VVeqJy=VVeqJy)
 def VVbXW0(self, VVShs0, title, txt, colList):
  refCode  = self.VVZiV6(colList)
  chName  = colList[0]
  png, path = CCgbc1.VVZUEz(refCode, chName)
  txt   += "Reference\t: %s" % refCode
  CCnwAc.VVnSa9(self, refCode, txt, title, path)
 def VVDMlB(self, VVShs0, title, txt, colList):
  refCode = self.VVZiV6(colList)
  FFhRft(self, refCode)
 def VVaetC(self, VVShs0, title, txt, colList):
  FFhRft(self, colList[3])
 def VVZiV6(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVdgTw(SELF, mode, VVxXpq=None, VVAvww=True, VVnWJU=True):
  lamedbFile, disabledFile = CCfCKg.VVqLz6()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVxXpq:
    filterCol = VVxXpq[0]
    filterWords = VVxXpq[1]
    asPrefix = VVxXpq[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCfCKg.VVHdEp:
    blackList = None
    path = "/etc/enigma2/blacklist"
    if fileExists(path):
     blackList = FFUM2c(path)
     if blackList:
      blackList = set(blackList)
   elif mode == CCfCKg.VVWSnu:
    tp = CCLFki()
   VVT1Il, VVyD7q = FF0mQl()
   tagFound  = False
   if mode in (CCfCKg.VVYPJZ, CCfCKg.VVMHag):
    VVgBMX = {}
   else:
    VVgBMX = []
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     if not FFulRq(SELF):
      return None
     line = line.strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
        sTypeInt = int(STYPE)
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFwzNy(val)
       servTypeHex = (hex(sTypeInt))[2:].upper()
       if mode == CCfCKg.VVaytQ:
        if sTypeInt in VVT1Il:
         STYPE = VVyD7q[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVgBMX.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVgBMX.append(tRow)
        else:
         VVgBMX.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCfCKg.VVYPJZ:
         VVgBMX[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCfCKg.VVMHag:
         VVgBMX[chName] = refCode
        elif mode == CCfCKg.VVHdEp:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVgBMX.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVgBMX.append(tRow)
         else:
          VVgBMX.append(tRow)
        elif mode == CCfCKg.VVWSnu:
         if sTypeInt in VVT1Il:
          STYPE = VVyD7q[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVDV7b(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVgBMX.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVgBMX.append(tRow)
         else:
          VVgBMX.append(tRow)
        elif mode == CCfCKg.VVPAIy:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VVgBMX.append((chName, chProv, sat, refCode))
        elif mode == CCfCKg.VVBj8v:
         VVgBMX.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VVgBMX and VVAvww:
    FFEW3v(SELF, "No services found!")
   return VVgBMX
  else:
   if VVnWJU:
    FFV5mI(SELF, lamedbFile)
   return None
 def VVBEjS(self):
  path = "/etc/enigma2/blacklist"
  if fileExists(path):
   lines = FFUM2c(path)
   if lines:
    newRows  = []
    VVgBMX = CCfCKg.VVdgTw(self, self.VVBj8v)
    if VVgBMX:
     lines = set(lines)
     for item in VVgBMX:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVgBMX = newRows
      VVgBMX.sort(key=lambda x: x[0].lower())
      VVUv68 = ("", self.VVvLAZ, [])
      VVcgcO = ("Zap", self.VVaetC, [])
      self.VVnSrU(VVXy7C=VVgBMX, VVcgcO=VVcgcO, VVUv68=VVUv68)
     else:
      FFKjl2(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVgBMX)))
   else:
    FFJjNb(self, "No hidden services.", FFSb2Q())
  else:
   FFV5mI(self, path)
 def VVIFwZ(self):
  VVgBMX = CCfCKg.VVdgTw(self, self.VVPAIy)
  if VVgBMX:
   if VVgBMX:
    VVgBMX.sort(key=lambda x: x[0].lower())
    VVUv68 = ("" , self.VVvLAZ, [])
    VVcgcO  = ("Zap", self.VVaetC, [])
    self.VVnSrU(VVXy7C=VVgBMX, VVcgcO=VVcgcO, VVUv68=VVUv68)
   else:
    FFKjl2(self, "Lines\t: %d\nFound\t: %d\nLameDB\t: %d" % (len(lines), txt.count("\n"), len(VVgBMX)))
 def VVnj7q(self):
  totT, totC, totA, totS, totS2, satList = self.VVrqIM()
  txt = FFW8xd("Total Transponders:\n\n", VVhJi6)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFW8xd("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVhJi6)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FF0uha(item), satList.count(item))
  FFKjl2(self, txt)
 def VVrqIM(self):
  lamedbFile, disabledFile = CCfCKg.VVqLz6()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     if not FFulRq(self):
      return 0, 0, 0, 0, 0, None
     line = line.strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFV5mI(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VVrxdP(self):
  self.VV1mlG(True)
 def VVKzf8(self):
  self.VV1mlG(False)
 def VV1mlG(self, isWithPIcons):
  piconsPath = CCgbc1.VVrn8y()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCgbc1.VVgeVx(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVgBMX = CCfCKg.VVdgTw(self, self.VVBj8v)
    if VVgBMX:
     channels = []
     for (chName, chProv, sat, refCode) in VVgBMX:
      if not FFulRq(self):
       return
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFsghU(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVgBMX)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VV269Y(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VV269Y("PIcons Path"  , piconsPath)
     txt += VV269Y("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VV269Y("Total services" , totalServices)
     txt += VV269Y("With PIcons"  , totalWithPIcons)
     txt += VV269Y("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFKjl2(self, txt)
     else:
      VVUv68     = (""      , self.VVvLAZ , [])
      if isWithPIcons : VVeqJy = ("Export Current PIcon", self.VVdn9v  , [])
      else   : VVeqJy = None
      VV6mer     = ("Statistics", FFKjl2, [txt])
      VVcgcO      = ("Zap", self.VVaetC, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVnSrU(VVXy7C=channels, VVcgcO=VVcgcO, VVUv68=VVUv68, VV6mer=VV6mer, VVeqJy=VVeqJy)
   else:
    FFEW3v(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFEW3v(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVvLAZ(self, VVShs0, title, txt, colList):
  png, path = CCgbc1.VVZUEz(colList[3], colList[0])
  CCnwAc.VVnSa9(self, colList[3], txt, title, path)
 def VVdn9v(self, VVShs0, title, txt, colList):
  png, path = CCgbc1.VVZUEz(colList[3], colList[0])
  if path:
   CCgbc1.VVlJY9(self, png, path)
 @staticmethod
 def VVqLz6():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVAddD():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVOey0(self, isEnable):
  lamedbFile, disabledFile = CCfCKg.VVqLz6()
  if isEnable and not fileExists(disabledFile):
   FFJjNb(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FFEW3v(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFUzhN(self, boundFunction(self.VVpeLc, isEnable), "%s Hidden Channels ?" % word)
 def VVpeLc(self, isEnable):
  lamedbFile , disabledFile = CCfCKg.VVqLz6()
  lamedb5File, diabled5File = CCfCKg.VVAddD()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FF1Rf4()
  if res == 0 : FFJjNb(self, "Hidden List %s" % word)
  else  : FFEW3v(self, "Error while restoring:\n\n%s" % fileName)
 def VVGCr5(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFxkJ6(self, cmd)
 def VVgxmD(self):
  lamedbFile, disabledFile = CCfCKg.VVqLz6()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFLcOy("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFUM2c(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFLcOy("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FF1Rf4()
   FFKjl2(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFV5mI(self, lamedbFile)
class CCnwAc(Screen):
 VVFtDY = 0
 VVgiUS   = 1
 VV2REk   = 2
 EPG_MODE_SERVER_IPTV  = 3
 VVrbLq    = 4
 def __init__(self, session, isFromSignal=False, extraInfoData=[]):
  self.skin, self.skinParam = FFQUXb(VVV8lu, 1400, 800, 50, 30, 20, "#110B2830", "#050B242c", 30, addFramedPic=True)
  self.extraInfoData = extraInfoData
  if self.extraInfoData:
   self.infoMode = self.extraInfoData[0]
   if self.infoMode == self.VVrbLq: title = self.extraInfoData[2]
   else         : title = "Channel Information"
  else:
   self.infoMode = self.VVFtDY
   title = "Current Service"
   if isFromSignal:
    title += FFW8xd("   (No Signal Monitor for IPTV)", VVYh3b)
  self.Sep = FFW8xd("%s\n", VVYh3b) % VVklh1
  self.session   = session
  FFZrGE(self, title=title, addScrollLabel=True)
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  self["myLabel"].VV0fFU(enableSave=True)
  if   self.infoMode == self.VVFtDY : fnc = self.VV7bsD_fromCurrentChannel
  elif self.infoMode == self.VVgiUS  : fnc = self.VV7bsD_fromFindTable
  elif self.infoMode == self.VV2REk  : fnc = self.VV7bsD_fromLocalIptvTable
  elif self.infoMode == self.EPG_MODE_SERVER_IPTV  : fnc = self.VV7bsD_fromServerIptvTable
  elif self.infoMode == self.VVrbLq   : fnc = self.VV7bsD_fromOthers
  FFBV5V(self, fnc, title="Reading info. ...")
 def VVLGLe(self, err):
  self["myLabel"].setText(err)
  FFwL0h(self["myTitle"], "#22200000")
  FFwL0h(self["myBody"], "#22200000")
  self["myLabel"].FFwL0hColor("#22200000")
  self["myLabel"].VV0W5a()
 def VVlShh(self, txt, isIptv, chName, refCode, decodedUrl, info=None):
  txt += self.VVHl7Q(isIptv, chName, refCode, decodedUrl, info)
  self.VVJeAO(txt)
 def VV7bsD_fromOthers(self):
  mode, refCode, txt, title, VVaRdA = self.extraInfoData
  picShown = self.VVufAa(VVaRdA)
  epg = self.VVkvWQ(refCode, None)
  if epg:
   txt += epg
  self.VVJeAO(txt)
 def VVJeAO(self, txt):
  self["myLabel"].setText(txt, VVTBXk=VVaGDj)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VV0W5a(minHeight=minH)
 def VV7bsD_fromFindTable(self):
  mode, chName, refCode, txt = self.extraInfoData
  txt += self.VVOyT5(refCode, refCode, chName)
  isIptv = FFF590(refCode)
  if isIptv:
   txt += self.VVWwny(refCode)
  else:
   tp = CCLFki()
   tpTxt, namespace = tp.VVdUTv(refCode)
   del tp
   if tpTxt:
    txt += self.Sep
    txt += tpTxt
  refCode, decodedUrl, origUrl, iptvRef = FFwwJ6(refCode)
  self.VVlShh(txt, isIptv, chName, refCode, decodedUrl)
 def VV7bsD_fromLocalIptvTable(self):
  mode, chName, refCode, decodedUrl, txt = self.extraInfoData
  txt += self.VVWwny(refCode + decodedUrl)
  txt += "\n"
  txt += self.VVOyT5(refCode, refCode, chName)
  self.VVlShh(txt, True, chName, refCode, decodedUrl)
 def VV7bsD_fromServerIptvTable(self):
  mode, chName, chUrl, picUrl, refCode, txt = self.extraInfoData
  decodedUrl = FFzmJo(chUrl.replace(refCode, "").replace(chName, "").strip(":").strip())
  self.VVlShh(txt, True, chName, refCode, decodedUrl)
 def VV7bsD_fromCurrentChannel(self):
  info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
  try:
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF8KLs(self)
  except:
   return
  if not info:
   self.VVLGLe("No data from system !")
   return
  chName = info.getName()
  txt = ""
  txt += "Service Name\t: %s\n" % FFW8xd(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VV269Y(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFW8xd(state, VVdNwi)
   txt += "State\t: %s\n" % state
  w = FF3WDL(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FF3WDL(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = FF3WDL(info      , iServiceInformation.sAspect)
  if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : aspect = "4:3"
  else           : aspect = "16:9"
  txt += "Video Format\t: %s\n" % aspect
  txt += self.VV269Y(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VV269Y(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VV269Y(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  isIptv = len(iptvRef) > 0
  if iptvRef:
   txt += "Service Type\t: %s\n" % FFW8xd("IPTV", VVhJi6)
   txt += self.VVWwny(iptvRef)
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not refCode:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    path = serv.getPath()
    if path:
     txt += "Path\t: %s\n" % path
  txt += "\n"
  txt += self.VVOyT5(refCode, iptvRef, chName)
  if not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCLFki()
    tpTxt, namespace = tp.VVdUTv(refCode)
    del tp
    if tpTxt:
     txt += FFW8xd("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFW8xd("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VV269Y(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VV269Y(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VV269Y(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VV269Y(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VV269Y(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VV269Y(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VV269Y(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VV269Y(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VV269Y(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  self.VVlShh(txt, isIptv, chName, refCode, decodedUrl, info)
 def VV269Y(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FF3WDL(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VV5AY0(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VV5AY0(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVHl7Q(self, isIptv, chName, refCode, decodedUrl, info):
  txt = ""
  sep = "%s\n" % VVklh1
  png, path = CCgbc1.VVZUEz(refCode, chName)
  picShown = False
  if png:
   if VVqAV4:
    txt += "\n"
    txt += sep
    txt += "PIcon:\n"
    txt += "%s\n" % path
   picShown = self.VVufAa(path)
  txt = ""
  if isIptv:
   epg, err = self.VVN5Cy(decodedUrl, refCode, not picShown)
   txt += FFW8xd("\n%sEPG:\n%s" % (sep, sep), COLOR_CONS_BRIGHT_YELLOW)
   if epg : txt += epg
   elif err: txt += FFW8xd(err, VVYh3b)
  else:
   epg = self.VVkvWQ(refCode, info)
   if epg:
    txt += epg
  return txt
 def VVkvWQ(self, refCode, info):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVT5xO(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVT5xO(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVT5xO(event, 0)
     except:
      pass
  return epg
 def VVT5xO(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName()    or ""
   evTime = event.getBeginTime()    or ""
   evDur = event.getDuration()    or ""
   evShort = event.getShortDescription()  or ""
   evDesc = event.getExtendedDescription() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    if evName          : txt += "Name\t: %s\n"   % FFW8xd(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evTime           : txt += "Start Time\t: %s\n" % FFnWMY(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFnWMY(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FF55bZ(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FF55bZ(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FF55bZ(evTime - now)
    if evShort and evShort.strip()     : txt += "\nSummary:\n%s\n"  % FFW8xd(evShort, VVqb5h)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFW8xd(evDesc , VVqb5h)
    if txt:
     txt = FFW8xd("\n%s\n%s Event:\n%s\n" % (VVklh1, ("Current", "Next")[evNum], VVklh1), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVN5Cy(self, decodedUrl, refCode, showPIcon):
  if not FF2qeK():
   return "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCzPop.VVspd4(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "No EPG (not a subscription ULR) !"
  if   uType == "live" : qUrl = "%s/player_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uHost, uUser, uPass, uId)
  elif uType == "movie" : qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
  elif uType == "series" : return "", "No EPG for Series Channels !"
  txt, err = CCzPop.VVFmAW(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "Could not parse server data !"
  epg  = ""
  if tDict:
   if uType == "live":
    epg, lang = self.VVIrlc(tDict)
    if epg:
     epg = "Language\t: %s\n\n%s" % (lang, epg)
   elif uType == "movie":
    epg, picUrl = self.VV0QPn(tDict)
    if showPIcon and picUrl:
     path, err = FF0NYM(picUrl, "ajpanel_tmp.png", timeout=2)
     picShown = self.VVufAa(path)
     self.VVbG1o(path, refCode)
  if epg : return epg, ""
  else : return "" ,  "No EPG from server !"
 def VVIrlc(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCzPop.VVETLr(item, "title"    , isBase64=True )
     lang    = CCzPop.VVETLr(item, "lang"        ).upper()
     description   = CCzPop.VVETLr(item, "description"  , isBase64=True )
     start_timestamp  = CCzPop.VVETLr(item, "start_timestamp" , isDate=True )
     stop_timestamp  = CCzPop.VVETLr(item, "stop_timestamp"  , isDate=True )
     stop_timestamp_unix = CCzPop.VVETLr(item, "stop_timestamp"      )
     now_playing   = CCzPop.VVETLr(item, "now_playing"      )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVI2d4, ""
      else     : color, txt = VVdNwi , "    (CURRENT EVENT)"
      epg += FFW8xd("_" * 32 + "\n", VVYh3b)
      epg += FFW8xd("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      epg += "Description:\n%s\n" % FFW8xd(description, VVqb5h)
      evNum += 1
   except:
    pass
  return epg, lang
 def VV0QPn(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item =tDict["info"]
    movie_image   = CCzPop.VVETLr(item, "movie_image" )
    genre    = CCzPop.VVETLr(item, "genre"   ) or "-"
    plot    = CCzPop.VVETLr(item, "plot"   ) or "-"
    cast    = CCzPop.VVETLr(item, "cast"   ) or "-"
    rating    = CCzPop.VVETLr(item, "rating"   ) or "-"
    director   = CCzPop.VVETLr(item, "director"  ) or "-"
    releasedate   = CCzPop.VVETLr(item, "releasedate" ) or "-"
    duration   = CCzPop.VVETLr(item, "duration"  ) or "-"
    epg += "Genre\t: %s\n"  % genre
    epg += "Released\t: %s\n" % releasedate
    epg += "Duration\t: %s\n" % duration
    epg += "Director\t: %s\n" % director
    epg += "Rating\t: %s\n\n" % rating
    epg += "Cast:\n%s\n\n"  % FFW8xd(cast, VVqb5h)
    epg += "Plot:\n%s"   % FFW8xd(plot, VVqb5h)
   except:
    pass
  return epg, movie_image
 def VVbG1o(self, path, refCode):
  if path and fileExists(path) and os.system(FFLcOy("which ffmpeg")) == 0:
   pPath = CCgbc1.VVrn8y()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
    cmd += FFLcOy("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVWwny(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFwwJ6(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   txt += "\n"
   txt += FFW8xd("URL:", VVhJi6) + "\n%s\n" % decodedUrl
  else:
   txt = "\n"
   txt += FFW8xd("Reference:", VVhJi6) + "\n%s\n" % refCode
  return txt
 def VVufAa(self, path):
  if path and fileExists(path):
   err, w, h = self.VVi2fh(path)
   if not err:
    if h > w:
     self.VViIHQ(self["myPicF"], w, h, True)
     self.VViIHQ(self["myPic"] , w, h, False)
   allOK = FFoEjx(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VViIHQ(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVi2fh(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFHvE5(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVOyT5(self, refCode, iptvRef, chName):
  refCode = FF726c(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFteHI(VVlT2l + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFteHI(VVlT2l + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVXy7C = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVlT2l + item
   if fileExists(path):
    txt = FFteHI(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVXy7C.append(bName)
  txt = self.Sep
  if VVXy7C:
   if len(VVXy7C) == 1:
    txt += "%s\t: %s\n" % (FFW8xd("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VVXy7C[0])
   else:
    txt += FFW8xd("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VVXy7C):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 @staticmethod
 def VVBNh4(SELF, chName, refCode, url, txt):
  SELF.session.open(boundFunction(CCnwAc, extraInfoData=[CCnwAc.VV2REk, chName, refCode, url, txt]))
 @staticmethod
 def VVQhuL(SELF, chName, chUrl, picUrl, refCode, txt):
  SELF.session.open(boundFunction(CCnwAc, extraInfoData=[CCnwAc.EPG_MODE_SERVER_IPTV, chName, chUrl, picUrl, refCode, txt]))
 @staticmethod
 def VVwJQT(SELF, chName, refCode, txt):
  SELF.session.open(boundFunction(CCnwAc, extraInfoData=[CCnwAc.VVgiUS, chName, refCode, txt]))
 @staticmethod
 def VVnSa9(SELF, refCode, txt, title, VVaRdA):
  SELF.session.open(boundFunction(CCnwAc, extraInfoData=[CCnwAc.VVrbLq, refCode, txt, title, VVaRdA]))
class CCzPop(Screen):
 VVtUcj = 0
 VVORpf = 1
 VV4UVF = 2
 VVi9NL = 3
 VVhDb5  = 4
 VVAFIr  = 5
 VVUU8P  = 6
 VVh0G4  = 7
 VVfdwg   = 8
 VVJOzq  = 9
 VVMkLR  = 10
 VVU13N  = 11
 VVBIUx  = 12
 VV8hdh   = 13
 VVW06J   = 14
 VVRKRi   = 15
 VVN53k   = 16
 VVKFto   = 17
 VVvvP4    = 0
 VVnkpH   = 1
 VVUaXw   = 2
 VV67Ce   = 3
 VVcxju  = 4
 VVlm6j   = 5
 VVkgOr   = 6
 VVo93c  = 7
 VVbZ0A  = 8
 VVuwqM   = 9
 VVTIil = 10
 VVmNeB   = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFQUXb(VV2YUz, 1100, 1050, 50, 40, 30, "#0a00292B", "#0a00272B", 30)
  self.session  = session
  self.VVShs0 = None
  self.tableTitle  = "IPTV Channels List"
  self.VVvyPoData = {}
  VVXWOy= self.VVKkZ8()
  FFZrGE(self, VVXWOy=VVXWOy)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  FFNsDm(self["myMenu"])
  FF8cqd(self)
  FFBLuo(self)
 def VVKkZ8(self):
  files = self.VVyQGd()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"    , "VVvyPo_fromPlayList" ))
  tList.append(("IPTV Server Browser (from M3U File)"     , "VVvyPo_fromM3u"  ))
  qUrl = self.VVIoW0()
  if qUrl:
   tList.append(("IPTV Server Browser (from Current Channel)"  , "VVvyPo_fromCurrChan"  ))
  VVXWOy = []
  if files:
   if self.VVShs0:
    VVXWOy.append(("Add Current List to a New Bouquet"      , "VV6zFc"  ))
    VVXWOy.append(VVGV45)
    VVXWOy.append(("Change Current List References to Unique Codes"   , "VVyVY8"))
    VVXWOy.append(("Change Current List References to Identical Codes"  , "VVjtBB_rows" ))
    VVXWOy.append(VVGV45)
    VVXWOy.append(("Share Reference with Satellite/C/T Channel"    , "VVXfpQ" ))
   else:
    VVXWOy += tList
    VVXWOy.append(VVGV45)
    VVXWOy.append(("Local IPTV Channels (Live)"        , "iptvTable_live"   ))
    VVXWOy.append(("Local IPTV Channels (All)"        , "iptvTable_all"   ))
    VVXWOy.append(VVGV45)
    VVXWOy.append(("Count Available IPTV Channels"       , "VV8Pex"    ))
    VVXWOy.append(("Check Reference Codes Format"        , "VVZ4AB"   ))
    VVXWOy.append(("Check System Acceptable Reference Types"     , "VVvJPJ"   ))
    VVXWOy.append(VVGV45)
    VVXWOy.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVFuVq"  ))
    VVXWOy.append(("Change ALL References to Matching Sat/C/T Channels"  , "VVtiUX" ))
    VVXWOy.append(("Change ALL References to Unique Codes"     , "VVfmaa" ))
    VVXWOy.append(("Change ALL References to Identical Codes"     , "VVjtBB_all" ))
  if not self.VVShs0:
   if not files:
    VVXWOy += tList
   VVXWOy.append(VVGV45)
   VVXWOy.append(("Analyse m3u File"            , "VVx7ii"   ))
   VVXWOy.append(("Convert m3u File to Bouquet (from File Manager)"    , "VVYpMz" ))
   VVXWOy.append(("Convert m3u File to Bouquet (from m3u File List)"    , "VVxPnA" ))
   VVXWOy.append(('Convert m3u File to Bouquet (Download from "Play Lists")'  , "VVZlLJ" ))
   VVXWOy.append(VVGV45)
   VVXWOy.append(("Reload Channels and Bouquets"         , "VVw2U9"   ))
  return VVXWOy
 def VVzScv(self, item):
  if item is not None:
   if   item == "VV6zFc"   : FFiVZt(self, self.VV6zFc, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVyVY8" : FFUzhN(self, boundFunction(FFBV5V, self.VVShs0, self.VVyVY8 ), "Change Current List References to Unique Codes ?")
   elif item == "VVjtBB_rows" : FFUzhN(self, boundFunction(FFBV5V, self.VVShs0, self.VVjtBB   ), "Change Current List References to Identical Codes ?")
   elif item == "VVXfpQ" : FFBV5V(self.VVShs0, self.VVXfpQ, title="Searching ...")
   elif item == "VVvyPo_fromPlayList" : FFBV5V(self, boundFunction(self.VVUO6R, True), title="Searching ...")
   elif item == "VVvyPo_fromM3u"  : FFBV5V(self, boundFunction(self.VVQtLq, 0), title="Searching ...")
   elif item == "VVvyPo_fromCurrChan" : self.VVvyPo_fromCurrChan()
   elif item == "iptvTable_live"   : FFBV5V(self, boundFunction(self.VVC4Y1, self.VVh0G4 ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFBV5V(self, boundFunction(self.VVC4Y1, self.VVtUcj) , title="Loading Channels ...")
   elif item == "VV8Pex"    : FFBV5V(self, self.VV8Pex)
   elif item == "VVZ4AB"    : FFBV5V(self, self.VVZ4AB)
   elif item == "VVvJPJ"   : FFBV5V(self, self.VVvJPJ)
   elif item == "VVFuVq"  : self.VVFuVq()
   elif item == "VVtiUX"  : FFUzhN(self, boundFunction(FFBV5V, self, self.VVtiUX ), "Copy from existing Sat. Channel" )
   elif item == "VVfmaa" : FFUzhN(self, boundFunction(FFBV5V, self, self.VVfmaa ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVjtBB_all" : FFUzhN(self, boundFunction(FFBV5V, self, self.VVjtBB  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "VVx7ii"   : FFBV5V(self, boundFunction(self.VVQtLq, 1), title="Searching ...")
   elif item == "VVYpMz" : self.VVYpMz()
   elif item == "VVxPnA" : FFBV5V(self, boundFunction(self.VVQtLq, 2), title="Searching ...")
   elif item == "VVZlLJ" : FFBV5V(self, boundFunction(self.VVUO6R, False), title="Searching ...")
   elif item == "VVw2U9"   : FFBV5V(self, boundFunction(CCfCKg.VVw2U9, self))
 def VVOF6C(self):
  global VVaLC9
  VVaLC9 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVzScv(item)
 def VVC4Y1(self, mode):
  VVgBMX = self.VVkyfh(mode)
  if VVgBMX:
   VVUhO3 = ("Current Service", self.VVnJl7 , [])
   VV6mer = ("Options"  , self.VVSmlU   , [])
   VVeqJy = ("Filter"   , self.VVbiS1    , [])
   VVcgcO  = ("Zap"   , self.VVZoNA   , [])
   VVUv68 = (""    , self.VVFBPA    , [])
   VVVt4G = (""    , self.VVJXFx     , [])
   VVWZbv = (""    , self.VVm2E5    , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVqjzl  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFZUAl(self, None, header=header, VVXy7C=VVgBMX, VVqjzl=VVqjzl, VV08hy=widths, VVH2Qb=22
     , VVcgcO=VVcgcO, VVUhO3=VVUhO3, VV6mer=VV6mer, VVeqJy=VVeqJy, VVUv68=VVUv68, VVVt4G=VVVt4G
     , VVrgKF="#0a00292B", VVr4tL="#0a002126", VVnGDQ="#0a002126", VVli9s="#00000000", VVxpps=True, searchCol=1)
  else:
   if mode == self.VVh0G4: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFEW3v(self, err)
 def VVJXFx(self, VVShs0, title, txt, colList):
  self.VVShs0 = VVShs0
 def VVm2E5(self, VVShs0):
  self.VVShs0 = None
 def VVSmlU(self, VVShs0, title, txt, colList):
  VVXWOy= self.VVKkZ8()
  FFue1q(self, self.VVzScv, title="IPTV Tools", VVXWOy=VVXWOy)
 def VVbiS1(self, VVShs0, title, txt, colList):
  VVXWOy = []
  VVXWOy.append(("All"         , "all"   ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Prefix of Selected Channel"   , "sameName" ))
  VVXWOy.append(("Suggest Words from Selected Channel" , "partName" ))
  VVXWOy.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Live TV"        , "live"  ))
  VVXWOy.append(("VOD"         , "vod"   ))
  VVXWOy.append(("Series"        , "series"  ))
  VVXWOy.append(("Uncategorised"      , "uncat"  ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Video"        , "video"  ))
  VVXWOy.append(("Audio"        , "audio"  ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("MKV"         , "MKV"   ))
  VVXWOy.append(("MP4"         , "MP4"   ))
  VVXWOy.append(("MP3"         , "MP3"   ))
  VVXWOy.append(("AVI"         , "AVI"   ))
  VVXWOy.append(("FLV"         , "FLV"   ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVmct2()
  if bNames:
   bNames.sort()
   VVXWOy.append(VVGV45)
   for item in bNames:
    VVXWOy.append((item, "__b__" + item))
  filterObj = CCpZgp(self)
  filterObj.VVht5m(VVXWOy, VVXWOy, boundFunction(self.VVYVAM, VVShs0))
 def VVYVAM(self, VVShs0, item=None):
  prefix = VVShs0.VVB4LN(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVtUcj, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVORpf , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VV4UVF , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVi9NL , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVh0G4  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVfdwg   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVJOzq  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVMkLR  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVU13N  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVBIUx  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VV8hdh   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVW06J   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVRKRi   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVN53k   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVKFto   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVUU8P  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVhDb5  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVAFIr  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VV4UVF:
   VVXWOy = []
   chName = VVShs0.VVB4LN(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVXWOy.append((item, item))
    if not VVXWOy and chName:
     VVXWOy.append((chName, chName))
    FFue1q(self, boundFunction(self.VVyJEy_partOfName, title), title="Words from Current Selection", VVXWOy=VVXWOy)
   else:
    VVShs0.VVczAi("Invalid Channel Name")
  else:
   words, asPrefix = CCpZgp.VV3cHn(words)
   if not words and mode in (self.VVhDb5, self.VVAFIr):
    FFtXOm(self.VVShs0, "Incorrect filter", 2000)
   else:
    FFBV5V(self.VVShs0, boundFunction(self.VVDvjd, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVyJEy_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFBV5V(self.VVShs0, boundFunction(self.VVDvjd, self.VV4UVF, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 def VVvTE8(self, txt):
  return "#f#11ffff00#" + txt
 def VVDvjd(self, mode, words, asPrefix, title):
  VVgBMX = self.VVkyfh(mode=mode, words=words, asPrefix=asPrefix)
  if VVgBMX : self.VVShs0.VVrhOZ(VVgBMX, title)
  else  : self.VVShs0.VVczAi("Not found")
 def VVkyfh(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVgBMX = []
  files  = self.VVyQGd()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFteHI(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVdFti = span.group(1)
    else : VVdFti = ""
    VVdFti_lCase = VVdFti.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVxhn9(chName): chNameMod = self.VVvTE8(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVdFti, chType, refCode, url)
     ok = False
     tUrl = FFzmJo(url).lower()
     if mode == self.VVtUcj       : ok = True
     elif mode == self.VVUU8P       : ok = True
     elif mode == self.VVU13N:
      if CCzPop.VVspd4(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVBIUx:
      if CCzPop.VVspd4(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVh0G4:
      if CCzPop.VVspd4(tUrl, compareType="live")  : ok = True
     elif mode == self.VVfdwg:
      if CCzPop.VVspd4(tUrl, compareType="movie") : ok = True
     elif mode == self.VVJOzq:
      if CCzPop.VVspd4(tUrl, compareType="series") : ok = True
     elif mode == self.VVMkLR:
      if CCzPop.VVspd4(tUrl, compareType="")   : ok = True
     elif mode == self.VV8hdh:
      if CCzPop.VVspd4(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVW06J:
      if CCzPop.VVspd4(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVRKRi:
      if CCzPop.VVspd4(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVN53k:
      if CCzPop.VVspd4(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVKFto:
      if CCzPop.VVspd4(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVORpf:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VV4UVF:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVi9NL:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVhDb5:
      if words[0] == VVdFti_lCase:
       ok = True
     elif mode == self.VVAFIr:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VVgBMX.append(row)
      chNum += 1
  if VVgBMX and mode == self.VVUU8P:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VVgBMX)
   for item in VVgBMX:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VVgBMX = newRows
  return VVgBMX
 def VV6zFc(self, bName):
  if bName:
   FFBV5V(self.VVShs0, boundFunction(self.VVZWtd, bName), title="Adding Channels ...")
 def VVZWtd(self, bName):
  num = 0
  path = VVlT2l + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVlT2l + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVShs0.VVtK2v():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFOCgm(row[1]))
    totChange += 1
  FFad9U(os.path.basename(path))
  self.VVuCd2(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVFuVq(self):
  txt = "Stream Type "
  VVXWOy = []
  VVXWOy.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVXWOy.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVXWOy.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVXWOy.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVXWOy.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVXWOy.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFue1q(self, self.VVZsuh, title="Change Reference Types to:", VVXWOy=VVXWOy)
 def VVZsuh(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVZq5b("1"   )
   elif item == "RT_4097" : self.VVZq5b("4097")
   elif item == "RT_5001" : self.VVZq5b("5001")
   elif item == "RT_5002" : self.VVZq5b("5002")
   elif item == "RT_8192" : self.VVZq5b("8192")
   elif item == "RT_8193" : self.VVZq5b("8193")
 def VVZq5b(self, rType):
  FFUzhN(self, boundFunction(FFBV5V, self, boundFunction(self.VV4fBt, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VV4fBt(self, refType):
  totChange = 0
  files  = self.VVyQGd()
  if files:
   for path in files:
    txt = FFteHI(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFad9U(os.path.basename(path))
  self.VVuCd2(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VV8Pex(self):
  totFiles = 0
  files  = self.VVyQGd()
  if files:
   totFiles = len(files)
  totChans = 0
  VVgBMX = self.VVkyfh()
  if VVgBMX:
   totChans = len(VVgBMX)
  FFKjl2(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVZ4AB(self):
  files  = self.VVyQGd()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFteHI(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVmHHA
   else    : color = VVdNwi
   totInvalid = FFW8xd(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFW8xd("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFKjl2(self, txt, title="Check IPTV References")
 def VVvJPJ(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVlT2l + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFad9U(os.path.basename(path))
  FF1Rf4()
  acceptedList = []
  VV6bm9 = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VV6bm9:
   VVenST = FFESB6(VV6bm9)
   if VVenST:
    for service in VVenST:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVlT2l + userBName
  bFile = VVlT2l + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFLcOy("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFLcOy("rm -f '%s'" % path)
  os.system(cmd)
  FF1Rf4()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVmHHA
    else     : res, color = "No" , VVdNwi
    txt += "    %s\t: %s\n" % (item, FFW8xd(res, color))
   FFKjl2(self, txt, title=title)
  else:
   txt = FFEW3v(self, "Could not complete the test on your system!", title=title)
 def VVtiUX(self):
  lameDbChans = CCfCKg.VVdgTw(self, CCfCKg.VVMHag)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVyQGd():
    toSave = False
    txt = FFteHI(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVuCd2(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFEW3v(self, 'No channels in "lamedb" !')
 def VVfmaa(self):
  files  = self.VVyQGd()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFUM2c(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVoB8i(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVuCd2(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVyVY8(self):
  iptvRefList = []
  files  = self.VVyQGd()
  if files:
   for path in files:
    txt = FFteHI(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVShs0.VVmRKN(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVoB8i(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVyQGd()
  if files:
   for path in files:
    lines = FFUM2c(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVuCd2(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVoB8i(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVjtBB(self):
  list = None
  if self.VVShs0:
   list = []
   for row in self.VVShs0.VVtK2v():
    list.append(row[4] + row[5])
  files  = self.VVyQGd()
  totChange = 0
  if files:
   for path in files:
    lines = FFUM2c(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVuCd2(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVuCd2(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FF1Rf4()
   if refreshTable and self.VVShs0:
    VVgBMX = self.VVkyfh()
    if VVgBMX and self.VVShs0:
     self.VVShs0.VVrhOZ(VVgBMX, self.tableTitle)
     self.VVShs0.VVczAi(txt)
   FFKjl2(self, txt, title=title)
  else:
   FFJjNb(self, "No changes.")
 def VVmct2(self):
  files = self.VVyQGd()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with open(path, "r") as f:
     span = iSearch(r"#NAME\s+(.*)", f.readline(), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VVz9jE = FFqGJf()
    if VVz9jE:
     for b in VVz9jE:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVyQGd(self):
  return CCzPop.VVxJII(self)
 @staticmethod
 def VVxJII(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVlT2l + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFteHI(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVFBPA(self, VVShs0, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFzmJo(colList[5]).strip()
  ndx = txt.find("Ref.")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "Row Number\t: %d of %d\n\n%s" % (VVShs0.VVYWtJ() + 1, VVShs0.VVUSpe(), txt)
  CCnwAc.VVBNh4(self, chName, refCode, url, txt)
 def VVZoNA(self, VVShs0, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  self.VVSnh9(VVShs0, chName, chUrl)
 def VVhXgb(self, mode, VVShs0, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVTKO7(mode, colList)
  self.VVSnh9(VVShs0, chName, chUrl)
 def VVSnh9(self, VVShs0, chName, chUrl):
  chName = FFOCgm(chName)
  if not self.VVxhn9(chName):
   FFhRft(self, chUrl, VVgeCS=False)
   if len(chName) > 70:
    chName = chName[:70] + " .."
   self.session.open(CCq8j1, enableZapping=False)
  else:
   FFtXOm(VVShs0, "This is a marker!", 300)
 def VVxhn9(self, chName):
  mark = ("--", "__", "==", "##")
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVnJl7(self, VVShs0, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF8KLs(self)
  if refCode:
   colDict = { 4:refCode, 5:FF726c(refCode, origUrl, chName) }
   VVShs0.VV1tKW_partial(colDict, showErr=True)
 def VVYpMz(self):
  self.session.open(CCMIrG)
  self.close()
 def VVQtLq(self, m3uMode):
  lines = FFUtqa("find / %s -iname '*.m3u' | grep -i '.m3u'" % FFx6OB(1))
  if lines:
   lines.sort()
   VVXWOy = []
   for line in lines:
    VVXWOy.append((line, line))
   if   m3uMode == 0 : title = "Browse Server from M3U URLs"
   elif m3uMode == 1 : title = "Analyse M3U File:"
   else    : title = "Convert M3U File to Bouquet"
   if m3uMode in [0, 2]: VVpjth = ("All to Playlist", self.VVkxz2)
   else    : VVpjth = None
   OKBtnFnc = boundFunction(self.VVSmqU, m3uMode, title)
   VV2cC5 = ("Show Full Path", self.VVjhFc)
   FFue1q(self, None, title=title, VVXWOy=VVXWOy, OKBtnFnc=OKBtnFnc, VV2cC5=VV2cC5, VVpjth=VVpjth)
  else:
   FFEW3v(self, 'No "m3u" files found.')
 def VVjhFc(self, VVz4aFObj, url):
  FFKjl2(self, url, title="Full Path")
 def VVSmqU(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if   m3uMode == 0 : FFBV5V(menuInstance, boundFunction(self.VVIbJt, title, path))
   elif m3uMode == 1 : FFBV5V(menuInstance, boundFunction(self.VVx7ii, title, path))
   else    : self.VVEJ0q(menuInstance, path)
 def VVkxz2(self, VVz4aFObj, item=None):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVz4aFObj.VVXWOy):
    path = item[1]
    if fileExists(path):
     with open(path, "r") as f:
      for line in f:
       url = self.VVrozo(line)
       if url:
        if not url in pList : pList.append(url)
        else    : dupl += 1
        break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    pListF = "%sPlaylist_%s.txt" % (FFTsBZ(CFG.exportedTablesPath.getValue()), FFtouN())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVz4aFObj.VVXWOy)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFKjl2(self, txt, title=title)
   else:
    FFEW3v(self, "Could not obtain URLs from this file list !", title=title)
 def VVx7ii(self, title, path):
  if fileExists(path):
   txt = FFteHI(path)
   totChan   = 0
   totLive   = 0
   totVod   = 0
   totSeries  = 0
   totUncat  = 0
   totVideo  = 0
   totAudio  = 0
   for match in iFinditer(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?((.+)(:[^:\/]+$)|.+)", txt, IGNORECASE):
    totChan += 1
    chName  = match.group(1).strip()
    fullUrl  = match.group(2).strip()
    urlPart1 = match.group(3)
    if urlPart1 : tUrl = urlPart1
    else  : tUrl = fullUrl
    tUrl = FFzmJo(tUrl).lower()
    chType, host, username, password, streamId, chName = CCzPop.VVspd4(tUrl)
    if   chType == "live" : totLive += 1
    elif chType == "movie" : totVod += 1
    elif chType == "series" : totSeries += 1
    else     : totUncat += 1
    aud_vid = CCzPop.VVspd4(tUrl, getAudVid=True)
    if   aud_vid == "vid" : totVideo += 1
    elif aud_vid == "aud" : totAudio += 1
   txt = ""
   txt += FFW8xd("File:\n", VVhJi6)
   txt += "    %s\n"    % path
   txt += "\n"
   txt += FFW8xd("Channels:\n", VVhJi6)
   txt += "    Total\t: %d\n" % totChan
   txt += "\n"
   txt += FFW8xd("Category:\n", VVhJi6)
   txt += "    Live\t: %d\n" % totLive
   txt += "    VOD\t: %d\n" % totVod
   txt += "    Series\t: %d\n" % totSeries
   txt += "    Uncat.\t: %d\n" % totUncat
   txt += "\n"
   txt += FFW8xd("Content:\n", VVhJi6)
   txt += "    Video\t: %d\n" % totVideo
   txt += "    Audio\t: %d\n" % totAudio
   txt += "\n"
   FFKjl2(self, txt, title="M3U File Analysis")
  else:
   FFEW3v(SELF, "Cannot open file :\n\n%s" % path, title=title)
   return
 def VVUO6R(self, isBrowseServer):
  lines = FFUtqa('find / %s -iname "*playlist*" | grep -i ".txt"' % FFx6OB(1))
  if lines:
   lines.sort()
   VVXWOy = []
   for line in lines:
    VVXWOy.append((line, line))
   OKBtnFnc = boundFunction(self.VVMIgy, isBrowseServer)
   FFue1q(self, None, title="Select Playlist File", VVXWOy=VVXWOy, width=1200, OKBtnFnc=OKBtnFnc)
  else:
   FFV5mI(self, "( playlist.txt  or  playlists.txt )")
 def VVMIgy(self, isBrowseServer, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   VVXWOy = []
   lines = FFUM2c(path)
   for line in lines:
    line = line.strip()
    if line and "/" in line:
     VVXWOy.append((line, line))
   if VVXWOy:
    if isBrowseServer : title = "Select Server URL  (Total = %d)" % len(VVXWOy)
    else    : title = "Convert to Bouquet"
    OKBtnFnc  = boundFunction(self.VVIa0r, isBrowseServer, title)
    VVdwgz  = ("Exit IPTV"  , FF3SS7)
    VV2cC5  = ("Show URL"  , self.VVWvWM)
    VVpjth   = ("Check & Filter" , boundFunction(self.VV91TJ, path, menuInstance, isBrowseServer))
    FFue1q(self, None, title=title, VVXWOy=VVXWOy, width=1200, OKBtnFnc=OKBtnFnc, VVdwgz=VVdwgz, VV2cC5=VV2cC5, VVpjth=VVpjth)
   else:
    FFEW3v(self, "No valid URLs in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVWvWM(self, VVz4aFObj, url):
  FFKjl2(self, url, title="URL")
 def VVIa0r(self, isBrowseServer, title, item=None):
  if item:
   menuInstance, txt, url, ndx = item
   if isBrowseServer:
    FFBV5V(menuInstance, boundFunction(self.VVloxv, title, url), title="Checking Server ...")
   else:
    FFUzhN(self, boundFunction(FFBV5V, menuInstance, boundFunction(self.VVpGlN, menuInstance, url), title="Downloading ..."), "Download m3u file from this URL ?\n\n%s" % url, title=title)
 def VVpGlN(self, menuInstance, url):
  path, err = FF0NYM(url, "ajpanel_tmp.m3u", timeout=3)
  title = "Download Problem"
  if err:
   FFEW3v(self, err, title=title)
  else:
   if fileExists(path):
    txt = FFteHI(path)
    if '{"user_info":{"auth":0}}' in txt:
     FFEW3v(self, "Unauthorized", title=title)
     os.system(FFLcOy("rm -f '%s'" % path))
     return
   self.VVEJ0q(menuInstance, path)
 def VVXfpQ(self):
  curChName = self.VVShs0.VVB4LN(1)
  curRefCode = self.VVShs0.VVB4LN(4)
  curUrl  = self.VVShs0.VVB4LN(5)
  FFtXOm(self, "Loading Channels ...")
  tableRows = []
  lameDbChans = CCfCKg.VVdgTw(self, CCfCKg.VVYPJZ, VVAvww=False, VVnWJU=False)
  if lameDbChans:
   curCh = curChName.lower().replace(" hd", "").replace(" fm", "").replace("4k", "")
   for refCode in lameDbChans:
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCgbc1.VVEnnI(chName.lower(), curCh)
    if ratio > 50:
     tableRows.append((chName, FFp5ev(sat), refCode.replace("_", ":")))
  FFtXOm(self)
  title = "Share Reference with Satellite/C/T Channel"
  if tableRows:
   tableRows.sort(key=lambda x: x[0].lower())
   VVcgcO  = ("Share Sat/C/T Ref.", boundFunction(self.VVu69d, title, curChName, curRefCode, curUrl) , [])
   header   = ("Name" , "Sat"  , "Reference" )
   widths   = (34  , 33  , 33   )
   FFZUAl(self, None, title=title, header=header, VVXy7C=tableRows, VV08hy=widths, VVH2Qb=24, VVcgcO=VVcgcO, VVrgKF="#0a00112B", VVr4tL="#0a001126", VVnGDQ="#0a001126", VVli9s="#00000000")
  else:
   FFEW3v(self, "No similar names found !", title)
 def VVu69d(self, newtitle, curChName, curRefCode, curUrl, VVShs0, title, txt, colList):
  VVShs0.cancel()
  newChName = colList[0]
  newRefCode = colList[2]
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  FFBV5V(self.VVShs0, boundFunction(self.VVuMjA, data, ques, newtitle))
 def VVuMjA(self, data, ques, title):
  FFUzhN(self.VVShs0, boundFunction(FFBV5V, self.VVShs0, boundFunction(self.VVHRhm, data)), ques, title=title, VVBim4=True)
 def VVHRhm(self, data):
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  if curFullUrl and newFullUrl:
   for path in self.VVyQGd():
    txt = FFteHI(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FF1Rf4()
    newRow = []
    for i in range(6):
     newRow.append(self.VVShs0.VVB4LN(i))
    newRow[4] = newRefCode
    done = self.VVShs0.VVoPzw(newRow)
    FFJjNb(self, "Done", title=title)
   else:
    FFEW3v(self, "Not found in IPTV files !", title=title)
  else:
   FFEW3v(self, "Could not read channel info !", title=title)
 def VV91TJ(self, path, parentMenuInstance, isBrowseServer, menuInstance, url):
  FFBV5V(menuInstance, boundFunction(self.VV1aQP, path, parentMenuInstance, isBrowseServer, menuInstance), title="Filtering Servers ...")
 def VV1aQP(self, path, parentMenuInstance, isBrowseServer, menuInstance):
  urlList = []
  for ndx, item in enumerate(menuInstance.VVXWOy):
   qUrl = self.VVJq1Q(self.VVvvP4, item[0])
   txt, err = self.VVFmAW(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVETLr(item, "auth") == "0":
       urlList.append(qUrl)
    except:
     pass
  title = "Authorized Servers"
  if urlList:
   totChk = len(menuInstance.VVXWOy)
   totAuth = len(urlList)
   if not totAuth == totChk:
    newPath = path + "_OK_%s.txt" % FFtouN()
    with open(newPath, "w") as f:
     for item in urlList:
      f.write("%s\n" % item)
    self.VVUO6R(isBrowseServer)
    txt = ""
    txt += "Checked\t: %d\n"  %  totChk
    txt += "Authorized\t: %s\n\n" %  FFW8xd(str(totAuth), VVmHHA)
    txt += "Output File:\n%s\n " %  FFW8xd(newPath, VVqb5h)
    FFKjl2(self, txt, title=title)
    menuInstance.close()
    parentMenuInstance.close()
   else:
    FFJjNb(self, "All URLs are authorized.", title=title)
  else:
   FFEW3v(self, "No authorized URL found !", title=title)
 def VVEJ0q(self, parentInstant, path):
  files = CCzPop.VVxJII(self, atLeastOne=True)
  if files: exitCurWin = False
  else : exitCurWin = True
  CCzPop.VVWBvT(parentInstant, path, exitCurWin)
 @staticmethod
 def VVWBvT(SELF, path, exitCurWin):
  FFUzhN(SELF, boundFunction(FFBV5V, SELF, boundFunction(CCzPop.VVNX1s, SELF, path, exitCurWin), title="Converting ...")
    , "Convert file to bouquet ?\n\n%s" % path, title="Convert m3u file")
 @staticmethod
 def VVNX1s(SELF, path, exitCurWin):
  SID = TSID = ONID = 0
  MAX = 65535
  title = "Convert m3u File to Bouquet"
  if not fileExists(path):
   FFEW3v(SELF, "Cannot open file :\n\n%s" % path, title=title)
   return
  bName  = os.path.basename(path)
  bName  = os.path.splitext(bName)[0]
  bName   = CCzPop.VVshKZ(bName)
  bName  = "IPTV_" + bName
  bFileName = "userbouquet.%s.tv" % bName
  if fileExists(VVlT2l + bFileName):
   while True:
    SID += 1
    tmpBName = "%s_%d" % (bName, SID)
    bFileName = "userbouquet.%s.tv" % tmpBName
    if not fileExists(VVlT2l + bFileName):
     bName = tmpBName
     break
  txt = FFteHI(path)
  pattern = r"#EXTINF.+,(.+)\n(.+)"
  span = iSearch(r"#EXTINF.+,(.+)\n(.+)", txt, IGNORECASE)
  if span:
   with open(VVlT2l + bFileName, "w") as f:
    totChan = 0
    f.write("#NAME %s\n" % bName.replace("IPTV_", "IPTV - ", 1))
    for match in iFinditer(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?(.+)", txt, IGNORECASE):
     TSID += 1
     if TSID > MAX:
      TSID = MAX
      ONID += 1
      if ONID > MAX:
       ONID = 0
     chName = match.group(1).strip()
     url  = FFNc1a(match.group(2).strip())
     rType = CFG.iptvAddToBouquetRefType.getValue()
     refCode = "%s:0:1:%s:%s:%s:0:0:0:0:" % (rType, hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:])
     line1 = "#SERVICE %s%s\n" % (refCode.upper(), url)
     line2 = "#DESCRIPTION %s\n" % chName
     f.write(line1 + line2)
     totChan += 1
   FFad9U(bFileName)
   FF1Rf4()
   FFJjNb(SELF, 'New Bouquet = %s\n\nTotal Channels = %d' % (bName, totChan), title=title)
  else:
   FFEW3v(SELF, "No channels found in file (or invalid file format) !\n\n%s" % path, title=title)
  if exitCurWin:
   SELF.close()
 @staticmethod
 def VVFmAW(url, timeout=3):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   res = res.read().decode('utf-8')
   if res:
    if "<!DOCTYPE html>" in res : return "", "Incorrect data format from server !"
    else      : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 def VVrKV0(self, url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     key, val = part.split("=")
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVspd4(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = parts[1]
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVJq1Q(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVrKV0(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVvvP4   : return "%s"            % url
  elif mode == self.VVnkpH   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVUaXw   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VV67Ce  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVcxju : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVlm6j   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVkgOr    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVo93c  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVbZ0A  : return "%s&action=get_simple_data_table&stream_id=%s"  % (url, Id)
  elif mode == self.VVuwqM  : return "%s&action=get_short_epg&stream_id=%s"    % (url, Id)
  elif mode == self.VVTIil : return "%s&action=get_short_epg&stream_id=%s&limit=%s" % (url, Id, limit)
  elif mode == self.VVmNeB   : return "%s&action=get_vod_info&vod_id=%s"     % (url, Id)
 @staticmethod
 def VVETLr(item, key, isDate=False, isBase64=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFnWMY(int(val))
    elif isBase64 : val = b64decode(val).decode("utf-8")
   except:
    pass
   return val
  else:
   return ""
 def VVIbJt(self, title, path):
  if fileExists(path):
   qUrl = ""
   with open(path, "r") as f:
    for line in f:
     qUrl = self.VVrozo(line)
     if qUrl:
      break
   if qUrl : self.VVloxv(title, qUrl)
   else : FFEW3v(self, "No valid Server URL found in:\n\n%s" % path, title=title)
  else:
   FFEW3v(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVvyPo_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl = self.VVIoW0()
  if qUrl:
   FFBV5V(self, boundFunction(self.VVloxv, title, qUrl), title="Checking Server ...")
  else:
   FFEW3v(self, "Error while trying URL for current channel !", title=title)
 def VVIoW0(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF8KLs(self)
  qUrl = self.VVrozo(decodedUrl)
  return qUrl
 def VVrozo(self, urlLine):
  if urlLine.startswith("#"):
   return ""
  span  = iSearch(r"\s*(.+)\/\/*(.+)\/(.+)\/(\d+):*", urlLine, IGNORECASE)
  if span:
   uUrl = span.group(1)
   uUser = span.group(2)
   uPass = span.group(3)
   qUrl = "%s/get.php?username=%s&password=%s&type=m3u" % (uUrl, uUser, uPass)
   return qUrl
  else:
   return ""
 def VVloxv(self, title, url):
  self.VVvyPoData = {}
  qUrl = self.VVJq1Q(self.VVvvP4, url)
  txt, err = self.VVFmAW(qUrl)
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVvyPoData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVvyPoData["username"    ] = self.VVETLr(item, "username"        )
    self.VVvyPoData["password"    ] = self.VVETLr(item, "password"        )
    self.VVvyPoData["message"    ] = self.VVETLr(item, "message"        )
    self.VVvyPoData["auth"     ] = self.VVETLr(item, "auth"         )
    self.VVvyPoData["status"    ] = self.VVETLr(item, "status"        )
    self.VVvyPoData["exp_date"    ] = self.VVETLr(item, "exp_date"    , isDate=True )
    self.VVvyPoData["is_trial"    ] = self.VVETLr(item, "is_trial"        )
    self.VVvyPoData["active_cons"   ] = self.VVETLr(item, "active_cons"       )
    self.VVvyPoData["created_at"   ] = self.VVETLr(item, "created_at"   , isDate=True )
    self.VVvyPoData["max_connections"  ] = self.VVETLr(item, "max_connections"      )
    self.VVvyPoData["allowed_output_formats"] = self.VVETLr(item, "allowed_output_formats"    )
    lst = []
    key = "allowed_output_formats"
    if key in item:
     for item in item[key]:
      lst.append(str(item))
     self.VVvyPoData[key] = lst
    item = tDict["server_info"]
    self.VVvyPoData["url"    ] = self.VVETLr(item, "url"        )
    self.VVvyPoData["port"    ] = self.VVETLr(item, "port"        )
    self.VVvyPoData["https_port"  ] = self.VVETLr(item, "https_port"      )
    self.VVvyPoData["server_protocol" ] = self.VVETLr(item, "server_protocol"     )
    self.VVvyPoData["rtmp_port"   ] = self.VVETLr(item, "rtmp_port"       )
    self.VVvyPoData["timezone"   ] = self.VVETLr(item, "timezone"       )
    self.VVvyPoData["timestamp_now"  ] = self.VVETLr(item, "timestamp_now"  , isDate=True )
    self.VVvyPoData["time_now"   ] = self.VVETLr(item, "time_now"       )
    VVXWOy = []
    VVXWOy.append(("Live"     , "serverLive"  ))
    VVXWOy.append(("VOD"     , "serverVod"  ))
    VVXWOy.append(("Series (Seasons)"  , "serverSeries" ))
    VVXWOy.append(VVGV45)
    VVXWOy.append(("User/Server Info." , "serverInfo"  ))
    OKBtnFnc  = self.VVvyPoOptions
    VVdwgz  = ("Exit IPTV", FF3SS7)
    FFue1q(self, None, title="Server Resources", VVXWOy=VVXWOy, OKBtnFnc=OKBtnFnc, VVdwgz=VVdwgz)
   else:
    err = "Could not get data from server !"
  if err:
   FFEW3v(self, err, title=title)
  FFtXOm(self)
 def VVvyPoOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "serverLive" : FFBV5V(menuInstance, boundFunction(self.VV0jTn, self.VVnkpH , title=title), title=wTxt)
   elif ref == "serverVod"  : FFBV5V(menuInstance, boundFunction(self.VV0jTn, self.VVUaXw , title=title), title=wTxt)
   elif ref == "serverSeries" : FFBV5V(menuInstance, boundFunction(self.VV0jTn, self.VV67Ce, title=title), title=wTxt)
   elif ref == "serverInfo" : FFBV5V(menuInstance, boundFunction(self.VVQSyb          , title=title), title=wTxt)
 def VVQSyb(self, title):
  c1 = "#f#11ffffaa#"
  c2 = "#f#11aaffff#"
  list = []
  list.append((c1 + "User" , "Username"    , self.VVvyPoData["username"    ]))
  list.append((c1 + "User" , "Password"    , self.VVvyPoData["password"    ]))
  list.append((c1 + "User" , "Message"     , self.VVvyPoData["message"        ]))
  list.append((c1 + "User" , "Auth"     , self.VVvyPoData["auth"     ]))
  list.append((c1 + "User" , "Status"     , self.VVvyPoData["status"        ]))
  list.append((c1 + "User" , "Expiry"     , self.VVvyPoData["exp_date"    ]))
  list.append((c1 + "User" , "Is Trial"    , self.VVvyPoData["is_trial"    ]))
  list.append((c1 + "User" , "Active Cons"    , self.VVvyPoData["active_cons"       ]))
  list.append((c1 + "User" , "Created"     , self.VVvyPoData["created_at"    ]))
  list.append((c1 + "User" , "Max Connections"   , self.VVvyPoData["max_connections"   ]))
  list.append((c1 + "User" , "Allowed Output Formats" , " , ".join(self.VVvyPoData["allowed_output_formats"])))
  list.append((c2 + "Server" , "URL"      , self.VVvyPoData["url"         ]))
  list.append((c2 + "Server" , "Port"     , self.VVvyPoData["port"     ]))
  list.append((c2 + "Server" , "HTTPS Port"    , self.VVvyPoData["https_port"       ]))
  list.append((c2 + "Server" , "Server Protocol"   , self.VVvyPoData["server_protocol"      ]))
  list.append((c2 + "Server" , "RTMP Port"    , self.VVvyPoData["rtmp_port"    ]))
  list.append((c2 + "Server" , "Timezone"    , self.VVvyPoData["timezone"    ]))
  list.append((c2 + "Server" , "Local Time"    , self.VVvyPoData["timestamp_now"   ]))
  list.append((c2 + "Server" , "Server Time"    , self.VVvyPoData["time_now"    ]))
  header   = ("User/Server", "Subject" , "Value" )
  widths   = (15   , 45   , 40  )
  FFZUAl(self, None, title=title, header=header, VVXy7C=list, VV08hy=widths, VVH2Qb=26, VVrgKF="#0a00292B", VVr4tL="#0a002126", VVnGDQ="#0a002126", VVli9s="#00000000")
  FFtXOm(self)
 def VVVIU1(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    if mode == self.VVlm6j:
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVETLr(item, "num"         )
      name     = self.VVETLr(item, "name"        )
      stream_id    = self.VVETLr(item, "stream_id"       )
      stream_icon    = self.VVETLr(item, "stream_icon"       )
      epg_channel_id   = self.VVETLr(item, "epg_channel_id"      )
      added     = self.VVETLr(item, "added"    , isDate=True )
      is_adult    = self.VVETLr(item, "is_adult"       )
      category_id    = self.VVETLr(item, "category_id"       )
      if self.VVxhn9(name): name = self.VVvTE8(name)
      list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVkgOr:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVETLr(item, "num"         )
      name    = self.VVETLr(item, "name"        )
      stream_id   = self.VVETLr(item, "stream_id"       )
      stream_icon   = self.VVETLr(item, "stream_icon"       )
      added    = self.VVETLr(item, "added"    , isDate=True )
      is_adult   = self.VVETLr(item, "is_adult"       )
      category_id   = self.VVETLr(item, "category_id"       )
      container_extension = self.VVETLr(item, "container_extension"     ) or "mp4"
      if self.VVxhn9(name): name = self.VVvTE8(name)
      list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVo93c:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVETLr(item, "num"        )
      name    = self.VVETLr(item, "name"       )
      series_id   = self.VVETLr(item, "series_id"      )
      cover    = self.VVETLr(item, "cover"       )
      genre    = self.VVETLr(item, "genre"       )
      episode_run_time = self.VVETLr(item, "episode_run_time"    )
      category_id   = self.VVETLr(item, "category_id"      )
      container_extension = self.VVETLr(item, "container_extension"    ) or "mp4"
      if self.VVxhn9(name): name = self.VVvTE8(name)
      list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VV0jTn(self, mode, title):
  qUrl = self.VVJq1Q(mode, self.VVvyPoData["playListURL"])
  txt, err = self.VVFmAW(qUrl)
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     for item in tDict:
      category_id  = self.VVETLr(item, "category_id"  )
      category_name = self.VVETLr(item, "category_name" )
      parent_id  = self.VVETLr(item, "parent_id"  )
      if category_name:
       list.append((category_name, category_id, parent_id))
   except:
    err = "Cannot parse received data !"
  else:
   FFEW3v(self, err, title=title)
  if err:
   FFEW3v(self, err, title=title)
  elif list:
   list.sort(key=lambda x: x[0].lower())
   if   mode == self.VVnkpH  : okTitle = "Show Channels"
   elif mode == self.VVUaXw  : okTitle = "Show Channels"
   elif mode == self.VV67Ce : okTitle = "Show List"
   VVcgcO  = (okTitle, boundFunction(self.VVa4oj, mode) , [])
   VVFZEv = ("Exit IPTV"   , FF3SS7       , [])
   header   = ("Category", "catID" , "ParentID" )
   widths   = (100   , 0  , 0    )
   FFZUAl(self, None, title=title, header=header, VVXy7C=list, VV08hy=widths, VVH2Qb=30, VVFZEv=VVFZEv, VVcgcO=VVcgcO, VVrgKF="#0a00292B", VVr4tL="#0a002126", VVnGDQ="#0a002126", VVli9s="#00000000")
  else:
   FFEW3v(self, "No list from server !", title=title)
  FFtXOm(self)
 def VVa4oj(self, mode, VVShs0, title, txt, colList):
  title = colList[1]
  FFBV5V(VVShs0, boundFunction(self.VV57Y8, mode, VVShs0, title, txt, colList), title="Downloading ...")
 def VV57Y8(self, mode, VVShs0, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title  = bName
  if   mode == self.VVnkpH  : mode, title = self.VVlm6j  , "Live = %s" % title
  elif mode == self.VVUaXw  : mode, title = self.VVkgOr  , "VOD = %s" % title
  elif mode == self.VV67Ce : mode, title = self.VVo93c , "Series = %s" % title
  qUrl  = self.VVJq1Q(mode, self.VVvyPoData["playListURL"], catID)
  txt, err = self.VVFmAW(qUrl)
  list  = []
  if not err:
   if   mode == self.VVlm6j : list, err = self.VVVIU1(mode, txt)
   elif mode == self.VVkgOr  : list, err = self.VVVIU1(mode, txt)
   elif mode == self.VVo93c : list, err = self.VVVIU1(mode, txt)
  if err:
   FFEW3v(self, err, title=title)
  elif list:
   VVFZEv  = ("Exit IPTV"   , FF3SS7            , [])
   if mode == self.VVlm6j:
    VVcgcO  = ("Play"    , boundFunction(self.VVhXgb, mode)    , [])
    VVUv68 = (""     , boundFunction(self.VV6Rif, mode)    , [])
    VVUhO3 = ("Download PIcons" , boundFunction(self.VViDhD , mode)   , [])
    VV6mer = ("Add ALL to Bouquet" , boundFunction(self.VVT28L, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VVqjzl  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVkgOr:
    VVcgcO  = ("Play"    , boundFunction(self.VVhXgb, mode)    , [])
    VVUv68 = (""     , boundFunction(self.VV6Rif, mode)    , [])
    VVUhO3 = ("Download PIcons" , boundFunction(self.VViDhD , mode)   , [])
    VV6mer = ("Add ALL to Bouquet" , boundFunction(self.VVT28L, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VVqjzl  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVo93c:
    VVcgcO  = ("Show Seasons", boundFunction(self.VVIhK0, mode), [])
    VVUv68 = ("", boundFunction(self.VVwZPr, mode), [])
    VVUhO3 = None
    VV6mer = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VVqjzl  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFZUAl(self, None, title=title, header=header, VVXy7C=list, VVqjzl=VVqjzl, VV08hy=widths, VVH2Qb=26, VVcgcO=VVcgcO, VVFZEv=VVFZEv, VVUhO3=VVUhO3, VV6mer=VV6mer, VVUv68=VVUv68, searchCol=1, VVrgKF="#0a00292B", VVr4tL="#0a002126", VVnGDQ="#0a002126", VVli9s="#00000000", VVxpps=True)
  else:
   FFEW3v(self, "No Channels found !", title=title)
  FFtXOm(self)
 def VVIhK0(self, mode, VVShs0, title, txt, colList):
  title = colList[1]
  FFBV5V(VVShs0, boundFunction(self.VV4bIz, mode, VVShs0, title, txt, colList), title="Downloading ...")
 def VV4bIz(self, mode, VVShs0, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVJq1Q(self.VVcxju, self.VVvyPoData["playListURL"], series_id)
  txt, err = self.VVFmAW(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVETLr(tDict["info"], "name"   )
      category_id = self.VVETLr(tDict["info"], "category_id" )
      icon  = self.VVETLr(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVETLr(EP, "id"     )
        episode_num   = self.VVETLr(EP, "episode_num"   )
        epTitle    = self.VVETLr(EP, "title"     )
        container_extension = self.VVETLr(EP, "container_extension" )
        seasonNum   = self.VVETLr(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFEW3v(self, err, title=title)
  elif list:
   VVFZEv = ("Exit IPTV"   , FF3SS7            , [])
   VVUhO3 = ("Download PIcons" , boundFunction(self.VViDhD , mode)   , [])
   VV6mer = ("Add ALL to Bouquet" , boundFunction(self.VVT28L, mode, title) , [])
   VVUv68 = (""     , boundFunction(self.VV6Rif, mode)    , [])
   VVcgcO  = ("Play"    , boundFunction(self.VVhXgb, mode)    , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVqjzl  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFZUAl(self, None, title=title, header=header, VVXy7C=list, VVqjzl=VVqjzl, VV08hy=widths, VVH2Qb=26, VVFZEv=VVFZEv, VVUhO3=VVUhO3, VVcgcO=VVcgcO, VVUv68=VVUv68, VV6mer=VV6mer, VVrgKF="#0a00292B", VVr4tL="#0a002126", VVnGDQ="#0a002126", VVli9s="#00000000")
  else:
   FFEW3v(self, "No Channels found !", title=title)
  FFtXOm(self)
 def VVTKO7(self, mode, colList):
  if mode == self.VVlm6j:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVkgOr:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFOCgm(chName)
  url = self.VVvyPoData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVrKV0(url)
  refCode = self.VVN6tm(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VV6Rif(self, mode, VVShs0, title, txt, colList):
  FFBV5V(VVShs0, boundFunction(self.VV7EVQ, mode, VVShs0, title, txt, colList))
 def VV7EVQ(self, mode, VVShs0, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVTKO7(mode, colList)
  CCnwAc.VVQhuL(self, chName, chUrl, picUrl, refCode, txt)
 def VVwZPr(self, mode, VVShs0, title, txt, colList):
  FFBV5V(VVShs0, boundFunction(self.VVXXZ6, mode, VVShs0, title, txt, colList))
 def VVXXZ6(self, mode, VVShs0, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  += "Duration\t: %s" % Dur
  if Cover: path, err = FF0NYM(Cover, "ajpanel_tmp.png", timeout=1)
  else : path = ""
  CCnwAc.VVnSa9(self, "", txt, title, path)
 def VVT28L(self, mode, bName, VVShs0, title, txt, colList):
  FFBV5V(VVShs0, boundFunction(self.VVjeBd, mode, bName, VVShs0, title, txt, colList), title="Adding Channels ...")
 def VVjeBd(self, mode, bName, VVShs0, title, txt, colList):
  url = self.VVvyPoData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVrKV0(url)
  bNameFile = CCzPop.VVshKZ(bName)
  num  = 0
  path = VVlT2l + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVlT2l + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVShs0.VVtK2v():
    chName, chUrl, picUrl, refCode = self.VVTKO7(mode, row)
    f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
    f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
    totChange += 1
  FFad9U(os.path.basename(path))
  self.VVuCd2(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VViDhD(self, mode, VVShs0, title, txt, colList):
  if os.system(FFLcOy("which ffmpeg")) == 0:
   self.session.open(boundFunction(CCLrtT, iptvTableInstance=self, VVShs0=VVShs0, piconMode=mode))
  else:
   FFUzhN(self, self.VV7kzE, '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?')
 def VV7kzE(self):
  cmd = FF2NxH(VVQ6yh, "ffmpeg")
  if cmd : FFb6xn(self, cmd, title="Installing FFmpeg")
  else : FFVWVs(self)
 def VVN6tm(self, catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = self.VVvhB6(catID, MAX_4b)
  TSID = self.VVvhB6(chNum, MAX_4b)
  ONID = self.VVvhB6(chNum, MAX_4b)
  NS  = self.VVvhB6(stID, MAX_8b)
  int(catID) if catID.isdigit() else ""
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 def VVvhB6(self, numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVshKZ(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
class CCezVa(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFQUXb(VV2YUz, 700, 700, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVTOw5  = 0
  self.VVroqQ = 1
  self.VV9MeD  = 2
  VVXWOy = []
  VVXWOy.append(("Find All (from filter)"    , "VVgtlh" ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Find All"        , "VVsjmG"    ))
  VVXWOy.append(("Find TV"        , "VVgyT0"    ))
  VVXWOy.append(("Find Radio"       , "VVIPfQ"   ))
  if self.VVaBkE():
   VVXWOy.append(VVGV45)
   VVXWOy.append(("Hide Channel: %s" % self.servName , "VVYTQv"   ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Zap History"       , "VVOoUk"    ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("PIcons Tools"       , "PIconsTools"     ))
  VVXWOy.append(("Channels Tools"      , "ChannelsTools"    ))
  FFZrGE(self, VVXWOy=VVXWOy, title=title)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  FFNsDm(self["myMenu"])
  FF8cqd(self)
  if self.isFindMode:
   self.VVfBz4(self.VVxmRv())
 def VVOF6C(self):
  global VVaLC9
  VVaLC9 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVsjmG"    : self.VVsjmG()
   elif item == "VVgtlh" : self.VVgtlh()
   elif item == "VVgyT0"    : self.VVgyT0()
   elif item == "VVIPfQ"   : self.VVIPfQ()
   elif item == "VVYTQv"   : self.VVYTQv()
   elif item == "VVOoUk"    : self.VVOoUk()
   elif item == "PIconsTools"     : self.session.open(CCgbc1)
   elif item == "ChannelsTools"    : self.session.open(CCfCKg)
 def VVgyT0(self) : self.VVfBz4(self.VVTOw5)
 def VVIPfQ(self) : self.VVfBz4(self.VVroqQ)
 def VVsjmG(self) : self.VVfBz4(self.VV9MeD)
 def VVfBz4(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFiVZt(self, boundFunction(self.VVppiC, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVgtlh(self):
  filterObj = CCpZgp(self)
  filterObj.VVwJPM(self.VV8wQL)
 def VV8wQL(self, item):
  self.VVppiC(self.VV9MeD, item)
 def VVaBkE(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFF590(self.refCode)        : return False
  return True
 def VVppiC(self, mode, VVMtwy):
  FFBV5V(self, boundFunction(self.VVoh5y, mode, VVMtwy), title="Searching ...")
 def VVoh5y(self, mode, VVMtwy):
  if VVMtwy:
   self.findTxt = VVMtwy
   if   mode == self.VVTOw5  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVroqQ : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVMtwy)
   if len(title) > 55:
    title = title[:55] + ".."
   VVgBMX = self.VVBKSj(VVMtwy, servTypes)
   if self.isFindMode or mode == self.VV9MeD:
    VVgBMX += self.VVB9CA(VVMtwy)
   if VVgBMX:
    VVgBMX.sort(key=lambda x: x[0].lower())
    VVWZbv = self.VVsNOO
    VVcgcO  = ("Zap"   , self.VVXwKB    , [])
    VVUhO3 = ("Current Service", self.VVPnDv , [])
    VV6mer = ("Options"  , self.VVi6NP , [])
    VVUv68 = (""    , self.VVZ3Pu , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVqjzl  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFZUAl(self, None, title=title, header=header, VVXy7C=VVgBMX, VVqjzl=VVqjzl, VV08hy=widths, VVH2Qb=25, VVcgcO=VVcgcO, VVWZbv=VVWZbv, VVUhO3=VVUhO3, VV6mer=VV6mer, VVUv68=VVUv68)
   else:
    self.VVfBz4(self.VVxmRv())
    FFJjNb(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVBKSj(self, VVMtwy, servTypes):
  VVy14z  = eServiceCenter.getInstance()
  VVygG2   = '%s ORDER BY name' % servTypes
  VVYglE   = eServiceReference(VVygG2)
  VVmKwM = VVy14z.list(VVYglE)
  if VVmKwM: VVXy7C = VVmKwM.getContent("CN", False)
  else     : VVXy7C = None
  VVgBMX = []
  if VVXy7C:
   VVT1Il, VVyD7q = FF0mQl()
   tp   = CCLFki()
   words, asPrefix = CCpZgp.VV3cHn(VVMtwy)
   colorYellow  = CCKdGY.VVlMXG(VVFlyn)
   colorWhite  = CCKdGY.VVlMXG(VVI2d4)
   for s in VVXy7C:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFTI0M(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVT1Il:
        STYPE = VVyD7q[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVDV7b(refCode)
       if not "-S" in syst:
        sat = syst
       VVgBMX.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVgBMX
 def VVB9CA(self, VVMtwy):
  VVMtwy = VVMtwy.lower()
  VVz9jE = FFqGJf()
  VVgBMX = []
  colorYellow  = CCKdGY.VVlMXG(VVFlyn)
  colorWhite  = CCKdGY.VVlMXG(VVI2d4)
  if VVz9jE:
   for b in VVz9jE:
    VVdFti  = b[0]
    VVdaI2  = b[1].toString()
    VV6bm9 = eServiceReference(VVdaI2)
    VVenST = FFESB6(VV6bm9)
    for service in VVenST:
     refCode  = service[0]
     if FFF590(refCode):
      servName = service[1]
      if VVMtwy in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VVMtwy), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VVgBMX.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVgBMX
 def VVxmRv(self):
  VVDbSW = InfoBar.instance
  if VVDbSW:
   VVDkKf = VVDbSW.servicelist
   if VVDkKf:
    return VVDkKf.mode == 1
  return self.VV9MeD
 def VVsNOO(self, VVShs0):
  self.close()
  VVShs0.cancel()
 def VVXwKB(self, VVShs0, title, txt, colList):
  FFhRft(VVShs0, colList[2], VVgeCS=False, checkParentalControl=True)
 def VVPnDv(self, VVShs0, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF8KLs(VVShs0)
  if refCode:
   VVShs0.VVevA6(2, FF726c(refCode, iptvRef, chName), True)
 def VVi6NP(self, VVShs0, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CCsg5m(self, VVShs0, 2)
  mSel.VVVkt5(servName, refCode)
 def VVZ3Pu(self, VVShs0, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  CCnwAc.VVwJQT(self, chName, refCode, txt)
 def VVYTQv(self):
  FFUzhN(self, self.VV7fEO, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VV7fEO(self):
  ret = FFdZr6(self.refCode, True)
  if ret:
   self.VVWbM1()
   self.close()
  else:
   FFtXOm(self, "Cannot change state" , 1000)
 def VVWbM1(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVIZQg()
  except:
   self.VVAftt()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      self.session.nav.playService(serviceRef)
 def VVJAEU(self):
  VVDbSW = InfoBar.instance
  if VVDbSW:
   VVDkKf = VVDbSW.servicelist
   if VVDkKf:
    VVDkKf.setMode()
 def VVIZQg(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVDbSW = InfoBar.instance
   if VVDbSW:
    VVDkKf = VVDbSW.servicelist
    if VVDkKf:
     hList = VVDkKf.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVDkKf.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVDkKf.history  = newList
       VVDkKf.history_pos = pos
 def VVAftt(self):
  VVDbSW = InfoBar.instance
  if VVDbSW:
   VVDkKf = VVDbSW.servicelist
   if VVDkKf:
    VVDkKf.history  = []
    VVDkKf.history_pos = 0
 def VVOoUk(self):
  VVDbSW = InfoBar.instance
  VVgBMX = []
  if VVDbSW:
   VVDkKf = VVDbSW.servicelist
   if VVDkKf:
    VVT1Il, VVyD7q = FF0mQl()
    for chParams in VVDkKf.history:
     refCode = chParams[-1].toString()
     chName = FFi9ZT(refCode)
     isIptv = FFF590(refCode)
     if isIptv: sat = "-"
     else  : sat = FFTI0M(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVT1Il:
       STYPE = VVyD7q[sTypeInt]
     VVgBMX.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVgBMX:
   VVcgcO  = ("Zap"   , self.VVOtHw   , [])
   VV6mer = ("Clear History" , self.VVkzKx   , [])
   VVUv68 = (""    , self.VV7bsDFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVqjzl  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFZUAl(self, None, title=title, header=header, VVXy7C=VVgBMX, VVqjzl=VVqjzl, VV08hy=widths, VVH2Qb=23, VVcgcO=VVcgcO, VV6mer=VV6mer, VVUv68=VVUv68)
  else:
   FFJjNb(self, "Not found", title=title)
 def VVOtHw(self, VVShs0, title, txt, colList):
  FFhRft(VVShs0, colList[3], VVgeCS=False, checkParentalControl=True)
 def VVkzKx(self, VVShs0, title, txt, colList):
  FFUzhN(self, boundFunction(self.VV8GUD, VVShs0), "Clear Zap History ?")
 def VV8GUD(self, VVShs0):
  self.VVAftt()
  VVShs0.cancel()
 def VV7bsDFromZapHistory(self, VVShs0, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  png, path = CCgbc1.VVZUEz(refCode, chName)
  CCnwAc.VVnSa9(self, refCode, txt, title, path)
class CCgbc1(Screen):
 VVgX8r   = 0
 VV06LZ  = 1
 VV3TYW  = 2
 VVjiWq  = 3
 VVVWK0  = 4
 VVZpLG  = 5
 VV04PS  = 6
 VVKBZA  = 7
 VVt09a = 8
 VVA4xd = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFQUXb(VVcN3H, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFZrGE(self, self.Title)
  FFnxzu(self["keyRed"] , "OK = Zap")
  FFnxzu(self["keyGreen"] , "Current Service")
  FFnxzu(self["keyYellow"], "Page Options")
  FFnxzu(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCgbc1.VVrn8y()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVXy7C    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVLiFF        ,
   "green"   : self.VVpezc       ,
   "yellow"  : self.VVbtAj        ,
   "blue"   : self.VVnpI3        ,
   "menu"   : self.VVa5Ri        ,
   "info"   : self.VV7bsD         ,
   "up"   : self.VV5LtW          ,
   "down"   : self.VVal2h         ,
   "left"   : self.VVFEaV         ,
   "right"   : self.VVivVo         ,
   "pageUp"  : boundFunction(self.VVgTCO, True) ,
   "chanUp"  : boundFunction(self.VVgTCO, True) ,
   "pageDown"  : boundFunction(self.VVgTCO, False) ,
   "chanDown"  : boundFunction(self.VVgTCO, False) ,
   "next"   : self.VVsPQH        ,
   "last"   : self.VVp21r         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  FFjswv(self)
  FFwL0h(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFBV5V(self, boundFunction(self.VVnZeo, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVa5Ri(self):
  if not self.isBusy:
   VVXWOy = []
   VVXWOy.append(("Statistics"           , "VVjhNT"    ))
   VVXWOy.append(VVGV45)
   VVXWOy.append(("Suggest PIcons for Current Channel"     , "VVqhwi"   ))
   VVXWOy.append(("Set to Current Channel (copy file)"     , "VVVBeJ_file"  ))
   VVXWOy.append(("Set to Current Channel (as SymLink)"     , "VVVBeJ_link"  ))
   VVXWOy.append(VVGV45)
   VVXWOy.append(CCgbc1.VVQo0i())
   VVXWOy.append(VVGV45)
   VVXWOy.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVNbCY"  ))
   VVXWOy.append(VVGV45)
   VVXWOy += CCgbc1.VVujPD()
   VVXWOy.append(VVGV45)
   VVXWOy.append(("RCU Keys Help"          , "VVLOXP"    ))
   FFue1q(self, self.VVzScv, title=self.Title, VVXWOy=VVXWOy)
 def VVzScv(self, item=None):
  if item is not None:
   if   item == "VVjhNT"     : self.VVjhNT()
   elif item == "VVqhwi"    : FFBV5V(self, self.VVqhwi, clearMsg=False)
   elif item == "VVVBeJ_file"   : self.VVVBeJ(0)
   elif item == "VVVBeJ_link"   : self.VVVBeJ(1)
   elif item == "VVpvrV_file"  : self.VVpvrV(0)
   elif item == "VVpvrV_link"  : self.VVpvrV(1)
   elif item == "VVhmkP"   : self.VVhmkP()
   elif item == "VV2DYf"  : self.VV2DYf()
   elif item == "VVn8A5"   : self.VVn8A5()
   elif item == "VVNbCY"   : self.VVNbCY()
   elif item == "VVHSXx"   : CCgbc1.VVHSXx(self)
   elif item == "VVjGWw"   : CCgbc1.VVjGWw(self)
   elif item == "findPiconBrokenSymLinks"  : CCgbc1.VV10ew(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCgbc1.VV10ew(self, False)
   elif item == "VVLOXP"      : self.VVLOXP()
 def VVbtAj(self):
  if not self.isBusy:
   VVXWOy = []
   VVXWOy.append(("Go to First PIcon"  , "VVezrh"  ))
   VVXWOy.append(("Go to Last PIcon"   , "VVPUU9"  ))
   VVXWOy.append(VVGV45)
   VVXWOy.append(("Sort by Channel Name"     , "sortByChan" ))
   VVXWOy.append(("Sort by File Name"  , "sortByFile" ))
   VVXWOy.append(VVGV45)
   VVXWOy.append(("Find from File List .." , "VVwVkC" ))
   FFue1q(self, self.VVDcI8, title=self.Title, VVXWOy=VVXWOy)
 def VVDcI8(self, item=None):
  if item is not None:
   if   item == "VVezrh"   : self.VVezrh()
   elif item == "VVPUU9"   : self.VVPUU9()
   elif item == "sortByChan"  : self.VVS5Gl(2)
   elif item == "sortByFile"  : self.VVS5Gl(0)
   elif item == "VVwVkC"  : self.VVwVkC()
 def VVLOXP(self):
  FFifNb(self, VVhwNz + "_help_picons", "PIcons Manager (Keys Help)")
 def VV5LtW(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVPUU9()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVZTBR()
 def VVal2h(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVezrh()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVZTBR()
 def VVFEaV(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVPUU9()
  else:
   self.curCol -= 1
   self.VVZTBR()
 def VVivVo(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVezrh()
  else:
   self.curCol += 1
   self.VVZTBR()
 def VVp21r(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVZTBR(True)
 def VVsPQH(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVZTBR(True)
 def VVezrh(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVZTBR(True)
 def VVPUU9(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVZTBR(True)
 def VVwVkC(self):
  VVXWOy = []
  for item in self.VVXy7C:
   VVXWOy.append((item[0], item[0]))
  FFue1q(self, self.VVqVJX, title='PIcons ".png" Files', VVXWOy=VVXWOy, VVQLeA=True)
 def VVqVJX(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VV0851(ndx)
 def VVLiFF(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVLyzT()
   if refCode:
    FFhRft(self, refCode)
    self.VVoxjR()
    self.VVlKvz()
 def VVgTCO(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVoxjR()
   self.VVlKvz()
  except:
   pass
 def VVpezc(self):
  if self["keyGreen"].getVisible():
   self.VV0851(self.curChanIndex)
 def VV0851(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVZTBR(True)
  else:
   FFtXOm(self, "Not found", 1000)
 def VVS5Gl(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFBV5V(self, boundFunction(self.VVnZeo, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVVBeJ(self, mode):
  title = "Change Current Channel PIcon"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF8KLs(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVLyzT()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVXWOy = []
     VVXWOy.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVXWOy.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFue1q(self, boundFunction(self.VVHkfe, mode, curChF, selPiconF), VVXWOy=VVXWOy, title="Current Channel PIcon (already exists)")
    else:
     self.VVHkfe(mode, curChF, selPiconF, "overwrite")
   else:
    FFEW3v(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFEW3v(self, "Could not read current channel info. !", title=title)
 def VVHkfe(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFBV5V(self, boundFunction(self.VVnZeo, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVpvrV(self, mode):
  pass
 def VVhmkP(self):
  pass
 def VV2DYf(self):
  pass
 def VVn8A5(self):
  pass
 def VVNbCY(self):
  lines = FFUtqa("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFUzhN(self, boundFunction(self.VVedE8, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVBim4=True)
  else:
   FFJjNb(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVedE8(self, fList):
  os.system(FFLcOy("find -L '%s' -type l -delete" % self.pPath))
  FFJjNb(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VV7bsD(self):
  FFBV5V(self, self.VVHpe3)
 def VVHpe3(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVLyzT()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFW8xd("PIcon Directory:\n", VVhJi6)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FF6m1I(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FF6m1I(path)
   txt += FFW8xd("PIcon File:\n", VVhJi6)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFUtqa(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FFW8xd("Found %d SymLink%s to this file from:\n" % (tot, s), VVhJi6)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFi9ZT(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FFW8xd(tChName, VVmHHA)
     else  : tChName = ""
     txt += "  %s%s\n" % (FFW8xd(line, VVqb5h), tChName)
    txt += "\n"
   if chName:
    txt += FFW8xd("Channel:\n", VVhJi6)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFW8xd(chName, VVmHHA)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FFW8xd("Remarks:\n", VVhJi6)
    txt += "  %s\n" % FFW8xd("Unused", VVdNwi)
  else:
   txt = "No info found"
  CCnwAc.VVnSa9(self, refCode, txt, "PIcon Info.", self.pPath + filName)
 def VVLyzT(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVXy7C[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFp5ev(sat)
  return fName, refCode, chName, sat, inDB
 def VVoxjR(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF8KLs(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVXy7C):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVlKvz(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVLyzT()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFW8xd("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVhJi6))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVLyzT()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFW8xd(self.curChanName, VVFlyn)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVjhNT(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VVXy7C:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFHvE5("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFKjl2(self, txt, title=self.Title)
 def VVnpI3(self):
  if not self.isBusy:
   VVXWOy = []
   VVXWOy.append(("All"         , "all"   ))
   VVXWOy.append(VVGV45)
   VVXWOy.append(("Used by Channels"      , "used"  ))
   VVXWOy.append(("Unused PIcons"      , "unused"  ))
   VVXWOy.append(VVGV45)
   VVXWOy.append(("PIcons Files"       , "pFiles"  ))
   VVXWOy.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVXWOy.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVXWOy.append(VVGV45)
   VVXWOy.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVXWOy.append(VVGV45)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFwzNy(val)
      VVXWOy.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCpZgp(self)
   filterObj.VVE0Xt(VVXWOy, self.nsList, self.VVwWQV)
 def VVwWQV(self, item=None):
  if item is not None:
   self.VVyJEy(item)
 def VVyJEy(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVgX8r   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VV06LZ   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VV3TYW  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVjiWq  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVVWK0  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVZpLG  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VV04PS   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVKBZA   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVt09a , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVZpLG:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFUtqa("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFtXOm(self, "Not found", 1000)
     return
   elif mode == self.VVA4xd:
    return
   else:
    words, asPrefix = CCpZgp.VV3cHn(words)
   if not words and mode in (self.VVKBZA, self.VVt09a):
    FFtXOm(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFBV5V(self, boundFunction(self.VVnZeo, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVqhwi(self):
  FFtXOm(self, "Loading Channels ...")
  lameDbChans = CCfCKg.VVdgTw(self, CCfCKg.VVYPJZ, VVAvww=False, VVnWJU=False)
  files = []
  words = []
  if lameDbChans:
   curCh = self.curChanName.lower().replace(" hd", "").replace(" fm", "").replace("4k", "")
   for refCode in lameDbChans:
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCgbc1.VVEnnI(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCgbc1.VVd5bN(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       words.append(f.replace(".png", ""))
  if words:
   FFBV5V(self, boundFunction(self.VVnZeo, mode=self.VVA4xd, words=words), title="Filtering ...", clearMsg=False)
  else:
   FFtXOm(self, "Not found", 1000)
 def VVnZeo(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VV7AS0(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCfCKg.VVdgTw(self, CCfCKg.VVYPJZ, VVAvww=False, VVnWJU=False)
  iptvRefList = self.VVZxht()
  tList = []
  for fName, fType in CCgbc1.VVgeVx(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVgX8r:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VV06LZ  and chName         : isAdd = True
   elif mode == self.VV3TYW and not chName        : isAdd = True
   elif mode == self.VVjiWq  and fType == 0        : isAdd = True
   elif mode == self.VVVWK0  and fType == 1        : isAdd = True
   elif mode == self.VVZpLG  and fName in words       : isAdd = True
   elif mode == self.VVA4xd and fName in words       : isAdd = True
   elif mode == self.VV04PS  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVKBZA  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVt09a:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVXy7C   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFtXOm(self)
  else:
   self.isBusy = False
   FFtXOm(self, "Not found", 1000)
   return
  self.VVXy7C.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVoxjR()
  self.totalPIcons = len(self.VVXy7C)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVZTBR(True)
 def VV7AS0(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCgbc1.VVgeVx(self.pPath):
    if fName:
     return True
   if isFirstTime : FFEW3v(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFtXOm(self, "Not found", 1000)
  else:
   FFEW3v(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVZxht(self):
  VVgBMX = {}
  files  = CCzPop.VVxJII(self)
  if files:
   for path in files:
    txt = FFteHI(path)
    list = iFindall("#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVgBMX[refCode] = item[1]
  return VVgBMX
 def VVZTBR(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVR4JK = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVR4JK: self.curPage = VVR4JK
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVrjVB()
  if self.curPage == VVR4JK:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVlKvz()
  filName, refCode, chName, sat, inDB = self.VVLyzT()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVrjVB(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVXy7C[ndx]
   fName = self.VVXy7C[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FFW8xd(chName, VVmHHA))
    else : lbl.setText("-")
   except:
    lbl.setText(FFW8xd(chName, VVbXIp))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVEnnI(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVQo0i():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VVHSXx"   )
 @staticmethod
 def VVujPD():
  VVXWOy = []
  VVXWOy.append(("Find SymLinks (to PIcon Directory)"   , "VVjGWw"   ))
  VVXWOy.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVXWOy.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVXWOy
 @staticmethod
 def VVHSXx(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF8KLs(SELF)
  png, path = CCgbc1.VVZUEz(refCode)
  if path : CCgbc1.VVlJY9(SELF, png, path)
  else : FFEW3v(SELF, "No PIcon found for current channel in:\n\n%s" % CCgbc1.VVrn8y())
 @staticmethod
 def VVjGWw(SELF):
  if VVFlyn:
   sed1 = FF3Nyd("->", VVFlyn)
   sed2 = FF3Nyd("picon", VVdNwi)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVbXIp, VVI2d4)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFAxIC(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFx6OB(), grep, sed1, sed2, sed3))
 @staticmethod
 def VV10ew(SELF, isPIcon):
  sed1 = FF3Nyd("->", VVbXIp)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FF3Nyd("picon", VVdNwi)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFAxIC(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFx6OB(), grep, sed1, sed2))
 @staticmethod
 def VVgeVx(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVrn8y():
  path = CFG.PIconsPath.getValue()
  return FFTsBZ(path)
 @staticmethod
 def VVZUEz(refCode, chName=None):
  if FFF590(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFwwJ6(refCode)
  allPath, fName, refCodeFile, pList = CCgbc1.VVd5bN(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VVlJY9(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FF3Nyd("%s%s" % (dest, png), VVmHHA))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FF3Nyd(errTxt, VV7KZt))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FF2NFl(SELF, cmd)
 @staticmethod
 def VVd5bN(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCgbc1.VVrn8y()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFOCgm(chName)
    lst = iGlob(allPath + chName + ".png")
    if lst:
     pList += lst
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCHXts():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVWEcc  = None
  self.VV5mRY = ""
  self.VV9TSH  = noService
  self.VVGm7w = 0
  self.VVDv0f  = noService
  self.VVMH6F = 0
  self.VVW2dX  = "-"
  self.VVP2on = 0
  self.VVheI0  = ""
  self.serviceName = ""
 def VVzviJ(self, service):
  if service:
   feinfo = service.frontendInfo()
   if feinfo:
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVWEcc = frontEndStatus
     self.VV1mr0()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VV1mr0(self):
  if self.VVWEcc:
   val = self.VVWEcc.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VV5mRY = "%3.02f dB" % (val / 100.0)
   else         : self.VV5mRY = ""
   val = self.VVWEcc.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVGm7w = int(val)
   self.VV9TSH  = "%d%%" % val
   val = self.VVWEcc.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVMH6F = int(val)
   self.VVDv0f  = "%d%%" % val
   val = self.VVWEcc.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVW2dX  = "%d" % val
   val = int(val * 100 / 500)
   self.VVP2on = min(500, val)
   val = self.VVWEcc.get("tuner_locked", 0)
   if val == 1 : self.VVheI0 = "Locked"
   else  : self.VVheI0 = "Not locked"
 def VV9fkQ(self)   : return self.VV5mRY
 def VV1qhW(self)   : return self.VV9TSH
 def VV09jY(self)  : return self.VVGm7w
 def VV4aWl(self)   : return self.VVDv0f
 def VVo2wR(self)  : return self.VVMH6F
 def VV08bR(self)   : return self.VVW2dX
 def VVeMAs(self)  : return self.VVP2on
 def VVixLW(self)   : return self.VVheI0
 def VVZhsB(self) : return self.serviceName
class CCLFki():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVG8f0(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FF4GcA(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVCQkB(self.ORPOS  , mod=1   )
      self.sat2  = self.VVCQkB(self.ORPOS  , mod=2   )
      self.freq  = self.VVCQkB(self.FREQ  , mod=3   )
      self.sr   = self.VVCQkB(self.SR   , mod=4   )
      self.inv  = self.VVCQkB(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVCQkB(self.POL  , self.D_POL )
      self.fec  = self.VVCQkB(self.FEC  , self.D_FEC )
      self.syst  = self.VVCQkB(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVCQkB("modulation" , self.D_MOD )
       self.rolof = self.VVCQkB("rolloff"  , self.D_ROLOF )
       self.pil = self.VVCQkB("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVCQkB("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVCQkB("pls_code"  )
       self.iStId = self.VVCQkB("is_id"   )
       self.t2PlId = self.VVCQkB("t2mi_plp_id" )
       self.t2PId = self.VVCQkB("t2mi_pid"  )
 def VVCQkB(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFwzNy(val)
  elif mod == 2   : return FFUZWq(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVdUTv(self, refCode):
  txt = ""
  self.VVG8f0(refCode)
  if self.data:
   def VV269Y(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VV269Y("System"   , self.syst)
    txt += VV269Y("Satellite"  , self.sat2)
    txt += VV269Y("Frequency"  , self.freq)
    txt += VV269Y("Inversion"  , self.inv)
    txt += VV269Y("Symbol Rate"  , self.sr)
    txt += VV269Y("Polarization" , self.pol)
    txt += VV269Y("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VV269Y("Modulation" , self.mod)
     txt += VV269Y("Roll-Off" , self.rolof)
     txt += VV269Y("Pilot"  , self.pil)
     txt += VV269Y("Input Stream", self.iStId)
     txt += VV269Y("T2MI PLP ID" , self.t2PlId)
     txt += VV269Y("T2MI PID" , self.t2PId)
     txt += VV269Y("PLS Mode" , self.plsMod)
     txt += VV269Y("PLS Code" , self.plsCod)
   else:
    txt += VV269Y("System"   , self.txMedia)
    txt += VV269Y("Frequency"  , self.freq)
  return txt, self.namespace
 def VVxp9E(self, refCode):
  txt = "Transpoder : ?"
  self.VVG8f0(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVhJi6 + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVDV7b(self, refCode):
  self.data = None
  servRef = eServiceReference(refCode)
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FF4GcA(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVCQkB(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVCQkB(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVCQkB(self.SYST, self.D_SYS_S)
     freq = self.VVCQkB(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVCQkB(self.POL , self.D_POL)
      fec = self.VVCQkB(self.FEC , self.D_FEC)
      sr = self.VVCQkB(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVWX7a(self, refCode):
  self.data = None
  self.VVG8f0(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCRFRx():
 def __init__(self, VV87hH, path, VV7s75=None):
  self.VV87hH  = VV87hH
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VV7s75  = VV7s75
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.insertMode   = 0
  response = os.system(FFLcOy("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VV8jSg()
  else:
   FFEW3v(self.VV87hH, "Error while preparing edit!")
 def VV8jSg(self):
  VVgBMX = self.VVIwTT()
  VVFZEv = None #("Delete Line" , self.deleteLine  , [])
  VVUhO3 = ("Save Changes" , self.VVRQoP   , [])
  VVcgcO  = ("Edit Line"  , self.VVzxXK    , [])
  VVeqJy = ("Line Options" , self.VVVrNw   , [])
  VVVt4G = (""    , self.VVhQLa , [])
  VVWZbv = self.VV4V7e
  VV2jer  = self.VVNGYU
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVqjzl  = (CENTER  , LEFT  )
  FFZUAl(self.VV87hH, None, title=self.Title, header=header, VVXy7C=VVgBMX, VVqjzl=VVqjzl, VV08hy=widths, VVH2Qb=24, VVFZEv=VVFZEv, VVUhO3=VVUhO3, VVcgcO=VVcgcO, VVeqJy=VVeqJy, VVWZbv=VVWZbv, VV2jer=VV2jer, VVVt4G=VVVt4G, VVxpps=True
    , VVrgKF   = "#11001111"
    , VVr4tL   = "#11001111"
    , VVnGDQ   = "#11001111"
    , VVli9s  = "#05333333"
    , VV9S0H  = "#00222222"
    , VVBowS  = "#11331133"
    )
 def VVVrNw(self, VVShs0, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVShs0.VVHM5I()
  VVXWOy = []
  VVXWOy.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVXWOy.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVPHzU"  ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVnRzV:
   VVXWOy.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(  ("Delete Line"         , "deleteLine"   ))
  FFue1q(self.VV87hH, boundFunction(self.VVtal7, VVShs0, lineNum), VVXWOy=VVXWOy, title="Line Options")
 def VVtal7(self, VVShs0, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVzzYO("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVShs0)
   elif item == "VVPHzU"  : self.VVPHzU(VVShs0, lineNum)
   elif item == "copyToClipboard"  : self.VVQg0I(VVShs0, lineNum)
   elif item == "pasteFromClipboard" : self.VVLy10(VVShs0, lineNum)
   elif item == "deleteLine"   : self.VVzzYO("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVShs0)
 def VVNGYU(self, VVShs0):
  VVShs0.VV2OZh()
 def VVhQLa(self, VVShs0, title, txt, colList):
  if   self.insertMode == 1: VVShs0.VV8ILm()
  elif self.insertMode == 2: VVShs0.VVSnhc()
  self.insertMode = 0
 def VVPHzU(self, VVShs0, lineNum):
  if lineNum == VVShs0.VVHM5I():
   self.insertMode = 1
   self.VVzzYO("echo '' >> '%s'" % self.tmpFile, VVShs0)
  else:
   self.insertMode = 2
   self.VVzzYO("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVShs0)
 def VVQg0I(self, VVShs0, lineNum):
  global VVnRzV
  VVnRzV = FFHvE5("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVShs0.VVczAi("Copied to clipboard")
 def VVRQoP(self, VVShs0, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFLcOy("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFLcOy("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVShs0.VVczAi("Saved")
     self.fileChanged = False
     VVShs0.VV2OZh()
    else:
     FFEW3v(self.VV87hH, "Cannot save file!")
   else:
    FFEW3v(self.VV87hH, "Cannot create backup copy of original file!")
 def VV4V7e(self, VVShs0):
  if self.fileChanged:
   FFUzhN(self.VV87hH, boundFunction(self.VVinIW, VVShs0), "Cancel changes ?")
  else:
   finalOK = os.system(FFLcOy("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVinIW(VVShs0)
 def VVinIW(self, VVShs0):
  VVShs0.cancel()
  os.system(FFLcOy("rm -f '%s'" % self.tmpFile))
  if self.VV7s75:
   self.VV7s75()
 def VVzxXK(self, VVShs0, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVI2d4 + "ORIGINAL TEXT:\n" + VVqb5h + lineTxt
  FFiVZt(self.VV87hH, boundFunction(self.VVhoxi, lineNum, VVShs0), title="File Line", defaultText=lineTxt, message=message)
 def VVhoxi(self, lineNum, VVShs0, VV47ip):
  if not VV47ip is None:
   if VVShs0.VVHM5I() <= 1:
    self.VVzzYO("echo %s > '%s'" % (VV47ip, self.tmpFile), VVShs0)
   else:
    self.VVherU(VVShs0, lineNum, VV47ip)
 def VVLy10(self, VVShs0, lineNum):
  if lineNum == VVShs0.VVHM5I() and VVShs0.VVHM5I() == 1:
   self.VVzzYO("echo %s >> '%s'" % (VVnRzV, self.tmpFile), VVShs0)
  else:
   self.VVherU(VVShs0, lineNum, VVnRzV)
 def VVherU(self, VVShs0, lineNum, newTxt):
  VVShs0.VVKDDX("Saving ...")
  lines = FFUM2c(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVShs0.VVI0CR()
  VVgBMX = self.VVIwTT()
  VVShs0.VVrhOZ(VVgBMX)
 def VVzzYO(self, cmd, VVShs0):
  tCons = CCLvxk()
  tCons.ePopen(cmd, boundFunction(self.VVpoeX, VVShs0))
  self.fileChanged = True
  VVShs0.VVI0CR()
 def VVpoeX(self, VVShs0, result, retval):
  VVgBMX = self.VVIwTT()
  VVShs0.VVrhOZ(VVgBMX)
 def VVIwTT(self):
  if fileExists(self.tmpFile):
   lines = FFUM2c(self.tmpFile)
   VVgBMX = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVgBMX.append((str(ndx), line.strip()))
   if not VVgBMX:
    VVgBMX.append((str(1), ""))
   return VVgBMX
  else:
   FFV5mI(self.VV87hH, self.tmpFile)
class CCpZgp():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVXWOy   = []
  self.satList   = []
 def VVwJPM(self, VV7s75):
  self.VVXWOy = []
  VVXWOy, VVqXY8 = self.VVzuLm(False, True)
  if VVXWOy:
   self.VVXWOy += VVXWOy
   self.VV7rKx(VV7s75, VVqXY8)
 def VVUUrd(self, mode, VVShs0, satCol, VV7s75):
  VVShs0.VVKDDX("Loading Filters ...")
  self.VVXWOy = []
  self.VVXWOy.append(("All Services" , "all"))
  if mode == 1:
   self.VVXWOy.append(VVGV45)
   self.VVXWOy.append(("Parental Control", "parentalControl"))
   self.VVXWOy.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVXWOy.append(VVGV45)
   self.VVXWOy.append(("Selected Transponder"   , "selectedTP" ))
   self.VVXWOy.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVVpmj(VVShs0, satCol)
  VVXWOy, VVqXY8 = self.VVzuLm(True, False)
  if VVXWOy:
   VVXWOy.insert(0, VVGV45)
   self.VVXWOy += VVXWOy
  VVShs0.VVGqtm()
  self.VV7rKx(VV7s75, VVqXY8)
 def VVE0Xt(self, VVXWOy, sats, VV7s75):
  self.VVXWOy = VVXWOy
  VVXWOy, VVqXY8 = self.VVzuLm(True, False)
  if VVXWOy:
   self.VVXWOy.append(VVGV45)
   self.VVXWOy += VVXWOy
  self.VV7rKx(VV7s75, VVqXY8)
 def VVht5m(self, VVXWOy, sats, VV7s75):
  self.VVXWOy = VVXWOy
  VVXWOy, VVqXY8 = self.VVzuLm(True, False)
  if VVXWOy:
   self.VVXWOy.append(VVGV45)
   self.VVXWOy += VVXWOy
  self.VV7rKx(VV7s75, VVqXY8)
 def VV7rKx(self, VV7s75, VVqXY8):
  VV2cC5 = ("Edit Filter", boundFunction(self.VVOsWq, VVqXY8))
  VVpjth  = ("Filter Help", boundFunction(self.VVntzi, VVqXY8))
  FFue1q(self.callingSELF, boundFunction(self.VVgyIf, VV7s75), VVXWOy=self.VVXWOy, title="Select Filter", VV2cC5=VV2cC5, VVpjth=VVpjth)
 def VVgyIf(self, VV7s75, item):
  if item:
   VV7s75(item)
 def VVOsWq(self, VVqXY8, VVz4aFObj, sel):
  if fileExists(VVqXY8) : CCRFRx(self.callingSELF, VVqXY8, VV7s75=None)
  else       : FFV5mI(self.callingSELF, VVqXY8)
  VVz4aFObj.cancel()
 def VVntzi(self, VVqXY8, VVz4aFObj, sel):
  FFifNb(self.callingSELF, VVhwNz + "_help_service_filter", "Service Filter")
 def VVVpmj(self, VVShs0, satColNum):
  if not self.satList:
   satList = VVShs0.VVmRKN(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFp5ev(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVGV45)
  if self.VVXWOy:
   self.VVXWOy += self.satList
 def VVzuLm(self, addTag, showErr):
  FFnlPn()
  fileName  = "ajpanel_services_filter"
  VVqXY8 = VVoi8H + fileName
  VVXWOy  = []
  if not fileExists(VVqXY8):
   os.system(FFLcOy("cp -f '%s' '%s'" % (VVhwNz + fileName, VVqXY8)))
  fileFound = False
  if fileExists(VVqXY8):
   fileFound = True
   lines = FFUM2c(VVqXY8)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVXWOy.append((line, "__w__" + line))
       else  : VVXWOy.append((line, line))
  if showErr:
   if   not fileFound : FFV5mI(self.callingSELF , VVqXY8)
   elif not VVXWOy : FFqWYJ(self.callingSELF , VVqXY8)
  return VVXWOy, VVqXY8
 @staticmethod
 def VV3cHn(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CCsg5m():
 def __init__(self, callingSELF, VVShs0, refCodeColNum):
  self.callingSELF = callingSELF
  self.VVShs0 = VVShs0
  self.refCodeColNum = refCodeColNum
  self.VVXWOy = []
  iMulSel = self.VVShs0.VVrFw7()
  if iMulSel : self.VVXWOy.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVXWOy.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVShs0.VV0Gy1()
  self.VVXWOy.append(    ("Select all"    , "selectAll"  ))
  if tot > 0:
   self.VVXWOy.append(   ("Unselect all"    , "unselectAll"  ))
  self.VVXWOy.append(VVGV45)
 def VVVkt5(self, servName, refCode):
  tot = self.VVShs0.VV0Gy1()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVXWOy.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VV3eZL_multi" ))
  else    : self.VVXWOy.append( ("Add to Bouquet : %s"      % servName , "VV3eZL_one" ))
  self.VVnEdO(servName, refCode)
 def VV4Wtv(self, servName, refCode, pcState, hidState):
  self.VVXWOy = []
  if pcState == "No" : self.VVXWOy.append(("Add to Parental Control"  , "parentalControl_add"  ))
  else    : self.VVXWOy.append(("Remove from Parental Control" , "parentalControl_remove" ))
  if hidState == "No" : self.VVXWOy.append(("Add to Hidden Services"  , "hiddenServices_add"  ))
  else    : self.VVXWOy.append(("Remove from Hidden Services" , "hiddenServices_remove" ))
  self.VVnEdO(servName, refCode)
 def VVnEdO(self, servName, refCode):
  FFue1q(self.callingSELF, boundFunction(self.VVTFvk, servName, refCode), title="Options", VVXWOy=self.VVXWOy)
 def VVTFvk(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"    : self.VVShs0.VVkDua(True)
   elif item == "MultSelDisab"    : self.VVShs0.VVkDua(False)
   elif item == "selectAll"    : self.VVShs0.VVFo0v()
   elif item == "unselectAll"    : self.VVShs0.VVDrD1()
   elif item == "parentalControl_add"  : self.callingSELF.VV5oSw(self.VVShs0, refCode, True)
   elif item == "parentalControl_remove" : self.callingSELF.VV5oSw(self.VVShs0, refCode, False)
   elif item == "hiddenServices_add"  : self.callingSELF.VVw7PP(self.VVShs0, refCode, True)
   elif item == "hiddenServices_remove" : self.callingSELF.VVw7PP(self.VVShs0, refCode, False)
   elif item == "VV3eZL_multi" : self.VV3eZL(refCode, True)
   elif item == "VV3eZL_one" : self.VV3eZL(refCode, False)
 def VV3eZL(self, refCode, isMulti):
  bouquets = FFqGJf()
  if bouquets:
   VVXWOy = []
   for item in bouquets:
    VVXWOy.append((item[0], item[1].toString()))
   VV2cC5 = ("Create New", boundFunction(self.VVm4zC, refCode, isMulti))
   FFue1q(self.callingSELF, boundFunction(self.VVKp52, refCode, isMulti), VVXWOy=VVXWOy, title="Add to Bouquet", VV2cC5=VV2cC5, VVQLeA=True, VVIgE2=True)
  else:
   FFUzhN(self.callingSELF, boundFunction(self.VVQHOc, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVKp52(self, refCode, isMulti, bName=None):
  if bName:
   FFBV5V(self.VVShs0, boundFunction(self.VVF1Vf, refCode, isMulti, bName), title="Adding Channels ...")
 def VVF1Vf(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VV2ode(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVDbSW = InfoBar.instance
    if VVDbSW:
     VVDkKf = VVDbSW.servicelist
     if VVDkKf:
      mutableList = VVDkKf.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVShs0.VVGqtm()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFJjNb(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFEW3v(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VV2ode(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVShs0.VVixYY(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVm4zC(self, refCode, isMulti, VVz4aFObj, path):
  self.VVQHOc(refCode, isMulti)
 def VVQHOc(self, refCode, isMulti):
  FFiVZt(self.callingSELF, boundFunction(self.VVjnEB, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVjnEB(self, refCode, isMulti, name):
  if name:
   FFBV5V(self.VVShs0, boundFunction(self.VV6vL1, refCode, isMulti, name), title="Adding Channels ...")
 def VV6vL1(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VV2ode(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVDbSW = InfoBar.instance
    if VVDbSW:
     VVDkKf = VVDbSW.servicelist
     if VVDkKf:
      try:
       VVDkKf.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVDkKf.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVShs0.VVGqtm()
   title = "Add to Bouquet"
   if allOK: FFJjNb(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFEW3v(self.callingSELF, "Nothing added!", title=title)
class CCSXBa(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFQUXb(VV8LqE, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFZrGE(self)
  FFnxzu(self["keyRed"]  , "Exit")
  FFnxzu(self["keyGreen"]  , "Save")
  FFnxzu(self["keyYellow"] , "Refresh")
  FFnxzu(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVwZob  ,
   "green"   : self.VVsODo ,
   "yellow"  : self.VVNaRL  ,
   "blue"   : self.VVE5RC   ,
   "up"   : self.VV5LtW    ,
   "down"   : self.VVal2h   ,
   "left"   : self.VVFEaV   ,
   "right"   : self.VVivVo   ,
   "cancel"  : self.VVwZob
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VVNaRL()
  self.VVqNby()
  FFjswv(self)
 def VVwZob(self) : self.close(True)
 def VV35L8(self) : self.close(False)
 def VVE5RC(self):
  self.session.openWithCallback(self.VVxY29, boundFunction(CCVbSU))
 def VVxY29(self, closeAll):
  if closeAll:
   self.close()
 def VV5LtW(self):
  self.VVVbSO(1)
 def VVal2h(self):
  self.VVVbSO(-1)
 def VVFEaV(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVqNby()
 def VVivVo(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVqNby()
 def VVVbSO(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VV5TeY(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VV5TeY(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VV5TeY(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVPCci(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVPCci(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVqNby(self):
  for obj in self.list:
   FFwL0h(obj, "#11404040")
  FFwL0h(self.list[self.index], "#11ff8000")
 def VVNaRL(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVsODo(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCLvxk()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVS9Zk)
 def VVS9Zk(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFJjNb(self, "Nothing returned from the system!")
  else:
   FFJjNb(self, str(result))
class CCVbSU(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFQUXb(VVnLZX, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFZrGE(self, addLabel=True)
  FFnxzu(self["keyRed"]  , "Exit")
  FFnxzu(self["keyGreen"]  , "Sync")
  FFnxzu(self["keyYellow"] , "Refresh")
  FFnxzu(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVwZob   ,
   "green"   : self.VVHe2Z  ,
   "yellow"  : self.VVOZut ,
   "blue"   : self.VVQX2m  ,
   "cancel"  : self.VVwZob
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VV86zt()
  self.onShow.append(self.start)
 def start(self):
  FF1XIo(self.refresh)
  FFjswv(self)
 def refresh(self):
  self.VVnxfu()
  self.VVCKwJ(False)
 def VVwZob(self)  : self.close(True)
 def VVQX2m(self) : self.close(False)
 def VV86zt(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVnxfu(self):
  self.VVTLbK()
  self.VV4drd()
  self.VVwW9o()
  self.VVX0RR()
 def VVOZut(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VV86zt()
   self.VVnxfu()
   FF1XIo(self.refresh)
 def VVHe2Z(self):
  if len(self["keyGreen"].getText()) > 0:
   FFUzhN(self, self.VVm5g3, "Synchronize with Internet Date/Time ?")
 def VVm5g3(self):
  self.VVnxfu()
  FF1XIo(boundFunction(self.VVCKwJ, True))
 def VVTLbK(self)  : self["keyRed"].show()
 def VVxVtF(self)  : self["keyGreen"].show()
 def VV7M2s(self) : self["keyYellow"].show()
 def VV2W61(self)  : self["keyBlue"].show()
 def VV4drd(self)  : self["keyGreen"].hide()
 def VVwW9o(self) : self["keyYellow"].hide()
 def VVX0RR(self)  : self["keyBlue"].hide()
 def VVCKwJ(self, sync):
  localTime = FFEhBS()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVSTzz(server)
   if epoch_time is not None:
    ntpTime = FFnWMY(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCLvxk()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVS9Zk, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VV7M2s()
  self.VV2W61()
  if ok:
   self.VVxVtF()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVS9Zk(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVCKwJ(False)
  except:
   pass
 def VVSTzz(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FF2qeK():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCpFbI(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFQUXb(VVOwis, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFZrGE(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  FF1XIo(self.VV9csQ)
 def VV9csQ(self):
  if FF2qeK(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFwL0h(self["myBody"], color)
   FFwL0h(self["myLabel"], color)
  except:
   pass
class CC4Jdh(Screen):
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFV7UG()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFQUXb(VVkfbA, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCBEhl(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCBEhl(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCBEhl(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCHXts()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFZrGE(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VV5LtW          ,
   "down"  : self.VVal2h         ,
   "left"  : self.VVFEaV         ,
   "right"  : self.VVivVo         ,
   "info"  : self.VVVH9g        ,
   "epg"  : self.VVVH9g        ,
   "menu"  : self.VVLOXP         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "last"  : boundFunction(self.VV1sPw, -1)  ,
   "next"  : boundFunction(self.VV1sPw, 1)  ,
   "pageUp" : boundFunction(self.VV2buB, True) ,
   "chanUp" : boundFunction(self.VV2buB, True) ,
   "pageDown" : boundFunction(self.VV2buB, False) ,
   "chanDown" : boundFunction(self.VV2buB, False) ,
   "0"   : boundFunction(self.VV1sPw, 0)  ,
   "1"   : boundFunction(self.VVUAR3, pos=1) ,
   "2"   : boundFunction(self.VVUAR3, pos=2) ,
   "3"   : boundFunction(self.VVUAR3, pos=3) ,
   "4"   : boundFunction(self.VVUAR3, pos=4) ,
   "5"   : boundFunction(self.VVUAR3, pos=5) ,
   "6"   : boundFunction(self.VVUAR3, pos=6) ,
   "7"   : boundFunction(self.VVUAR3, pos=7) ,
   "8"   : boundFunction(self.VVUAR3, pos=8) ,
   "9"   : boundFunction(self.VVUAR3, pos=9) ,
  }, -1)
  self.onShown.append(self.VVqv5b)
  self.onClose.append(self.onExit)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  self.sliderSNR.VV1J0l()
  self.sliderAGC.VV1J0l()
  self.sliderBER.VV1J0l(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVUAR3()
  self.VVNbLBInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVNbLB)
  except:
   self.timer.callback.append(self.VVNbLB)
  self.timer.start(500, False)
 def VVNbLBInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVzviJ(service)
  serviceName = self.tunerInfo.VVZhsB()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF8KLs(self)
  tp = CCLFki()
  txt = tp.VVxp9E(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVNbLB(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVzviJ(service)
  self["mySNRdB"].setText(self.tunerInfo.VV9fkQ())
  self["mySNR"].setText(self.tunerInfo.VV1qhW())
  self["myAGC"].setText(self.tunerInfo.VV4aWl())
  self["myBER"].setText(self.tunerInfo.VV08bR())
  self.sliderSNR.VVwM78(self.tunerInfo.VV09jY())
  self.sliderAGC.VVwM78(self.tunerInfo.VVo2wR())
  self.sliderBER.VVwM78(self.tunerInfo.VVeMAs())
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF8KLs(self)
    if state and not state == "Tuned":
     FFtXOm(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVVH9g(self):
  self.session.open(CCnwAc)
 def VVLOXP(self):
  FFifNb(self, VVhwNz + "_help_signal", "Signal Monitor (Keys)")
 def VV5LtW(self)  : self.VVUAR3(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVal2h(self) : self.VVUAR3(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVFEaV(self) : self.VVUAR3(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVivVo(self) : self.VVUAR3(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVUAR3(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VV1sPw(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFUMrv(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VV2buB(self, isUp):
  FFtXOm(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVNbLBInfo()
  except:
   pass
class CCBEhl(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VV1J0l(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFwL0h(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVhwNz +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFwL0h(self.covObj, self.covColor)
   else:
    FFwL0h(self.covObj, "#00006688")
    self.isColormode = True
  self.VVwM78(0)
 def VVwM78(self, val):
  val  = FFUMrv(val, self.minN, self.maxN)
  width = int(FFufQ4(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFUMrv(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCLrtT(Screen):
 def __init__(self, session, iptvTableInstance, VVShs0, piconMode=CCzPop.VVlm6j):
  self.skin, self.skinParam = FFQUXb(VV2Nqk, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30)
  self.session    = session
  self.iptvTableInstance  = iptvTableInstance
  self.VVShs0   = VVShs0
  self.piconMode    = piconMode
  self.isCancelled   = False
  self.curValue    = 0
  self.maxValue    = VVShs0.VVUSpe()
  self.barWidth    = 0
  self.barHeight    = 0
  self.totRows    = 0
  self.totNoUrl    = 0
  self.totExists    = 0
  self.totDownload_attempt = 0
  self.totDownload_success = 0
  self.totDownload_failed  = 0
  self.totIncorrect_size  = 0
  self.pPath     = CCgbc1.VVrn8y()
  self.ResultTxt    = ""
  self.VVnGDQ    = None
  self.timer     = eTimer()
  self.myThread    = None
  FFZrGE(self, title="Downloading PIcons ...")
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVqv5b)
  self.onClose.append(self.onExit)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  if not pathExists(self.pPath):
   FFEW3v(self, "PIcons path not found.\n\n%s" % self.pPath)
   self.close()
  FFwL0h(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVAd3H()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVAd3H)
  except:
   self.timer.callback.append(self.VVAd3H)
  self.timer.start(300, False)
  from threading import Thread as iThread
  self.myThread = iThread(name="download_PIcons", target=self.VVZ40c)
  self.myThread.start()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  FFtXOm(self, "Cancelling ...")
  self.isCancelled = True
 def VVAd3H(self):
  val  = self.totRows
  val  = FFUMrv(self.totRows, 0, self.maxValue)
  width = int(FFufQ4(val, 0, self.maxValue, 0, self.barWidth))
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
  self["myTitle"].setText("  Downloading PIcons ( %d of %d) ..." % (val, self.maxValue))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   FFKjl2(self, self.ResultTxt, title="PIcons Download Result", VVnGDQ=self.VVnGDQ)
   self.close()
 def VVZ40c(self):
  err = ""
  for row in self.VVShs0.VVtK2v():
   if self.isCancelled:
    break
   self.totRows += 1
   chName, chUrl, picUrl, refCode = self.iptvTableInstance.VVTKO7(self.piconMode, row)
   if picUrl:
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    if not fileExists(self.pPath + picon):
     self.totDownload_attempt += 1
     path, err = FF0NYM(picUrl, picon, timeout=1)
     if path:
      self.totDownload_success += 1
      if FFQzAx(path) > 0:
       cmd = ""
       if not self.piconMode == CCzPop.VVlm6j:
        cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
       cmd += FFLcOy("mv -f '%s' '%s'" % (path, self.pPath)) + ";"
       os.system(cmd)
      else:
       self.totIncorrect_size += 1
       os.system(FFLcOy("rm -f '%s'" % path))
     elif err:
      self.totDownload_failed += 1
      err = err.lower()
      if "time-out" in err or "unauthorized" in err:
       break
    else:
     self.totExists += 1
   else:
    self.totNoUrl += 1
  txt  = ""
  if err:
   txt += err + "\n\n"
   self.VVnGDQ = "#22200000"
  txt += "Total Processed\t\t: %d of %d\n" % (self.totRows, self.maxValue)
  txt += "Download Success\t: %d of %s\n"  % (self.totDownload_success, self.totDownload_attempt)
  txt += "Skipped (PIcon exist)\t: %d\n"  % self.totExists
  txt += "Skipped (Size = 0)\t: %d\n"   % self.totIncorrect_size
  txt += "Incorrect PIcon URL\t: %d\n"  % self.totNoUrl
  txt += "PIcons Path\t\t: %s\n"    % self.pPath
  self.ResultTxt = txt
class CCLvxk(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VV7s75 = {}
  self.commandRunning = False
  self.VVFOlr  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VV7s75, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VV7s75[name] = VV7s75
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVFOlr:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VV3Iuh, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVpisk , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VV3Iuh, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVpisk , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVpisk(name, retval)
  return True
 def VV3Iuh(self, name, data):
  data = data.decode('UTF-8')
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVpisk(self, name, retval):
  if not self.VVFOlr:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VV7s75[name]:
   self.VV7s75[name](self.appResults[name], retval)
  del self.VV7s75[name]
 def VVVzjs(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCfXPk(Screen):
 def __init__(self, session, title="", VVZwQE=None, VVUE41=False, VVVMmG=False, VVub9W=False, VV1gNq=False, VVvUA4=False, VV68JP=False, VVTBXk=VVhDR4, VVngoh=None, VVhXLe=False, VVFswX=None, VVegm6="", checkNetAccess=False, enableSaveRes=False):
  self.skin, self.skinParam = FFQUXb(VVV8lu, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFZrGE(self, addScrollLabel=True)
  if not VVegm6:
   VVegm6 = "Processing ..."
  self["myLabel"].setText("   %s" % VVegm6)
  self.VVUE41   = VVUE41
  self.VVVMmG   = VVVMmG
  self.VVub9W   = VVub9W
  self.VV1gNq  = VV1gNq
  self.VVvUA4 = VVvUA4
  self.VV68JP = VV68JP
  self.VVTBXk   = VVTBXk
  self.VVngoh = VVngoh
  self.VVhXLe  = VVhXLe
  self.VVFswX  = VVFswX
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCLvxk()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFSb2Q()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVZwQE, str):
   self.VVZwQE = [VVZwQE]
  else:
   self.VVZwQE = VVZwQE
  if self.VVub9W or self.VV1gNq:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVklh1, VVklh1)
   self.VVZwQE.append("echo -e '\n%s\n' %s" % (restartNote, FF3Nyd(restartNote, VVFlyn)))
   if self.VVub9W:
    self.VVZwQE.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVZwQE.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVvUA4:
   FFtXOm(self, "Processing ...")
  self.onLayoutFinish.append(self.VVxlzC)
  self.onClose.append(self.VVCBsA)
 def VVxlzC(self):
  self["myLabel"].VV0fFU(enableSave=self.enableSaveRes)
  if self.VVUE41:
   self["myLabel"].VV0W5a()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVFPCY()
  else:
   self.VVc4Zu()
 def VVFPCY(self):
  if FF2qeK():
   self["myLabel"].setText("Processing ...")
   self.VVc4Zu()
  else:
   self["myLabel"].setText(FFW8xd("\n   No connection to internet!", VVdNwi))
 def VVc4Zu(self):
  allOK = self.container.ePopen(self.VVZwQE[0], self.VVIfTl, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVIfTl("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VV68JP or self.VVub9W or self.VV1gNq:
    self["myLabel"].setText(FFyty0("STARTED", VVFlyn) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVFswX:
   colorWhite = CCKdGY.VVlMXG(VVI2d4)
   color  = CCKdGY.VVlMXG(self.VVFswX[0])
   words  = self.VVFswX[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVTBXk=self.VVTBXk)
 def VVIfTl(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVZwQE):
   allOK = self.container.ePopen(self.VVZwQE[self.cmdNum], self.VVIfTl, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVIfTl("Cannot connect to Console!", -1)
  else:
   if self.VVvUA4 and FFulRq(self):
    FFtXOm(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VV68JP:
    self["myLabel"].appendText("\n" + FFyty0("FINISHED", VVFlyn), self.VVTBXk)
   if self.VVUE41 or self.VVVMmG:
    self["myLabel"].VV0W5a()
   if self.VVngoh is not None:
    self.VVngoh()
   if not retval and self.VVhXLe:
    self.VVCBsA()
 def VVCBsA(self):
  if self.container.VVVzjs():
   self.container.killAll()
class CCs1DY(Screen):
 def __init__(self, session, VVZwQE=None, VVvUA4=False):
  self.skin, self.skinParam = FFQUXb(VVV8lu, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVoi8H + "ajpanel_terminal.history"
  self.customCommandsFile = VVoi8H + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFHvE5("pwd") or "/home/root"
  self.container   = CCLvxk()
  FFZrGE(self, addScrollLabel=True)
  FFnxzu(self["keyRed"] , "Stop Command")
  FFnxzu(self["keyGreen"] , "OK = History")
  FFnxzu(self["keyYellow"], "Menu = Custom Cmds")
  FFnxzu(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVCEVR ,
   "red"  : self.VVqGtE   ,
   "cancel" : self.VVJ8Xv   ,
   "menu"  : self.VV5134 ,
   "last"  : self.VVS9hB  ,
   "next"  : self.VVS9hB  ,
   "1"   : self.VVS9hB  ,
   "2"   : self.VVS9hB  ,
   "3"   : self.VVS9hB  ,
   "4"   : self.VVS9hB  ,
   "5"   : self.VVS9hB  ,
   "6"   : self.VVS9hB  ,
   "7"   : self.VVS9hB  ,
   "8"   : self.VVS9hB  ,
   "9"   : self.VVS9hB  ,
   "0"   : self.VVS9hB
  })
  self.onLayoutFinish.append(self.VVqv5b)
  self.onClose.append(self.VVqGtE)
 def VVqv5b(self):
  self["myLabel"].VV0fFU(isResizable=False)
  FFwL0h(self["keyGreen"]  , self.skinParam["titleColor"])
  FFwL0h(self["keyYellow"] , self.skinParam["titleColor"])
  FFwL0h(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVMwBk(FFHvE5("date"), 5)
  result = FFHvE5("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVzBgR()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVhwNz + "LinuxCommands.lst"
   newTemplate = VVhwNz + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFLcOy("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFLcOy("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVqGtE(self):
  if self.container.VVVzjs():
   self.container.killAll()
   self.VVMwBk("Process killed\n", 4)
   self.VVzBgR()
 def VVJ8Xv(self):
  if self.container.VVVzjs():
   FFUzhN(self, self.close, "Terminate command and exit ?")
  else:
   self.close()
 def VVzBgR(self):
  self.VVMwBk(self.prompt, 1)
  self["keyRed"].hide()
 def VVMwBk(self, txt, mode):
  if   mode == 1 : color = VVFlyn
  elif mode == 2 : color = VVhJi6
  elif mode == 3 : color = VVI2d4
  elif mode == 4 : color = VVdNwi
  elif mode == 5 : color = VVqb5h
  elif mode == 6 : color = VVYh3b
  else   : color = VVI2d4
  try:
   self["myLabel"].appendText(FFW8xd(txt, color))
  except:
   pass
 def VVU2VU(self, cmd):
  self["keyRed"].show()
  cmd = cmd.strip()
  if "#" in cmd:
   parts = cmd.split("#")
   left  = FFW8xd(parts[0].strip(), VVhJi6)
   right = FFW8xd("#" + parts[1].strip(), VVYh3b)
   txt = "%s    %s\n" % (left, right)
  else:
   txt = "%s\n" % cmd
  self.VVMwBk(txt, 2)
  lastLine = self.VVM5By()
  if not lastLine or not cmd == lastLine:
   self.lastCommand = cmd
   self.VV7uK2(cmd)
  span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
  if span:
   self.curDir = span.group(1)
  allOK = self.container.ePopen(cmd, self.VVIfTl, dataAvailFnc=self.dataAvail, curDir=self.curDir)
  if not allOK:
   FFEW3v(self, "Cannot connect to Console!")
  self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVMwBk(data, 3)
 def VVIfTl(self, data, retval):
  if not retval == 0:
   self.VVMwBk("Exit Code : %d\n" % retval, 4)
  self.VVzBgR()
 def VVCEVR(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVM5By() == "":
   self.VV7uK2("cd /tmp")
   self.VV7uK2("ls")
  VVgBMX = []
  if fileExists(self.commandHistoryFile):
   lines  = FFUM2c(self.commandHistoryFile)
   c = 0
   for line in reversed(lines):
    line = line.strip()
    if line and not line.startswith("#"):
     c += 1
     VVgBMX.append((str(c), line))
   self.VVJSYX(VVgBMX, title, self.commandHistoryFile, isHistory=True)
  else:
   FFV5mI(self, self.commandHistoryFile, title=title)
 def VVM5By(self):
  lastLine = FFHvE5("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VV7uK2(self, cmd):
  os.system("echo '%s' >> %s" % (cmd, self.commandHistoryFile))
 def VV5134(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFUM2c(self.customCommandsFile)
   lastLineIsSep = False
   VVgBMX = []
   c = 0
   for line in lines:
    line = line.strip()
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVgBMX.append((str(c), line))
   self.VVJSYX(VVgBMX, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFV5mI(self, self.customCommandsFile, title=title)
 def VVJSYX(self, VVgBMX, title, filePath=None, isHistory=False):
  if VVgBMX:
   VVli9s = "#05333333"
   if isHistory: VVrgKF = VVr4tL = VVnGDQ = "#11000020"
   else  : VVrgKF = VVr4tL = VVnGDQ = "#06002020"
   VVcgcO     = ("Send"   , self.VV5S2T  , [])
   VV6mer    = ("Modify & Send" , self.VVgjEd  , [])
   if filePath : VVeqJy = ("Edit File"  , self.VVI1ci , [filePath])
   else  : VVeqJy = None
   header      = ("No."  , "Commands")
   widths      = (7   , 93   )
   VVqjzl     = (CENTER  , LEFT   )
   FFZUAl(self, None, title=title, header=header, VVXy7C=VVgBMX, VVqjzl=VVqjzl, VV08hy=widths, VVH2Qb=22, VVcgcO=VVcgcO, VV6mer=VV6mer, VVeqJy=VVeqJy, VVxpps=True
     , VVrgKF   = VVrgKF
     , VVr4tL   = VVr4tL
     , VVnGDQ   = VVnGDQ
     , VVhDXP  = "#05ffff00"
     , VVli9s  = VVli9s
    )
  else:
   FFqWYJ(self, filePath, title=title)
 def VV5S2T(self, VVShs0, title, txt, colList):
  cmd = colList[1].strip()
  VVShs0.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VVMwBk("\n%s\n" % cmd, 6)
   self.VVMwBk(self.prompt, 1)
  else:
   if cmd.startswith("passwd"):
    self.VVMwBk(cmd, 2)
    self.VVMwBk("\nCannot change passwrod from Console this way. Try using:\n", 4)
    txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
    for ch in txt:
     if not ch == "#":
      self.VVMwBk(ch, 0)
    self.VVMwBk("\nor\n", 4)
    self.VVMwBk("echo root:NEW_PASSWORD | chpasswd\n", 0)
    self.VVzBgR()
   else:
    self.VVU2VU(cmd)
 def VVgjEd(self, VVShs0, title, txt, colList):
  cmd = colList[1]
  self.VVibf9(VVShs0, cmd)
 def VVI1ci(self, VVShs0, filePath):
  if fileExists(filePath):
   CCRFRx(self, filePath, VV7s75=boundFunction(self.VVsmL2))
   VVShs0.cancel()
  else:
   FFV5mI(self, filePath)
 def VVsmL2(self):
  FF1XIo(self.VV5134)
 def VVS9hB(self):
  self.VVibf9(None, self.lastCommand)
 def VVibf9(self, VVShs0, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFiVZt(self, boundFunction(self.VVmOSb, VVShs0), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVmOSb(self, VVShs0, cmd):
  if cmd and len(cmd) > 0:
   self.VVU2VU(cmd)
   if VVShs0:
    VVShs0.cancel()
class CCt2jw(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VV47ip="", VVEZWm=False, VVCHvz=False, isTrimEnds=True):
  self.skin, self.skinParam = FFQUXb(VV2aOg, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFZrGE(self, title, addLabel=True)
  FFnxzu(self["keyRed"] , "Up/Down = Change")
  FFnxzu(self["keyGreen"] , "Overwrite")
  FFnxzu(self["keyYellow"], "Pick Key Map")
  FFnxzu(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVCHvz   = VVCHvz
  self.VVEZWm  = VVEZWm
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VV47ip, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVPbSm      ,
   "green"    : self.VVs6hJ    ,
   "yellow"   : self.VViPwH      ,
   "blue"    : self.VVTwaG     ,
   "menu"    : self.VV2w5c     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VV51NF, True) ,
   "down"    : boundFunction(self.VV51NF, False) ,
   "left"    : self.VVm0hy       ,
   "right"    : self.VVhb2U       ,
   "home"    : self.VVVilO       ,
   "end"    : self.VVAnr2       ,
   "next"    : self.VVVgzw      ,
   "last"    : self.VVspBt      ,
   "deleteForward"  : self.VVVgzw      ,
   "deleteBackward" : self.VVspBt      ,
   "tab"    : self.VVpzKs       ,
   "toggleOverwrite" : self.VVs6hJ    ,
   "0"     : self.VVRtmK     ,
   "1"     : self.VVRtmK     ,
   "2"     : self.VVRtmK     ,
   "3"     : self.VVRtmK     ,
   "4"     : self.VVRtmK     ,
   "5"     : self.VVRtmK     ,
   "6"     : self.VVRtmK     ,
   "7"     : self.VVRtmK     ,
   "8"     : self.VVRtmK     ,
   "9"     : self.VVRtmK
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVuhim()
  self.onShown.append(self.VVqv5b)
  self.onClose.append(self.onExit)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  self["myLabel"].setText(self.message)
  self.VVE0H1()
  if self.VVEZWm : self.VVs6hJ()
  else    : self.VVgeVQ()
  FFjswv(self)
  FFwL0h(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVVrKa)
  except:
   self.timer.callback.append(self.VVVrKa)
 def onExit(self):
  self.timer.stop()
 def VVPbSm(self):
  self.VVy5G1()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVy5G1()
  self.close(None)
 def VV2w5c(self):
  VVXWOy = []
  VVXWOy.append(("Home"         , "home"    ))
  VVXWOy.append(("End"         , "end"     ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Clear All"       , "clearAll"   ))
  VVXWOy.append(("Clear To Home"      , "clearToHome"   ))
  VVXWOy.append(("Clear To End"       , "clearToEnd"   ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVnRzV:
   VVXWOy.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("To Capital Letters"     , "toCapital"   ))
  VVXWOy.append(("To Small Letters"      , "toSmall"    ))
  FFue1q(self, self.VVSNWS, title="Edit Options", VVXWOy=VVXWOy)
 def VVSNWS(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVVilO()
   elif item == "end"     : self.VVAnr2()
   elif item == "clearAll"    : self.VVvsxB()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVVilO()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVnRzV
    VVnRzV = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVnRzV)
    self.VVVilO()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVVrKa(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVs6hJ(self):
  self["myInput"].toggleOverwrite()
  self.VVgeVQ()
 def VViPwH(self):
  self.session.openWithCallback(self.VVjJcx, boundFunction(CCiCSw, mode=self.charMode, VVCHvz=self.VVCHvz))
 def VVjJcx(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVE0H1()
 def VVgeVQ(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVuhim(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVy5G1(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VV2DDN(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVm0hy(self)     : self.VVOPct(self["myInput"].left)
 def VVhb2U(self)     : self.VVOPct(self["myInput"].right)
 def VVVgzw(self)     : self.VVOPct(self["myInput"].delete)
 def VVVilO(self)     : self.VVOPct(self["myInput"].home)
 def VVAnr2(self)     : self.VVOPct(self["myInput"].end)
 def VVspBt(self)    : self.VVOPct(self["myInput"].deleteBackward)
 def VVpzKs(self)     : self.VVOPct(self["myInput"].tab)
 def VVvsxB(self)     : self["myInput"].setText("")
 def VVOPct(self, fnc):
  fnc()
  self.VVVrKa()
 def VVRtmK(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VV2DDN(newChar, overwrite)
   self.VVtRBe(newChar, self["myInput"].mapping[number])
 def VV51NF(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCiCSw.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCiCSw.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VV2DDN(newChar, True)
   for group in groups:
    if newChar in group:
     self.VVtRBe(newChar, group)
     break
 def VVtRBe(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVI2d4:
    group = VVqb5h + group.replace(newChar, FFW8xd(newChar, VVI2d4, VVqb5h))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVTwaG(self):
  if self.VVCHvz : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVE0H1()
 def VVE0H1(self):
  self["myInput"].mapping = CCiCSw.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCiCSw.RCU_MAP_TITLES[self.charMode])
class CCiCSw(Screen):
 VVSmg1  = 0
 VV1ub7  = 1
 VVkjJU  = 2
 VV451a  = 3
 VVmFU0 = 4
 VVDv4H = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols, arabic_nums1, arabic1)
       , ( symbols, arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A" , u"\u0628")
       , (u"\u0647" , u"\u062A")
       )
 def __init__(self, session, mode=VVSmg1, VVCHvz=False):
  self.skin, self.skinParam = FFQUXb(VVJl51, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVCHvz  = VVCHvz
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFZrGE(self, title=self.Title)
  FFnxzu(self["keyRed"] ,"OK = Select")
  FFnxzu(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVKHmI     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVwesg, -1) ,
   "next"  : boundFunction(self.VVwesg, +1) ,
   "left"  : boundFunction(self.VVwesg, -1) ,
   "right"  : boundFunction(self.VVwesg, +1) ,
  }, -1)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  FFwL0h(self["keyRed"], "#11222222")
  FFwL0h(self["keyGreen"], "#11222222")
  self.VVuUIV()
 def VVuUIV(self):
  self.VVBJzl()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVBJzl(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVwesg(self, direction):
  if self.VVCHvz : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVuUIV()
 def VVKHmI(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCmvvf(Screen):
 def __init__(self, session, title="", message="", VVTBXk=VVhDR4, VVL4wo=False, VVnGDQ=None, VVH2Qb=30):
  self.skin, self.skinParam = FFQUXb(VVV8lu, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVH2Qb)
  self.session   = session
  FFZrGE(self, title, addScrollLabel=True)
  self.VVTBXk   = VVTBXk
  self.VVL4wo   = VVL4wo
  self.VVnGDQ   = VVnGDQ
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  self["myLabel"].VV0fFU(VVL4wo=self.VVL4wo)
  self["myLabel"].setText(self.message, self.VVTBXk)
  if self.VVnGDQ:
   FFwL0h(self["myBody"], self.VVnGDQ)
   FFwL0h(self["myLabel"], self.VVnGDQ)
   FFFHq1(self["myLabel"], self.VVnGDQ)
  self["myLabel"].VV0W5a()
class CCf7Z4(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFQUXb(VVDi9S, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFZrGE(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  path = VVhwNz + "err.png"
  if fileExists(path):
   self["errPic"].instance.setScale(1)
   self["errPic"].instance.setPixmapFromFile(path)
class CCq8j1(Screen):
 def __init__(self, session, enableZapping=True):
  self.skin, self.skinParam = FFQUXb(VVKVKL, 800, 170, 25, 10, 6, "#1100202a", "#1100202a", 20)
  self.session   = session
  self.enableZapping  = enableZapping
  self.winHeight   = 0
  self.Title    = ""
  self.timer    = eTimer()
  self.barWidth   = 0
  self.barHeight   = 0
  self.isManualSeek  = False
  self.manualSeekSec  = 0
  self.manualSeekPts  = 0
  self.jumpMinutes  = CFG.playerJumpMin.getValue()
  self.cutListCounter  = 0
  self.isCutListFound  = 0
  FFZrGE(self, "", addLabel=True)
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayBarM"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayJmp"] = Label("Jump: %d m" % self.jumpMinutes)
  self["myPlaySkp"] = Label()
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayInf"] = Label("Info")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVOF6C         ,
   "info"  : self.VVVH9g        ,
   "epg"  : self.VVVH9g        ,
   "menu"  : self.VVLOXP         ,
   "cancel" : self.cancel         ,
   "blue"  : self.VV4WwS        ,
   "play"  : self.VVqgWd        ,
   "pause"  : self.VVqgWd        ,
   "stop"  : self.VVqgWd        ,
   "left"  : boundFunction(self.VVFX6t, -1)   ,
   "right"  : boundFunction(self.VVFX6t,  1)   ,
   "rewind" : self.VVzH7A        ,
   "forward" : self.VV5rHC        ,
   "last"  : boundFunction(self.VVY4tt, 0)    ,
   "next"  : self.VV63eJ        ,
   "pageUp" : boundFunction(self.VV9yG5, True) ,
   "chanUp" : boundFunction(self.VV9yG5, True) ,
   "pageDown" : boundFunction(self.VV9yG5, False) ,
   "chanDown" : boundFunction(self.VV9yG5, False) ,
   "0"   : boundFunction(self.VVIis6 , 10)  ,
   "1"   : boundFunction(self.VVIis6 , 1)  ,
   "2"   : boundFunction(self.VVIis6 , 2)  ,
   "3"   : boundFunction(self.VVIis6 , 3)  ,
   "4"   : boundFunction(self.VVIis6 , 4)  ,
   "5"   : boundFunction(self.VVIis6 , 5)  ,
   "6"   : boundFunction(self.VVIis6 , 6)  ,
   "7"   : boundFunction(self.VVIis6 , 7)  ,
   "8"   : boundFunction(self.VVIis6 , 8)  ,
   "9"   : boundFunction(self.VVIis6 , 9)
  }, -1)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  self.VV3oxe()
  self.instance.move(ePoint(40, 40))
  size = self.instance.size()
  self.VVtFRG = int(size.width())
  self.winHeight1 = int(size.height())
  self.winHeight2 = int(self["myPlaySep"].getPosition()[1])
  FFTsrs(self["myPlayJmp"], "#0a666666")
  FFTsrs(self["myPlaySkp"], "#0affff00")
  FFwL0h(self["myPlayBlu"], "#1118188b")
  FFwL0h(self["myPlayInf"], "#11444444")
  self["myPlayBarM"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVCxi2)
  except:
   self.timer.callback.append(self.VVCxi2)
  self.timer.start(1000, False)
  self.VVCxi2("Checking ...")
 def onExit(self):
  self.timer.stop()
 def VV3oxe(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FF8KLs(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
 def VVLOXP(self):
  FFifNb(self, VVhwNz + "_help_player", "Player Controller (Keys)")
 def VVOF6C(self):
  if self.isManualSeek:
   self.VVlTUh()
   self.VVY4tt(self.manualSeekPts)
  else:
   if self.shown: self.hide()
   else   : self.show()
 def cancel(self):
  if self.isManualSeek:
   self.VVlTUh()
  else:
   self.close()
 def VVVH9g(self):
  self.session.open(CCnwAc)
 def VVqgWd(self):
  try:
   InfoBar.instance.playpauseService()
  except Exception as e:
   pass
  self.VVCxi2("Toggling Play/Pause ...")
 def VVlTUh(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayBarM"].hide()
   self["myPlaySkp"].hide()
 def VVFX6t(self, direc):
  seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt = self.VVGhPr()
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayBarM"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.jumpMinutes * 60.0
   else:
    self.manualSeekSec += direc * self.jumpMinutes * 60.0
    self.manualSeekSec = FFUMrv(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayBarM"].instance.size().width() + 1
   left = int(FFufQ4(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayBarM"].instance.move(ePoint(left, int(self["myPlayBarM"].getPosition()[1])))
   self["myPlaySkp"].setText(FF55bZ(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVIis6(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   FFnxzu(self["myPlayJmp"], "Jump: %d m" % self.jumpMinutes)
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVCxi2("Changed Jump Minutes to : %d" % val)
 def VVCxi2(self, title=""):
  if title:
   self.timer.stop()
  txt = self.Title
  seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt = self.VVGhPr()
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(str(posTxt))
    self["myPlayVal"].setText(percTxt)
    val  = FFUMrv(percVal, 0, 100)
    width = int(FFufQ4(val, 0, 100, 0, self.barWidth))
    self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
   if durTxt:
    self["myPlayDur"].setText(str(durTxt))
  if not self.isCutListFound and self.cutListCounter < 5:
   self.cutListCounter += 1
   if self.VVTUa7():
    self["myPlayBlu"].show()
    self.isCutListFound
  winH = self.instance.size().height()
  if durTxt:
   if winH < self.winHeight1:
    self.instance.resize(eSize(*(self.VVtFRG, self.winHeight1)))
  else:
   self["myPlayVal"].setText("0 %")
   if winH > self.winHeight2:
    self.instance.resize(eSize(*(self.VVtFRG, self.winHeight2)))
  if title:
   stateTxt = title
   FFTsrs(self["myPlayMsg"], "#00ff8000")
   self.timer.start(1000, False)
  else:
   stateTxt = ""
   if not posTxt and not durTxt:
    stateTxt = "Not playing yet ..."
   state = self.VVazaP()
   if state:
    if state == "Playing" and not posTxt: stateTxt = "Unknown state"
    elif percVal == 100     : stateTxt = "End"
    else        : stateTxt = state
   state = self.VV0vKO()
   if state:
    stateTxt = state
   if stateTxt == "Playing": FFTsrs(self["myPlayMsg"], "#0000ff00")
   else     : FFTsrs(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVGhPr(self):
  percVal = durVal = posVal = seekable = 0
  percTxt = durTxt = posTxt = ""
  isEnded = False
  try:
   service = self.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FF55bZ(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FF55bZ(posVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt
 def VV4WwS(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVTUa7()
   if cList:
    VVXWOy = []
    for pts, what in cList:
     txt = FF55bZ(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVXWOy.append((txt, pts))
    FFue1q(self, self.VVAhIo, VVXWOy=VVXWOy, title="Cut List")
   else:
    self.VVCxi2("No Cut-List for this channel !")
 def VVAhIo(self, item=None):
  if item:
   self.VVY4tt(item)
 def VVTUa7(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VV5rHC(self) : self.VVZ2Ht(self.jumpMinutes)
 def VVzH7A(self) : self.VVZ2Ht(-self.jumpMinutes)
 def VVZ2Ht(self, mins):
  try:
   inst = InfoBar.instance
   inst.doSeekRelative(mins * 60 * 90000)
   inst.hide()
   if   mins > 0 : self.VVCxi2("Forawrd (%d min) ..." % self.jumpMinutes)
   elif mins < 0 : self.VVCxi2("Rewind (%d min) ..." % self.jumpMinutes)
  except:
   self.VVCxi2("Cannot jump")
 def VVC2KR(self):
  InfoBar.instance.VVC2KR()
 def VVY4tt(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVCxi2("Changing Time ...")
 def VV63eJ(self):
  try:
   seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt = self.VVGhPr()
   if durVal > 0:
    pts = int(durVal * 60 * 90000)
    InfoBar.instance.doSeek(pts)
    self.VVCxi2("Jumping to end ...")
  except:
   pass
 def VVazaP(self):
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VV0vKO(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VV9yG5(self, isUp):
  if self.enableZapping:
   try:
    if isUp : InfoBar.instance.zapDown()
    else : InfoBar.instance.zapUp()
   except:
    pass
   self.VV3oxe()
class CCwFhk(Screen):
 def __init__(self, session, title="", VVRCwb="Continue?", VVhUed=True, VVBim4=False):
  self.skin, self.skinParam = FFQUXb(VVCUG2, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVRCwb = VVRCwb
  self.VVBim4 = VVBim4
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVhUed : VVXWOy = [no , yes]
  else   : VVXWOy = [yes, no ]
  FFZrGE(self, title, VVXWOy=VVXWOy, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVOF6C ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVRCwb)
  if self.VVBim4:
   self["myLabel"].instance.setHAlign(0)
  self.VVXVQE()
  FFNsDm(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FF7chj(self["myMenu"])
  FFcCYZ(self, self["myMenu"])
 def VVOF6C(self):
  item = FFU5pX(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVXVQE(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCVfo3(Screen):
 def __init__(self, session, title="", VVXWOy=None, width=1000, OKBtnFnc=None, VVdwgz=None, VVhih3=None, VV2cC5=None, VVpjth=None, VVQLeA=False, VVIgE2=False):
  self.skin, self.skinParam = FFQUXb(VV2YUz, width, 850, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVXWOy   = VVXWOy
  self.OKBtnFnc   = OKBtnFnc
  self.VVdwgz   = VVdwgz
  self.VVhih3  = VVhih3
  self.VV2cC5  = VV2cC5
  self.VVpjth   = VVpjth
  self.VVQLeA  = VVQLeA
  self.VVIgE2  = VVIgE2
  FFZrGE(self, title, VVXWOy=VVXWOy)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVOF6C          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVoMPB         ,
   "green"  : self.VVCHnk         ,
   "yellow" : self.VVcWmi         ,
   "blue"  : self.VVWr6o         ,
   "pageUp" : self.VVKkW9       ,
   "chanUp" : self.VVKkW9       ,
   "pageDown" : self.VVHE6F        ,
   "chanDown" : self.VVHE6F
  }, -1)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  FFNsDm(self["myMenu"])
  FF8cqd(self)
  self.VVRFs6(self["keyRed"]  , self.VVdwgz )
  self.VVRFs6(self["keyGreen"] , self.VVhih3 )
  self.VVRFs6(self["keyYellow"] , self.VV2cC5 )
  self.VVRFs6(self["keyBlue"]  , self.VVpjth )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFjswv(self)
 def VVRFs6(self, btnObj, btnFnc):
  if btnFnc:
   FFnxzu(btnObj, btnFnc[0])
 def VVOF6C(self):
  item = FFU5pX(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVQLeA: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVoMPB(self)  : self.VVOPct(self.VVdwgz)
 def VVCHnk(self) : self.VVOPct(self.VVhih3)
 def VVcWmi(self) : self.VVOPct(self.VV2cC5)
 def VVWr6o(self) : self.VVOPct(self.VVpjth)
 def VVOPct(self, btnFnc):
  if btnFnc:
   item = FFU5pX(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVIgE2:
    self.cancel()
 def VV7l9H(self, VVXWOy):
  if len(VVXWOy) > 0:
   newList = []
   for item in VVXWOy:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVYuBQ(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVKkW9(self):
  self["myMenu"].moveToIndex(0)
 def VVHE6F(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCn9YK(Screen):
 def __init__(self, session, title="", header=None, VVXy7C=None, VVqjzl=None, VV08hy=None, VVH2Qb=24, VVxpps=False, VVcgcO=None, VVUv68=None, VVFZEv=None, VVUhO3=None, VV6mer=None, VVeqJy=None, VV2jer=None, VVVt4G=None, VVWZbv=None, VVeTRB=-1, VVD19W=False, searchCol=0, VVrgKF=None, VVr4tL=None, VVew7y="#00dddddd", VVnGDQ="#11002233", VVhDXP="#00ff8833", VVli9s="#11111111", VV9S0H="#0a555555", VVhryq="#0affffff", VVBowS="#11552200", VVUhYN="#0055ff55"):
  self.skin, self.skinParam = FFQUXb(VVUm8T, 1400, 800, 50, 10, 5, "#22003344", "#22002233", 24, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFZrGE(self, title)
  self.header     = header
  self.VVXy7C     = VVXy7C
  self.totalCols    = len(VVXy7C[0])
  self.VVWE2V   = 0
  self.lastSortModeIsReverese = False
  self.VVxpps   = VVxpps
  self.VVqFXi   = 0.01
  self.VVUNIA   = 0.02
  self.VVD7cr  = 1
  self.VV08hy = VV08hy
  self.colWidthPixels   = []
  self.VVcgcO   = VVcgcO
  self.OKButtonObj   = None
  self.VVUv68   = VVUv68
  self.VVFZEv   = VVFZEv
  self.VVUhO3   = VVUhO3
  self.VV6mer  = VV6mer
  self.VVeqJy   = VVeqJy
  self.VV2jer    = VV2jer
  self.VVVt4G   = VVVt4G
  self.VVWZbv  = VVWZbv
  self.VVeTRB    = VVeTRB
  self.VVD19W   = VVD19W
  self.searchCol    = searchCol
  self.VVqjzl    = VVqjzl
  self.keyPressed    = -1
  self.VVH2Qb    = FF1Slb(VVH2Qb)
  self.VV7XV0    = FFsX3s(self.VVH2Qb, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVrgKF    = VVrgKF
  self.VVr4tL      = VVr4tL
  self.VVew7y    = FF91hV(VVew7y)
  self.VVnGDQ    = FF91hV(VVnGDQ)
  self.VVhDXP    = FF91hV(VVhDXP)
  self.VVli9s    = FF91hV(VVli9s)
  self.VV9S0H   = FF91hV(VV9S0H)
  self.VVhryq    = FF91hV(VVhryq)
  self.VVBowS    = FF91hV(VVBowS)
  self.VVUhYN   = FF91hV(VVUhYN)
  self.VVVy7n  = False
  self.selectedItems   = 0
  self.VV6laD   = FF91hV("#01fefe01")
  self.VVTwr0   = FF91hV("#11400040")
  self.VVXi5Z  = self.VV6laD
  self.VVMwHD  = self.VVli9s
  if self.VVD19W:
   self["keyMenu1F"].hide()
   self["keyMenu1"].hide()
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VV01Oh  ,
   "red"   : self.VV13BE  ,
   "green"   : self.VVKIcS ,
   "yellow"  : self.VVpU6v ,
   "blue"   : self.VV6H8R  ,
   "menu"   : self.VVg5cI ,
   "info"   : self.VVE2LA  ,
   "cancel"  : self.VVL5nJ  ,
   "up"   : self.VVlpKL    ,
   "down"   : self.VVSYAG  ,
   "left"   : self.VVp21r   ,
   "right"   : self.VVsPQH  ,
   "pageUp"  : self.VVsEfw  ,
   "chanUp"  : self.VVsEfw  ,
   "pageDown"  : self.VVSnhc  ,
   "chanDown"  : self.VVSnhc
  }, -1)
  FFzceg(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  try:
   self.VVoRDz()
  except Exception as err:
   FFEW3v(self, str(err))
   self.close(None)
 def VVoRDz(self):
  FFjswv(self)
  if self.VVrgKF:
   FFwL0h(self["myTitle"], self.VVrgKF)
  if self.VVr4tL:
   FFwL0h(self["myBody"] , self.VVr4tL)
   FFwL0h(self["myTableH"] , self.VVr4tL)
   FFwL0h(self["myTable"] , self.VVr4tL)
   FFwL0h(self["myBar"]  , self.VVr4tL)
  self.VVRFs6(self.VVFZEv  , self["keyRed"])
  self.VVRFs6(self.VVUhO3  , self["keyGreen"])
  self.VVRFs6(self.VV6mer , self["keyYellow"])
  self.VVRFs6(self.VVeqJy  , self["keyBlue"])
  if self.VVcgcO:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVcgcO[0])
    FFwL0h(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VV7XV0)
  self["myTableH"].l.setFont(0, gFont(VVmgWy, self.VVH2Qb))
  self["myTable"].l.setItemHeight(self.VV7XV0)
  self["myTable"].l.setFont(0, gFont(VVmgWy, self.VVH2Qb))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VV7XV0)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VV7XV0))
   self["myTable"].instance.resize(eSize(*(w, h - self.VV7XV0)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VV7XV0
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VV7XV0 * len(self.VVXy7C) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VV08hy:
   self.VV08hy = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VV08hy)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVqjzl:
   self.VVqjzl = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVqjzl
   self.VVqjzl = []
   for item in tmpList:
    self.VVqjzl.append(item | RT_VALIGN_CENTER)
  self.VVRquJ()
  if self.VV2jer:
   self.VV2jer(self)
 def VVRFs6(self, btnFnc, btn):
  if btnFnc : FFnxzu(btn, btnFnc[0])
  else  : FFnxzu(btn, "")
 def VVDj3y(self, waitTxt):
  FFBV5V(self, self.VVRquJ, title=waitTxt)
 def VVRquJ(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVd5Q8(0, self.header, self.VVhryq, self.VVBowS, self.VVhryq, self.VVBowS, self.VVUhYN)])
   rows = []
   for c, row in enumerate(self.VVXy7C):
    rows.append(self.VVd5Q8(c, row, self.VVew7y, self.VVnGDQ, self.VVhDXP, self.VVli9s, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVeTRB > -1:
    self["myTable"].moveToIndex(self.VVeTRB )
   self.VVSOUf()
   if self.VVD19W:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VV7XV0 * len(self.VVXy7C)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVVt4G:
    self.VVOPct(self.VVVt4G, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFEW3v(self, str(err))
    self.close()
   except:
    pass
 def VVd5Q8(self, keyIndex, columns, VVew7y, VVnGDQ, VVhDXP, VVli9s, VVUhYN):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVUhYN and ndx == self.VVWE2V : textColor = VVUhYN
   else           : textColor = VVew7y
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.+)", entry, IGNORECASE)
   if span:
    c = FF91hV(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVnGDQ = c
    entry = span.group(3)
   if self.VVqjzl[ndx] & LEFT:
    entry = " " + entry
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VV7XV0)
           , font   = 0
           , flags   = self.VVqjzl[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVnGDQ
           , color_sel  = VVhDXP
           , backcolor_sel = VVli9s
           , border_width = 1
           , border_color = self.VV9S0H
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVE2LA(self):
  rowData = self.VVHEtc()
  if rowData:
   title, txt, colList = rowData
   if self.VVUv68:
    fnc  = self.VVUv68[1]
    params = self.VVUv68[2]
    fnc(self, title, txt, colList)
   else:
    FFKjl2(self, txt, title)
 def VV01Oh(self):
  if   self.VVVy7n : self.VV5iQG(self.VVYWtJ(), mode=2)
  elif self.VVcgcO  : self.VVOPct(self.VVcgcO, None)
  else      : self.VVE2LA()
 def VV13BE(self) : self.VVOPct(self.VVFZEv , self["keyRed"])
 def VVKIcS(self) : self.VVOPct(self.VVUhO3 , self["keyGreen"])
 def VVpU6v(self): self.VVOPct(self.VV6mer , self["keyYellow"])
 def VV6H8R(self) : self.VVOPct(self.VVeqJy , self["keyBlue"])
 def VVOPct(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFtXOm(self, buttonFnc[3])
    FF1XIo(boundFunction(self.VVD9Zr, buttonFnc))
   else:
    self.VVD9Zr(buttonFnc)
 def VVD9Zr(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVHEtc()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VV5iQG(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VVXy7C[ndx]
   isSelected = row[1][9] == self.VV6laD
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVd5Q8(ndx, item, self.VVew7y, self.VVnGDQ, self.VVhDXP, self.VVli9s, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVd5Q8(ndx, item, self.VV6laD, self.VVTwr0, self.VVXi5Z, self.VVMwHD, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVSOUf()
 def VVFo0v(self):
  FFBV5V(self, self.VV3Qxt, title="Selecting all ...")
 def VV3Qxt(self):
  self.VVkDua(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VV6laD
   if not isSelected:
    item = self.VVXy7C[ndx]
    newRow = self.VVd5Q8(ndx, item, self.VV6laD, self.VVTwr0, self.VVXi5Z, self.VVMwHD, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVSOUf()
  self.VV1cyf()
 def VVDrD1(self):
  FFBV5V(self, self.VVzAs4, title="Unselecting all ...")
 def VVzAs4(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VV6laD:
    item = self.VVXy7C[ndx]
    newRow = self.VVd5Q8(ndx, item, self.VVew7y, self.VVnGDQ, self.VVhDXP, self.VVli9s, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVSOUf()
  self.VV1cyf()
 def VVHEtc(self):
  item = self["myTable"].getCurrent()
  if item:
   rowNum = item[0] + 1
   txt  = ""
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    if self.VV08hy[i - 1] > 1 or self.VV08hy[i - 1] == self.VVqFXi:
     if self.header : txt += "%s\t: %s\n" % (self.header[i - 1], colTxt)
     else   : txt += "Col-%d\t: %s\n" % (i, colTxt)
    colList.append(colTxt)
   return "Row Number : %d of %d\n\n" % (rowNum, len(self.VVXy7C)), txt, colList
  else:
   return None
 def VVL5nJ(self):
  if self.VVWZbv : self.VVWZbv(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVD0uy(self):
  return self["myTitle"].getText().strip()
 def VVOGbA(self, title):
  self["myTitle"].setText("  " + title)
 def VVKDDX(self, txt):
  FFtXOm(self, txt)
 def VVczAi(self, txt):
  FFtXOm(self, txt, 1000)
 def VVGqtm(self):
  FFtXOm(self)
 def VVHM5I(self):
  return len(self.VVXy7C)
 def VVI0CR(self): self["keyGreen"].show()
 def VV2OZh(self): self["keyGreen"].hide()
 def VVYWtJ(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVUSpe(self):
  return len(self["myTable"].list)
 def VVkDua(self, isOn):
  self.VVVy7n = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   if self.VVeqJy: self["keyBlue"].hide()
   if self.VVcgcO and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
   if self.VVeqJy: self["keyBlue"].show()
   if self.VVcgcO and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVcgcO[0])
   self.VVDrD1()
  FFwL0h(self["myTitle"], color)
  FFwL0h(self["myBar"]  , color)
 def VVrFw7(self):
  return self.VVVy7n
 def VV0Gy1(self):
  return self.selectedItems
 def VV1cyf(self):
  self.hide()
  self.show()
 def VV8ILm(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVSOUf()
 def VVluaq(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VVXy7C:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VV1qha(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVHM5I()
  txt += FFyty0("Total Unique Items", VVdNwi)
  for i in range(self.totalCols):
   if self.VV08hy[i - 1] > 1 or self.VV08hy[i - 1] == self.VVqFXi:
    name, tot = self.VVluaq(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFKjl2(self, txt)
 def VVB4LN(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVrhOZ(self, newList, newTitle=""):
  if newList:
   self.VVXy7C = newList
   if self.VVxpps and self.VVWE2V == 0:
    self.VVXy7C = sorted(self.VVXy7C, key=lambda x: int(x[self.VVWE2V])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VVXy7C = sorted(self.VVXy7C, key=lambda x: x[self.VVWE2V].lower(), reverse=self.lastSortModeIsReverese)
   self.VVDj3y("Refreshing ...")
   if newTitle:
    self.VVOGbA(newTitle)
  else:
   FFEW3v(self, "Cannot refresh list")
   self.cancel()
 def VVoPzw(self, data):
  ndx = self.VVYWtJ()
  newRow = self.VVd5Q8(ndx, data, self.VVew7y, self.VVnGDQ, self.VVhDXP, self.VVli9s, None)
  if newRow:
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VV1cyf()
   return True
  else:
   return False
 def VVevA6(self, colNum, textToFind, showErr=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVSOUf()
    break
  else:
   if showErr:
    FFtXOm(self, "Not found", 1000)
 def VV1tKW(self, colDict, showErr=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVSOUf()
    return
  if showErr:
   FFtXOm(self, "Not found", 1000)
 def VV1tKW_partial(self, colDict, showErr=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(txt, self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVSOUf()
    return
  if showErr:
   FFtXOm(self, "Not found", 1000)
 def VVmRKN(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVixYY(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VV6laD:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVtK2v(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVg5cI(self):
  if not self["keyMenu2F"].getVisible():
   return
  if not self.VVD19W:
   VVXWOy = []
   VVXWOy.append(("Table Statistcis"             , "tableStat"  ))
   VVXWOy.append(VVGV45)
   VVXWOy.append((FFW8xd("Export Table to .html"     , VVdNwi) , "VVJB6N" ))
   VVXWOy.append((FFW8xd("Export Table to .csv"     , VVdNwi) , "VVhqSr" ))
   VVXWOy.append((FFW8xd("Export Table to .txt (Tab Separated)", VVdNwi) , "VVW5sy" ))
   VVXWOy.append(VVGV45)
   for i in range(self.totalCols):
    if self.header : name = self.header[i]
    else   : name = "Col-%d" % i
    if self.VV08hy[i] > 1 or self.VV08hy[i] == self.VVUNIA:
     VVXWOy.append(("Sort by : %s" % name, i))
   if VVXWOy:
    FFue1q(self, self.VVD1OD, VVXWOy=VVXWOy, title=self.VVD0uy())
 def VVD1OD(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VV1qha()
   elif item == "VVJB6N": FFBV5V(self, self.VVJB6N, title=title)
   elif item == "VVhqSr" : FFBV5V(self, self.VVhqSr , title=title)
   elif item == "VVW5sy" : FFBV5V(self, self.VVW5sy , title=title)
   else:
    isReversed = False
    if self.VVWE2V == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVxpps and item == 0:
     self.VVXy7C = sorted(self.VVXy7C, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VVXy7C = sorted(self.VVXy7C, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVWE2V = item
    self.VVDj3y("Sorting ...")
 def VVlpKL(self):
  self["myTable"].up()
  self.VVSOUf()
 def VVSYAG(self):
  self["myTable"].down()
  self.VVSOUf()
 def VVp21r(self):
  self["myTable"].pageUp()
  self.VVSOUf()
 def VVsPQH(self):
  self["myTable"].pageDown()
  self.VVSOUf()
 def VVsEfw(self):
  self["myTable"].moveToIndex(0)
  self.VVSOUf()
 def VVSnhc(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVSOUf()
 def VVW5sy(self):
  expFile = self.VVgk2Y() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVkLGD()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VVXy7C:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VV08hy[ndx] > self.VVD7cr:
      col = self.VVlTOu(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVzHAd(expFile)
 def VVhqSr(self):
  expFile = self.VVgk2Y() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVkLGD()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VVXy7C:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VV08hy[ndx] > self.VVD7cr:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVlTOu(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVzHAd(expFile)
 def VVJB6N(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVD0uy(), PLUGIN_NAME, VVFjWv)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVD0uy()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVkLGD()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VV08hy:
   colgroup += '   <colgroup>'
   for w in self.VV08hy:
    if w > self.VVD7cr:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVgk2Y() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VVXy7C:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VV08hy[ndx] > self.VVD7cr:
      col = self.VVlTOu(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVzHAd(expFile)
 def VVkLGD(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VV08hy[ndx] > self.VVD7cr:
     newRow.append(col.strip())
  return newRow
 def VVlTOu(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  return FFOCgm(col)
 def VVgk2Y(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVD0uy())
  fileName = fileName.replace("__", "_")
  path  = FFTsBZ(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFtouN()
  return expFile
 def VVzHAd(self, expFile):
  FFJjNb(self, "File exported to:\n\n%s" % expFile, title=self.VVD0uy())
 def VVSOUf(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCMWbp(Screen):
 def __init__(self, session, Title="", VVaRdA=None):
  self.skin, self.skinParam = FFQUXb(VV3kF9, 1400, 800, 50, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FFZrGE(self, Title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VVaRdA = VVaRdA
  if len(Title) == 0 : Title = FFSb2Q()
  else    : Title = "File : %s" % VVaRdA
  self["myTitle"] = Label("  %s" % Title)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  allOK = FFoEjx(self["myLabel"], self.VVaRdA)
  if not allOK:
   FFEW3v(self, "Could not view this picture file")
   self.close()
class CClCHG(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFQUXb(VVXfv4, 1400, 850, 50, 40, 40, "#11201010", "#11101010", 32, barHeight=40, topRightBtns=1)
  self.session  = session
  FFZrGE(self)
  FFnxzu(self["keyGreen"], "Save")
  self.VVXy7C = []
  self.VVXy7C.append(getConfigListEntry("Show in Main Menu"     , CFG.showInMainMenu   ))
  self.VVXy7C.append(getConfigListEntry("Show in Extensions Menu"    , CFG.showInExtensionMenu  ))
  self.VVXy7C.append(getConfigListEntry("Show in Channel List Context Menu" , CFG.showInChannelListMenu  ))
  self.VVXy7C.append(getConfigListEntry("Input Type"       , CFG.keyboard     ))
  self.VVXy7C.append(getConfigListEntry("Signal & Player Cotroller Hotkey" , CFG.hotkey_signal    ))
  self.VVXy7C.append(getConfigListEntry("Default IPTV Reference Type"   , CFG.iptvAddToBouquetRefType ))
  self.VVXy7C.append(getConfigListEntry(VVklh1 *2        ,         ))
  self.VVXy7C.append(getConfigListEntry("PIcons Path"       , CFG.PIconsPath    ))
  self.VVXy7C.append(getConfigListEntry(VVklh1 *2        ,         ))
  self.VVXy7C.append(getConfigListEntry("Backup/Restore Path"     , CFG.backupPath    ))
  self.VVXy7C.append(getConfigListEntry("Created Package Files (IPK/DEB)"  , CFG.packageOutputPath   ))
  self.VVXy7C.append(getConfigListEntry("Downloaded Packages (from feeds)" , CFG.downloadedPackagesPath ))
  self.VVXy7C.append(getConfigListEntry("Exported Tables"      , CFG.exportedTablesPath  ))
  self.VVXy7C.append(getConfigListEntry("Exported PIcons"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, self.VVXy7C, session)
  self["setupActions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard", "OkCancelActions"],
  {
   "ok"  : self.VVOF6C   ,
   "OK"  : self.VVOF6C   ,
   "green"  : self.VVK8Pu  ,
   "menu"  : self.VVRLuq ,
   "cancel" : self.VV17me
  }, -1)
  self.titleText = "  Settings"
  self["myTitle"].setText(self.titleText)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  FFNsDm(self["config"])
  FF8cqd(self,  self["config"])
  FFjswv(self)
 def VVOF6C(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.PIconsPath    : self.VVrh3Q(item)
   elif item == CFG.backupPath    : self.VVrh3Q(item)
   elif item == CFG.packageOutputPath  : self.VVrh3Q(item)
   elif item == CFG.downloadedPackagesPath : self.VVrh3Q(item)
   elif item == CFG.exportedTablesPath  : self.VVrh3Q(item)
   elif item == CFG.exportedPIconsPath  : self.VVrh3Q(item)
 def VVrh3Q(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(boundFunction(self.VVEl2L, configObj)
         , boundFunction(CCMIrG, mode=CCMIrG.BROWSER_MODE_DIR_PICKER, VVvo0t=sDir))
 def VVEl2L(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VV17me(self):
  if CFG.showInMainMenu.isChanged()   or \
   CFG.showInExtensionMenu.isChanged()  or \
   CFG.showInChannelListMenu.isChanged() or \
   CFG.keyboard.isChanged()    or \
   CFG.hotkey_signal.isChanged()   or \
   CFG.iptvAddToBouquetRefType.isChanged() or \
   CFG.PIconsPath.isChanged()    or \
   CFG.backupPath.isChanged()    or \
   CFG.packageOutputPath.isChanged()  or \
   CFG.downloadedPackagesPath.isChanged() or \
   CFG.exportedTablesPath.isChanged()  or \
   CFG.exportedPIconsPath.isChanged():
    FFUzhN(self, self.VVK8Pu, "Save Changes ?", callBack_No=self.cancel)
  else:
   self.cancel()
 def VVK8Pu(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVhg0e()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVRLuq(self):
  VVXWOy = []
  VVXWOy.append(("Use Backup directory in all other paths"      , "VVQOC0"   ))
  VVXWOy.append(("Reset all to default (including File Manager bookmarks)"  , "VVVzLO"   ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Change Text Color Scheme (for Transparent Text)"    , "changeColorScheme" ))
  if fileExists(VVoi8H + VVFvKy):
   VVXWOy.append(VVGV45)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVXWOy.append(('%s Checking for Update' % txt1       , txt2     ))
   VVXWOy.append(("Reinstall %s" % PLUGIN_NAME        , "VVLh5v"  ))
   VVXWOy.append(("Update %s" % PLUGIN_NAME        , "VVxZJk"   ))
  FFue1q(self, self.VVzgx7, VVXWOy=VVXWOy, title="Config. Options")
 def VVzgx7(self, item=None):
  if item:
   if   item == "VVQOC0"  : FFUzhN(self, self.VVQOC0 , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVVzLO"  : FFUzhN(self, self.VVVzLO, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCKdGY)
   elif item == "enableChkUpdate" : self.VVi2wE(True)
   elif item == "disableChkUpdate" : self.VVi2wE(False)
   elif item == "VVLh5v" : FFBV5V(self, self.VVLh5v , "Checking Server ...")
   elif item == "VVxZJk"  : FFBV5V(self, self.VVxZJk  , "Checking Server ...")
 def VVi2wE(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVQOC0(self):
  newPath = FFTsBZ(VVoi8H)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVhg0e()
 @staticmethod
 def VVSnbX():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVVzLO(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.PIconsPath.setValue(VVx9ys)
  CFG.backupPath.setValue(CClCHG.VVSnbX())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  CFG.showInMainMenu.save()
  CFG.showInExtensionMenu.save()
  CFG.showInChannelListMenu.save()
  CFG.keyboard.save()
  CFG.hotkey_signal.save()
  CFG.iptvAddToBouquetRefType.save()
  CFG.PIconsPath.save()
  CFG.backupPath.save()
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  CFG.browserStartPath.save()
  CFG.browserBookmarks.save()
  self.VVhg0e()
  self.close()
 def VVhg0e(self):
  configfile.save()
  global VVoi8H
  VVoi8H = CFG.backupPath.getValue()
  FF8E0M()
 def VVxZJk(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVfCxM(title)
  if webVer:
   FFUzhN(self, boundFunction(FFBV5V, self, boundFunction(self.VVdPjG, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVLh5v(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVfCxM(title, True)
  if webVer:
   FFUzhN(self, boundFunction(FFBV5V, self, boundFunction(self.VVdPjG, webVer, title)), "Install and Restart ?", title=title)
 def VVdPjG(self, webVer, title):
  url = self.VV45Z4(self, title)
  if url:
   VVFOlr = FFqtwu() == "dpkg"
   if VVFOlr == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VVFOlr else "ipk")
   path, err = FF0NYM(url + fName, fName, timeout=2)
   if path:
    cmd = FF2NxH(VVXTqa, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFb6xn(self, cmd)
    else:
     FFVWVs(self, title=title)
   else:
    FFEW3v(self, err, title=title)
 def VVfCxM(self, title, anyVer=False):
  url = self.VV45Z4(self, title)
  if not url:
   return ""
  path, err = FF0NYM(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFEW3v(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFteHI(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFEW3v(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVFjWv.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFUtqa(cmd)
   if list and curVer == list[0]:
    return webVer
  FFJjNb(self, FFW8xd("No update required.", VVmHHA) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VV45Z4(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVoi8H + VVFvKy
  if fileExists(path):
   span = iSearch(r"(http.+)", FFteHI(path), IGNORECASE)
   if span : url = FFTsBZ(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFEW3v(SELF, err, title)
  return url
 @staticmethod
 def VVEjNJ(url):
  path, err = FF0NYM(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFteHI(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVFjWv.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFUtqa(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCKdGY(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFQUXb(VVsoAu, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VV0pPs
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFZrGE(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVV9IX("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVV9IX("\c00888888", i) + sp + "GREY\n"
   txt += self.VVV9IX("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVV9IX("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVV9IX("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVV9IX("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVV9IX("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVV9IX("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVV9IX("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVV9IX("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVV9IX("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVV9IX("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVOF6C ,
   "green"   : self.VVOF6C ,
   "left"   : self.VVFEaV ,
   "right"   : self.VVivVo ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  self.VVl26x()
 def VVOF6C(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFUzhN(self, self.VVn0jj, "Change to : %s" % txt, title=self.Title)
 def VVn0jj(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VV0pPs
  VV0pPs = self.cursorPos
  self.VVjKYa()
  self.close()
 def VVFEaV(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVl26x()
 def VVivVo(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVl26x()
 def VVl26x(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVV9IX(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVlMXG(color):
  if VVFlyn: return "\\" + color
  else    : return ""
 @staticmethod
 def VVjKYa():
  global VVYh3b, VVqb5h, VV7KZt, VVdNwi, VVUYyn, VV74c8, VVmHHA, VVFlyn, COLOR_CONS_BRIGHT_YELLOW, VVhJi6, VVbXIp, VVI2d4
  VVI2d4   = CCKdGY.VVV9IX("\c00FFFFFF", VV0pPs)
  VVqb5h    = CCKdGY.VVV9IX("\c00888888", VV0pPs)
  VVYh3b  = CCKdGY.VVV9IX("\c005A5A5A", VV0pPs)
  VV74c8    = CCKdGY.VVV9IX("\c00FF0000", VV0pPs)
  VV7KZt   = CCKdGY.VVV9IX("\c00FF5000", VV0pPs)
  VVFlyn   = CCKdGY.VVV9IX("\c00FFFF00", VV0pPs)
  COLOR_CONS_BRIGHT_YELLOW = CCKdGY.VVV9IX("\c00FFFFAA", VV0pPs)
  VVmHHA   = CCKdGY.VVV9IX("\c0000FF00", VV0pPs)
  VVUYyn    = CCKdGY.VVV9IX("\c000066FF", VV0pPs)
  VVhJi6    = CCKdGY.VVV9IX("\c0000FFFF", VV0pPs)
  VVbXIp   = CCKdGY.VVV9IX("\c00FA55E7", VV0pPs)
  VVdNwi    = CCKdGY.VVV9IX("\c00FF8F5F", VV0pPs)
CCKdGY.VVjKYa()
class CCnXtk(Screen):
 def __init__(self, session, path, VVFOlr):
  self.skin, self.skinParam = FFQUXb(VVnLZX, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VV0CuN   = path
  self.VVXaIS   = ""
  self.VV8TO3   = ""
  self.VVFOlr    = VVFOlr
  self.VV2C96    = ""
  self.VVlJi7  = ""
  self.VVyZbg    = False
  self.VVHxpy  = False
  self.postInstAcion   = 0
  self.VVWbKz  = "enigma2-plugin-extensions"
  self.VVTAcW  = "enigma2-plugin-systemplugins"
  self.VV5IMc = "enigma2"
  self.VVFpVR  = 0
  self.VVVATP  = 1
  self.VVxEZS  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVuEWI = "DEBIAN"
  else        : self.VVuEWI = "CONTROL"
  self.controlPath = self.Path + self.VVuEWI
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVFOlr:
   self.packageExt  = ".deb"
   self.VVnGDQ  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVnGDQ  = "#11001020"
  FFZrGE(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFnxzu(self["keyRed"] , "Create")
  FFnxzu(self["keyGreen"] , "Post Install")
  FFnxzu(self["keyYellow"], "Installation Path")
  FFnxzu(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVIiXm  ,
   "green"   : self.VVyaWv ,
   "yellow"  : self.VV8CRo  ,
   "blue"   : self.VVxWRa  ,
   "cancel"  : self.VVwZob
  }, -1)
  self.onShown.append(self.VVqv5b)
 def VVqv5b(self):
  self.onShown.remove(self.VVqv5b)
  FFjswv(self)
  if self.VVnGDQ:
   FFwL0h(self["myBody"], self.VVnGDQ)
   FFwL0h(self["myLabel"], self.VVnGDQ)
  self.VVFxnk(True)
  self.VV7bsD(True)
 def VV7bsD(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VV73Wn()
  if isFirstTime:
   if   package.startswith(self.VVWbKz) : self.VV0CuN = VVCrBY + self.VV2C96 + "/"
   elif package.startswith(self.VVTAcW) : self.VV0CuN = VVO2Lq + self.VV2C96 + "/"
   else            : self.VV0CuN = self.Path
  if self.VVyZbg : myColor = VVdNwi
  else    : myColor = VVI2d4
  txt  = ""
  txt += "Source Path\t: %s\n" % FFW8xd(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFW8xd(self.VV0CuN, VVFlyn)
  if self.VV8TO3 : txt += "Package File\t: %s\n" % FFW8xd(self.VV8TO3, VVqb5h)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFW8xd("Check Control File fields : %s" % errTxt, VV7KZt)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFW8xd("Restart GUI", VVdNwi)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFW8xd("Reboot Device", VVdNwi)
  else      : act = "No action."
  txt += "\nPost Install\t: %s\n" % act
  if not errTxt and VV7KZt in controlInfo:
   txt += "Warning\t: %s\n" % FFW8xd("Errors in control file may affect the result package.", VV7KZt)
  txt += "\nControl File\t: %s\n" % FFW8xd(self.controlFile, VVqb5h)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVyaWv(self):
  VVXWOy = []
  VVXWOy.append(("No Action"    , "noAction"  ))
  VVXWOy.append(("Restart GUI"    , "VVub9W"  ))
  VVXWOy.append(("Reboot Device"   , "rebootDev"  ))
  FFue1q(self, self.VV0xXk, title="Package Installation Option (after completing installation)", VVXWOy=VVXWOy)
 def VV0xXk(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVub9W"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVFxnk(False)
   self.VV7bsD()
 def VV8CRo(self):
  VVXWOy = []
  VVXWOy.append(("Current Path"   , "toCurrent"  ))
  VVXWOy.append(("Extension Path"  , "toExtensions" ))
  VVXWOy.append(("System Plugins Path" , "toSystemPlugins" ))
  VVXWOy.append(("Root Path"   , "toRoot"   ))
  VVXWOy.append(("Other Path"   , "toOthers"  ))
  FFue1q(self, self.VViVO8, title="Installation Path", VVXWOy=VVXWOy)
 def VViVO8(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVJoRu(FF89XU(self.Path, True))
   elif item == "toExtensions"  : self.VVJoRu(VVCrBY)
   elif item == "toSystemPlugins" : self.VVJoRu(VVO2Lq)
   elif item == "toRoot"   : self.VVJoRu("/")
   elif item == "toOthers"   : self.session.openWithCallback(self.VVR7OM, boundFunction(CCMIrG, mode=CCMIrG.BROWSER_MODE_DIR_PICKER, VVvo0t=VVoi8H))
 def VVR7OM(self, path):
  if len(path) > 0:
   self.VVJoRu(path)
 def VVJoRu(self, parent):
  self.VV0CuN = parent + self.VV2C96 + "/"
  mode = self.VVHtd6()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVECJX(mode), self.controlFile))
  self.VV7bsD()
 def VVxWRa(self):
  if fileExists(self.controlFile):
   lines = FFUM2c(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFiVZt(self, self.VVgMgJ, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFEW3v(self, "Version not found or incorrectly set !")
  else:
   FFV5mI(self, self.controlFile)
 def VVgMgJ(self, VV47ip):
  if VV47ip:
   version, color = self.VVkAij(VV47ip, False)
   if color == VVhJi6:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VV47ip, self.controlFile))
    self.VV7bsD()
   else:
    FFEW3v(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVwZob(self):
  if self.newControlPath:
   if self.VVyZbg:
    self.VVWutj()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFW8xd(self.newControlPath, VVqb5h)
    txt += FFW8xd("Do you want to keep these files ?", VVFlyn)
    FFUzhN(self, self.close, txt, callBack_No=self.VVWutj, title="Create Package", VVBim4=True)
  else:
   self.close()
 def VVWutj(self):
  os.system(FFLcOy("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVECJX(self, mode):
  if   mode == self.VVVATP : prefix = self.VVWbKz
  elif mode == self.VVxEZS : prefix = self.VVTAcW
  else        : prefix = self.VV5IMc
  return prefix + "-" + self.VVlJi7
 def VVHtd6(self):
  if   self.VV0CuN.startswith(VVCrBY) : return self.VVVATP
  elif self.VV0CuN.startswith(VVO2Lq) : return self.VVxEZS
  else            : return self.VVFpVR
 def VVFxnk(self, isFirstTime):
  self.VV2C96   = os.path.basename(os.path.normpath(self.Path))
  self.VV2C96   = "_".join(self.VV2C96.split())
  self.VVlJi7 = self.VV2C96.lower()
  self.VVyZbg = self.VVlJi7 == VVSjR1.lower()
  if self.VVyZbg and self.VVlJi7.endswith("ajpan"):
   self.VVlJi7 += "el"
  if self.VVyZbg : self.VVXaIS = VVoi8H
  else    : self.VVXaIS = CFG.packageOutputPath.getValue()
  self.VVXaIS = FFTsBZ(self.VVXaIS)
  if not pathExists(self.controlPath):
   os.system(FFLcOy("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVyZbg : t = PLUGIN_NAME
  else    : t = self.VV2C96
  self.VVVLnA(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVt4G6.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVyZbg : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVVLnA(self.postrmFile, txt)
  if self.VVyZbg:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVFjWv)
   self.VVVLnA(self.preinstFile, txt)
  else:
   self.VVVLnA(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VV2C96)
  mode = self.VVHtd6()
  if isFirstTime and not mode == self.VVFpVR:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVklh1
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVVLnA(self.postinstFile, txt, VVEZWm=True)
  os.system(FFLcOy("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVyZbg : version, descripton, maintainer = VVFjWv , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VV2C96 , self.VV2C96
   txt = ""
   txt += "Package: %s\n"  % self.VVECJX(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVVLnA(self, path, lines, VVEZWm=False):
  if not fileExists(path) or VVEZWm:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VV73Wn(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFUM2c(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFW8xd(line, VV7KZt)
     elif not line.startswith(" ")    : line = FFW8xd(line, VV7KZt)
     else          : line = FFW8xd(line, VVhJi6)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVhJi6
   else   : color = VV7KZt
   descr = FFW8xd(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VV7KZt
     elif line.startswith((" ", "\t")) : color = VV7KZt
     elif line.startswith("#")   : color = VVqb5h
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVkAij(val, True)
      elif key == "Version"  : version, color = self.VVkAij(val, False)
      elif key == "Maintainer" : maint  , color = val, VVhJi6
      elif key == "Architecture" : arch  , color = val, VVhJi6
      else:
       color = VVhJi6
      if not key == "OE" and not key.istitle():
       color = VV7KZt
     else:
      color = VVdNwi
     txt += FFW8xd(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VV8TO3 = self.VVXaIS + packageName
   self.VVHxpy = True
   errTxt = ""
  else:
   self.VV8TO3  = ""
   self.VVHxpy = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVkAij(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVhJi6
  else          : return val, VV7KZt
 def VVIiXm(self):
  if not self.VVHxpy:
   FFEW3v(self, "Please fix Control File errors first.")
   return
  if self.VVFOlr: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FF89XU(self.VV0CuN, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VV2C96
  symlinkTo  = FFcHPD(self.Path)
  dataDir   = self.VV0CuN.rstrip("/")
  removePorjDir = FFLcOy("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFLcOy("rm -f '%s'" % self.VV8TO3) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FF6Afo()
  if self.VVFOlr:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFUIFh("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVyZbg:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVuEWI)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VV8TO3, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VV8TO3
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VV8TO3, FF3Nyd(result  , VVmHHA))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VV0CuN, FF3Nyd(instPath, VVhJi6))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FF3Nyd(failed, VV7KZt))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFb6xn(self, cmd)
class CCMIrG(Screen):
 BROWSER_MODE_NORMAL   = 0
 BROWSER_MODE_DIR_PICKER  = 1
 MAX_BOOKMARKS = 20
 def __init__(self, session, VVvo0t="/", mode=BROWSER_MODE_NORMAL, VV83AD="Select", VVH2Qb=30):
  self.skin, self.skinParam = FFQUXb(VV2YUz, 1400, 820, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFZrGE(self)
  FFnxzu(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VV83AD = VV83AD
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  if   self.mode == self.BROWSER_MODE_NORMAL  : VV4tCg, self.VVvo0t = True , CFG.browserStartPath.getValue()
  elif self.mode == self.BROWSER_MODE_DIR_PICKER : VV4tCg, self.VVvo0t = False, VVvo0t
  else           : VV4tCg, self.VVvo0t = True , VVvo0t
  VVvo0t = FFTsBZ(VVvo0t)
  self["myMenu"] = CCba5i(  directory   = "/"
         , VV4tCg   = VV4tCg
         , VVkq1h = True
         , VVtFRG   = self.skinParam["width"]
         , VVH2Qb   = self.skinParam["bodyFontSize"]
         , VV7XV0  = self.skinParam["bodyLineH"]
         , VVi5S5  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVOF6C      ,
   "cancel"   : self.cancel      ,
   "green"    : self.VVim42    ,
   "yellow"   : self.VV1IeF   ,
   "blue"    : self.VVRwJF   ,
   "menu"    : self.VVIODH    ,
   "info"    : self.VVvvzt    ,
   "pageUp"   : self.VVQW8r     ,
   "chanUp"   : self.VVQW8r
  }, -1)
  FFzceg(self, self["myMenu"])
  self.onShown.append(self.start)
  self["myMenu"].onSelectionChanged.append(self.VVqNby)
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVqNby)
  FFNsDm(self["myMenu"], bg="#06003333")
  FFjswv(self)
  self.maxTitleWidth = self["keyMenu1"].getPosition()[0] - 40
  if self.mode == self.BROWSER_MODE_DIR_PICKER:
   FFnxzu(self["keyGreen"], self.VV83AD)
   color = "#22000022"
   FFwL0h(self["myBody"], color)
   FFwL0h(self["myMenu"], color)
   color = "#22220000"
   FFwL0h(self["myTitle"], color)
   FFwL0h(self["myBar"], color)
  self.VVqNby()
  if self.VVztUc(self.VVvo0t) > self.bigDirSize:
   FFtXOm(self, "Changing directory...")
   FF1XIo(self.VVl4yC)
  else:
   self.VVl4yC()
 def VVl4yC(self):
  self["myMenu"].VVtmc4(self.VVvo0t)
 def VVwjlY(self):
  self["myMenu"].refresh()
  FFigte()
 def VVztUc(self, folder):
  totalItems = 0
  if pathExists(folder):
   totalItems = len(os.listdir(folder))
  return totalItems
 def VVOF6C(self):
  if self["myMenu"].VVGecm():
   path = self.VVCv4i(self.VVz4aF())
   if self.VVztUc(path) > self.bigDirSize:
    FFtXOm(self, "Changing directory...")
    FF1XIo(self.VVXIdh)
   else:
    self.VVXIdh()
  else:
   self.VVPDRu()
 def VVXIdh(self):
  self["myMenu"].descent()
  self["myMenu"].moveToIndex(0)
  self.VVqNby()
 def VVQW8r(self):
  if self["myMenu"].VVhxxE():
   self["myMenu"].moveToIndex(0)
   self.VVXIdh()
 def cancel(self):
  if not FFulRq(self):
   self.close("")
 def VVim42(self):
  if self.mode == self.BROWSER_MODE_DIR_PICKER:
   path = self.VVCv4i(self.VVz4aF())
   self.close(path)
 def VVvvzt(self):
  FFBV5V(self, self.VVr1nb, title="Calculating size ...")
 def VVr1nb(self):
  path = self.VVCv4i(self.VVz4aF())
  param = self.VV0NF7(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = ""
   if typeChar == "d":
    result = FFHvE5("myDir='%s'; totDirs=$(find $myDir -type d | wc -l); totFiles=$(find $myDir ! -type d | wc -l); echo $totDirs','$totFiles" % path)
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents  = "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
    size = FFHvE5("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    size = int(size)
   if size >= 1024 : size = "%s  ( %s bytes )" % (self.VVmfMr(size), format(size, ',d'))
   else   : size = "%s" % self.VVmfMr(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFW8xd(pathTxt, VVdNwi) + "\n"
   if slBroken : fileTime = self.VV7d4g(path)
   else  : fileTime = self.VVupT0(path)
   def VVBpgj(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVBpgj("Path"    , pathTxt)
   txt += VVBpgj("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVBpgj("Target"   , slTarget)
   txt += VVBpgj("Size"    , "%s" % size)
   txt += contents
   txt += "\n"
   txt += VVBpgj("Owner"    , owner)
   txt += VVBpgj("Group"    , group)
   txt += VVBpgj("Perm. (User)"  , permUser)
   txt += VVBpgj("Perm. (Group)"  , permGroup)
   txt += VVBpgj("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVBpgj("Perm. (Ext.)" , permExtra)
   txt += VVBpgj("iNode"    , iNode)
   txt += VVBpgj("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVklh1, VVklh1)
    txt += hLinkedFiles
  else:
   FFEW3v(self, "Cannot access information !")
  if len(txt) > 0:
   FFKjl2(self, txt)
 def VV0NF7(self, path):
  path = path.strip()
  path = FFcHPD(path)
  result = FFHvE5("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VV1ejD(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VV1ejD(perm, 1, 4)
   permGroup = VV1ejD(perm, 4, 7)
   permOther = VV1ejD(perm, 7, 10)
   permExtra = VV1ejD(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFrSA4("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVupT0(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFnWMY(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFnWMY(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFnWMY(os.path.getctime(path))
  return txt
 def VV7d4g(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFHvE5("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFHvE5("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFHvE5("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVmfMr(self, size):
  power = 1024.0
  n = 0
  power_labels = {0 : 'B', 1: 'kB', 2: 'MB', 3: 'GB', 4: 'TB'}
  while size > power:
   size /= power
   n += 1
  size = "%.1f" % size
  if size.endswith(".0"):
   size = size[:-2]
  return "%s %s" % (size, power_labels[n])
 def VVCv4i(self, currentSel):
  currentDir  = self["myMenu"].VVhxxE()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVGecm():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVz4aF(self):
  return self["myMenu"].getSelection()[0]
 def VVqNby(self):
  FFtXOm(self)
  path = self.VVCv4i(self.VVz4aF())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VVXy7C = self.VVosJt()
  if VVXy7C and len(VVXy7C) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VV4JFV(path)
  if self.mode == self.BROWSER_MODE_NORMAL and len(path) > 0:
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
  else:
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
 def VV4JFV(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVTEGG(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVIODH(self):
  if self.mode == self.BROWSER_MODE_NORMAL:
   path  = self.VVCv4i(self.VVz4aF())
   isDir  = os.path.isdir(path)
   VVXWOy = []
   VVXWOy.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVvekX(path):
     sepShown = True
     VVXWOy.append(VVGV45)
     VVXWOy.append( (VVdNwi + "Archiving / Packaging"      , "VVow8H"  ))
    if self.VVynvy(path):
     if not sepShown:
      VVXWOy.append(VVGV45)
     VVXWOy.append( (VVdNwi + "Read Backup information"     , "VVo6lU"  ))
     VVXWOy.append( (VVdNwi + "Compress Octagon Image (to zip File)"  , "VVn9SU" ))
   elif os.path.isfile(path):
    selFile = self.VVz4aF()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip"))   : VVXWOy.extend(self.VVMMVf(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVXWOy.extend(self.VVRQqT(True))
    elif selFile.endswith(".m3u")              : VVXWOy.extend(self.VVMX6i(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FF0hai(path):
     VVXWOy.append(VVGV45)
     VVXWOy.append((VVdNwi + "View" , "text_View" ))
     VVXWOy.append((VVdNwi + "Edit" , "text_Edit" ))
    if len(txt) > 0:
     VVXWOy.append(VVGV45)
     VVXWOy.append(   (VVdNwi + txt      , "VVPDRu"  ))
   VVXWOy.append(VVGV45)
   VVXWOy.append(     ("Create SymLink"       , "VVcRA4" ))
   if not self.VVvekX(path):
    VVXWOy.append(   ("Rename"          , "VV9hwD" ))
    VVXWOy.append(   ("Copy"           , "copyFileOrDir" ))
    VVXWOy.append(   ("Move"           , "moveFileOrDir" ))
    VVXWOy.append(   ("DELETE"          , "VVbWa9" ))
    if fileExists(path):
     VVXWOy.append(VVGV45)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVXWOy.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVXWOy.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVXWOy.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVXWOy.append(VVGV45)
   VVXWOy.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVXWOy.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   VVXWOy.append(VVGV45)
   VVXWOy.append(    ("Set current directory as \"Startup Path\"" , "VV0Pfy" ))
   FFue1q(self, self.VVaOl6, title="Options", VVXWOy=VVXWOy)
 def VVaOl6(self, item=None):
  if self.mode == self.BROWSER_MODE_NORMAL:
   if item is not None:
    path = self.VVCv4i(self.VVz4aF())
    selFile = self.VVz4aF()
    if   item == "properties"    : self.VVvvzt()
    elif item == "VVow8H"  : self.VVow8H(path)
    elif item == "VVo6lU"  : self.VVo6lU(path)
    elif item == "VVn9SU" : self.VVn9SU(path)
    elif item.startswith("extract_")  : self.VVQjbm(path, selFile, item)
    elif item.startswith("script_")   : self.VVvSHF(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVzScvItem_m3u(path, selFile, item)
    elif item.startswith("text_View")  : FFW3ac(self, path)
    elif item.startswith("text_Edit")  : CCRFRx(self, path, VV7s75=self.VVwjlY)
    elif item == "chmod644"     : self.VVLAws(path, selFile, "644")
    elif item == "chmod755"     : self.VVLAws(path, selFile, "755")
    elif item == "chmod777"     : self.VVLAws(path, selFile, "777")
    elif item == "VVcRA4"   : self.VVcRA4(path, selFile)
    elif item == "VV9hwD"   : self.VV9hwD(path, selFile)
    elif item == "copyFileOrDir"   : self.VVKtZ4(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVKtZ4(path, selFile, True)
    elif item == "VVbWa9"   : self.VVbWa9(path, selFile)
    elif item == "createNewFile"   : self.VVis3c(path, True)
    elif item == "createNewDir"    : self.VVis3c(path, False)
    elif item == "VV0Pfy"   : self.VV0Pfy(path)
    elif item == "VVPDRu"    : self.VVPDRu()
    else         : self.close()
 def VVPDRu(self):
  selFile = self.VVz4aF()
  path  = self.VVCv4i(selFile)
  if os.path.isfile(path):
   VVZwQE = []
   category = self["myMenu"].VVRBR4(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVv9wf(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FFPHv7(self, selFile, path)
   elif category == "txt"         : FFW3ac(self, path)
   elif category in ("tar", "zip")       : self.VVCHXv(path, selFile)
   elif category == "scr"         : self.VVXcaB(path, selFile)
   elif category == "m3u"         : self.VVEzOG(path, selFile)
   elif category in ("ipk", "deb")       : self.VVu3v6(path, selFile)
   elif category == "mus"         : self.VV5lAW(path)
   elif category == "mov"         : self.VV5lAW(path)
   elif not FF0hai(path)        : FFW3ac(self, path)
 def VV5lAW(self, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   FFhRft(self, refCode)
  except:
   pass
 def VV1IeF(self):
  path = self.VVCv4i(self.VVz4aF())
  action = self.VV4JFV(path)
  if action == 1:
   self.VVjkwD(path)
   FFtXOm(self, "Added", 500)
  elif action == -1:
   self.VVk2wI(path)
   FFtXOm(self, "Removed", 500)
  self.VV4JFV(path)
 def VVjkwD(self, path):
  VVXy7C = self.VVosJt()
  if not VVXy7C:
   VVXy7C = []
  if len(VVXy7C) >= self.MAX_BOOKMARKS:
   FFEW3v(SELF, "Max bookmarks reached (max=%d)." % self.MAX_BOOKMARKS)
  elif not path in VVXy7C:
   VVXy7C = [path] + VVXy7C
   self.VVaNti(VVXy7C)
 def VVRwJF(self):
  VVXy7C = self.VVosJt()
  if VVXy7C:
   newList = []
   for line in VVXy7C:
    newList.append((line, line))
   VVdwgz  = ("Delete"  , self.VV7b5k )
   VV2cC5 = ("Move Up"   , self.VVwlfr )
   VVpjth  = ("Move Down" , self.VVlf12 )
   self.bookmarkMenu = FFue1q(self, self.VVhQWu, title="Bookmarks", VVXWOy=newList, VVdwgz=VVdwgz, VV2cC5=VV2cC5, VVpjth=VVpjth)
 def VV7b5k(self, VVz4aFObj, path):
  if self.bookmarkMenu:
   VVXy7C = self.VVk2wI(path)
   self.bookmarkMenu.VV7l9H(VVXy7C)
 def VVwlfr(self, VVz4aFObj, path):
  if self.bookmarkMenu:
   VVXy7C = self.bookmarkMenu.VVYuBQ(True)
   if VVXy7C:
    self.VVaNti(VVXy7C)
 def VVlf12(self, VVz4aFObj, path):
  if self.bookmarkMenu:
   VVXy7C = self.bookmarkMenu.VVYuBQ(False)
   if VVXy7C:
    self.VVaNti(VVXy7C)
 def VVhQWu(self, folder=None):
  if folder:
   if not folder.endswith("/"):
    folder += "/"
   self["myMenu"].VVtmc4(folder)
   self["myMenu"].moveToIndex(0)
  self.VVqNby()
 def VVosJt(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVTEGG(self, path):
  VVXy7C = self.VVosJt()
  if VVXy7C and path in VVXy7C:
   return True
  else:
   return False
 def VVNse9(self):
  if VVosJt():
   return True
  else:
   return False
 def VVaNti(self, VVXy7C):
  line = ",".join(VVXy7C)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVk2wI(self, path):
  VVXy7C = self.VVosJt()
  if VVXy7C:
   while path in VVXy7C:
    VVXy7C.remove(path)
   self.VVaNti(VVXy7C)
   return VVXy7C
 def VV0Pfy(self, path):
  if not os.path.isdir(path):
   path = FF89XU(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVv9wf(self, selFile, VVRCwb, command):
  FFUzhN(self, boundFunction(FFb6xn, self, command, VVngoh=self.VVwjlY), "%s\n\n%s" % (VVRCwb, selFile))
 def VVMMVf(self, path, calledFromMenu):
  destPath = self.VVTNqw(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVXWOy = []
  if calledFromMenu:
   VVXWOy.append(VVGV45)
   color = VVdNwi
  else:
   color = ""
  VVXWOy.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVXWOy.append(VVGV45)
  VVXWOy.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVXWOy.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVXWOy.append((color + "Extract Here"            , "extract_here"  ))
  if VViQ7B and path.endswith(".tar.gz"):
   VVXWOy.append(VVGV45)
   VVXWOy.append((color + 'Convert to ".ipk" Package' , "VVZJj8"  ))
   VVXWOy.append((color + 'Convert to ".deb" Package' , "VVE5Qt"  ))
  return VVXWOy
 def VVCHXv(self, path, selFile):
  FFue1q(self, boundFunction(self.VVQjbm, path, selFile), title="Tar File Options", VVXWOy=self.VVMMVf(path, False))
 def VVQjbm(self, path, selFile, item=None):
  if item is not None:
   parent  = FF89XU(path, False)
   destPath = self.VVTNqw(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVklh1
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += "echo '';"
     cmd += "unzip -l '%s';" % path
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVklh1, VVklh1)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFAxIC(self, cmd)
   elif path.endswith(".zip"):
    self.VVYZ0b(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFLcOy("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVv9wf(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVv9wf(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FF89XU(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVv9wf(selFile, "Extract Here ?"      , cmd)
   elif item == "VVZJj8" : self.VVZJj8(path)
   elif item == "VVE5Qt" : self.VVE5Qt(path)
 def VVTNqw(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVYZ0b(self, item, path, parent, destPath, VVRCwb):
  FFUzhN(self, boundFunction(self.VVc9Aj, item, path, parent, destPath), VVRCwb)
 def VVc9Aj(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVklh1
  cmd  = FFUIFh("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FF3Nyd(destPath, VVmHHA))
  cmd +=   sep
  cmd += "fi;"
  FFwT7C(self, cmd, VVngoh=self.VVwjlY)
 def VVRQqT(self, addSep=False):
  VVXWOy = []
  if addSep:
   VVXWOy.append(VVGV45)
  VVXWOy.append((VVdNwi + "View Script File"  , "script_View"  ))
  VVXWOy.append((VVdNwi + "Execute Script File" , "script_Execute" ))
  VVXWOy.append((VVdNwi + "Edit"     , "script_Edit" ))
  return VVXWOy
 def VVXcaB(self, path, selFile):
  FFue1q(self, boundFunction(self.VVvSHF, path, selFile), title="Script File Options", VVXWOy=self.VVRQqT())
 def VVvSHF(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFW3ac(self, path)
   elif item == "script_Execute" : self.VVv9wf(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCRFRx(self, path)
 def VVMX6i(self, addSep=False):
  VVXWOy = []
  if addSep:
   VVXWOy.append(VVGV45)
  VVXWOy.append((VVdNwi + "View"      , "m3u_View" ))
  VVXWOy.append((VVdNwi + "Edit"      , "m3u_Edit" ))
  VVXWOy.append((VVdNwi + "Convert to IPTV Bouquet" , "m3u_Convert" ))
  return VVXWOy
 def VVEzOG(self, path, selFile):
  FFue1q(self, boundFunction(self.VVzScvItem_m3u, path, selFile), title="M3U File Options", VVXWOy=self.VVMX6i())
 def VVzScvItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_View"  : FFW3ac(self, path)
   elif item == "m3u_Edit"  : CCRFRx(self, path)
   elif item == "m3u_Convert" : CCzPop.VVWBvT(self, path, False)
 def VVLAws(self, path, selFile, newChmod):
  FFUzhN(self, boundFunction(self.VVdLLn, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVdLLn(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VV1uYF)
  result = FFHvE5(cmd)
  if result == "Successful" : FFJjNb(self, result)
  else      : FFEW3v(self, result)
 def VVcRA4(self, path, selFile):
  parent = FF89XU(path, False)
  self.session.openWithCallback(self.VVwji1, boundFunction(CCMIrG, mode=CCMIrG.BROWSER_MODE_DIR_PICKER, VVvo0t=parent, VV83AD="Create Symlink here"))
 def VVwji1(self, newPath):
  if len(newPath) > 0:
   target = self.VVCv4i(self.VVz4aF())
   target = FFcHPD(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFTsBZ(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFEW3v(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFUzhN(self, boundFunction(self.VVFobL, target, link), "Create Soft Link ?\n\n%s" % txt, VVBim4=True)
 def VVFobL(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VV1uYF)
  result = FFHvE5(cmd)
  if result == "Successful" : FFJjNb(self, result)
  else      : FFEW3v(self, result)
 def VV9hwD(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFiVZt(self, boundFunction(self.VV1FSr, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VV1FSr(self, path, selFile, VV47ip):
  if VV47ip:
   parent = FF89XU(path, True)
   if os.path.isdir(path):
    path = FFcHPD(path)
   newName = parent + VV47ip
   cmd = "mv '%s' '%s' %s" % (path, newName, VV1uYF)
   if VV47ip:
    if selFile != VV47ip:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFUzhN(self, boundFunction(self.VVeaBc, cmd), message, title="Rename file?")
    else:
     FFEW3v(self, "Cannot use same name!", title="Rename")
 def VVeaBc(self, cmd):
  result = FFHvE5(cmd)
  if "Fail" in result:
   FFEW3v(self, result)
  self.VVwjlY()
 def VVKtZ4(self, path, selFile, isMove):
  if isMove : VV83AD = "Move to here"
  else  : VV83AD = "Copy to here"
  parent = FF89XU(path, False)
  self.session.openWithCallback(boundFunction(self.VVtFVV, isMove, path, selFile)
         , boundFunction(CCMIrG, mode=CCMIrG.BROWSER_MODE_DIR_PICKER, VVvo0t=parent, VV83AD=VV83AD))
 def VVtFVV(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFcHPD(path)
   newPath = FFTsBZ(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFUzhN(self, boundFunction(FF2NFl, self, cmd, VVngoh=self.VVwjlY), txt, VVBim4=True)
   else:
    FFEW3v(self, "Cannot %s to same directory !" % action.lower())
 def VVbWa9(self, path, fileName):
  path = FFcHPD(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFUzhN(self, boundFunction(self.VVkUvv, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVkUvv(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("rm %s '%s'" % (opt, path))
  self.VVwjlY()
 def VVvekX(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVqAV4 and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVis3c(self, path, isFile):
  dirName = FFTsBZ(os.path.dirname(path))
  if isFile : objName, VV47ip = "File"  , self.edited_newFile
  else  : objName, VV47ip = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFiVZt(self, boundFunction(self.VVaS70, dirName, isFile, title), title=title, defaultText=VV47ip, message="Enter %s Name:" % objName)
 def VVaS70(self, dirName, isFile, title, VV47ip):
  if VV47ip:
   if isFile : self.edited_newFile = VV47ip
   else  : self.edited_newDir  = VV47ip
   path = dirName + VV47ip
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VV1uYF)
    else  : cmd = "mkdir '%s' %s" % (path, VV1uYF)
    result = FFHvE5(cmd)
    if "Fail" in result:
     FFEW3v(self, result)
    self.VVwjlY()
   else:
    FFEW3v(self, "Name already exists !\n\n%s" % path, title)
 def VVu3v6(self, path, selFile):
  VVXWOy = []
  VVXWOy.append(("List Package Files"          , "VV7Ee9"     ))
  VVXWOy.append(("Package Information"          , "VV9oL4"     ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Install Package"           , "VVrpZQ_CheckVersion" ))
  VVXWOy.append(("Install Package (force reinstall)"      , "VVrpZQ_ForceReinstall" ))
  VVXWOy.append(("Install Package (force downgrade)"      , "VVrpZQ_ForceDowngrade" ))
  VVXWOy.append(("Install Package (ignore failed dependencies)"    , "VVrpZQ_IgnoreDepends" ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Remove Related Package"         , "VVJCJo_ExistingPackage" ))
  VVXWOy.append(("Remove Related Package (force remove)"     , "VVJCJo_ForceRemove"  ))
  VVXWOy.append(("Remove Related Package (ignore failed dependencies)"  , "VVJCJo_IgnoreDepends" ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("Extract Files"           , "VVSQUu"     ))
  VVXWOy.append(("Unbuild Package"           , "VVY3Ox"     ))
  FFue1q(self, boundFunction(self.VVMSsz, path, selFile), VVXWOy=VVXWOy)
 def VVMSsz(self, path, selFile, item=None):
  if item is not None:
   if   item == "VV7Ee9"      : self.VV7Ee9(path, selFile)
   elif item == "VV9oL4"      : self.VV9oL4(path)
   elif item == "VVrpZQ_CheckVersion"  : self.VVrpZQ(path, selFile, VVQ6yh     )
   elif item == "VVrpZQ_ForceReinstall" : self.VVrpZQ(path, selFile, VVXTqa )
   elif item == "VVrpZQ_ForceDowngrade" : self.VVrpZQ(path, selFile, VVF0Dt )
   elif item == "VVrpZQ_IgnoreDepends" : self.VVrpZQ(path, selFile, VVYEWw )
   elif item == "VVJCJo_ExistingPackage" : self.VVJCJo(path, selFile, VVgUUu     )
   elif item == "VVJCJo_ForceRemove"  : self.VVJCJo(path, selFile, VVkVAT  )
   elif item == "VVJCJo_IgnoreDepends"  : self.VVJCJo(path, selFile, VVn1In )
   elif item == "VVSQUu"     : self.VVSQUu(path, selFile)
   elif item == "VVY3Ox"     : self.VVY3Ox(path, selFile)
   else           : self.close()
 def VV7Ee9(self, path, selFile):
  if FFIqu7("ar") : cmd = "allOK='1';"
  else    : cmd  = FF6Afo()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVklh1, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVklh1, VVklh1)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFkvWV(self, cmd, VVngoh=self.VVwjlY)
 def VVSQUu(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FF89XU(path, True) + selFile[:-4]
  cmd  =  FF6Afo()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFLcOy("mkdir '%s'" % dest) + ";"
  cmd +=    FFLcOy("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FF3Nyd(dest, VVmHHA))
  cmd += "fi;"
  FFb6xn(self, cmd, VVngoh=self.VVwjlY)
 def VVY3Ox(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VV4gX1 = os.path.splitext(path)[0]
  else        : VV4gX1 = path + "_"
  if path.endswith(".deb")   : VVuEWI = "DEBIAN"
  else        : VVuEWI = "CONTROL"
  cmd  = FF6Afo()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VV4gX1, FFfno2())
  cmd += "  mkdir '%s';"    % VV4gX1
  cmd += "  CONTPATH='%s/%s';"  % (VV4gX1, VVuEWI)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VV4gX1
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VV4gX1, VV4gX1)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VV4gX1
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VV4gX1, VV4gX1)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VV4gX1
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VV4gX1
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VV4gX1, FF3Nyd(VV4gX1, VVmHHA))
  cmd += "fi;"
  FFb6xn(self, cmd, VVngoh=self.VVwjlY)
 def VV9oL4(self, path):
  listCmd  = FFKs6c(VVWSiA, "")
  infoCmd  = FF2NxH(VVPMTK , "")
  filesCmd = FF2NxH(VVVFn3, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFuLlr(VVFlyn)
   notInst = "Package not installed."
   cmd  = FFsGXc("File Info", VVFlyn)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFsGXc("System Info", VVFlyn)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FF3Nyd(notInst, VVdNwi))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFsGXc("Related Files", VVFlyn)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFAxIC(self, cmd)
  else:
   FFVWVs(self)
 def VVrpZQ(self, path, selFile, cmdOpt):
  cmd = FF2NxH(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFUzhN(self, boundFunction(FFb6xn, self, cmd, VVngoh=FFigte), "Install Package ?\n\n%s" % selFile)
  else:
   FFVWVs(self)
 def VVJCJo(self, path, selFile, cmdOpt):
  listCmd  = FFKs6c(VVWSiA, "")
  infoCmd  = FF2NxH(VVPMTK, "")
  instRemCmd = FF2NxH(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FF3Nyd(errTxt, VVdNwi))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FF3Nyd(cannotTxt, VVdNwi))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FF3Nyd(tryTxt, VVdNwi))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFUzhN(self, boundFunction(FFb6xn, self, cmd, VVngoh=FFigte), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFVWVs(self)
 def VVDFJs(self, path):
  hostName = FFHvE5("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVynvy(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVDFJs(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVow8H(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVXWOy = []
  VVXWOy.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVXWOy.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVXWOy.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVXWOy.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVXWOy.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVXWOy.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVXWOy.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVXWOy.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVXWOy.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVXWOy.append(VVGV45)
  VVXWOy.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVXWOy.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFue1q(self, boundFunction(self.VVh0fd, path), VVXWOy=VVXWOy)
 def VVh0fd(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VV6DZg(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VV6DZg(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VV6DZg(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VV6DZg(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VV6DZg(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VV6DZg(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VV6DZg(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VV6DZg(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VV6DZg(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VV6DZg(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVkV46(path, False)
   elif item == "convertDirToDeb"   : self.VVkV46(path, True)
   else         : self.close()
 def VVkV46(self, path, VVFOlr):
  self.session.openWithCallback(self.VVwjlY, boundFunction(CCnXtk, path=path, VVFOlr=VVFOlr))
 def VV6DZg(self, path, fileExt, preserveDirStruct):
  parent  = FF89XU(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFUIFh("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFUIFh("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFUIFh("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVklh1
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFLcOy("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FF3Nyd(resultFile, VVmHHA))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FF3Nyd(failed, VV7KZt))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFkvWV(self, cmd, VVngoh=self.VVwjlY)
 def VVo6lU(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFW3ac(self, versionFile)
 def VVn9SU(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVDFJs(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFEW3v(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFUM2c(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FF89XU(path, False)
  VV4gX1 = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FF3Nyd(errCmd, VV7KZt))
  installCmd = FF2NxH(VVQ6yh , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VV4gX1, VV4gX1)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VV4gX1
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VV4gX1
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VV4gX1, VV4gX1)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFb6xn(self, cmd, VVngoh=self.VVwjlY)
 def VVZJj8(self, path):
  FFEW3v(self, "Under Construction.")
 def VVE5Qt(self, path):
  FFEW3v(self, "Under Construction.")
class CCba5i(MenuList):
 def __init__(self, VVkq1h=False, directory="/", VVtBl5=True, VV4tCg=True, VVIGjA=True, VVlw6k=None, VV3gJv=False, VVukWo=False, VVavaf=False, isTop=False, VVQTw8=None, VVtFRG=1000, VVH2Qb=30, VV7XV0=30, VVi5S5="#00000000"):
  MenuList.__init__(self, list, VVkq1h, eListboxPythonMultiContent)
  self.VVtBl5  = VVtBl5
  self.VV4tCg    = VV4tCg
  self.VVIGjA  = VVIGjA
  self.VVlw6k  = VVlw6k
  self.VV3gJv   = VV3gJv
  self.VVukWo   = VVukWo or []
  self.VVavaf   = VVavaf or []
  self.isTop     = isTop
  self.additional_extensions = VVQTw8
  self.VVtFRG    = VVtFRG
  self.VVH2Qb    = VVH2Qb
  self.VV7XV0    = VV7XV0
  self.pngBGColor    = FF91hV(VVi5S5)
  self.EXTENSIONS    = self.VV3tau()
  self.VVy14z   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVmgWy, self.VVH2Qb))
  self.l.setItemHeight(self.VV7XV0)
  self.png_mem   = self.VVLruu("mem")
  self.png_usb   = self.VVLruu("usb")
  self.png_fil   = self.VVLruu("fil")
  self.png_dir   = self.VVLruu("dir")
  self.png_dirup   = self.VVLruu("dirup")
  self.png_srv   = self.VVLruu("srv")
  self.png_slwfil   = self.VVLruu("slwfil")
  self.png_slbfil   = self.VVLruu("slbfil")
  self.png_slwdir   = self.VVLruu("slwdir")
  self.VV6pIo()
  self.VVtmc4(directory)
 def VVLruu(self, category):
  return LoadPixmap("%s%s.png" % (VVhwNz, category), getDesktop(0))
 def VV3tau(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u"
  }
 def VV7T2H(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFcHPD(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFW8xd(" -> " , VVFlyn) + FFW8xd(os.readlink(path), VVmHHA)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VV7XV0 + 10, 0, self.VVtFRG, self.VV7XV0, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VV79xv: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV7XV0-4, self.VV7XV0-4, png, self.pngBGColor, self.pngBGColor, VV79xv))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VV7XV0-4, self.VV7XV0-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVRBR4(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VV6pIo(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVQuIN(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVJzXv(self, file):
  if os.path.realpath(file) == file:
   return self.VVQuIN(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVQuIN(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVQuIN(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVBTKZ(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVy14z.info(l[0][0]).getEvent(l[0][0])
 def VV2HrS(self):
  return self.list
 def VVNIFm(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVtmc4(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVIGjA:
    self.current_mountpoint = self.VVJzXv(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVIGjA:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVavaf and not self.VVNIFm(path, self.VVukWo):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VV7T2H(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VV3gJv:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVy14z = eServiceCenter.getInstance()
   list = VVy14z.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVtBl5 and not self.isTop:
   if directory == self.current_mountpoint and self.VVIGjA:
    self.list.append(self.VV7T2H(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVavaf and self.VVQuIN(directory) in self.VVavaf):
    self.list.append(self.VV7T2H(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVtBl5:
   for x in directories:
    if not (self.VVavaf and self.VVQuIN(x) in self.VVavaf) and not self.VVNIFm(x, self.VVukWo):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VV7T2H(name = name, absolute = x, isDir = True, png = png))
  if self.VV4tCg:
   for x in files:
    if self.VV3gJv:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FFW8xd(" -> " , VVFlyn) + FFW8xd(target, VVmHHA)
       else:
        png = self.png_slbfil
        name += FFW8xd(" -> " , VVFlyn) + FFW8xd(target, VV7KZt)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVRBR4(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVhwNz, category))
    if (self.VVlw6k is None) or iCompile(self.VVlw6k).search(path):
     self.list.append(self.VV7T2H(name = name, absolute = x , isDir = False, png = png))
  if self.VVIGjA and len(self.list) == 0:
   self.list.append(self.VV7T2H(name = FFW8xd("No USB connected", VVqb5h), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVhxxE(self):
  return self.current_directory
 def VVGecm(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVtmc4(self.getSelection()[0], select = self.current_directory)
 def VVklcz(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVc1LT(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVzEQy)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVzEQy)
 def refresh(self):
  self.VVtmc4(self.current_directory, self.VVklcz())
 def VVzEQy(self, action, device):
  self.VV6pIo()
  if self.current_directory is None:
   self.refresh()
class CCAGQP(ScrollLabel):
 def __init__(self, parentSELF, text="", VVh5e9=True):
  ScrollLabel.__init__(self, text)
  self.VVh5e9=VVh5e9
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVdX36  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVH2Qb    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close   ,
   "cancel"  : parentSELF.close   ,
   "red"   : self.VVbpAh   ,
   "green"   : self.VVRxA1  ,
   "yellow"  : self.VVzbef  ,
   "blue"   : self.VVTeC4  ,
   "up"   : self.pageUp    ,
   "down"   : self.pageDown    ,
   "left"   : self.pageUp    ,
   "right"   : self.pageDown    ,
   "pageUp"  : self.VVFwCs    ,
   "chanUp"  : self.VVFwCs    ,
   "pageDown"  : self.VVR4JK    ,
   "chanDown"  : self.VVR4JK
  }, -1)
 def VV0fFU(self, isResizable=True, VVL4wo=False, enableSave=False):
  if enableSave:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFjswv(self.parentSELF, True)
  self.isResizable = isResizable
  if VVL4wo:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVH2Qb  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFwL0h(self, color)
 def FFwL0hColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVdX36 - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VV0yz1()
 def pageUp(self):
  if self.VVdX36 > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVdX36 > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVFwCs(self):
  self.setPos(0)
 def VVR4JK(self):
  self.setPos(self.VVdX36-self.pageHeight)
 def VVSKtU(self):
  return self.VVdX36 <= self.pageHeight or self.curPos == self.VVdX36 - self.pageHeight
 def VV0yz1(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVdX36, 3))
   start = int((100 - vis) * self.curPos / (self.VVdX36 - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVTBXk=VVhDR4):
  old_VVSKtU = self.VVSKtU()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VVdX36 = self.long_text.calculateSize().height()
   if self.VVh5e9 and self.VVdX36 > self.pageHeight:
    self.scrollbar.show()
    self.VV0yz1()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVdX36))
   if   VVTBXk == VVaGDj: self.setPos(0)
   elif VVTBXk == VVkxAh : self.VVR4JK()
   elif old_VVSKtU    : self.VVR4JK()
 def appendText(self, text, VVTBXk=VVkxAh):
  self.setText(self.message + str(text), VVTBXk)
 def VVzbef(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVo2Qy(size)
 def VVTeC4(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVo2Qy(size)
 def VVRxA1(self):
  self.VVo2Qy(self.VVH2Qb)
 def VVo2Qy(self, VVH2Qb):
  self.long_text.setFont(gFont(self.fontFamily, VVH2Qb))
  self.setText(self.message, VVTBXk=VVhDR4)
  self.VV0W5a(calledFromFontSizer=True)
 def VVbpAh(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "Save to File"
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_Info_%s.txt" % (FFTsBZ(expPath), FFtouN())
    with open(outF, "w") as f:
     f.write(FFOCgm(self.message))
    FFJjNb(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FFEW3v(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VV0W5a(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer:
   totalCR = self.message.count("\n")
   if totalCR < 20:
    txt = ""
    if not self.message.startswith("\n"): txt = "\n" + self.message
    if not self.message.endswith("\n") : txt += "\n"
    if txt and not len(txt) == len(self.message):
     self.setText(txt)
   elif totalCR < 30:
    self.setText(self.message.strip())
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVdX36
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
