import os
from json      import loads as jLoads
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import log
from time      import localtime, mktime, strftime
from time      import time as iTime
from datetime     import datetime
from base64      import b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVjmQ2   = "v2.5.0"
VV2ELH    = "30-08-2021"
VV0421  = "AJ File Manager"
VVhHgm   = "AJ Live Log (OSCam/NCam)"
EASY_MODE    = 0
VV6Pon   = 0
VV7UC7   = 0
VVxO5U  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVPnB7  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVjHyF    = "/media/usb/"
VVRRk2    = "/usr/share/enigma2/picon/"
VVH4FS   = "/etc/enigma2/"
VVSqx6  = "ajpanel_update_url"
VVzi9Y   = "AJPan"
VVT0Tr    = ""
VVdm9k    = "Regular"
VVfebv      = "-" * 80;
VVPkfI    = (VVfebv, )
VV6lLO    = ""
VVbxGJ   = " && echo 'Successful' || echo 'Failed!'"
VV16xo    = []
VVYidQ     = 0
VVBzWg    = ""
VVSc6q  = False
VV4dZ1  = False
VVk1xP     = 0
VVKQ1t    = 1
VVCMfm    = 2
VVFFPS   = 3
VVw7dT    = 4
VVmTxQ    = 5
VVQGZG = 6
VVlOWi = 7
VVN88w  = 8
VV2aji   = 9
VVeaqQ   = 10
VVtsNg   = 11
VVfOhm  = 12
VVOPX4  = 13
VVn1L0    = 14
VVHFU8   = 15
VVFqyT   = 16
VVGFrO  = 15
VVfHMe   = 0
VVuJnR   = 1
VVsLgX   = 2
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu   = ConfigYesNo(default=False)
CFG.showInExtensionMenu  = ConfigYesNo(default=True)
CFG.showInChannelListMenu = ConfigYesNo(default=True)
CFG.keyboard    = ConfigSelection(default="v", choices = [ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal   = ConfigSelection(default="lesc", choices = [ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.iptvAddToBouquetRefType = ConfigSelection(default="4097", choices = [ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.PIconsPath    = ConfigDirectory(default=VVRRk2, visible_width=51)
CFG.backupPath    = ConfigDirectory(default=VVjHyF, visible_width=51)
CFG.packageOutputPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath  = ConfigText(default="/")
CFG.browserBookmarks   = ConfigText(default="/tmp/,/")
CFG.signalPos    = ConfigInteger(default=5, limits=(1, 9))
CFG.signalSize    = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme  = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup = ConfigYesNo(default=False)
CFG.playerJumpMin   = ConfigInteger(default=5, limits=(1, 10))
def FFgtJT():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVFoJ4  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVyRSN = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVFoJ4  : return 0
  elif VVyRSN : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVZp5T = FFgtJT()
VVdsiT = VVvBji = VVUDh4 = VVepFH = VVTNcj = VVKtLG = VVul8x = VVESyM = COLOR_CONS_BRIGHT_YELLOW = VV3hnc = VVMwfZ = VV4Z4E = ""
def FFBbAg(FFBbAgText="", addSep=True):
 if VV6Pon:
  txt = VVfebv + "\n" if addSep else ""
  txt += ">>>> %s >>  %s" % (PLUGIN_NAME, str(FFBbAgText))
  os.system('echo -e "%s"' % txt)
def FFMYQC(txt, isAppend=True):
 if VV6Pon:
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   f.write(str(txt) + "\n")
  FFBbAg("Output Log File : %s" % fileName)
VV16xo = []
def FFo7Oc(win):
 global VV16xo
 if not win in VV16xo:
  VV16xo.append(win)
def FFe6kn(*args):
 global VV16xo
 for win in VV16xo:
  try:
   win.close()
  except:
   pass
 VV16xo = []
def FFjuVj():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VV70jO = FFjuVj()
def getDescriptor(fnc, where, name=PLUGIN_NAME):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=True, name=name, description=PLUGIN_DESCRIPTION, icon=icon)
def FF6oSK()     : return getDescriptor(FF4ha6   , [ PluginDescriptor.WHERE_PLUGINMENU  ] )
def FFtnLN()  : return getDescriptor(FF4ha6   , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] )
def FFwmPF()  : return getDescriptor(FFuUMT , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , VV0421)
def FF2paM() : return getDescriptor(FFQKBs , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , VVhHgm)
def FFKjnB()    : return getDescriptor(FFtWT3  , [ PluginDescriptor.WHERE_SESSIONSTART  ] )
def FFRP2t()      : return getDescriptor(FFGQ2e  , [ PluginDescriptor.WHERE_MENU    ] )
def Plugins(**kwargs):
 result = [ FF6oSK() , FFRP2t() , FFKjnB() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFtnLN())
  result.append(FFwmPF())
  result.append(FF2paM())
 return result
def FFtWT3(reason, **kwargs):
 if reason == 0:
  FFeQth()
  session = kwargs["session"]
  if session:
   FFOfo2(session)
def FFGQ2e(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FF4ha6, PLUGIN_NAME, 45)]
 else:
  return []
def FF4ha6(session, **kwargs):
 session.open(Main_Menu)
def FFuUMT(session, **kwargs):
 session.open(CC1oiB)
def FFQKBs(session, **kwargs):
 FFOYHw(session, CCmINT.VVhOiX)
def FFCPT9():
 pluginList  = iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU)
 descrPanel  = FFtnLN()
 descrFileMan = FFwmPF()
 descrCamLog  = FF2paM()
 try:
  if CFG.showInExtensionMenu.getValue():
   if not descrPanel    in pluginList : iPlugins.addPlugin(descrPanel)
   if not descrFileMan  in pluginList : iPlugins.addPlugin(descrFileMan)
   if not descrCamLog in pluginList : iPlugins.addPlugin(descrCamLog)
  else:
   if descrPanel   in pluginList  : iPlugins.removePlugin(descrPanel)
   if descrFileMan in pluginList  : iPlugins.removePlugin(descrFileMan)
   if descrCamLog  in pluginList  : iPlugins.removePlugin(descrCamLog)
 except:
  pass
VVUKqo = None
def FFeQth():
 try:
  global VVUKqo
  if VVUKqo is None:
   VVUKqo    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FF1Uwa
  ChannelContextMenu.FFSE6J = FFSE6J
 except:
  pass
def FF1Uwa(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VVUKqo(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFSE6J, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFSE6J, title1, csel, isFind=True))))
def FFSE6J(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFCNiw(refCode)
 except:
  pass
 self.session.open(boundFunction(CC9nXL, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFOfo2(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFxWnA, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFxWnA, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFxWnA, session, "lred")
def FFxWnA(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FFHQ6U(session, isFromSession=True)
def FFEPCp(SELF, title="", addLabel=False, addScrollLabel=False, VVqVzN=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFfHwI()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 if SELF.skinParam["topRightBtns"] > 0:
  SELF["keyMenu2F"]  = Label()
  SELF["keyMenu2"]  = Label("Menu")
  if SELF.skinParam["topRightBtns"] > 1:
   SELF["keyMenu1F"] = Label()
   SELF["keyMenu1"] = Label("Info")
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCmaSB(SELF)
 if VVqVzN:
  SELF["myMenu"] = MenuList(VVqVzN)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVzZWl        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFYjRo(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FFJbw7, SELF, "0") ,
  "1"    : boundFunction(FFJbw7, SELF, "1") ,
  "2"    : boundFunction(FFJbw7, SELF, "2") ,
  "3"    : boundFunction(FFJbw7, SELF, "3") ,
  "4"    : boundFunction(FFJbw7, SELF, "4") ,
  "5"    : boundFunction(FFJbw7, SELF, "5") ,
  "6"    : boundFunction(FFJbw7, SELF, "6") ,
  "7"    : boundFunction(FFJbw7, SELF, "7") ,
  "8"    : boundFunction(FFJbw7, SELF, "8") ,
  "9"    : boundFunction(FFJbw7, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFxFPh, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFJbw7(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VV4Z4E:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VV4Z4E + SELF.keyPressed + VVvBji)
    txt = VVvBji + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FF0fiU(SELF, txt)
def FFxFPh(SELF, tableObj, colNum):
 FF0fiU(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     tableObj.moveToIndex(i)
     SELF.VVCEKi()
     break
 except:
  pass
def FFVBPb(SELF, setMenuAction=True):
 if setMenuAction:
  global VV6lLO
  VV6lLO = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFfHwI():
 return ("  %s" % VV6lLO)
def FFIj9t(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFiZhB(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFcvvP(color):
 return parseColor(color).argb()
def FFaaWy(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFUPS3(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFK62f(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFDI4H(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VV4Z4E)
 else:
  return ""
def FFcBuL(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVfebv, word, VVfebv, VV4Z4E)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVfebv, word, VVfebv)
def FF39Hq(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VV4Z4E
def FFRlBl(color):
 if color: return "echo -e '%s' %s;" % (VVfebv, FFDI4H(VVfebv, VVESyM))
 else : return "echo -e '%s';" % VVfebv
def FFAAb7(title, color):
 title = "%s\n%s\n%s\n" % (VVfebv, title, VVfebv)
 return FF39Hq(title, color)
def FFGE7x(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFDv7i(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FF4YxS(callBackFunction):
 tCons = CCsZDe()
 tCons.ePopen("echo", boundFunction(FFGtzy, callBackFunction))
def FFGtzy(callBackFunction, result, retval):
 callBackFunction()
def FFFe8v(SELF, fnc, title="Processing ...", clearMsg=True):
 FF0fiU(SELF, title)
 tCons = CCsZDe()
 tCons.ePopen("echo", boundFunction(FFoFGr, SELF, fnc, clearMsg))
def FFoFGr(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FF0fiU(SELF)
def FFBul9(cmd):
 from subprocess import Popen, PIPE
 process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
 stdout, stderr = process.communicate()
 stdout = stdout.strip()
 stderr = stderr.strip()
 if stderr : return stderr
 else  : return stdout
def FFGZr4(cmd):
 txt = FFBul9(cmd)
 if txt:
  txt.strip()
  if "\n" in txt:
   txt = txt.splitlines()
   return list(map(str.strip, txt))
  else:
   return [txt]
 else:
  return []
def FFedlY(cmd):
 lines = FFGZr4(cmd)
 if lines: return lines[0]
 else : return ""
def FFt02Z(SELF, cmd):
 lines = FFGZr4(cmd)
 VVKfpb = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVKfpb.append((key, val))
  elif line:
   VVKfpb.append((line, ""))
 if VVKfpb:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFqaCW(SELF, None, header=header, VVnxKJ=VVKfpb, VVf6S2=widths, VVzQkv=22)
 else:
  FFpBIq(SELF, cmd)
def FFpBIq(    SELF, cmd, **kwargs): SELF.session.open(CCwtHp, VV4umH=cmd, VVbEEx=True, VVNp8T=VVuJnR, **kwargs)
def FFdjGT(  SELF, cmd, **kwargs): SELF.session.open(CCwtHp, VV4umH=cmd, **kwargs)
def FFSs3o(   SELF, cmd, **kwargs): SELF.session.open(CCwtHp, VV4umH=cmd, VVYwzK=True, VVj2aH=True, VVNp8T=VVuJnR, **kwargs)
def FFrPjR(  SELF, cmd, **kwargs): SELF.session.open(CCwtHp, VV4umH=cmd, VVYwzK=True, VVj2aH=True, VVNp8T=VVsLgX, **kwargs)
def FFFM6I(  SELF, cmd, **kwargs): SELF.session.open(CCwtHp, VV4umH=cmd, VVjizR=True , **kwargs)
def FFkRWX( SELF, cmd, **kwargs): SELF.session.open(CCwtHp, VV4umH=cmd, VVX7yx=True   , **kwargs)
def FFofxf( SELF, cmd, **kwargs): SELF.session.open(CCwtHp, VV4umH=cmd, VVbXZi=True  , **kwargs)
def FFhmFU(cmd):
 return cmd + " > /dev/null 2>&1"
def FFfSWi():
 return " > /dev/null 2>&1"
def FFyoqC(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFvH88(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "/bin"
    , "/boot"
    , "/dev"
    , "/hdd"
    , "/home"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/picon"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FF5iuo():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFedlY(cmd)
VVCvwl     = 0
VVHCkj      = 1
VVgzHK   = 2
VVuVVp      = 3
VVbbcC      = 4
VVQTgL     = 5
VVEmKG     = 6
VVxMeg  = 7
VVveCC = 8
VVEjfp  = 9
VVLc03     = 10
VVxKpM  = 11
VVHZM0  = 12
def FFjZGS(parmNum, grepTxt):
 if   parmNum == VVCvwl  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVHCkj   : param = ["list"   , "apt list" ]
 elif parmNum == VVgzHK: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FF5iuo()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFxt6o(parmNum, package):
 if   parmNum == VVuVVp      : param = ["info"      ,"apt show"          ]
 elif parmNum == VVbbcC      : param = ["files"      ,"dpkg -L"          ]
 elif parmNum == VVQTgL     : param = ["download"     ,"apt-get download"        ]
 elif parmNum == VVEmKG     : param = ["install"     ,"apt-get install -y"       ]
 elif parmNum == VVxMeg  : param = ["install --force-reinstall" ,"apt-get install --reinstall -y"    ]
 elif parmNum == VVveCC : param = ["install --force-downgrade" ,"apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVEjfp  : param = ["install --force-depends" ,"apt-get install --no-install-recommends -y" ]
 elif parmNum == VVLc03     : param = ["remove"      ,"apt-get purge --auto-remove -y"    ]
 elif parmNum == VVxKpM  : param = ["remove --force-remove"  ,"dpkg --purge --force-all"      ]
 elif parmNum == VVHZM0  : param = ["remove --force-depends"  ,"dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FF5iuo()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFwjGA():
 result = FFedlY("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFxt6o(VVEmKG , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFhmFU("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFhmFU("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFDI4H(failed1, VVESyM))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFDI4H(failed2, VVESyM))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFDI4H(failed3, VVUDh4))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFIEas(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFxt6o(VVEmKG , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFhmFU("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFDI4H(failed1, VVESyM))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFDI4H(failed2, VVUDh4))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FF0KEj(timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect(("1.1.1.1", 53))
  return True
 except:
  return False
def FF7gKM(path, maxSize=-1):
 from io import open as ioOpen
 encodings = (None, "utf-8", "ISO8859-15", 'iso6937', "windows-1250", "windows-1252")
 txt = ""
 for enc in encodings:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FF709T(path, keepends=False, maxSize=-1):
 lines = FF7gKM(path, maxSize)
 return lines.splitlines(keepends)
def FFuyab(SELF, path):
 title = FFfHwI()
 if fileExists(path):
  fSize = os.path.getsize(path)
  maxSize = 60000
  if (fSize > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FF709T(path, maxSize=maxSize)
  if lines: FFcui4(SELF, lines, title=title, VVNp8T=VVuJnR)
  else : FFYN1B(SELF, path, title=title)
 else:
  FFQJvo(SELF, path, title)
def FF0K3L(SELF, path, title):
 if fileExists(path):
  txt = FF7gKM(path)
  txt = txt.replace("#W#", VV4Z4E)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVvBji)
  txt = txt.replace("#C#", VV3hnc)
  txt = txt.replace("#P#", VVepFH)
  FFcui4(SELF, txt, title=title)
 else:
  FFQJvo(SELF, path, title)
def FFWywO(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FF4zd5(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFgmeM(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FFRJ2W(parent)
 else    : return FFdjQ5(parent)
def FFHO0G(path):
 try:
  return os.path.getsize(path)
 except:
  return 0
def FFRJ2W(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFdjQ5(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FF3Nbo():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVxO5U)
 paths.append(VVxO5U.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FF4zd5(ba)
 for p in list:
  p = ba + p + VVxO5U
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVzi9Y, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVxO5U, VVzi9Y , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVxJlC, VVLdJi = FF3Nbo()
def FFDH09():
 def VV0KZU(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 VVCw0b  = VV0KZU(CFG.backupPath, CCX1EL.VV12tJ())
 VVt4xX  = VV0KZU(CFG.downloadedPackagesPath, t)
 VVvdpU = VV0KZU(CFG.exportedTablesPath, t)
 VVUAX3 = VV0KZU(CFG.exportedPIconsPath, t)
 VVDbcm  = VV0KZU(CFG.packageOutputPath, t)
 global VVjHyF
 VVjHyF = FFRJ2W(CFG.backupPath.getValue())
 if VVCw0b or VVDbcm or VVt4xX or VVvdpU or VVUAX3:
  configfile.save()
 return VVCw0b, VVDbcm, VVt4xX, VVvdpU, VVUAX3
def FFQtYX(path):
 path = FFdjQ5(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFhebi(SELF, pathList, tarFileName, addTimeStamp=True):
 VVnxKJ = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVnxKJ.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVnxKJ.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVnxKJ.append(path)
 if not VVnxKJ:
  FFj9Oj(SELF, "Files not found!")
 elif not pathExists(VVjHyF):
  FFj9Oj(SELF, "Path not found!\n\n%s" % VVjHyF)
 else:
  VVXmtK = FFRJ2W(VVjHyF)
  tarFileName = "%s%s" % (VVXmtK, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFCy03())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVnxKJ:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVfebv
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFDI4H(tarFileName, VVul8x))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFDI4H(failed, VVul8x))
  cmd += "fi;"
  cmd +=  sep
  FFdjGT(SELF, cmd)
def FFKnNz(SELF, title, VVhesn):
 SELF.session.open(boundFunction(CCMtHS, Title=title, VVhesn=VVhesn))
def FF20Za(labelObj, VVhesn):
 if VVhesn and fileExists(VVhesn):
  try:
   from enigma import ePicLoad
   scaleX, scaleY = 1, 1
   picLoad = ePicLoad()
   def VVQpQ9(pictureInfo=""):
    labelObj.instance.setPixmap(picLoad.getData())
   picLoad.PictureData.get().append(VVQpQ9)
   picLoad.setPara([labelObj.instance.size().width(), labelObj.instance.size().height(), scaleX, scaleY, 0, 1, "#1100002a"])
   picLoad.startDecode(VVhesn)
   return True
  except:
   pass
 return False
def FF16jJ(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFzEOF(satNum)
  return satName
def FFzEOF(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFIEWh(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FF16jJ(val)
  else  : sat = FFzEOF(val)
 return sat
def FFFdtD(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FF16jJ(num)
 except:
  pass
 return sat
def FFgDL3(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFiz95(SELF, isFromSession=None):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFk7cY(info, iServiceInformation.sServiceref)
   prov = FFk7cY(info, iServiceInformation.sProvider)
   state = str(FFk7cY(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFzufs(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFq3e7(refCode)
 return info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFk7cY(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFxYrs(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFCNiw(refCode):
 info = FFs4CC(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFhqUM(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFnMHY(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFs4CC(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVgANK = eServiceCenter.getInstance()
  if VVgANK:
   info = VVgANK.info(service)
 return info
def FFj5dK(SELF, refCode, VVxOas=True, checkParentalControl=False):
 if not refCode.endswith(":"):
  refCode += ":"
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  SELF.session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
  if VVxOas:
   FFHQ6U(SELF)
 try:
  VVW3zD = InfoBar.instance
  if VVW3zD:
   VVGkgl = VVW3zD.servicelist
   if VVGkgl:
    servRef = eServiceReference(refCode)
    VVGkgl.saveChannel(servRef)
 except:
  pass
def FFzufs(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFq3e7(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FF67mR(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFun7D(userBfile):
 txt = ""
 bFile = VVH4FS + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVH4FS + userBfile):
  fTxt = FF7gKM(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFedlY('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
 return
def FF67mR(url):
 if iUnquote : return iUnquote(url)
 else  : return url
def FFVVb6(url):
 if iQuote : return iQuote(url)
 else  : return url
def FFHQ6U(SELF, isFromSession=None):
 if isFromSession: session = SELF
 else   : session = SELF.session
 info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiz95(SELF, isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CCFtnG)
 else      : FFuQsM(session, True)
def FFuQsM(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFuQsM, session), CCuGxf)
  except:
   try:
    FFjSKw(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFhKNX(refCode):
 tp = CCRdiH()
 if tp.VVOYq2(refCode) : return True
 else        : return False
def FFlRJL(refCode, isHide):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FF89ZG():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FF0ci0():
 VVW3zD = InfoBar.instance
 if VVW3zD:
  VVGkgl = VVW3zD.servicelist
  if VVGkgl:
   return VVGkgl.getBouquetList()
 return None
def FF0fvT(root):
 services = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVgANK = eServiceCenter.getInstance()
  services  = []
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVgANK.info(service)
    services.append((service.toString(), info.getName(service)))
 except:
  pass
 return services
def FFIHPD():
 VVI06l = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VVzLy1 = list(VVI06l)
 return VVzLy1, VVI06l
def FF0Wsq():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFOYHw(session, VVIDkW):
 VV1GXQ, VVoaeg, VV7W0n, camCommand = FF1Hig()
 if VVoaeg:
  runLog = False
  if   VVIDkW == CCmINT.VVdxVH : runLog = True
  elif VVIDkW == CCmINT.VVCTde : runLog = True
  elif not VV7W0n          : FFjSKw(session, message="SoftCam not started yet!")
  elif fileExists(VV7W0n)        : runLog = True
  else             : FFjSKw(session, message="File not found !\n\n%s" % VV7W0n)
  if runLog:
   session.open(boundFunction(CCmINT, VV1GXQ=VV1GXQ, VVoaeg=VVoaeg, VV7W0n=VV7W0n, VVIDkW=VVIDkW))
 else:
  FFjSKw(session, message="No active OSCam/NCam found !")
def FF1Hig():
 VV1GXQ = "/etc/tuxbox/config/"
 VVoaeg = None
 VV7W0n  = None
 camCommand = FFedlY("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVoaeg = "oscam"
 elif "ncam"  in camCommand : VVoaeg = "ncam"
 if VVoaeg:
  path = FFedlY(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FFRJ2W(path)
  if pathExists(path):
   VV1GXQ = path
  tFile = VV1GXQ + VVoaeg + ".conf"
  tFile = FFedlY("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VV7W0n = tFile
 return VV1GXQ, VVoaeg, VV7W0n, camCommand
def FFXglk(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFW5Nh():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFCy03():
 return FFW5Nh().replace(" ", "_").replace("-", "").replace(":", "")
def FF7B8o(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFarie(url, outFile, timeout=3):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CC2RcG.VV4GkZ(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CC2RcG.VVQEvg(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFhmFU("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFztHE(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFbs3Q(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFa6cL():
 return int(FFBul9("cat /proc/meminfo | grep MemFree | awk '{print $2}'"))
def FFxtCg():
 global VVYidQ_TIME, VVBzWg
 VVBzWg  = int(FFa6cL())
 VVYidQ_TIME = iTime()
def FFZxpi():
 elapsed = iTime() - VVYidQ_TIME
 elapsed = "{:.6f}".format(elapsed).rstrip("0").rstrip(".")
 mem  = FFa6cL() - VVBzWg
 FFBbAg(">>>>>> Elapsed\t: {} seconds ... Memory\t: {} bytes".format(elapsed, mem))
def FFhXFJ(SELF, message, title=""):
 SELF.session.open(boundFunction(CCQ1fn, title=title, message=message, VVdzWD=True))
def FFcui4(SELF, message, title="", VVNp8T=VVuJnR, **kwargs):
 SELF.session.open(boundFunction(CCQ1fn, title=title, message=message, VVNp8T=VVNp8T, **kwargs))
def FFj9Oj(SELF, message, title="")  : FFjSKw(SELF.session, message, title)
def FFQJvo(SELF, path, title="") : FFjSKw(SELF.session, "File not found !\n\n%s" % path, title)
def FFYN1B(SELF, path, title="") : FFjSKw(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFhggE(SELF, title="")  : FFjSKw(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFjSKw(session, message, title="") : session.open(boundFunction(CCnFDm, title=title, message=message))
def FFxR0u(SELF, VVBijC, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVBijC, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVBijC, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVBijC, boundFunction(CCwpdR, title=title, message=message, VVNYr8=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFj9Oj(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFi0Lh(SELF, callBack_Yes, VVG82G, callBack_No=None, title="", VVEE7G=False):
 SELF.session.openWithCallback(boundFunction(FFgQEI, callBack_Yes, callBack_No)
        , boundFunction(CCKvo2, title=title, VVG82G=VVG82G, VVWODa=True, VVEE7G=VVEE7G))
def FFgQEI(callBack_Yes, callBack_No, FFi0Lhed):
 if FFi0Lhed : callBack_Yes()
 elif callBack_No: callBack_No()
def FF0fiU(SELF, message="", milliSeconds=0):
 try:
  SELF["myInfoBody"].setText(str(message))
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFfraW(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFjMv5(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
myTimer = eTimer()
def FFfraW(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFO3dc, SELF))
 try:
  myTimer_conn = myTimer.timeout.connect(boundFunction(FFO3dc, SELF))
 except:
  myTimer.callback.append(boundFunction(FFO3dc, SELF))
 myTimer.start(milliSeconds, 1)
def FFO3dc(SELF):
 myTimer.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFqaCW(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCc5fD, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCc5fD, **kwargs))
  FFo7Oc(win)
  return win
 except:
  return None
def FFbvqQ(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CC5JP6, **kwargs))
 FFo7Oc(win)
 return win
def FFbkgB(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   obj = SELF[name]
   SELF[name].instance.setBorderColor(parseColor("#000000"))
   SELF[name].instance.setBorderWidth(3)
   SELF[name].instance.setNoWrap(True)
  except:
   pass
def FFpxSp(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVdm9k, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFmktH(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFpxSp(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FF1qMk():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFaaJY(VVzQkv):
 screenSize  = FF1qMk()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVzQkv)
 return bodyFontSize
def FF7whL(VVzQkv, extraSpace):
 font = gFont(VVdm9k, VVzQkv)
 VVRsNa = fontRenderClass.getInstance().getLineHeight(font) or (VVzQkv * 1.25)
 return int(VVRsNa + VVRsNa * extraSpace)
def FFJjah(fontName):
 fList = None
 try:
  from enigma import getFontFaces
  fList = getFontFaces()
 except:
  try:
   from skin import getFontFaces
   fList = getFontFaces()
  except:
   pass
 if fList and fontName in fList : return fontName
 else       : return VVdm9k
def FFm81W(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FF1qMk()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * VVGFrO)
 bodyFontStr  = 'font="%s;%d"' % (VVdm9k, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FF7whL(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVdm9k, titleFontSize, alignLeftCenter)
 if winType == VVk1xP or winType == VVKQ1t:
  if winType == VVKQ1t : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVn1L0:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.2)
  b2Left1 = marginLeft
  b2Left2 = b2Left1 + timeW + marginLeft
  b2Left3 = width - marginLeft - timeW
  infW = b2Left3 - b2Left2 - marginLeft
  tmp += '<widget name="myPlayBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="myPlayBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" />'   % (marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyColor)
  tmp += '<widget name="myPlayBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a005555" />' % (marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="myPlayBarM"  position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="myPlayVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="#0a002233" %s %s'   % (bodyFontStr, alignCenter)
  tmp += '<widget name="myPlayPos"  position="%d,%d" size="%d,%d" %s />' % (b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlayMsg"  position="%d,%d" size="%d,%d" %s />' % (b2Left2, b2Top, infW , barH, param)
  tmp += '<widget name="myPlayDur"  position="%d,%d" size="%d,%d" %s />' % (b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep"   position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  names = ["Jmp", "Skp", "Mrk", "Blu", "Inf"]
  b3W  = int((width - marginLeft * 6.0) / 5.0)
  left = marginLeft
  for i in range(5):
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" foregroundColor="#0affffff" backgroundColor="#11222222" %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter)
   left += b3W + marginLeft
 elif winType == VVHFU8:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVw7dT:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVCMfm:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVFFPS:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVdm9k, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVdm9k, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVeaqQ:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFhXFJH = int(bodyH * 0.5)
  inpTop = bodyTop + FFhXFJH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFhXFJH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVdm9k, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVdm9k, mapF, alignCenter)
 elif winType == VVtsNg:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVfOhm:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVdm9k, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVFqyT:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVdm9k, fontH, alignCenter)
 elif winType == VVOPX4:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVdm9k, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVdm9k, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVdm9k, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 else:
  if   winType == VVlOWi : align = alignLeftCenter
  elif winType == VVQGZG : align = alignLeftTop
  else          : align = alignCenter
  if winType == VV2aji:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  if winType == VVmTxQ:
   moreParams = ""
  else:
   fontStr = bodyFontStr
   if usefixedFont and winType == VVQGZG:
    fontStr = 'font="%s;%d"' % (FFJjah("Fixed"), bodyFontSize)
   moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" %s %s ' % (bodyColor, fontStr, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVzQkv = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVdm9k, VVzQkv, alignCenter)
 if topRightBtns > 0:
  btnW = int(ratioW * 80)
  btnH = int(titleH * 0.7)
  btnTop = int(titleH * 0.15)
  btnLeft = width - (btnW + btnTop)
  btnFont = int(btnH * 0.6)
  tmp += '<widget name="keyMenu2F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
  tmp += '<widget name="keyMenu2"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VVdm9k, btnFont, alignCenter)
  if topRightBtns > 1:
   btnLeft = btnLeft - btnW - 8
   tmp += '<widget name="keyMenu1F" position="%d,%d" size="%d,%d" zPosition="7" backgroundColor="#ffffff" />' % (btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="keyMenu1"  position="%d,%d" size="%d,%d" zPosition="8" backgroundColor="#444444" font="%s;%d" foregroundColor="white" %s />' % (btnLeft+1, btnTop+1, btnW-2, btnH-2, VVdm9k, btnFont, alignCenter)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VVCMEX = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVdm9k, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VVCMEX[i], VVdm9k, barFont, alignCenter)
   left += btnW + gap
 if winType == VVQGZG:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VVCMEX = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVCMEX[i], VVdm9k, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFm81W(VVk1xP, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.hiddenMenuPass = ""
  self.themsList  = []
  VVqVzN = []
  if VV7UC7:
   VVqVzN.append(("-- MY TEST --"    , "myTest"   ))
  VVqVzN.append(("File Manager"      , "FileManager"  ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Services/Channels"    , "ChannelsTools" ))
  VVqVzN.append(("IPTV"        , "IptvTools"  ))
  VVqVzN.append(("PIcons"       , "PIconsTools"  ))
  VVqVzN.append(("SoftCam"       , "SoftCam"   ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Plugins"       , "PluginsTools" ))
  VVqVzN.append(("Terminal"       , "Terminal"  ))
  VVqVzN.append(("Backup & Restore"     , "BackupRestore" ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Date/Time"      , "Date_Time"  ))
  VVqVzN.append(("Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVqVzN)
  FFEPCp(self, VVqVzN=VVqVzN)
  FFIj9t(self["keyRed"] , "Exit")
  FFIj9t(self["keyGreen"] , "Settings")
  FFIj9t(self["keyYellow"], "Dev. Info.")
  FFIj9t(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVSinj       ,
   "yellow"  : self.VV2zri       ,
   "blue"   : self.VV3x0g       ,
   "info"   : self.VV3x0g       ,
   "next"   : self.VV7Wj3       ,
   "0"    : boundFunction(self.VV4PGa, 0) ,
   "1"    : boundFunction(self.VVzmDi, 1)   ,
   "2"    : boundFunction(self.VVzmDi, 2)   ,
   "3"    : boundFunction(self.VVzmDi, 3)   ,
   "4"    : boundFunction(self.VVzmDi, 4)   ,
   "5"    : boundFunction(self.VVzmDi, 5)   ,
   "6"    : boundFunction(self.VVzmDi, 6)   ,
   "7"    : boundFunction(self.VVzmDi, 7)   ,
   "8"    : boundFunction(self.VVzmDi, 8)   ,
   "9"    : boundFunction(self.VVzmDi, 9)
  })
  self.onShown.append(self.VVOs7w)
  self.onClose.append(self.onExit)
  global VVSc6q, VV4dZ1
  VVSc6q = VV4dZ1 = False
 def VVzZWl(self):
  item = FFVBPb(self)
  self.VVzmDi(item)
 def VVzmDi(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVeEnd()
   elif item in ("FileManager"  , 1) : self.session.open(CC1oiB)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCxXMf)
   elif item in ("IptvTools"  , 3) : self.session.open(CC2RcG)
   elif item in ("PIconsTools"  , 4) : self.VVruGZ()
   elif item in ("SoftCam"   , 5) : self.session.open(CC9StB)
   elif item in ("PluginsTools" , 6) : self.session.open(CCZLbi)
   elif item in ("Terminal"  , 7) : self.session.open(CCAYul)
   elif item in ("BackupRestore" , 8) : self.session.open(CC4UP2)
   elif item in ("Date_Time"  , 9) : self.session.open(CCpRMz)
   elif item in ("CheckInternet" , 10) : self.session.open(CCRI0y)
   else         : self.close()
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  FFGE7x(self["myMenu"])
  FFmktH(self)
  FFbkgB(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVjmQ2)
  self["myTitle"].setText(title)
  VVCw0b, VVDbcm, VVt4xX, VVvdpU, VVUAX3 = FFDH09()
  self.VVTsoc()
  if VVCw0b or VVDbcm or VVt4xX or VVvdpU or VVUAX3:
   VVp8k8 = lambda path, subj: "%s:\n%s\n\n" % (subj, FF39Hq(path, VVUDh4)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVp8k8(VVCw0b   , "Backup/Restore Path"    )
   txt += VVp8k8(VVDbcm  , "Created Package Files (IPK/DEB)" )
   txt += VVp8k8(VVt4xX  , "Download Packages (from feeds)" )
   txt += VVp8k8(VVvdpU , "Exported Tables"     )
   txt += VVp8k8(VVUAX3 , "Exported PIcons"     )
   txt += "\nYou can change paths from Settings.\n"
   FFcui4(self, txt, title="Settings Paths")
  if (EASY_MODE or VV6Pon or VV7UC7):
   FFUPS3(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FF0fiU(self, "Welcome", 300)
  FF4YxS(boundFunction(self.VViD3d, title))
 def VViD3d(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCX1EL.VVyJsH()
   if url:
    newWebVer = CCX1EL.VV1UtK(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFhmFU("rm /tmp/ajpanel*"))
 def VV4PGa(self, digit):
  self.hiddenMenuPass += str(digit)
  if len(self.hiddenMenuPass) == 4:
   if self.hiddenMenuPass == "0" * 4:
    global VVSc6q
    VVSc6q = True
    FFUPS3(self["myTitle"], "#800080")
   else:
    self.hiddenMenuPass = "x"
 def VV7Wj3(self):
  self.hiddenMenuPass += ">"
  if self.hiddenMenuPass == ("0" * 4) + ">>":
   global VV4dZ1
   VV4dZ1 = True
   FFUPS3(self["myTitle"], "#dd5588")
 def VVruGZ(self):
  found = False
  pPath = CC6Hdl.VVH2R4()
  if pathExists(pPath):
   for fName, fType in CC6Hdl.VVB9DD(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CC6Hdl)
  else:
   VVqVzN = []
   VVqVzN.append(("PIcons Manager"          , "CC6Hdl"    ))
   VVqVzN.append(VVPkfI)
   VVqVzN.append(CC6Hdl.VVl7Iz())
   VVqVzN.append(VVPkfI)
   VVqVzN += CC6Hdl.VVYCXL()
   FFbvqQ(self, self.VVIMHK, VVqVzN=VVqVzN)
 def VVIMHK(self, item=None):
  if item:
   if   item == "CC6Hdl"   : self.session.open(CC6Hdl)
   elif item == "VV3vYD"  : CC6Hdl.VV3vYD(self)
   elif item == "VVPj7u"  : CC6Hdl.VVPj7u(self)
   elif item == "findPiconBrokenSymLinks" : CC6Hdl.VVlwob(self, True)
   elif item == "FindAllBrokenSymLinks" : CC6Hdl.VVlwob(self, False)
 def VVSinj(self):
  self.session.open(CCX1EL)
 def VV2zri(self):
  self.session.open(CCkt5E)
 def VV3x0g(self):
  changeLogFile = VVLdJi + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   txt += "Change Log:\n"
   lines  = FF709T(changeLogFile)
   for line in lines:
    if not line == "" and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FF39Hq("\n%s\n%s\n%s" % (VVfebv, line, VVfebv), VVepFH, VV4Z4E)
     elif line.strip().startswith("-"):
      line = "\n" + line
     elif line.strip().startswith(".."):
      line = FF39Hq(line, VVvBji, VV4Z4E)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFcui4(self, txt, title="%s - %s - %s" % (PLUGIN_NAME, PLUGIN_DESCRIPTION , VVjmQ2), VVzQkv=26)
 def VVTsoc(self):
  p = VVjHyF + "ajpanel_colors"
  if fileExists(p):
   txt = FF7gKM(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    try:
     if   txt == "main_title_fg" : FFaaWy(self["myTitle"], c)
     elif txt == "main_title_bg" : FFUPS3(self["myTitle"], c)
     elif txt == "main_body_fg" : FFaaWy(self["myMenu"], c)
     elif txt == "main_body_bg" :
      FFUPS3(self["myBody"], c)
      FFUPS3(self["myMenu"], c)
     elif txt == "main_cursor_fg" : self["myMenu"].instance.setForegroundColorSelected(parseColor(c))
     elif txt == "main_cursor_bg" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(c))
     elif txt == "main_bar_bg"  : FFUPS3(self["myBar"], c)
    except:
     pass
 def VVeEnd(self):
  opt = 11
  if   opt ==  0 : FFhXFJ(self, "This is My Message.", "Testing")
  elif opt == 11:
   pass
class CCkt5E(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFm81W(VVk1xP, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVqVzN = []
  VVqVzN.append(("Settings File"        , "SettingsFile"   ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Box Info"          , "VV3NVH"    ))
  VVqVzN.append(("Tuners Info"         , "VVmTNL"   ))
  VVqVzN.append(("Python Version"        , "VVvMoa"   ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Screen Size"         , "ScreenSize"    ))
  VVqVzN.append(("Locale"          , "Locale"     ))
  VVqVzN.append(("Processor"         , "Processor"    ))
  VVqVzN.append(("Operating System"        , "OperatingSystem"   ))
  VVqVzN.append(("Drivers"          , "drivers"     ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("System Users"         , "SystemUsers"    ))
  VVqVzN.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVqVzN.append(("Uptime"          , "Uptime"     ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Host Name"         , "HostName"    ))
  VVqVzN.append(("MAC Address"         , "MACAddress"    ))
  VVqVzN.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVqVzN.append(("Network Status"        , "NetworkStatus"   ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Disk Usage"         , "VVpLn5"    ))
  VVqVzN.append(("Mount Points"         , "MountPoints"    ))
  VVqVzN.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVqVzN.append(("USB Devices"         , "USB_Devices"    ))
  VVqVzN.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVqVzN.append(("Directory Size"        , "DirectorySize"   ))
  VVqVzN.append(("Memory"          , "Memory"     ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVqVzN.append(("Running Processes"       , "RunningProcesses"  ))
  VVqVzN.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FFEPCp(self, VVqVzN=VVqVzN, title="Device Information")
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  FFGE7x(self["myMenu"])
  FFmktH(self)
 def VVzZWl(self):
  global VV6lLO
  VV6lLO = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CC9q9O)
   elif item == "VV3NVH"    : self.VV3NVH()
   elif item == "VVmTNL"   : self.VVmTNL()
   elif item == "VVvMoa"   : self.VVvMoa()
   elif item == "ScreenSize"    : FFcui4(self, "Width\t: %s\nHeight\t: %s" % (FF1qMk()[0], FF1qMk()[1]))
   elif item == "Locale"     : self.VVTDjg()
   elif item == "Processor"    : self.VV6hob()
   elif item == "OperatingSystem"   : FFpBIq(self, "uname -a"        )
   elif item == "drivers"     : self.VVsfeV()
   elif item == "SystemUsers"    : FFpBIq(self, "id"          )
   elif item == "LoggedInUsers"   : FFpBIq(self, "who -a"         )
   elif item == "Uptime"     : FFpBIq(self, "uptime"         )
   elif item == "HostName"     : FFpBIq(self, "hostname"        )
   elif item == "MACAddress"    : self.VV5jlU()
   elif item == "NetworkConfiguration"  : FFpBIq(self, "ifconfig %s %s" % (FFDI4H("HWaddr", VVMwfZ), FFDI4H("addr:", VVESyM)))
   elif item == "NetworkStatus"   : FFpBIq(self, "netstat -tulpn"       )
   elif item == "VVpLn5"    : self.VVpLn5()
   elif item == "MountPoints"    : FFpBIq(self, "mount %s" % (FFDI4H(" on ", VVESyM)))
   elif item == "FileSystemTable"   : FFpBIq(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FFpBIq(self, "lsusb"         )
   elif item == "listBlockDevices"   : FFpBIq(self, "blkid"         )
   elif item == "DirectorySize"   : FFpBIq(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVl4G8="Reading size ...")
   elif item == "Memory"     : FFpBIq(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVMB9B()
   elif item == "RunningProcesses"   : FFpBIq(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FFpBIq(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVqIxM()
   else         : self.close()
 def VV5jlU(self):
  res = FFBul9("ip link")
  list = iFindall("[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFcui4(self, txt)
  else:
   FFpBIq(self, "ip link")
 def VVZGKB(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFGZr4(cmd)
  return lines
 def VVa85C(self, lines, headerRepl, widths, VVfxos):
  VVKfpb = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVKfpb.append(parts)
  if VVKfpb and len(header) == len(widths):
   VVKfpb.sort(key=lambda x: x[0].lower())
   FFqaCW(self, None, header=header, VVnxKJ=VVKfpb, VVfxos=VVfxos, VVf6S2=widths, VVzQkv=22, VVjJ5Z=True)
   return True
  else:
   return False
 def VVpLn5(self):
  cmd   = "df -h"
  headerRepl = "Mounted on"
  lines  = self.VVZGKB(cmd, headerRepl, 6, False)
  widths  = (30 , 10 , 9  , 10 , 8  , 33 )
  VVfxos = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
  allOK = self.VVa85C(lines, headerRepl, widths, VVfxos)
  if not allOK:
   lines = FFGZr4(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFdjQ5(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVul8x:
     note = "\n%s" % FF39Hq("Green = Mounted Partitions", VVul8x)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVESyM
     elif line.endswith(mountList) : color = VVul8x
     else       : color = VVvBji
     txt += FF39Hq(line, color) + "\n"
    FFcui4(self, txt + note)
   else:
    FFj9Oj(self, "Not data from system !")
 def VVMB9B(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVZGKB(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVfxos = (LEFT , CENTER, LEFT )
  allOK = self.VVa85C(lines, headerRepl, widths, VVfxos)
  if not allOK:
   FFpBIq(self, cmd)
 def VVTDjg(self):
  from locale import getdefaultlocale
  loc = getdefaultlocale()
  FFcui4(self, "Language\t: %s\nEncoding\t: %s" % (loc[0], loc[1]))
 def VVsfeV(self):
  cmd = FFjZGS(VVgzHK, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFpBIq(self, cmd)
  else : FFhggE(self)
 def VV6hob(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFpBIq(self, cmd)
 def VVqIxM(self):
  cmd = FFjZGS(VVHCkj, "| grep secondstage")
  if cmd : FFpBIq(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFhggE(self)
 def VV3NVH(self):
  c = VVul8x
  VVnxKJ = []
  VVnxKJ.append((FF39Hq("Box Type"  , c), FF39Hq(self.VV5vPk("boxtype").upper(), c)))
  VVnxKJ.append((FF39Hq("Board Version", c), FF39Hq(self.VV5vPk("board_revision") , c)))
  VVnxKJ.append((FF39Hq("Chipset"  , c), FF39Hq(self.VV5vPk("chipset")  , c)))
  VVnxKJ.append((FF39Hq("S/N"   , c), FF39Hq(self.VV5vPk("sn")    , c)))
  VVnxKJ.append((FF39Hq("Version"  , c), FF39Hq(self.VV5vPk("version")  , c)))
  VVIbOZ   = []
  VVIfIt = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVIfIt = SystemInfo[key]
     else:
      VVIbOZ.append((FF39Hq(str(key), VV3hnc), FF39Hq(str(SystemInfo[key]), VV3hnc)))
  except:
   pass
  if VVIfIt:
   VVQKpT = self.VV1Rvc(VVIfIt)
   if VVQKpT:
    VVQKpT.sort(key=lambda x: x[0].lower())
    VVnxKJ += VVQKpT
  if VVIbOZ:
   VVIbOZ.sort(key=lambda x: x[0].lower())
   VVnxKJ += VVIbOZ
  if VVnxKJ:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFqaCW(self, None, header=header, VVnxKJ=VVnxKJ, VVf6S2=widths, VVzQkv=22, VVjJ5Z=True)
  else:
   FFcui4(self, "Could not read info!")
 def VV5vPk(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FF709T(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VV1Rvc(self, mbDict):
  try:
   mbList = list(mbDict)
   VVnxKJ = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVnxKJ.append((FF39Hq(subject, VVESyM), FF39Hq(value, VVESyM)))
  except:
   pass
  return VVnxKJ
 def VVmTNL(self):
  txt = self.VVa31e("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVa31e("/proc/bus/nim_sockets")
  if not txt: txt = self.VVRKpU()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFcui4(self, txt)
 def VVRKpU(self):
  txt = ""
  VVp8k8 = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVp8k8("Slot Name" , slot.getSlotName())
     txt += FF39Hq(slotName, VVESyM)
     txt += VVp8k8("Description"  , slot.getFullDescription())
     txt += VVp8k8("Frontend ID"  , slot.frontend_id)
     txt += VVp8k8("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVa31e(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FF709T(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FF39Hq(line, VVESyM)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVvMoa(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFcui4(self, txt)
class CC9q9O(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFm81W(VVk1xP, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVqVzN = []
  VVqVzN.append(("Settings (All)"   , "Settings_All"   ))
  VVqVzN.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVqVzN.append(("Settings (FHDG-17)"  , "Settings_FHDG_17"  ))
  VVqVzN.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVqVzN.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVqVzN.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVqVzN.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVqVzN.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FFEPCp(self, VVqVzN=VVqVzN)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  FFGE7x(self["myMenu"])
  FFmktH(self)
 def VVzZWl(self):
  global VV6lLO
  VV6lLO = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FFpBIq(self, cmd                )
   elif item == "Settings_HotKeys"   : FFpBIq(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FFpBIq(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FFpBIq(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FFpBIq(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FFpBIq(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FFpBIq(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FFpBIq(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CC9StB(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFm81W(VVk1xP, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VV1GXQ, VVoaeg, VV7W0n, camCommand = FF1Hig()
  self.VVoaeg = VVoaeg
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVqVzN = []
  VVqVzN.append(("OSCam Files"        , "OSCamFiles"  ))
  VVqVzN.append(("NCam Files"        , "NCamFiles"  ))
  VVqVzN.append(("CCcam Files"        , "CCcamFiles"  ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVqVzN.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVqVzN.append(VVPkfI)
  if VVoaeg:
   if   "oscam" in VVoaeg : camName = "OSCam"
   elif "ncam"  in VVoaeg : camName = "NCam"
   VVqVzN.append((camName + " Info."      , "camInfo"   ))
   VVqVzN.append((camName + " Live Status"    , "camLiveStatus" ))
   VVqVzN.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVqVzN.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVqVzN.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FFEPCp(self, VVqVzN=VVqVzN)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  FFGE7x(self["myMenu"])
  FFmktH(self)
 def VVzZWl(self):
  global VV6lLO
  VV6lLO = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCAFoU, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCAFoU, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCAFoU, "cccam"))
   elif item == "OSCamReaders"  : self.VV9BEb("os")
   elif item == "NSCamReaders"  : self.VV9BEb("n")
   elif item == "camInfo"   : FFt02Z(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFOYHw(self.session, CCmINT.VVdxVH)
   elif item == "camLiveReaders" : FFOYHw(self.session, CCmINT.VVCTde)
   elif item == "camLiveLog"  : FFOYHw(self.session, CCmINT.VVhOiX)
   else       : self.close()
 def VV9BEb(self, camPrefix):
  VVKfpb = self.VV1ZFD(camPrefix)
  if VVKfpb:
   VVKfpb.sort(key=lambda x: int(x[0]))
   if self.VVoaeg and self.VVoaeg.startswith(camPrefix):
    VV2BU1 = ("Toggle State", self.VV9gGj, [camPrefix], "Changing State ...")
   else:
    VV2BU1 = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVfxos  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFqaCW(self, None, header=header, VVnxKJ=VVKfpb, VVfxos=VVfxos, VVf6S2=widths, VVzQkv=22, VV2BU1=VV2BU1, VVSl9p=True)
 def VV1ZFD(self, camPrefix):
  readersFile = self.VV1GXQ + camPrefix + "cam.server"
  VVKfpb = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FF709T(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = FF39Hq("ON", VVul8x)
   offStr  = FF39Hq("OFF", VVvBji)
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVKfpb.append((str(len(VVKfpb) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVKfpb:
    FFj9Oj(self, "No readers found !")
  else:
   FFQJvo(self, readersFile)
  return VVKfpb
 def VV9gGj(self, VVqAwN, camPrefix):
  configFile  = "%s%scam.conf" % (self.VV1GXQ, camPrefix)
  readerState  = VVqAwN.VVtuRl(1)
  readerLabel  = VVqAwN.VVtuRl(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CC9StB.VVAzDt(self, camPrefix, configFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVqAwN.VVXuQa()
    FFj9Oj(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVKfpb = self.VV1ZFD(camPrefix)
   if VVKfpb:
    VVqAwN.VV6duD(VVKfpb)
 @staticmethod
 def VVAzDt(SELF, camPrefix, configFile, urlPart, urlAction):
  if fileExists(configFile):
   lines = FF709T(configFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFj9Oj(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFj9Oj(SELF, "SoftCAM Web Port not found in file:\n\n%s" % configFile)
    return None
  else:
   FFQJvo(SELF, configFile)
   return None
  if not iRequest:
   FFj9Oj(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFj9Oj(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFj9Oj(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCAFoU(Screen):
 def __init__(self, VVTnF8, session, args=0):
  self.skin, self.skinParam = FFm81W(VVk1xP, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VV1GXQ, VVoaeg, VV7W0n, camCommand = FF1Hig()
  if   VVTnF8 == "ncam" : self.prefix = "n"
  elif VVTnF8 == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVqVzN = []
  if self.prefix == "":
   VVqVzN.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVqVzN.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVqVzN.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVqVzN.append(("constant.cw"         , "x_constant_cw" ))
   VVqVzN.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVqVzN.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVqVzN.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVqVzN.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVqVzN.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVqVzN.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVqVzN.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVqVzN.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVqVzN.append(VVPkfI)
   VVqVzN.append(("SoftCam.Key"         , "x_SoftCam_Key" ))
   VVqVzN.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVqVzN.append(VVPkfI)
   VVqVzN.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVqVzN.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVqVzN.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFEPCp(self, VVqVzN=VVqVzN)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  FFGE7x(self["myMenu"])
  FFmktH(self)
 def VVzZWl(self):
  global VV6lLO
  VV6lLO = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFuyab(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFuyab(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFuyab(self, self.VV1GXQ + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFuyab(self, self.VV1GXQ + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVRvfQ("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVRvfQ("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVRvfQ("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVRvfQ("cam.provid"        )
   elif item == "x_cam_server"  : self.VVRvfQ("cam.server"        )
   elif item == "x_cam_services" : self.VVRvfQ("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVRvfQ("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVRvfQ("cam.user"        )
   elif item == "x_VVfebv"   : pass
   elif item == "x_SoftCam_Key" : FFuyab(self, self.VV1GXQ + "SoftCam.Key"   )
   elif item == "x_CCcam_cfg"  : FFuyab(self, self.VV1GXQ + "CCcam.cfg"    )
   elif item == "x_VVfebv"   : pass
   elif item == "x_cam_log"  : FFuyab(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFuyab(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFuyab(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVRvfQ(self, fileName):
  FFuyab(self, self.VV1GXQ + self.prefix + fileName)
class CCmINT(Screen):
 VVdxVH  = 0
 VVCTde = 1
 VVhOiX = 2
 def __init__(self, session, VV1GXQ="", VVoaeg="", VV7W0n="", VVIDkW=VVdxVH):
  self.skin, self.skinParam = FFm81W(VVQGZG, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VV7W0n   = VV7W0n
  self.VVIDkW  = VVIDkW
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VV1GXQ + VVoaeg + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVoaeg : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.configFile  = "%s%scam.conf" % (VV1GXQ, self.camPrefix)
  if self.VVIDkW == self.VVdxVH:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVIDkW == self.VVCTde:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFEPCp(self, self.Title, addScrollLabel=True)
  FFIj9t(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVXabD
  self.onShown.append(self.VVOs7w)
  self.onClose.append(self.onExit)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  self["myLabel"].VVOdAK(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFbkgB(self)
  self.VVXabD()
 def onExit(self):
  self.timer.stop()
 def VVdeMZ(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVGKiS)
  except:
   self.timer.callback.append(self.VVGKiS)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FF0fiU(self, "Started", 1000)
 def VVU2mv(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVGKiS)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FF0fiU(self, "Stopped", 1000)
 def VVXabD(self):
  if self.timerRunning:
   self.VVU2mv()
  else:
   self.VVdeMZ()
   if self.VVIDkW == self.VVdxVH or self.VVIDkW == self.VVCTde:
    if self.VVIDkW == self.VVdxVH : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CC9StB.VVAzDt(self, self.camPrefix, self.configFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FF4YxS(self.VVgbuY)
    else:
     self.close()
   else:
    self.VVLMkB()
 def VVGKiS(self):
  if self.timerRunning:
   if   self.VVIDkW == self.VVdxVH : self.VVTMRz()
   elif self.VVIDkW == self.VVCTde : self.VVTMRz()
   else            : self.VVLMkB()
 def VVLMkB(self):
  if fileExists(self.VV7W0n):
   fTime = FFXglk(os.path.getmtime(self.VV7W0n))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVef42(), VVNp8T=VVsLgX)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VV7W0n)
 def VVgbuY(self):
  self.VVTMRz()
 def VVTMRz(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FF39Hq("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVepFH))
   self.camWebIfErrorFound = True
   self.VVU2mv()
   return
  page = page.decode('UTF-8')
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVIDkW == self.VVdxVH : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FF39Hq("Error while parsing data elements !\n\nError = %s" % str(e), VVUDh4)
   self.camWebIfErrorFound = True
   self.VVU2mv()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVAdQp(root)
  self["myLabel"].setText(txt, VVNp8T=VVsLgX)
  self["myBar"].setText("Last Update : %s" % FFW5Nh())
 def VVAdQp(self, rootElement):
  def VVp8k8(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVIDkW == self.VVdxVH:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FF39Hq(status, VVul8x)
    else          : status = FF39Hq(status, VVUDh4)
    txt += VVfebv + "\n"
    txt += VVp8k8("Name"  , name)
    txt += VVp8k8("Description" , desc)
    txt += VVp8k8("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVp8k8("Protocol" , protocol)
    txt += VVp8k8("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FF39Hq("Yes", VVul8x)
    else    : enabTxt = FF39Hq("No", VVUDh4)
    txt += VVfebv + "\n"
    txt += VVp8k8("Label"  , label)
    txt += VVp8k8("Protocol" , protocol)
    txt += VVp8k8("Enabled" , enabTxt)
  return txt
 def VVef42(self):
  wordsDict = self.VVCIH7()
  color = [ VVESyM, VVMwfZ, VVul8x, VVUDh4, VV3hnc, VVTNcj]
  lines = FFGZr4("tail -n %d %s" % (100, self.VV7W0n))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVepFH + line[:19] + VVvBji + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VV4Z4E + line[ndx + 3:] + VVvBji
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVESyM + line[ndx + 8 : ndx1 + 4] + VVvBji + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVvBji)
   elif line.startswith("----") or ">>" in line:
    line = FF39Hq(line, VVESyM)
   txt += line + "\n"
  return txt
 def VVCIH7(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FF709T(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CC4UP2(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFm81W(VVk1xP, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVqVzN = []
  VVqVzN.append(("Backup Channels"        , "VVgxQv"   ))
  VVqVzN.append(("Restore Channels"        , "Restore_Channels"  ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Backup SoftCAM Files"       , "VVXpO0" ))
  VVqVzN.append(("Restore SoftCAM Files"      , "Restore_SoftCAM_Files" ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Backup Tuner Settings"      , "Backup_TunerDiSEqC"  ))
  VVqVzN.append(("Restore Tuner Settings"      , "Restore_TunerDiSEqC"  ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Backup HotKeys & FHDG17 Settings"    , "Backup_Hotkey_FHDG17" ))
  VVqVzN.append(("Restore HotKeys & FHDG17 Settings"   , "Restore_Hotkey_FHDG17" ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Backup Network Settings"      , "VVI41G"   ))
  VVqVzN.append(("Restore Network Settings"      , "Restore_Network"   ))
  if VV4dZ1:
   VVqVzN.append(VVPkfI)
   VVqVzN.append((VVepFH + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME , "VVqSJm"   ))
   VVqVzN.append((VVul8x + "2- Create %s for IPK"   % PLUGIN_NAME , "createMyIpk"   ))
   VVqVzN.append((VVul8x + "3- Create %s for DEB"   % PLUGIN_NAME , "createMyDeb"   ))
   VVqVzN.append((VV3hnc + "Create %s TAR (Absolute Path)" % PLUGIN_NAME , "createMyTar"   ))
   VVqVzN.append((VV3hnc + "Decode %s Crash Report"   % PLUGIN_NAME , "VVslX2" ))
  FFEPCp(self, VVqVzN=VVqVzN)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  FFGE7x(self["myMenu"])
  FFmktH(self)
 def VVzZWl(self):
  global VV6lLO
  VV6lLO = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVgxQv"    : self.VVgxQv()
   elif item == "Restore_Channels"    : self.VVzlg7("channels_backup*.tar.gz", self.VVayLN)
   elif item == "VVXpO0"   : self.VVXpO0()
   elif item == "Restore_SoftCAM_Files"  : self.VVzlg7("softcam_backup*.tar.gz", self.VVZEfS)
   elif item == "Backup_TunerDiSEqC"   : self.VVfD9Y("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVzlg7("tuner_backup*.backup", boundFunction(self.VVTU4e, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVfD9Y("hotkey_fhdg17_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVzlg7("hotkey_fhdg17_backup*.backup", boundFunction(self.VVTU4e, "misc"))
   elif item == "VVI41G"    : self.VVI41G()
   elif item == "Restore_Network"    : self.VVzlg7("network_backup*.tar.gz", self.VVsfq2)
   elif item == "VVqSJm"     : FFi0Lh(self, boundFunction(FFFe8v, self, boundFunction(CC4UP2.VVqSJm, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VV14aB(False)
   elif item == "createMyDeb"     : self.VV14aB(True)
   elif item == "createMyTar"     : self.VVtCaM()
   elif item == "VVslX2"   : self.VVslX2()
 @staticmethod
 def VVqSJm(SELF):
  OBF_Path = VVxJlC + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VVxJlC, VVjmQ2, VV2ELH)
   if err : FFj9Oj(SELF, err)
   else : FFcui4(SELF, txt)
  else:
   FFQJvo(SELF, OBF_Path)
 def VV14aB(self, VV9ot9):
  OBF_Path = VVxJlC + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFj9Oj(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VVxJlC)
  os.system("mv -f %s %s" % (VVxJlC + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VVxJlC + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VVxJlC + "plugin.py"))
  self.session.openWithCallback(self.VV14aB1, boundFunction(CCgJW5, path=VVxJlC, VV9ot9=VV9ot9))
 def VV14aB1(self):
  os.system("mv -f %s %s" % (VVxJlC + "OBF/main.py"  , VVxJlC))
  os.system("mv -f %s %s" % (VVxJlC + "OBF/plugin.py" , VVxJlC))
 def VVslX2(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFj9Oj(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFj9Oj(self, "No log files in:\n\n%s" % path)
   return
  VVnxKJ = []
  for f in files:
   f = os.path.basename(f)
   VVnxKJ.append((f, f))
  FFbvqQ(self, boundFunction(self.VV6xfI, path), VVqVzN=VVnxKJ)
 def VV6xfI(self, path, item=None):
  if item:
   codF = ""
   cFiles = iGlob("%s*.list" % path)
   if cFiles:
    codF = cFiles[0]
    if fileExists(codF):
     logF = path + item
     if fileExists(logF):
      lst  = []
      lines = FF709T(codF)
      for line in lines:
       line = line.split(":")[1]
       parts = line.split("->")
       lst.append((parts[1].strip(), parts[0].strip()))
      if lst:
       logTxt = FF7gKM(logF)
       for item in lst:
        logTxt = logTxt.replace(item[0], item[1])
       resF = logF + ".decoded.log"
       with open(resF, "w") as f:
        f.write(logTxt)
       FFhXFJ(self, "Output File:\n\n%s" % resF)
      else: FFj9Oj(self, "No codes in : %s" % codF)
     else: FFQJvo(self, logF)
   else: FFQJvo(self, codF)
 def VVtCaM(self):
  VVnxKJ = []
  VVnxKJ.append("%s%s" % (VVxJlC, "*.py"))
  VVnxKJ.append("%s%s" % (VVxJlC, "*.png"))
  VVnxKJ.append("%s%s" % (VVxJlC, "*.xml"))
  VVnxKJ.append("%s"  % (VVLdJi))
  FFhebi(self, VVnxKJ, "%s_%s" % (PLUGIN_NAME, VVjmQ2), addTimeStamp=False)
 def VVgxQv(self):
  path1 = VVH4FS
  path2 = "/etc/tuxbox/"
  VVnxKJ = []
  VVnxKJ.append("%s%s" % (path1, "*.tv"))
  VVnxKJ.append("%s%s" % (path1, "*.radio"))
  VVnxKJ.append("%s%s" % (path1, "*list"))
  VVnxKJ.append("%s%s" % (path1, "lamedb*"))
  VVnxKJ.append("%s%s" % (path2, "*.xml"))
  FFhebi(self, VVnxKJ, "channels_backup", addTimeStamp=True)
 def VVXpO0(self):
  VVnxKJ = []
  VVnxKJ.append("/etc/tuxbox/config/")
  VVnxKJ.append("/usr/keys/")
  VVnxKJ.append("/usr/scam/")
  VVnxKJ.append("/etc/CCcam.cfg")
  FFhebi(self, VVnxKJ, "softcam_backup", addTimeStamp=True)
 def VVI41G(self):
  VVnxKJ = []
  VVnxKJ.append("/etc/hostname")
  VVnxKJ.append("/etc/default_gw")
  VVnxKJ.append("/etc/resolv.conf")
  VVnxKJ.append("/etc/wpa_supplicant*.conf")
  VVnxKJ.append("/etc/network/interfaces")
  VVnxKJ.append("/etc/enigma2/nameserversdns.conf")
  FFhebi(self, VVnxKJ, "network_backup", addTimeStamp=True)
 def VVayLN(self, fileName):
  if fileName:
   FFi0Lh(self, boundFunction(self.VVSFs5, fileName), "Overwrite current channels ?")
 def VVSFs5(self, fileName):
  path = "%s%s" % (VVjHyF, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCxXMf.VVzMpB()
   lamedb5File, diabled5File = CCxXMf.VVAHBx()
   cmd = ""
   cmd += FFhmFU("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFhmFU("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FF89ZG()
   if res == 0 : FFhXFJ(self, "Channels Restored.")
   else  : FFj9Oj(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFQJvo(self, path)
 def VVZEfS(self, fileName):
  if fileName:
   FFi0Lh(self, boundFunction(self.VVGHWU, fileName), "Overwrite SoftCAM files ?")
 def VVGHWU(self, fileName):
  fileName = "%s%s" % (VVjHyF, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVfebv
   note = "You may need to restart your SoftCAM."
   FFrPjR(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFDI4H(note, VVESyM), sep))
  else:
   FFQJvo(self, fileName)
 def VVsfq2(self, fileName):
  if fileName:
   FFi0Lh(self, boundFunction(self.VVsKrj, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVsKrj(self, fileName):
  fileName = "%s%s" % (VVjHyF, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFFM6I(self,  cmd)
  else:
   FFQJvo(self, fileName)
 def VVzlg7(self, pattern, callBackFunction, isTuner=False):
  title = FFfHwI()
  if pathExists(VVjHyF):
   myFiles = iGlob("%s%s" % (VVjHyF, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVnxKJ = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVnxKJ.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVTaNU = ("Sat. List", self.VV6P3n)
    else  : VVTaNU = None
    FFbvqQ(self, callBackFunction, title=title, VVqVzN=VVnxKJ, VVTaNU=VVTaNU)
   else:
    FFj9Oj(self, "No files found in:\n\n%s" % VVjHyF, title)
  else:
   FFj9Oj(self, "Path not found:\n\n%s" % VVjHyF, title)
 def VVfD9Y(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCsZDe()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVhTkw, filePrefix))
 def VVhTkw(self, filePrefix, result, retval):
  title = FFfHwI()
  if pathExists(VVjHyF):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFj9Oj(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVjHyF, filePrefix, FFCy03())
    try:
     VVnxKJ = str(result.strip()).split()
     if VVnxKJ:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVnxKJ:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVfebv, FF39Hq(fName, VVESyM), VVfebv)
       FFcui4(self, txt, title=title, VVNp8T=VVsLgX)
      else:
       FFj9Oj(self, "File creation failed!", title)
     else:
      FFj9Oj(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFhmFU("rm %s" % fName))
     FFj9Oj(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFhmFU("rm %s" % fName))
     FFj9Oj(self, "Error while writing file.")
  else:
   FFj9Oj(self, "Path not found:\n\n%s" % VVjHyF, title)
 def VVTU4e(self, mode, path):
  if path:
   path = "%s%s" % (VVjHyF, path)
   if fileExists(path):
    lines = FF709T(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys/FHDG17"
     FFi0Lh(self, boundFunction(self.VVXWMb, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFYN1B(self, path, title=FFfHwI())
   else:
    FFQJvo(self, path)
 def VVXWMb(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VV4umH = []
  VV4umH.append("echo -e 'Reading current settings ...'")
  VV4umH.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VV4umH.append("echo -e 'Preparing new settings ...'")
  VV4umH.append(settingsLines)
  VV4umH.append("echo -e 'Applying new settings ...'")
  VV4umH.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFofxf(self, VV4umH)
 def VV6P3n(self, VVw5fsObj, path):
  if not path:
   return
  path = VVjHyF + path
  if not fileExists(path):
   FFQJvo(self, path)
   return
  txt = FF7gKM(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VVnxKJ  = []
   for item in satList:
    VVnxKJ.append("%s\t%s" % (item[0], FF16jJ(item[1])))
   FFcui4(self, VVnxKJ, title="  Satellites List")
  else:
   FFj9Oj(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCZLbi(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFm81W(VVk1xP, 850, 700, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVqVzN = []
  VVqVzN.append(("Plugins Browser List"       , "VVII1t"   ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVqVzN.append(("Installed Packages (all)"      , "installedPackagesAll"  ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Remove Packages (Plugin/SoftCAM/Skin)"  , "removePluginSkinSoftCAM"  ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Update List of Available Packages"   , "VVdb3G"   ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Packaging Tool"        , "VV9o2Y"    ))
  VVqVzN.append(("Packages Feeds"        , "packagesFeeds"    ))
  FFEPCp(self, VVqVzN=VVqVzN)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  FFGE7x(self["myMenu"])
  FFmktH(self)
 def VVzZWl(self):
  global VV6lLO
  VV6lLO = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVII1t"   : self.VVII1t()
   elif item == "pluginsDirList"    : self.VVzvzv()
   elif item == "installedPackagesAll"     : FFFe8v(self, boundFunction(self.VVRquP, 0, ""))
   elif item == "removePluginSkinSoftCAM"  : FFFe8v(self, boundFunction(self.VVRquP, 1, "| grep -e skin -e enigma2-"))
   elif item == "downloadInstallPackages"  : FFFe8v(self, boundFunction(self.VVRquP, 2, ""))
   elif item == "VVdb3G"   : self.VVdb3G()
   elif item == "VV9o2Y"    : self.VV9o2Y()
   elif item == "packagesFeeds"    : self.VVFm1T()
   else          : self.close()
 def VVzvzv(self):
  extDirs  = FF4zd5(VVxO5U)
  sysDirs  = FF4zd5(VVPnB7)
  VVnxKJ  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VVnxKJ.append((item, VVxO5U + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VVnxKJ.append((item, VVPnB7 + item))
  if VVnxKJ:
   VVnxKJ = sorted(VVnxKJ, key=lambda x: x[0].lower())
   VV2CKM = ("Package Info.", self.VVIU9J, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFqaCW(self, None, header=header, VVnxKJ=VVnxKJ, VVf6S2=widths, VVzQkv=28, VV2CKM=VV2CKM)
  else:
   FFj9Oj(self, "Nothing found!")
 def VVIU9J(self, VVqAwN, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVxO5U) : loc = "extensions"
  elif path.startswith(VVPnB7) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVvp21(package)
  else:
   FFj9Oj(self, "No info!")
 def VVFm1T(self):
  pkg = FF5iuo()
  if pkg : FFpBIq(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFhggE(self)
 def VVII1t(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VVp8k8(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVfebv + "\n"
    txt += VVp8k8("Number"   , str(c))
    txt += VVp8k8("Name"   , FF39Hq(str(p.name), VVESyM))
    txt += VVp8k8("Path"  , p.path  )
    txt += VVp8k8("Description" , p.description )
    txt += VVp8k8("Icon"  , p.iconstr  )
    txt += VVp8k8("Wakeup Fnc" , p.wakeupfnc )
    txt += VVp8k8("NeedsRestart", p.needsRestart)
    txt += VVp8k8("Internal" , p.internal )
    txt += VVp8k8("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFcui4(self, txt)
 def VVdb3G(self):
  cmd = FFjZGS(VVCvwl, "")
  if cmd : FFFM6I(self, cmd, checkNetAccess=True)
  else : FFhggE(self)
 def VV9o2Y(self):
  pkg = FF5iuo()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFhXFJ(self, txt)
 def VVRquP(self, mode, grep, VVqAwN=None, title=""):
  if   mode == 0: cmd = FFjZGS(VVgzHK , grep)
  elif mode == 1: cmd = FFjZGS(VVgzHK , grep)
  elif mode == 2: cmd = FFjZGS(VVHCkj    , grep)
  if not cmd:
   FFhggE(self)
   return
  VVKfpb = FFGZr4(cmd)
  if not VVKfpb:
   if VVqAwN: VVqAwN.VVXuQa()
   FFj9Oj(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVnxKJ  = []
  for item in VVKfpb:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVnxKJ.append((name, package, version))
  if mode == 1:
   extensions = FFGZr4("ls %s -l | grep '^d' | awk '{print $9}'" % VVxO5U)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVnxKJ:
      if item.lower() == row[0].lower():
       break
     else:
      VVnxKJ.append((item, VVxO5U + item, "-"))
   systemPlugins = FFGZr4("ls %s -l | grep '^d' | awk '{print $9}'" % VVPnB7)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVnxKJ:
      if item.lower() == row[0].lower():
       break
     else:
      VVnxKJ.append((item, VVPnB7 + item, "-"))
  if not VVnxKJ:
   FFj9Oj(self, "No packages found!")
   return
  if VVqAwN:
   VVnxKJ.sort(key=lambda x: x[0].lower())
   VVqAwN.VV6duD(VVnxKJ, title)
  else:
   widths = (20, 50, 30)
   if mode == 0:
    VVUaPo = None
    VV2BU1 = None
    VVFLU5 = None
   elif mode == 1:
    VVUaPo = ("Uninstall", self.VVxHfn, [])
    VV2BU1 = None
    VVFLU5 = None
    widths= (18, 57, 25)
   elif mode == 2:
    VVUaPo = ("Install" , self.VVJLA6   , [])
    VV2BU1 = ("Download" , self.VVdl3O   , [])
    VVFLU5 = ("Filter"  , self.VVCUcu , [])
   VVnxKJ = sorted(VVnxKJ, key=lambda x: x[0].lower())
   VV2CKM = ("Package Info.", self.VVqMdo, [])
   header   = ("Name" ,"Package" , "Version" )
   FFqaCW(self, None, header=header, VVnxKJ=VVnxKJ, VVf6S2=widths, VVzQkv=24, VVUaPo=VVUaPo, VV2BU1=VV2BU1, VV2CKM=VV2CKM, VVFLU5=VVFLU5, VVyJj1=self.lastSelectedRow
     , VVMhkn="#22110011", VVLwBG="#22191111", VVCMEX="#22191111", VVwS8Y="#00003030", VVihFS="#00333333")
 def VVqMdo(self, VVqAwN, title, txt, colList):
  package  = colList[1]
  self.VVvp21(package)
 def VVCUcu(self, VVqAwN, title, txt, colList):
  words = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVqVzN = []
  VVqVzN.append(("All Packages", "all"))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVqVzN.append(VVPkfI)
  for word in words:
   VVqVzN.append((word, word))
  FFbvqQ(self, boundFunction(self.VVNvxX, VVqAwN), VVqVzN=VVqVzN, title="Select Filter")
 def VVNvxX(self, VVqAwN, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFFe8v(VVqAwN, boundFunction(self.VVRquP, 2, grep, VVqAwN, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVxHfn(self, VVqAwN, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVxO5U, VVPnB7)):
   FFi0Lh(self, boundFunction(self.VVmp9d, VVqAwN, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVqVzN = []
   VVqVzN.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVqVzN.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVqVzN.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFbvqQ(self, boundFunction(self.VVocRu, VVqAwN, package), VVqVzN=VVqVzN)
 def VVmp9d(self, VVqAwN, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVbxGJ)
  FFFM6I(self, cmd, VVoAx2=boundFunction(self.VVSAgT, VVqAwN))
 def VVocRu(self, VVqAwN, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVLc03
   elif item == "remove_ForceRemove"  : cmdOpt = VVxKpM
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVHZM0
   FFi0Lh(self, boundFunction(self.VV3yOM, VVqAwN, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VV3yOM(self, VVqAwN, package, cmdOpt):
  self.lastSelectedRow = VVqAwN.VVrHvs()
  cmd = FFxt6o(cmdOpt, package)
  if cmd : FFFM6I(self, cmd, VVoAx2=boundFunction(self.VVSAgT, VVqAwN))
  else : FFhggE(self)
 def VVSAgT(self, VVqAwN):
  VVqAwN.cancel()
  FF0Wsq()
 def VVJLA6(self, VVqAwN, title, txt, colList):
  package  = colList[1]
  VVqVzN = []
  VVqVzN.append(("Install Package"         , "install_CheckVersion" ))
  VVqVzN.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVqVzN.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVqVzN.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFbvqQ(self, boundFunction(self.VVBx1i, package), VVqVzN=VVqVzN)
 def VVBx1i(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVEmKG
   elif item == "install_ForceReinstall" : cmdOpt = VVxMeg
   elif item == "install_ForceDowngrade" : cmdOpt = VVveCC
   elif item == "install_IgnoreDepends" : cmdOpt = VVEjfp
   FFi0Lh(self, boundFunction(self.VVMA3N, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVMA3N(self, package, cmdOpt):
  cmd = FFxt6o(cmdOpt, package)
  if cmd : FFFM6I(self, cmd, VVoAx2=FF0Wsq, checkNetAccess=True)
  else : FFhggE(self)
 def VVdl3O(self, VVqAwN, title, txt, colList):
  package  = colList[1]
  FFi0Lh(self, boundFunction(self.VVr9QQ, package), "Download Package ?\n\n%s" % package)
 def VVr9QQ(self, package):
  if FF0KEj():
   cmd = FFxt6o(VVQTgL, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFDI4H(success, VVul8x))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFDI4H(fail, VVUDh4))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFFM6I(self, cmd, VV2Ujo=[VVUDh4, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFhggE(self)
  else:
   FFj9Oj(self, "No internet connection !")
 def VVvp21(self, package):
  infoCmd  = FFxt6o(VVuVVp, package)
  filesCmd = FFxt6o(VVbbcC, package)
  listInstCmd = FFjZGS(VVgzHK, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFRlBl(VVESyM)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFDI4H(notInst, VVepFH))
   cmd += "else "
   cmd +=   FFcBuL("System Info", VVESyM)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFcBuL("Related Files", VVESyM)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFSs3o(self, cmd)
  else:
   FFhggE(self)
class CCxXMf(Screen):
 VVwNky  = 0
 VVEDcJ = 1
 VVLqWs  = 2
 VVn4sF  = 3
 VV32vG = 4
 VVa4uq = 5
 VVbiyT = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFm81W(VVk1xP, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVQF4Q = None
  self.lastfilterUsed  = None
  VVqVzN = self.VVJ2Ke()
  FFEPCp(self, VVqVzN=VVqVzN, title="Services/Channels")
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self["myMenu"].setList(self.VVJ2Ke())
  FFGE7x(self["myMenu"])
  FFmktH(self)
 def VVJ2Ke(self):
  VVqVzN = []
  VVqVzN.append(("Current Service (Signal Monitor)"   , "currentServiceSignal"    ))
  VVqVzN.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Services (Reference)"      , "lameDB_allChannels_with_refCode"  ))
  VVqVzN.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVqVzN.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVqVzN.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVqVzN.append(("Services with PIcons for the System"  , "VVeuNJ"     ))
  VVqVzN.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVqVzN.append(VVPkfI)
  lamedbFile, disabledFile = CCxXMf.VVzMpB()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVqVzN.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVqVzN.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVqVzN.append(("Reset Parental Control Settings"   , "VVQIsp"    ))
  VVqVzN.append(("Delete Channels with no names"   , "VVewWT"    ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Reload Channels and Bouquets"    , "VVAXiI"      ))
  return VVqVzN
 def VVzZWl(self):
  global VV6lLO
  VV6lLO = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FFHQ6U(self)
   elif item == "currentServiceInfo"     : self.session.open(CC3OlU)
   elif item == "TranspondersStats"     : FFFe8v(self, self.VVz84S     )
   elif item == "lameDB_allChannels_with_refCode"  : FFFe8v(self, self.VVBt62 )
   elif item == "lameDB_allChannels_with_tranaponder" : FFFe8v(self, self.VVzCAQ)
   elif item == "lameDB_allChannels_with_details"  : FFFe8v(self, self.VVBQB1 )
   elif item == "parentalControlChannels"    : FFFe8v(self, self.VVOcD0   )
   elif item == "showHiddenChannels"     : FFFe8v(self, self.VVWig0     )
   elif item == "VVeuNJ"     : FFFe8v(self, self.VV2GEh     )
   elif item == "servicesWithMissingPIcons"   : FFFe8v(self, self.VVhBQS   )
   elif item == "enableHiddenChannels"     : self.VVj0c9(True)
   elif item == "disableHiddenChannels"    : self.VVj0c9(False)
   elif item == "VVQIsp"    : FFi0Lh(self, self.VVQIsp, "Reset and Restart ?" )
   elif item == "VVewWT"    : FFFe8v(self, self.VVewWT)
   elif item == "VVAXiI"      : FFFe8v(self, boundFunction(CCxXMf.VVAXiI, self))
   else            : self.close()
 @staticmethod
 def VVAXiI(SELF):
  FF89ZG()
  FFhXFJ(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVBt62(self):
  self.VVQF4Q = None
  self.lastfilterUsed  = None
  self.filterObj   = CCZ6u9(self)
  VVKfpb = CCxXMf.VVcYBO(self, self.VVwNky)
  if VVKfpb:
   VVKfpb.sort(key=lambda x: x[0].lower())
   VVm7uJ  = ("Zap"   , self.VVJ5Oy     , [])
   VVtv1H = (""    , self.VVCXkw   , [])
   VV2CKM = ("Options"  , self.VVTc4q , [])
   VV2BU1 = ("Current Service", self.VVNp4g , [])
   VVFLU5 = ("Filter"   , self.VVNdDV  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVfxos  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFqaCW(self, None, header=header, VVnxKJ=VVKfpb, VVfxos=VVfxos, VVf6S2=widths, VVzQkv=22, VVm7uJ=VVm7uJ, VVtv1H=VVtv1H, VV2BU1=VV2BU1, VV2CKM=VV2CKM, VVFLU5=VVFLU5)
 def VVzCAQ(self):
  self.VVQF4Q = None
  self.lastfilterUsed  = None
  self.filterObj   = CCZ6u9(self)
  VVKfpb = CCxXMf.VVcYBO(self, self.VVEDcJ)
  if VVKfpb:
   VVKfpb.sort(key=lambda x: x[0].lower())
   VVm7uJ  = ("Zap"   , self.VVJ5Oy      , [])
   VVtv1H = (""    , self.VVCXkw    , [])
   VV2BU1 = ("Current Service", self.VVNp4g  , [])
   VV2CKM = ("Options"  , self.VVCPw5 , [])
   VVFLU5 = ("Filter"   , self.VVcaDI  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVfxos  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFqaCW(self, None, header=header, VVnxKJ=VVKfpb, VVfxos=VVfxos, VVf6S2=widths, VVzQkv=22, VVm7uJ=VVm7uJ, VVtv1H=VVtv1H, VV2BU1=VV2BU1, VV2CKM=VV2CKM, VVFLU5=VVFLU5)
 def VVTc4q(self, VVqAwN, title, txt, colList):
  servName = colList[0]
  refCode  = colList[3]
  pcState  = colList[4]
  hidState = colList[5]
  mSel  = CC6pTH(self, VVqAwN, 3)
  mSel.VVEOWs(servName, refCode, pcState, hidState)
 def VVCPw5(self, VVqAwN, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CC6pTH(self, VVqAwN, 3)
  mSel.VVsOQx(servName, refCode)
 def VVO5uK(self, VVqAwN, refCode, isAddToBlackList):
  self.VVQF4Q = None
  self.lastfilterUsed  = None
  VVqAwN.VVPO8w("Changing state ...")
  path = "/etc/enigma2/blacklist"
  if not fileExists(path):
   os.system("echo '' > %s" % path)
  if fileExists(path):
   if not refCode.endswith(":"):
    refCode += ":"
   if isAddToBlackList :
    os.system("sed -i '/%s/d' %s" % (refCode, path))
    os.system("echo '%s' >> %s" % (refCode, path))
   else:
    os.system("sed -i '/%s/d' %s" % (refCode, path))
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   if refCode.endswith(":"):
    refCode = refCode[:-1]
   FFFe8v(self, boundFunction(self.VVaaBo, VVqAwN, refCode))
  else:
   FFQJvo(self, path)
 def VVMpOT(self, VVqAwN, refCode, isHide):
  self.VVQF4Q = None
  self.lastfilterUsed  = None
  VVqAwN.VVPO8w("Changing state ...")
  if FFhKNX(refCode):
   ret = FFlRJL(refCode, isHide)
   if ret : FFFe8v(self, boundFunction(self.VVaaBo, VVqAwN, refCode))
   else : FFj9Oj(self, "Cannot Hide/Unhide this channel.")
  else:
   FFj9Oj(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)")
 def VVaaBo(self, VVqAwN, refCode):
  VVKfpb = CCxXMf.VVcYBO(self, self.VVwNky, VVd4o9=[3, [refCode], False])
  done = False
  if VVKfpb:
   data = VVKfpb[0]
   if data[3] == refCode:
    done = VVqAwN.VVTAfS(data)
  if not done:
   self.VV52qu(VVqAwN, VVqAwN.VVQpNy(), self.VVwNky)
  VVqAwN.VVXuQa()
 def VVNdDV(self, VVqAwN, title, txt, colList):
  self.filterObj.VVP6E6(1, VVqAwN, 2, boundFunction(self.VVgaii, VVqAwN))
 def VVgaii(self, VVqAwN, item):
  self.VVB3Nx(VVqAwN, item, 2, self.VVwNky)
 def VVcaDI(self, VVqAwN, title, txt, colList):
  self.filterObj.VVP6E6(2, VVqAwN, 4, boundFunction(self.VVQNK4, VVqAwN))
 def VVQNK4(self, VVqAwN, item):
  self.VVB3Nx(VVqAwN, item, 4, self.VVEDcJ)
 def VVC09d(self, VVqAwN, title, txt, colList):
  self.filterObj.VVP6E6(0, VVqAwN, 4, boundFunction(self.VV2HYt, VVqAwN))
 def VV2HYt(self, VVqAwN, item):
  self.VVB3Nx(VVqAwN, item, 4, self.VVLqWs)
 def VVB3Nx(self, VVqAwN, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVqAwN.VVtuRl(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVQF4Q = None
  else:
   words, asPrefix = CCZ6u9.VVpQVr(words)
   self.VVQF4Q = [col, words, asPrefix]
  if not words:
   FF0fiU(VVqAwN, "Incorrect filter", 2000)
  else:
   VVqAwN.VVPO8w("Reading Services ...")
   FFFe8v(self, boundFunction(self.VV52qu, VVqAwN, title, mode))
 def VV52qu(self, VVqAwN, title, mode):
  VVKfpb = CCxXMf.VVcYBO(self, mode, VVd4o9=self.VVQF4Q, VVb4xi=False)
  if VVKfpb:
   VVKfpb.sort(key=lambda x: x[0].lower())
   VVqAwN.VV6duD(VVKfpb, title)
  else:
   VVqAwN.VVXuQa()
   FF0fiU(VVqAwN, "Not found!", 1500)
 def VVURhA(self, VVnxKJ, VVm7uJ=None, VVtv1H=None, VVUaPo=None, VV2BU1=None, VV2CKM=None, VVFLU5=None):
  VV2BU1 = ("Current Service", self.VVNp4g, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVfxos = (LEFT  , LEFT  , CENTER, LEFT    )
  FFqaCW(self, None, header=header, VVnxKJ=VVnxKJ, VVfxos=VVfxos, VVf6S2=widths, VVzQkv=24, VVm7uJ=VVm7uJ, VVtv1H=VVtv1H, VVUaPo=VVUaPo, VV2BU1=VV2BU1, VV2CKM=VV2CKM, VVFLU5=VVFLU5)
 def VVNp4g(self, VVqAwN, title, txt, colList):
  self.VVU3b5(VVqAwN)
 def VVaFve(self, VVqAwN, title, txt, colList):
  self.VVU3b5(VVqAwN, True)
 def VVU3b5(self, VVqAwN, isFromDetails=False):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiz95(self)
  if refCode:
   if isFromDetails:
    chName  = info.getName()
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVqAwN.VVkQmG(colDict, showErr=True)
   else:
    VVqAwN.VVFBev(3, refCode, True)
   return
  FFj9Oj(self, "Colud not read current Reference Code !")
 def VVBQB1(self):
  self.VVQF4Q = None
  self.lastfilterUsed  = None
  self.filterObj   = CCZ6u9(self)
  VVKfpb = CCxXMf.VVcYBO(self, self.VVLqWs)
  if VVKfpb:
   VVKfpb.sort(key=lambda x: x[0].lower())
   VVtv1H = (""    , self.VVoJIS , []      )
   VV2BU1 = ("Current Service", self.VVaFve  , []      )
   VVFLU5 = ("Filter"   , self.VVC09d   , [], "Loading Filters ..." )
   VVm7uJ  = ("Zap"   , self.VVHQWm      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVfxos  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFqaCW(self, None, header=header, VVnxKJ=VVKfpb, VVfxos=VVfxos, VVf6S2=widths, VVzQkv=24, VVm7uJ=VVm7uJ, VVtv1H=VVtv1H, VV2BU1=VV2BU1, VVFLU5=VVFLU5)
 def VVoJIS(self, VVqAwN, title, txt, colList):
  refCode  = self.VVxqip(colList)
  chName  = colList[0]
  png, path = CC6Hdl.VVLXik(refCode, chName)
  txt   += "Reference\t: %s" % refCode
  CC3OlU.VVm2Ur(self, refCode, txt, title, path)
 def VVHQWm(self, VVqAwN, title, txt, colList):
  refCode = self.VVxqip(colList)
  FFj5dK(self, refCode)
 def VVJ5Oy(self, VVqAwN, title, txt, colList):
  FFj5dK(self, colList[3])
 def VVxqip(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVcYBO(SELF, mode, VVd4o9=None, VVb4xi=True, VVgbkb=True):
  lamedbFile, disabledFile = CCxXMf.VVzMpB()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVd4o9:
    filterCol = VVd4o9[0]
    filterWords = VVd4o9[1]
    asPrefix = VVd4o9[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCxXMf.VVwNky:
    blackList = None
    path = "/etc/enigma2/blacklist"
    if fileExists(path):
     blackList = FF709T(path)
     if blackList:
      blackList = set(blackList)
   elif mode == CCxXMf.VVEDcJ:
    tp = CCRdiH()
   VVzLy1, VVI06l = FFIHPD()
   tagFound  = False
   if mode in (CCxXMf.VVa4uq, CCxXMf.VVbiyT):
    VVKfpb = {}
   else:
    VVKfpb = []
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     if not FFjMv5(SELF):
      return None
     line = line.strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
        sTypeInt = int(STYPE)
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFzEOF(val)
       servTypeHex = (hex(sTypeInt))[2:].upper()
       if mode == CCxXMf.VVLqWs:
        if sTypeInt in VVzLy1:
         STYPE = VVI06l[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVKfpb.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVKfpb.append(tRow)
        else:
         VVKfpb.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCxXMf.VVa4uq:
         VVKfpb[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCxXMf.VVbiyT:
         VVKfpb[chName] = refCode
        elif mode == CCxXMf.VVwNky:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVKfpb.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVKfpb.append(tRow)
         else:
          VVKfpb.append(tRow)
        elif mode == CCxXMf.VVEDcJ:
         if sTypeInt in VVzLy1:
          STYPE = VVI06l[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVcat9(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVKfpb.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVKfpb.append(tRow)
         else:
          VVKfpb.append(tRow)
        elif mode == CCxXMf.VVn4sF:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VVKfpb.append((chName, chProv, sat, refCode))
        elif mode == CCxXMf.VV32vG:
         VVKfpb.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VVKfpb and VVb4xi:
    FFj9Oj(SELF, "No services found!")
   return VVKfpb
  else:
   if VVgbkb:
    FFQJvo(SELF, lamedbFile)
   return None
 def VVOcD0(self):
  path = "/etc/enigma2/blacklist"
  if fileExists(path):
   lines = FF709T(path)
   if lines:
    newRows  = []
    VVKfpb = CCxXMf.VVcYBO(self, self.VV32vG)
    if VVKfpb:
     lines = set(lines)
     for item in VVKfpb:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVKfpb = newRows
      VVKfpb.sort(key=lambda x: x[0].lower())
      VVtv1H = ("", self.VVCXkw, [])
      VVm7uJ = ("Zap", self.VVJ5Oy, [])
      self.VVURhA(VVnxKJ=VVKfpb, VVm7uJ=VVm7uJ, VVtv1H=VVtv1H)
     else:
      FFcui4(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVKfpb)))
   else:
    FFhXFJ(self, "No hidden services.", FFfHwI())
  else:
   FFQJvo(self, path)
 def VVWig0(self):
  VVKfpb = CCxXMf.VVcYBO(self, self.VVn4sF)
  if VVKfpb:
   if VVKfpb:
    VVKfpb.sort(key=lambda x: x[0].lower())
    VVtv1H = ("" , self.VVCXkw, [])
    VVm7uJ  = ("Zap", self.VVJ5Oy, [])
    self.VVURhA(VVnxKJ=VVKfpb, VVm7uJ=VVm7uJ, VVtv1H=VVtv1H)
   else:
    FFcui4(self, "Lines\t: %d\nFound\t: %d\nLameDB\t: %d" % (len(lines), txt.count("\n"), len(VVKfpb)))
 def VVz84S(self):
  totT, totC, totA, totS, totS2, satList = self.VVLCvr()
  txt = FF39Hq("Total Transponders:\n\n", VV3hnc)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FF39Hq("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VV3hnc)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFgDL3(item), satList.count(item))
  FFcui4(self, txt)
 def VVLCvr(self):
  lamedbFile, disabledFile = CCxXMf.VVzMpB()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with open(lamedbFile, "r") as f:
    lines = []
    for line in f:
     if not FFjMv5(self):
      return 0, 0, 0, 0, 0, None
     line = line.strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFQJvo(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VV2GEh(self):
  self.VVeuNJ(True)
 def VVhBQS(self):
  self.VVeuNJ(False)
 def VVeuNJ(self, isWithPIcons):
  piconsPath = CC6Hdl.VVH2R4()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CC6Hdl.VVB9DD(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVKfpb = CCxXMf.VVcYBO(self, self.VV32vG)
    if VVKfpb:
     channels = []
     for (chName, chProv, sat, refCode) in VVKfpb:
      if not FFjMv5(self):
       return
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFnMHY(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVKfpb)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVp8k8(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVp8k8("PIcons Path"  , piconsPath)
     txt += VVp8k8("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVp8k8("Total services" , totalServices)
     txt += VVp8k8("With PIcons"  , totalWithPIcons)
     txt += VVp8k8("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFcui4(self, txt)
     else:
      VVtv1H     = (""      , self.VVCXkw , [])
      if isWithPIcons : VVFLU5 = ("Export Current PIcon", self.VVEDRT  , [])
      else   : VVFLU5 = None
      VV2CKM     = ("Statistics", FFcui4, [txt])
      VVm7uJ      = ("Zap", self.VVJ5Oy, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVURhA(VVnxKJ=channels, VVm7uJ=VVm7uJ, VVtv1H=VVtv1H, VV2CKM=VV2CKM, VVFLU5=VVFLU5)
   else:
    FFj9Oj(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFj9Oj(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVCXkw(self, VVqAwN, title, txt, colList):
  png, path = CC6Hdl.VVLXik(colList[3], colList[0])
  CC3OlU.VVm2Ur(self, colList[3], txt, title, path)
 def VVEDRT(self, VVqAwN, title, txt, colList):
  png, path = CC6Hdl.VVLXik(colList[3], colList[0])
  if path:
   CC6Hdl.VV763w(self, png, path)
 @staticmethod
 def VVzMpB():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVAHBx():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VVj0c9(self, isEnable):
  lamedbFile, disabledFile = CCxXMf.VVzMpB()
  if isEnable and not fileExists(disabledFile):
   FFhXFJ(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FFj9Oj(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFi0Lh(self, boundFunction(self.VVBzyv, isEnable), "%s Hidden Channels ?" % word)
 def VVBzyv(self, isEnable):
  lamedbFile , disabledFile = CCxXMf.VVzMpB()
  lamedb5File, diabled5File = CCxXMf.VVAHBx()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FF89ZG()
  if res == 0 : FFhXFJ(self, "Hidden List %s" % word)
  else  : FFj9Oj(self, "Error while restoring:\n\n%s" % fileName)
 def VVQIsp(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFofxf(self, cmd)
 def VVewWT(self):
  lamedbFile, disabledFile = CCxXMf.VVzMpB()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFhmFU("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FF709T(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFhmFU("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FF89ZG()
   FFcui4(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFQJvo(self, lamedbFile)
class CC3OlU(Screen):
 VVw2vK = 0
 VVGO9o   = 1
 VV42vb   = 2
 EPG_MODE_SERVER_IPTV  = 3
 VVaXhE    = 4
 def __init__(self, session, isFromSignal=False, extraInfoData=[]):
  self.skin, self.skinParam = FFm81W(VVQGZG, 1400, 800, 50, 30, 20, "#110B2830", "#050B242c", 30, addFramedPic=True)
  self.extraInfoData = extraInfoData
  if self.extraInfoData:
   self.infoMode = self.extraInfoData[0]
   if self.infoMode == self.VVaXhE: title = self.extraInfoData[2]
   else         : title = "Channel Information"
  else:
   self.infoMode = self.VVw2vK
   title = "Current Service"
   if isFromSignal:
    title += FF39Hq("   (No Signal Monitor for IPTV)", VVdsiT)
  self.Sep = FF39Hq("%s\n", VVdsiT) % VVfebv
  self.session   = session
  FFEPCp(self, title=title, addScrollLabel=True)
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  self["myLabel"].VVOdAK(enableSave=True)
  if   self.infoMode == self.VVw2vK : fnc = self.VVaGsm_fromCurrentChannel
  elif self.infoMode == self.VVGO9o  : fnc = self.VVaGsm_fromFindTable
  elif self.infoMode == self.VV42vb  : fnc = self.VVaGsm_fromLocalIptvTable
  elif self.infoMode == self.EPG_MODE_SERVER_IPTV  : fnc = self.VVaGsm_fromServerIptvTable
  elif self.infoMode == self.VVaXhE   : fnc = self.VVaGsm_fromOthers
  FFFe8v(self, fnc, title="Reading info. ...")
 def VVoB0H(self, err):
  self["myLabel"].setText(err)
  FFUPS3(self["myTitle"], "#22200000")
  FFUPS3(self["myBody"], "#22200000")
  self["myLabel"].FFUPS3Color("#22200000")
  self["myLabel"].VVUAyE()
 def VVXkqv(self, txt, isIptv, chName, refCode, decodedUrl, info=None):
  txt += self.VVDX8r(isIptv, chName, refCode, decodedUrl, info)
  self.VVhFdR(txt)
 def VVaGsm_fromOthers(self):
  mode, refCode, txt, title, VVhesn = self.extraInfoData
  picShown = self.VVDnT2(VVhesn)
  epg = self.VVjCEp(refCode, None)
  if epg:
   txt += epg
  self.VVhFdR(txt)
 def VVhFdR(self, txt):
  self["myLabel"].setText(txt, VVNp8T=VVuJnR)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVUAyE(minHeight=minH)
 def VVaGsm_fromFindTable(self):
  mode, chName, refCode, txt = self.extraInfoData
  txt += self.VVXxek(refCode, refCode, chName)
  isIptv = FFzufs(refCode)
  if isIptv:
   txt += self.VVtbpE(refCode)
  else:
   tp = CCRdiH()
   tpTxt, namespace = tp.VVKIIp(refCode)
   del tp
   if tpTxt:
    txt += self.Sep
    txt += tpTxt
  refCode, decodedUrl, origUrl, iptvRef = FFq3e7(refCode)
  self.VVXkqv(txt, isIptv, chName, refCode, decodedUrl)
 def VVaGsm_fromLocalIptvTable(self):
  mode, chName, refCode, decodedUrl, txt = self.extraInfoData
  txt += self.VVtbpE(refCode + decodedUrl)
  txt += "\n"
  txt += self.VVXxek(refCode, refCode, chName)
  self.VVXkqv(txt, True, chName, refCode, decodedUrl)
 def VVaGsm_fromServerIptvTable(self):
  mode, chName, chUrl, picUrl, refCode, txt = self.extraInfoData
  decodedUrl = FF67mR(chUrl.replace(refCode, "").replace(chName, "").strip(":").strip())
  self.VVXkqv(txt, True, chName, refCode, decodedUrl)
 def VVaGsm_fromCurrentChannel(self):
  info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
  try:
   info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiz95(self)
  except:
   return
  if not info:
   self.VVoB0H("No data from system !")
   return
  chName = info.getName()
  txt = ""
  txt += "Service Name\t: %s\n" % FF39Hq(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VVp8k8(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FF39Hq(state, VVepFH)
   txt += "State\t: %s\n" % state
  w = FFk7cY(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFk7cY(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = FFk7cY(info      , iServiceInformation.sAspect)
  if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : aspect = "4:3"
  else           : aspect = "16:9"
  txt += "Video Format\t: %s\n" % aspect
  txt += self.VVp8k8(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVp8k8(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVp8k8(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  isIptv = len(iptvRef) > 0
  if iptvRef:
   txt += "Service Type\t: %s\n" % FF39Hq("IPTV", VV3hnc)
   txt += self.VVtbpE(iptvRef)
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not refCode:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    path = serv.getPath()
    if path:
     txt += "Path\t: %s\n" % path
  txt += "\n"
  txt += self.VVXxek(refCode, iptvRef, chName)
  if not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCRdiH()
    tpTxt, namespace = tp.VVKIIp(refCode)
    del tp
    if tpTxt:
     txt += FF39Hq("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FF39Hq("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVp8k8(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVp8k8(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVp8k8(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVp8k8(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVp8k8(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVp8k8(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVp8k8(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVp8k8(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVp8k8(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  self.VVXkqv(txt, isIptv, chName, refCode, decodedUrl, info)
 def VVp8k8(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFk7cY(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVF9o1(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVF9o1(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVDX8r(self, isIptv, chName, refCode, decodedUrl, info):
  txt = ""
  sep = "%s\n" % VVfebv
  png, path = CC6Hdl.VVLXik(refCode, chName)
  picShown = False
  if png:
   if VVSc6q:
    txt += "\n"
    txt += sep
    txt += "PIcon:\n"
    txt += "%s\n" % path
   picShown = self.VVDnT2(path)
  txt = ""
  if isIptv:
   epg, err = self.VVjaFF(decodedUrl, refCode, not picShown)
   txt += FF39Hq("\n%sEPG:\n%s" % (sep, sep), COLOR_CONS_BRIGHT_YELLOW)
   if epg : txt += epg
   elif err: txt += FF39Hq(err, VVdsiT)
  else:
   epg = self.VVjCEp(refCode, info)
   if epg:
    txt += epg
  return txt
 def VVjCEp(self, refCode, info):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVR3Yr(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVR3Yr(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVR3Yr(event, 0)
     except:
      pass
  return epg
 def VVR3Yr(self, event, evNum):
  txt = ""
  if event:
   evName = event.getEventName()    or ""
   evTime = event.getBeginTime()    or ""
   evDur = event.getDuration()    or ""
   evShort = event.getShortDescription()  or ""
   evDesc = event.getExtendedDescription() or ""
   if any([evName, evShort, evDesc, evTime, evDur]):
    if evName          : txt += "Name\t: %s\n"   % FF39Hq(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evTime           : txt += "Start Time\t: %s\n" % FFXglk(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFXglk(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FF7B8o(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FF7B8o(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FF7B8o(evTime - now)
    if evShort and evShort.strip()     : txt += "\nSummary:\n%s\n"  % FF39Hq(evShort, VVvBji)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FF39Hq(evDesc , VVvBji)
    if txt:
     txt = FF39Hq("\n%s\n%s Event:\n%s\n" % (VVfebv, ("Current", "Next")[evNum], VVfebv), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVjaFF(self, decodedUrl, refCode, showPIcon):
  if not FF0KEj():
   return "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CC2RcG.VV4GkZ(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "No EPG (not a subscription ULR) !"
  if   uType == "live" : qUrl = "%s/player_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uHost, uUser, uPass, uId)
  elif uType == "movie" : qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
  elif uType == "series" : return "", "No EPG for Series Channels !"
  txt, err = CC2RcG.VV2Mjm(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "Could not parse server data !"
  epg  = ""
  if tDict:
   if uType == "live":
    epg, lang = self.VVZaHF(tDict)
    if epg:
     epg = "Language\t: %s\n\n%s" % (lang, epg)
   elif uType == "movie":
    epg, picUrl = self.VVgcEu(tDict)
    if showPIcon and picUrl:
     path, err = FFarie(picUrl, "ajpanel_tmp.png", timeout=2)
     picShown = self.VVDnT2(path)
     self.VVZVr0(path, refCode)
  if epg : return epg, ""
  else : return "" ,  "No EPG from server !"
 def VVZaHF(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CC2RcG.VVhHeU(item, "title"    , isBase64=True )
     lang    = CC2RcG.VVhHeU(item, "lang"        ).upper()
     description   = CC2RcG.VVhHeU(item, "description"  , isBase64=True )
     start_timestamp  = CC2RcG.VVhHeU(item, "start_timestamp" , isDate=True )
     stop_timestamp  = CC2RcG.VVhHeU(item, "stop_timestamp"  , isDate=True )
     stop_timestamp_unix = CC2RcG.VVhHeU(item, "stop_timestamp"      )
     now_playing   = CC2RcG.VVhHeU(item, "now_playing"      )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VV4Z4E, ""
      else     : color, txt = VVepFH , "    (CURRENT EVENT)"
      epg += FF39Hq("_" * 32 + "\n", VVdsiT)
      epg += FF39Hq("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      epg += "Description:\n%s\n" % FF39Hq(description, VVvBji)
      evNum += 1
   except:
    pass
  return epg, lang
 def VVgcEu(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item =tDict["info"]
    movie_image   = CC2RcG.VVhHeU(item, "movie_image" )
    genre    = CC2RcG.VVhHeU(item, "genre"   ) or "-"
    plot    = CC2RcG.VVhHeU(item, "plot"   ) or "-"
    cast    = CC2RcG.VVhHeU(item, "cast"   ) or "-"
    rating    = CC2RcG.VVhHeU(item, "rating"   ) or "-"
    director   = CC2RcG.VVhHeU(item, "director"  ) or "-"
    releasedate   = CC2RcG.VVhHeU(item, "releasedate" ) or "-"
    duration   = CC2RcG.VVhHeU(item, "duration"  ) or "-"
    epg += "Genre\t: %s\n"  % genre
    epg += "Released\t: %s\n" % releasedate
    epg += "Duration\t: %s\n" % duration
    epg += "Director\t: %s\n" % director
    epg += "Rating\t: %s\n\n" % rating
    epg += "Cast:\n%s\n\n"  % FF39Hq(cast, VVvBji)
    epg += "Plot:\n%s"   % FF39Hq(plot, VVvBji)
   except:
    pass
  return epg, movie_image
 def VVZVr0(self, path, refCode):
  if path and fileExists(path) and os.system(FFhmFU("which ffmpeg")) == 0:
   pPath = CC6Hdl.VVH2R4()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
    cmd += FFhmFU("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVtbpE(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFq3e7(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   txt += "\n"
   txt += FF39Hq("URL:", VV3hnc) + "\n%s\n" % decodedUrl
  else:
   txt = "\n"
   txt += FF39Hq("Reference:", VV3hnc) + "\n%s\n" % refCode
  return txt
 def VVDnT2(self, path):
  if path and fileExists(path):
   err, w, h = self.VVtgJV(path)
   if not err:
    if h > w:
     self.VVx9a7(self["myPicF"], w, h, True)
     self.VVx9a7(self["myPic"] , w, h, False)
   allOK = FF20Za(self["myPic"], path)
   if allOK:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VVx9a7(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVtgJV(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFedlY(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVXxek(self, refCode, iptvRef, chName):
  refCode = FFxYrs(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FF7gKM(VVH4FS + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FF7gKM(VVH4FS + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VVnxKJ = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVH4FS + item
   if fileExists(path):
    txt = FF7gKM(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVnxKJ.append(bName)
  txt = self.Sep
  if VVnxKJ:
   if len(VVnxKJ) == 1:
    txt += "%s\t: %s\n" % (FF39Hq("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VVnxKJ[0])
   else:
    txt += FF39Hq("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VVnxKJ):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 @staticmethod
 def VV5ze1(SELF, chName, refCode, url, txt):
  SELF.session.open(boundFunction(CC3OlU, extraInfoData=[CC3OlU.VV42vb, chName, refCode, url, txt]))
 @staticmethod
 def VVGwcH(SELF, chName, chUrl, picUrl, refCode, txt):
  SELF.session.open(boundFunction(CC3OlU, extraInfoData=[CC3OlU.EPG_MODE_SERVER_IPTV, chName, chUrl, picUrl, refCode, txt]))
 @staticmethod
 def VVns1Y(SELF, chName, refCode, txt):
  SELF.session.open(boundFunction(CC3OlU, extraInfoData=[CC3OlU.VVGO9o, chName, refCode, txt]))
 @staticmethod
 def VVm2Ur(SELF, refCode, txt, title, VVhesn):
  SELF.session.open(boundFunction(CC3OlU, extraInfoData=[CC3OlU.VVaXhE, refCode, txt, title, VVhesn]))
class CC2RcG(Screen):
 VVRNWY = 0
 VVEz9D = 1
 VVJwLW = 2
 VVC9Fs = 3
 VVeCLz  = 4
 VVnGTc  = 5
 VVuVZV  = 6
 VVVGfv  = 7
 VV6bVd   = 8
 VVU9ga  = 9
 VVxNOg  = 10
 VVFyhQ  = 11
 VVEx3i  = 12
 VVfMKb   = 13
 VVx9HQ   = 14
 VV07EQ   = 15
 VVIGPR   = 16
 VVJt71   = 17
 VVKnzT    = 0
 VVqO7q   = 1
 VVzpZR   = 2
 VV4aYl   = 3
 VVRLF5  = 4
 VVDoHM   = 5
 VVxyYk   = 6
 VVsH07  = 7
 VVDzEy  = 8
 VVwhMv   = 9
 VV4OOf = 10
 VVCLJm   = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFm81W(VVk1xP, 1100, 1050, 50, 40, 30, "#0a00292B", "#0a00272B", 30)
  self.session  = session
  self.VVqAwN = None
  self.tableTitle  = "IPTV Channels List"
  self.VV8Iu8Data = {}
  VVqVzN= self.VVvFUR()
  FFEPCp(self, VVqVzN=VVqVzN)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  FFGE7x(self["myMenu"])
  FFmktH(self)
  FFo7Oc(self)
 def VVvFUR(self):
  files = self.VVm3mi()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"    , "VV8Iu8_fromPlayList" ))
  tList.append(("IPTV Server Browser (from M3U File)"     , "VV8Iu8_fromM3u"  ))
  qUrl = self.VV9sWT()
  if qUrl:
   tList.append(("IPTV Server Browser (from Current Channel)"  , "VV8Iu8_fromCurrChan"  ))
  VVqVzN = []
  if files:
   if self.VVqAwN:
    VVqVzN.append(("Add Current List to a New Bouquet"      , "VV4plc"  ))
    VVqVzN.append(VVPkfI)
    VVqVzN.append(("Change Current List References to Unique Codes"   , "VVgl65"))
    VVqVzN.append(("Change Current List References to Identical Codes"  , "VVBtZ4_rows" ))
   else:
    VVqVzN += tList
    VVqVzN.append(VVPkfI)
    VVqVzN.append(("Local IPTV Channels (Live)"        , "iptvTable_live"   ))
    VVqVzN.append(("Local IPTV Channels (All)"        , "iptvTable_all"   ))
    VVqVzN.append(VVPkfI)
    VVqVzN.append(("Count Available IPTV Channels"       , "VV35r6"    ))
    VVqVzN.append(("Check Reference Codes Format"        , "VVsbWP"   ))
    VVqVzN.append(("Check System Acceptable Reference Types"     , "VVJraD"   ))
    VVqVzN.append(VVPkfI)
    VVqVzN.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVyH6c"  ))
    VVqVzN.append(("Change ALL References to Matching Sat/C/T Channels"  , "VVq8qF" ))
    VVqVzN.append(("Change ALL References to Unique Codes"     , "VVkVXq" ))
    VVqVzN.append(("Change ALL References to Identical Codes"     , "VVBtZ4_all" ))
  if not self.VVqAwN:
   if not files:
    VVqVzN += tList
   VVqVzN.append(VVPkfI)
   VVqVzN.append(("Analyse m3u File"            , "VVdcVI"   ))
   VVqVzN.append(("Convert m3u File to Bouquet (from File Manager)"    , "VVBb0x" ))
   VVqVzN.append(("Convert m3u File to Bouquet (from m3u File List)"    , "VV0QN4" ))
   VVqVzN.append(('Convert m3u File to Bouquet (Download from "Play Lists")'  , "VV8T3e" ))
   VVqVzN.append(VVPkfI)
   VVqVzN.append(("Reload Channels and Bouquets"         , "VVAXiI"   ))
  return VVqVzN
 def VVzmDi(self, item):
  if item is not None:
   if   item == "VV4plc"   : FFxR0u(self, self.VV4plc, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVgl65" : FFi0Lh(self, boundFunction(FFFe8v, self.VVqAwN, self.VVgl65 ), "Change Current List References to Unique Codes ?")
   elif item == "VVBtZ4_rows" : FFi0Lh(self, boundFunction(FFFe8v, self.VVqAwN, self.VVBtZ4   ), "Change Current List References to Identical Codes ?")
   elif item == "VV8Iu8_fromPlayList" : FFFe8v(self, boundFunction(self.VVpZtu, True), title="Searching ...")
   elif item == "VV8Iu8_fromM3u"  : FFFe8v(self, boundFunction(self.VVTrGi, 0), title="Searching ...")
   elif item == "VV8Iu8_fromCurrChan" : self.VV8Iu8_fromCurrChan()
   elif item == "iptvTable_live"   : FFFe8v(self, boundFunction(self.VV8BUA, self.VVVGfv ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFFe8v(self, boundFunction(self.VV8BUA, self.VVRNWY) , title="Loading Channels ...")
   elif item == "VV35r6"    : FFFe8v(self, self.VV35r6)
   elif item == "VVsbWP"    : FFFe8v(self, self.VVsbWP)
   elif item == "VVJraD"   : FFFe8v(self, self.VVJraD)
   elif item == "VVyH6c"  : self.VVyH6c()
   elif item == "VVq8qF"  : FFi0Lh(self, boundFunction(FFFe8v, self, self.VVq8qF ), "Copy from existing Sat. Channel" )
   elif item == "VVkVXq" : FFi0Lh(self, boundFunction(FFFe8v, self, self.VVkVXq ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVBtZ4_all" : FFi0Lh(self, boundFunction(FFFe8v, self, self.VVBtZ4  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "VVdcVI"   : FFFe8v(self, boundFunction(self.VVTrGi, 1), title="Searching ...")
   elif item == "VVBb0x" : self.VVBb0x()
   elif item == "VV0QN4" : FFFe8v(self, boundFunction(self.VVTrGi, 2), title="Searching ...")
   elif item == "VV8T3e" : FFFe8v(self, boundFunction(self.VVpZtu, False), title="Searching ...")
   elif item == "VVAXiI"   : FFFe8v(self, boundFunction(CCxXMf.VVAXiI, self))
 def VVzZWl(self):
  global VV6lLO
  VV6lLO = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVzmDi(item)
 def VV8BUA(self, mode):
  VVKfpb = self.VVm0B5(mode)
  if VVKfpb:
   VV2BU1 = ("Current Service", self.VVUbjG , [])
   VV2CKM = ("Options"  , self.VVrMdH   , [])
   VVFLU5 = ("Filter"   , self.VVVskX    , [])
   VVm7uJ  = ("Zap"   , self.VVPrrf   , [])
   VVtv1H = (""    , self.VVSs2V    , [])
   VVD9v1 = (""    , self.VV3bFK     , [])
   VVUoVo = (""    , self.VV6lKF    , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VVfxos  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFqaCW(self, None, header=header, VVnxKJ=VVKfpb, VVfxos=VVfxos, VVf6S2=widths, VVzQkv=22
     , VVm7uJ=VVm7uJ, VV2BU1=VV2BU1, VV2CKM=VV2CKM, VVFLU5=VVFLU5, VVtv1H=VVtv1H, VVD9v1=VVD9v1
     , VVMhkn="#0a00292B", VVLwBG="#0a002126", VVCMEX="#0a002126", VVwS8Y="#00000000", VVSl9p=True, searchCol=1)
  else:
   if mode == self.VVVGfv: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFj9Oj(self, err)
 def VV3bFK(self, VVqAwN, title, txt, colList):
  self.VVqAwN = VVqAwN
 def VV6lKF(self, VVqAwN):
  self.VVqAwN = None
 def VVrMdH(self, VVqAwN, title, txt, colList):
  VVqVzN= self.VVvFUR()
  FFbvqQ(self, self.VVzmDi, title="IPTV Tools", VVqVzN=VVqVzN)
 def VVVskX(self, VVqAwN, title, txt, colList):
  VVqVzN = []
  VVqVzN.append(("All"         , "all"   ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Prefix of Selected Channel"   , "sameName" ))
  VVqVzN.append(("Suggest Words from Selected Channel" , "partName" ))
  VVqVzN.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Live TV"        , "live"  ))
  VVqVzN.append(("VOD"         , "vod"   ))
  VVqVzN.append(("Series"        , "series"  ))
  VVqVzN.append(("Uncategorised"      , "uncat"  ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Video"        , "video"  ))
  VVqVzN.append(("Audio"        , "audio"  ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("MKV"         , "MKV"   ))
  VVqVzN.append(("MP4"         , "MP4"   ))
  VVqVzN.append(("MP3"         , "MP3"   ))
  VVqVzN.append(("AVI"         , "AVI"   ))
  VVqVzN.append(("FLV"         , "FLV"   ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVm4fe()
  if bNames:
   bNames.sort()
   VVqVzN.append(VVPkfI)
   for item in bNames:
    VVqVzN.append((item, "__b__" + item))
  filterObj = CCZ6u9(self)
  filterObj.VVYKnC(VVqVzN, VVqVzN, boundFunction(self.VVajsN, VVqAwN))
 def VVajsN(self, VVqAwN, item=None):
  prefix = VVqAwN.VVtuRl(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVRNWY, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVEz9D , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVJwLW , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVC9Fs , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVVGfv  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VV6bVd   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVU9ga  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVxNOg  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVFyhQ  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVEx3i  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVfMKb   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVx9HQ   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VV07EQ   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVIGPR   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVJt71   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VVuVZV  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVeCLz  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVnGTc  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVJwLW:
   VVqVzN = []
   chName = VVqAwN.VVtuRl(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVqVzN.append((item, item))
    if not VVqVzN and chName:
     VVqVzN.append((chName, chName))
    FFbvqQ(self, boundFunction(self.VVkDvB_partOfName, title), title="Words from Current Selection", VVqVzN=VVqVzN)
   else:
    VVqAwN.VVbwVV("Invalid Channel Name")
  else:
   words, asPrefix = CCZ6u9.VVpQVr(words)
   if not words and mode in (self.VVeCLz, self.VVnGTc):
    FF0fiU(self.VVqAwN, "Incorrect filter", 2000)
   else:
    FFFe8v(self.VVqAwN, boundFunction(self.VVLNbi, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVkDvB_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFFe8v(self.VVqAwN, boundFunction(self.VVLNbi, self.VVJwLW, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 def VVLNbi(self, mode, words, asPrefix, title):
  VVKfpb = self.VVm0B5(mode=mode, words=words, asPrefix=asPrefix)
  if VVKfpb : self.VVqAwN.VV6duD(VVKfpb, title)
  else  : self.VVqAwN.VVbwVV("Not found")
 def VVm0B5(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVKfpb = []
  files  = self.VVm3mi()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FF7gKM(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVT5VC = span.group(1)
    else : VVT5VC = ""
    VVT5VC_lCase = VVT5VC.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVXCWh(chName): chNameMod = FF39Hq(chName, VVESyM)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVT5VC, chType, refCode, url)
     ok = False
     tUrl = FF67mR(url).lower()
     if mode == self.VVRNWY       : ok = True
     elif mode == self.VVuVZV       : ok = True
     elif mode == self.VVFyhQ:
      if CC2RcG.VV4GkZ(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVEx3i:
      if CC2RcG.VV4GkZ(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVVGfv:
      if CC2RcG.VV4GkZ(tUrl, compareType="live")  : ok = True
     elif mode == self.VV6bVd:
      if CC2RcG.VV4GkZ(tUrl, compareType="movie") : ok = True
     elif mode == self.VVU9ga:
      if CC2RcG.VV4GkZ(tUrl, compareType="series") : ok = True
     elif mode == self.VVxNOg:
      if CC2RcG.VV4GkZ(tUrl, compareType="")   : ok = True
     elif mode == self.VVfMKb:
      if CC2RcG.VV4GkZ(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVx9HQ:
      if CC2RcG.VV4GkZ(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VV07EQ:
      if CC2RcG.VV4GkZ(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVIGPR:
      if CC2RcG.VV4GkZ(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VVJt71:
      if CC2RcG.VV4GkZ(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVEz9D:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVJwLW:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVC9Fs:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVeCLz:
      if words[0] == VVT5VC_lCase:
       ok = True
     elif mode == self.VVnGTc:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VVKfpb.append(row)
      chNum += 1
  if VVKfpb and mode == self.VVuVZV:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VVKfpb)
   for item in VVKfpb:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VVKfpb = newRows
  return VVKfpb
 def VV4plc(self, bName):
  if bName:
   FFFe8v(self.VVqAwN, boundFunction(self.VVC12w, bName), title="Adding Channels ...")
 def VVC12w(self, bName):
  num = 0
  path = VVH4FS + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVH4FS + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVqAwN.VV9ASy():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFiZhB(row[1]))
    totChange += 1
  FFun7D(os.path.basename(path))
  self.VVghwW(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVyH6c(self):
  txt = "Stream Type "
  VVqVzN = []
  VVqVzN.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVqVzN.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVqVzN.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVqVzN.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVqVzN.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVqVzN.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFbvqQ(self, self.VV52hA, title="Change Reference Types to:", VVqVzN=VVqVzN)
 def VV52hA(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVu2J0("1"   )
   elif item == "RT_4097" : self.VVu2J0("4097")
   elif item == "RT_5001" : self.VVu2J0("5001")
   elif item == "RT_5002" : self.VVu2J0("5002")
   elif item == "RT_8192" : self.VVu2J0("8192")
   elif item == "RT_8193" : self.VVu2J0("8193")
 def VVu2J0(self, rType):
  FFi0Lh(self, boundFunction(FFFe8v, self, boundFunction(self.VVboo0, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVboo0(self, refType):
  totChange = 0
  files  = self.VVm3mi()
  if files:
   for path in files:
    txt = FF7gKM(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFun7D(os.path.basename(path))
  self.VVghwW(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VV35r6(self):
  totFiles = 0
  files  = self.VVm3mi()
  if files:
   totFiles = len(files)
  totChans = 0
  VVKfpb = self.VVm0B5()
  if VVKfpb:
   totChans = len(VVKfpb)
  FFcui4(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVsbWP(self):
  files  = self.VVm3mi()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FF7gKM(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVul8x
   else    : color = VVepFH
   totInvalid = FF39Hq(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FF39Hq("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFcui4(self, txt, title="Check IPTV References")
 def VVJraD(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVH4FS + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFun7D(os.path.basename(path))
  FF89ZG()
  acceptedList = []
  VVtCo7 = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVtCo7:
   VVJ5Q6 = FF0fvT(VVtCo7)
   if VVJ5Q6:
    for service in VVJ5Q6:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVH4FS + userBName
  bFile = VVH4FS + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFhmFU("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFhmFU("rm -f '%s'" % path)
  os.system(cmd)
  FF89ZG()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVul8x
    else     : res, color = "No" , VVepFH
    txt += "    %s\t: %s\n" % (item, FF39Hq(res, color))
   FFcui4(self, txt, title=title)
  else:
   txt = FFj9Oj(self, "Could not complete the test on your system!", title=title)
 def VVq8qF(self):
  lameDbChans = CCxXMf.VVcYBO(self, CCxXMf.VVbiyT)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVm3mi():
    toSave = False
    txt = FF7gKM(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVghwW(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFj9Oj(self, 'No channels in "lamedb" !')
 def VVkVXq(self):
  files  = self.VVm3mi()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FF709T(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VVElHj(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVghwW(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVgl65(self):
  iptvRefList = []
  files  = self.VVm3mi()
  if files:
   for path in files:
    txt = FF7gKM(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVqAwN.VV2uMm(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VVElHj(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVm3mi()
  if files:
   for path in files:
    lines = FF709T(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VVghwW(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVElHj(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVBtZ4(self):
  list = None
  if self.VVqAwN:
   list = []
   for row in self.VVqAwN.VV9ASy():
    list.append(row[4] + row[5])
  files  = self.VVm3mi()
  totChange = 0
  if files:
   for path in files:
    lines = FF709T(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VVghwW(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVghwW(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FF89ZG()
   if refreshTable and self.VVqAwN:
    VVKfpb = self.VVm0B5()
    if VVKfpb and self.VVqAwN:
     self.VVqAwN.VV6duD(VVKfpb, self.tableTitle)
     self.VVqAwN.VVbwVV(txt)
   FFcui4(self, txt, title=title)
  else:
   FFhXFJ(self, "No changes.")
 def VVm4fe(self):
  files = self.VVm3mi()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with open(path, "r") as f:
     span = iSearch(r"#NAME\s+(.*)", f.readline(), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    VV1dzv = FF0ci0()
    if VV1dzv:
     for b in VV1dzv:
      sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVm3mi(self):
  return CC2RcG.VVHdyL(self)
 @staticmethod
 def VVHdyL(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVH4FS + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FF7gKM(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVSs2V(self, VVqAwN, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FF67mR(colList[5]).strip()
  ndx = txt.find("Ref.")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "Row Number\t: %d of %d\n\n%s" % (VVqAwN.VVrHvs() + 1, VVqAwN.VV5pBz(), txt)
  CC3OlU.VV5ze1(self, chName, refCode, url, txt)
 def VVPrrf(self, VVqAwN, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  self.VVeSek(VVqAwN, chName, chUrl)
 def VV4FfZ(self, mode, VVqAwN, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VV24Ey(mode, colList)
  self.VVeSek(VVqAwN, chName, chUrl)
 def VVeSek(self, VVqAwN, chName, chUrl):
  chName = FFiZhB(chName)
  if not self.VVXCWh(chName):
   FFj5dK(self, chUrl, VVxOas=False)
   if len(chName) > 70:
    chName = chName[:70] + " .."
   self.session.open(CCFtnG)
  else:
   FF0fiU(VVqAwN, "This is a marker!", 300)
 def VVXCWh(self, chName):
  mark = ("--", "__", "==", "##")
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVUbjG(self, VVqAwN, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiz95(self)
  if refCode:
   colDict = { 4:refCode, 5:FFxYrs(refCode, origUrl, chName) }
   VVqAwN.VVkQmG_partial(colDict, showErr=True)
 def VVBb0x(self):
  self.session.open(CC1oiB)
  self.close()
 def VVTrGi(self, m3uMode):
  lines = FFGZr4("find / %s -iname '*.m3u' | grep -i '.m3u'" % FFvH88(1))
  if lines:
   lines.sort()
   VVqVzN = []
   for line in lines:
    VVqVzN.append((line, line))
   if   m3uMode == 0 : title = "Browse Server from M3U URLs"
   elif m3uMode == 1 : title = "Analyse M3U File:"
   else    : title = "Convert M3U File to Bouquet"
   VVTaNU = ("Show Full Path", self.VVEurH)
   OKBtnFnc = boundFunction(self.VVXhU9, m3uMode, title)
   FFbvqQ(self, None, title=title, VVqVzN=VVqVzN, VVTaNU=VVTaNU, OKBtnFnc=OKBtnFnc)
  else:
   FFj9Oj(self, 'No "m3u" files found.')
 def VVEurH(self, VVw5fsObj, url):
  FFcui4(self, url, title="Full Path")
 def VVXhU9(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if   m3uMode == 0 : FFFe8v(menuInstance, boundFunction(self.VVZC5u, title, path))
   elif m3uMode == 1 : FFFe8v(menuInstance, boundFunction(self.VVdcVI, title, path))
   else    : self.VVCN1t(menuInstance, path)
 def VVdcVI(self, title, path):
  if fileExists(path):
   txt = FF7gKM(path)
   totChan   = 0
   totLive   = 0
   totVod   = 0
   totSeries  = 0
   totUncat  = 0
   totVideo  = 0
   totAudio  = 0
   for match in iFinditer(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?((.+)(:[^:\/]+$)|.+)", txt, IGNORECASE):
    totChan += 1
    chName  = match.group(1).strip()
    fullUrl  = match.group(2).strip()
    urlPart1 = match.group(3)
    if urlPart1 : tUrl = urlPart1
    else  : tUrl = fullUrl
    tUrl = FF67mR(tUrl).lower()
    chType, host, username, password, streamId, chName = CC2RcG.VV4GkZ(tUrl)
    if   chType == "live" : totLive += 1
    elif chType == "movie" : totVod += 1
    elif chType == "series" : totSeries += 1
    else     : totUncat += 1
    aud_vid = CC2RcG.VV4GkZ(tUrl, getAudVid=True)
    if   aud_vid == "vid" : totVideo += 1
    elif aud_vid == "aud" : totAudio += 1
   txt = ""
   txt += FF39Hq("File:\n", VV3hnc)
   txt += "    %s\n"    % path
   txt += "\n"
   txt += FF39Hq("Channels:\n", VV3hnc)
   txt += "    Total\t: %d\n" % totChan
   txt += "\n"
   txt += FF39Hq("Category:\n", VV3hnc)
   txt += "    Live\t: %d\n" % totLive
   txt += "    VOD\t: %d\n" % totVod
   txt += "    Series\t: %d\n" % totSeries
   txt += "    Uncat.\t: %d\n" % totUncat
   txt += "\n"
   txt += FF39Hq("Content:\n", VV3hnc)
   txt += "    Video\t: %d\n" % totVideo
   txt += "    Audio\t: %d\n" % totAudio
   txt += "\n"
   FFcui4(self, txt, title="M3U File Analysis")
  else:
   FFj9Oj(SELF, "Cannot open file :\n\n%s" % path, title=title)
   return
 def VVpZtu(self, isBrowseServer):
  lines = FFGZr4('find / %s -iname "*playlist*" | grep -i ".txt"' % FFvH88(1))
  if lines:
   lines.sort()
   VVqVzN = []
   for line in lines:
    VVqVzN.append((line, line))
   OKBtnFnc = boundFunction(self.VVB9AV, isBrowseServer)
   FFbvqQ(self, None, title="Select Playlist File", VVqVzN=VVqVzN, width=1200, OKBtnFnc=OKBtnFnc)
  else:
   FFQJvo(self, "( playlist.txt  or  playlists.txt )")
 def VVB9AV(self, isBrowseServer, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   VVqVzN = []
   lines = FF709T(path)
   for line in lines:
    line = line.strip()
    if line and "/" in line:
     VVqVzN.append((line, line))
   if VVqVzN:
    if isBrowseServer : title = "Select Server URL  (Total = %d)" % len(VVqVzN)
    else    : title = "Convert to Bouquet"
    OKBtnFnc  = boundFunction(self.VV2jlo, isBrowseServer, title)
    VVE2sX  = ("Exit IPTV"  , FFe6kn)
    VVTaNU  = ("Show URL"  , self.VVxubl)
    VVmews   = ("Check & Filter" , boundFunction(self.VVlZqm, path, menuInstance, isBrowseServer))
    FFbvqQ(self, None, title=title, VVqVzN=VVqVzN, width=1200, OKBtnFnc=OKBtnFnc, VVE2sX=VVE2sX, VVTaNU=VVTaNU, VVmews=VVmews)
   else:
    FFj9Oj(self, "No valid URLs in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVxubl(self, VVw5fsObj, url):
  FFcui4(self, url, title="URL")
 def VV2jlo(self, isBrowseServer, title, item=None):
  if item:
   menuInstance, txt, url, ndx = item
   if isBrowseServer:
    FFFe8v(menuInstance, boundFunction(self.VV8hY9, title, url), title="Checking Server ...")
   else:
    FFi0Lh(self, boundFunction(FFFe8v, menuInstance, boundFunction(self.VVbb6l, menuInstance, url), title="Downloading ..."), "Download m3u file from this URL ?\n\n%s" % url, title=title)
 def VVbb6l(self, menuInstance, url):
  path, err = FFarie(url, "ajpanel_tmp.m3u", timeout=3)
  title = "Download Problem"
  if err:
   FFj9Oj(self, err, title=title)
  else:
   if fileExists(path):
    txt = FF7gKM(path)
    if '{"user_info":{"auth":0}}' in txt:
     FFj9Oj(self, "Unauthorized", title=title)
     os.system(FFhmFU("rm -f '%s'" % path))
     return
   self.VVCN1t(menuInstance, path)
 def VVlZqm(self, path, parentMenuInstance, isBrowseServer, menuInstance, url):
  FFFe8v(menuInstance, boundFunction(self.VVFgBG, path, parentMenuInstance, isBrowseServer, menuInstance), title="Filtering Servers ...")
 def VVFgBG(self, path, parentMenuInstance, isBrowseServer, menuInstance):
  VVqVzN = []
  totChk = 0
  totAuth = 0
  for ndx, item in enumerate(menuInstance.VVqVzN):
   totChk += 1
   qUrl = self.VVQBE4(self.VVKnzT, item[0])
   txt, err = self.VV2Mjm(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     isAuth = False
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVhHeU(item, "auth") == "0":
       totAuth += 1
       VVqVzN.append(qUrl)
    except:
     pass
  title = "Authorized Servers"
  if VVqVzN:
   if not totAuth == totChk:
    newPath = path + "_OK_%s.txt" % FFCy03()
    with open(newPath, "w") as f:
     for item in VVqVzN:
      f.write("%s\n" % item)
    self.VVpZtu(isBrowseServer)
    txt = ""
    txt += "Checked\t: %d\n"  %  totChk
    txt += "Authorized\t: %s\n\n" %  FF39Hq(str(totAuth), VVul8x)
    txt += "Output File:\n%s\n " %  FF39Hq(newPath, VVvBji)
    FFcui4(self, txt, title=title)
    menuInstance.close()
    parentMenuInstance.close()
   else:
    FFhXFJ(self, "All URLs are authorized.", title=title)
  else:
   FFj9Oj(self, "No authorized URL found !", title=title)
 def VVCN1t(self, parentInstant, path):
  files = CC2RcG.VVHdyL(self, atLeastOne=True)
  if files: exitCurWin = False
  else : exitCurWin = True
  CC2RcG.VV020V(parentInstant, path, exitCurWin)
 @staticmethod
 def VV020V(SELF, path, exitCurWin):
  FFi0Lh(SELF, boundFunction(FFFe8v, SELF, boundFunction(CC2RcG.VVBWPB, SELF, path, exitCurWin), title="Converting ...")
    , "Convert file to bouquet ?\n\n%s" % path, title="Convert m3u file")
 @staticmethod
 def VVBWPB(SELF, path, exitCurWin):
  SID = TSID = ONID = 0
  MAX = 65535
  title = "Convert m3u File to Bouquet"
  if not fileExists(path):
   FFj9Oj(SELF, "Cannot open file :\n\n%s" % path, title=title)
   return
  bName  = os.path.basename(path)
  bName  = os.path.splitext(bName)[0]
  bName   = CC2RcG.VVQEvg(bName)
  bName  = "IPTV_" + bName
  bFileName = "userbouquet.%s.tv" % bName
  if fileExists(VVH4FS + bFileName):
   while True:
    SID += 1
    tmpBName = "%s_%d" % (bName, SID)
    bFileName = "userbouquet.%s.tv" % tmpBName
    if not fileExists(VVH4FS + bFileName):
     bName = tmpBName
     break
  txt = FF7gKM(path)
  pattern = r"#EXTINF.+,(.+)\n(.+)"
  span = iSearch(r"#EXTINF.+,(.+)\n(.+)", txt, IGNORECASE)
  if span:
   with open(VVH4FS + bFileName, "w") as f:
    totChan = 0
    f.write("#NAME %s\n" % bName.replace("IPTV_", "IPTV - ", 1))
    for match in iFinditer(r"#EXTINF.+,(.+)\n(?:#EXTVLCOPT.+\n)?(.+)", txt, IGNORECASE):
     TSID += 1
     if TSID > MAX:
      TSID = MAX
      ONID += 1
      if ONID > MAX:
       ONID = 0
     chName = match.group(1).strip()
     url  = FFVVb6(match.group(2).strip())
     rType = CFG.iptvAddToBouquetRefType.getValue()
     refCode = "%s:0:1:%s:%s:%s:0:0:0:0:" % (rType, hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:])
     line1 = "#SERVICE %s%s\n" % (refCode.upper(), url)
     line2 = "#DESCRIPTION %s\n" % chName
     f.write(line1 + line2)
     totChan += 1
   FFun7D(bFileName)
   FF89ZG()
   FFhXFJ(SELF, 'New Bouquet = %s\n\nTotal Channels = %d' % (bName, totChan), title=title)
  else:
   FFj9Oj(SELF, "No channels found in file (or invalid file format) !\n\n%s" % path, title=title)
  if exitCurWin:
   SELF.close()
 @staticmethod
 def VV2Mjm(url, timeout=3):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Enigma2-Plugin')
   res = iUrlopen(req, timeout=timeout)
   res = res.read().decode('utf-8')
   if res:
    if "<!DOCTYPE html>" in res : return "", "Incorrect data format from server !"
    else      : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 def VVncpc(self, url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     key, val = part.split("=")
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VV4GkZ(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = parts[1]
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVQBE4(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVncpc(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVKnzT   : return "%s"            % url
  elif mode == self.VVqO7q   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVzpZR   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VV4aYl  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVRLF5 : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVDoHM   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVxyYk    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVsH07  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVDzEy  : return "%s&action=get_simple_data_table&stream_id=%s"  % (url, Id)
  elif mode == self.VVwhMv  : return "%s&action=get_short_epg&stream_id=%s"    % (url, Id)
  elif mode == self.VV4OOf : return "%s&action=get_short_epg&stream_id=%s&limit=%s" % (url, Id, limit)
  elif mode == self.VVCLJm   : return "%s&action=get_vod_info&vod_id=%s"     % (url, Id)
 @staticmethod
 def VVhHeU(item, key, isDate=False, isBase64=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFXglk(int(val))
    elif isBase64 : val = b64decode(val).decode("utf-8")
   except:
    pass
   return val
  else:
   return ""
 def VVZC5u(self, title, path):
  if fileExists(path):
   qUrl = ""
   with open(path, "r") as f:
    for line in f:
     qUrl = self.VVfryH(line)
     if qUrl:
      break
   if qUrl : self.VV8hY9(title, qUrl)
   else : FFj9Oj(self, "No valid Server URL found in:\n\n%s" % path, title=title)
  else:
   FFj9Oj(self, "Cannot open file :\n\n%s" % path, title=title)
 def VV8Iu8_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl = self.VV9sWT()
  if qUrl:
   FFFe8v(self, boundFunction(self.VV8hY9, title, qUrl), title="Checking Server ...")
  else:
   FFj9Oj(self, "Error while trying URL for current channel !", title=title)
 def VV9sWT(self):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiz95(self)
  qUrl = self.VVfryH(decodedUrl)
  return qUrl
 def VVfryH(self, urlLine):
  span  = iSearch(r"\s*(.+)\/\/*(.+)\/(.+)\/(\d+):*", urlLine, IGNORECASE)
  if span:
   uUrl = span.group(1)
   uUser = span.group(2)
   uPass = span.group(3)
   qUrl = "%s/get.php?username=%s&password=%s&type=m3u" % (uUrl, uUser, uPass)
   return qUrl
  else:
   return ""
 def VV8hY9(self, title, url):
  self.VV8Iu8Data = {}
  qUrl = self.VVQBE4(self.VVKnzT, url)
  txt, err = self.VV2Mjm(qUrl)
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VV8Iu8Data = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VV8Iu8Data["username"    ] = self.VVhHeU(item, "username"        )
    self.VV8Iu8Data["password"    ] = self.VVhHeU(item, "password"        )
    self.VV8Iu8Data["message"    ] = self.VVhHeU(item, "message"        )
    self.VV8Iu8Data["auth"     ] = self.VVhHeU(item, "auth"         )
    self.VV8Iu8Data["status"    ] = self.VVhHeU(item, "status"        )
    self.VV8Iu8Data["exp_date"    ] = self.VVhHeU(item, "exp_date"    , isDate=True )
    self.VV8Iu8Data["is_trial"    ] = self.VVhHeU(item, "is_trial"        )
    self.VV8Iu8Data["active_cons"   ] = self.VVhHeU(item, "active_cons"       )
    self.VV8Iu8Data["created_at"   ] = self.VVhHeU(item, "created_at"   , isDate=True )
    self.VV8Iu8Data["max_connections"  ] = self.VVhHeU(item, "max_connections"      )
    self.VV8Iu8Data["allowed_output_formats"] = self.VVhHeU(item, "allowed_output_formats"    )
    lst = []
    key = "allowed_output_formats"
    if key in item:
     for item in item[key]:
      lst.append(str(item))
     self.VV8Iu8Data[key] = lst
    item = tDict["server_info"]
    self.VV8Iu8Data["url"    ] = self.VVhHeU(item, "url"        )
    self.VV8Iu8Data["port"    ] = self.VVhHeU(item, "port"        )
    self.VV8Iu8Data["https_port"  ] = self.VVhHeU(item, "https_port"      )
    self.VV8Iu8Data["server_protocol" ] = self.VVhHeU(item, "server_protocol"     )
    self.VV8Iu8Data["rtmp_port"   ] = self.VVhHeU(item, "rtmp_port"       )
    self.VV8Iu8Data["timezone"   ] = self.VVhHeU(item, "timezone"       )
    self.VV8Iu8Data["timestamp_now"  ] = self.VVhHeU(item, "timestamp_now"  , isDate=True )
    self.VV8Iu8Data["time_now"   ] = self.VVhHeU(item, "time_now"       )
    VVqVzN = []
    VVqVzN.append(("Live"     , "serverLive"  ))
    VVqVzN.append(("VOD"     , "serverVod"  ))
    VVqVzN.append(("Series (Seasons)"  , "serverSeries" ))
    VVqVzN.append(VVPkfI)
    VVqVzN.append(("User/Server Info." , "serverInfo"  ))
    OKBtnFnc  = self.VV8Iu8Options
    VVE2sX  = ("Exit IPTV", FFe6kn)
    FFbvqQ(self, None, title="Server Resources", VVqVzN=VVqVzN, OKBtnFnc=OKBtnFnc, VVE2sX=VVE2sX)
   else:
    err = "Could not get data from server !"
  if err:
   FFj9Oj(self, err, title=title)
  FF0fiU(self)
 def VV8Iu8Options(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "serverLive" : FFFe8v(menuInstance, boundFunction(self.VVvI9q, self.VVqO7q , title=title), title=wTxt)
   elif ref == "serverVod"  : FFFe8v(menuInstance, boundFunction(self.VVvI9q, self.VVzpZR , title=title), title=wTxt)
   elif ref == "serverSeries" : FFFe8v(menuInstance, boundFunction(self.VVvI9q, self.VV4aYl, title=title), title=wTxt)
   elif ref == "serverInfo" : FFFe8v(menuInstance, boundFunction(self.VVWiOy          , title=title), title=wTxt)
 def VVWiOy(self, title):
  c1 = VVESyM
  c2 = VVMwfZ
  list = []
  list.append((FF39Hq("User" , c1), "Username"    , self.VV8Iu8Data["username"    ]))
  list.append((FF39Hq("User" , c1), "Password"    , self.VV8Iu8Data["password"    ]))
  list.append((FF39Hq("User" , c1), "Message"    , self.VV8Iu8Data["message"        ]))
  list.append((FF39Hq("User" , c1), "Auth"     , self.VV8Iu8Data["auth"     ]))
  list.append((FF39Hq("User" , c1), "Status"     , self.VV8Iu8Data["status"        ]))
  list.append((FF39Hq("User" , c1), "Expiry"     , self.VV8Iu8Data["exp_date"    ]))
  list.append((FF39Hq("User" , c1), "Is Trial"    , self.VV8Iu8Data["is_trial"    ]))
  list.append((FF39Hq("User" , c1), "Active Cons"   , self.VV8Iu8Data["active_cons"       ]))
  list.append((FF39Hq("User" , c1), "Created"    , self.VV8Iu8Data["created_at"    ]))
  list.append((FF39Hq("User" , c1), "Max Connections"  , self.VV8Iu8Data["max_connections"   ]))
  list.append((FF39Hq("User" , c1), "Allowed Output Formats" , " , ".join(self.VV8Iu8Data["allowed_output_formats"])))
  list.append((FF39Hq("Server" , c2), "URL"     , self.VV8Iu8Data["url"         ]))
  list.append((FF39Hq("Server" , c2), "Port"     , self.VV8Iu8Data["port"     ]))
  list.append((FF39Hq("Server" , c2), "HTTPS Port"    , self.VV8Iu8Data["https_port"       ]))
  list.append((FF39Hq("Server" , c2), "Server Protocol"  , self.VV8Iu8Data["server_protocol"      ]))
  list.append((FF39Hq("Server" , c2), "RTMP Port"    , self.VV8Iu8Data["rtmp_port"    ]))
  list.append((FF39Hq("Server" , c2), "Timezone"    , self.VV8Iu8Data["timezone"    ]))
  list.append((FF39Hq("Server" , c2), "Local Time"    , self.VV8Iu8Data["timestamp_now"   ]))
  list.append((FF39Hq("Server" , c2), "Server Time"   , self.VV8Iu8Data["time_now"    ]))
  header   = ("User/Server", "Subject" , "Value" )
  widths   = (15   , 45   , 40  )
  FFqaCW(self, None, title=title, header=header, VVnxKJ=list, VVf6S2=widths, VVzQkv=26, VVMhkn="#0a00292B", VVLwBG="#0a002126", VVCMEX="#0a002126", VVwS8Y="#00000000")
  FF0fiU(self)
 def VVjK0q(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    if mode == self.VVDoHM:
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVhHeU(item, "num"         )
      name     = self.VVhHeU(item, "name"        )
      stream_id    = self.VVhHeU(item, "stream_id"       )
      stream_icon    = self.VVhHeU(item, "stream_icon"       )
      epg_channel_id   = self.VVhHeU(item, "epg_channel_id"      )
      added     = self.VVhHeU(item, "added"    , isDate=True )
      is_adult    = self.VVhHeU(item, "is_adult"       )
      category_id    = self.VVhHeU(item, "category_id"       )
      if self.VVXCWh(name): name = FF39Hq(name, VVESyM)
      list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVxyYk:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVhHeU(item, "num"         )
      name    = self.VVhHeU(item, "name"        )
      stream_id   = self.VVhHeU(item, "stream_id"       )
      stream_icon   = self.VVhHeU(item, "stream_icon"       )
      added    = self.VVhHeU(item, "added"    , isDate=True )
      is_adult   = self.VVhHeU(item, "is_adult"       )
      category_id   = self.VVhHeU(item, "category_id"       )
      container_extension = self.VVhHeU(item, "container_extension"     ) or "mp4"
      if self.VVXCWh(name): name = FF39Hq(name, VVESyM)
      list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVsH07:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVhHeU(item, "num"        )
      name    = self.VVhHeU(item, "name"       )
      series_id   = self.VVhHeU(item, "series_id"      )
      cover    = self.VVhHeU(item, "cover"       )
      genre    = self.VVhHeU(item, "genre"       )
      episode_run_time = self.VVhHeU(item, "episode_run_time"    )
      category_id   = self.VVhHeU(item, "category_id"      )
      container_extension = self.VVhHeU(item, "container_extension"    ) or "mp4"
      if self.VVXCWh(name): name = FF39Hq(name, VVESyM)
      list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVvI9q(self, mode, title):
  qUrl = self.VVQBE4(mode, self.VV8Iu8Data["playListURL"])
  txt, err = self.VV2Mjm(qUrl)
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     for item in tDict:
      category_id  = self.VVhHeU(item, "category_id"  )
      category_name = self.VVhHeU(item, "category_name" )
      parent_id  = self.VVhHeU(item, "parent_id"  )
      if category_name:
       list.append((category_name, category_id, parent_id))
   except:
    err = "Cannot parse received data !"
  else:
   FFj9Oj(self, err, title=title)
  if err:
   FFj9Oj(self, err, title=title)
  elif list:
   list.sort(key=lambda x: x[0].lower())
   if   mode == self.VVqO7q  : okTitle = "Show Channels"
   elif mode == self.VVzpZR  : okTitle = "Show Channels"
   elif mode == self.VV4aYl : okTitle = "Show List"
   VVm7uJ  = (okTitle, boundFunction(self.VVQD3p, mode) , [])
   VVUaPo = ("Exit IPTV"   , FFe6kn       , [])
   header   = ("Category", "catID" , "ParentID" )
   widths   = (100   , 0  , 0    )
   FFqaCW(self, None, title=title, header=header, VVnxKJ=list, VVf6S2=widths, VVzQkv=30, VVUaPo=VVUaPo, VVm7uJ=VVm7uJ, VVMhkn="#0a00292B", VVLwBG="#0a002126", VVCMEX="#0a002126", VVwS8Y="#00000000")
  else:
   FFj9Oj(self, "No list from server !", title=title)
  FF0fiU(self)
 def VVQD3p(self, mode, VVqAwN, title, txt, colList):
  title = colList[1]
  FFFe8v(VVqAwN, boundFunction(self.VV2oEO, mode, VVqAwN, title, txt, colList), title="Downloading ...")
 def VV2oEO(self, mode, VVqAwN, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title  = bName
  if   mode == self.VVqO7q  : mode, title = self.VVDoHM  , "Live = %s" % title
  elif mode == self.VVzpZR  : mode, title = self.VVxyYk  , "VOD = %s" % title
  elif mode == self.VV4aYl : mode, title = self.VVsH07 , "Series = %s" % title
  qUrl  = self.VVQBE4(mode, self.VV8Iu8Data["playListURL"], catID)
  txt, err = self.VV2Mjm(qUrl)
  list  = []
  if not err:
   if   mode == self.VVDoHM : list, err = self.VVjK0q(mode, txt)
   elif mode == self.VVxyYk  : list, err = self.VVjK0q(mode, txt)
   elif mode == self.VVsH07 : list, err = self.VVjK0q(mode, txt)
  if err:
   FFj9Oj(self, err, title=title)
  elif list:
   VVUaPo  = ("Exit IPTV"   , FFe6kn            , [])
   if mode == self.VVDoHM:
    VVm7uJ  = ("Play"    , boundFunction(self.VV4FfZ, mode)    , [])
    VVtv1H = (""     , boundFunction(self.VV5803, mode)    , [])
    VV2BU1 = ("Download PIcons" , boundFunction(self.VVUwet , mode)   , [])
    VV2CKM = ("Add ALL to Bouquet" , boundFunction(self.VVmSKE, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 69  , 0   , 0   , 0  , 23  , 0   , 0   )
    VVfxos  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVxyYk:
    VVm7uJ  = ("Play"    , boundFunction(self.VV4FfZ, mode)    , [])
    VVtv1H = (""     , boundFunction(self.VV5803, mode)    , [])
    VV2BU1 = ("Download PIcons" , boundFunction(self.VVUwet , mode)   , [])
    VV2CKM = ("Add ALL to Bouquet" , boundFunction(self.VVmSKE, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 69  , 0   , 0   , 0  , 23  , 0   , 0  )
    VVfxos  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVsH07:
    VVm7uJ  = ("Show Seasons", boundFunction(self.VVngA5, mode), [])
    VVtv1H = ("", boundFunction(self.VV2ZUo, mode), [])
    VV2BU1 = None
    VV2CKM = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 69  , 0   , 0   , 23  , 0  , 0  , 0   )
    VVfxos  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFqaCW(self, None, title=title, header=header, VVnxKJ=list, VVfxos=VVfxos, VVf6S2=widths, VVzQkv=24, VVm7uJ=VVm7uJ, VVUaPo=VVUaPo, VV2BU1=VV2BU1, VV2CKM=VV2CKM, VVtv1H=VVtv1H, searchCol=1, VVMhkn="#0a00292B", VVLwBG="#0a002126", VVCMEX="#0a002126", VVwS8Y="#00000000", VVSl9p=True)
  else:
   FFj9Oj(self, "No Channels found !", title=title)
  FF0fiU(self)
 def VVngA5(self, mode, VVqAwN, title, txt, colList):
  title = colList[1]
  FFFe8v(VVqAwN, boundFunction(self.VVRRtO, mode, VVqAwN, title, txt, colList), title="Downloading ...")
 def VVRRtO(self, mode, VVqAwN, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVQBE4(self.VVRLF5, self.VV8Iu8Data["playListURL"], series_id)
  txt, err = self.VV2Mjm(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVhHeU(tDict["info"], "name"   )
      category_id = self.VVhHeU(tDict["info"], "category_id" )
      icon  = self.VVhHeU(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVhHeU(EP, "id"     )
        episode_num   = self.VVhHeU(EP, "episode_num"   )
        epTitle    = self.VVhHeU(EP, "title"     )
        container_extension = self.VVhHeU(EP, "container_extension" )
        seasonNum   = self.VVhHeU(EP, "season"    )
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFj9Oj(self, err, title=title)
  elif list:
   VVUaPo = ("Exit IPTV"   , FFe6kn            , [])
   VV2BU1 = ("Download PIcons" , boundFunction(self.VVUwet , mode)   , [])
   VV2CKM = ("Add ALL to Bouquet" , boundFunction(self.VVmSKE, mode, title) , [])
   VVtv1H = (""     , boundFunction(self.VV5803, mode)    , [])
   VVm7uJ  = ("Play"    , boundFunction(self.VV4FfZ, mode)    , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVfxos  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFqaCW(self, None, title=title, header=header, VVnxKJ=list, VVfxos=VVfxos, VVf6S2=widths, VVzQkv=24, VVUaPo=VVUaPo, VV2BU1=VV2BU1, VVm7uJ=VVm7uJ, VVtv1H=VVtv1H, VV2CKM=VV2CKM, VVMhkn="#0a00292B", VVLwBG="#0a002126", VVCMEX="#0a002126", VVwS8Y="#00000000")
  else:
   FFj9Oj(self, "No Channels found !", title=title)
  FF0fiU(self)
 def VV24Ey(self, mode, colList):
  if mode == self.VVDoHM:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVxyYk:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFiZhB(chName)
  url = self.VV8Iu8Data["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVncpc(url)
  refCode = self.VV12aK(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VV5803(self, mode, VVqAwN, title, txt, colList):
  FFFe8v(VVqAwN, boundFunction(self.VV1QoF, mode, VVqAwN, title, txt, colList))
 def VV1QoF(self, mode, VVqAwN, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VV24Ey(mode, colList)
  CC3OlU.VVGwcH(self, chName, chUrl, picUrl, refCode, txt)
 def VV2ZUo(self, mode, VVqAwN, title, txt, colList):
  FFFe8v(VVqAwN, boundFunction(self.VVvvRx, mode, VVqAwN, title, txt, colList))
 def VVvvRx(self, mode, VVqAwN, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  += "Duration\t: %s" % Dur
  if Cover: path, err = FFarie(Cover, "ajpanel_tmp.png", timeout=1)
  else : path = ""
  CC3OlU.VVm2Ur(self, "", txt, title, path)
 def VVmSKE(self, mode, bName, VVqAwN, title, txt, colList):
  FFFe8v(VVqAwN, boundFunction(self.VVSCbt, mode, bName, VVqAwN, title, txt, colList), title="Adding Channels ...")
 def VVSCbt(self, mode, bName, VVqAwN, title, txt, colList):
  url = self.VV8Iu8Data["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVncpc(url)
  bNameFile = CC2RcG.VVQEvg(bName)
  num  = 0
  path = VVH4FS + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVH4FS + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in VVqAwN.VV9ASy():
    chName, chUrl, picUrl, refCode = self.VV24Ey(mode, row)
    f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
    f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
    totChange += 1
  FFun7D(os.path.basename(path))
  self.VVghwW(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVUwet(self, mode, VVqAwN, title, txt, colList):
  if os.system(FFhmFU("which ffmpeg")) == 0:
   self.session.open(boundFunction(CCRyHO, iptvTableInstance=self, VVqAwN=VVqAwN, piconMode=mode))
  else:
   FFi0Lh(self, self.VVfd3m, '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?')
 def VVfd3m(self):
  cmd = FFxt6o(VVEmKG, "ffmpeg")
  if cmd : FFFM6I(self, cmd, title="Installing FFmpeg")
  else : FFhggE(self)
 def VV12aK(self, catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = self.VVwQTH(catID, MAX_4b)
  TSID = self.VVwQTH(chNum, MAX_4b)
  ONID = self.VVwQTH(chNum, MAX_4b)
  NS  = self.VVwQTH(stID, MAX_8b)
  int(catID) if catID.isdigit() else ""
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 def VVwQTH(self, numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVQEvg(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
class CC9nXL(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFm81W(VVk1xP, 700, 700, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VV43V4  = 0
  self.VVRPlQ = 1
  self.VVWHwA  = 2
  VVqVzN = []
  VVqVzN.append(("Find All (from filter)"    , "VVctrt" ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Find All"        , "VVyv00"    ))
  VVqVzN.append(("Find TV"        , "VVyqAO"    ))
  VVqVzN.append(("Find Radio"       , "VVzkRL"   ))
  if self.VVFRKI():
   VVqVzN.append(VVPkfI)
   VVqVzN.append(("Hide Channel: %s" % self.servName , "VVFl1d"   ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Zap History"       , "VVQBMt"    ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("PIcons Tools"       , "PIconsTools"     ))
  VVqVzN.append(("Channels Tools"      , "ChannelsTools"    ))
  FFEPCp(self, VVqVzN=VVqVzN, title=title)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  FFGE7x(self["myMenu"])
  FFmktH(self)
  if self.isFindMode:
   self.VVIGmE(self.VVRQQw())
 def VVzZWl(self):
  global VV6lLO
  VV6lLO = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVyv00"    : self.VVyv00()
   elif item == "VVctrt" : self.VVctrt()
   elif item == "VVyqAO"    : self.VVyqAO()
   elif item == "VVzkRL"   : self.VVzkRL()
   elif item == "VVFl1d"   : self.VVFl1d()
   elif item == "VVQBMt"    : self.VVQBMt()
   elif item == "PIconsTools"     : self.session.open(CC6Hdl)
   elif item == "ChannelsTools"    : self.session.open(CCxXMf)
 def VVyqAO(self) : self.VVIGmE(self.VV43V4)
 def VVzkRL(self) : self.VVIGmE(self.VVRPlQ)
 def VVyv00(self) : self.VVIGmE(self.VVWHwA)
 def VVIGmE(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFxR0u(self, boundFunction(self.VVX8LX, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VVctrt(self):
  filterObj = CCZ6u9(self)
  filterObj.VVK5ua(self.VVq5O7)
 def VVq5O7(self, item):
  self.VVX8LX(self.VVWHwA, item)
 def VVFRKI(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFzufs(self.refCode)        : return False
  return True
 def VVX8LX(self, mode, VVeKmv):
  FFFe8v(self, boundFunction(self.VV7FAv, mode, VVeKmv), title="Searching ...")
 def VV7FAv(self, mode, VVeKmv):
  if VVeKmv:
   self.findTxt = VVeKmv
   if   mode == self.VV43V4  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVRPlQ : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVeKmv)
   if len(title) > 55:
    title = title[:55] + ".."
   VVKfpb = self.VVKIeL(VVeKmv, servTypes)
   if self.isFindMode or mode == self.VVWHwA:
    VVKfpb += self.VVqDFn(VVeKmv)
   if VVKfpb:
    VVKfpb.sort(key=lambda x: x[0].lower())
    VVUoVo = self.VVE6yL
    VVm7uJ  = ("Zap"   , self.VVbvL2    , [])
    VV2BU1 = ("Current Service", self.VVjm62 , [])
    VV2CKM = ("Options"  , self.VVnOMC , [])
    VVtv1H = (""    , self.VVuLBE , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVfxos  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFqaCW(self, None, title=title, header=header, VVnxKJ=VVKfpb, VVfxos=VVfxos, VVf6S2=widths, VVzQkv=25, VVm7uJ=VVm7uJ, VVUoVo=VVUoVo, VV2BU1=VV2BU1, VV2CKM=VV2CKM, VVtv1H=VVtv1H)
   else:
    self.VVIGmE(self.VVRQQw())
    FFhXFJ(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVKIeL(self, VVeKmv, servTypes):
  VVgANK  = eServiceCenter.getInstance()
  VVTQow   = '%s ORDER BY name' % servTypes
  VV0tim   = eServiceReference(VVTQow)
  VVemMq = VVgANK.list(VV0tim)
  if VVemMq: VVnxKJ = VVemMq.getContent("CN", False)
  else     : VVnxKJ = None
  VVKfpb = []
  if VVnxKJ:
   VVzLy1, VVI06l = FFIHPD()
   tp   = CCRdiH()
   words, asPrefix = CCZ6u9.VVpQVr(VVeKmv)
   colorYellow  = CCndzU.VVMaPH(VVESyM)
   colorWhite  = CCndzU.VVMaPH(VV4Z4E)
   for s in VVnxKJ:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFIEWh(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVzLy1:
        STYPE = VVI06l[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVcat9(refCode)
       if not "-S" in syst:
        sat = syst
       VVKfpb.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVKfpb
 def VVqDFn(self, VVeKmv):
  VVeKmv = VVeKmv.lower()
  VV1dzv = FF0ci0()
  VVKfpb = []
  colorYellow  = CCndzU.VVMaPH(VVESyM)
  colorWhite  = CCndzU.VVMaPH(VV4Z4E)
  if VV1dzv:
   for b in VV1dzv:
    VVT5VC  = b[0]
    VVDkQm  = b[1].toString()
    VVtCo7 = eServiceReference(VVDkQm)
    VVJ5Q6 = FF0fvT(VVtCo7)
    for service in VVJ5Q6:
     refCode  = service[0]
     if FFzufs(refCode):
      servName = service[1]
      if VVeKmv in servName.lower():
       servName = iSub(r"(%s)" % iEscape(VVeKmv), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
       VVKfpb.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVKfpb
 def VVRQQw(self):
  VVW3zD = InfoBar.instance
  if VVW3zD:
   VVGkgl = VVW3zD.servicelist
   if VVGkgl:
    return VVGkgl.mode == 1
  return self.VVWHwA
 def VVE6yL(self, VVqAwN):
  self.close()
  VVqAwN.cancel()
 def VVbvL2(self, VVqAwN, title, txt, colList):
  FFj5dK(VVqAwN, colList[2], VVxOas=False, checkParentalControl=True)
 def VVjm62(self, VVqAwN, title, txt, colList):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiz95(VVqAwN)
  if refCode:
   VVqAwN.VVFBev(2, FFxYrs(refCode, iptvRef, chName), True)
 def VVnOMC(self, VVqAwN, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CC6pTH(self, VVqAwN, 2)
  mSel.VVsOQx(servName, refCode)
 def VVuLBE(self, VVqAwN, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  CC3OlU.VVns1Y(self, chName, refCode, txt)
 def VVFl1d(self):
  FFi0Lh(self, self.VVeNZt, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVeNZt(self):
  ret = FFlRJL(self.refCode, True)
  if ret:
   self.VVhret()
   self.close()
  else:
   FF0fiU(self, "Cannot change state" , 1000)
 def VVhret(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVc4pq()
  except:
   self.VVOv5x()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      self.session.nav.playService(serviceRef)
 def VVSqRp(self):
  VVW3zD = InfoBar.instance
  if VVW3zD:
   VVGkgl = VVW3zD.servicelist
   if VVGkgl:
    VVGkgl.setMode()
 def VVc4pq(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVW3zD = InfoBar.instance
   if VVW3zD:
    VVGkgl = VVW3zD.servicelist
    if VVGkgl:
     hList = VVGkgl.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVGkgl.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVGkgl.history  = newList
       VVGkgl.history_pos = pos
 def VVOv5x(self):
  VVW3zD = InfoBar.instance
  if VVW3zD:
   VVGkgl = VVW3zD.servicelist
   if VVGkgl:
    VVGkgl.history  = []
    VVGkgl.history_pos = 0
 def VVQBMt(self):
  VVW3zD = InfoBar.instance
  VVKfpb = []
  if VVW3zD:
   VVGkgl = VVW3zD.servicelist
   if VVGkgl:
    VVzLy1, VVI06l = FFIHPD()
    for chParams in VVGkgl.history:
     refCode = chParams[-1].toString()
     chName = FFCNiw(refCode)
     isIptv = FFzufs(refCode)
     if isIptv: sat = "-"
     else  : sat = FFIEWh(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVzLy1:
       STYPE = VVI06l[sTypeInt]
     VVKfpb.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVKfpb:
   VVm7uJ  = ("Zap"   , self.VV6MBD   , [])
   VV2CKM = ("Clear History" , self.VV9sf9   , [])
   VVtv1H = (""    , self.VVaGsmFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVfxos  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFqaCW(self, None, title=title, header=header, VVnxKJ=VVKfpb, VVfxos=VVfxos, VVf6S2=widths, VVzQkv=23, VVm7uJ=VVm7uJ, VV2CKM=VV2CKM, VVtv1H=VVtv1H)
  else:
   FFhXFJ(self, "Not found", title=title)
 def VV6MBD(self, VVqAwN, title, txt, colList):
  FFj5dK(VVqAwN, colList[3], VVxOas=False, checkParentalControl=True)
 def VV9sf9(self, VVqAwN, title, txt, colList):
  FFi0Lh(self, boundFunction(self.VVcxvt, VVqAwN), "Clear Zap History ?")
 def VVcxvt(self, VVqAwN):
  self.VVOv5x()
  VVqAwN.cancel()
 def VVaGsmFromZapHistory(self, VVqAwN, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  png, path = CC6Hdl.VVLXik(refCode, chName)
  CC3OlU.VVm2Ur(self, refCode, txt, title, path)
class CC6Hdl(Screen):
 VVtegw   = 0
 VVm3R7  = 1
 VVJN4A  = 2
 VVX5Eq  = 3
 VVlsf2  = 4
 VVLtnE  = 5
 VVxzHO  = 6
 VVA1qW  = 7
 VVSZrG = 8
 VVZzqx = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFm81W(VVOPX4, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FFEPCp(self, self.Title)
  FFIj9t(self["keyRed"] , "OK = Zap")
  FFIj9t(self["keyGreen"] , "Current Service")
  FFIj9t(self["keyYellow"], "Page Options")
  FFIj9t(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CC6Hdl.VVH2R4()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVnxKJ    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVcwjH   ,
   "green"   : self.VVQ16q  ,
   "yellow"  : self.VVmYh2   ,
   "blue"   : self.VVOlz3   ,
   "menu"   : self.VVFI23   ,
   "info"   : self.VVaGsm    ,
   "up"   : self.VVtCHb     ,
   "down"   : self.VVBVsz    ,
   "left"   : self.VV29Kt    ,
   "right"   : self.VVms4U    ,
   "pageUp"  : self.VVrAsy    ,
   "chanUp"  : self.VVrAsy    ,
   "pageDown"  : self.VVhAlO   ,
   "chanDown"  : self.VVhAlO   ,
   "next"   : self.VVZmtf    ,
   "last"   : self.VVv2oJ    ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  FFbkgB(self)
  FFUPS3(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFFe8v(self, boundFunction(self.VVCDEH, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVFI23(self):
  if not self.isBusy:
   VVqVzN = []
   VVqVzN.append(("Statistics"           , "VVUYgA"    ))
   VVqVzN.append(VVPkfI)
   VVqVzN.append(("Suggest PIcons for Current Channel"     , "VVwPXj"   ))
   VVqVzN.append(("Set to Current Channel (copy file)"     , "VVgsrU_file"  ))
   VVqVzN.append(("Set to Current Channel (as SymLink)"     , "VVgsrU_link"  ))
   VVqVzN.append(VVPkfI)
   VVqVzN.append(CC6Hdl.VVl7Iz())
   VVqVzN.append(VVPkfI)
   VVqVzN.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVoSMw"  ))
   VVqVzN.append(VVPkfI)
   VVqVzN += CC6Hdl.VVYCXL()
   FFbvqQ(self, self.VVzmDi, title=self.Title, VVqVzN=VVqVzN)
 def VVzmDi(self, item=None):
  if item is not None:
   if   item == "VVUYgA"     : self.VVUYgA()
   elif item == "VVwPXj"    : FFFe8v(self, self.VVwPXj, clearMsg=False)
   elif item == "VVgsrU_file"   : self.VVgsrU(0)
   elif item == "VVgsrU_link"   : self.VVgsrU(1)
   elif item == "VVFExa_file"  : self.VVFExa(0)
   elif item == "VVFExa_link"  : self.VVFExa(1)
   elif item == "VVpedy"   : self.VVpedy()
   elif item == "VVyzTO"  : self.VVyzTO()
   elif item == "VVhW8v"   : self.VVhW8v()
   elif item == "VVoSMw"   : self.VVoSMw()
   elif item == "VV3vYD"   : CC6Hdl.VV3vYD(self)
   elif item == "VVPj7u"   : CC6Hdl.VVPj7u(self)
   elif item == "findPiconBrokenSymLinks"  : CC6Hdl.VVlwob(self, True)
   elif item == "FindAllBrokenSymLinks"  : CC6Hdl.VVlwob(self, False)
 def VVmYh2(self):
  if not self.isBusy:
   VVqVzN = []
   VVqVzN.append(("Go to First PIcon   ( < )" , "VVv2oJ"  ))
   VVqVzN.append(("Go to Last PIcon   ( > )"  , "VVZmtf"  ))
   VVqVzN.append(VVPkfI)
   VVqVzN.append(("Sort by Channel Name"      , "sortByChan" ))
   VVqVzN.append(("Sort by File Name"   , "sortByFile" ))
   VVqVzN.append(VVPkfI)
   VVqVzN.append(("Find from File List .."  , "VVnAeU" ))
   FFbvqQ(self, self.VVIZA0, title=self.Title, VVqVzN=VVqVzN)
 def VVIZA0(self, item=None):
  if item is not None:
   if   item == "VVv2oJ"   : self.VVv2oJ()
   elif item == "VVZmtf"   : self.VVZmtf()
   elif item == "sortByChan"  : self.VVfvZS(2)
   elif item == "sortByFile"  : self.VVfvZS(0)
   elif item == "VVnAeU"  : self.VVnAeU()
 def VVtCHb(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVZmtf()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVUXTo()
 def VVBVsz(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVv2oJ()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVUXTo()
 def VV29Kt(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVZmtf()
  else:
   self.curCol -= 1
   self.VVUXTo()
 def VVms4U(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVv2oJ()
  else:
   self.curCol += 1
   self.VVUXTo()
 def VVrAsy(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVUXTo(True)
 def VVhAlO(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVUXTo(True)
 def VVv2oJ(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVUXTo(True)
 def VVZmtf(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVUXTo(True)
 def VVnAeU(self):
  VVqVzN = []
  for item in self.VVnxKJ:
   VVqVzN.append((item[0], item[0]))
  FFbvqQ(self, self.VV2kgO, title='PIcons ".png" Files', VVqVzN=VVqVzN, VV1G3P=True)
 def VV2kgO(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVkkjJ(ndx)
 def VVcwjH(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVtxlg()
   if refCode:
    FFj5dK(self, refCode)
    self.VVsImx()
    self.VVMVCT()
 def VVQ16q(self):
  if self["keyGreen"].getVisible():
   self.VVkkjJ(self.curChanIndex)
 def VVkkjJ(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVUXTo(True)
  else:
   FF0fiU(self, "Not found", 1000)
 def VVfvZS(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFFe8v(self, boundFunction(self.VVCDEH, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVgsrU(self, mode):
  title = "Change Current Channel PIcon"
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiz95(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVtxlg()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVqVzN = []
     VVqVzN.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVqVzN.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFbvqQ(self, boundFunction(self.VVN5XU, mode, curChF, selPiconF), VVqVzN=VVqVzN, title="Current Channel PIcon (already exists)")
    else:
     self.VVN5XU(mode, curChF, selPiconF, "overwrite")
   else:
    FFj9Oj(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFj9Oj(self, "Could not read current channel info. !", title=title)
 def VVN5XU(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFFe8v(self, boundFunction(self.VVCDEH, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVFExa(self, mode):
  pass
 def VVpedy(self):
  pass
 def VVyzTO(self):
  pass
 def VVhW8v(self):
  pass
 def VVoSMw(self):
  lines = FFGZr4("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFi0Lh(self, boundFunction(self.VV55DF, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVEE7G=True)
  else:
   FFhXFJ(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VV55DF(self, fList):
  os.system(FFhmFU("find -L '%s' -type l -delete" % self.pPath))
  FFhXFJ(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVaGsm(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVtxlg()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FF39Hq("PIcon Directory:\n", VV3hnc)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFQtYX(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFQtYX(path)
   txt += FF39Hq("PIcon File:\n", VV3hnc)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FFGZr4(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FF39Hq("Found %d SymLink%s to this file from:\n" % (tot, s), VV3hnc)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFCNiw(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FF39Hq(tChName, VVul8x)
     else  : tChName = ""
     txt += "  %s%s\n" % (FF39Hq(line, VVvBji), tChName)
    txt += "\n"
   if chName:
    txt += FF39Hq("Channel:\n", VV3hnc)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FF39Hq(chName, VVul8x)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FF39Hq("Remarks:\n", VV3hnc)
    txt += "  %s\n" % FF39Hq("Unused", VVepFH)
  else:
   txt = "No info found"
  CC3OlU.VVm2Ur(self, refCode, txt, "PIcon Info.", self.pPath + filName)
 def VVtxlg(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VVnxKJ[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFFdtD(sat)
  return fName, refCode, chName, sat, inDB
 def VVsImx(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiz95(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVnxKJ):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVMVCT(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVtxlg()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FF39Hq("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VV3hnc))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVtxlg()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FF39Hq(self.curChanName, VVESyM)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVUYgA(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VVnxKJ:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFedlY("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFcui4(self, txt, title=self.Title)
 def VVOlz3(self):
  if not self.isBusy:
   VVqVzN = []
   VVqVzN.append(("All"         , "all"   ))
   VVqVzN.append(VVPkfI)
   VVqVzN.append(("Used by Channels"      , "used"  ))
   VVqVzN.append(("Unused PIcons"      , "unused"  ))
   VVqVzN.append(VVPkfI)
   VVqVzN.append(("PIcons Files"       , "pFiles"  ))
   VVqVzN.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVqVzN.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVqVzN.append(VVPkfI)
   VVqVzN.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVqVzN.append(VVPkfI)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFzEOF(val)
      VVqVzN.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCZ6u9(self)
   filterObj.VV7mnf(VVqVzN, self.nsList, self.VVgzOE)
 def VVgzOE(self, item=None):
  if item is not None:
   self.VVkDvB(item)
 def VVkDvB(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVtegw   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVm3R7   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVJN4A  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVX5Eq  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVlsf2  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVLtnE  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVxzHO   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVA1qW   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVSZrG , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVLtnE:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFGZr4("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FF0fiU(self, "Not found", 1000)
     return
   elif mode == self.VVZzqx:
    return
   else:
    words, asPrefix = CCZ6u9.VVpQVr(words)
   if not words and mode in (self.VVA1qW, self.VVSZrG):
    FF0fiU(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFFe8v(self, boundFunction(self.VVCDEH, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVwPXj(self):
  FF0fiU(self, "Loading Channels ...")
  lameDbChans = CCxXMf.VVcYBO(self, CCxXMf.VVa4uq, VVb4xi=False, VVgbkb=False)
  files = []
  words = []
  if lameDbChans:
   curCh = self.curChanName.lower().replace(" hd", "").replace(" fm", "").replace("4k", "")
   for refCode in lameDbChans:
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = self.VVz0XY(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CC6Hdl.VVZlLx(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       words.append(f.replace(".png", ""))
  if words:
   FFFe8v(self, boundFunction(self.VVCDEH, mode=self.VVZzqx, words=words), title="Filtering ...", clearMsg=False)
  else:
   FF0fiU(self, "Not found", 1000)
 def VVCDEH(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVRmPz(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCxXMf.VVcYBO(self, CCxXMf.VVa4uq, VVb4xi=False, VVgbkb=False)
  iptvRefList = self.VV8O7e()
  tList = []
  for fName, fType in CC6Hdl.VVB9DD(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVtegw:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVm3R7  and chName         : isAdd = True
   elif mode == self.VVJN4A and not chName        : isAdd = True
   elif mode == self.VVX5Eq  and fType == 0        : isAdd = True
   elif mode == self.VVlsf2  and fType == 1        : isAdd = True
   elif mode == self.VVLtnE  and fName in words       : isAdd = True
   elif mode == self.VVZzqx and fName in words       : isAdd = True
   elif mode == self.VVxzHO  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVA1qW  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVSZrG:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVnxKJ   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FF0fiU(self)
  else:
   self.isBusy = False
   FF0fiU(self, "Not found", 1000)
   return
  self.VVnxKJ.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVsImx()
  self.totalPIcons = len(self.VVnxKJ)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVUXTo(True)
 def VVRmPz(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CC6Hdl.VVB9DD(self.pPath):
    if fName:
     return True
   if isFirstTime : FFj9Oj(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FF0fiU(self, "Not found", 1000)
  else:
   FFj9Oj(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VV8O7e(self):
  VVKfpb = {}
  files  = CC2RcG.VVHdyL(self)
  if files:
   for path in files:
    txt = FF7gKM(path)
    list = iFindall("#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVKfpb[refCode] = item[1]
  return VVKfpb
 def VVUXTo(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVusRQ = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVusRQ: self.curPage = VVusRQ
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VV52Qs()
  if self.curPage == VVusRQ:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVMVCT()
  filName, refCode, chName, sat, inDB = self.VVtxlg()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VV52Qs(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVnxKJ[ndx]
   fName = self.VVnxKJ[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FF39Hq(chName, VVul8x))
    else : lbl.setText("-")
   except:
    lbl.setText(FF39Hq(chName, VVMwfZ))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVz0XY(self, s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVl7Iz():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VV3vYD"   )
 @staticmethod
 def VVYCXL():
  VVqVzN = []
  VVqVzN.append(("Find SymLinks (to PIcon Directory)"   , "VVPj7u"   ))
  VVqVzN.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVqVzN.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVqVzN
 @staticmethod
 def VV3vYD(SELF):
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiz95(SELF)
  png, path = CC6Hdl.VVLXik(refCode)
  if path : CC6Hdl.VV763w(SELF, png, path)
  else : FFj9Oj(SELF, "No PIcon found for current channel in:\n\n%s" % CC6Hdl.VVH2R4())
 @staticmethod
 def VVPj7u(SELF):
  if VVESyM:
   sed1 = FFDI4H("->", VVESyM)
   sed2 = FFDI4H("picon", VVepFH)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVMwfZ, VV4Z4E)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFSs3o(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFvH88(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVlwob(SELF, isPIcon):
  sed1 = FFDI4H("->", VVMwfZ)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFDI4H("picon", VVepFH)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFSs3o(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFvH88(), grep, sed1, sed2))
 @staticmethod
 def VVB9DD(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVH2R4():
  path = CFG.PIconsPath.getValue()
  return FFRJ2W(path)
 @staticmethod
 def VVLXik(refCode, chName=None):
  if FFzufs(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFq3e7(refCode)
  allPath, fName, refCodeFile, pList = CC6Hdl.VVZlLx(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VV763w(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFDI4H("%s%s" % (dest, png), VVul8x))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFDI4H(errTxt, VVUDh4))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFpBIq(SELF, cmd)
 @staticmethod
 def VVZlLx(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CC6Hdl.VVH2R4()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFiZhB(chName)
    lst = iGlob(allPath + chName + ".png")
    if lst:
     pList += lst
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCB3HG():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVu32w  = None
  self.VVL965 = ""
  self.VVj4WF  = noService
  self.VVgeVq = 0
  self.VVMylM  = noService
  self.VV925p = 0
  self.VVIi6c  = "-"
  self.VVqmn1 = 0
  self.VVPOxY  = ""
  self.serviceName = ""
 def VVxWvY(self, service):
  if service:
   feinfo = service.frontendInfo()
   if feinfo:
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVu32w = frontEndStatus
     self.VVeWFL()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVeWFL(self):
  if self.VVu32w:
   val = self.VVu32w.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVL965 = "%3.02f dB" % (val / 100.0)
   else         : self.VVL965 = ""
   val = self.VVu32w.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVgeVq = int(val)
   self.VVj4WF  = "%d%%" % val
   val = self.VVu32w.get("tuner_signal_power" , 0) * 100 / 65536
   self.VV925p = int(val)
   self.VVMylM  = "%d%%" % val
   val = self.VVu32w.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVIi6c  = "%d" % val
   val = int(val * 100 / 500)
   self.VVqmn1 = min(500, val)
   val = self.VVu32w.get("tuner_locked", 0)
   if val == 1 : self.VVPOxY = "Locked"
   else  : self.VVPOxY = "Not locked"
 def VVUJeE(self)   : return self.VVL965
 def VVb6Dk(self)   : return self.VVj4WF
 def VV2rNa(self)  : return self.VVgeVq
 def VVxzF9(self)   : return self.VVMylM
 def VVLOdK(self)  : return self.VV925p
 def VVVWEz(self)   : return self.VVIi6c
 def VV7qgA(self)  : return self.VVqmn1
 def VVWoNR(self)   : return self.VVPOxY
 def VVxO3B(self) : return self.serviceName
class CCRdiH():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVqZYQ(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFhqUM(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVsmyr(self.ORPOS  , mod=1   )
      self.sat2  = self.VVsmyr(self.ORPOS  , mod=2   )
      self.freq  = self.VVsmyr(self.FREQ  , mod=3   )
      self.sr   = self.VVsmyr(self.SR   , mod=4   )
      self.inv  = self.VVsmyr(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVsmyr(self.POL  , self.D_POL )
      self.fec  = self.VVsmyr(self.FEC  , self.D_FEC )
      self.syst  = self.VVsmyr(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVsmyr("modulation" , self.D_MOD )
       self.rolof = self.VVsmyr("rolloff"  , self.D_ROLOF )
       self.pil = self.VVsmyr("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVsmyr("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVsmyr("pls_code"  )
       self.iStId = self.VVsmyr("is_id"   )
       self.t2PlId = self.VVsmyr("t2mi_plp_id" )
       self.t2PId = self.VVsmyr("t2mi_pid"  )
 def VVsmyr(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFzEOF(val)
  elif mod == 2   : return FF16jJ(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVKIIp(self, refCode):
  txt = ""
  self.VVqZYQ(refCode)
  if self.data:
   def VVp8k8(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVp8k8("System"   , self.syst)
    txt += VVp8k8("Satellite"  , self.sat2)
    txt += VVp8k8("Frequency"  , self.freq)
    txt += VVp8k8("Inversion"  , self.inv)
    txt += VVp8k8("Symbol Rate"  , self.sr)
    txt += VVp8k8("Polarization" , self.pol)
    txt += VVp8k8("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVp8k8("Modulation" , self.mod)
     txt += VVp8k8("Roll-Off" , self.rolof)
     txt += VVp8k8("Pilot"  , self.pil)
     txt += VVp8k8("Input Stream", self.iStId)
     txt += VVp8k8("T2MI PLP ID" , self.t2PlId)
     txt += VVp8k8("T2MI PID" , self.t2PId)
     txt += VVp8k8("PLS Mode" , self.plsMod)
     txt += VVp8k8("PLS Code" , self.plsCod)
   else:
    txt += VVp8k8("System"   , self.txMedia)
    txt += VVp8k8("Frequency"  , self.freq)
  return txt, self.namespace
 def VVctlB(self, refCode):
  txt = "Transpoder : ?"
  self.VVqZYQ(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VV3hnc + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVcat9(self, refCode):
  self.data = None
  servRef = eServiceReference(refCode)
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFhqUM(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVsmyr(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVsmyr(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVsmyr(self.SYST, self.D_SYS_S)
     freq = self.VVsmyr(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVsmyr(self.POL , self.D_POL)
      fec = self.VVsmyr(self.FEC , self.D_FEC)
      sr = self.VVsmyr(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVOYq2(self, refCode):
  self.data = None
  self.VVqZYQ(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCOrgc():
 def __init__(self, VV5uXC, path, VVBijC=None):
  self.VV5uXC  = VV5uXC
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVBijC  = VVBijC
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.insertMode   = 0
  response = os.system(FFhmFU("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VVckzR()
  else:
   FFj9Oj(self.VV5uXC, "Error while preparing edit!")
 def VVckzR(self):
  VVKfpb = self.VV8Yob()
  VVUaPo = None #("Delete Line" , self.deleteLine  , [])
  VV2BU1 = ("Save Changes" , self.VVWORe   , [])
  VVm7uJ  = ("Edit Line"  , self.VV909z    , [])
  VVFLU5 = ("Line Options" , self.VV4lvW   , [])
  VVD9v1 = (""    , self.VVUbey , [])
  VVUoVo = self.VVg2xq
  VVqMZT  = self.VVZ8ED
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVfxos  = (CENTER  , LEFT  )
  FFqaCW(self.VV5uXC, None, title=self.Title, header=header, VVnxKJ=VVKfpb, VVfxos=VVfxos, VVf6S2=widths, VVzQkv=24, VVUaPo=VVUaPo, VV2BU1=VV2BU1, VVm7uJ=VVm7uJ, VVFLU5=VVFLU5, VVUoVo=VVUoVo, VVqMZT=VVqMZT, VVD9v1=VVD9v1, VVSl9p=True
    , VVMhkn   = "#11001111"
    , VVLwBG   = "#11001111"
    , VVCMEX   = "#11001111"
    , VVwS8Y  = "#05333333"
    , VVihFS  = "#00222222"
    , VVVkZY  = "#11331133"
    )
 def VV4lvW(self, VVqAwN, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVqAwN.VVQ1BS()
  VVqVzN = []
  VVqVzN.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVqVzN.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVhu9O"  ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVT0Tr:
   VVqVzN.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(  ("Delete Line"         , "deleteLine"   ))
  FFbvqQ(self.VV5uXC, boundFunction(self.VVzrA9, VVqAwN, lineNum), VVqVzN=VVqVzN, title="Line Options")
 def VVzrA9(self, VVqAwN, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVDbsQ("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVqAwN)
   elif item == "VVhu9O"  : self.VVhu9O(VVqAwN, lineNum)
   elif item == "copyToClipboard"  : self.VVeidZ(VVqAwN, lineNum)
   elif item == "pasteFromClipboard" : self.VVNHeT(VVqAwN, lineNum)
   elif item == "deleteLine"   : self.VVDbsQ("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVqAwN)
 def VVZ8ED(self, VVqAwN):
  VVqAwN.VVjPkA()
 def VVUbey(self, VVqAwN, title, txt, colList):
  if   self.insertMode == 1: VVqAwN.VVu3gt()
  elif self.insertMode == 2: VVqAwN.VVmc1o()
  self.insertMode = 0
 def VVhu9O(self, VVqAwN, lineNum):
  if lineNum == VVqAwN.VVQ1BS():
   self.insertMode = 1
   self.VVDbsQ("echo '' >> '%s'" % self.tmpFile, VVqAwN)
  else:
   self.insertMode = 2
   self.VVDbsQ("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVqAwN)
 def VVeidZ(self, VVqAwN, lineNum):
  global VVT0Tr
  VVT0Tr = FFedlY("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVqAwN.VVbwVV("Copied to clipboard")
 def VVWORe(self, VVqAwN, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFhmFU("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFhmFU("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVqAwN.VVbwVV("Saved")
     self.fileChanged = False
     VVqAwN.VVjPkA()
    else:
     FFj9Oj(self.VV5uXC, "Cannot save file!")
   else:
    FFj9Oj(self.VV5uXC, "Cannot create backup copy of original file!")
 def VVg2xq(self, VVqAwN):
  if self.fileChanged:
   FFi0Lh(self.VV5uXC, boundFunction(self.VVEJBQ, VVqAwN), "Cancel changes ?")
  else:
   finalOK = os.system(FFhmFU("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVEJBQ(VVqAwN)
 def VVEJBQ(self, VVqAwN):
  VVqAwN.cancel()
  os.system(FFhmFU("rm -f '%s'" % self.tmpFile))
  if self.VVBijC:
   self.VVBijC()
 def VV909z(self, VVqAwN, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VV4Z4E + "ORIGINAL TEXT:\n" + VVvBji + lineTxt
  FFxR0u(self.VV5uXC, boundFunction(self.VVnZ0v, lineNum, VVqAwN), title="File Line", defaultText=lineTxt, message=message)
 def VVnZ0v(self, lineNum, VVqAwN, VVNYr8):
  if not VVNYr8 is None:
   if VVqAwN.VVQ1BS() <= 1:
    self.VVDbsQ("echo %s > '%s'" % (VVNYr8, self.tmpFile), VVqAwN)
   else:
    self.VV4yMu(VVqAwN, lineNum, VVNYr8)
 def VVNHeT(self, VVqAwN, lineNum):
  if lineNum == VVqAwN.VVQ1BS() and VVqAwN.VVQ1BS() == 1:
   self.VVDbsQ("echo %s >> '%s'" % (VVT0Tr, self.tmpFile), VVqAwN)
  else:
   self.VV4yMu(VVqAwN, lineNum, VVT0Tr)
 def VV4yMu(self, VVqAwN, lineNum, newTxt):
  VVqAwN.VVPO8w("Saving ...")
  lines = FF709T(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVqAwN.VVysWb()
  VVKfpb = self.VV8Yob()
  VVqAwN.VV6duD(VVKfpb)
 def VVDbsQ(self, cmd, VVqAwN):
  tCons = CCsZDe()
  tCons.ePopen(cmd, boundFunction(self.VVtIQq, VVqAwN))
  self.fileChanged = True
  VVqAwN.VVysWb()
 def VVtIQq(self, VVqAwN, result, retval):
  VVKfpb = self.VV8Yob()
  VVqAwN.VV6duD(VVKfpb)
 def VV8Yob(self):
  if fileExists(self.tmpFile):
   lines = FF709T(self.tmpFile)
   VVKfpb = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVKfpb.append((str(ndx), line.strip()))
   if not VVKfpb:
    VVKfpb.append((str(1), ""))
   return VVKfpb
  else:
   FFQJvo(self.VV5uXC, self.tmpFile)
class CCZ6u9():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVqVzN   = []
  self.satList   = []
 def VVK5ua(self, VVBijC):
  self.VVqVzN = []
  VVqVzN, VVOEPE = self.VVuyqJ(False, True)
  if VVqVzN:
   self.VVqVzN += VVqVzN
   self.VVMIgO(VVBijC, VVOEPE)
 def VVP6E6(self, mode, VVqAwN, satCol, VVBijC):
  VVqAwN.VVPO8w("Loading Filters ...")
  self.VVqVzN = []
  self.VVqVzN.append(("All Services" , "all"))
  if mode == 1:
   self.VVqVzN.append(VVPkfI)
   self.VVqVzN.append(("Parental Control", "parentalControl"))
   self.VVqVzN.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVqVzN.append(VVPkfI)
   self.VVqVzN.append(("Selected Transponder"   , "selectedTP" ))
   self.VVqVzN.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVOdpg(VVqAwN, satCol)
  VVqVzN, VVOEPE = self.VVuyqJ(True, False)
  if VVqVzN:
   VVqVzN.insert(0, VVPkfI)
   self.VVqVzN += VVqVzN
  VVqAwN.VVXuQa()
  self.VVMIgO(VVBijC, VVOEPE)
 def VV7mnf(self, VVqVzN, sats, VVBijC):
  self.VVqVzN = VVqVzN
  VVqVzN, VVOEPE = self.VVuyqJ(True, False)
  if VVqVzN:
   self.VVqVzN.append(VVPkfI)
   self.VVqVzN += VVqVzN
  self.VVMIgO(VVBijC, VVOEPE)
 def VVYKnC(self, VVqVzN, sats, VVBijC):
  self.VVqVzN = VVqVzN
  VVqVzN, VVOEPE = self.VVuyqJ(True, False)
  if VVqVzN:
   self.VVqVzN.append(VVPkfI)
   self.VVqVzN += VVqVzN
  self.VVMIgO(VVBijC, VVOEPE)
 def VVMIgO(self, VVBijC, VVOEPE):
  VVTaNU = ("Edit Filter", boundFunction(self.VVTG1n, VVOEPE))
  VVmews  = ("Filter Help", boundFunction(self.VV7zyJ, VVOEPE))
  FFbvqQ(self.callingSELF, boundFunction(self.VVOIXC, VVBijC), VVqVzN=self.VVqVzN, title="Select Filter", VVTaNU=VVTaNU, VVmews=VVmews)
 def VVOIXC(self, VVBijC, item):
  if item:
   VVBijC(item)
 def VVTG1n(self, VVOEPE, VVw5fsObj, sel):
  if fileExists(VVOEPE) : CCOrgc(self.callingSELF, VVOEPE, VVBijC=None)
  else       : FFQJvo(self.callingSELF, VVOEPE)
  VVw5fsObj.cancel()
 def VV7zyJ(self, VVOEPE, VVw5fsObj, sel):
  FF0K3L(self.callingSELF, VVLdJi + "_help_service_filter", "Service Filter")
 def VVOdpg(self, VVqAwN, satColNum):
  if not self.satList:
   satList = VVqAwN.VV2uMm(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFFdtD(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VVPkfI)
  if self.VVqVzN:
   self.VVqVzN += self.satList
 def VVuyqJ(self, addTag, showErr):
  FFDH09()
  fileName  = "ajpanel_services_filter"
  VVOEPE = VVjHyF + fileName
  VVqVzN  = []
  if not fileExists(VVOEPE):
   os.system(FFhmFU("cp -f '%s' '%s'" % (VVLdJi + fileName, VVOEPE)))
  fileFound = False
  if fileExists(VVOEPE):
   fileFound = True
   lines = FF709T(VVOEPE)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVqVzN.append((line, "__w__" + line))
       else  : VVqVzN.append((line, line))
  if showErr:
   if   not fileFound : FFQJvo(self.callingSELF , VVOEPE)
   elif not VVqVzN : FFYN1B(self.callingSELF , VVOEPE)
  return VVqVzN, VVOEPE
 @staticmethod
 def VVpQVr(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CC6pTH():
 def __init__(self, callingSELF, VVqAwN, refCodeColNum):
  self.callingSELF = callingSELF
  self.VVqAwN = VVqAwN
  self.refCodeColNum = refCodeColNum
  self.VVqVzN = []
  iMulSel = self.VVqAwN.VV1Xgr()
  if iMulSel : self.VVqVzN.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVqVzN.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVqAwN.VVav9t()
  self.VVqVzN.append(    ("Select all"    , "selectAll"  ))
  if tot > 0:
   self.VVqVzN.append(   ("Unselect all"    , "unselectAll"  ))
  self.VVqVzN.append(VVPkfI)
 def VVsOQx(self, servName, refCode):
  tot = self.VVqAwN.VVav9t()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVqVzN.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVVqan_multi" ))
  else    : self.VVqVzN.append( ("Add to Bouquet : %s"      % servName , "VVVqan_one" ))
  self.VVkkrv(servName, refCode)
 def VVEOWs(self, servName, refCode, pcState, hidState):
  self.VVqVzN = []
  if pcState == "No" : self.VVqVzN.append(("Add to Parental Control"  , "parentalControl_add"  ))
  else    : self.VVqVzN.append(("Remove from Parental Control" , "parentalControl_remove" ))
  if hidState == "No" : self.VVqVzN.append(("Add to Hidden Services"  , "hiddenServices_add"  ))
  else    : self.VVqVzN.append(("Remove from Hidden Services" , "hiddenServices_remove" ))
  self.VVkkrv(servName, refCode)
 def VVkkrv(self, servName, refCode):
  FFbvqQ(self.callingSELF, boundFunction(self.VVuC2h, servName, refCode), title="Options", VVqVzN=self.VVqVzN)
 def VVuC2h(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"    : self.VVqAwN.VVDQD4(True)
   elif item == "MultSelDisab"    : self.VVqAwN.VVDQD4(False)
   elif item == "selectAll"    : self.VVqAwN.VVYaa4()
   elif item == "unselectAll"    : self.VVqAwN.VVOUvZ()
   elif item == "parentalControl_add"  : self.callingSELF.VVO5uK(self.VVqAwN, refCode, True)
   elif item == "parentalControl_remove" : self.callingSELF.VVO5uK(self.VVqAwN, refCode, False)
   elif item == "hiddenServices_add"  : self.callingSELF.VVMpOT(self.VVqAwN, refCode, True)
   elif item == "hiddenServices_remove" : self.callingSELF.VVMpOT(self.VVqAwN, refCode, False)
   elif item == "VVVqan_multi" : self.VVVqan(refCode, True)
   elif item == "VVVqan_one" : self.VVVqan(refCode, False)
 def VVVqan(self, refCode, isMulti):
  bouquets = FF0ci0()
  if bouquets:
   VVqVzN = []
   for item in bouquets:
    VVqVzN.append((item[0], item[1].toString()))
   VVTaNU = ("Create New", boundFunction(self.VViCQq, refCode, isMulti))
   FFbvqQ(self.callingSELF, boundFunction(self.VVb0Xj, refCode, isMulti), VVqVzN=VVqVzN, title="Add to Bouquet", VVTaNU=VVTaNU, VV1G3P=True, VVDIyw=True)
  else:
   FFi0Lh(self.callingSELF, boundFunction(self.VVt6Xp, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVb0Xj(self, refCode, isMulti, bName=None):
  if bName:
   FFFe8v(self.VVqAwN, boundFunction(self.VV7Fft, refCode, isMulti, bName), title="Adding Channels ...")
 def VV7Fft(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVmswW(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVW3zD = InfoBar.instance
    if VVW3zD:
     VVGkgl = VVW3zD.servicelist
     if VVGkgl:
      mutableList = VVGkgl.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVqAwN.VVXuQa()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFhXFJ(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFj9Oj(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVmswW(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVqAwN.VVHjRM(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VViCQq(self, refCode, isMulti, VVw5fsObj, path):
  self.VVt6Xp(refCode, isMulti)
 def VVt6Xp(self, refCode, isMulti):
  FFxR0u(self.callingSELF, boundFunction(self.VV3uMd, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VV3uMd(self, refCode, isMulti, name):
  if name:
   FFFe8v(self.VVqAwN, boundFunction(self.VVQHcE, refCode, isMulti, name), title="Adding Channels ...")
 def VVQHcE(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVmswW(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVW3zD = InfoBar.instance
    if VVW3zD:
     VVGkgl = VVW3zD.servicelist
     if VVGkgl:
      try:
       VVGkgl.addBouquet(name, services)
       allOK = True
      except:
       try:
        VVGkgl.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVqAwN.VVXuQa()
   title = "Add to Bouquet"
   if allOK: FFhXFJ(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFj9Oj(self.callingSELF, "Nothing added!", title=title)
class CCpRMz(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFm81W(VVFFPS, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFEPCp(self)
  FFIj9t(self["keyRed"]  , "Exit")
  FFIj9t(self["keyGreen"]  , "Save")
  FFIj9t(self["keyYellow"] , "Refresh")
  FFIj9t(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVGvWt  ,
   "green"   : self.VVL26y ,
   "yellow"  : self.VV28h3  ,
   "blue"   : self.VVsZqJ   ,
   "up"   : self.VVtCHb    ,
   "down"   : self.VVBVsz   ,
   "left"   : self.VV29Kt   ,
   "right"   : self.VVms4U   ,
   "cancel"  : self.VVGvWt
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VV28h3()
  self.VVt0ko()
  FFbkgB(self)
 def VVGvWt(self) : self.close(True)
 def VVBu12(self) : self.close(False)
 def VVsZqJ(self):
  self.session.openWithCallback(self.VVx4yP, boundFunction(CCPRpt))
 def VVx4yP(self, closeAll):
  if closeAll:
   self.close()
 def VVtCHb(self):
  self.VVJNdF(1)
 def VVBVsz(self):
  self.VVJNdF(-1)
 def VV29Kt(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVt0ko()
 def VVms4U(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVt0ko()
 def VVJNdF(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVJxYF(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVJxYF(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVJxYF(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVqYvy(year)):
   days += 1 #29 days in a leap year February
  return days
 def VVqYvy(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVt0ko(self):
  for obj in self.list:
   FFUPS3(obj, "#11404040")
  FFUPS3(self.list[self.index], "#11ff8000")
 def VV28h3(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVL26y(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCsZDe()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVGnkB)
 def VVGnkB(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFhXFJ(self, "Nothing returned from the system!")
  else:
   FFhXFJ(self, str(result))
class CCPRpt(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFm81W(VVlOWi, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFEPCp(self, addLabel=True)
  FFIj9t(self["keyRed"]  , "Exit")
  FFIj9t(self["keyGreen"]  , "Sync")
  FFIj9t(self["keyYellow"] , "Refresh")
  FFIj9t(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVGvWt   ,
   "green"   : self.VVwxyc  ,
   "yellow"  : self.VVzRRo ,
   "blue"   : self.VVGgDY  ,
   "cancel"  : self.VVGvWt
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVFr2p()
  self.onShow.append(self.start)
 def start(self):
  FF4YxS(self.refresh)
  FFbkgB(self)
 def refresh(self):
  self.VVUn55()
  self.VVg9yn(False)
 def VVGvWt(self)  : self.close(True)
 def VVGgDY(self) : self.close(False)
 def VVFr2p(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVUn55(self):
  self.VVTSKW()
  self.VV7Ov7()
  self.VVBDZS()
  self.VVoV3W()
 def VVzRRo(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVFr2p()
   self.VVUn55()
   FF4YxS(self.refresh)
 def VVwxyc(self):
  if len(self["keyGreen"].getText()) > 0:
   FFi0Lh(self, self.VVln4D, "Synchronize with Internet Date/Time ?")
 def VVln4D(self):
  self.VVUn55()
  FF4YxS(boundFunction(self.VVg9yn, True))
 def VVTSKW(self)  : self["keyRed"].show()
 def VVNWJW(self)  : self["keyGreen"].show()
 def VVjBSh(self) : self["keyYellow"].show()
 def VVDudA(self)  : self["keyBlue"].show()
 def VV7Ov7(self)  : self["keyGreen"].hide()
 def VVBDZS(self) : self["keyYellow"].hide()
 def VVoV3W(self)  : self["keyBlue"].hide()
 def VVg9yn(self, sync):
  localTime = FFW5Nh()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVZSKJ(server)
   if epoch_time is not None:
    ntpTime = FFXglk(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCsZDe()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVGnkB, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVjBSh()
  self.VVDudA()
  if ok:
   self.VVNWJW()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVGnkB(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVg9yn(False)
  except:
   pass
 def VVZSKJ(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FF0KEj():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCRI0y(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFm81W(VVN88w, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FFEPCp(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  FF4YxS(self.VVhwyA)
 def VVhwyA(self):
  if FF0KEj(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFUPS3(self["myBody"], color)
   FFUPS3(self["myLabel"], color)
  except:
   pass
class CCuGxf(Screen):
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FF1qMk()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFm81W(VVfOhm, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCIBmT(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCIBmT(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCIBmT(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"] = Label()
  self.timer   = eTimer()
  self.tunerInfo  = CCB3HG()
  self.top   = 0
  self.left   = 0
  self.curPosNum  = CFG.signalPos.getValue()
  self.curSize  = CFG.signalSize.getValue()
  FFEPCp(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVtCHb          ,
   "down"  : self.VVBVsz         ,
   "left"  : self.VV29Kt         ,
   "right"  : self.VVms4U         ,
   "info"  : self.VVax4F        ,
   "epg"  : self.VVax4F        ,
   "menu"  : self.VVyhnh         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "last"  : boundFunction(self.VVvaCI, -1)  ,
   "next"  : boundFunction(self.VVvaCI, 1)  ,
   "0"   : boundFunction(self.VVvaCI, 0)  ,
   "1"   : boundFunction(self.VVU5yF, pos=1) ,
   "2"   : boundFunction(self.VVU5yF, pos=2) ,
   "3"   : boundFunction(self.VVU5yF, pos=3) ,
   "4"   : boundFunction(self.VVU5yF, pos=4) ,
   "5"   : boundFunction(self.VVU5yF, pos=5) ,
   "6"   : boundFunction(self.VVU5yF, pos=6) ,
   "7"   : boundFunction(self.VVU5yF, pos=7) ,
   "8"   : boundFunction(self.VVU5yF, pos=8) ,
   "9"   : boundFunction(self.VVU5yF, pos=9) ,
  }, -1)
  self.onShown.append(self.VVOs7w)
  self.onClose.append(self.onExit)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  self.sliderSNR.VVO3EB()
  self.sliderAGC.VVO3EB()
  self.sliderBER.VVO3EB(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVU5yF()
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiz95(self)
  tp  = CCRdiH()
  self["myTPInfo"].setText(tp.VVctlB(refCode))
  del tp
  if state and not state == "Tuned":
   FF0fiU(self, state.replace(" (", "\n("), 1500)
  self.VVaquj()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVaquj)
  except:
   self.timer.callback.append(self.VVaquj)
  self.timer.start(500, False)
 def VVaquj(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVxWvY(service)
  self["mySNRdB"].setText(self.tunerInfo.VVUJeE())
  self["mySNR"].setText(self.tunerInfo.VVb6Dk())
  self["myAGC"].setText(self.tunerInfo.VVxzF9())
  self["myBER"].setText(self.tunerInfo.VVVWEz())
  self.sliderSNR.VVQyIm(self.tunerInfo.VV2rNa())
  self.sliderAGC.VVQyIm(self.tunerInfo.VVLOdK())
  self.sliderBER.VVQyIm(self.tunerInfo.VV7qgA())
  serviceName = self.tunerInfo.VVxO3B()
  if not serviceName    : serviceName = "Signal"
  if len(serviceName) > 25  : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
 def VVax4F(self):
  self.session.open(CC3OlU)
 def VVyhnh(self):
  FF0K3L(self, VVLdJi + "_help_signal", "Signal Monitor (Keys)")
 def VVtCHb(self)  : self.VVU5yF(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVBVsz(self) : self.VVU5yF(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VV29Kt(self) : self.VVU5yF(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVms4U(self) : self.VVU5yF(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVU5yF(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVvaCI(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFztHE(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
class CCIBmT(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVO3EB(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFUPS3(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVLdJi +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFUPS3(self.covObj, self.covColor)
   else:
    FFUPS3(self.covObj, "#00006688")
    self.isColormode = True
  self.VVQyIm(0)
 def VVQyIm(self, val):
  val  = FFztHE(val, self.minN, self.maxN)
  width = int(FFbs3Q(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFztHE(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCRyHO(Screen):
 def __init__(self, session, iptvTableInstance, VVqAwN, piconMode=CC2RcG.VVDoHM):
  self.skin, self.skinParam = FFm81W(VVFqyT, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30)
  self.session    = session
  self.iptvTableInstance  = iptvTableInstance
  self.VVqAwN   = VVqAwN
  self.piconMode    = piconMode
  self.isCancelled   = False
  self.curValue    = 0
  self.maxValue    = VVqAwN.VV5pBz()
  self.barWidth    = 0
  self.barHeight    = 0
  self.totRows    = 0
  self.totNoUrl    = 0
  self.totExists    = 0
  self.totDownload_attempt = 0
  self.totDownload_success = 0
  self.totDownload_failed  = 0
  self.totIncorrect_size  = 0
  self.pPath     = CC6Hdl.VVH2R4()
  self.ResultTxt    = ""
  self.VVCMEX    = None
  self.timer     = eTimer()
  self.myThread    = None
  FFEPCp(self, title="Downloading PIcons ...")
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVOs7w)
  self.onClose.append(self.onExit)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  if not pathExists(self.pPath):
   FFj9Oj(self, "PIcons path not found.\n\n%s" % self.pPath)
   self.close()
  FFUPS3(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVPKid()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVPKid)
  except:
   self.timer.callback.append(self.VVPKid)
  self.timer.start(300, False)
  from threading import Thread as Thread
  self.myThread = Thread(name="download_PIcons", target=self.VVLkGo)
  self.myThread.start()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  FF0fiU(self, "Cancelling ...")
  self.isCancelled = True
 def VVPKid(self):
  val  = self.totRows
  val  = FFztHE(self.totRows, 0, self.maxValue)
  width = int(FFbs3Q(val, 0, self.maxValue, 0, self.barWidth))
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
  self["myTitle"].setText("  Downloading PIcons ( %d of %d) ..." % (val, self.maxValue))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   FFcui4(self, self.ResultTxt, title="PIcons Download Result", VVCMEX=self.VVCMEX)
   self.close()
 def VVLkGo(self):
  err = ""
  for row in self.VVqAwN.VV9ASy():
   if self.isCancelled:
    break
   self.totRows += 1
   chName, chUrl, picUrl, refCode = self.iptvTableInstance.VV24Ey(self.piconMode, row)
   if picUrl:
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    if not fileExists(self.pPath + picon):
     self.totDownload_attempt += 1
     path, err = FFarie(picUrl, picon, timeout=1)
     if path:
      self.totDownload_success += 1
      if FFHO0G(path) > 0:
       cmd = ""
       if not self.piconMode == CC2RcG.VVDoHM:
        cmd += "ffmpeg -y -i %s -vf scale=-1:132 %s > /dev/null 2>&1;" % (path, path)
       cmd += FFhmFU("mv -f '%s' '%s'" % (path, self.pPath)) + ";"
       os.system(cmd)
      else:
       self.totIncorrect_size += 1
       os.system(FFhmFU("rm -f '%s'" % path))
     elif err:
      self.totDownload_failed += 1
      err = err.lower()
      if "time-out" in err or "unauthorized" in err:
       break
    else:
     self.totExists += 1
   else:
    self.totNoUrl += 1
  txt  = ""
  if err:
   txt += err + "\n\n"
   self.VVCMEX = "#22200000"
  txt += "Total Processed\t\t: %d of %d\n" % (self.totRows, self.maxValue)
  txt += "Download Success\t: %d of %s\n"  % (self.totDownload_success, self.totDownload_attempt)
  txt += "Skipped (PIcon exist)\t: %d\n"  % self.totExists
  txt += "Skipped (Size = 0)\t: %d\n"   % self.totIncorrect_size
  txt += "Incorrect PIcon URL\t: %d\n"  % self.totNoUrl
  txt += "PIcons Path\t\t: %s\n"    % self.pPath
  self.ResultTxt = txt
class CCsZDe(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVBijC = {}
  self.commandRunning = False
  self.VV9ot9  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVBijC, dataAvailFnc=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVBijC[name] = VVBijC
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VV9ot9:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVZ65o, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VVnzV8 , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVZ65o, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VVnzV8 , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVnzV8(name, retval)
  return True
 def VVZ65o(self, name, data):
  data = data.decode('UTF-8')
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVnzV8(self, name, retval):
  if not self.VV9ot9:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVBijC[name]:
   self.VVBijC[name](self.appResults[name], retval)
  del self.VVBijC[name]
 def VVuTg8(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCwtHp(Screen):
 def __init__(self, session, title="", VV4umH=None, VVbEEx=False, VVj2aH=False, VVX7yx=False, VVbXZi=False, VVYwzK=False, VVjizR=False, VVNp8T=VVfHMe, VVoAx2=None, VV5uHZ=False, VV2Ujo=None, VVl4G8="", checkNetAccess=False):
  self.skin, self.skinParam = FFm81W(VVQGZG, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FFEPCp(self, addScrollLabel=True)
  if not VVl4G8:
   VVl4G8 = "Processing ..."
  self["myLabel"].setText("   %s" % VVl4G8)
  self.VVbEEx   = VVbEEx
  self.VVj2aH   = VVj2aH
  self.VVX7yx   = VVX7yx
  self.VVbXZi  = VVbXZi
  self.VVYwzK = VVYwzK
  self.VVjizR = VVjizR
  self.VVNp8T   = VVNp8T
  self.VVoAx2 = VVoAx2
  self.VV5uHZ  = VV5uHZ
  self.VV2Ujo  = VV2Ujo
  self.checkNetAccess  = checkNetAccess
  self.cmdNum    = 0
  self.container   = CCsZDe()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFfHwI()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VV4umH, str):
   self.VV4umH = [VV4umH]
  else:
   self.VV4umH = VV4umH
  if self.VVX7yx or self.VVbXZi:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVfebv, VVfebv)
   self.VV4umH.append("echo -e '\n%s\n' %s" % (restartNote, FFDI4H(restartNote, VVESyM)))
   if self.VVX7yx:
    self.VV4umH.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VV4umH.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVYwzK:
   FF0fiU(self, "Processing ...")
  self.onLayoutFinish.append(self.VVqgGL)
  self.onClose.append(self.VVyBKd)
 def VVqgGL(self):
  self["myLabel"].VVOdAK()
  if self.VVbEEx:
   self["myLabel"].VVUAyE()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VV0awG()
  else:
   self.VVAHZg()
 def VV0awG(self):
  if FF0KEj():
   self["myLabel"].setText("Processing ...")
   self.VVAHZg()
  else:
   self["myLabel"].setText(FF39Hq("\n   No connection to internet!", VVepFH))
 def VVAHZg(self):
  allOK = self.container.ePopen(self.VV4umH[0], self.VVZYVb, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVZYVb("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVjizR or self.VVX7yx or self.VVbXZi:
    self["myLabel"].setText(FFAAb7("STARTED", VVESyM) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VV2Ujo:
   colorWhite = CCndzU.VVMaPH(VV4Z4E)
   color  = CCndzU.VVMaPH(self.VV2Ujo[0])
   words  = self.VV2Ujo[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVNp8T=self.VVNp8T)
 def VVZYVb(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VV4umH):
   allOK = self.container.ePopen(self.VV4umH[self.cmdNum], self.VVZYVb, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVZYVb("Cannot connect to Console!", -1)
  else:
   if self.VVYwzK and FFjMv5(self):
    FF0fiU(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVjizR:
    self["myLabel"].appendText("\n" + FFAAb7("FINISHED", VVESyM), self.VVNp8T)
   if self.VVbEEx or self.VVj2aH:
    self["myLabel"].VVUAyE()
   if self.VVoAx2 is not None:
    self.VVoAx2()
   if not retval and self.VV5uHZ:
    self.VVyBKd()
 def VVyBKd(self):
  if self.container.VVuTg8():
   self.container.killAll()
class CCAYul(Screen):
 def __init__(self, session, VV4umH=None, VVYwzK=False):
  self.skin, self.skinParam = FFm81W(VVQGZG, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVjHyF + "ajpanel_terminal.history"
  self.customCommandsFile = VVjHyF + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFedlY("pwd") or "/home/root"
  self.container   = CCsZDe()
  FFEPCp(self, addScrollLabel=True)
  FFIj9t(self["keyRed"] , "Stop Command")
  FFIj9t(self["keyGreen"] , "OK = History")
  FFIj9t(self["keyYellow"], "Menu = Custom Cmds")
  FFIj9t(self["keyBlue"] , "Keypad = New Cmd")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVSDzN ,
   "red"  : self.VVQxw2   ,
   "cancel" : self.VVkcbO   ,
   "menu"  : self.VVbFe3 ,
   "last"  : self.VVLE15  ,
   "next"  : self.VVLE15  ,
   "1"   : self.VVLE15  ,
   "2"   : self.VVLE15  ,
   "3"   : self.VVLE15  ,
   "4"   : self.VVLE15  ,
   "5"   : self.VVLE15  ,
   "6"   : self.VVLE15  ,
   "7"   : self.VVLE15  ,
   "8"   : self.VVLE15  ,
   "9"   : self.VVLE15  ,
   "0"   : self.VVLE15
  })
  self.onLayoutFinish.append(self.VVOs7w)
  self.onClose.append(self.VVQxw2)
 def VVOs7w(self):
  self["myLabel"].VVOdAK(isResizable=False)
  FFUPS3(self["keyGreen"]  , self.skinParam["titleColor"])
  FFUPS3(self["keyYellow"] , self.skinParam["titleColor"])
  FFUPS3(self["keyBlue"] , self.skinParam["titleColor"])
  self.VViHVw(FFedlY("date"), 5)
  result = FFedlY("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVfitl()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVLdJi + "LinuxCommands.lst"
   newTemplate = VVLdJi + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFhmFU("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFhmFU("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VVQxw2(self):
  if self.container.VVuTg8():
   self.container.killAll()
   self.VViHVw("Process killed\n", 4)
   self.VVfitl()
 def VVkcbO(self):
  if self.container.VVuTg8():
   FFi0Lh(self, self.close, "Terminate command and exit ?")
  else:
   self.close()
 def VVfitl(self):
  self.VViHVw(self.prompt, 1)
  self["keyRed"].hide()
 def VViHVw(self, txt, mode):
  if   mode == 1 : color = VVESyM
  elif mode == 2 : color = VV3hnc
  elif mode == 3 : color = VV4Z4E
  elif mode == 4 : color = VVepFH
  elif mode == 5 : color = VVvBji
  elif mode == 6 : color = VVdsiT
  else   : color = VV4Z4E
  try:
   self["myLabel"].appendText(FF39Hq(txt, color))
  except:
   pass
 def VVmC8K(self, cmd):
  self["keyRed"].show()
  cmd = cmd.strip()
  if "#" in cmd:
   parts = cmd.split("#")
   left  = FF39Hq(parts[0].strip(), VV3hnc)
   right = FF39Hq("#" + parts[1].strip(), VVdsiT)
   txt = "%s    %s\n" % (left, right)
  else:
   txt = "%s\n" % cmd
  self.VViHVw(txt, 2)
  lastLine = self.VVF279()
  if not lastLine or not cmd == lastLine:
   self.lastCommand = cmd
   self.VVkLzo(cmd)
  cdList = iFindall(r'(cd\s+[\/?\w\.+\~]+|cd\s?)', cmd)
  if cdList:
   self.curDir = cdList[-1]
  finalCmd = FFhmFU(self.curDir) + ";" + cmd
  allOK = self.container.ePopen(finalCmd, self.VVZYVb, dataAvailFnc=self.dataAvail)
  if not allOK:
   FFj9Oj(self, "Cannot connect to Console!")
  self.lastCommand = cmd
 def dataAvail(self, data):
  self.VViHVw(data, 3)
 def VVZYVb(self, data, retval):
  if not retval == 0:
   self.VViHVw("Exit Code : %d\n" % retval, 4)
  self.VVfitl()
 def VVSDzN(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVF279() == "":
   self.VVkLzo("cd /tmp")
   self.VVkLzo("ls")
  VVKfpb = []
  if fileExists(self.commandHistoryFile):
   lines  = FF709T(self.commandHistoryFile)
   c = 0
   for line in reversed(lines):
    line = line.strip()
    if line and not line.startswith("#"):
     c += 1
     VVKfpb.append((str(c), line))
   self.VVhIcT(VVKfpb, title, self.commandHistoryFile, isHistory=True)
  else:
   FFQJvo(self, self.commandHistoryFile, title=title)
 def VVF279(self):
  lastLine = FFedlY("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVkLzo(self, cmd):
  os.system("echo '%s' >> %s" % (cmd, self.commandHistoryFile))
 def VVbFe3(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FF709T(self.customCommandsFile)
   lastLineIsSep = False
   VVKfpb = []
   c = 0
   for line in lines:
    line = line.strip()
    if line:
     c += 1
     if line.startswith(("#", "@")):
      line = FF39Hq(line, VVMwfZ)
     VVKfpb.append((str(c), line))
   self.VVhIcT(VVKfpb, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFQJvo(self, self.customCommandsFile, title=title)
 def VVhIcT(self, VVKfpb, title, filePath=None, isHistory=False):
  if VVKfpb:
   VVwS8Y = "#05333333"
   if isHistory: VVMhkn = VVLwBG = VVCMEX = "#11000020"
   else  : VVMhkn = VVLwBG = VVCMEX = "#06002020"
   VVm7uJ     = ("Send"   , self.VVdxZ5  , [])
   VV2CKM    = ("Modify & Send" , self.VVUT2W  , [])
   if filePath : VVFLU5 = ("Edit File"  , self.VV3vu3 , [filePath])
   else  : VVFLU5 = None
   header      = ("No."  , "Commands")
   widths      = (7   , 93   )
   VVfxos     = (CENTER  , LEFT   )
   FFqaCW(self, None, title=title, header=header, VVnxKJ=VVKfpb, VVfxos=VVfxos, VVf6S2=widths, VVzQkv=22, VVm7uJ=VVm7uJ, VV2CKM=VV2CKM, VVFLU5=VVFLU5, VVSl9p=True
     , VVMhkn   = VVMhkn
     , VVLwBG   = VVLwBG
     , VVCMEX   = VVCMEX
     , VVwS8Y  = VVwS8Y
    )
  else:
   FFYN1B(self, filePath, title=title)
 def VVdxZ5(self, VVqAwN, title, txt, colList):
  cmd = FFiZhB(colList[1])
  VVqAwN.cancel()
  if cmd.startswith(("#", "@")):
   self.VViHVw("\n%s\n" % cmd, 6)
   self.VViHVw(self.prompt, 1)
  else:
   self.VVmC8K(cmd)
 def VVUT2W(self, VVqAwN, title, txt, colList):
  cmd = colList[1]
  self.VVCkWm(VVqAwN, cmd)
 def VV3vu3(self, VVqAwN, filePath):
  if fileExists(filePath):
   CCOrgc(self, filePath, VVBijC=boundFunction(self.VVe2Cf))
   VVqAwN.cancel()
  else:
   FFQJvo(self, filePath)
 def VVe2Cf(self):
  FF4YxS(self.VVbFe3)
 def VVLE15(self):
  self.VVCkWm(None, self.lastCommand)
 def VVCkWm(self, VVqAwN, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFxR0u(self, boundFunction(self.VVEUxK, VVqAwN), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVEUxK(self, VVqAwN, cmd):
  if cmd and len(cmd) > 0:
   self.VVmC8K(cmd)
   if VVqAwN:
    VVqAwN.cancel()
class CCwpdR(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVNYr8="", VVu2KL=False, VVnBGk=False, isTrimEnds=True):
  self.skin, self.skinParam = FFm81W(VVeaqQ, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FFEPCp(self, title, addLabel=True)
  FFIj9t(self["keyRed"] , "Up/Down = Change")
  FFIj9t(self["keyGreen"] , "Overwrite")
  FFIj9t(self["keyYellow"], "Pick Key Map")
  FFIj9t(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVnBGk   = VVnBGk
  self.VVu2KL  = VVu2KL
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVNYr8, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVzzQL      ,
   "green"    : self.VVHXWP    ,
   "yellow"   : self.VV4As8      ,
   "blue"    : self.VVkROf     ,
   "menu"    : self.VVmIM9     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVCddN, True) ,
   "down"    : boundFunction(self.VVCddN, False) ,
   "left"    : self.VVEAW3       ,
   "right"    : self.VV4FpW       ,
   "home"    : self.VVeIvJ       ,
   "end"    : self.VVHQtv       ,
   "next"    : self.VVOWCy      ,
   "last"    : self.VVncQe      ,
   "deleteForward"  : self.VVOWCy      ,
   "deleteBackward" : self.VVncQe      ,
   "tab"    : self.VVqua4       ,
   "toggleOverwrite" : self.VVHXWP    ,
   "0"     : self.VVRpCj     ,
   "1"     : self.VVRpCj     ,
   "2"     : self.VVRpCj     ,
   "3"     : self.VVRpCj     ,
   "4"     : self.VVRpCj     ,
   "5"     : self.VVRpCj     ,
   "6"     : self.VVRpCj     ,
   "7"     : self.VVRpCj     ,
   "8"     : self.VVRpCj     ,
   "9"     : self.VVRpCj
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVCiqK()
  self.onShown.append(self.VVOs7w)
  self.onClose.append(self.onExit)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  self["myLabel"].setText(self.message)
  self.VVyUng()
  if self.VVu2KL : self.VVHXWP()
  else    : self.VV8tmf()
  FFbkgB(self)
  FFUPS3(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVLD9c)
  except:
   self.timer.callback.append(self.VVLD9c)
 def onExit(self):
  self.timer.stop()
 def VVzzQL(self):
  self.VVKYNC()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVKYNC()
  self.close(None)
 def VVmIM9(self):
  VVqVzN = []
  VVqVzN.append(("Home"         , "home"    ))
  VVqVzN.append(("End"         , "end"     ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Clear All"       , "clearAll"   ))
  VVqVzN.append(("Clear To Home"      , "clearToHome"   ))
  VVqVzN.append(("Clear To End"       , "clearToEnd"   ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVT0Tr:
   VVqVzN.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("To Capital Letters"     , "toCapital"   ))
  VVqVzN.append(("To Small Letters"      , "toSmall"    ))
  FFbvqQ(self, self.VVbdw6, title="Edit Options", VVqVzN=VVqVzN)
 def VVbdw6(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVeIvJ()
   elif item == "end"     : self.VVHQtv()
   elif item == "clearAll"    : self.VVD3Yj()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVeIvJ()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVT0Tr
    VVT0Tr = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVT0Tr)
    self.VVeIvJ()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVLD9c(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVHXWP(self):
  self["myInput"].toggleOverwrite()
  self.VV8tmf()
 def VV4As8(self):
  self.session.openWithCallback(self.VVUA4B, boundFunction(CCY1TG, mode=self.charMode, VVnBGk=self.VVnBGk))
 def VVUA4B(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVyUng()
 def VV8tmf(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVCiqK(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVKYNC(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVMggz(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVEAW3(self)     : self.VV9D6v(self["myInput"].left)
 def VV4FpW(self)     : self.VV9D6v(self["myInput"].right)
 def VVOWCy(self)     : self.VV9D6v(self["myInput"].delete)
 def VVeIvJ(self)     : self.VV9D6v(self["myInput"].home)
 def VVHQtv(self)     : self.VV9D6v(self["myInput"].end)
 def VVncQe(self)    : self.VV9D6v(self["myInput"].deleteBackward)
 def VVqua4(self)     : self.VV9D6v(self["myInput"].tab)
 def VVD3Yj(self)     : self["myInput"].setText("")
 def VV9D6v(self, fnc):
  fnc()
  self.VVLD9c()
 def VVRpCj(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVMggz(newChar, overwrite)
   self.VVldHh(newChar, self["myInput"].mapping[number])
 def VVCddN(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCY1TG.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCY1TG.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVMggz(newChar, True)
   for group in groups:
    if newChar in group:
     self.VVldHh(newChar, group)
     break
 def VVldHh(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VV4Z4E:
    group = VVvBji + group.replace(newChar, FF39Hq(newChar, VV4Z4E, VVvBji))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VVkROf(self):
  if self.VVnBGk : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVyUng()
 def VVyUng(self):
  self["myInput"].mapping = CCY1TG.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCY1TG.RCU_MAP_TITLES[self.charMode])
class CCY1TG(Screen):
 VVvHRD  = 0
 VVbRzG  = 1
 VVel2j  = 2
 VVNzeT  = 3
 VVGLYH = 4
 VVqA1S = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols, arabic_nums1, arabic1)
       , ( symbols, arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A" , u"\u0628")
       , (u"\u0647" , u"\u062A")
       )
 def __init__(self, session, mode=VVvHRD, VVnBGk=False):
  self.skin, self.skinParam = FFm81W(VVtsNg, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVnBGk  = VVnBGk
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FFEPCp(self, title=self.Title)
  FFIj9t(self["keyRed"] ,"OK = Select")
  FFIj9t(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVFlFd     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VVgnWQ, -1) ,
   "next"  : boundFunction(self.VVgnWQ, +1) ,
   "left"  : boundFunction(self.VVgnWQ, -1) ,
   "right"  : boundFunction(self.VVgnWQ, +1) ,
  }, -1)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  FFUPS3(self["keyRed"], "#11222222")
  FFUPS3(self["keyGreen"], "#11222222")
  self.VVv0U3()
 def VVv0U3(self):
  self.VVITBG()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVITBG(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VVgnWQ(self, direction):
  if self.VVnBGk : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVv0U3()
 def VVFlFd(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCQ1fn(Screen):
 def __init__(self, session, title="", message="", VVNp8T=VVfHMe, VVdzWD=False, VVCMEX=None, VVzQkv=30):
  self.skin, self.skinParam = FFm81W(VVQGZG, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVzQkv)
  self.session   = session
  FFEPCp(self, title, addScrollLabel=True)
  self.VVNp8T   = VVNp8T
  self.VVdzWD   = VVdzWD
  self.VVCMEX   = VVCMEX
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  self["myLabel"].VVOdAK(VVdzWD=self.VVdzWD)
  self["myLabel"].setText(self.message, self.VVNp8T)
  if self.VVCMEX:
   FFUPS3(self["myBody"], self.VVCMEX)
   FFUPS3(self["myLabel"], self.VVCMEX)
   FFK62f(self["myLabel"], self.VVCMEX)
  self["myLabel"].VVUAyE()
class CCnFDm(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFm81W(VV2aji, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFEPCp(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  path = VVLdJi + "err.png"
  if fileExists(path):
   self["errPic"].instance.setScale(1)
   self["errPic"].instance.setPixmapFromFile(path)
class CCFtnG(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFm81W(VVn1L0, 800, 170, 25, 10, 6, "#1100202a", "#1100202a", 20)
  self.session   = session
  self.winHeight   = 0
  self.Title    = ""
  self.timer    = eTimer()
  self.barWidth   = 0
  self.barHeight   = 0
  self.isManualSeek  = False
  self.manualSeekSec  = 0
  self.manualSeekPts  = 0
  self.jumpMinutes  = CFG.playerJumpMin.getValue()
  self.cutListCounter  = 0
  self.isCutListFound  = 0
  FFEPCp(self, "", addLabel=True)
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayBarM"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayJmp"] = Label("Jump: %d m" % self.jumpMinutes)
  self["myPlaySkp"] = Label()
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayInf"] = Label("Info")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVzZWl        ,
   "info"  : self.VVax4F       ,
   "epg"  : self.VVax4F       ,
   "menu"  : self.VVyhnh        ,
   "cancel" : self.cancel        ,
   "blue"  : self.VVlPTs       ,
   "play"  : self.VVPCH4       ,
   "pause"  : self.VVPCH4       ,
   "stop"  : self.VVPCH4       ,
   "left"  : boundFunction(self.VVqwLT, -1)  ,
   "right"  : boundFunction(self.VVqwLT,  1)  ,
   "rewind" : self.VVTyBp       ,
   "forward" : self.VVLBEB       ,
   "last"  : boundFunction(self.VVzp5z, 0)   ,
   "next"  : self.VVhLn5       ,
   "0"   : boundFunction(self.VVF88R , 10) ,
   "1"   : boundFunction(self.VVF88R , 1) ,
   "2"   : boundFunction(self.VVF88R , 2) ,
   "3"   : boundFunction(self.VVF88R , 3) ,
   "4"   : boundFunction(self.VVF88R , 4) ,
   "5"   : boundFunction(self.VVF88R , 5) ,
   "6"   : boundFunction(self.VVF88R , 6) ,
   "7"   : boundFunction(self.VVF88R , 7) ,
   "8"   : boundFunction(self.VVF88R , 8) ,
   "9"   : boundFunction(self.VVF88R , 9)
  }, -1)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFiz95(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  self.instance.move(ePoint(40, 40))
  size = self.instance.size()
  self.VVnY5b = int(size.width())
  self.winHeight1 = int(size.height())
  self.winHeight2 = int(self["myPlaySep"].getPosition()[1])
  FFaaWy(self["myPlayJmp"], "#0a666666")
  FFaaWy(self["myPlaySkp"], "#0affff00")
  FFUPS3(self["myPlayBlu"], "#1118188b")
  FFUPS3(self["myPlayInf"], "#11444444")
  self["myPlayBarM"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVhakH)
  except:
   self.timer.callback.append(self.VVhakH)
  self.timer.start(1000, False)
  self.VVhakH("Checking ...")
 def onExit(self):
  self.timer.stop()
 def VVyhnh(self):
  FF0K3L(self, VVLdJi + "_help_player", "Player Controller (Keys)")
 def VVzZWl(self):
  if self.isManualSeek:
   self.VVVwJa()
   self.VVzp5z(self.manualSeekPts)
  else:
   if self.shown: self.hide()
   else   : self.show()
 def cancel(self):
  if self.isManualSeek:
   self.VVVwJa()
  else:
   self.close()
 def VVax4F(self):
  self.session.open(CC3OlU)
 def VVPCH4(self):
  try:
   InfoBar.instance.playpauseService()
  except Exception as e:
   pass
  self.VVhakH("Toggling Play/Pause ...")
 def VVVwJa(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayBarM"].hide()
   self["myPlaySkp"].hide()
 def VVqwLT(self, direc):
  seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt = self.VVQWKa()
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayBarM"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.jumpMinutes * 60.0
   else:
    self.manualSeekSec += direc * self.jumpMinutes * 60.0
    self.manualSeekSec = FFztHE(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayBarM"].instance.size().width() + 1
   left = int(FFbs3Q(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayBarM"].instance.move(ePoint(left, int(self["myPlayBarM"].getPosition()[1])))
   self["myPlaySkp"].setText(FF7B8o(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVF88R(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   FFIj9t(self["myPlayJmp"], "Jump: %d m" % self.jumpMinutes)
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVhakH("Changed Jump Minutes to : %d" % val)
 def VVhakH(self, title=""):
  if title:
   self.timer.stop()
  txt = self.Title
  seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt = self.VVQWKa()
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(str(posTxt))
    self["myPlayVal"].setText(percTxt)
    val  = FFztHE(percVal, 0, 100)
    width = int(FFbs3Q(val, 0, 100, 0, self.barWidth))
    self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
   if durTxt:
    self["myPlayDur"].setText(str(durTxt))
  if not self.isCutListFound and self.cutListCounter < 5:
   self.cutListCounter += 1
   if self.VV8Sko():
    self["myPlayBlu"].show()
    self.isCutListFound
  winH = self.instance.size().height()
  if durTxt:
   if winH < self.winHeight1:
    self.instance.resize(eSize(*(self.VVnY5b, self.winHeight1)))
  else:
   self["myPlayVal"].setText("0 %")
   if winH > self.winHeight2:
    self.instance.resize(eSize(*(self.VVnY5b, self.winHeight2)))
  if title:
   stateTxt = title
   FFaaWy(self["myPlayMsg"], "#00ff8000")
   self.timer.start(1000, False)
  else:
   stateTxt = ""
   if not posTxt and not durTxt:
    stateTxt = "Not playing yet ..."
   state = self.VVrBLK()
   if state:
    if state == "Playing" and not posTxt: stateTxt = "Unknown state"
    elif percVal == 100     : stateTxt = "End"
    else        : stateTxt = state
   state = self.VVuAql()
   if state:
    stateTxt = state
   if stateTxt == "Playing": FFaaWy(self["myPlayMsg"], "#0000ff00")
   else     : FFaaWy(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVQWKa(self):
  percVal = durVal = posVal = seekable = 0
  percTxt = durTxt = posTxt = ""
  isEnded = False
  try:
   service = self.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FF7B8o(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FF7B8o(posVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt
 def VVlPTs(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VV8Sko()
   if cList:
    VVqVzN = []
    for pts, what in cList:
     txt = FF7B8o(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVqVzN.append((txt, pts))
    FFbvqQ(self, self.VVWYeU, VVqVzN=VVqVzN, title="Cut List")
   else:
    self.VVhakH("No Cut-List for this channel !")
 def VVWYeU(self, item=None):
  if item:
   self.VVzp5z(item)
 def VV8Sko(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVLBEB(self) : self.VV4WYk(self.jumpMinutes)
 def VVTyBp(self) : self.VV4WYk(-self.jumpMinutes)
 def VV4WYk(self, mins):
  try:
   inst = InfoBar.instance
   inst.doSeekRelative(mins * 60 * 90000)
   inst.hide()
   if   mins > 0 : self.VVhakH("Forawrd (%d min) ..." % self.jumpMinutes)
   elif mins < 0 : self.VVhakH("Rewind (%d min) ..." % self.jumpMinutes)
  except:
   self.VVhakH("Cannot jump")
 def VV7wFW(self):
  InfoBar.instance.VV7wFW()
 def VVzp5z(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVhakH("Changing Time ...")
 def VVhLn5(self):
  try:
   seekable, percVal, durVal, posVal, percTxt, durTxt, posTxt = self.VVQWKa()
   if durVal > 0:
    pts = int(durVal * 60 * 90000)
    InfoBar.instance.doSeek(pts)
    self.VVhakH("Jumping to end ...")
  except:
   pass
 def VVrBLK(self):
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVuAql(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
class CCKvo2(Screen):
 def __init__(self, session, title="", VVG82G="Continue?", VVWODa=True, VVEE7G=False):
  self.skin, self.skinParam = FFm81W(VVw7dT, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVG82G = VVG82G
  self.VVEE7G = VVEE7G
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVWODa : VVqVzN = [no , yes]
  else   : VVqVzN = [yes, no ]
  FFEPCp(self, title, VVqVzN=VVqVzN, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVzZWl ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVG82G)
  if self.VVEE7G:
   self["myLabel"].instance.setHAlign(0)
  self.VVbK6Q()
  FFGE7x(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFDv7i(self["myMenu"])
  FFpxSp(self, self["myMenu"])
 def VVzZWl(self):
  item = FFVBPb(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVbK6Q(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CC5JP6(Screen):
 def __init__(self, session, title="", VVqVzN=None, width=1000, OKBtnFnc=None, VVE2sX=None, VVvE04=None, VVTaNU=None, VVmews=None, VV1G3P=False, VVDIyw=False):
  self.skin, self.skinParam = FFm81W(VVk1xP, width, 850, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVqVzN   = VVqVzN
  self.OKBtnFnc   = OKBtnFnc
  self.VVE2sX   = VVE2sX
  self.VVvE04  = VVvE04
  self.VVTaNU  = VVTaNU
  self.VVmews   = VVmews
  self.VV1G3P  = VV1G3P
  self.VVDIyw  = VVDIyw
  FFEPCp(self, title, VVqVzN=VVqVzN)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVzZWl          ,
   "cancel" : self.cancel          ,
   "red"  : self.VVQE5q         ,
   "green"  : self.VV6PxL         ,
   "yellow" : self.VVC2hJ         ,
   "blue"  : self.VVZ6rO         ,
   "pageUp" : self.VV0RLm       ,
   "chanUp" : self.VV0RLm       ,
   "pageDown" : self.VVz87m        ,
   "chanDown" : self.VVz87m
  }, -1)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  FFGE7x(self["myMenu"])
  FFmktH(self)
  self.VViFXw(self["keyRed"]  , self.VVE2sX )
  self.VViFXw(self["keyGreen"] , self.VVvE04 )
  self.VViFXw(self["keyYellow"] , self.VVTaNU )
  self.VViFXw(self["keyBlue"]  , self.VVmews )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFbkgB(self)
 def VViFXw(self, btnObj, btnFnc):
  if btnFnc:
   FFIj9t(btnObj, btnFnc[0])
 def VVzZWl(self):
  item = FFVBPb(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VV1G3P: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VVQE5q(self)  : self.VV9D6v(self.VVE2sX)
 def VV6PxL(self) : self.VV9D6v(self.VVvE04)
 def VVC2hJ(self) : self.VV9D6v(self.VVTaNU)
 def VVZ6rO(self) : self.VV9D6v(self.VVmews)
 def VV9D6v(self, btnFnc):
  if btnFnc:
   item = FFVBPb(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVDIyw:
    self.cancel()
 def VVtPsV(self, VVqVzN):
  if len(VVqVzN) > 0:
   newList = []
   for item in VVqVzN:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVWgEF(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VV0RLm(self):
  self["myMenu"].moveToIndex(0)
 def VVz87m(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCc5fD(Screen):
 def __init__(self, session, title="", header=None, VVnxKJ=None, VVfxos=None, VVf6S2=None, VVzQkv=24, VVSl9p=False, VVm7uJ=None, VVtv1H=None, VVUaPo=None, VV2BU1=None, VV2CKM=None, VVFLU5=None, VVqMZT=None, VVD9v1=None, VVUoVo=None, VVyJj1=-1, VVjJ5Z=False, searchCol=0, VVMhkn=None, VVLwBG=None, VVEsqx="#00dddddd", VVCMEX="#11002233", VVLvys="#00ff8833", VVwS8Y="#11111111", VVihFS="#0a555555", VVeMYx="#0affffff", VVVkZY="#11552200", VVZFgr="#0055ff55"):
  self.skin, self.skinParam = FFm81W(VVCMfm, 1400, 800, 50, 10, 5, "#22003344", "#22002233", 24, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFEPCp(self, title)
  self.header     = header
  self.VVnxKJ     = VVnxKJ
  self.totalCols    = len(VVnxKJ[0])
  self.VVsbUD   = 0
  self.lastSortModeIsReverese = False
  self.VVSl9p   = VVSl9p
  self.VVSBVf   = 0.01
  self.VVejpM   = 0.02
  self.VVaybB  = 1
  self.VVf6S2 = VVf6S2
  self.colWidthPixels   = []
  self.VVm7uJ   = VVm7uJ
  self.OKButtonObj   = None
  self.VVtv1H   = VVtv1H
  self.VVUaPo   = VVUaPo
  self.VV2BU1   = VV2BU1
  self.VV2CKM  = VV2CKM
  self.VVFLU5   = VVFLU5
  self.VVqMZT    = VVqMZT
  self.VVD9v1   = VVD9v1
  self.VVUoVo  = VVUoVo
  self.VVyJj1    = VVyJj1
  self.VVjJ5Z   = VVjJ5Z
  self.searchCol    = searchCol
  self.VVfxos    = VVfxos
  self.keyPressed    = -1
  self.VVzQkv    = FFaaJY(VVzQkv)
  self.VVRsNa    = FF7whL(self.VVzQkv, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVMhkn    = VVMhkn
  self.VVLwBG      = VVLwBG
  self.VVEsqx    = FFcvvP(VVEsqx)
  self.VVCMEX    = FFcvvP(VVCMEX)
  self.VVLvys    = FFcvvP(VVLvys)
  self.VVwS8Y    = FFcvvP(VVwS8Y)
  self.VVihFS   = FFcvvP(VVihFS)
  self.VVeMYx    = FFcvvP(VVeMYx)
  self.VVVkZY    = FFcvvP(VVVkZY)
  self.VVZFgr   = FFcvvP(VVZFgr)
  self.VVNBCJ  = False
  self.selectedItems   = 0
  self.VVLRTZ   = FFcvvP("#01fefe01")
  self.VV9IgX   = FFcvvP("#11400040")
  self.VVJjUl  = self.VVLRTZ
  self.VVwCUl  = self.VVwS8Y
  if self.VVjJ5Z:
   self["keyMenu1F"].hide()
   self["keyMenu1"].hide()
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVlvlz  ,
   "red"   : self.VVyehj  ,
   "green"   : self.VV45sp ,
   "yellow"  : self.VVoOso ,
   "blue"   : self.VVZkBD  ,
   "menu"   : self.VV9kpR ,
   "info"   : self.VV6sp1  ,
   "cancel"  : self.VVpC17  ,
   "up"   : self.VVeqNv    ,
   "down"   : self.VVHtTq  ,
   "left"   : self.VVrAsy   ,
   "right"   : self.VVhAlO  ,
   "pageUp"  : self.VVFEL1  ,
   "chanUp"  : self.VVFEL1  ,
   "pageDown"  : self.VVmc1o  ,
   "chanDown"  : self.VVmc1o
  }, -1)
  FFYjRo(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  try:
   self.VVmMT1()
  except Exception as err:
   FFj9Oj(self, str(err))
   self.close(None)
 def VVmMT1(self):
  FFbkgB(self)
  if self.VVMhkn:
   FFUPS3(self["myTitle"], self.VVMhkn)
  if self.VVLwBG:
   FFUPS3(self["myBody"] , self.VVLwBG)
   FFUPS3(self["myTableH"] , self.VVLwBG)
   FFUPS3(self["myTable"] , self.VVLwBG)
   FFUPS3(self["myBar"]  , self.VVLwBG)
  self.VViFXw(self.VVUaPo  , self["keyRed"])
  self.VViFXw(self.VV2BU1  , self["keyGreen"])
  self.VViFXw(self.VV2CKM , self["keyYellow"])
  self.VViFXw(self.VVFLU5  , self["keyBlue"])
  if self.VVm7uJ:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVm7uJ[0])
    FFUPS3(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVRsNa)
  self["myTableH"].l.setFont(0, gFont(VVdm9k, self.VVzQkv))
  self["myTable"].l.setItemHeight(self.VVRsNa)
  self["myTable"].l.setFont(0, gFont(VVdm9k, self.VVzQkv))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVRsNa)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVRsNa))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVRsNa)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVRsNa
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVRsNa * len(self.VVnxKJ) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVf6S2:
   self.VVf6S2 = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVf6S2)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVfxos:
   self.VVfxos = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVfxos
   self.VVfxos = []
   for item in tmpList:
    self.VVfxos.append(item | RT_VALIGN_CENTER)
  self.VVQ4v1()
  if self.VVqMZT:
   self.VVqMZT(self)
 def VViFXw(self, btnFnc, btn):
  if btnFnc : FFIj9t(btn, btnFnc[0])
  else  : FFIj9t(btn, "")
 def VVxHj3(self, waitTxt):
  FFFe8v(self, self.VVQ4v1, title=waitTxt)
 def VVQ4v1(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VV9pvQ(0, self.header, self.VVeMYx, self.VVVkZY, self.VVeMYx, self.VVVkZY, self.VVZFgr)])
   rows = []
   for c, row in enumerate(self.VVnxKJ):
    rows.append(self.VV9pvQ(c, row, self.VVEsqx, self.VVCMEX, self.VVLvys, self.VVwS8Y, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVyJj1 > -1:
    self["myTable"].moveToIndex(self.VVyJj1 )
   self.VVCEKi()
   if self.VVjJ5Z:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVRsNa * len(self.VVnxKJ)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVD9v1:
    self.VV9D6v(self.VVD9v1, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFj9Oj(self, str(err))
    self.close()
   except:
    pass
 def VV9pvQ(self, keyIndex, columns, VVEsqx, VVCMEX, VVLvys, VVwS8Y, VVZFgr):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if self.VVfxos[ndx] & LEFT:
    entry = " " + entry
   if VVZFgr and ndx == self.VVsbUD : textColor = VVZFgr
   else           : textColor = VVEsqx
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVRsNa)
           , font   = 0
           , flags   = self.VVfxos[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVCMEX
           , color_sel  = VVLvys
           , backcolor_sel = VVwS8Y
           , border_width = 1
           , border_color = self.VVihFS
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VV6sp1(self):
  rowData = self.VVYqiT()
  if rowData:
   title, txt, colList = rowData
   if self.VVtv1H:
    fnc  = self.VVtv1H[1]
    params = self.VVtv1H[2]
    fnc(self, title, txt, colList)
   else:
    FFcui4(self, txt, title)
 def VVlvlz(self):
  if   self.VVNBCJ : self.VVQAGt(self.VVrHvs(), mode=2)
  elif self.VVm7uJ  : self.VV9D6v(self.VVm7uJ, None)
  else      : self.VV6sp1()
 def VVyehj(self) : self.VV9D6v(self.VVUaPo , self["keyRed"])
 def VV45sp(self) : self.VV9D6v(self.VV2BU1 , self["keyGreen"])
 def VVoOso(self): self.VV9D6v(self.VV2CKM , self["keyYellow"])
 def VVZkBD(self) : self.VV9D6v(self.VVFLU5 , self["keyBlue"])
 def VV9D6v(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FF0fiU(self, buttonFnc[3])
    FF4YxS(boundFunction(self.VV9xDT, buttonFnc))
   else:
    self.VV9xDT(buttonFnc)
 def VV9xDT(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVYqiT()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVQAGt(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VVnxKJ[ndx]
   isSelected = row[1][9] == self.VVLRTZ
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VV9pvQ(ndx, item, self.VVEsqx, self.VVCMEX, self.VVLvys, self.VVwS8Y, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VV9pvQ(ndx, item, self.VVLRTZ, self.VV9IgX, self.VVJjUl, self.VVwCUl, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVCEKi()
 def VVYaa4(self):
  FFFe8v(self, self.VV7ocB, title="Selecting all ...")
 def VV7ocB(self):
  self.VVDQD4(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVLRTZ
   if not isSelected:
    item = self.VVnxKJ[ndx]
    newRow = self.VV9pvQ(ndx, item, self.VVLRTZ, self.VV9IgX, self.VVJjUl, self.VVwCUl, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVCEKi()
  self.VV72Wd()
 def VVOUvZ(self):
  FFFe8v(self, self.VVdk6O, title="Unselecting all ...")
 def VVdk6O(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVLRTZ:
    item = self.VVnxKJ[ndx]
    newRow = self.VV9pvQ(ndx, item, self.VVEsqx, self.VVCMEX, self.VVLvys, self.VVwS8Y, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVCEKi()
  self.VV72Wd()
 def VVYqiT(self):
  item = self["myTable"].getCurrent()
  if item:
   rowNum = item[0] + 1
   txt  = ""
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    if self.VVf6S2[i - 1] > 1 or self.VVf6S2[i - 1] == self.VVSBVf:
     if self.header : txt += "%s\t: %s\n" % (self.header[i - 1], colTxt)
     else   : txt += "Col-%d\t: %s\n" % (i, colTxt)
    colList.append(colTxt)
   return "Row Number : %d of %d\n\n" % (rowNum, len(self.VVnxKJ)), txt, colList
  else:
   return None
 def VVpC17(self):
  if self.VVUoVo : self.VVUoVo(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVQpNy(self):
  return self["myTitle"].getText().strip()
 def VVwqLs(self, title):
  self["myTitle"].setText("  " + title)
 def VVPO8w(self, txt):
  FF0fiU(self, txt)
 def VVbwVV(self, txt):
  FF0fiU(self, txt, 1000)
 def VVXuQa(self):
  FF0fiU(self)
 def VVQ1BS(self):
  return len(self.VVnxKJ)
 def VVysWb(self): self["keyGreen"].show()
 def VVjPkA(self): self["keyGreen"].hide()
 def VVrHvs(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VV5pBz(self):
  return len(self["myTable"].list)
 def VVDQD4(self, isOn):
  self.VVNBCJ = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
   if self.VVFLU5: self["keyBlue"].hide()
   if self.VVm7uJ and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
   if self.VVFLU5: self["keyBlue"].show()
   if self.VVm7uJ and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVm7uJ[0])
   self.VVOUvZ()
  FFUPS3(self["myTitle"], color)
  FFUPS3(self["myBar"]  , color)
 def VV1Xgr(self):
  return self.VVNBCJ
 def VVav9t(self):
  return self.selectedItems
 def VV72Wd(self):
  self.hide()
  self.show()
 def VVu3gt(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVCEKi()
 def VVULna(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VVnxKJ:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVF9Be(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVQ1BS()
  txt += FFAAb7("Total Unique Items", VVepFH)
  for i in range(self.totalCols):
   if self.VVf6S2[i - 1] > 1 or self.VVf6S2[i - 1] == self.VVSBVf:
    name, tot = self.VVULna(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFcui4(self, txt)
 def VVtuRl(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VV6duD(self, newList, newTitle=""):
  if newList:
   self.VVnxKJ = newList
   if self.VVSl9p and self.VVsbUD == 0:
    self.VVnxKJ = sorted(self.VVnxKJ, key=lambda x: int(x[self.VVsbUD])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VVnxKJ = sorted(self.VVnxKJ, key=lambda x: x[self.VVsbUD].lower(), reverse=self.lastSortModeIsReverese)
   self.VVxHj3("Refreshing ...")
   if newTitle:
    self.VVwqLs(newTitle)
  else:
   FFj9Oj(self, "Cannot refresh list")
   self.cancel()
 def VVTAfS(self, data):
  ndx = self.VVrHvs()
  newRow = self.VV9pvQ(ndx, data, self.VVEsqx, self.VVCMEX, self.VVLvys, self.VVwS8Y, None)
  if newRow:
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VV72Wd()
   return True
  else:
   return False
 def VVFBev(self, colNum, textToFind, showErr=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVCEKi()
    break
  else:
   if showErr:
    FF0fiU(self, "Not found", 1000)
 def VVkQmG(self, colDict, showErr=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVCEKi()
    return
  if showErr:
   FF0fiU(self, "Not found", 1000)
 def VVkQmG_partial(self, colDict, showErr=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(txt, self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVCEKi()
    return
  if showErr:
   FF0fiU(self, "Not found", 1000)
 def VV2uMm(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVHjRM(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVLRTZ:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VV9ASy(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VV9kpR(self):
  if not self["keyMenu2F"].getVisible():
   return
  if not self.VVjJ5Z:
   VVqVzN = []
   VVqVzN.append(("Table Statistcis"             , "tableStat"  ))
   VVqVzN.append(VVPkfI)
   VVqVzN.append((FF39Hq("Export Table to .html"     , VVepFH) , "VVxiMO" ))
   VVqVzN.append((FF39Hq("Export Table to .csv"     , VVepFH) , "VVk35g" ))
   VVqVzN.append((FF39Hq("Export Table to .txt (Tab Separated)", VVepFH) , "VVK8eb" ))
   VVqVzN.append(VVPkfI)
   for i in range(self.totalCols):
    if self.header : name = self.header[i]
    else   : name = "Col-%d" % i
    if self.VVf6S2[i] > 1 or self.VVf6S2[i] == self.VVejpM:
     VVqVzN.append(("Sort by : %s" % name, i))
   if VVqVzN:
    FFbvqQ(self, self.VVrrzu, VVqVzN=VVqVzN, title=self.VVQpNy())
 def VVrrzu(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVF9Be()
   elif item == "VVxiMO": FFFe8v(self, self.VVxiMO, title=title)
   elif item == "VVk35g" : FFFe8v(self, self.VVk35g , title=title)
   elif item == "VVK8eb" : FFFe8v(self, self.VVK8eb , title=title)
   else:
    isReversed = False
    if self.VVsbUD == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVSl9p and item == 0:
     self.VVnxKJ = sorted(self.VVnxKJ, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VVnxKJ = sorted(self.VVnxKJ, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVsbUD = item
    self.VVxHj3("Sorting ...")
 def VVeqNv(self):
  self["myTable"].up()
  self.VVCEKi()
 def VVHtTq(self):
  self["myTable"].down()
  self.VVCEKi()
 def VVrAsy(self):
  self["myTable"].pageUp()
  self.VVCEKi()
 def VVhAlO(self):
  self["myTable"].pageDown()
  self.VVCEKi()
 def VVFEL1(self):
  self["myTable"].moveToIndex(0)
  self.VVCEKi()
 def VVmc1o(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVCEKi()
 def VVK8eb(self):
  expFile = self.VVviqA() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVavgN()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VVnxKJ:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVf6S2[ndx] > self.VVaybB:
      col = self.VVocWO(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVT2BC(expFile)
 def VVk35g(self):
  expFile = self.VVviqA() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVavgN()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VVnxKJ:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVf6S2[ndx] > self.VVaybB:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVocWO(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVT2BC(expFile)
 def VVxiMO(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVQpNy(), PLUGIN_NAME, VVjmQ2)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVQpNy()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVavgN()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVf6S2:
   colgroup += '   <colgroup>'
   for w in self.VVf6S2:
    if w > self.VVaybB:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVviqA() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VVnxKJ:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVf6S2[ndx] > self.VVaybB:
      col = self.VVocWO(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVT2BC(expFile)
 def VVavgN(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVf6S2[ndx] > self.VVaybB:
     newRow.append(col.strip())
  return newRow
 def VVocWO(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  return FFiZhB(col)
 def VVviqA(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVQpNy())
  fileName = fileName.replace("__", "_")
  path  = FFRJ2W(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFCy03()
  return expFile
 def VVT2BC(self, expFile):
  FFhXFJ(self, "File exported to:\n\n%s" % expFile, title=self.VVQpNy())
 def VVCEKi(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CCMtHS(Screen):
 def __init__(self, session, Title="", VVhesn=None):
  self.skin, self.skinParam = FFm81W(VVmTxQ, 1400, 800, 50, 40, 20, "#22000060", "#2200002a", 30)
  self.session = session
  FFEPCp(self, Title, addCloser=True)
  self["myLabel"]  = Pixmap()
  self.VVhesn = VVhesn
  if len(Title) == 0 : Title = FFfHwI()
  else    : Title = "File : %s" % VVhesn
  self["myTitle"] = Label("  %s" % Title)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  allOK = FF20Za(self["myLabel"], self.VVhesn)
  if not allOK:
   FFj9Oj(self, "Could not view this picture file")
   self.close()
class CCX1EL(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFm81W(VVKQ1t, 1400, 850, 50, 40, 40, "#11201010", "#11101010", 32, barHeight=40, topRightBtns=1)
  self.session  = session
  FFEPCp(self)
  FFIj9t(self["keyGreen"], "Save")
  self.VVnxKJ = []
  self.VVnxKJ.append(getConfigListEntry("Show in Main Menu"     , CFG.showInMainMenu   ))
  self.VVnxKJ.append(getConfigListEntry("Show in Extensions Menu"    , CFG.showInExtensionMenu  ))
  self.VVnxKJ.append(getConfigListEntry("Show in Channel List Context Menu" , CFG.showInChannelListMenu  ))
  self.VVnxKJ.append(getConfigListEntry("Input Type"       , CFG.keyboard     ))
  self.VVnxKJ.append(getConfigListEntry("Signal & Player Cotroller Hotkey" , CFG.hotkey_signal    ))
  self.VVnxKJ.append(getConfigListEntry("Default IPTV Reference Type"   , CFG.iptvAddToBouquetRefType ))
  self.VVnxKJ.append(getConfigListEntry(VVfebv *2        ,         ))
  self.VVnxKJ.append(getConfigListEntry("PIcons Path"       , CFG.PIconsPath    ))
  self.VVnxKJ.append(getConfigListEntry(VVfebv *2        ,         ))
  self.VVnxKJ.append(getConfigListEntry("Backup/Restore Path"     , CFG.backupPath    ))
  self.VVnxKJ.append(getConfigListEntry("Created Package Files (IPK/DEB)"  , CFG.packageOutputPath   ))
  self.VVnxKJ.append(getConfigListEntry("Downloaded Packages (from feeds)" , CFG.downloadedPackagesPath ))
  self.VVnxKJ.append(getConfigListEntry("Exported Tables"      , CFG.exportedTablesPath  ))
  self.VVnxKJ.append(getConfigListEntry("Exported PIcons"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, self.VVnxKJ, session)
  self["setupActions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard", "OkCancelActions"],
  {
   "ok"  : self.VVzZWl   ,
   "OK"  : self.VVzZWl   ,
   "green"  : self.VVnD1z  ,
   "menu"  : self.VV9HP1 ,
   "cancel" : self.VVC4Vk
  }, -1)
  self.titleText = "  Settings"
  self["myTitle"].setText(self.titleText)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  FFGE7x(self["config"])
  FFmktH(self,  self["config"])
  FFbkgB(self)
 def VVzZWl(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.PIconsPath    : self.VV5Ry8(item)
   elif item == CFG.backupPath    : self.VV5Ry8(item)
   elif item == CFG.packageOutputPath  : self.VV5Ry8(item)
   elif item == CFG.downloadedPackagesPath : self.VV5Ry8(item)
   elif item == CFG.exportedTablesPath  : self.VV5Ry8(item)
   elif item == CFG.exportedPIconsPath  : self.VV5Ry8(item)
 def VV5Ry8(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(boundFunction(self.VV0ui7, configObj)
         , boundFunction(CC1oiB, mode=CC1oiB.BROWSER_MODE_DIR_PICKER, VVcSFS=sDir))
 def VV0ui7(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVC4Vk(self):
  if CFG.showInMainMenu.isChanged()   or \
   CFG.showInExtensionMenu.isChanged()  or \
   CFG.showInChannelListMenu.isChanged() or \
   CFG.keyboard.isChanged()    or \
   CFG.hotkey_signal.isChanged()   or \
   CFG.iptvAddToBouquetRefType.isChanged() or \
   CFG.PIconsPath.isChanged()    or \
   CFG.backupPath.isChanged()    or \
   CFG.packageOutputPath.isChanged()  or \
   CFG.downloadedPackagesPath.isChanged() or \
   CFG.exportedTablesPath.isChanged()  or \
   CFG.exportedPIconsPath.isChanged():
    FFi0Lh(self, self.VVnD1z, "Save Changes ?", callBack_No=self.cancel)
  else:
   self.cancel()
 def VVnD1z(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVMxoL()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VV9HP1(self):
  VVqVzN = []
  VVqVzN.append(("Use Backup directory in all other paths"      , "VVANQJ"   ))
  VVqVzN.append(("Reset all to default (including File Manager bookmarks)"  , "VVjXPE"   ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Change Text Color Scheme (for Transparent Text)"    , "changeColorScheme" ))
  if fileExists(VVjHyF + VVSqx6):
   VVqVzN.append(VVPkfI)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVqVzN.append(('%s Checking for Update' % txt1       , txt2     ))
   VVqVzN.append(("Reinstall %s" % PLUGIN_NAME        , "VVevCW"  ))
   VVqVzN.append(("Update %s" % PLUGIN_NAME        , "VVDXGR"   ))
  FFbvqQ(self, self.VVvI6r, VVqVzN=VVqVzN, title="Config. Options")
 def VVvI6r(self, item=None):
  if item:
   if   item == "VVANQJ"  : FFi0Lh(self, self.VVANQJ , "Use Backup directory in all other paths (and save) ?")
   elif item == "VVjXPE"  : FFi0Lh(self, self.VVjXPE, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCndzU)
   elif item == "enableChkUpdate" : self.VVwZJv(True)
   elif item == "disableChkUpdate" : self.VVwZJv(False)
   elif item == "VVevCW" : FFFe8v(self, self.VVevCW , "Checking Server ...")
   elif item == "VVDXGR"  : FFFe8v(self, self.VVDXGR  , "Checking Server ...")
 def VVwZJv(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVANQJ(self):
  newPath = FFRJ2W(VVjHyF)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVMxoL()
 @staticmethod
 def VV12tJ():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVjXPE(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.PIconsPath.setValue(VVRRk2)
  CFG.backupPath.setValue(CCX1EL.VV12tJ())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  CFG.showInMainMenu.save()
  CFG.showInExtensionMenu.save()
  CFG.showInChannelListMenu.save()
  CFG.keyboard.save()
  CFG.hotkey_signal.save()
  CFG.iptvAddToBouquetRefType.save()
  CFG.PIconsPath.save()
  CFG.backupPath.save()
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  CFG.browserStartPath.save()
  CFG.browserBookmarks.save()
  self.VVMxoL()
  self.close()
 def VVMxoL(self):
  configfile.save()
  global VVjHyF
  VVjHyF = CFG.backupPath.getValue()
  FFCPT9()
 def VVDXGR(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VVLrJh(title)
  if webVer:
   FFi0Lh(self, boundFunction(FFFe8v, self, boundFunction(self.VVAmKf, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVevCW(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VVLrJh(title, True)
  if webVer:
   FFi0Lh(self, boundFunction(FFFe8v, self, boundFunction(self.VVAmKf, webVer, title)), "Install and Restart ?", title=title)
 def VVAmKf(self, webVer, title):
  url = self.VVyJsH(self, title)
  if url:
   VV9ot9 = FF5iuo() == "dpkg"
   if VV9ot9 == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VV9ot9 else "ipk")
   path, err = FFarie(url + fName, fName, timeout=2)
   if path:
    cmd = FFxt6o(VVxMeg, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFFM6I(self, cmd)
    else:
     FFhggE(self, title=title)
   else:
    FFj9Oj(self, err, title=title)
 def VVLrJh(self, title, anyVer=False):
  url = self.VVyJsH(self, title)
  if not url:
   return ""
  path, err = FFarie(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFj9Oj(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FF7gKM(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFj9Oj(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVjmQ2.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FFGZr4(cmd)
   if list and curVer == list[0]:
    return webVer
  FFhXFJ(self, FF39Hq("No update required.", VVul8x) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVyJsH(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVjHyF + VVSqx6
  if fileExists(path):
   span = iSearch(r"(http.+)", FF7gKM(path), IGNORECASE)
   if span : url = FFRJ2W(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFj9Oj(SELF, err, title)
  return url
 @staticmethod
 def VV1UtK(url):
  path, err = FFarie(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FF7gKM(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVjmQ2.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FFGZr4(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCndzU(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFm81W(VVHFU8, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVZp5T
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFEPCp(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VV4MSS("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VV4MSS("\c00888888", i) + sp + "GREY\n"
   txt += self.VV4MSS("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VV4MSS("\c00FF0000", i) + sp + "RED\n"
   txt += self.VV4MSS("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VV4MSS("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VV4MSS("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VV4MSS("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VV4MSS("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VV4MSS("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VV4MSS("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VV4MSS("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVzZWl ,
   "green"   : self.VVzZWl ,
   "left"   : self.VV29Kt ,
   "right"   : self.VVms4U ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  self.VVVrsQ()
 def VVzZWl(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFi0Lh(self, self.VVKQ5Q, "Change to : %s" % txt, title=self.Title)
 def VVKQ5Q(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVZp5T
  VVZp5T = self.cursorPos
  self.VV54Yf()
  self.close()
 def VV29Kt(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVVrsQ()
 def VVms4U(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVVrsQ()
 def VVVrsQ(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VV4MSS(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVMaPH(color):
  if VVESyM: return "\\" + color
  else    : return ""
 @staticmethod
 def VV54Yf():
  global VVdsiT, VVvBji, VVUDh4, VVepFH, VVTNcj, VVKtLG, VVul8x, VVESyM, COLOR_CONS_BRIGHT_YELLOW, VV3hnc, VVMwfZ, VV4Z4E
  VV4Z4E   = CCndzU.VV4MSS("\c00FFFFFF", VVZp5T)
  VVvBji    = CCndzU.VV4MSS("\c00888888", VVZp5T)
  VVdsiT  = CCndzU.VV4MSS("\c005A5A5A", VVZp5T)
  VVKtLG    = CCndzU.VV4MSS("\c00FF0000", VVZp5T)
  VVUDh4   = CCndzU.VV4MSS("\c00FF5000", VVZp5T)
  VVESyM   = CCndzU.VV4MSS("\c00FFFF00", VVZp5T)
  COLOR_CONS_BRIGHT_YELLOW = CCndzU.VV4MSS("\c00FFFFAA", VVZp5T)
  VVul8x   = CCndzU.VV4MSS("\c0000FF00", VVZp5T)
  VVTNcj    = CCndzU.VV4MSS("\c000066FF", VVZp5T)
  VV3hnc    = CCndzU.VV4MSS("\c0000FFFF", VVZp5T)
  VVMwfZ   = CCndzU.VV4MSS("\c00FA55E7", VVZp5T)
  VVepFH    = CCndzU.VV4MSS("\c00FF8F5F", VVZp5T)
CCndzU.VV54Yf()
class CCgJW5(Screen):
 def __init__(self, session, path, VV9ot9):
  self.skin, self.skinParam = FFm81W(VVlOWi, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVPgP7   = path
  self.VVfj6K   = ""
  self.VV0yj0   = ""
  self.VV9ot9    = VV9ot9
  self.VVVgyV    = ""
  self.VVyQ1C  = ""
  self.VVyxQH    = False
  self.VVWgJj  = False
  self.postInstAcion   = 0
  self.VVItvD  = "enigma2-plugin-extensions"
  self.VVC8Wy  = "enigma2-plugin-systemplugins"
  self.VVaMaY = "enigma2"
  self.VVGDAg  = 0
  self.VVgX7p  = 1
  self.VVqs4E  = 2
  if pathExists(self.Path + "DEBIAN") : self.VV93TB = "DEBIAN"
  else        : self.VV93TB = "CONTROL"
  self.controlPath = self.Path + self.VV93TB
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VV9ot9:
   self.packageExt  = ".deb"
   self.VVCMEX  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVCMEX  = "#11001020"
  FFEPCp(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFIj9t(self["keyRed"] , "Create")
  FFIj9t(self["keyGreen"] , "Post Install")
  FFIj9t(self["keyYellow"], "Installation Path")
  FFIj9t(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVjSwA  ,
   "green"   : self.VVwNVQ ,
   "yellow"  : self.VVYZPW  ,
   "blue"   : self.VVE7UA  ,
   "cancel"  : self.VVGvWt
  }, -1)
  self.onShown.append(self.VVOs7w)
 def VVOs7w(self):
  self.onShown.remove(self.VVOs7w)
  FFbkgB(self)
  if self.VVCMEX:
   FFUPS3(self["myBody"], self.VVCMEX)
   FFUPS3(self["myLabel"], self.VVCMEX)
  self.VVI9AS(True)
  self.VVaGsm(True)
 def VVaGsm(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVZnyA()
  if isFirstTime:
   if   package.startswith(self.VVItvD) : self.VVPgP7 = VVxO5U + self.VVVgyV + "/"
   elif package.startswith(self.VVC8Wy) : self.VVPgP7 = VVPnB7 + self.VVVgyV + "/"
   else            : self.VVPgP7 = self.Path
  if self.VVyxQH : myColor = VVepFH
  else    : myColor = VV4Z4E
  txt  = ""
  txt += "Source Path\t: %s\n" % FF39Hq(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FF39Hq(self.VVPgP7, VVESyM)
  if self.VV0yj0 : txt += "Package File\t: %s\n" % FF39Hq(self.VV0yj0, VVvBji)
  elif errTxt   : txt += "Warning\t: %s\n"  % FF39Hq("Check Control File fields : %s" % errTxt, VVUDh4)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FF39Hq("Restart GUI", VVepFH)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FF39Hq("Reboot Device", VVepFH)
  else      : act = "No action."
  txt += "\nPost Install\t: %s\n" % act
  if not errTxt and VVUDh4 in controlInfo:
   txt += "Warning\t: %s\n" % FF39Hq("Errors in control file may affect the result package.", VVUDh4)
  txt += "\nControl File\t: %s\n" % FF39Hq(self.controlFile, VVvBji)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVwNVQ(self):
  VVqVzN = []
  VVqVzN.append(("No Action"    , "noAction"  ))
  VVqVzN.append(("Restart GUI"    , "VVX7yx"  ))
  VVqVzN.append(("Reboot Device"   , "rebootDev"  ))
  FFbvqQ(self, self.VVWQTO, title="Package Installation Option (after completing installation)", VVqVzN=VVqVzN)
 def VVWQTO(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVX7yx"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVI9AS(False)
   self.VVaGsm()
 def VVYZPW(self):
  VVqVzN = []
  VVqVzN.append(("Current Path"   , "toCurrent"  ))
  VVqVzN.append(("Extension Path"  , "toExtensions" ))
  VVqVzN.append(("System Plugins Path" , "toSystemPlugins" ))
  VVqVzN.append(("Root Path"   , "toRoot"   ))
  VVqVzN.append(("Other Path"   , "toOthers"  ))
  FFbvqQ(self, self.VVmRu5, title="Installation Path", VVqVzN=VVqVzN)
 def VVmRu5(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVfkBS(FFgmeM(self.Path, True))
   elif item == "toExtensions"  : self.VVfkBS(VVxO5U)
   elif item == "toSystemPlugins" : self.VVfkBS(VVPnB7)
   elif item == "toRoot"   : self.VVfkBS("/")
   elif item == "toOthers"   : self.session.openWithCallback(self.VVi6dE, boundFunction(CC1oiB, mode=CC1oiB.BROWSER_MODE_DIR_PICKER, VVcSFS=VVjHyF))
 def VVi6dE(self, path):
  if len(path) > 0:
   self.VVfkBS(path)
 def VVfkBS(self, parent):
  self.VVPgP7 = parent + self.VVVgyV + "/"
  mode = self.VVP8fK()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVoFr9(mode), self.controlFile))
  self.VVaGsm()
 def VVE7UA(self):
  if fileExists(self.controlFile):
   lines = FF709T(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFxR0u(self, self.VVKO6o, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFj9Oj(self, "Version not found or incorrectly set !")
  else:
   FFQJvo(self, self.controlFile)
 def VVKO6o(self, VVNYr8):
  if VVNYr8:
   version, color = self.VVvO3s(VVNYr8, False)
   if color == VV3hnc:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVNYr8, self.controlFile))
    self.VVaGsm()
   else:
    FFj9Oj(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVGvWt(self):
  if self.newControlPath:
   if self.VVyxQH:
    self.VVndxf()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FF39Hq(self.newControlPath, VVvBji)
    txt += FF39Hq("Do you want to keep these files ?", VVESyM)
    FFi0Lh(self, self.close, txt, callBack_No=self.VVndxf, title="Create Package", VVEE7G=True)
  else:
   self.close()
 def VVndxf(self):
  os.system(FFhmFU("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVoFr9(self, mode):
  if   mode == self.VVgX7p : prefix = self.VVItvD
  elif mode == self.VVqs4E : prefix = self.VVC8Wy
  else        : prefix = self.VVaMaY
  return prefix + "-" + self.VVyQ1C
 def VVP8fK(self):
  if   self.VVPgP7.startswith(VVxO5U) : return self.VVgX7p
  elif self.VVPgP7.startswith(VVPnB7) : return self.VVqs4E
  else            : return self.VVGDAg
 def VVI9AS(self, isFirstTime):
  self.VVVgyV   = os.path.basename(os.path.normpath(self.Path))
  self.VVVgyV   = "_".join(self.VVVgyV.split())
  self.VVyQ1C = self.VVVgyV.lower()
  self.VVyxQH = self.VVyQ1C == VVzi9Y.lower()
  if self.VVyxQH and self.VVyQ1C.endswith("ajpan"):
   self.VVyQ1C += "el"
  if self.VVyxQH : self.VVfj6K = VVjHyF
  else    : self.VVfj6K = CFG.packageOutputPath.getValue()
  self.VVfj6K = FFRJ2W(self.VVfj6K)
  if not pathExists(self.controlPath):
   os.system(FFhmFU("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVyxQH : t = PLUGIN_NAME
  else    : t = self.VVVgyV
  self.VVSyGK(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VVxJlC.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVyxQH : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVSyGK(self.postrmFile, txt)
  if self.VVyxQH:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVjmQ2)
   self.VVSyGK(self.preinstFile, txt)
  else:
   self.VVSyGK(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVVgyV)
  mode = self.VVP8fK()
  if isFirstTime and not mode == self.VVGDAg:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVfebv
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVSyGK(self.postinstFile, txt, VVu2KL=True)
  os.system(FFhmFU("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVyxQH : version, descripton, maintainer = VVjmQ2 , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVVgyV , self.VVVgyV
   txt = ""
   txt += "Package: %s\n"  % self.VVoFr9(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVSyGK(self, path, lines, VVu2KL=False):
  if not fileExists(path) or VVu2KL:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVZnyA(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FF709T(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FF39Hq(line, VVUDh4)
     elif not line.startswith(" ")    : line = FF39Hq(line, VVUDh4)
     else          : line = FF39Hq(line, VV3hnc)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VV3hnc
   else   : color = VVUDh4
   descr = FF39Hq(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVUDh4
     elif line.startswith((" ", "\t")) : color = VVUDh4
     elif line.startswith("#")   : color = VVvBji
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVvO3s(val, True)
      elif key == "Version"  : version, color = self.VVvO3s(val, False)
      elif key == "Maintainer" : maint  , color = val, VV3hnc
      elif key == "Architecture" : arch  , color = val, VV3hnc
      else:
       color = VV3hnc
      if not key == "OE" and not key.istitle():
       color = VVUDh4
     else:
      color = VVepFH
     txt += FF39Hq(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VV0yj0 = self.VVfj6K + packageName
   self.VVWgJj = True
   errTxt = ""
  else:
   self.VV0yj0  = ""
   self.VVWgJj = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVvO3s(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VV3hnc
  else          : return val, VVUDh4
 def VVjSwA(self):
  if not self.VVWgJj:
   FFj9Oj(self, "Please fix Control File errors first.")
   return
  if self.VV9ot9: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFgmeM(self.VVPgP7, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVVgyV
  symlinkTo  = FFdjQ5(self.Path)
  dataDir   = self.VVPgP7.rstrip("/")
  removePorjDir = FFhmFU("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFhmFU("rm -f '%s'" % self.VV0yj0) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFwjGA()
  if self.VV9ot9:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFIEas("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVyxQH:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VV93TB)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VV0yj0, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VV0yj0
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VV0yj0, FFDI4H(result  , VVul8x))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVPgP7, FFDI4H(instPath, VV3hnc))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFDI4H(failed, VVUDh4))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFFM6I(self, cmd)
class CC1oiB(Screen):
 BROWSER_MODE_NORMAL   = 0
 BROWSER_MODE_DIR_PICKER  = 1
 MAX_BOOKMARKS = 20
 def __init__(self, session, VVcSFS="/", mode=BROWSER_MODE_NORMAL, VVSGYc="Select", VVzQkv=30):
  self.skin, self.skinParam = FFm81W(VVk1xP, 1400, 820, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FFEPCp(self)
  FFIj9t(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVSGYc = VVSGYc
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  if   self.mode == self.BROWSER_MODE_NORMAL  : VVigGp, self.VVcSFS = True , CFG.browserStartPath.getValue()
  elif self.mode == self.BROWSER_MODE_DIR_PICKER : VVigGp, self.VVcSFS = False, VVcSFS
  else           : VVigGp, self.VVcSFS = True , VVcSFS
  VVcSFS = FFRJ2W(VVcSFS)
  self["myMenu"] = CCkQI5(  directory   = "/"
         , VVigGp   = VVigGp
         , VVu7i5 = True
         , VVnY5b   = self.skinParam["width"]
         , VVzQkv   = self.skinParam["bodyFontSize"]
         , VVRsNa  = self.skinParam["bodyLineH"]
         , VVjIhK  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVzZWl      ,
   "cancel"   : self.cancel      ,
   "green"    : self.VV3kyw    ,
   "yellow"   : self.VVA1Y1   ,
   "blue"    : self.VVaaSb   ,
   "menu"    : self.VVUu9x    ,
   "info"    : self.VV8UWQ    ,
   "pageUp"   : self.VVtPk1     ,
   "chanUp"   : self.VVtPk1
  }, -1)
  FFYjRo(self, self["myMenu"])
  self.onShown.append(self.start)
  self["myMenu"].onSelectionChanged.append(self.VVt0ko)
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVt0ko)
  FFGE7x(self["myMenu"], bg="#06003333")
  FFbkgB(self)
  self.maxTitleWidth = self["keyMenu1"].getPosition()[0] - 40
  if self.mode == self.BROWSER_MODE_DIR_PICKER:
   FFIj9t(self["keyGreen"], self.VVSGYc)
   color = "#22000022"
   FFUPS3(self["myBody"], color)
   FFUPS3(self["myMenu"], color)
   color = "#22220000"
   FFUPS3(self["myTitle"], color)
   FFUPS3(self["myBar"], color)
  self.VVt0ko()
  if self.VVIpQA(self.VVcSFS) > self.bigDirSize:
   FF0fiU(self, "Changing directory...")
   FF4YxS(self.VVtTE2)
  else:
   self.VVtTE2()
 def VVtTE2(self):
  self["myMenu"].VVugxV(self.VVcSFS)
 def VVwwya(self):
  self["myMenu"].refresh()
  FF0Wsq()
 def VVIpQA(self, folder):
  totalItems = 0
  if pathExists(folder):
   totalItems = len(os.listdir(folder))
  return totalItems
 def VVzZWl(self):
  if self["myMenu"].VVj4UA():
   path = self.VVmspx(self.VVw5fs())
   if self.VVIpQA(path) > self.bigDirSize:
    FF0fiU(self, "Changing directory...")
    FF4YxS(self.VVkpjz)
   else:
    self.VVkpjz()
  else:
   self.VVINXL()
 def VVkpjz(self):
  self["myMenu"].descent()
  self["myMenu"].moveToIndex(0)
  self.VVt0ko()
 def VVtPk1(self):
  if self["myMenu"].VVMouN():
   self["myMenu"].moveToIndex(0)
   self.VVkpjz()
 def cancel(self):
  if not FFjMv5(self):
   self.close("")
 def VV3kyw(self):
  if self.mode == self.BROWSER_MODE_DIR_PICKER:
   path = self.VVmspx(self.VVw5fs())
   self.close(path)
 def VV8UWQ(self):
  FFFe8v(self, self.VV8E50, title="Calculating size ...")
 def VV8E50(self):
  path = self.VVmspx(self.VVw5fs())
  param = self.VVetEW(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = ""
   if typeChar == "d":
    result = FFedlY("myDir='%s'; totDirs=$(find $myDir -type d | wc -l); totFiles=$(find $myDir ! -type d | wc -l); echo $totDirs','$totFiles" % path)
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents  = "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
    size = FFedlY("find %s ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    size = int(size)
   if size >= 1024 : size = "%s  ( %s bytes )" % (self.VVFDYM(size), format(size, ',d'))
   else   : size = "%s" % self.VVFDYM(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FF39Hq(pathTxt, VVepFH) + "\n"
   if slBroken : fileTime = self.VVHyiy(path)
   else  : fileTime = self.VVo44p(path)
   def VVRhq7(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVRhq7("Path"    , pathTxt)
   txt += VVRhq7("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVRhq7("Target"   , slTarget)
   txt += VVRhq7("Size"    , "%s" % size)
   txt += contents
   txt += "\n"
   txt += VVRhq7("Owner"    , owner)
   txt += VVRhq7("Group"    , group)
   txt += VVRhq7("Perm. (User)"  , permUser)
   txt += VVRhq7("Perm. (Group)"  , permGroup)
   txt += VVRhq7("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVRhq7("Perm. (Ext.)" , permExtra)
   txt += VVRhq7("iNode"    , iNode)
   txt += VVRhq7("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVfebv, VVfebv)
    txt += hLinkedFiles
  else:
   FFj9Oj(self, "Cannot access information !")
  if len(txt) > 0:
   FFcui4(self, txt)
 def VVetEW(self, path):
  path = path.strip()
  path = FFdjQ5(path)
  result = FFedlY("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVXYFL(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVXYFL(perm, 1, 4)
   permGroup = VVXYFL(perm, 4, 7)
   permOther = VVXYFL(perm, 7, 10)
   permExtra = VVXYFL(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFBul9("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVo44p(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFXglk(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFXglk(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFXglk(os.path.getctime(path))
  return txt
 def VVHyiy(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFedlY("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFedlY("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFedlY("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVFDYM(self, size):
  power = 1024.0
  n = 0
  power_labels = {0 : 'B', 1: 'kB', 2: 'MB', 3: 'GB', 4: 'TB'}
  while size > power:
   size /= power
   n += 1
  size = "%.1f" % size
  if size.endswith(".0"):
   size = size[:-2]
  return "%s %s" % (size, power_labels[n])
 def VVmspx(self, currentSel):
  currentDir  = self["myMenu"].VVMouN()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVj4UA():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVw5fs(self):
  return self["myMenu"].getSelection()[0]
 def VVt0ko(self):
  FF0fiU(self)
  path = self.VVmspx(self.VVw5fs())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VVnxKJ = self.VVg7Db()
  if VVnxKJ and len(VVnxKJ) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VVuHBU(path)
  if self.mode == self.BROWSER_MODE_NORMAL and len(path) > 0:
   self["keyMenu2F"].show()
   self["keyMenu2"].show()
  else:
   self["keyMenu2F"].hide()
   self["keyMenu2"].hide()
 def VVuHBU(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVUQ3G(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVUu9x(self):
  if self.mode == self.BROWSER_MODE_NORMAL:
   path  = self.VVmspx(self.VVw5fs())
   isDir  = os.path.isdir(path)
   VVqVzN = []
   VVqVzN.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVFYRK(path):
     sepShown = True
     VVqVzN.append(VVPkfI)
     VVqVzN.append( (VVepFH + "Archiving / Packaging"      , "VVinUF"  ))
    if self.VVRN2Z(path):
     if not sepShown:
      VVqVzN.append(VVPkfI)
     VVqVzN.append( (VVepFH + "Read Backup information"     , "VVeWPw"  ))
     VVqVzN.append( (VVepFH + "Compress Octagon Image (to zip File)"  , "VVB9SJ" ))
   elif os.path.isfile(path):
    selFile = self.VVw5fs()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip"))   : VVqVzN.extend(self.VVrjpQ(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVqVzN.extend(self.VVXhV2(True))
    elif selFile.endswith(".m3u")              : VVqVzN.extend(self.VVwhBO(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FFWywO(path):
     VVqVzN.append(VVPkfI)
     VVqVzN.append((VVepFH + "View" , "text_View" ))
     VVqVzN.append((VVepFH + "Edit" , "text_Edit" ))
    if len(txt) > 0:
     VVqVzN.append(VVPkfI)
     VVqVzN.append(   (VVepFH + txt      , "VVINXL"  ))
   VVqVzN.append(VVPkfI)
   VVqVzN.append(     ("Create SymLink"       , "VVUkXa" ))
   if not self.VVFYRK(path):
    VVqVzN.append(   ("Rename"          , "VVAa9n" ))
    VVqVzN.append(   ("Copy"           , "copyFileOrDir" ))
    VVqVzN.append(   ("Move"           , "moveFileOrDir" ))
    VVqVzN.append(   ("DELETE"          , "VVsc1F" ))
    if fileExists(path):
     VVqVzN.append(VVPkfI)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVqVzN.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVqVzN.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVqVzN.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVqVzN.append(VVPkfI)
   VVqVzN.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVqVzN.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   VVqVzN.append(VVPkfI)
   VVqVzN.append(    ("Set current directory as \"Startup Path\"" , "VVb8uV" ))
   FFbvqQ(self, self.VV5ryQ, title="Options", VVqVzN=VVqVzN)
 def VV5ryQ(self, item=None):
  if self.mode == self.BROWSER_MODE_NORMAL:
   if item is not None:
    path = self.VVmspx(self.VVw5fs())
    selFile = self.VVw5fs()
    if   item == "properties"    : self.VV8UWQ()
    elif item == "VVinUF"  : self.VVinUF(path)
    elif item == "VVeWPw"  : self.VVeWPw(path)
    elif item == "VVB9SJ" : self.VVB9SJ(path)
    elif item.startswith("extract_")  : self.VVIaQY(path, selFile, item)
    elif item.startswith("script_")   : self.VVu3w0(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVzmDiItem_m3u(path, selFile, item)
    elif item.startswith("text_View")  : FFuyab(self, path)
    elif item.startswith("text_Edit")  : CCOrgc(self, path, VVBijC=self.VVwwya)
    elif item == "chmod644"     : self.VVSFUk(path, selFile, "644")
    elif item == "chmod755"     : self.VVSFUk(path, selFile, "755")
    elif item == "chmod777"     : self.VVSFUk(path, selFile, "777")
    elif item == "VVUkXa"   : self.VVUkXa(path, selFile)
    elif item == "VVAa9n"   : self.VVAa9n(path, selFile)
    elif item == "copyFileOrDir"   : self.VVYkLu(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVYkLu(path, selFile, True)
    elif item == "VVsc1F"   : self.VVsc1F(path, selFile)
    elif item == "createNewFile"   : self.VVQwgB(path, True)
    elif item == "createNewDir"    : self.VVQwgB(path, False)
    elif item == "VVb8uV"   : self.VVb8uV(path)
    elif item == "VVINXL"    : self.VVINXL()
    else         : self.close()
 def VVINXL(self):
  selFile = self.VVw5fs()
  path  = self.VVmspx(selFile)
  if os.path.isfile(path):
   VV4umH = []
   category = self["myMenu"].VVSeZn(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VVzSEB(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : FFKnNz(self, selFile, path)
   elif category == "txt"         : FFuyab(self, path)
   elif category in ("tar", "zip")       : self.VVo4eB(path, selFile)
   elif category == "scr"         : self.VVCugp(path, selFile)
   elif category == "m3u"         : self.VVLlBR(path, selFile)
   elif category in ("ipk", "deb")       : self.VVxmx9(path, selFile)
   elif category == "mus"         : self.VVdGvO(path)
   elif category == "mov"         : self.VVdGvO(path)
   elif not FFWywO(path)        : FFuyab(self, path)
 def VVdGvO(self, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   FFj5dK(self, refCode)
  except:
   pass
 def VVA1Y1(self):
  path = self.VVmspx(self.VVw5fs())
  action = self.VVuHBU(path)
  if action == 1:
   self.VVZ0b5(path)
   FF0fiU(self, "Added", 500)
  elif action == -1:
   self.VVWe5o(path)
   FF0fiU(self, "Removed", 500)
  self.VVuHBU(path)
 def VVZ0b5(self, path):
  VVnxKJ = self.VVg7Db()
  if not VVnxKJ:
   VVnxKJ = []
  if len(VVnxKJ) >= self.MAX_BOOKMARKS:
   FFj9Oj(SELF, "Max bookmarks reached (max=%d)." % self.MAX_BOOKMARKS)
  elif not path in VVnxKJ:
   VVnxKJ = [path] + VVnxKJ
   self.VVH28I(VVnxKJ)
 def VVaaSb(self):
  VVnxKJ = self.VVg7Db()
  if VVnxKJ:
   newList = []
   for line in VVnxKJ:
    newList.append((line, line))
   VVE2sX  = ("Delete"  , self.VVeYcX )
   VVTaNU = ("Move Up"   , self.VVS3od )
   VVmews  = ("Move Down" , self.VVZbhW )
   self.bookmarkMenu = FFbvqQ(self, self.VVbDQK, title="Bookmarks", VVqVzN=newList, VVE2sX=VVE2sX, VVTaNU=VVTaNU, VVmews=VVmews)
 def VVeYcX(self, VVw5fsObj, path):
  if self.bookmarkMenu:
   VVnxKJ = self.VVWe5o(path)
   self.bookmarkMenu.VVtPsV(VVnxKJ)
 def VVS3od(self, VVw5fsObj, path):
  if self.bookmarkMenu:
   VVnxKJ = self.bookmarkMenu.VVWgEF(True)
   if VVnxKJ:
    self.VVH28I(VVnxKJ)
 def VVZbhW(self, VVw5fsObj, path):
  if self.bookmarkMenu:
   VVnxKJ = self.bookmarkMenu.VVWgEF(False)
   if VVnxKJ:
    self.VVH28I(VVnxKJ)
 def VVbDQK(self, folder=None):
  if folder:
   if not folder.endswith("/"):
    folder += "/"
   self["myMenu"].VVugxV(folder)
   self["myMenu"].moveToIndex(0)
  self.VVt0ko()
 def VVg7Db(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVUQ3G(self, path):
  VVnxKJ = self.VVg7Db()
  if VVnxKJ and path in VVnxKJ:
   return True
  else:
   return False
 def VVoB2t(self):
  if VVg7Db():
   return True
  else:
   return False
 def VVH28I(self, VVnxKJ):
  line = ",".join(VVnxKJ)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVWe5o(self, path):
  VVnxKJ = self.VVg7Db()
  if VVnxKJ:
   while path in VVnxKJ:
    VVnxKJ.remove(path)
   self.VVH28I(VVnxKJ)
   return VVnxKJ
 def VVb8uV(self, path):
  if not os.path.isdir(path):
   path = FFgmeM(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VVzSEB(self, selFile, VVG82G, command):
  FFi0Lh(self, boundFunction(FFFM6I, self, command, VVoAx2=self.VVwwya), "%s\n\n%s" % (VVG82G, selFile))
 def VVrjpQ(self, path, calledFromMenu):
  destPath = self.VVrYFR(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVqVzN = []
  if calledFromMenu:
   VVqVzN.append(VVPkfI)
   color = VVepFH
  else:
   color = ""
  VVqVzN.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVqVzN.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVqVzN.append((color + "Extract Here"            , "extract_here"  ))
  if VV4dZ1 and path.endswith(".tar.gz"):
   VVqVzN.append(VVPkfI)
   VVqVzN.append((color + 'Convert to ".ipk" Package' , "VVuM3D"  ))
   VVqVzN.append((color + 'Convert to ".deb" Package' , "VVd6l7"  ))
  return VVqVzN
 def VVo4eB(self, path, selFile):
  FFbvqQ(self, boundFunction(self.VVIaQY, path, selFile), title="Tar File Options", VVqVzN=self.VVrjpQ(path, False))
 def VVIaQY(self, path, selFile, item=None):
  if item is not None:
   parent  = FFgmeM(path, False)
   destPath = self.VVrYFR(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVfebv
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += "echo '';"
     cmd += "unzip -l '%s';" % path
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVfebv, VVfebv)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFSs3o(self, cmd)
   elif path.endswith(".zip"):
    self.VVjhDG(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFhmFU("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVzSEB(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVzSEB(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFgmeM(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVzSEB(selFile, "Extract Here ?"      , cmd)
   elif item == "VVuM3D" : self.VVuM3D(path)
   elif item == "VVd6l7" : self.VVd6l7(path)
 def VVrYFR(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVjhDG(self, item, path, parent, destPath, VVG82G):
  FFi0Lh(self, boundFunction(self.VVgM9x, item, path, parent, destPath), VVG82G)
 def VVgM9x(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVfebv
  cmd  = FFIEas("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFDI4H(destPath, VVul8x))
  cmd +=   sep
  cmd += "fi;"
  FFrPjR(self, cmd, VVoAx2=self.VVwwya)
 def VVXhV2(self, addSep=False):
  VVqVzN = []
  if addSep:
   VVqVzN.append(VVPkfI)
  VVqVzN.append((VVepFH + "View Script File"  , "script_View"  ))
  VVqVzN.append((VVepFH + "Execute Script File" , "script_Execute" ))
  VVqVzN.append((VVepFH + "Edit"     , "script_Edit" ))
  return VVqVzN
 def VVCugp(self, path, selFile):
  FFbvqQ(self, boundFunction(self.VVu3w0, path, selFile), title="Script File Options", VVqVzN=self.VVXhV2())
 def VVu3w0(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFuyab(self, path)
   elif item == "script_Execute" : self.VVzSEB(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCOrgc(self, path)
 def VVwhBO(self, addSep=False):
  VVqVzN = []
  if addSep:
   VVqVzN.append(VVPkfI)
  VVqVzN.append((VVepFH + "View"      , "m3u_View" ))
  VVqVzN.append((VVepFH + "Edit"      , "m3u_Edit" ))
  VVqVzN.append((VVepFH + "Convert to IPTV Bouquet" , "m3u_Convert" ))
  return VVqVzN
 def VVLlBR(self, path, selFile):
  FFbvqQ(self, boundFunction(self.VVzmDiItem_m3u, path, selFile), title="M3U File Options", VVqVzN=self.VVwhBO())
 def VVzmDiItem_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_View"  : FFuyab(self, path)
   elif item == "m3u_Edit"  : CCOrgc(self, path)
   elif item == "m3u_Convert" : CC2RcG.VV020V(self, path, False)
 def VVSFUk(self, path, selFile, newChmod):
  FFi0Lh(self, boundFunction(self.VVDUxL, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVDUxL(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVbxGJ)
  result = FFedlY(cmd)
  if result == "Successful" : FFhXFJ(self, result)
  else      : FFj9Oj(self, result)
 def VVUkXa(self, path, selFile):
  parent = FFgmeM(path, False)
  self.session.openWithCallback(self.VV7Gi1, boundFunction(CC1oiB, mode=CC1oiB.BROWSER_MODE_DIR_PICKER, VVcSFS=parent, VVSGYc="Create Symlink here"))
 def VV7Gi1(self, newPath):
  if len(newPath) > 0:
   target = self.VVmspx(self.VVw5fs())
   target = FFdjQ5(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FFRJ2W(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFj9Oj(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFi0Lh(self, boundFunction(self.VVf8s4, target, link), "Create Soft Link ?\n\n%s" % txt, VVEE7G=True)
 def VVf8s4(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVbxGJ)
  result = FFedlY(cmd)
  if result == "Successful" : FFhXFJ(self, result)
  else      : FFj9Oj(self, result)
 def VVAa9n(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFxR0u(self, boundFunction(self.VV9eaC, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VV9eaC(self, path, selFile, VVNYr8):
  if VVNYr8:
   parent = FFgmeM(path, True)
   if os.path.isdir(path):
    path = FFdjQ5(path)
   newName = parent + VVNYr8
   cmd = "mv '%s' '%s' %s" % (path, newName, VVbxGJ)
   if VVNYr8:
    if selFile != VVNYr8:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFi0Lh(self, boundFunction(self.VV9rCj, cmd), message, title="Rename file?")
    else:
     FFj9Oj(self, "Cannot use same name!", title="Rename")
 def VV9rCj(self, cmd):
  result = FFedlY(cmd)
  if "Fail" in result:
   FFj9Oj(self, result)
  self.VVwwya()
 def VVYkLu(self, path, selFile, isMove):
  if isMove : VVSGYc = "Move to here"
  else  : VVSGYc = "Copy to here"
  parent = FFgmeM(path, False)
  self.session.openWithCallback(boundFunction(self.VVwWeB, isMove, path, selFile)
         , boundFunction(CC1oiB, mode=CC1oiB.BROWSER_MODE_DIR_PICKER, VVcSFS=parent, VVSGYc=VVSGYc))
 def VVwWeB(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFdjQ5(path)
   newPath = FFRJ2W(newPath)
   dest = newPath + lastPart
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFi0Lh(self, boundFunction(FFpBIq, self, cmd, VVoAx2=self.VVwwya), txt, VVEE7G=True)
   else:
    FFj9Oj(self, "Cannot %s to same directory !" % action.lower())
 def VVsc1F(self, path, fileName):
  path = FFdjQ5(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFi0Lh(self, boundFunction(self.VVmjHG, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVmjHG(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("rm %s '%s'" % (opt, path))
  self.VVwwya()
 def VVFYRK(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVSc6q and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVQwgB(self, path, isFile):
  dirName = FFRJ2W(os.path.dirname(path))
  if isFile : objName, VVNYr8 = "File"  , self.edited_newFile
  else  : objName, VVNYr8 = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFxR0u(self, boundFunction(self.VVmGJk, dirName, isFile, title), title=title, defaultText=VVNYr8, message="Enter %s Name:" % objName)
 def VVmGJk(self, dirName, isFile, title, VVNYr8):
  if VVNYr8:
   if isFile : self.edited_newFile = VVNYr8
   else  : self.edited_newDir  = VVNYr8
   path = dirName + VVNYr8
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVbxGJ)
    else  : cmd = "mkdir '%s' %s" % (path, VVbxGJ)
    result = FFedlY(cmd)
    if "Fail" in result:
     FFj9Oj(self, result)
    self.VVwwya()
   else:
    FFj9Oj(self, "Name already exists !\n\n%s" % path, title)
 def VVxmx9(self, path, selFile):
  VVqVzN = []
  VVqVzN.append(("List Package Files"          , "VV9iug"     ))
  VVqVzN.append(("Package Information"          , "VVLgVQ"     ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Install Package"           , "VVjVHE_CheckVersion" ))
  VVqVzN.append(("Install Package (force reinstall)"      , "VVjVHE_ForceReinstall" ))
  VVqVzN.append(("Install Package (force downgrade)"      , "VVjVHE_ForceDowngrade" ))
  VVqVzN.append(("Install Package (ignore failed dependencies)"    , "VVjVHE_IgnoreDepends" ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Remove Related Package"         , "VVqssO_ExistingPackage" ))
  VVqVzN.append(("Remove Related Package (force remove)"     , "VVqssO_ForceRemove"  ))
  VVqVzN.append(("Remove Related Package (ignore failed dependencies)"  , "VVqssO_IgnoreDepends" ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("Extract Files"           , "VVSxR6"     ))
  VVqVzN.append(("Unbuild Package"           , "VVXOxh"     ))
  FFbvqQ(self, boundFunction(self.VV0RGd, path, selFile), VVqVzN=VVqVzN)
 def VV0RGd(self, path, selFile, item=None):
  if item is not None:
   if   item == "VV9iug"      : self.VV9iug(path, selFile)
   elif item == "VVLgVQ"      : self.VVLgVQ(path)
   elif item == "VVjVHE_CheckVersion"  : self.VVjVHE(path, selFile, VVEmKG     )
   elif item == "VVjVHE_ForceReinstall" : self.VVjVHE(path, selFile, VVxMeg )
   elif item == "VVjVHE_ForceDowngrade" : self.VVjVHE(path, selFile, VVveCC )
   elif item == "VVjVHE_IgnoreDepends" : self.VVjVHE(path, selFile, VVEjfp )
   elif item == "VVqssO_ExistingPackage" : self.VVqssO(path, selFile, VVLc03     )
   elif item == "VVqssO_ForceRemove"  : self.VVqssO(path, selFile, VVxKpM  )
   elif item == "VVqssO_IgnoreDepends"  : self.VVqssO(path, selFile, VVHZM0 )
   elif item == "VVSxR6"     : self.VVSxR6(path, selFile)
   elif item == "VVXOxh"     : self.VVXOxh(path, selFile)
   else           : self.close()
 def VV9iug(self, path, selFile):
  if FFyoqC("ar") : cmd = "allOK='1';"
  else    : cmd  = FFwjGA()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVfebv, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVfebv, VVfebv)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFdjGT(self, cmd, VVoAx2=self.VVwwya)
 def VVSxR6(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFgmeM(path, True) + selFile[:-4]
  cmd  =  FFwjGA()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFhmFU("mkdir '%s'" % dest) + ";"
  cmd +=    FFhmFU("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFDI4H(dest, VVul8x))
  cmd += "fi;"
  FFFM6I(self, cmd, VVoAx2=self.VVwwya)
 def VVXOxh(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVXmtK = os.path.splitext(path)[0]
  else        : VVXmtK = path + "_"
  if path.endswith(".deb")   : VV93TB = "DEBIAN"
  else        : VV93TB = "CONTROL"
  cmd  = FFwjGA()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VVXmtK, FFfSWi())
  cmd += "  mkdir '%s';"    % VVXmtK
  cmd += "  CONTPATH='%s/%s';"  % (VVXmtK, VV93TB)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VVXmtK
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VVXmtK, VVXmtK)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VVXmtK
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VVXmtK, VVXmtK)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VVXmtK
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VVXmtK
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VVXmtK, FFDI4H(VVXmtK, VVul8x))
  cmd += "fi;"
  FFFM6I(self, cmd, VVoAx2=self.VVwwya)
 def VVLgVQ(self, path):
  listCmd  = FFjZGS(VVgzHK, "")
  infoCmd  = FFxt6o(VVuVVp , "")
  filesCmd = FFxt6o(VVbbcC, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFRlBl(VVESyM)
   notInst = "Package not installed."
   cmd  = FFcBuL("File Info", VVESyM)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFcBuL("System Info", VVESyM)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFDI4H(notInst, VVepFH))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFcBuL("Related Files", VVESyM)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFSs3o(self, cmd)
  else:
   FFhggE(self)
 def VVjVHE(self, path, selFile, cmdOpt):
  cmd = FFxt6o(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFi0Lh(self, boundFunction(FFFM6I, self, cmd, VVoAx2=FF0Wsq), "Install Package ?\n\n%s" % selFile)
  else:
   FFhggE(self)
 def VVqssO(self, path, selFile, cmdOpt):
  listCmd  = FFjZGS(VVgzHK, "")
  infoCmd  = FFxt6o(VVuVVp, "")
  instRemCmd = FFxt6o(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFDI4H(errTxt, VVepFH))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFDI4H(cannotTxt, VVepFH))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFDI4H(tryTxt, VVepFH))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFi0Lh(self, boundFunction(FFFM6I, self, cmd, VVoAx2=FF0Wsq), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFhggE(self)
 def VVDyoE(self, path):
  hostName = FFedlY("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVRN2Z(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVDyoE(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VVinUF(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVqVzN = []
  VVqVzN.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVqVzN.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVqVzN.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVqVzN.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVqVzN.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVqVzN.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVqVzN.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVqVzN.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVqVzN.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVqVzN.append(VVPkfI)
  VVqVzN.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVqVzN.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFbvqQ(self, boundFunction(self.VVTD8u, path), VVqVzN=VVqVzN)
 def VVTD8u(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVW4cq(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVW4cq(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVW4cq(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVW4cq(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVW4cq(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVW4cq(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVW4cq(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVW4cq(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVW4cq(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVW4cq(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVw56A(path, False)
   elif item == "convertDirToDeb"   : self.VVw56A(path, True)
   else         : self.close()
 def VVw56A(self, path, VV9ot9):
  self.session.openWithCallback(self.VVwwya, boundFunction(CCgJW5, path=path, VV9ot9=VV9ot9))
 def VVW4cq(self, path, fileExt, preserveDirStruct):
  parent  = FFgmeM(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFIEas("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFIEas("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFIEas("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVfebv
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFhmFU("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FFDI4H(resultFile, VVul8x))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FFDI4H(failed, VVUDh4))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFdjGT(self, cmd, VVoAx2=self.VVwwya)
 def VVeWPw(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFuyab(self, versionFile)
 def VVB9SJ(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVDyoE(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFj9Oj(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FF709T(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFgmeM(path, False)
  VVXmtK = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FFDI4H(errCmd, VVUDh4))
  installCmd = FFxt6o(VVEmKG , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VVXmtK, VVXmtK)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VVXmtK
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VVXmtK
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VVXmtK, VVXmtK)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFFM6I(self, cmd, VVoAx2=self.VVwwya)
 def VVuM3D(self, path):
  FFj9Oj(self, "Under Construction.")
 def VVd6l7(self, path):
  FFj9Oj(self, "Under Construction.")
class CCkQI5(MenuList):
 def __init__(self, VVu7i5=False, directory="/", VVIOg5=True, VVigGp=True, VVf3S1=True, VV9sSj=None, VVLqbQ=False, VVvFPV=False, VVc1h3=False, isTop=False, VVcM6i=None, VVnY5b=1000, VVzQkv=30, VVRsNa=30, VVjIhK="#00000000"):
  MenuList.__init__(self, list, VVu7i5, eListboxPythonMultiContent)
  self.VVIOg5  = VVIOg5
  self.VVigGp    = VVigGp
  self.VVf3S1  = VVf3S1
  self.VV9sSj  = VV9sSj
  self.VVLqbQ   = VVLqbQ
  self.VVvFPV   = VVvFPV or []
  self.VVc1h3   = VVc1h3 or []
  self.isTop     = isTop
  self.additional_extensions = VVcM6i
  self.VVnY5b    = VVnY5b
  self.VVzQkv    = VVzQkv
  self.VVRsNa    = VVRsNa
  self.pngBGColor    = FFcvvP(VVjIhK)
  self.EXTENSIONS    = self.VVY8Le()
  self.VVgANK   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVdm9k, self.VVzQkv))
  self.l.setItemHeight(self.VVRsNa)
  self.png_mem   = self.VVPg94("mem")
  self.png_usb   = self.VVPg94("usb")
  self.png_fil   = self.VVPg94("fil")
  self.png_dir   = self.VVPg94("dir")
  self.png_dirup   = self.VVPg94("dirup")
  self.png_srv   = self.VVPg94("srv")
  self.png_slwfil   = self.VVPg94("slwfil")
  self.png_slbfil   = self.VVPg94("slbfil")
  self.png_slwdir   = self.VVPg94("slwdir")
  self.VVcbfm()
  self.VVugxV(directory)
 def VVPg94(self, category):
  return LoadPixmap("%s%s.png" % (VVLdJi, category), getDesktop(0))
 def VVY8Le(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u"
  }
 def VVHC1v(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFdjQ5(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FF39Hq(" -> " , VVESyM) + FF39Hq(os.readlink(path), VVul8x)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVRsNa + 10, 0, self.VVnY5b, self.VVRsNa, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VV70jO: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVRsNa-4, self.VVRsNa-4, png, self.pngBGColor, self.pngBGColor, VV70jO))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVRsNa-4, self.VVRsNa-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VVSeZn(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVcbfm(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VV26o1(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVqNh0(self, file):
  if os.path.realpath(file) == file:
   return self.VV26o1(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VV26o1(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VV26o1(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVYujC(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVgANK.info(l[0][0]).getEvent(l[0][0])
 def VVTcwf(self):
  return self.list
 def VVdLtB(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVugxV(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVf3S1:
    self.current_mountpoint = self.VVqNh0(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVf3S1:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VVc1h3 and not self.VVdLtB(path, self.VVvFPV):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VVHC1v(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVLqbQ:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVgANK = eServiceCenter.getInstance()
   list = VVgANK.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVIOg5 and not self.isTop:
   if directory == self.current_mountpoint and self.VVf3S1:
    self.list.append(self.VVHC1v(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VVc1h3 and self.VV26o1(directory) in self.VVc1h3):
    self.list.append(self.VVHC1v(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VVIOg5:
   for x in directories:
    if not (self.VVc1h3 and self.VV26o1(x) in self.VVc1h3) and not self.VVdLtB(x, self.VVvFPV):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVHC1v(name = name, absolute = x, isDir = True, png = png))
  if self.VVigGp:
   for x in files:
    if self.VVLqbQ:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FF39Hq(" -> " , VVESyM) + FF39Hq(target, VVul8x)
       else:
        png = self.png_slbfil
        name += FF39Hq(" -> " , VVESyM) + FF39Hq(target, VVUDh4)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVSeZn(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVLdJi, category))
    if (self.VV9sSj is None) or iCompile(self.VV9sSj).search(path):
     self.list.append(self.VVHC1v(name = name, absolute = x , isDir = False, png = png))
  if self.VVf3S1 and len(self.list) == 0:
   self.list.append(self.VVHC1v(name = FF39Hq("No USB connected", VVvBji), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VVMouN(self):
  return self.current_directory
 def VVj4UA(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVugxV(self.getSelection()[0], select = self.current_directory)
 def VVjcLi(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVLyjn(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVRejM)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVRejM)
 def refresh(self):
  self.VVugxV(self.current_directory, self.VVjcLi())
 def VVRejM(self, action, device):
  self.VVcbfm()
  if self.current_directory is None:
   self.refresh()
class CCmaSB(ScrollLabel):
 def __init__(self, parentSELF, text="", VVq5Xi=True):
  ScrollLabel.__init__(self, text)
  self.VVq5Xi=VVq5Xi
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVexpu  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVzQkv    = None
  self.parentW    = None
  self.parentH    = None
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close   ,
   "cancel"  : parentSELF.close   ,
   "red"   : self.VVvfm1   ,
   "green"   : self.VVi3lh  ,
   "yellow"  : self.VVy5rM  ,
   "blue"   : self.VV4rTW  ,
   "up"   : self.pageUp    ,
   "down"   : self.pageDown    ,
   "left"   : self.pageUp    ,
   "right"   : self.pageDown    ,
   "pageUp"  : self.VVyeGs    ,
   "chanUp"  : self.VVyeGs    ,
   "pageDown"  : self.VVusRQ    ,
   "chanDown"  : self.VVusRQ
  }, -1)
 def VVOdAK(self, isResizable=True, VVdzWD=False, enableSave=False):
  if enableSave:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FFbkgB(self.parentSELF, True)
  self.isResizable = isResizable
  if VVdzWD:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVzQkv  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFUPS3(self, color)
 def FFUPS3Color(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVexpu - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVZ47a()
 def pageUp(self):
  if self.VVexpu > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVexpu > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVyeGs(self):
  self.setPos(0)
 def VVusRQ(self):
  self.setPos(self.VVexpu-self.pageHeight)
 def VVumXR(self):
  return self.VVexpu <= self.pageHeight or self.curPos == self.VVexpu - self.pageHeight
 def VVZ47a(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVexpu, 3))
   start = int((100 - vis) * self.curPos / (self.VVexpu - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVNp8T=VVfHMe):
  old_VVumXR = self.VVumXR()
  self.message = text
  if self.pageHeight:
   self.long_text.setText(str(text))
   self.VVexpu = self.long_text.calculateSize().height()
   if self.VVq5Xi and self.VVexpu > self.pageHeight:
    self.scrollbar.show()
    self.VVZ47a()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVexpu))
   if   VVNp8T == VVuJnR: self.setPos(0)
   elif VVNp8T == VVsLgX : self.VVusRQ()
   elif old_VVumXR    : self.VVusRQ()
 def appendText(self, text, VVNp8T=VVsLgX):
  self.setText(self.message + str(text), VVNp8T)
 def VVy5rM(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVeLPU(size)
 def VV4rTW(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVeLPU(size)
 def VVi3lh(self):
  self.VVeLPU(self.VVzQkv)
 def VVeLPU(self, VVzQkv):
  self.long_text.setFont(gFont(self.fontFamily, VVzQkv))
  self.setText(self.message, VVNp8T=VVfHMe)
  self.VVUAyE(calledFromFontSizer=True)
 def VVvfm1(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "Save to File"
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_Info_%s.txt" % (FFRJ2W(expPath), FFCy03())
    with open(outF, "w") as f:
     f.write(FFiZhB(self.message))
    FFhXFJ(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FFj9Oj(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVUAyE(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer:
   totalCR = self.message.count("\n")
   if totalCR < 20:
    txt = ""
    if not self.message.startswith("\n"): txt = "\n" + self.message
    if not self.message.endswith("\n") : txt += "\n"
    if txt and not len(txt) == len(self.message):
     self.setText(txt)
   elif totalCR < 30:
    self.setText(self.message.strip())
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVexpu
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
