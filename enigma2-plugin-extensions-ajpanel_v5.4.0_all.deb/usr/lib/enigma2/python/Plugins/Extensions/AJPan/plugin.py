import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, IGNORECASE
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime
from base64      import b64encode, b64decode
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT   as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = None
  build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVy0i9   = "v5.4.0"
VVNDDP    = "13-06-2022"
EASY_MODE    = 0
VVG9OS   = 0
VVi5k8   = 0
VVMMWP  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVpZJm  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVmnJB    = "/media/usb/"
VVwNbm    = "/usr/share/enigma2/picon/"
VVXF7n = "/etc/enigma2/blacklist"
VVYYh9   = "/etc/enigma2/"
VVLwsT  = "ajpanel_update_url"
VVlvoG   = "AJPan"
VVIhrd    = "AUTO FIND"
VVyLHd    = ""
VVs8av    = "Regular"
VVlhhY      = "-" * 80
VV1dpw    = ("-" * 100, )
VVCBxr    = ""
VVFyCE   = " && echo 'Successful' || echo 'Failed!'"
VVHHUQ    = []
VVzpvL  = "Cannot continue (No Enough Memory) !"
VVgFen  = False
VV5KEQ  = False
VVDsHP = False
VVXAn9     = 0
VVeULt    = 1
VVJ5AW    = 2
VVaU94   = 3
VV0fqG    = 4
VV3w8V    = 5
VVukgN = 6
VVDouV = 7
VVl5Hy  = 8
VVUtFT   = 9
VVcnnT   = 10
VVCObr   = 11
VVp0oQ  = 12
VVm2MP  = 13
VVXlNP    = 14
VVDZov   = 15
VVyrEB   = 16
VVRQc2    = 17
WINDOW_SUBTITLE    = 18
VVMKe8  = 19
VVdoHn   = 0
VVtYyU   = 1
VVHjEe   = 2
def FFCu92():
 fList = None
 try:
  from enigma import getFontFaces
  return set(getFontFaces())
 except:
  try:
   from skin import getFontFaces
   return set(getFontFaces())
  except:
   pass
 return [VVs8av]
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[ ("v", "Virtual Keyboard"), ("s", "System Default"), ("b", "Built-in") ])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[ ("off", "Disabled"), ("lok", "Long-OK"), ("lesc", "Long-Exit"), ("lred", "Long-Red") ])
CFG.epgLanguage     = ConfigSelection(default="off", choices=[ ("off", "Original"), ("en", "English"), ("ar", "Arabic") ])
CFG.forceUtf8Encoding   = ConfigYesNo(default=True)
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[ ("1", "1 (DVB Stream)"), ("4097", "4097 (servicemp3)"), ("5001", "5001 (GST Player)"), ("5002", "5002 (Ext-3 EPlayer)"), ("8192", "8192 (HDMI input)"), ("8193", "8193 (eServiceUri)") ])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsPath    = ConfigDirectory(default=VVIhrd, visible_width=51)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=51)
CFG.PIconsPath     = ConfigDirectory(default=VVwNbm, visible_width=51)
CFG.backupPath     = ConfigDirectory(default=VVmnJB, visible_width=51)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=51)
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
tmp = [("srt", "From SRT File"), ("#FFFFFF", "White"), ("#C0C0C0", "Silver"), ("#808080", "Gray"), ("#000000", "Black"), ("#FF0000", "Red"), ("#800000", "Maroon"), ("#FFFF00", "Yellow"), ("#808000", "Olive"), ("#00FF00", "Lime"), ("#008000", "Green"), ("#00FFFF", "Aqua"), ("#008080", "Teal"), ("#0000FF", "Blue"), ("#000080", "Navy"), ("#FF00FF", "Fuchsia"), ("#800080", "Purple")]
CFG.subtDelay     = ConfigSelection(default="0.0", choices=[ (str(x/10.0),  str(x/10.0)) for x in range(-600, 600, 5) ])
CFG.subtTextFg     = ConfigSelection(default="srt", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVs8av, choices=[ (x,  x) for x in FFCu92() ])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=80, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[ ("0", "Left"), ("1", "Center"), ("2", "Right") ])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=0, stepwidth=10, min=-140, max=140, wraparound=False)
del tmp
def FFMMnb():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVanUP  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVf9Un = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVanUP  : return 0
  elif VVf9Un : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVor0l = FFMMnb()
VVaVAY = VVQDXE = VVUq52 = VVpKeT = VVY5Zb = VVhTxz = VVx2Y8 = VVWvE3 = COLOR_CONS_BRIGHT_YELLOW = VVpg8I = VVXXzX = VVNLkI = VVjMps = ""
def FFcAPi()  : FFYmGo(FFUHMm())
def FFH29B()  : FFYmGo(FFc2tf())
def FFwQil(tDict): FFYmGo(iDumps(tDict, indent=4, sort_keys=True))
def FF1Xw4(*args): FF3hk2(True, False, *args)
def FFYmGo(*args) : FF3hk2(True , True , *args)
def FFP6RD(*args): FF3hk2(False, True , *args)
def FF3hk2(addSep=True, oneLine=True, *args):
 if VVG9OS:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if oneLine:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  else:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item:
      txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFSGXZ(txt, isAppend=True, ignoreErr=False):
 if VVG9OS:
  tm = FFc7lk()
  err = ""
  if not ignoreErr:
   err = FFc2tf()
  fileName = "/tmp/ajpanel_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFYmGo(err)
  FFYmGo("Output Log File : %s" % fileName)
def FFc2tf():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFc7lk()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except Exception as e:
  return "Cannot Trace !"
def FFUHMm():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVHHUQ = []
def FFbUXD(win):
 global VVHHUQ
 if not win in VVHHUQ:
  VVHHUQ.append(win)
def FFAu6q(*args):
 global VVHHUQ
 for win in VVHHUQ:
  try:
   win.close()
  except:
   pass
 VVHHUQ = []
def FFH7JP():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVVbjX = FFH7JP()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFdD8s()     : return PluginDescriptor(fnc=FFYCDt, where=[PluginDescriptor.WHERE_SESSIONSTART] , needsRestart=True   , description="AJPanel Startup")
def FFwLpq()      : return getDescriptor(FFjeLL   , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FF7Ia7()       : return getDescriptor(FF8UAh  , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFOEdS()   : return getDescriptor(FFRDPD , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFncIc(): return getDescriptor(FFEuqW , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal/Player"  , descr="Signal Monitor / Player")
def FF6SPj()  : return getDescriptor(FFEbQm  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV"     , descr="IPTV Menu")
def FFl91Z()     : return getDescriptor(FFRwEh , [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Info."    , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFwLpq() , FF7Ia7() , FFdD8s() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFOEdS())
  result.append(FFncIc())
  result.append(FF6SPj())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFl91Z())
 return result
def FFYCDt(reason, **kwargs):
 if reason == 0:
  FFKeKf()
  if "session" in kwargs:
   session = kwargs["session"]
   FFxkTA(session)
   CCeEiP(session)
  CCaMcm.VV3HAb()
def FF8UAh(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFjeLL, PLUGIN_NAME, 45)]
 else:
  return []
def FFjeLL(session, **kwargs):
 session.open(Main_Menu)
def FFRDPD(session, **kwargs):
 session.open(CCsPG3)
def FFEuqW(session, **kwargs):
 FF4nG4(session, isFromSession=True)
def FFEbQm(session, **kwargs):
 session.open(CCmV60)
def FFRwEh(session, **kwargs):
 session.open(CCipRP, fncMode=CCipRP.VVCIAD)
def FFpFFC():
 FFN8Ka(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFOEdS(), FFncIc(), FF6SPj() ])
 FFN8Ka(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFl91Z() ])
def FFN8Ka(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
VV3xF7 = None
def FFKeKf():
 try:
  global VV3xF7
  if VV3xF7 is None:
   VV3xF7    = ChannelContextMenu.__init__
  ChannelContextMenu.__init__   = FFpWAV
  ChannelContextMenu.FFf01q = FFf01q
 except:
  pass
def FFpWAV(SELF, session, csel):
 from Components.ChoiceList import ChoiceEntryComponent
 VV3xF7(SELF, session, csel)
 if CFG.showInChannelListMenu.getValue():
  title1 = PLUGIN_NAME + " - Find"
  title2 = PLUGIN_NAME + " - Channels Tools"
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title2 , boundFunction(SELF.FFf01q, title2, csel, isFind=False))))
  SELF["menu"].list.insert(0, ChoiceEntryComponent(key=" ", text=(title1 , boundFunction(SELF.FFf01q, title1, csel, isFind=True))))
def FFf01q(self, title, csel, isFind):
 refCode = servName = bouquetRoot = ""
 try:
  currSel  = csel.getCurrentSelection()
  bouquetRoot = csel.getRoot().toString()
  refCode  = currSel.toString()
  servName = FFquq9(refCode)
 except:
  pass
 self.session.open(boundFunction(CCkIH2, title=title, csel=csel, refCode=refCode, servName=servName, bouquetRoot=bouquetRoot, isFind=isFind))
 self.close()
def FFxkTA(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions['longOK']  = boundFunction(FFSwzo, session, "lok")
 hk.actions['longCancel'] = boundFunction(FFSwzo, session, "lesc")
 hk.actions['longRed']  = boundFunction(FFSwzo, session, "lred")
def FFSwzo(session, key):
 if CFG.hotkey_signal.getValue() == key:
  FF4nG4(session, isFromSession=True)
def FF9Cql(SELF, title="", addLabel=False, addScrollLabel=False, VVJ4VL=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFmdhR()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF["myInfoFrame"].hide()
 SELF["myInfoBody"].hide()
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCw6AU(SELF)
 if VVJ4VL:
  SELF["myMenu"] = MenuList(VVJ4VL)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : SELF.VVFd70        ,
   "cancel" : SELF.close        ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : SELF.close ,
   "cancel"  : SELF.close ,
   "red"   : SELF.close
  }, -1)
def FFYrbe(SELF, tableObj, colNum=0):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0"    : boundFunction(FFjxNp, SELF, "0") ,
  "1"    : boundFunction(FFjxNp, SELF, "1") ,
  "2"    : boundFunction(FFjxNp, SELF, "2") ,
  "3"    : boundFunction(FFjxNp, SELF, "3") ,
  "4"    : boundFunction(FFjxNp, SELF, "4") ,
  "5"    : boundFunction(FFjxNp, SELF, "5") ,
  "6"    : boundFunction(FFjxNp, SELF, "6") ,
  "7"    : boundFunction(FFjxNp, SELF, "7") ,
  "8"    : boundFunction(FFjxNp, SELF, "8") ,
  "9"    : boundFunction(FFjxNp, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=boundFunction(FFHTmy, SELF, tableObj, colNum))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFjxNp(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVjMps:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVjMps + SELF.keyPressed + VVQDXE)
    txt = VVQDXE + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFtMdo(SELF, txt)
def FFHTmy(SELF, tableObj, colNum):
 FFtMdo(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    item = tableObj.list[i][colNum + 1][7].strip()
    item = item.encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     SELF.VVSgIu(i)
     break
 except:
  pass
def FFTSK4(SELF, setMenuAction=True):
 if setMenuAction:
  global VVCBxr
  VVCBxr = SELF["myMenu"].l.getCurrentSelection()[0]
 return SELF["myMenu"].l.getCurrentSelection()[1]
def FFmdhR():
 return ("  %s" % VVCBxr)
def FFCpCt(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFWYHc(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFmdyN(color):
 return parseColor(color).argb()
def FFZkbe(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FF3luO(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFHpgH(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFOCvV(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVjMps)
 else:
  return ""
def FFAhCU(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, VVlhhY, word, VVlhhY, VVjMps)
 else : return "echo -e '%s\n--- %s\n%s';" % (VVlhhY, word, VVlhhY)
def FF2tuT(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVjMps
def FFv4kb(color):
 if color: return "echo -e '%s' %s;" % (VVlhhY, FFOCvV(VVlhhY, VVWvE3))
 else : return "echo -e '%s';" % VVlhhY
def FFZuRe(title, color):
 title = "%s\n%s\n%s\n" % (VVlhhY, title, VVlhhY)
 return FF2tuT(title, color)
def FFYI0q(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFGNTa(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFOFIS(callBackFunction):
 tCons = CCHJqS()
 tCons.ePopen("echo", boundFunction(FFQF2f, callBackFunction))
def FFQF2f(callBackFunction, result, retval):
 callBackFunction()
def FFobhC(SELF, fnc, title="Processing ...", clearMsg=True):
 FFtMdo(SELF, title)
 tCons = CCHJqS()
 tCons.ePopen("echo", boundFunction(FFlCJm, SELF, fnc, clearMsg))
def FFlCJm(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFtMdo(SELF)
def FFi677(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVzpvL
  else       : return ""
def FF5Oes(cmd):
 txt = FFi677(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFDup1(cmd):
 lines = FF5Oes(cmd)
 if lines: return lines[0]
 else : return ""
def FFiQcA(SELF, cmd):
 lines = FF5Oes(cmd)
 VVhCPI = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVhCPI.append((key, val))
  elif line:
   VVhCPI.append((line, ""))
 if VVhCPI:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFN0i6(SELF, None, header=header, VV1rg6=VVhCPI, VVDe98=widths, VVwZKv=28)
 else:
  FF4pyg(SELF, cmd)
def FF4pyg(    SELF, cmd, **kwargs): SELF.session.open(CCA5J7, VVAIfv=cmd, VVJIg6=True, VVFuWe=VVtYyU, **kwargs)
def FFtWHX(  SELF, cmd, **kwargs): SELF.session.open(CCA5J7, VVAIfv=cmd, **kwargs)
def FFa7xk(   SELF, cmd, **kwargs): SELF.session.open(CCA5J7, VVAIfv=cmd, VVotGp=True, VVn7rS=True, VVFuWe=VVtYyU, **kwargs)
def FFq1pL(  SELF, cmd, **kwargs): SELF.session.open(CCA5J7, VVAIfv=cmd, VVotGp=True, VVn7rS=True, VVFuWe=VVHjEe, **kwargs)
def FFKyuP(  SELF, cmd, **kwargs): SELF.session.open(CCA5J7, VVAIfv=cmd, VVin47=True , **kwargs)
def FFj9TT( SELF, cmd, **kwargs): SELF.session.open(CCA5J7, VVAIfv=cmd, VVyEiS=True   , **kwargs)
def FFgHOZ( SELF, cmd, **kwargs): SELF.session.open(CCA5J7, VVAIfv=cmd, VVBv1I=True  , **kwargs)
def FFps7R(cmd):
 return cmd + " > /dev/null 2>&1"
def FFp04w():
 return " > /dev/null 2>&1"
def FFosbb(cmd):
 if os.system("which %s > /dev/null 2>&1" % cmd) == 0: return True
 else            : return False
def FFebM5(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
def FF57GN():
 cmd = "if which opkg >/dev/null; then echo opkg; else if which ipkg >/dev/null; then echo ipkg; else if which dpkg >/dev/null; then echo dpkg; else echo ''; fi; fi; fi"
 return FFDup1(cmd)
VVOJRx     = 0
VVKtnX      = 1
VVi1qq   = 2
VVhPIi      = 3
VVv0Zt      = 4
VVorbi     = 5
VVSMBq     = 6
VVJUEs = 7
VV1Ulm = 8
VVptud = 9
VV24AE  = 10
VVXgHo     = 11
VVhvpp  = 12
VVzzTf  = 13
def FFgO5n(parmNum, grepTxt):
 if   parmNum == VVOJRx  : param = ["update"   , "dpkg update" ]
 elif parmNum == VVKtnX   : param = ["list"   , "apt list" ]
 elif parmNum == VVi1qq: param = ["list-installed" , "dpkg -l"  ]
 else         : param = []
 if param:
  pkg = FF57GN()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFj0t1(parmNum, package):
 if   parmNum == VVhPIi      : param = ["info"      , "apt show"         ]
 elif parmNum == VVv0Zt      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVorbi     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVSMBq     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVJUEs : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VV1Ulm : param = ["install --force-overwrite" , "dpkg -i --force-overwrite -y"    ]
 elif parmNum == VVptud : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VV24AE  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVXgHo     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVhvpp  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVzzTf  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FF57GN()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FF65DH():
 result = FFDup1("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e '\"ar\" command (v3.x) not found!';"
  installCmd = FFj0t1(VVSMBq , "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFps7R("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFps7R("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFOCvV(failed1, VVWvE3))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFOCvV(failed2, VVWvE3))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFOCvV(failed3, VVUq52))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFPsnd(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFj0t1(VVSMBq , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFps7R("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFOCvV(failed1, VVWvE3))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFOCvV(failed2, VVUq52))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFFIVQ(ip="1.1.1.1", timeout=1.0):
 from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
 try:
  setdefaulttimeout(timeout)
  socket(AF_INET, SOCK_STREAM).connect((ip, 53))
  return True
 except:
  pass
 if os.system(FFps7R('ping -W%d -q %s -c 1 | grep " 0%% packet"' % (timeout, ip))) == 0:
  return True
 return os.system(FFps7R("wget -q -T %d -t 1 --spider %s" % (timeout, ip))) == 0
def FFWaDF(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCaMcm.VVP16B()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 return txt
def FFHvYZ(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFWaDF(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFfN74(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFuS3Z(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFWaDF(path, maxSize=maxSize, encLst=encLst)
  if lines: FFzRpw(SELF, lines, title=title, VVFuWe=VVtYyU)
  else : FFY69f(SELF, path, title=title)
 else:
  FFhMRQ(SELF, path, title)
def FFf485(SELF, path, title):
 if fileExists(path):
  txt = FFWaDF(path)
  txt = txt.replace("#W#", VVjMps)
  txt = txt.replace("#Y#", COLOR_CONS_BRIGHT_YELLOW)
  txt = txt.replace("#G#", VVQDXE)
  txt = txt.replace("#C#", VVpg8I)
  txt = txt.replace("#P#", VVpKeT)
  FFzRpw(SELF, txt, title=title)
 else:
  FFhMRQ(SELF, path, title)
def FF9Lu1(path):
 rangeList = list(range(0x20, 0x100))
 with open(path, 'rb') as f:
  bytes = f.read(1024)
 textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
 return bool(bytes.translate(None, textchars))
def FFbJ0I(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFA44u(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FF5gdy(parent)
 else    : return FFaBTr(parent)
def FFuS3Z(path):
 try:
  return os.path.getsize(path)
 except:
  return -1
def FF5gdy(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFaBTr(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFQKXh():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVMMWP)
 paths.append(VVMMWP.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFbJ0I(ba)
 for p in list:
  p = ba + p + VVMMWP
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVlvoG, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVMMWP, VVlvoG , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VV3v04, VVqrRB = FFQKXh()
def FFV4Ub():
 def VVlovi(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 iPath = CFG.iptvHostsPath.getValue()
 if not iPath == VVIhrd and not pathExists(iPath):
  CFG.iptvHostsPath.setValue(VVIhrd)
  CFG.iptvHostsPath.save()
  oldIptvHostsPath = VVIhrd
 else:
  oldIptvHostsPath = ""
 oldMovieDownloadPath = VVlovi(CFG.MovieDownloadPath, CCiRRm.VV8UgT())
 VVOmN1   = VVlovi(CFG.backupPath, CCqqrI.VVdeeP())
 VV16sL   = VVlovi(CFG.downloadedPackagesPath, t)
 VVmfaV  = VVlovi(CFG.exportedTablesPath, t)
 VV9Fom  = VVlovi(CFG.exportedPIconsPath, t)
 VVLPM1   = VVlovi(CFG.packageOutputPath, t)
 global VVmnJB
 VVmnJB = FF5gdy(CFG.backupPath.getValue())
 if VVOmN1 or VVLPM1 or VV16sL or VVmfaV or VV9Fom or oldIptvHostsPath or oldMovieDownloadPath:
  configfile.save()
 return VVOmN1, VVLPM1, VV16sL, VVmfaV, VV9Fom, oldIptvHostsPath, oldMovieDownloadPath
def FFfoid(path):
 path = FFaBTr(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFsFpq(SELF, pathList, tarFileName, addTimeStamp=True):
 VV1rg6 = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VV1rg6.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VV1rg6.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VV1rg6.append(path)
 if not VV1rg6:
  FFBAp7(SELF, "Files not found!")
 elif not pathExists(VVmnJB):
  FFBAp7(SELF, "Path not found!\n\n%s" % VVmnJB)
 else:
  VV9Xey = FF5gdy(VVmnJB)
  tarFileName = "%s%s" % (VV9Xey, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFC5od())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VV1rg6:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % VVlhhY
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFOCvV(tarFileName, VVx2Y8))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFOCvV(failed, VVx2Y8))
  cmd += "fi;"
  cmd +=  sep
  FFtWHX(SELF, cmd)
def FFGuuf(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFDeL6(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFDeL6(SELF["keyInfo"], "info")
def FFDeL6(barObj, fName):
 path = "%s%s%s" % (VVqrRB, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FF7EuD(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   from Components.NimManager import nimmanager
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFAmCN(satNum)
  return satName
def FFAmCN(satNum):
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFQ6pE(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FF7EuD(val)
  else  : sat = FFAmCN(val)
 return sat
def FFEeIv(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FF7EuD(num)
 except:
  pass
 return sat
def FF9wEh(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFCcWd(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if isFromSession: service = SELF.nav.getCurrentService()
 else   : service = SELF.session.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFZXBZ(info, iServiceInformation.sServiceref)
   prov = FFZXBZ(info, iServiceInformation.sProvider)
   state = str(FFZXBZ(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFsGsn(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")):
      refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFF7xE(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFZXBZ(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFU1EP(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFquq9(refCode):
 info = FFPAAe(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFAL9w(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns
def FFgZun(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFPAAe(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVm0NB = eServiceCenter.getInstance()
  if VVm0NB:
   info = VVm0NB.info(service)
 return info
def FFPZFB(SELF, refCode, VVhM2K=True, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(refCode)
  FF2xwS(SELF, serviceRef, checkParentalControl, isFromSession, fromPrtalReplay)
  if VVhM2K:
   FF4nG4(SELF, isFromSession)
 try:
  VVw7XZ = InfoBar.instance
  if VVw7XZ:
   VV7u2w = VVw7XZ.servicelist
   if VV7u2w:
    servRef = eServiceReference(refCode)
    VV7u2w.saveChannel(servRef)
 except:
  pass
def FF2xwS(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPrtalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPrtalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCRIa4()
    if pr.VVAj2I(refCode, chName, decodedUrl, iptvRef):
     pr.VVTZVs(SELF, isFromSession)
def FFsGsn(refCode):
 if refCode:
  span = iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE)
  if span : return True
  else : return False
def FFvbGL(url): return FFbpLk(url) or FFRfoo(url)
def FFbpLk(url)  : return any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFRfoo(url)  : return any(x in url for x in ("/series/", "mode=series"))
def FFF7xE(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith("%3A"):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFxPTY(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFxPTY(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFrmgH(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFTa0V(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFQ0GA(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFPn96(txt):
 try:
  return FFTa0V(FFQ0GA(txt)) == txt
 except:
  return False
def FF4nG4(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: session.open(CC7tge, isFromExternal=isFromSession)
 else      : FFhFwI(session, reopen=True, isFromExternal=isFromSession)
def FFhFwI(session, reopen=False, isFromExternal=False):
 if reopen:
  try:
   session.openWithCallback(boundFunction(FFhFwI, session, isFromExternal=isFromExternal), boundFunction(CCIaJa, isFromExternal=isFromExternal))
  except:
   try:
    FFvX7c(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FF7mZV(refCode):
 tp = CCYelw()
 if tp.VV9B7N(refCode) : return True
 else        : return False
def FFNjm6(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     db.saveServicelist()
     db.reloadServicelist()
     db.reloadBouquets()
     return True
 return False
def FFWjYU():
 db = eDVBDB.getInstance()
 if db:
  db.reloadServicelist()
  db.reloadBouquets()
def FF1OCM():
 VVw7XZ = InfoBar.instance
 if VVw7XZ:
  VV7u2w = VVw7XZ.servicelist
  if VV7u2w:
   return VV7u2w.getBouquetList()
 return []
def FF5VPS():
 try:
  span = iSearch(r"BOUQUET\s+(.+)\s+ORDER", InfoBar.instance.servicelist.getRoot().toString(), IGNORECASE)
  if span:
   path = "/etc/enigma2/%s" % span.group(1).replace('"', "")
   if fileExists(path):
    return path
 except:
  pass
 return ""
def FFBFyz():
 path = FF5VPS()
 if path:
  txt = FFWaDF(path, maxSize=300)
  span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
  if span:
   return span.group(1).strip()
 return ""
def FFv9Xh(userBfile):
 txt = ""
 bFile = VVYYh9 + "bouquets.tv"
 line = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBfile
 if fileExists(bFile) and fileExists(VVYYh9 + userBfile):
  fTxt = FFWaDF(bFile)
  span = iSearch(line, fTxt, IGNORECASE)
  if span:
   return
  else:
   res = FFDup1('CC=$(tail -c 1 "%s"); if [ "$CC" != "" ]; then echo no; else echo yes; fi' % bFile)
   if res == "no":
    txt += "\n"
 else:
  txt += "#NAME User - Bouquets (TV)\n"
 txt += line + "\n"
 with open(bFile, "a") as f:
  f.write(txt)
def FFb3AA():
 return FFhmEb(InfoBar.instance.servicelist.getRoot())
def FFhmEb(root):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVm0NB = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVm0NB.info(service)
    lst.append((service.toString(), info.getName(service)))
 except:
  pass
 return lst
def FFZHPK():
 VVjaEE = {0x01:"TV",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Feed",0x81:"Feed",0x82:"TV",0x84:"Feed",0x95:"Feed",0x98:"Feed",0x9B:"Feed",0xAB:"Feed",0xB4:"Feed",0xB5:"Feed",0xC6:"Feed",0xFA:"Feed",0xFB:"Feed",0xFC:"Feed"}
 VV8Mu4 = list(VVjaEE)
 return VV8Mu4, VVjaEE
def FFVuPM():
 try:
  from Tools.Directories import resolveFilename, SCOPE_PLUGINS
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFcUCH(session, VVPQuE):
 VV7rIc, VVPpxa, VVv4P3, camCommand = FF6jk3()
 if VVPpxa:
  runLog = False
  if   VVPQuE == CCVI7f.VV7Z5t : runLog = True
  elif VVPQuE == CCVI7f.VVcKOa : runLog = True
  elif not VVv4P3          : FFvX7c(session, message="SoftCam not started yet!")
  elif fileExists(VVv4P3)        : runLog = True
  else             : FFvX7c(session, message="File not found !\n\n%s" % VVv4P3)
  if runLog:
   session.open(boundFunction(CCVI7f, VV7rIc=VV7rIc, VVPpxa=VVPpxa, VVv4P3=VVv4P3, VVPQuE=VVPQuE))
 else:
  FFvX7c(session, message="No active OSCam/NCam found !", title="Live Log")
def FF6jk3():
 VV7rIc = "/etc/tuxbox/config/"
 VVPpxa = None
 VVv4P3  = None
 camCommand = FFDup1("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
 if   "oscam" in camCommand : VVPpxa = "oscam"
 elif "ncam"  in camCommand : VVPpxa = "ncam"
 if VVPpxa:
  path = FFDup1(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
  path = FF5gdy(path)
  if pathExists(path):
   VV7rIc = path
  tFile = VV7rIc + VVPpxa + ".conf"
  tFile = FFDup1("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
  if fileExists(tFile):
   VVv4P3 = tFile
 return VV7rIc, VVPpxa, VVv4P3, camCommand
def FF78kj(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFqUqE():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFC5od():
 return FFqUqE().replace(" ", "_").replace("-", "").replace(":", "")
def FFi4q2(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFc7lk():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFSgzY(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCmV60.VVxXhs(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCmV60.VV21Ob_forBouquet(fName)
     phpFile = tmpDir + fName + ext
     os.system(FFps7R("mv -f '%s' '%s'" % (outFile, phpFile)))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFIeYG(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFOZ0S(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
VVtHxR = 0
def FFuGgT():
 global VVtHxR
 VVtHxR = iTime()
def FF0PoD():
 FFYmGo(">>>>>> Elapsed\t: {:.6f} seconds".format(iTime() - VVtHxR).rstrip("0").rstrip("."))
def FFSzHX(SELF, message, title=""):
 SELF.session.open(boundFunction(CCSeKr, title=title, message=message, VV1OEk=True))
def FFzRpw(SELF, message, title="", VVFuWe=VVtYyU, **kwargs):
 SELF.session.open(boundFunction(CCSeKr, title=title, message=message, VVFuWe=VVFuWe, **kwargs))
def FFBAp7(SELF, message, title="")  : FFvX7c(SELF.session, message, title)
def FFhMRQ(SELF, path, title="") : FFvX7c(SELF.session, "File not found !\n\n%s" % path, title)
def FFY69f(SELF, path, title="") : FFvX7c(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFhJ5k(SELF, title="")  : FFvX7c(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFvX7c(session, message, title="") : session.open(boundFunction(CCbAFE, title=title, message=message))
def FFIilI(SELF, VVS99s, title="", defaultText="", message="", isTrimEnds=True):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVS99s, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVS99s, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   SELF.session.openWithCallback(VVS99s, boundFunction(CCstQ0, title=title, message=message, VVVjkg=defaultText, isTrimEnds=isTrimEnds))
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFBAp7(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFJWhD(SELF, callBack_Yes, VVoqcK, callBack_No=None, title="", VVIDtV=False, VVxElG=True):
 SELF.session.openWithCallback(boundFunction(FFfVMP, callBack_Yes, callBack_No)
        , boundFunction(CCwb3a, title=title, VVoqcK=VVoqcK, VVxElG=VVxElG, VVIDtV=VVIDtV))
def FFfVMP(callBack_Yes, callBack_No, FFJWhDed):
 if FFJWhDed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFtMdo(SELF, message="", milliSeconds=0, isGrn=False):
 try:
  SELF["myInfoBody"].setText(str(message))
  if isGrn: color = "#00004040"
  else : color = "#00550000"
  FF3luO(SELF["myInfoBody"], color)
  if milliSeconds > 0:
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   FFmGE2(SELF, milliSeconds)
  else:
   if len(message) > 0:
    SELF["myInfoFrame"].show()
    SELF["myInfoBody"].show()
   else:
    SELF["myInfoFrame"].hide()
    SELF["myInfoBody"].hide()
 except:
  pass
def FFTKsv(SELF):
 try:
  if SELF["myInfoBody"] and SELF["myInfoBody"].visible:
   return True
 except:
  pass
 return False
VV9UOR = eTimer()
def FFmGE2(SELF, milliSeconds=1000):
 SELF.onClose.append(boundFunction(FFkvmr, SELF))
 fnc = boundFunction(FFkvmr, SELF)
 try:
  t = VV9UOR.timeout.connect(fnc)
 except:
  VV9UOR.callback.append(fnc)
 VV9UOR.start(milliSeconds, 1)
def FFkvmr(SELF):
 VV9UOR.stop()
 try:
  if SELF["myInfoFrame"] : SELF["myInfoFrame"].hide()
  if SELF["myInfoBody"] : SELF["myInfoBody"].hide()
 except:
  pass
def FFN0i6(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, boundFunction(CCt6LB, **kwargs))
  else   : win = SELF.session.open(boundFunction(CCt6LB, **kwargs))
  FFbUXD(win)
  return win
 except:
  return None
def FFdrYz(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, boundFunction(CC9g1v, **kwargs))
 FFbUXD(win)
 return win
def FFnMVC(SELF, **kwargs):
 SELF.session.open(CCipRP, **kwargs)
def FF4l2q(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   inst = SELF[name].instance
   inst.setBorderColor(parseColor("#000000"))
   inst.setBorderWidth(3)
   inst.setNoWrap(True)
  except:
   pass
def FFFCQO(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVs8av, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFImVi(SELF, menuObj=None):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFFCQO(SELF, menuObj)
 winW   = SELF.instance.size().width()
 winH   = SELF.instance.size().height()
 lineH   = menuObj.l.getItemSize().height()
 menuCurrentW = menuObj.instance.size().width()
 menuCurrentH = menuObj.instance.size().height()
 menuCorrectH = len(menuObj.list) * lineH
 diff   = menuCorrectH - menuCurrentH
 winNewH   = winH + diff
 if winNewH > winH:
  pos  = menuObj.getPosition()
  part = menuObj.instance.size().height() % lineH
  half = int(part / 2)
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH - part)))
  menuObj.instance.move(ePoint(pos[0], pos[1] + half))
 else:
  screenSize = getDesktop(0).size()
  menuObj.instance.resize(eSize(*(menuCurrentW, menuCurrentH + diff)))
  SELF.instance.resize(eSize(*(winW, winNewH)))
  SELF.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
  names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
  for name in names:
   try:
    obj = SELF[name]
    pos = obj.getPosition()
    obj.instance.move(ePoint(pos[0], pos[1] + diff))
   except:
    pass
 winSize  = SELF.instance.size()
 boxFSize = SELF["myInfoFrame"].instance.size()
 boxSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((winSize.width() - boxFSize.width()) // 2, (winSize.height() - boxFSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((winSize.width() - boxSize.width()) // 2, (winSize.height() - boxSize.height()) // 2))
def FFTeeG():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FF5pbP(VVwZKv):
 screenSize  = FFTeeG()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVwZKv)
 return bodyFontSize
def FFVZvQ(VVwZKv, extraSpace):
 font = gFont(VVs8av, VVwZKv)
 VVkqvP = fontRenderClass.getInstance().getLineHeight(font) or (VVwZKv * 1.25)
 return int(VVkqvP + VVkqvP * extraSpace)
def FFbmPq(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1):
 screenSize = FFTeeG()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVs8av, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFVZvQ(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0"   size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb" shadowColor="#000000" shadowOffset="-1,-1" %s />' % (width, titleH, titleColor, VVs8av, titleFontSize, alignLeftCenter)
 if winType == VVXAn9 or winType == VVeULt:
  if winType == VVeULt : menuName = "config"
  else      : menuName = "myMenu"
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, bodyW, bodyH, bodyColor, bodyLineH)
 elif winType == VVMKe8:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignLeftCenter)
 elif winType == WINDOW_SUBTITLE:
  lineH = int((height - 8) / 3.0)
  top = 2
  tmp += '<widget name="mySubtFr" position="0,0" size="%d,%d" zPosition="10" backgroundColor="#00FFFF00" />' % (width, height)
  for i in range(3):
   tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="11" foregroundColor="#ffffff" shadowColor="#555555" shadowOffset="-2,-2" backgroundColor="#ff000000" %s %s />' % (i, top + 2, width - 2, lineH - 2, bodyFontStr, alignCenter)
   top += lineH
 elif winType == VVXlNP:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(bodyW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = width - marginLeft - timeW
  b2Left3 = b2Left4 - marginLeft - timeW
  FFSzHXL = b2Left2 + timeW + marginLeft
  FFSzHXW = b2Left3 - marginLeft - FFSzHXL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, bodyW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06005555" />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, bodyW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s %s' % (bodyColor, bodyFontStr, alignCenter)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" />' % (name, b2Left1, b2Top, timeW, barH, param)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" />' % (name, b2Left2, b2Top, timeW, barH, param)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" />' % (name, FFSzHXL  , b2Top, FFSzHXW , barH, param)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" />' % (name, b2Left3, b2Top, timeW, barH, param)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" />' % (name, b2Left4, b2Top, timeW, barH, param)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (int(b3Top - marginTop / 2), width)
  color = ["#00FFFFFF", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((width - marginLeft * (Len + 1)) / Len)
  left = marginLeft
  for i in range(9):
   if   i == 0   : bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a004400"'
   elif i == Len - 1: bg = 'foregroundColor="#00FFFFFF" backgroundColor="#0a18188b"'
   else    : bg = 'foregroundColor="%s" transparent="1"' % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
 elif winType == VVDZov:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VV0fqG:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVJ5AW:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVaU94:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVs8av, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVs8av, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVcnnT:
  inpF = int(bodyFontSize * 1.3)
  inpH = int(inpF * 1.5)
  FFSzHXH = int(bodyH * 0.5)
  inpTop = bodyTop + FFSzHXH
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" %s foregroundColor="#FFFFFF" %s />'    % (marginLeft, bodyTop, bodyW, FFSzHXH, bodyColor, bodyFontStr , alignLeftCenter)
  tmp += '<widget name="myInput" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" font="%s;%d" foregroundColor="#ff8055" %s />' % (marginLeft, inpTop , bodyW, inpH, bodyColor, VVs8av, inpF , alignLeftCenter)
  mapF = int(inpF * 1.3)
  mapW = int(width / 2)
  mapH = int(mapF * 1.5)
  mapTop = height - barHeight - marginTop - mapH
  tmp += '<widget name="myKeyMap" position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#11550055" font="%s;%d" foregroundColor="#888888" %s />' % (marginLeft, mapTop, mapW, mapH, VVs8av, mapF, alignCenter)
 elif winType == VVCObr:
  names  = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"]
  cellW  = int(bodyW / 3)
  cellH  = int(bodyH / 4)
  cellLeft = marginLeft
  cellTop  = bodyTop
  ndx   = 0
  for row in range(4):
   for col in range(3):
    if names[ndx] in ["L", "R"] : keyColor = "#11666666"
    else      : keyColor = "#11ffffff"
    tmp += '<widget name="myRcu%s"  position="%d,%d" size="%d,%d" %s %s zPosition="1" backgroundColor="#05002222" foregroundColor="%s" />' % (names[ndx], cellLeft  , cellTop  , cellW-3  , cellH-3  , bodyFontStr, alignCenter, keyColor)
    tmp += '<widget name="myRcuF%s" position="%d,%d" size="%d,%d" %s %s zPosition="2" backgroundColor="#05550000" foregroundColor="#11ffff00" />' % (names[ndx], cellLeft+3, cellTop+3, bodyLineH, bodyLineH, bodyFontStr, alignCenter)
    ndx   += 1
    cellLeft += cellW
   cellLeft = marginLeft
   cellTop += cellH
 elif winType == VVp0oQ:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVs8av, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVyrEB:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVs8av, fontH, alignCenter)
 elif winType == VVm2MP:
  totRows  = 5
  totCols  = 7
  infT  = titleH + 2
  infH  = int(titleH * 1.8)
  boxT  = infT + infH + 2
  boxW  = int(width  / totCols)
  boxH  = int((height - barHeight - boxT) / totRows)
  picH  = int(boxH * 0.75)
  lblH  = int(boxH * 0.25) - 2
  lblT  = boxT + picH + 2
  lblFont  = int(lblH * 0.65)
  w1, w2 = int(width * 0.45), int(width * 0.55)
  h  = int(infH  * 0.3333)
  fnt  = int(h     * 0.7)
  s  = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="%s" font="%s;%d" %s />'
  y = infT + 1
  color = ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
  for i in range(3):
   tmp += s % (i  , 0   , y, w1, h , color[i]  , VVs8av, fnt, alignLeftCenter)
   tmp += s % (i+3, w1+1, y, w2, h , color[i+3], VVs8av, fnt, alignLeftCenter)
   y += h
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a5555" />'  % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  y = boxT + boxH
  for i in range(totRows - 1):
   tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
   y += boxH
  x = boxW
  h = height - barHeight - boxT
  for i in range(totCols - 1):
   tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
   x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaa00"/>' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myPicon%d%d"     position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, picH-2)
    tmp += '<widget name="myPiconLbl%d%d"  position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#00003333" font="%s;%d" %s />' % (row, col, boxL+gap1, lblT, boxW-gap, lblH-2, VVs8av, lblFont, alignCenter)
    boxL += boxW
   boxT += boxH
   lblT += boxH
 elif winType == VVRQc2:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VV3w8V:
  tmp += '<widget name="myPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (marginLeft, bodyTop, bodyW, bodyH)
 else:
  if   winType == VVDouV : align = alignLeftCenter
  elif winType == VVukgN : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVUtFT:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVs8av
  if usefixedFont and winType == VVukgN:
   fnt = "Fixed"
   if fnt in FFCu92():
    fontName = "Fixed"
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVwZKv = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVs8av, VVwZKv, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  VV5tqg = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVs8av, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], left, btnTop, btnW, btnH, VV5tqg[i], VVs8av, barFont, alignCenter)
   left += btnW + gap
 if winType == VVukgN:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  VV5tqg = [ "#119f1313", "#11005500", "#11a08000", "#1118188b"]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VV5tqg[i], VVs8av, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="13" />'        % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFbmPq(VVXAn9, 800, 850, 50, 50, 30, "#1a002244", "#10002233", 33, barHeight=40)
  self.session  = session
  self.VVNHth = ""
  self.themsList  = []
  VVJ4VL = []
  if VVi5k8:
   VVJ4VL.append(("-- MY TEST --"    , "myTest"   ))
  VVJ4VL.append(("  File Manager"     , "FileManager"  ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("  Services/Channels"    , "ChannelsTools" ))
  VVJ4VL.append(("  IPTV"       , "IptvTools"  ))
  VVJ4VL.append(("  PIcons"       , "PIconsTools"  ))
  VVJ4VL.append(("  SoftCam"      , "SoftCam"   ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("  Plugins"      , "PluginsTools" ))
  VVJ4VL.append(("  Terminal"      , "Terminal"  ))
  VVJ4VL.append(("  Backup & Restore"    , "BackupRestore" ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("  Date/Time"      , "Date_Time"  ))
  VVJ4VL.append(("  Check Internet Connection"  , "CheckInternet" ))
  self.totalItems = len(VVJ4VL)
  FF9Cql(self, VVJ4VL=VVJ4VL)
  FFCpCt(self["keyRed"] , "Exit")
  FFCpCt(self["keyGreen"] , "Settings")
  FFCpCt(self["keyYellow"], "Dev. Info.")
  FFCpCt(self["keyBlue"] , "About")
  self["myActionMap"].actions.update({
   "red"   : self.close        ,
   "green"   : self.VVpTo6       ,
   "yellow"  : self.VVMhdk       ,
   "blue"   : self.VVpQwV       ,
   "info"   : self.VVpQwV       ,
   "next"   : self.VVvGBv       ,
   "menu"   : self.VVFc78     ,
   "text"   : self.VVBxv9      ,
   "0"    : boundFunction(self.VVnc5g, 0) ,
   "1"    : boundFunction(self.VVz7D0, 1)   ,
   "2"    : boundFunction(self.VVz7D0, 2)   ,
   "3"    : boundFunction(self.VVz7D0, 3)   ,
   "4"    : boundFunction(self.VVz7D0, 4)   ,
   "5"    : boundFunction(self.VVz7D0, 5)   ,
   "6"    : boundFunction(self.VVz7D0, 6)   ,
   "7"    : boundFunction(self.VVz7D0, 7)   ,
   "8"    : boundFunction(self.VVz7D0, 8)   ,
   "9"    : boundFunction(self.VVz7D0, 9)
  })
  self.onShown.append(self.VVJGeB)
  self.onClose.append(self.onExit)
  global VVgFen, VV5KEQ, VVDsHP
  VVgFen = VV5KEQ = VVDsHP = False
 def VVFd70(self):
  item = FFTSK4(self)
  self.VVz7D0(item)
 def VVz7D0(self, item):
  if item is not None:
   if   item == "myTest"     : self.VVVHmu()
   elif item in ("FileManager"  , 1) : self.session.open(CCsPG3)
   elif item in ("ChannelsTools" , 2) : self.session.open(CCqgtV)
   elif item in ("IptvTools"  , 3) : self.session.open(CCmV60)
   elif item in ("PIconsTools"  , 4) : self.VVYXxA()
   elif item in ("SoftCam"   , 5) : self.session.open(CC1NrN)
   elif item in ("PluginsTools" , 6) : self.session.open(CCTQYU)
   elif item in ("Terminal"  , 7) : self.session.open(CCAoKc)
   elif item in ("BackupRestore" , 8) : self.session.open(CC7BTJ)
   elif item in ("Date_Time"  , 9) : self.session.open(CCzfDX)
   elif item in ("CheckInternet" , 10) : self.session.open(CCinGe)
   else         : self.close()
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FFYI0q(self["myMenu"])
  FFImVi(self)
  FF4l2q(self)
  title = "  %s - %s" % (PLUGIN_NAME, VVy0i9)
  self["myTitle"].setText(title)
  VVOmN1, VVLPM1, VV16sL, VVmfaV, VV9Fom, oldIptvHostsPath, oldMovieDownloadPath = FFV4Ub()
  self.VVyI4y()
  if VVOmN1 or VVLPM1 or VV16sL or VVmfaV or VV9Fom or oldIptvHostsPath or oldMovieDownloadPath:
   VV1j34 = lambda path, subj: "%s:\n%s\n\n" % (subj, FF2tuT(path, VVUq52)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VV1j34(oldIptvHostsPath  , "IPTV Hosts Files Path"   )
   txt += VV1j34(VVOmN1   , "Backup/Restore Path"    )
   txt += VV1j34(VVLPM1  , "Created Package Files (IPK/DEB)" )
   txt += VV1j34(VV16sL  , "Download Packages (from feeds)" )
   txt += VV1j34(VVmfaV , "Exported Tables"     )
   txt += VV1j34(VV9Fom , "Exported PIcons"     )
   txt += VV1j34(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFzRpw(self, txt, title="Settings Paths")
  if (EASY_MODE or VVG9OS or VVi5k8):
   FF3luO(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFtMdo(self, "Welcome", 300)
  FFOFIS(boundFunction(self.VV3yPB, title))
 def VV3yPB(self, title):
  if CFG.checkForUpdateAtStartup.getValue():
   url = CCqqrI.VVoe7c()
   if url:
    newWebVer = CCqqrI.VVDRHC(url)
    if newWebVer:
     self["myTitle"].setText(title + "  (%s available)" % newWebVer)
 def onExit(self):
  os.system(FFps7R("rm /tmp/ajpanel*"))
  global VVgFen, VV5KEQ, VVDsHP
  VVgFen = VV5KEQ = VVDsHP = False
 def VVnc5g(self, digit):
  self.VVNHth += str(digit)
  ln = len(self.VVNHth)
  global VVgFen, VVDsHP
  if ln == 4:
   if self.VVNHth == "0" * ln:
    VVgFen = True
    FF3luO(self["myTitle"], "#800080")
   else:
    self.VVNHth = "x"
  elif self.VVNHth == "0" * 8:
   VVDsHP = True
 def VVvGBv(self):
  self.VVNHth += ">"
  if self.VVNHth == "0" * 4 + ">" * 2:
   global VV5KEQ
   VV5KEQ = True
   FF3luO(self["myTitle"], "#dd5588")
 def VVBxv9(self):
  if self.VVNHth == "0" * 4:
   ok = False
   fnt = "ae_AlMateen.ttf"
   fontFile = "/usr/share/fonts/%s" % fnt
   if fileExists(fontFile):
    from enigma import addFont
    fontName = "AJPFont"
    try:
     addFont(fontFile, fontName, 100, True)
     ok = True
    except:
     try:
      addFont(fontFile, fontName, 100, True, 0)
      ok = True
     except:
      pass
   if ok: txt = 'Added Font: "%s"' % fnt
   else : txt = '"%s" Not Found' % fnt
   FFtMdo(self, txt, 2000, isGrn=ok)
 def VVYXxA(self):
  found = False
  pPath = CCYaR2.VVQI8K()
  if pathExists(pPath):
   for fName, fType in CCYaR2.VVNhPR(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCYaR2)
  else:
   VVJ4VL = []
   VVJ4VL.append(("PIcons Manager" , "CCYaR2" ))
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append(CCYaR2.VV7U1X())
   VVJ4VL.append(VV1dpw)
   VVJ4VL += CCYaR2.VV3ruH()
   FFdrYz(self, self.VVyXmJ, VVJ4VL=VVJ4VL)
 def VVyXmJ(self, item=None):
  if item:
   if   item == "CCYaR2"   : self.session.open(CCYaR2)
   elif item == "VV8BHx"  : CCYaR2.VV8BHx(self)
   elif item == "VVD7m5"  : CCYaR2.VVD7m5(self)
   elif item == "findPiconBrokenSymLinks" : CCYaR2.VVkgX9(self, True)
   elif item == "FindAllBrokenSymLinks" : CCYaR2.VVkgX9(self, False)
 def VVpTo6(self):
  self.session.open(CCqqrI)
 def VVMhdk(self):
  self.session.open(CCKvqx)
 def VVpQwV(self):
  changeLogFile = VVqrRB + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FFHvYZ(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FF2tuT("\n%s\n%s\n%s" % (VVlhhY, line, VVlhhY), VVWvE3, VVjMps)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FF2tuT(line, VVQDXE, VVjMps)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFzRpw(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVy0i9, PLUGIN_DESCRIPTION), VVwZKv=26)
 def VVFc78(self):
  VVJ4VL = []
  VVJ4VL.append(("Title Colors"   , "title" ))
  VVJ4VL.append(("Menu Area Colors"  , "body" ))
  VVJ4VL.append(("Menu Pointer Colors" , "cursor" ))
  VVJ4VL.append(("Bottom Bar Colors" , "bar"  ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Reset Colors"   , "reset" ))
  title = "Main Menu Colors"
  FFdrYz(self, boundFunction(self.VVR68L, title), VVJ4VL=VVJ4VL, width=500, title=title)
 def VVR68L(self, title, item=None):
  if item:
   if item == "reset":
    FFJWhD(self, self.VVHrPg, "Reset to default colors ?", title=title)
   else:
    tDict = self.VVgrpS()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(boundFunction(self.VVZC1N, tDict, item), CC3kG9, defFG=fg, defBG=bg)
 def VVU1hV(self):
  return VVmnJB + "ajpanel_colors"
 def VVgrpS(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVU1hV()
  if fileExists(p):
   txt = FFWaDF(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVZC1N(self, tDict, item, fg, bg):
  if fg:
   self.VVx67G(item, fg)
   self.VVJsHl(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVB4ag(tDict)
 def VVB4ag(self, tDict):
   p = self.VVU1hV()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVx67G(self, item, fg):
  if   item == "title" : FFZkbe(self["myTitle"], fg)
  elif item == "body"  :
   FFZkbe(self["myMenu"], fg)
   FFZkbe(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   FF3luO(self["myBar"], fg)
   FFZkbe(self["keyRed"], fg)
   FFZkbe(self["keyGreen"], fg)
   FFZkbe(self["keyYellow"], fg)
   FFZkbe(self["keyBlue"], fg)
 def VVJsHl(self, item, bg):
  if   item == "title" : FF3luO(self["myTitle"], bg)
  elif item == "body"  :
   FF3luO(self["myMenu"], bg)
   FF3luO(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FF3luO(self["myBar"], bg)
 def VVHrPg(self):
  os.system(FFps7R("rm %s" % self.VVU1hV()))
  self.close()
 def VVyI4y(self):
  tDict = self.VVgrpS()
  self.VVJzQL(tDict, "title")
  self.VVJzQL(tDict, "body")
  self.VVJzQL(tDict, "cursor")
  self.VVJzQL(tDict, "bar")
 def VVJzQL(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVx67G(name, fg)
  if bg: self.VVJsHl(name, bg)
 def VVVHmu(self):
  pass
class CCaMcm():
 @staticmethod
 def VVP16B():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VV3HAb(isApply=False):
  global VVltWt, VVM64s
  VVltWt  = True
  VVM64s = CCaMcm.VVkZv1()
  CCaMcm.VVPDqQ()
 @staticmethod
 def VVPDqQ():
  if VVM64s:
   global VVltWt
   if CFG.forceUtf8Encoding.getValue():
    if CCaMcm.VVedzf() : VVltWt = True
    else        : VVltWt = False
   else:
    CCaMcm.VVP1Hj()
    VVltWt = False
 @staticmethod
 def VVkZv1(isApply=False):
  from sys import version_info
  if version_info[0] >= 3 and version_info[1] >= 10:
   path = "/etc/issue"
   if fileExists(path):
    path = "/etc/issue"
    if fileExists(path):
     txt = FFWaDF(path)
     span = iSearch(r"open.?vision", txt, IGNORECASE)
     if span:
      return True
  return False
 @staticmethod
 def VVedzf():
  import locale
  enc = locale.getdefaultlocale()[1]
  span = iSearch(r"UTF.?8", enc, IGNORECASE)
  if not span:
   try:
    import locale
    return locale.setlocale(locale.LC_ALL, "en_GB.UTF-8")
   except:
    pass
  return None
 @staticmethod
 def VVP1Hj():
  try:
   import locale
   return locale.setlocale(locale.LC_ALL, "")
  except:
   return None
 @staticmethod
 def VVUpQM(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFN0i6(SELF, None, VV1rg6=lst, VVwZKv=30, VVtgEG=True)
 @staticmethod
 def VVQpht(path, SELF=None):
  for enc in CCaMcm.VVP16B():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFBAp7(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVhF4K(SELF, path, cbFnc, defEnc="", pos=0):
  FFtMdo(SELF)
  lst = CCaMcm.VVXDo7(path)
  if lst:
   VVJ4VL = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if defEnc == enc:
     txt = FF2tuT(txt, VVx2Y8)
    VVJ4VL.append((txt, enc))
   win = FFdrYz(SELF, cbFnc, title="Select Encoding", VVJ4VL=VVJ4VL, width=900, height=500 if pos == 1 else 0)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FFtMdo(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVXDo7(path):
  encLst = []
  cPath = VVqrRB + "codecs"
  if fileExists(cPath):
   lines = FFHvYZ(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCaMcm.VVP16B())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    try:
     with ioOpen(path, "r", encoding=enc) as f:
      for line in f:
       pass
     lst.append((item[0], enc))
    except:
     pass
  return lst
class CCKvqx(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFbmPq(VVXAn9, 900, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVJ4VL = []
  VVJ4VL.append(("Settings File"        , "SettingsFile"   ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Box Info"          , "VVYsaj"    ))
  VVJ4VL.append(("Tuners Info"         , "VVaJ2M"   ))
  VVJ4VL.append(("Python Version"        , "VVrDIt"   ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Screen Size"         , "ScreenSize"    ))
  VVJ4VL.append(("Language/Locale"        , "Locale"     ))
  VVJ4VL.append(("Processor"         , "Processor"    ))
  VVJ4VL.append(("Operating System"        , "OperatingSystem"   ))
  VVJ4VL.append(("Drivers"          , "drivers"     ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("System Users"         , "SystemUsers"    ))
  VVJ4VL.append(("Logged-in Users"        , "LoggedInUsers"   ))
  VVJ4VL.append(("Uptime"          , "Uptime"     ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Host Name"         , "HostName"    ))
  VVJ4VL.append(("MAC Address"         , "MACAddress"    ))
  VVJ4VL.append(("Network Configuration"      , "NetworkConfiguration" ))
  VVJ4VL.append(("Network Status"        , "NetworkStatus"   ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Disk Usage"         , "VVWr2o"    ))
  VVJ4VL.append(("Mount Points"         , "MountPoints"    ))
  VVJ4VL.append(("File System Table (FSTAB)"     , "FileSystemTable"   ))
  VVJ4VL.append(("USB Devices"         , "USB_Devices"    ))
  VVJ4VL.append(("List Block-Devices"       , "listBlockDevices"  ))
  VVJ4VL.append(("Directory Size"        , "DirectorySize"   ))
  VVJ4VL.append(("Memory"          , "Memory"     ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Loaded Kernel Modules"      , "LoadedKernelModules"  ))
  VVJ4VL.append(("Running Processes"       , "RunningProcesses"  ))
  VVJ4VL.append(("Processes with open files"     , "ProcessesOpenFiles"  ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"  ))
  FF9Cql(self, VVJ4VL=VVJ4VL, title="Device Information")
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FFYI0q(self["myMenu"])
  FFImVi(self)
 def VVFd70(self):
  global VVCBxr
  VVCBxr = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"    : self.session.open(CCIuGB)
   elif item == "VVYsaj"    : self.VVYsaj()
   elif item == "VVaJ2M"   : self.VVaJ2M()
   elif item == "VVrDIt"   : self.VVrDIt()
   elif item == "ScreenSize"    : FFzRpw(self, "Width\t: %s\nHeight\t: %s" % (FFTeeG()[0], FFTeeG()[1]))
   elif item == "Locale"     : CCaMcm.VVUpQM(self)
   elif item == "Processor"    : self.VVbfSK()
   elif item == "OperatingSystem"   : FF4pyg(self, "uname -a"        )
   elif item == "drivers"     : self.VVkMdo()
   elif item == "SystemUsers"    : FF4pyg(self, "id"          )
   elif item == "LoggedInUsers"   : FF4pyg(self, "who -a"         )
   elif item == "Uptime"     : FF4pyg(self, "uptime"         )
   elif item == "HostName"     : FF4pyg(self, "hostname"        )
   elif item == "MACAddress"    : self.VV3fJs()
   elif item == "NetworkConfiguration"  : FF4pyg(self, "ifconfig %s %s" % (FFOCvV("HWaddr", VVNLkI), FFOCvV("addr:", VVWvE3)))
   elif item == "NetworkStatus"   : FF4pyg(self, "netstat -tulpn"       )
   elif item == "VVWr2o"    : self.VVWr2o()
   elif item == "MountPoints"    : FF4pyg(self, "mount %s" % (FFOCvV(" on ", VVWvE3)))
   elif item == "FileSystemTable"   : FF4pyg(self, "cat /etc/fstab"       )
   elif item == "USB_Devices"    : FF4pyg(self, "lsusb"         )
   elif item == "listBlockDevices"   : FF4pyg(self, "blkid"         )
   elif item == "DirectorySize"   : FF4pyg(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVDFjd="Reading size ...")
   elif item == "Memory"     : FF4pyg(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules"  : self.VVvGtL()
   elif item == "RunningProcesses"   : FF4pyg(self, "ps"          )
   elif item == "ProcessesOpenFiles"  : FF4pyg(self, "lsof"         )
   elif item == "DreamBoxBootloader"   : self.VVsYXt()
   else         : self.close()
 def VV3fJs(self):
  res = FFi677("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFzRpw(self, txt)
  else:
   FF4pyg(self, "ip link")
 def VV3YRv(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FF5Oes(cmd)
  return lines
 def VVqCzD(self, lines, headerRepl, widths, VV32KX):
  VVhCPI = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVhCPI.append(parts)
  if VVhCPI and len(header) == len(widths):
   VVhCPI.sort(key=lambda x: x[0].lower())
   FFN0i6(self, None, header=header, VV1rg6=VVhCPI, VV32KX=VV32KX, VVDe98=widths, VVwZKv=28, VVtgEG=True)
   return True
  else:
   return False
 def VVWr2o(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFi677(cmd)
  if not "invalid option" in txt:
   lines  = self.VV3YRv(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VV32KX = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVqCzD(lines, headerRepl, widths, VV32KX)
  else:
   cmd = "df -h"
   lines  = self.VV3YRv(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VV32KX = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVqCzD(lines, headerRepl, widths, VV32KX)
  if not allOK:
   lines = FF5Oes(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFaBTr(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVx2Y8:
     note = "\n%s" % FF2tuT("Green = Mounted Partitions", VVx2Y8)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVWvE3
     elif line.endswith(mountList) : color = VVx2Y8
     else       : color = VVQDXE
     txt += FF2tuT(line, color) + "\n"
    FFzRpw(self, txt + note)
   else:
    FFBAp7(self, "Not data from system !")
 def VVvGtL(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VV3YRv(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VV32KX = (LEFT , CENTER, LEFT )
  allOK = self.VVqCzD(lines, headerRepl, widths, VV32KX)
  if not allOK:
   FF4pyg(self, cmd)
 def VVkMdo(self):
  cmd = FFgO5n(VVi1qq, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FF4pyg(self, cmd)
  else : FFhJ5k(self)
 def VVbfSK(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FF4pyg(self, cmd)
 def VVsYXt(self):
  cmd = FFgO5n(VVKtnX, "| grep secondstage")
  if cmd : FF4pyg(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFhJ5k(self)
 def VVYsaj(self):
  c = VVx2Y8
  VV1rg6 = []
  VV1rg6.append((FF2tuT("Box Type"  , c), FF2tuT(self.VVd2Qm("boxtype").upper(), c)))
  VV1rg6.append((FF2tuT("Board Version", c), FF2tuT(self.VVd2Qm("board_revision") , c)))
  VV1rg6.append((FF2tuT("Chipset"  , c), FF2tuT(self.VVd2Qm("chipset")  , c)))
  VV1rg6.append((FF2tuT("S/N"   , c), FF2tuT(self.VVd2Qm("sn")    , c)))
  VV1rg6.append((FF2tuT("Version"  , c), FF2tuT(self.VVd2Qm("version")  , c)))
  VVkh77   = []
  VV3zr6 = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VV3zr6 = SystemInfo[key]
     else:
      VVkh77.append((FF2tuT(str(key), VVpg8I), FF2tuT(str(SystemInfo[key]), VVpg8I)))
  except:
   pass
  if VV3zr6:
   VVZGyJ = self.VVDxna(VV3zr6)
   if VVZGyJ:
    VVZGyJ.sort(key=lambda x: x[0].lower())
    VV1rg6 += VVZGyJ
  if VVkh77:
   VVkh77.sort(key=lambda x: x[0].lower())
   VV1rg6 += VVkh77
  if VV1rg6:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFN0i6(self, None, header=header, VV1rg6=VV1rg6, VVDe98=widths, VVwZKv=28, VVtgEG=True)
  else:
   FFzRpw(self, "Could not read info!")
 def VVd2Qm(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFHvYZ(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVDxna(self, mbDict):
  try:
   mbList = list(mbDict)
   VV1rg6 = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VV1rg6.append((FF2tuT(subject, VVWvE3), FF2tuT(value, VVWvE3)))
  except:
   pass
  return VV1rg6
 def VVaJ2M(self):
  txt = self.VVKvtO("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVKvtO("/proc/bus/nim_sockets")
  if not txt: txt = self.VVyIlD()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFzRpw(self, txt)
 def VVyIlD(self):
  txt = ""
  VV1j34 = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   from Components.NimManager import nimmanager
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VV1j34("Slot Name" , slot.getSlotName())
     txt += FF2tuT(slotName, VVWvE3)
     txt += VV1j34("Description"  , slot.getFullDescription())
     txt += VV1j34("Frontend ID"  , slot.frontend_id)
     txt += VV1j34("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVKvtO(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFHvYZ(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FF2tuT(line, VVWvE3)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVrDIt(self):
  from sys import version_info
  major   = version_info[0]
  minor   = version_info[1]
  micro   = version_info[2]
  releaselevel = version_info[3]
  serial   = version_info[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFzRpw(self, txt)
class CCIuGB(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFbmPq(VVXAn9, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVJ4VL = []
  VVJ4VL.append(("Settings (All)"   , "Settings_All"   ))
  VVJ4VL.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  if VV5KEQ:
   VVJ4VL.append(("Settings (FHDG-17)" , "Settings_FHDG_17"  ))
  VVJ4VL.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVJ4VL.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVJ4VL.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVJ4VL.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVJ4VL.append(("Settings (Skin)"   , "Settings_Skin"   ))
  FF9Cql(self, VVJ4VL=VVJ4VL)
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FFYI0q(self["myMenu"])
  FFImVi(self)
 def VVFd70(self):
  global VVCBxr
  VVCBxr = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat /etc/enigma2/settings"
   grep = " | grep "
   if   item == "Settings_All"    : FF4pyg(self, cmd                )
   elif item == "Settings_HotKeys"   : FF4pyg(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'" )
   elif item == "Settings_FHDG_17"   : FF4pyg(self, cmd + grep + "'config.plugins.setupGlass17.'"      )
   elif item == "Settings_Tuner_DiSEqC" : FF4pyg(self, cmd + grep + "'config.Nims.'"          )
   elif item == "Settings_Plugins"   : FF4pyg(self, cmd + grep + "'.plugins.\|config.TS'"        )
   elif item == "Settings_Usage"   : FF4pyg(self, cmd + grep + "'.usage.'"           )
   elif item == "Settings_TimeZone"  : FF4pyg(self, cmd + grep + "'.timezone.'"          )
   elif item == "Settings_Skin"   : FF4pyg(self, cmd + grep + "'.skin.'"           )
   else         : self.close()
class CC1NrN(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFbmPq(VVXAn9, 800, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VV7rIc, VVPpxa, VVv4P3, camCommand = FF6jk3()
  self.VVPpxa = VVPpxa
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  VVJ4VL = []
  VVJ4VL.append(("OSCam Files"        , "OSCamFiles"  ))
  VVJ4VL.append(("NCam Files"        , "NCamFiles"  ))
  VVJ4VL.append(("CCcam Files"        , "CCcamFiles"  ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("OSCam Readers Table (oscam.server)"  , "OSCamReaders" ))
  VVJ4VL.append(("NCam Readers Table (ncam.server)"   , "NSCamReaders" ))
  VVJ4VL.append(VV1dpw)
  if VVPpxa:
   if   "oscam" in VVPpxa : camName = "OSCam"
   elif "ncam"  in VVPpxa : camName = "NCam"
   VVJ4VL.append((camName + " Info."      , "camInfo"   ))
   VVJ4VL.append((camName + " Live Status"    , "camLiveStatus" ))
   VVJ4VL.append((camName + " Live Readers"    , "camLiveReaders" ))
   VVJ4VL.append((camName + " Live Log"     , "camLiveLog"  ))
  else:
   VVJ4VL.append(("Live Log (No active OSCam/NCam found)", "camLiveLog"  ))
  FF9Cql(self, VVJ4VL=VVJ4VL)
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FFYI0q(self["myMenu"])
  FFImVi(self)
 def VVFd70(self):
  global VVCBxr
  VVCBxr = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(boundFunction(CCCrm3, "oscam"))
   elif item == "NCamFiles"  : self.session.open(boundFunction(CCCrm3, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(boundFunction(CCCrm3, "cccam"))
   elif item == "OSCamReaders"  : self.VValaR("os")
   elif item == "NSCamReaders"  : self.VValaR("n")
   elif item == "camInfo"   : FFiQcA(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : FFcUCH(self.session, CCVI7f.VV7Z5t)
   elif item == "camLiveReaders" : FFcUCH(self.session, CCVI7f.VVcKOa)
   elif item == "camLiveLog"  : FFcUCH(self.session, CCVI7f.VV0gJY)
   else       : self.close()
 def VValaR(self, camPrefix):
  VVhCPI = self.VVhT5W(camPrefix)
  if VVhCPI:
   VVhCPI.sort(key=lambda x: int(x[0]))
   if self.VVPpxa and self.VVPpxa.startswith(camPrefix):
    VVw8s5 = ("Toggle State", self.VVDYbA, [camPrefix], "Changing State ...")
   else:
    VVw8s5 = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VV32KX  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFN0i6(self, None, header=header, VV1rg6=VVhCPI, VV32KX=VV32KX, VVDe98=widths, VVwZKv=26, VVw8s5=VVw8s5, VVB9Wc=True)
 def VVhT5W(self, camPrefix):
  readersFile = self.VV7rIc + camPrefix + "cam.server"
  VVhCPI = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFHvYZ(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVhCPI.append((str(len(VVhCPI) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVhCPI:
    FFBAp7(self, "No readers found !")
  else:
   FFhMRQ(self, readersFile)
  return VVhCPI
 def VVDYbA(self, VVByVq, camPrefix):
  confFile  = "%s%scam.conf" % (self.VV7rIc, camPrefix)
  readerState  = VVByVq.VVfRxf(1)
  readerLabel  = VVByVq.VVfRxf(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CC1NrN.VVyVg2(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVByVq.VVZQH0()
    FFBAp7(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVhCPI = self.VVhT5W(camPrefix)
   if VVhCPI:
    VVByVq.VVzmZc(VVhCPI)
 @staticmethod
 def VVyVg2(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFHvYZ(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFBAp7(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFBAp7(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFhMRQ(SELF, confFile)
   return None
  if not iRequest:
   FFBAp7(SELF, "Module not found : urllib/urllib2 !")
   return None
  try:
   from xml.etree import ElementTree
  except:
   FFBAp7(SELF, "Module not found : xml.etree !")
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), ElementTree
  except Exception as e:
   FFBAp7(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
class CCCrm3(Screen):
 def __init__(self, VVFq3F, session, args=0):
  self.skin, self.skinParam = FFbmPq(VVXAn9, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VV7rIc, VVPpxa, VVv4P3, camCommand = FF6jk3()
  if   VVFq3F == "ncam" : self.prefix = "n"
  elif VVFq3F == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVJ4VL = []
  if self.prefix == "":
   VVJ4VL.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVJ4VL.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVJ4VL.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVJ4VL.append(("constant.cw"         , "x_constant_cw" ))
   VVJ4VL.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVJ4VL.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVJ4VL.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVJ4VL.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVJ4VL.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVJ4VL.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVJ4VL.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVJ4VL.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVJ4VL.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVJ4VL.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVJ4VL.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FF9Cql(self, VVJ4VL=VVJ4VL)
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FFYI0q(self["myMenu"])
  FFImVi(self)
 def VVFd70(self):
  global VVCBxr
  VVCBxr = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFfN74(self, "/var/etc/CCcam.cfg"      )
   elif item == "c_ecm_info"  : FFfN74(self, "/tmp/ecm.info"       )
   elif item == "x_AutoRoll_Key" : FFfN74(self, self.VV7rIc + "AutoRoll.Key"   )
   elif item == "x_constant_cw" : FFfN74(self, self.VV7rIc + "constant.cw"   )
   elif item == "x_cam_ccache"  : self.VVMcIJ("cam.ccache"        )
   elif item == "x_cam_conf"  : self.VVMcIJ("cam.conf"        )
   elif item == "x_cam_dvbapi"  : self.VVMcIJ("cam.dvbapi"        )
   elif item == "x_cam_provid"  : self.VVMcIJ("cam.provid"        )
   elif item == "x_cam_server"  : self.VVMcIJ("cam.server"        )
   elif item == "x_cam_services" : self.VVMcIJ("cam.services"       )
   elif item == "x_cam_srvid2"  : self.VVMcIJ("cam.srvid2"        )
   elif item == "x_cam_user"  : self.VVMcIJ("cam.user"        )
   elif item == "x_VVlhhY"   : pass
   elif item == "x_SoftCam_Key" : self.VVw3Pa()
   elif item == "x_CCcam_cfg"  : FFfN74(self, self.VV7rIc + "CCcam.cfg"    )
   elif item == "x_VVlhhY"   : pass
   elif item == "x_cam_log"  : FFfN74(self, pathTmp + self.prefix + "cam.log"   )
   elif item == "x_cam_log_prev" : FFfN74(self, pathTmp + self.prefix + "cam.log-prev"  )
   elif item == "x_cam_pid"  : FFfN74(self, pathTmp + self.prefix + "cam.pid"   )
   else       : self.close()
 def VVMcIJ(self, fileName):
  FFfN74(self, self.VV7rIc + self.prefix + fileName)
 def VVw3Pa(self):
  path = self.VV7rIc + "SoftCam.Key"
  if fileExists(path) : FFfN74(self, path)
  else    : FFfN74(self, path.replace(".Key", ".key"))
class CCVI7f(Screen):
 VV7Z5t  = 0
 VVcKOa = 1
 VV0gJY = 2
 def __init__(self, session, VV7rIc="", VVPpxa="", VVv4P3="", VVPQuE=VV7Z5t):
  self.skin, self.skinParam = FFbmPq(VVukgN, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVv4P3   = VVv4P3
  self.VVPQuE  = VVPQuE
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VV7rIc + VVPpxa + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVPpxa : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VV7rIc, self.camPrefix)
  if self.VVPQuE == self.VV7Z5t:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVPQuE == self.VVcKOa:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FF9Cql(self, self.Title, addScrollLabel=True)
  FFCpCt(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVTrjo
  self.onShown.append(self.VVJGeB)
  self.onClose.append(self.onExit)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  self["myLabel"].VVmT9l(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FF4l2q(self)
  self.VVTrjo()
 def onExit(self):
  self.timer.stop()
 def VVJmqU(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV8Rzp)
  except:
   self.timer.callback.append(self.VV8Rzp)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFtMdo(self, "Started", 1000)
 def VVTm1c(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VV8Rzp)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFtMdo(self, "Stopped", 1000)
 def VVTrjo(self):
  if self.timerRunning:
   self.VVTm1c()
  else:
   self.VVJmqU()
   if self.VVPQuE == self.VV7Z5t or self.VVPQuE == self.VVcKOa:
    if self.VVPQuE == self.VV7Z5t : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CC1NrN.VVyVg2(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFOFIS(self.VVlHDx)
    else:
     self.close()
   else:
    self.VVrO77()
 def VV8Rzp(self):
  if self.timerRunning:
   if   self.VVPQuE == self.VV7Z5t : self.VVauQX()
   elif self.VVPQuE == self.VVcKOa : self.VVauQX()
   else            : self.VVrO77()
 def VVrO77(self):
  if fileExists(self.VVv4P3):
   fTime = FF78kj(os.path.getmtime(self.VVv4P3))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVt0E7(), VVFuWe=VVHjEe)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVv4P3)
 def VVlHDx(self):
  self.VVauQX()
 def VVauQX(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FF2tuT("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVpKeT))
   self.camWebIfErrorFound = True
   self.VVTm1c()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVPQuE == self.VV7Z5t : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line #+ "\n"
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FF2tuT("Error while parsing data elements !\n\nError = %s" % str(e), VVUq52)
   self.camWebIfErrorFound = True
   self.VVTm1c()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVDgKk(root)
  self["myLabel"].setText(txt, VVFuWe=VVHjEe)
  self["myBar"].setText("Last Update : %s" % FFqUqE())
 def VVDgKk(self, rootElement):
  def VV1j34(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVPQuE == self.VV7Z5t:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FF2tuT(status, VVx2Y8)
    else          : status = FF2tuT(status, VVUq52)
    txt += VVlhhY + "\n"
    txt += VV1j34("Name"  , name)
    txt += VV1j34("Description" , desc)
    txt += VV1j34("IP/Port"  , "%s : %s" % (ip, port))
    txt += VV1j34("Protocol" , protocol)
    txt += VV1j34("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FF2tuT("Yes", VVx2Y8)
    else    : enabTxt = FF2tuT("No", VVUq52)
    txt += VVlhhY + "\n"
    txt += VV1j34("Label"  , label)
    txt += VV1j34("Protocol" , protocol)
    txt += VV1j34("Enabled" , enabTxt)
  return txt
 def VVt0E7(self):
  wordsDict = self.VVysw4()
  color = [ VVWvE3, VVNLkI, VVx2Y8, VVUq52, VVpg8I, VVY5Zb]
  lines = FF5Oes("tail -n %d %s" % (100, self.VVv4P3))
  txt  = ""
  datePatt  = r"^[0-9]{4}(\-|/)[0-9]{2}(\-|/)[0-9]{2}"
  for line in lines:
   line = line.strip()
   if iMatch(datePatt, line):
    line = "\n" + VVpKeT + line[:19] + VVQDXE + line[19:]
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVjMps + line[ndx + 3:] + VVQDXE
    ndx = line.find(": found (")
    if ndx > -1:
     ndx1 = line.find(" ms)")
     if ndx1 > -1:
      line = line[:ndx + 8] + VVWvE3 + line[ndx + 8 : ndx1 + 4] + VVQDXE + line[ndx1 + 4:]
    for key in wordsDict:
     val  = wordsDict[key]
     line = line.replace(key, color[val] + key + VVQDXE)
   elif line.startswith("----") or ">>" in line:
    line = FF2tuT(line, VVWvE3)
   txt += line + "\n"
  return txt
 def VVysw4(self):
  wordsDict = { "(webif)"    : 0
     , "(anticasc)"   : 1
     , "(cache)"    : 1
     , "(cccam)"    : 1
     , "(chk)"    : 1
     , "(client)"   : 1
     , "(config)"   : 1
     , "(dvbapi)"   : 1
     , "(ecm)"    : 1
     , "(emm)"    : 1
     , "(emmcache)"   : 1
     , "(emu)"    : 1
     , "(main)"    : 1
     , "(net)"    : 1
     , "(newcamd)"   : 1
     , "(reader)"   : 1
     , "(stat)"    : 1
     , "OSCam"    : 2
     , "NCam"    : 2
     , "log switched"  : 2
     , ": found"    : 2
     , ": not found"   : 3
     , "failed"    : 3
     , "rejected group"  : 3
     , "usr/pwd invalid"  : 3
     , "timeout"    : 3
     , "no matching reader" : 3
     , "disconnected"  : 3
     }
  if fileExists(self.readersFile):
   lines = FFHvYZ(self.readersFile)
   if lines:
    for line in lines:
     if "=" in line:
      tLine = line.strip().lower()
      c = -1
      if   tLine.startswith("label")  : c = 4
      elif tLine.startswith("device") : c, line = 5, line.replace(",", ":")
      if c > -1:
       wordsDict.update( { line.split("=")[1].strip() : c } )
  return wordsDict
class CC7BTJ(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFbmPq(VVXAn9, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVJ4VL = []
  VVJ4VL.append(("Backup Channels"    , "VVr9b3"   ))
  VVJ4VL.append(("Restore Channels"    , "Restore_Channels"  ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Backup SoftCAM Files"   , "VVqzsX" ))
  VVJ4VL.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVJ4VL.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVJ4VL.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Backup Network Settings"  , "VVBYFM"   ))
  VVJ4VL.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VV5KEQ:
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append((VVpKeT + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME     , "VVGVtI"   ))
   VVJ4VL.append((VVx2Y8 + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVNDDP) , "createMyIpk"   ))
   VVJ4VL.append((VVx2Y8 + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVNDDP) , "createMyDeb"   ))
   VVJ4VL.append((VVpg8I + "Create %s TAR (Absolute Path)" % PLUGIN_NAME     , "createMyTar"   ))
   VVJ4VL.append((VVpg8I + "Decode %s Crash Report"   % PLUGIN_NAME     , "VVeFqf" ))
  FF9Cql(self, VVJ4VL=VVJ4VL)
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FFYI0q(self["myMenu"])
  FFImVi(self)
 def VVFd70(self):
  global VVCBxr
  VVCBxr = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVr9b3"    : self.VVr9b3()
   elif item == "Restore_Channels"    : self.VVUdTO("channels_backup*.tar.gz", self.VV9c1j)
   elif item == "VVqzsX"   : self.VVqzsX()
   elif item == "Restore_SoftCAM_Files"  : self.VVUdTO("softcam_backup*.tar.gz", self.VVbQg4)
   elif item == "Backup_TunerDiSEqC"   : self.VVl3gM("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVUdTO("tuner_backup*.backup", boundFunction(self.VVEAwp, "tuner"), True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVl3gM("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVUdTO("hotkey_*backup*.backup", boundFunction(self.VVEAwp, "misc"))
   elif item == "VVBYFM"    : self.VVBYFM()
   elif item == "Restore_Network"    : self.VVUdTO("network_backup*.tar.gz", self.VVRvg2)
   elif item == "VVGVtI"     : FFJWhD(self, boundFunction(FFobhC, self, boundFunction(CC7BTJ.VVGVtI, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVqcOq(False)
   elif item == "createMyDeb"     : self.VVqcOq(True)
   elif item == "createMyTar"     : self.VVlzm3()
   elif item == "VVeFqf"   : self.VVeFqf()
 @staticmethod
 def VVGVtI(SELF):
  OBF_Path = VV3v04 + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try:
    from .OBF import obf
   except:
    import obf
   reload(obf)
   txt, err = obf.fixCode(VV3v04, VVy0i9, VVNDDP)
   if err : FFBAp7(SELF, err)
   else : FFzRpw(SELF, txt)
  else:
   FFhMRQ(SELF, OBF_Path)
 def VVqcOq(self, VV2ASm):
  OBF_Path = VV3v04 + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFBAp7(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  os.system("rm -f %s__pycache__/ > /dev/null 2>&1" % VV3v04)
  os.system("mv -f %s %s" % (VV3v04 + "main.py"  , OBF_Path))
  os.system("mv -f %s %s" % (VV3v04 + "plugin.py" , OBF_Path))
  os.system("cp -f %s %s" % (OBF_Path + "*main_final.py" , VV3v04 + "plugin.py"))
  self.session.openWithCallback(self.VVqcOq1, boundFunction(CCV26k, path=VV3v04, VV2ASm=VV2ASm))
 def VVqcOq1(self):
  os.system("mv -f %s %s" % (VV3v04 + "OBF/main.py"  , VV3v04))
  os.system("mv -f %s %s" % (VV3v04 + "OBF/plugin.py" , VV3v04))
 def VVeFqf(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFBAp7(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFBAp7(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVPS6d("%s*.list" % path)
  if err:
   FFhMRQ(self, path + "*.list")
   return
  srcF, err = self.VVPS6d("%s*main_final.py" % path)
  if err:
   FFhMRQ(self, path + "*.final.py")
   return
  VV1rg6 = []
  for f in files:
   f = os.path.basename(f)
   VV1rg6.append((f, f))
  FFdrYz(self, boundFunction(self.VVCU2E, path, codF, srcF), VVJ4VL=VV1rg6)
 def VVCU2E(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFhMRQ(self, logF)
   else     : FFobhC(self, boundFunction(self.VVSA06, logF, codF, srcF))
 def VVSA06(self, logF, codF, srcF):
  lst  = []
  lines = FFHvYZ(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFBAp7(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVArq7(lst, logF, newLogF)
  totSrc  = self.VVArq7(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFzRpw(self, txt)
 def VVPS6d(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVArq7(self, lst, f1, f2):
  txt = FFWaDF(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVlzm3(self):
  VV1rg6 = []
  VV1rg6.append("%s%s" % (VV3v04, "*.py"))
  VV1rg6.append("%s%s" % (VV3v04, "*.png"))
  VV1rg6.append("%s%s" % (VV3v04, "*.xml"))
  VV1rg6.append("%s"  % (VVqrRB))
  FFsFpq(self, VV1rg6, "%s_%s" % (PLUGIN_NAME, VVy0i9), addTimeStamp=False)
 def VVr9b3(self):
  path1 = VVYYh9
  path2 = "/etc/tuxbox/"
  VV1rg6 = []
  VV1rg6.append("%s%s" % (path1, "*.tv"))
  VV1rg6.append("%s%s" % (path1, "*.radio"))
  VV1rg6.append("%s%s" % (path1, "*list"))
  VV1rg6.append("%s%s" % (path1, "lamedb*"))
  VV1rg6.append("%s%s" % (path2, "*.xml"))
  FFsFpq(self, VV1rg6, "channels_backup", addTimeStamp=True)
 def VVqzsX(self):
  VV1rg6 = []
  VV1rg6.append("/etc/tuxbox/config/")
  VV1rg6.append("/usr/keys/")
  VV1rg6.append("/usr/scam/")
  VV1rg6.append("/etc/CCcam.cfg")
  FFsFpq(self, VV1rg6, "softcam_backup", addTimeStamp=True)
 def VVBYFM(self):
  VV1rg6 = []
  VV1rg6.append("/etc/hostname")
  VV1rg6.append("/etc/default_gw")
  VV1rg6.append("/etc/resolv.conf")
  VV1rg6.append("/etc/wpa_supplicant*.conf")
  VV1rg6.append("/etc/network/interfaces")
  VV1rg6.append("/etc/enigma2/nameserversdns.conf")
  FFsFpq(self, VV1rg6, "network_backup", addTimeStamp=True)
 def VV9c1j(self, fileName=None):
  if fileName:
   FFJWhD(self, boundFunction(self.VVJRGL, fileName), "Overwrite current channels ?")
 def VVJRGL(self, fileName):
  path = "%s%s" % (VVmnJB, fileName)
  if fileExists(path):
   lamedbFile , disabledFile = CCqgtV.VVZ7vo()
   lamedb5File, diabled5File = CCqgtV.VVzYQO()
   cmd = ""
   cmd += FFps7R("rm /etc/enigma2/userbouquet*") + ";"
   cmd += FFps7R("rm -f %s %s" % (disabledFile, diabled5File)) + ";"
   cmd += "tar -xzf '%s' -C /" % path
   res = os.system(cmd)
   FFWjYU()
   if res == 0 : FFSzHX(self, "Channels Restored.")
   else  : FFBAp7(self, "Error while restoring:\n\n%s" % fileName)
  else:
   FFhMRQ(self, path)
 def VVbQg4(self, fileName=None):
  if fileName:
   FFJWhD(self, boundFunction(self.VVxRsI, fileName), "Overwrite SoftCAM files ?")
 def VVxRsI(self, fileName):
  fileName = "%s%s" % (VVmnJB, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % VVlhhY
   note = "You may need to restart your SoftCAM."
   FFq1pL(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFOCvV(note, VVWvE3), sep))
  else:
   FFhMRQ(self, fileName)
 def VVRvg2(self, fileName=None):
  if fileName:
   FFJWhD(self, boundFunction(self.VVRAxP, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVRAxP(self, fileName):
  fileName = "%s%s" % (VVmnJB, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFKyuP(self,  cmd)
  else:
   FFhMRQ(self, fileName)
 def VVUdTO(self, pattern, callBackFunction, isTuner=False):
  title = FFmdhR()
  if pathExists(VVmnJB):
   myFiles = iGlob("%s%s" % (VVmnJB, pattern))
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VV1rg6 = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VV1rg6.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if isTuner : VVfRF6 = ("Sat. List", self.VVLZtR)
    else  : VVfRF6 = None
    VVx8rq = ("Delete File", self.VVGuQm)
    FFdrYz(self, callBackFunction, title=title, VVJ4VL=VV1rg6, VVfRF6=VVfRF6, VVx8rq=VVx8rq)
   else:
    FFBAp7(self, "No files found in:\n\n%s" % VVmnJB, title)
  else:
   FFBAp7(self, "Path not found:\n\n%s" % VVmnJB, title)
 def VVGuQm(self, VVH9sbObj, path):
  FFJWhD(self, boundFunction(self.VVrljo, VVH9sbObj, path), "Delete this file ?\n\n%s" % path)
 def VVrljo(self, VVH9sbObj, path):
  path = VVmnJB + path
  os.system(FFps7R("rm -f '%s'" % path))
  if fileExists(path) : FFtMdo(VVH9sbObj, "Not deleted", 1000)
  else    : VVH9sbObj.VV1cyv()
 def VVl3gM(self, filePrefix, wordsFilter):
  settingFile = "/etc/enigma2/settings"
  tCons = CCHJqS()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), boundFunction(self.VVHd2S, filePrefix))
 def VVHd2S(self, filePrefix, result, retval):
  title = FFmdhR()
  if pathExists(VVmnJB):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFBAp7(self, "Cannot read settings file", title)
   else:
    fName = "%s%s_%s.backup" % (VVmnJB, filePrefix, FFC5od())
    try:
     VV1rg6 = str(result.strip()).split()
     if VV1rg6:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VV1rg6:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (VVlhhY, FF2tuT(fName, VVWvE3), VVlhhY)
       FFzRpw(self, txt, title=title, VVFuWe=VVHjEe)
      else:
       FFBAp7(self, "File creation failed!", title)
     else:
      FFBAp7(self, "Parameters not found in settings file.", title)
    except IOError as e:
     os.system(FFps7R("rm %s" % fName))
     FFBAp7(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     os.system(FFps7R("rm %s" % fName))
     FFBAp7(self, "Error while writing file.")
  else:
   FFBAp7(self, "Path not found:\n\n%s" % VVmnJB, title)
 def VVEAwp(self, mode, path=None):
  if path:
   path = "%s%s" % (VVmnJB, path)
   if fileExists(path):
    lines = FFHvYZ(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFJWhD(self, boundFunction(self.VV776B, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFY69f(self, path, title=FFmdhR())
   else:
    FFhMRQ(self, path)
 def VV776B(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  newList = list(set(newList))
  newList.sort()
  VVAIfv = []
  VVAIfv.append("echo -e 'Reading current settings ...'")
  VVAIfv.append("cat /etc/enigma2/settings | grep -v '" + grepFilter + "' > /tmp/settings_my_tmp.txt")
  settingsLines = "echo -e '"
  for line in newList:
   settingsLines += line
  settingsLines += "' >> /tmp/settings_my_tmp.txt"
  VVAIfv.append("echo -e 'Preparing new settings ...'")
  VVAIfv.append(settingsLines)
  VVAIfv.append("echo -e 'Applying new settings ...'")
  VVAIfv.append("mv /tmp/settings_my_tmp.txt /etc/enigma2/settings")
  FFgHOZ(self, VVAIfv)
 def VVLZtR(self, VVH9sbObj, path):
  if not path:
   return
  path = VVmnJB + path
  if not fileExists(path):
   FFhMRQ(self, path)
   return
  txt = FFWaDF(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   sep   = ""
   VV1rg6  = []
   for item in satList:
    VV1rg6.append("%s\t%s" % (item[0], FF7EuD(item[1])))
   FFzRpw(self, VV1rg6, title="  Satellites List")
  else:
   FFBAp7(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCTQYU(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFbmPq(VVXAn9, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  VVJ4VL = []
  VVJ4VL.append(("Plugins Browser List"       , "VVcHOk"   ))
  VVJ4VL.append(("Plugins Additional Menus"      , "pluginsMenus"    ))
  VVJ4VL.append(("Startup Plugins"        , "pluginsStartup"    ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Extensions and System Plugins"    , "pluginsDirList"    ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Download/Install Packages"     , "downloadInstallPackages"  ))
  VVJ4VL.append(("Remove Packages (show all)"     , "VVZ7p3sAll"   ))
  VVJ4VL.append(("Remove Packages (Plugins/SoftCAMs/Skins)"  , "removePluginSkinSoftCAM"  ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Update List of Available Packages"   , "VV59ZG"   ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Packaging Tool"        , "VVC9XT"    ))
  VVJ4VL.append(("Packages Feeds"        , "packagesFeeds"    ))
  FF9Cql(self, VVJ4VL=VVJ4VL)
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FFYI0q(self["myMenu"])
  FFImVi(self)
 def VVFd70(self):
  global VVCBxr
  VVCBxr = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVcHOk"   : self.VVcHOk()
   elif item == "pluginsMenus"     : self.VVGhpA(0)
   elif item == "pluginsStartup"    : self.VVGhpA(1)
   elif item == "pluginsDirList"    : self.VVDFRU()
   elif item == "downloadInstallPackages"  : FFobhC(self, boundFunction(self.VVQw2w, 0, ""))
   elif item == "VVZ7p3sAll"   : FFobhC(self, boundFunction(self.VVQw2w, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFobhC(self, boundFunction(self.VVQw2w, 2, "| grep -e skin -e enigma2-"))
   elif item == "VV59ZG"   : self.VV59ZG()
   elif item == "VVC9XT"    : self.VVC9XT()
   elif item == "packagesFeeds"    : self.VV2O9u()
   else          : self.close()
 def VVDFRU(self):
  extDirs  = FFbJ0I(VVMMWP)
  sysDirs  = FFbJ0I(VVpZJm)
  VV1rg6  = []
  for item in extDirs:
   if not "__pycache__" in item:
    VV1rg6.append((item, VVMMWP + item))
  for item in sysDirs:
   if not "__pycache__" in item:
    VV1rg6.append((item, VVpZJm + item))
  if VV1rg6:
   VV1rg6 = sorted(VV1rg6, key=lambda x: x[0].lower())
   VV3Y5Z = ("Package Info.", self.VVOgmF, [])
   header   = ("Plugin" ,"Path" )
   widths   = (25  , 75 )
   FFN0i6(self, None, header=header, VV1rg6=VV1rg6, VVDe98=widths, VVwZKv=28, VV3Y5Z=VV3Y5Z)
  else:
   FFBAp7(self, "Nothing found!")
 def VVOgmF(self, VVByVq, title, txt, colList):
  name = colList[0]
  path = colList[1]
  loc = ""
  if   path.startswith(VVMMWP) : loc = "extensions"
  elif path.startswith(VVpZJm) : loc = "systemplugins"
  if loc:
   package = "enigma2-plugin-%s-%s" % (loc, name.lower())
   self.VVVDSm(package)
  else:
   FFBAp7(self, "No info!")
 def VV2O9u(self):
  pkg = FF57GN()
  if pkg : FF4pyg(self, "ls -1 /var/lib/%s/lists" % pkg)
  else : FFhJ5k(self)
 def VVcHOk(self):
  pluginList = iPlugins.getPlugins(PluginDescriptor.WHERE_PLUGINMENU)
  def VV1j34(key, val):
   return key + "\t: " + str(val) + "\n"
  txt = ""
  c = 1
  for p in pluginList:
   try:
    txt += VVlhhY + "\n"
    txt += VV1j34("Number"   , str(c))
    txt += VV1j34("Name"   , FF2tuT(str(p.name), VVWvE3))
    txt += VV1j34("Path"  , p.path  )
    txt += VV1j34("Description" , p.description )
    txt += VV1j34("Icon"  , p.iconstr  )
    txt += VV1j34("Wakeup Fnc" , p.wakeupfnc )
    txt += VV1j34("NeedsRestart", p.needsRestart)
    txt += VV1j34("Internal" , p.internal )
    txt += VV1j34("Weight"  , p.weight  ) + "\n"
    c += 1
   except:
    pass
  if not txt:
   txt = "Could not find any plugin."
  FFzRpw(self, txt)
 def VVGhpA(self, typ):
  if typ == 0:
   title = "Plugins Menu Items"
   tit2  = "Menu Item"
   tDict = { PluginDescriptor.WHERE_PLUGINMENU: "Plugins Browser"
     , PluginDescriptor.WHERE_EXTENSIONSMENU: "Extensions Menu"
     , PluginDescriptor.WHERE_MAINMENU: "Main Menu"
     , PluginDescriptor.WHERE_MENU: "Menu"
     , PluginDescriptor.WHERE_EVENTINFO: "Events Info Menu"
     , PluginDescriptor.WHERE_MOVIELIST: "Movie List"
     , PluginDescriptor.WHERE_NETWORKSETUP: "Network Setup"
     , PluginDescriptor.WHERE_SOFTWAREMANAGER: "WHERE_SOFTWAREMANAGER"
     , PluginDescriptor.WHERE_AUDIOMENU: "Audio Menu"
     , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU : "Channel Context Menu"
     }
  else:
   title = "Startup Plugins"
   tit2  = "Starts as"
   tDict = { PluginDescriptor.WHERE_AUTOSTART: "Auto-Start" , PluginDescriptor.WHERE_SESSIONSTART: "Start" }
  VV1rg6 = []
  for key, val in tDict.items():
   pluginList = iPlugins.getPlugins(key)
   for p in pluginList:
    try:
     VV1rg6.append((p.path.split("/")[-1], str(p.name), val, p.description, p.path))
    except:
     pass
  if VV1rg6:
   VV1rg6.sort(key=lambda x: x[0].lower())
   header  = ("Plugin" , tit2 , "Where" , "Description" , "Path")
   widths  = (19  , 25 , 20  , 27   , 9  )
   FFN0i6(self, None, title=title, header=header, VV1rg6=VV1rg6, VVDe98=widths, VVwZKv=26)
  else:
   FFBAp7(self, "Nothing Found", title=title)
 def VV59ZG(self):
  cmd = FFgO5n(VVOJRx, "")
  if cmd : FFKyuP(self, cmd, checkNetAccess=True)
  else : FFhJ5k(self)
 def VVC9XT(self):
  pkg = FF57GN()
  if   pkg == "ipkg" : txt = "OE2.0 - IPKG"
  elif pkg == "opkg" : txt = "OE2.0 - OPKG"
  elif pkg == "dpkg" : txt = "OE2.5/2.6 - APT-DPKG"
  else    : txt = "No packaging tools found!"
  FFSzHX(self, txt)
 def VVQw2w(self, mode, grep, VVByVq=None, title=""):
  if   mode == 0: cmd = FFgO5n(VVKtnX    , grep)
  elif mode == 1: cmd = FFgO5n(VVi1qq , grep)
  elif mode == 2: cmd = FFgO5n(VVi1qq , grep)
  if not cmd:
   FFhJ5k(self)
   return
  VVhCPI = FF5Oes(cmd)
  if not VVhCPI:
   if VVByVq: VVByVq.VVZQH0()
   FFBAp7(self, "No packages found!")
   return
  elif len(VVhCPI) == 1 and VVhCPI[0] == VVzpvL:
   FFBAp7(self, VVzpvL)
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VV1rg6  = []
  for item in VVhCPI:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VV1rg6.append((name, package, version))
  if mode > 0:
   extensions = FF5Oes("ls %s -l | grep '^d' | awk '{print $9}'" % VVMMWP)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VV1rg6:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == "AJPan": name += "el"
      VV1rg6.append((name, VVMMWP + item, "-"))
   systemPlugins = FF5Oes("ls %s -l | grep '^d' | awk '{print $9}'" % VVpZJm)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VV1rg6:
      if item.lower() == row[0].lower():
       break
     else:
      VV1rg6.append((item, VVpZJm + item, "-"))
  if not VV1rg6:
   FFBAp7(self, "No packages found!")
   return
  if VVByVq:
   VV1rg6.sort(key=lambda x: x[0].lower())
   VVByVq.VVzmZc(VV1rg6, title)
  else:
   widths = (20, 50, 30)
   VVw8s5 = None
   VVGv9L = None
   if mode == 0:
    VV5uBQ = ("Install" , self.VVVAPq   , [])
    VVw8s5 = ("Download" , self.VVBTLt   , [])
    VVGv9L = ("Filter"  , self.VV74n5 , [])
   elif mode == 1:
    VV5uBQ = ("Uninstall", self.VVZ7p3, [])
   elif mode == 2:
    VV5uBQ = ("Uninstall", self.VVZ7p3, [])
    widths= (18, 57, 25)
   VV1rg6 = sorted(VV1rg6, key=lambda x: x[0].lower())
   VV3Y5Z = ("Package Info.", self.VVDP5Q, [])
   header   = ("Name" ,"Package" , "Version" )
   FFN0i6(self, None, header=header, VV1rg6=VV1rg6, VVDe98=widths, VVwZKv=28, VV5uBQ=VV5uBQ, VVw8s5=VVw8s5, VV3Y5Z=VV3Y5Z, VVGv9L=VVGv9L, VVQTvb=self.lastSelectedRow
     , VVZ7ot="#22110011", VVuutY="#22191111", VV5tqg="#22191111", VVwtgu="#00003030", VVorfQ="#00333333")
 def VVDP5Q(self, VVByVq, title, txt, colList):
  package = colList[1]
  self.VVVDSm(package)
 def VV74n5(self, VVByVq, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVJ4VL = []
  VVJ4VL.append(("All Packages", "all"))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVJ4VL.append(VV1dpw)
  for word in words:
   VVJ4VL.append((word, word))
  FFdrYz(self, boundFunction(self.VVDw8a, VVByVq), VVJ4VL=VVJ4VL, title="Select Filter")
 def VVDw8a(self, VVByVq, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFobhC(VVByVq, boundFunction(self.VVQw2w, 0, grep, VVByVq, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVZ7p3(self, VVByVq, title, txt, colList):
  currentRow  = colList[0]
  package  = colList[1]
  if package.startswith((VVMMWP, VVpZJm)):
   FFJWhD(self, boundFunction(self.VVa1tB, VVByVq, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVJ4VL = []
   VVJ4VL.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVJ4VL.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVJ4VL.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFdrYz(self, boundFunction(self.VVuUpa, VVByVq, package), VVJ4VL=VVJ4VL)
 def VVa1tB(self, VVByVq, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -r '%s' &>/dev/null %s" % (package, VVFyCE)
  FFKyuP(self, cmd, VVrZnU=boundFunction(self.VVLoie, VVByVq))
 def VVuUpa(self, VVByVq, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVXgHo
   elif item == "remove_ForceRemove"  : cmdOpt = VVhvpp
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVzzTf
   FFJWhD(self, boundFunction(self.VVJ5fy, VVByVq, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVJ5fy(self, VVByVq, package, cmdOpt):
  self.lastSelectedRow = VVByVq.VVwl1D()
  cmd = FFj0t1(cmdOpt, package)
  if cmd : FFKyuP(self, cmd, VVrZnU=boundFunction(self.VVLoie, VVByVq))
  else : FFhJ5k(self)
 def VVLoie(self, VVByVq):
  VVByVq.cancel()
  FFVuPM()
 def VVVAPq(self, VVByVq, title, txt, colList):
  package  = colList[1]
  VVJ4VL = []
  VVJ4VL.append(("Install Package"         , "install_CheckVersion" ))
  VVJ4VL.append(("Install Package (force reinstall)"    , "install_ForceReinstall" ))
  VVJ4VL.append(("Install Package (force overwrite)"    , "install_ForceOverwrite" ))
  VVJ4VL.append(("Install Package (force downgrade)"    , "install_ForceDowngrade" ))
  VVJ4VL.append(("Install Package (ignore failed dependencies)"  , "install_IgnoreDepends" ))
  FFdrYz(self, boundFunction(self.VViFRT, package), VVJ4VL=VVJ4VL)
 def VViFRT(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVSMBq
   elif item == "install_ForceReinstall" : cmdOpt = VVJUEs
   elif item == "install_ForceOverwrite" : cmdOpt = VV1Ulm
   elif item == "install_ForceDowngrade" : cmdOpt = VVptud
   elif item == "install_IgnoreDepends" : cmdOpt = VV24AE
   FFJWhD(self, boundFunction(self.VVERwn, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVERwn(self, package, cmdOpt):
  cmd = FFj0t1(cmdOpt, package)
  if cmd : FFKyuP(self, cmd, VVrZnU=FFVuPM, checkNetAccess=True)
  else : FFhJ5k(self)
 def VVBTLt(self, VVByVq, title, txt, colList):
  package  = colList[1]
  FFJWhD(self, boundFunction(self.VVJ5Ap, package), "Download Package ?\n\n%s" % package)
 def VVJ5Ap(self, package):
  if FFFIVQ():
   cmd = FFj0t1(VVorbi, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFOCvV(success, VVx2Y8))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFOCvV(fail, VVUq52))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFKyuP(self, cmd, VVgVVL=[VVUq52, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFhJ5k(self)
  else:
   FFBAp7(self, "No internet connection !")
 def VVVDSm(self, package):
  infoCmd  = FFj0t1(VVhPIi, package)
  filesCmd = FFj0t1(VVv0Zt, package)
  listInstCmd = FFgO5n(VVi1qq, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFv4kb(VVWvE3)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFOCvV(notInst, VVpKeT))
   cmd += "else "
   cmd +=   FFAhCU("System Info", VVWvE3)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFAhCU("Related Files", VVWvE3)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFa7xk(self, cmd)
  else:
   FFhJ5k(self)
class CCqgtV(Screen):
 VVCDvp  = 0
 VV9vYz = 1
 VV5210  = 2
 VVW7ef  = 3
 VVrMwQ = 4
 VVehSi = 5
 VV2Ie6 = 6
 def __init__(self, session):
  self.skin, self.skinParam = FFbmPq(VVXAn9, 1000, 950, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VV13eF = None
  self.lastfilterUsed  = None
  VVJ4VL = self.VVb9ai()
  FF9Cql(self, VVJ4VL=VVJ4VL, title="Services/Channels")
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self["myMenu"].setList(self.VVb9ai())
  FFYI0q(self["myMenu"])
  FFImVi(self)
 def VVb9ai(self):
  VVJ4VL = []
  VVJ4VL.append(("Current Service (Signal / Player)"  , "currentServiceSignal"    ))
  VVJ4VL.append(("Current Service (info.)"     , "currentServiceInfo"     ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Transponders (Statistics)"    , "TranspondersStats"     ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Services (Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVJ4VL.append(("Services (Transponders)"     , "lameDB_allChannels_with_tranaponder" ))
  VVJ4VL.append(("Services (IDs)"       , "lameDB_allChannels_with_details"  ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Services (Parental-Control List)"   , "parentalControlChannels"    ))
  VVJ4VL.append(("Services (Hidden List)"     , "showHiddenChannels"     ))
  VVJ4VL.append(("Services with PIcons for the System"  , "VVVk1e"     ))
  VVJ4VL.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"   ))
  VVJ4VL.append(VV1dpw)
  lamedbFile, disabledFile = CCqgtV.VVZ7vo()
  if fileExists(lamedbFile):
   if fileExists(disabledFile):
    VVJ4VL.append(("Enable Hidden Services List"  , "enableHiddenChannels"    ))
   else:
    VVJ4VL.append(("Disable Hidden Services List"  , "disableHiddenChannels"    ))
  VVJ4VL.append(("Reset Parental Control Settings"   , "VV4fiJ"    ))
  VVJ4VL.append(("Delete Channels with no names"   , "VVr1Te"    ))
  VVJ4VL.append(('Export Services to "channels.xml"'  , "VVe9Qp"      ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Reload Channels and Bouquets"    , "VVkZJ8"      ))
  return VVJ4VL
 def VVFd70(self):
  global VVCBxr
  VVCBxr = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "currentServiceSignal"     : FF4nG4(self)
   elif item == "currentServiceInfo"     : FFnMVC(self, fncMode=CCipRP.VVCIAD)
   elif item == "TranspondersStats"     : FFobhC(self, self.VV61h1     )
   elif item == "lameDB_allChannels_with_refCode"  : FFobhC(self, self.VVrx5A )
   elif item == "lameDB_allChannels_with_tranaponder" : FFobhC(self, self.VV4elV)
   elif item == "lameDB_allChannels_with_details"  : FFobhC(self, self.VVNevk )
   elif item == "parentalControlChannels"    : FFobhC(self, self.VVP1o2   )
   elif item == "showHiddenChannels"     : FFobhC(self, self.VVDWUS     )
   elif item == "VVVk1e"     : FFobhC(self, self.VViiS9     )
   elif item == "servicesWithMissingPIcons"   : FFobhC(self, self.VV2Pwh   )
   elif item == "enableHiddenChannels"     : self.VV8fv6(True)
   elif item == "disableHiddenChannels"    : self.VV8fv6(False)
   elif item == "VV4fiJ"    : FFJWhD(self, self.VV4fiJ, "Reset and Restart ?" )
   elif item == "VVr1Te"    : FFobhC(self, self.VVr1Te)
   elif item == "VVe9Qp"      : self.VVe9Qp()
   elif item == "VVkZJ8"      : FFobhC(self, boundFunction(CCqgtV.VVkZJ8, self))
   else            : self.close()
 def VVe9Qp(self):
  VVJ4VL = []
  VVJ4VL.append(("All Sat/C/T Services", "all"))
  VVJ4VL.append(("--[ BOUQUETS ]" + "-" * 100, ))
  bouquets = FF1OCM()
  if bouquets:
   for item in bouquets:
    VVJ4VL.append((item[0], item[1].toString()))
  FFdrYz(self, self.VVMzST, VVJ4VL=VVJ4VL, title="", VVYMy8=True)
 def VVMzST(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCqgtV.VVn1cj("1:7:")
   else   : lst = FFhmEb(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     fPath = "%schannels_%s.xml" % (FF5gdy(CFG.exportedTablesPath.getValue()), FFC5od())
     with open(fPath, "w") as f:
      f.write('<?xml version="1.0" encoding="utf-8"?>\n')
      f.write('<channels>\n\n')
      for r, n in lst:
       sat = "?"
       serv = eServiceReference(r)
       if serv:
        chPath = serv.getPath()
        if not chPath    : sat = FFQ6pE(r, False)
        elif chPath.startswith("/") : sat = "Local"
        elif FFsGsn(r)    : sat = "IPTV"
       f.write('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
      f.write('\n</channels>\n')
     FFSzHX(self, "Saved %d services to:\n\n%s" % (tot, fPath))
     return
   FFtMdo(self, "No Services found !", 1500)
 @staticmethod
 def VVkZJ8(SELF):
  FFWjYU()
  FFSzHX(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVrx5A(self):
  self.VV13eF = None
  self.lastfilterUsed  = None
  self.filterObj   = CCQuuR(self)
  VVhCPI = CCqgtV.VVxFIz(self, self.VVCDvp)
  if VVhCPI:
   VVhCPI.sort(key=lambda x: x[0].lower())
   VV69tn  = ("Zap"   , self.VV0sw1     , [])
   VVTRSb = (""    , self.VVZHYp   , [])
   VV3Y5Z = ("Options"  , self.VVg81a , [])
   VVw8s5 = ("Current Service", self.VVuLMV , [])
   VVGv9L = ("Filter"   , self.VV9W8x  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VV32KX  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFN0i6(self, None, header=header, VV1rg6=VVhCPI, VV32KX=VV32KX, VVDe98=widths, VVwZKv=26, VV69tn=VV69tn, VVTRSb=VVTRSb, VVw8s5=VVw8s5, VV3Y5Z=VV3Y5Z, VVGv9L=VVGv9L)
 def VV4elV(self):
  self.VV13eF = None
  self.lastfilterUsed  = None
  self.filterObj   = CCQuuR(self)
  VVhCPI = CCqgtV.VVxFIz(self, self.VV9vYz)
  if VVhCPI:
   VVhCPI.sort(key=lambda x: x[0].lower())
   VV69tn  = ("Zap"   , self.VV0sw1      , [])
   VVTRSb = (""    , self.VVZHYp    , [])
   VVw8s5 = ("Current Service", self.VVuLMV  , [])
   VV3Y5Z = ("Options"  , self.VVFreL , [])
   VVGv9L = ("Filter"   , self.VVLrzK  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VV32KX  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFN0i6(self, None, header=header, VV1rg6=VVhCPI, VV32KX=VV32KX, VVDe98=widths, VVwZKv=26, VV69tn=VV69tn, VVTRSb=VVTRSb, VVw8s5=VVw8s5, VV3Y5Z=VV3Y5Z, VVGv9L=VVGv9L)
 def VVg81a(self, VVByVq, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel  = CCn4gV(self, VVByVq, 3)
  mSel.VVykF8(servName, refCode, pcState, hidState)
 def VVFreL(self, VVByVq, title, txt, colList):
  servName  = colList[0]
  refCode   = colList[3]
  mSel   = CCn4gV(self, VVByVq, 3)
  mSel.VVORrI(servName, refCode)
 def VVU3jm(self, VVByVq, refCode, isAddToBlackList):
  VVByVq.VVCgW1("Processing ...")
  FFOFIS(boundFunction(self.VVcsWB, VVByVq, [refCode], isAddToBlackList))
 def VVswGt(self, VVByVq, isAddToBlackList):
  refCodeList = VVByVq.VVcoGn(3)
  if not refCodeList:
   FFBAp7(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVByVq.VVCgW1("Processing ...")
  FFOFIS(boundFunction(self.VVcsWB, VVByVq, refCodeList, isAddToBlackList))
 def VVcsWB(self, VVByVq, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVXF7n, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVXF7n):
   lines = FFHvYZ(VVXF7n)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVXF7n, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVByVq.VVTa6z
   if isMulti:
    self.VV70T1(VVByVq, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VV6TEM(VVByVq, refCode)
    VVByVq.VVZQH0()
  else:
   VVByVq.VVq6Qj("No changes")
 def VVN3fs(self, VVByVq, refCode, isHide):
  title = "Change Hidden State"
  if FF7mZV(refCode):
   VVByVq.VVCgW1("Processing ...")
   ret = FFNjm6(refCode, isHide)
   if ret : FFobhC(self, boundFunction(self.VV6TEM, VVByVq, refCode))
   else : FFBAp7(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFBAp7(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VV6TEM(self, VVByVq, refCode):
  VVhCPI = CCqgtV.VVxFIz(self, self.VVCDvp, VVGOxR=[3, [refCode], False])
  done = False
  if VVhCPI:
   data = VVhCPI[0]
   if data[3] == refCode:
    done = VVByVq.VVFmzh(data)
  if not done:
   self.VVDKUe(VVByVq, VVByVq.VVWtjK(), self.VVCDvp)
  VVByVq.VVZQH0()
 def VV70T1(self, VVByVq, totRefCodes):
  VVhCPI = CCqgtV.VVxFIz(self, self.VVCDvp, VVGOxR=self.VV13eF)
  VVByVq.VVzmZc(VVhCPI)
  VVByVq.VVHK3s(False)
  VVByVq.VVq6Qj("%d Processed" % totRefCodes)
 def VVTSwS(self, VVByVq, isHide):
  refCodeList = VVByVq.VVcoGn(3)
  if not refCodeList:
   FFBAp7(self, "Nothing selected", title="Change Hidden State")
   return
  VVByVq.VVCgW1("Processing ...")
  FFOFIS(boundFunction(self.VViTwb, VVByVq, refCodeList, isHide))
 def VViTwb(self, VVByVq, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFNjm6(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   db = eDVBDB.getInstance()
   if db:
    db.saveServicelist()
    db.reloadServicelist()
    db.reloadBouquets()
   self.VV70T1(VVByVq, len(refCodeList))
  else:
   VVByVq.VVq6Qj("No changes")
 def VV9W8x(self, VVByVq, title, txt, colList):
  self.filterObj.VVrnLF(1, VVByVq, 2, boundFunction(self.VV2Mjd, VVByVq))
 def VV2Mjd(self, VVByVq, item):
  self.VV4uXK(VVByVq, item, 2, self.VVCDvp)
 def VVLrzK(self, VVByVq, title, txt, colList):
  self.filterObj.VVrnLF(2, VVByVq, 4, boundFunction(self.VVXXht, VVByVq))
 def VVXXht(self, VVByVq, item):
  self.VV4uXK(VVByVq, item, 4, self.VV9vYz)
 def VVh91R(self, VVByVq, title, txt, colList):
  self.filterObj.VVrnLF(0, VVByVq, 4, boundFunction(self.VVQsXq, VVByVq))
 def VVQsXq(self, VVByVq, item):
  self.VV4uXK(VVByVq, item, 4, self.VV5210)
 def VV4uXK(self, VVByVq, item, satCol, mode):
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVByVq.VVfRxf(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VV13eF = None
  else:
   words, asPrefix = CCQuuR.VVaZUu(words)
   self.VV13eF = [col, words, asPrefix]
  if words: FFobhC(self, boundFunction(self.VVDKUe, VVByVq, title, mode), title="Reading Services ...")
  else : FFtMdo(VVByVq, "Incorrect filter", 2000)
 def VVDKUe(self, VVByVq, title, mode):
  VVhCPI = CCqgtV.VVxFIz(self, mode, VVGOxR=self.VV13eF, VVO5r1=False)
  if VVhCPI:
   VVhCPI.sort(key=lambda x: x[0].lower())
   VVByVq.VVzmZc(VVhCPI, title)
  else:
   VVByVq.VVZQH0()
   FFtMdo(VVByVq, "Not found!", 1500)
 def VVaLZS(self, VV1rg6, VV69tn=None, VVTRSb=None, VV5uBQ=None, VVw8s5=None, VV3Y5Z=None, VVGv9L=None):
  VVw8s5 = ("Current Service", self.VVuLMV, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VV32KX = (LEFT  , LEFT  , CENTER, LEFT    )
  FFN0i6(self, None, header=header, VV1rg6=VV1rg6, VV32KX=VV32KX, VVDe98=widths, VVwZKv=26, VV69tn=VV69tn, VVTRSb=VVTRSb, VV5uBQ=VV5uBQ, VVw8s5=VVw8s5, VV3Y5Z=VV3Y5Z, VVGv9L=VVGv9L)
 def VVuLMV(self, VVByVq, title, txt, colList):
  self.VVTQuh(VVByVq)
 def VV2DPz(self, VVByVq, title, txt, colList):
  self.VVTQuh(VVByVq, True)
 def VVTQuh(self, VVByVq, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVByVq.VVdYA0(colDict, VVqJ5y=True)
   else:
    VVByVq.VVgUPC(3, refCode, True)
   return
  FFBAp7(self, "Colud not read current Reference Code !")
 def VVNevk(self):
  self.VV13eF = None
  self.lastfilterUsed  = None
  self.filterObj   = CCQuuR(self)
  VVhCPI = CCqgtV.VVxFIz(self, self.VV5210)
  if VVhCPI:
   VVhCPI.sort(key=lambda x: x[0].lower())
   VVTRSb = (""    , self.VV6EQc , []      )
   VVw8s5 = ("Current Service", self.VV2DPz  , []      )
   VVGv9L = ("Filter"   , self.VVh91R   , [], "Loading Filters ..." )
   VV69tn  = ("Zap"   , self.VVzsv8      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VV32KX  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFN0i6(self, None, header=header, VV1rg6=VVhCPI, VV32KX=VV32KX, VVDe98=widths, VVwZKv=26, VV69tn=VV69tn, VVTRSb=VVTRSb, VVw8s5=VVw8s5, VVGv9L=VVGv9L)
 def VV6EQc(self, VVByVq, title, txt, colList):
  refCode  = self.VVkhCv(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFnMVC(self, fncMode=CCipRP.VVvg8g, refCode=refCode, chName=chName, text=txt)
 def VVzsv8(self, VVByVq, title, txt, colList):
  refCode = self.VVkhCv(colList)
  FFPZFB(self, refCode)
 def VV0sw1(self, VVByVq, title, txt, colList):
  FFPZFB(self, colList[3])
 def VVkhCv(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVxFIz(SELF, mode, VVGOxR=None, VVO5r1=True, VVaKKN=True):
  lamedbFile, disabledFile = CCqgtV.VVZ7vo()
  if fileExists(lamedbFile):
   asPrefix = False
   if VVGOxR:
    filterCol = VVGOxR[0]
    filterWords = VVGOxR[1]
    asPrefix = VVGOxR[2]
    for ndx, item in enumerate(filterWords):
     filterWords[ndx] = item.strip().lower()
   else:
    filterWords = None
   if mode == CCqgtV.VVCDvp:
    blackList = None
    if fileExists(VVXF7n):
     blackList = FFHvYZ(VVXF7n)
     if blackList:
      blackList = set(blackList)
   elif mode == CCqgtV.VV9vYz:
    tp = CCYelw()
   VV8Mu4, VVjaEE = FFZHPK()
   tagFound  = False
   if mode in (CCqgtV.VVehSi, CCqgtV.VV2Ie6):
    VVhCPI = {}
   else:
    VVhCPI = []
   with ioOpen(lamedbFile, "r", encoding="utf-8") as f:
    lines = []
    for line in f:
     line = str(line).strip()
     if tagFound:
      if line == "end":
       break
      lines.append(line)
      if len(lines) >= 3:
       chCode = lines[0].upper()
       chName = lines[1]
       chProv = lines[2]
       if chCode.count(":") > 4 and not "," in chCode:
        parts = chCode.split(":")
        SID   = parts[0]
        NameSpace = parts[1]
        TSID  = parts[2]
        ONID  = parts[3]
        STYPE  = parts[4]
       else:
        SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
       chProvOrig = chProv
       if ","  in chProv : chProv = chProv.split(",")[0].strip()
       if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
       if len(chName) == 0 : chName = " ?"
       if len(chProv) == 0 : chProv = " ?"
       s = NameSpace.zfill(8)[:4]
       val = int(s, 16)
       sat = FFAmCN(val)
       try:
        sTypeInt = int(STYPE)
        servTypeHex = (hex(sTypeInt))[2:].upper()
       except:
        sTypeInt = 0
        servTypeHex = "0"
       if mode == CCqgtV.VV5210:
        if sTypeInt in VV8Mu4:
         STYPE = VVjaEE[sTypeInt]
        tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVhCPI.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVhCPI.append(tRow)
        else:
         VVhCPI.append(tRow)
       else:
        refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
        refCode = refCode.replace("::", ":0:")
        if mode == CCqgtV.VVehSi:
         VVhCPI[refCode.replace(":", "_")] = (chName, sat, 1)
        elif mode == CCqgtV.VV2Ie6:
         VVhCPI[chName] = refCode
        elif mode == CCqgtV.VVCDvp:
         if blackList and refCode + ":" in blackList : isBlackList = "Yes"
         else          : isBlackList = "No"
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
         else          : hidStr =  "No"
         tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVhCPI.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVhCPI.append(tRow)
         else:
          VVhCPI.append(tRow)
        elif mode == CCqgtV.VV9vYz:
         if sTypeInt in VV8Mu4:
          STYPE = VVjaEE[sTypeInt]
         freq, pol, fec, sr, syst = tp.VVWYTS(refCode)
         if not "-S" in syst:
          sat = syst
         if freq == "-" : tpStr = "-"
         else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
         tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
         if filterWords:
          tmp = tRow[filterCol].lower()
          if asPrefix:
           if any(tmp.startswith(x) for x in filterWords) : VVhCPI.append(tRow)
          elif any(x in tmp for x in filterWords)    : VVhCPI.append(tRow)
         else:
          VVhCPI.append(tRow)
        elif mode == CCqgtV.VVW7ef:
         flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
         if flag and int(flag.group(1), 16) & 2 == 2:
          VVhCPI.append((chName, chProv, sat, refCode))
        elif mode == CCqgtV.VVrMwQ:
         VVhCPI.append((chName, chProv, sat, refCode))
       lines = []
     elif line == "services":
      tagFound = True
   if not VVhCPI and VVO5r1:
    FFBAp7(SELF, "No services found!")
   return VVhCPI
  else:
   if VVaKKN:
    FFhMRQ(SELF, lamedbFile)
   return None
 def VVP1o2(self):
  if fileExists(VVXF7n):
   lines = FFHvYZ(VVXF7n)
   if lines:
    newRows  = []
    VVhCPI = CCqgtV.VVxFIz(self, self.VVrMwQ)
    if VVhCPI:
     lines = set(lines)
     for item in VVhCPI:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVhCPI = newRows
      VVhCPI.sort(key=lambda x: x[0].lower())
      VVTRSb = ("", self.VVZHYp, [])
      VV69tn = ("Zap", self.VV0sw1, [])
      self.VVaLZS(VV1rg6=VVhCPI, VV69tn=VV69tn, VVTRSb=VVTRSb)
     else:
      FFzRpw(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVhCPI)))
   else:
    FFSzHX(self, "No active Parental Control services.", FFmdhR())
  else:
   FFhMRQ(self, VVXF7n)
 def VVDWUS(self):
  VVhCPI = CCqgtV.VVxFIz(self, self.VVW7ef)
  if VVhCPI:
   VVhCPI.sort(key=lambda x: x[0].lower())
   VVTRSb = ("" , self.VVZHYp, [])
   VV69tn  = ("Zap", self.VV0sw1, [])
   self.VVaLZS(VV1rg6=VVhCPI, VV69tn=VV69tn, VVTRSb=VVTRSb)
  else:
   FFSzHX(self, "No hidden services.", FFmdhR())
 def VV61h1(self):
  totT, totC, totA, totS, totS2, satList = self.VVWT4x()
  txt = FF2tuT("Total Transponders:\n\n", VVpg8I)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FF2tuT("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVpg8I)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat = sorted(uniqSat, key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FF9wEh(item), satList.count(item))
  FFzRpw(self, txt)
 def VVWT4x(self):
  lamedbFile, disabledFile = CCqgtV.VVZ7vo()
  totT = totC = totA = totS = totS2 = 0
  if fileExists(lamedbFile):
   satList = []
   tagFound = False
   with ioOpen(lamedbFile, "r", encoding="utf-8") as f:
    lines = []
    for line in f:
     line = str(line).strip()
     if tagFound:
      if line == "end"    : break
      elif line.startswith("t")  : totT += 1
      elif line.startswith("c")  : totC += 1
      elif line.startswith("a")  : totA += 1
      elif line.startswith("s"):
       c = line.count(":")
       if   c > 9: totS2 += 1
       elif c > 5: totS  += 1
       if c > 5:
        satList.append(line.split(":")[4])
     elif line == "transponders":
      tagFound = True
   return totT, totC, totA, totS, totS2, satList
  else:
   FFhMRQ(self, lamedbFile)
   return 0, 0, 0, 0, 0, None
 def VViiS9(self)   : self.VVVk1e(True)
 def VV2Pwh(self) : self.VVVk1e(False)
 def VVVk1e(self, isWithPIcons):
  piconsPath = CCYaR2.VVQI8K()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCYaR2.VVNhPR(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVhCPI = CCqgtV.VVxFIz(self, self.VVrMwQ)
    if VVhCPI:
     channels = []
     for (chName, chProv, sat, refCode) in VVhCPI:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFgZun(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVhCPI)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VV1j34(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VV1j34("PIcons Path"  , piconsPath)
     txt += VV1j34("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VV1j34("Total services" , totalServices)
     txt += VV1j34("With PIcons"  , totalWithPIcons)
     txt += VV1j34("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFzRpw(self, txt)
     else:
      VVTRSb     = (""      , self.VVZHYp , [])
      if isWithPIcons : VVGv9L = ("Export Current PIcon", self.VVOCNQ  , [])
      else   : VVGv9L = None
      VV3Y5Z     = ("Statistics", FFzRpw, [txt])
      VV69tn      = ("Zap", self.VV0sw1, [])
      channels  = sorted(channels, key=lambda x: x[0].lower())
      self.VVaLZS(VV1rg6=channels, VV69tn=VV69tn, VVTRSb=VVTRSb, VV3Y5Z=VV3Y5Z, VVGv9L=VVGv9L)
   else:
    FFBAp7(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFBAp7(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVZHYp(self, VVByVq, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFnMVC(self, fncMode=CCipRP.VVvg8g, refCode=refCode, chName=chName, text=txt)
 def VVOCNQ(self, VVByVq, title, txt, colList):
  png, path = CCYaR2.VVt4fS(colList[3], colList[0])
  if path:
   CCYaR2.VV9Y13(self, png, path)
 @staticmethod
 def VVZ7vo():
  lamedbFile  = "/etc/enigma2/lamedb"
  disabledFile = "/etc/enigma2/lamedb.disabled"
  return lamedbFile, disabledFile
 @staticmethod
 def VVzYQO():
  lamedb5File  = "/etc/enigma2/lamedb5"
  diabled5File = "/etc/enigma2/lamedb5.disabled"
  return lamedb5File, diabled5File
 def VV8fv6(self, isEnable):
  lamedbFile, disabledFile = CCqgtV.VVZ7vo()
  if isEnable and not fileExists(disabledFile):
   FFSzHX(self, "Aready enabled.")
  elif not isEnable and not fileExists(lamedbFile):
   FFBAp7(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFJWhD(self, boundFunction(self.VV6eMB, isEnable), "%s Hidden Channels ?" % word)
 def VV6eMB(self, isEnable):
  lamedbFile , disabledFile = CCqgtV.VVZ7vo()
  lamedb5File, diabled5File = CCqgtV.VVzYQO()
  cmd  = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (disabledFile, disabledFile, lamedbFile)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (diabled5File, diabled5File, lamedb5File)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedbFile  , lamedbFile , disabledFile)
   cmd += "if [ -f '%s' ]; then cp '%s' '%s'; fi;"    % (lamedb5File , lamedb5File, diabled5File)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (disabledFile, lamedbFile )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (diabled5File, lamedb5File)
  res = os.system(cmd)
  FFWjYU()
  if res == 0 : FFSzHX(self, "Hidden List %s" % word)
  else  : FFBAp7(self, "Error while restoring:\n\n%s" % fileName)
 def VV4fiJ(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat /etc/enigma2/settings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;"
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt /etc/enigma2/settings"
  FFgHOZ(self, cmd)
 def VVr1Te(self):
  lamedbFile, disabledFile = CCqgtV.VVZ7vo()
  if fileExists(lamedbFile):
   tmpFile = "/tmp/ajpane_lamedb"
   os.system(FFps7R("rm -f '%s'" % tmpFile))
   totChan = totRemoved = 0
   lines = FFHvYZ(lamedbFile, keepends=True)
   with open(tmpFile, "w") as f:
    servFound = False
    servLines = []
    for line in lines:
     if servFound:
      if line.strip() == "end":
       f.write(line)
       break
      else:
       servLines.append(line)
       if len(servLines) == 3:
        if len(servLines[1].strip()) > 0:
         totChan += 1
         f.write(servLines[0])
         f.write(servLines[1])
         f.write(servLines[2])
        else:
         totRemoved += 1
        servLines = []
     else:
      f.write(line)
      if line.strip() == "services":
       servFound = True
   os.system(FFps7R("mv -f '%s' '%s'" % (tmpFile, lamedbFile)))
   FFWjYU()
   FFzRpw(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
  else:
   FFhMRQ(self, lamedbFile)
 @staticmethod
 def VVn1cj(servTypes):
  VVm0NB  = eServiceCenter.getInstance()
  VVBJbA   = '%s ORDER BY name' % servTypes
  VV9dwm   = eServiceReference(VVBJbA)
  VVx8LD = VVm0NB.list(VV9dwm)
  if VVx8LD: return VVx8LD.getContent("CN", False)
  else     : return []
class CCipRP(Screen):
 VVCIAD  = 0
 VV7ysN   = 1
 VVik0v   = 2
 VVvg8g    = 3
 VVRb2H    = 4
 VVzdCa   = 5
 VVokK3   = 6
 VVvTs7    = 7
 VV8Ny9   = 8
 VVL54a   = 9
 VVB8Lc   = 10
 VVVZ8U   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFbmPq(VVukgN, 1400, 800, 50, 30, 20, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVCIAD)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.piconShown  = False
  self.Sep   = FF2tuT("%s\n", VVaVAY) % VVlhhY
  self.picViewer  = None
  FF9Cql(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVW2R0 })
  self["myPicF"]   = Label()
  self["myPic"]   = Pixmap()
  self["myPicF"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVJGeB)
  self.onClose.append(self.onExit)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  self["myLabel"].VVmT9l(textOutFile="chann_info")
  if   self.fncMode == self.VVCIAD : fnc = self.VVkdxs_VVCIAD
  elif self.fncMode == self.VV7ysN  : fnc = self.VVkdxs_VVCIAD
  elif self.fncMode == self.VVik0v  : fnc = self.VVkdxs_VVCIAD
  elif self.fncMode == self.VVvg8g  : fnc = self.VVkdxs_VVvg8g
  elif self.fncMode == self.VVRb2H  : fnc = self.VVkdxs_VVRb2H
  elif self.fncMode == self.VVzdCa  : fnc = self.VVkdxs_VVzdCa
  elif self.fncMode == self.VVokK3  : fnc = self.VVkdxs_VVokK3
  elif self.fncMode == self.VVvTs7  : fnc = self.VVkdxs_VVvTs7
  elif self.fncMode == self.VV8Ny9  : fnc = self.VVkdxs_VV8Ny9
  elif self.fncMode == self.VVL54a : fnc = self.VVkdxs_VVL54a
  elif self.fncMode == self.VVB8Lc  : fnc = self.VVkdxs_VVB8Lc
  elif self.fncMode == self.VVVZ8U : fnc = self.VVkdxs_VVVZ8U
  self["myLabel"].setText("\n   Reading Info ...")
  FFOFIS(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVQ3cj()
 def VVzicj(self, err):
  self["myLabel"].setText(err)
  FF3luO(self["myTitle"], "#22200000")
  FF3luO(self["myBody"], "#22200000")
  self["myLabel"].FF3luOColor("#22200000")
  self["myLabel"].VV1ZXK()
 def VVkdxs_VVCIAD(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self)
  self.refCode = refCode
  self.VV6vFf(chName)
 def VVkdxs_VVvg8g(self):
  self.VV6vFf(self.chName)
 def VVkdxs_VVRb2H(self):
  self.VV6vFf(self.chName)
 def VVkdxs_VVzdCa(self):
  self.VV6vFf(self.chName)
 def VVkdxs_VVokK3(self):
  self.VV6vFf("Picon Info")
 def VVkdxs_VVvTs7(self):
  self.VV6vFf(self.chName)
 def VVkdxs_VV8Ny9(self):
  self.VV6vFf(self.chName)
 def VVkdxs_VVL54a(self):
  self.VV6vFf(self.chName)
 def VVkdxs_VVB8Lc(self):
  self.chUrl = self.refCode + self.callingSELF.VVQlcb(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VV6vFf(self.chName)
 def VVkdxs_VVVZ8U(self):
  self.VV6vFf(self.chName)
 def VV6vFf(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFCcWd(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VV0vPl(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FF2tuT(self.VV0P0L(tUrl), VVQDXE)
  if not self.epg:
   epg = self.VVPMi8(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVWqPm(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCYaR2.VVt4fS(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVWqPm(path)
  self.VVTNHo()
  self.VVu6aE()
  self["myLabel"].setText(self.text, VVFuWe=VVtYyU)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VV1ZXK(minHeight=minH)
 def VVu6aE(self):
  url = max([self.refCode, self.chUrl, self.iptvRef], key=len)
  if not FFsGsn(url):
   return
  url = url.replace("%3a", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VV4BqU(FFxPTY(url))
  if epg:
   self.text += "\n" + FFZuRe("EPG:", COLOR_CONS_BRIGHT_YELLOW) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVTNHo()
 def VVTNHo(self):
  if not self.piconShown and self.picUrl:
   path, err = FFSgzY(self.picUrl, "ajpanel_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVWqPm(path)
    if self.piconShown and self.refCode:
     self.VVPfoR(path, self.refCode)
 def VVPfoR(self, path, refCode):
  if path and fileExists(path) and os.system(FFps7R("which ffmpeg")) == 0:
   pPath = CCYaR2.VVQI8K()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = ""
    cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
    cmd += FFps7R("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    os.system(cmd)
 def VVWqPm(self, path):
  if path and fileExists(path):
   err, w, h = self.VVrSIw(path)
   if not err:
    if h > w:
     self.VV78W7(self["myPicF"], w, h, True)
     self.VV78W7(self["myPic"] , w, h, False)
   self.picViewer = CC0FUZ.VV98pS(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPic"].show()
    return True
  return False
 def VV78W7(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVrSIw(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFDup1(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VV0vPl(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FF2tuT(chName, COLOR_CONS_BRIGHT_YELLOW)
  txt += self.VV1j34(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FF2tuT(state, VVpKeT)
   txt += "State\t: %s\n" % state
  w = FFZXBZ(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFZXBZ(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVmVv7(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VV1j34(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VV1j34(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VV1j34(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVqTyg()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVVPLl()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCipRP.VVd5Qs(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FF2tuT("IPTV", VVpg8I)
   txt += self.VVXPa3(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVJEDk(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCYelw()
    tpTxt, namespace = tp.VVjZZL(refCode)
    del tp
    if tpTxt:
     txt += FF2tuT("Tuner:\n", COLOR_CONS_BRIGHT_YELLOW)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FF2tuT("Codes:\n", COLOR_CONS_BRIGHT_YELLOW)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VV1j34(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VV1j34(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VV1j34(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VV1j34(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VV1j34(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VV1j34(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VV1j34(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VV1j34(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VV1j34(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVmVv7(info):
  if info:
   aspect = FFZXBZ(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VV1j34(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFZXBZ(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VV50hK(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VV50hK(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVqTyg(self):
  try:
   service = self.session.nav.getCurrentService()
   audio = service and service.audioTracks()
   return audio and audio.getNumberOfTracks() or 0
  except:
   pass
  return -1
 def VVVPLl(self):
  try:
   service   = self.session.nav.getCurrentService()
   subtitle  = service and service.subtitle()
   subtitlelist = subtitle and subtitle.getSubtitleList()
   return len(subtitlelist)
  except:
   pass
  return -1
 def VVJEDk(self, refCode, iptvRef, chName):
  refCode = FFU1EP(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFWaDF(VVYYh9 + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFWaDF(VVYYh9 + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList += list
  VV1rg6 = []
  tmpRefCode = refCode.upper()
  for item in fList:
   path = VVYYh9 + item
   if fileExists(path):
    txt = FFWaDF(path)
    if tmpRefCode in txt.upper():
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VV1rg6.append(bName)
  txt = self.Sep
  if VV1rg6:
   if len(VV1rg6) == 1:
    txt += "%s\t: %s\n" % (FF2tuT("Bouquet", COLOR_CONS_BRIGHT_YELLOW), VV1rg6[0])
   else:
    txt += FF2tuT("Bouquets:\n", COLOR_CONS_BRIGHT_YELLOW)
    for ndx, item in enumerate(VV1rg6):
     txt += "%d- %s\n" % (ndx + 1, item.strip())
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVPMi8(self, info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += self.VVbNja(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += self.VVbNja(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += self.VVbNja(event, 0)
     except:
      pass
  return epg
 def VVbNja(self, event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCipRP.VVUvxl(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    lang = CFG.epgLanguage.getValue()
    evNameTransl = ""
    if not lang == "off":
     sep = "\nx\nx\nx\n"
     res = self.VV7aTT(evName + sep + evShort + sep + evDesc)
     if res.count(sep) >= 2:
      res = res.split(sep)
      evNameT = res[0]
      evShort = res[1]
      evDesc = res[2]
      if evName and not evName == evNameT:
       evNameTransl = evNameT
    if evName          : txt += "Name\t: %s\n"   % FF2tuT(evName, COLOR_CONS_BRIGHT_YELLOW)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (lang.upper(), FF2tuT(evNameTransl, COLOR_CONS_BRIGHT_YELLOW))
    if evTime           : txt += "Start Time\t: %s\n" % FF78kj(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FF78kj(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFi4q2(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFi4q2(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFi4q2(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FF2tuT(evShort, VVXXzX)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FF2tuT(evDesc , VVXXzX)
    if txt:
     txt = FF2tuT("\n%s\n%s Event:\n%s\n" % (VVlhhY, ("Current", "Next")[evNum], VVlhhY), COLOR_CONS_BRIGHT_YELLOW) + txt
  return txt
 def VVXPa3(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFF7xE(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCKdjH()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVWAZY(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FF2tuT("URL:", VVpg8I) + "\n%s\n" % self.VV0P0L(decodedUrl)
  else:
   txt = "\n"
   txt += FF2tuT("Reference:", VVpg8I) + "\n%s\n" % refCode
  return txt
 def VV0P0L(self, url):
  span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
  if span:
   url = span.group(1)
  if not VV5KEQ:
   url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return url.replace("%3a", ":").strip()
 def VV4BqU(self, decodedUrl):
  if not FFFIVQ():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCmV60.VVxXhs(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCmV60.VVI40b(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVnwzW(tDict)
   elif uType == "movie" : epg, picUrl = self.VVNpQa(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVnwzW(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCmV60.VVVFIA(item, "title"    , is_base64=True )
     lang    = CCmV60.VVVFIA(item, "lang"         ).upper()
     description   = CCmV60.VVVFIA(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCmV60.VVVFIA(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCmV60.VVVFIA(item, "start_timestamp"      )
     stop_timestamp  = CCmV60.VVVFIA(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCmV60.VVVFIA(item, "stop_timestamp"       )
     now_playing   = CCmV60.VVVFIA(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVjMps, ""
      else     : color, txt = VVpKeT , "    (CURRENT EVENT)"
      epg += FF2tuT("_" * 32 + "\n", VVaVAY)
      epg += FF2tuT("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FF2tuT(description, VVQDXE)
      else   : epg += "Description\t: - \n"
      evNum += 1
     try:
      start  = int(start_timestamp_unix)
      dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
      shortDesc = ("Language : %s" % lang) if lang else ""
      totEv, totOK = self.VVl8S9(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)])
     except:
      pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 def VVNpQa(self, tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCmV60.VVVFIA(item, "movie_image" )
    genre  = CCmV60.VVVFIA(item, "genre"   ) or "-"
    plot  = CCmV60.VVVFIA(item, "plot"   ) or "-"
    cast  = CCmV60.VVVFIA(item, "cast"   ) or "-"
    rating  = CCmV60.VVVFIA(item, "rating"   ) or "-"
    director = CCmV60.VVVFIA(item, "director"  ) or "-"
    releasedate = CCmV60.VVVFIA(item, "releasedate" ) or "-"
    duration = CCmV60.VVVFIA(item, "duration"  ) or "-"
    try:
     lang = CCmV60.VVVFIA(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FF2tuT(cast, VVQDXE)
    epg += "Plot:\n%s"    % FF2tuT(self.VV7aTT(plot), VVQDXE)
   except:
    pass
  return epg, movie_image
 def VV7aTT(self, evTxt):
  lang = CFG.epgLanguage.getValue()
  if lang == "off":
   return evTxt
  else:
   txt, err = self.VVRJN2(evTxt, lang)
   return CCipRP.VVNmfe(txt).strip() or evTxt
 def VVW2R0(self):
  if VV5KEQ:
   def VV1j34(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VV1j34(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCKdjH()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVWAZY(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VV1j34(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (VVlhhY, txt))
   FFtMdo(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVNmfe(txt):
  try:
   import HTMLParser
   return HTMLParser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
 @staticmethod
 def VVX9la(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCipRP.VVUvxl(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVUvxl(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCipRP.VVLibo(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVRJN2(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "https://translate.google.com/m?&sl=auto&tl=%s&q=%s" % (toLang, FFrmgH(txt))
   txt, err = CCmV60.VVI40b(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFxPTY(txt)
    div1, div2 = '<div class="result-container">', '</div>'
    ndx  = txt.find(div1)
    if ndx > -1:
     txt = txt[ndx + len(div1):]
     ndx  = txt.find(div2)
     if ndx > -1:
      return txt[:ndx], ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVl8S9(refCode, events):
  from enigma import eEPGCache
  totEv = totOK = 0
  if hasattr(eEPGCache, "importEvents"):
   epgInst = eEPGCache.getInstance()
   if epgInst:
    for data in events:
     totEv += 1
     try:
      if data[0] > iTime() + 604800:
       data = data[:4] + ("",) + data[5:]
      epgInst.importEvents(refCode, (data,))
      totOK += 1
     except:
      pass
  return totEv, totOK
 @staticmethod
 def VV0oX9(SELF):
  if not CC7z2E.VVrOnV(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(SELF)
  err = url =  fSize = resumable = ""
  if FFvbGL(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCKdjH.VVmCee(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCKdjH.VVT7g6Header(), timeout=3, stream=True, verify=False)
    if not resp.ok:
     FFBAp7(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCsPG3.VVekPE(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FF2tuT(" (M3U/M3U8 File)", VVQDXE)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCiRRm.VVXwF1(resp) else "No"
   except requests.Timeout as e     : err = "Connection Timeout"
   except Exception as e       : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVu5M6(subj, val):
   return "%s\n%s\n\n" % (FF2tuT("%s:" % subj, COLOR_CONS_BRIGHT_YELLOW), val)
  title = "File Size"
  txt  = VVu5M6(title , fSize or "?")
  txt += VVu5M6("Name" , chName)
  txt += VVu5M6("URL" , url)
  if resumable: txt += VVu5M6("Supports Download-Resume", resumable)
  if err  : txt += FF2tuT("Error:\n", VVpKeT) + err
  FFzRpw(SELF, txt, title=title)
 @staticmethod
 def VVd5Qs(SELF):
  fPath, fDir, fName = CCsPG3.VVKA14(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg", "mvi"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVLibo(event):
  genre = PR = ""
  try:
   genre  = CCipRP.VVXn6x(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCipRP.VV9JcL(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VV9JcL(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVXn6x(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCipRP.VVSRRi()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVSRRi():
  path = VVqrRB + "genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFWaDF(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFWaDF(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
class CCKdjH():
 def __init__(self):
  self.VVxKP6   = ""
  self.VV2Jz6    = ""
  self.VVMxeP   = ""
  self.portal_moreAuthRand = ""
  self.portal_moreAuthMsg  = ""
  self.portal_moreAuthType = 0
  self.portal_php    = ""
  self.colored_user   = "#f#11ffffaa#User"
  self.colored_server   = "#f#11aaffff#Server"
 def VV732T(self, url, mac, ph1="", VVqJ5y=True):
  self.VVxKP6   = ""
  self.VV2Jz6    = ""
  self.VVMxeP   = ""
  self.portal_moreAuthRand = ""
  self.portal_moreAuthMsg  = ""
  self.portal_moreAuthType = 0
  self.portal_php    = {"s": "/server/load.php", "p": "/portal.php"}.get(ph1, "")
  host = self.VV8enA(url)
  if not host:
   if VVqJ5y:
    self.VVqJ5yor("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVUWJv(mac)
  if not host:
   if VVqJ5y:
    self.VVqJ5yor("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVxKP6 = host
  self.VV2Jz6  = mac
  return True
 def VV8enA(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVUWJv(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVAQgU(self):
  res, err = self.VVNrcH(self.VVdY8n())
  urlPath = "/stalker_portal"
  if "404" in err and urlPath in self.VVxKP6:
   self.VVxKP6 = self.VVxKP6.replace(urlPath, "")
   res, err = self.VVNrcH(self.VVdY8n())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCmV60.VVVFIA(tDict["js"], "token")
    rand  = CCmV60.VVVFIA(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVzqe7(self, VVqJ5y=True):
  if not self.portal_php:
   self.portal_php = self.VVhOG4()
  err = blkMsg = FFSzHXTxt = ""
  try:
   token, rand, err = self.VVAQgU()
   if token:
    self.VVMxeP = token
    self.portal_moreAuthRand = rand
    if rand:
     self.portal_moreAuthType = 2
    prof, retTxt = self.VVsY6Q(True)
    if prof:
     self.portal_moreAuthMsg = retTxt
     if "device_id mismatch" in retTxt:
      self.portal_moreAuthType = 3
      prof, retTxt = self.VVsY6Q(False)
      if retTxt:
       self.portal_moreAuthMsg = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFSzHXTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFSzHXTxt: tErr += "\n%s" % FFSzHXTxt
  if VVqJ5y:
   self.VVqJ5yor(tErr)
  return "", "", tErr
 def VVhOG4(self):
  try:
   import requests
   res = requests.get("%s/c/xpcom.common.js" % self.VVxKP6, headers=CCKdjH.VVT7g6Header(), stream=True, timeout=2)
   if res.ok :
    for line in res.iter_lines():
     if line:
      line = line.decode('utf-8')
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       return span.group(1)
  except:
   pass
  return ""
 def VVsY6Q(self, capMac):
  res, err = self.VVNrcH(self.VV5MDI(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCmV60.VVVFIA(tDict["js"], "block_%s" % word)
    FFSzHXTxt = CCmV60.VVVFIA(tDict["js"], word)
    return tDict, FFSzHXTxt.strip() or blkMsg.strip()
   except Exception as e:
    pass
  return "", ""
 def VV5MDI(self, capMac):
  if self.portal_moreAuthMsg or self.portal_moreAuthRand:
   import hashlib
   if capMac: mac = self.VV2Jz6.upper()
   else  : mac = self.VV2Jz6.lower()
   macUtf8 = mac.encode('utf-8')
   sn = hashlib.md5(macUtf8).hexdigest().upper()[:13]
   Id = hashlib.sha256(macUtf8).hexdigest().upper()
   sig = hashlib.sha256((sn + mac).encode('utf-8')).hexdigest().upper()
   param  = ""
   param += "&sn=%s"   % sn
   param += "&device_id=%s" % Id
   param += "&device_id2=%s" % Id
   param += "&signature=%s" % sig
   param += '&auth_second_step=1'
   param += '&hw_version=2.17-IB-00&hw_version_2=62'
   param += '&metrics={"mac":"%s","sn":"%s","type":"STB","model":"MAG250","random":"%s"}' % (self.VV2Jz6, sn, self.portal_moreAuthRand)
  else:
   param = ""
  return self.VVQYOS() + "type=stb&action=get_profile" + param
 def VV54Ej(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVHZIF()
  if len(rows) < 10:
   rows = self.VVZeKE()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVxKP6 ))
   rows.append(("MAC (from URL)" , self.VV2Jz6 ))
   rows.append(("Token"   , self.VVMxeP ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.colored_user , "MAC"  , self.VV2Jz6 ))
   rows.append(("2", self.colored_server, "Host" , self.VVxKP6 ))
   rows.append(("2", self.colored_server, "Token" , self.VVMxeP ))
   rows = sorted(rows, key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVRp8t(self, isPhp=True, VVqJ5y=False):
  token, profile, tErr = self.VVzqe7(VVqJ5y)
  if not token:
   return "", tErr
  m3u_Url = ""
  url = self.VVUvPA()
  res, err = self.VVNrcH(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCmV60.VVVFIA(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFrmgH(span.group(2))
     pass1 = FFrmgH(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, err
 def VVHZIF(self):
  m3u_Url, err = self.VVRp8t()
  rows = []
  if m3u_Url:
   res, err = self.VVNrcH(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FF78kj(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.colored_user, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FF78kj(int(val))
      else      : val = str(val)
      rows.append(("2", self.colored_server, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVZeKE(self):
  token, profile, tErr = self.VVzqe7()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFPn96(val): val = FFQ0GA(val.decode("UTF-8"))
     else     : val = self.VV2Jz6
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FF78kj(int(parts[1]))
      if parts[2] : ends = FF78kj(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FF78kj(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVQlcb(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVzqe7(VVqJ5y=False)
  if not token:
   return ""
  crLinkUrl = self.VVKOXh(mode, chCm, epNum, epId)
  res, err = self.VVNrcH(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCmV60.VVVFIA(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVQYOS(self):
  return self.VVxKP6 + (self.portal_php or "/server/load.php") + "?"
 def VVdY8n(self):
  return self.VVQYOS() + "type=stb&action=handshake&token=&mac=%s" % self.VV2Jz6
 def VVCUGF(self, mode):
  url = self.VVQYOS() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVEsT7(self, catID):
  return self.VVQYOS() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVLgB0(self, mode, catID, page):
  url = self.VVQYOS() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVSHl9(self, mode, searchName, page):
  return self.VVQYOS() + "type=%s&action=get_ordered_list&search=%s&p=%d" % (mode, searchName, page)
 def VVRXdt(self, mode, catID):
  return self.VVQYOS() + "type=%s&action=get_all_channels&genre=%s&force_ch_link_check=&fav=0&sortby=number&hd=0" % (mode, catID)
 def VVKOXh(self, mode, chCm, serCode, serId):
  url = self.VVQYOS() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=undefined&disable_ad=0&download=false" % (mode, chCm)
  return url
 def VVUvPA(self):
  return self.VVQYOS() + "type=itv&action=create_link"
 def VVxFhz(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVqrfU(catID, stID, chNum)
  query = self.VVlxZ8(mode, self.portal_php[1:2], FFTa0V(host), FFTa0V(mac), serCode, serId, chCm)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVlxZ8(self, mode, ph1, host, mac, serCode, serId, chCm):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVWAZY(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  query = self.VVlxZ8(mode, ph1, host, mac, epNum, epId, chCm)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFQ0GA(host)
  mac   = FFQ0GA(mac)
  valid = False
  if self.VV8enA(playHost) and self.VV8enA(host) and self.VV8enA(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query
 def VVNrcH(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCKdjH.VVT7g6Header()
   if self.VVMxeP:
    headers["Authorization"] = "Bearer %s" % self.VVMxeP
   if useCookies : cookies = {"mac": self.VV2Jz6, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=2, cookies=cookies)
   if res.ok : return res, ""
   else  : err = "Err-%d : %s" % (res.status_code, res.reason or "Unknown")
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVT0zt(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCKdjH.VVT7g6Header(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVT7g6Header():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 @staticmethod
 def VV2h9k(host, mac, tType, action, keysList=[]):
  myPortal = CCKdjH()
  ph1 = "s"
  pref = "/portal.php" if par == "p" else "/server/load.php"
  ok = myPortal.VV732T(host, mac, ph1)
  if not ok:
   return url, "", "Incorrect URL/MAC", "", "", ""
  token, profile, tErr = myPortal.VVzqe7(VVqJ5y=False)
  if not token:
   return url, "", "No Token Received", "", "", ""
  url = "%s%s?type=%s&action=%s" % (host, ph1, tType, action)
  res, err = myPortal.VVNrcH(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    extraDict = {}
    if keysList:
     for item in keysList:
      if item in tDict["js"]:
       extraDict[item] =  tDict["js"][item]
    return True, url, res.text, err, tDict, myPortal.VV1iCh(tDict), extraDict
   except:
    pass
  return False, url, res, err, "", "", ""
 def VV1iCh(self, tDict):
  return iDumps(tDict, indent=4, sort_keys=True)
 def VVqJ5yor(self, err, title="Portal Browser"):
  FFBAp7(self, str(err), title=title)
 def VVEOd3(self, mode):
  if   mode in ("itv"  , CCmV60.VVkEVz , CCmV60.VVaXq9)  : return "Live"
  elif mode in ("vod"  , CCmV60.VV96AI , CCmV60.VVFRmD)  : return "VOD"
  elif mode in ("series" , CCmV60.VVaKzY , CCmV60.VVCEw7) : return "Series"
  else                          : return "IPTV"
 def VVIE3g(self, mode, searchName):
  return 'Find in %s : "%s"' % (self.VVEOd3(mode), searchName)
 def VVxbqK(self, catchup=False):
  VVJ4VL = []
  VVJ4VL.append(("Live"    , "live"  ))
  VVJ4VL.append(("VOD"    , "vod"   ))
  VVJ4VL.append(("Series"   , "series"  ))
  if catchup:
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append(("Catchup TV" , "catchup"  ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Account Info." , "accountInfo" ))
  return VVJ4VL
 @staticmethod
 def VVxJVO(decodedUrl):
  m3u_Url = ""
  p = CCKdjH()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVWAZY(decodedUrl)
  if valid:
   ok = p.VV732T(host, mac, ph1, VVqJ5y=False)
   if ok:
    m3u_Url, err = p.VVRp8t(isPhp=False, VVqJ5y=False)
    span = iSearch(r".+ch\/(.+)_", decodedUrl, IGNORECASE)
    if span:
     m3u_Url += span.group(1)
  return m3u_Url
 @staticmethod
 def VVmCee(decodedUrl):
  p = CCKdjH()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVWAZY(decodedUrl)
  if valid:
   if CCKdjH.VVX3hA(chCm):
    return FFxPTY(chCm)
   else:
    ok = p.VV732T(host, mac, ph1, VVqJ5y=False)
    if ok:
     try:
      chUrl = p.VVQlcb(mode, chCm, epNum, epId)
      return FFxPTY(chUrl)
     except Exception as e:
      pass
  return ""
 @staticmethod
 def VVX3hA(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
class CCRIa4(CCKdjH):
 def __init__(self):
  CCKdjH.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVAj2I(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = self.VVWAZY(decodedUrl)
  if valid:
   if self.VV732T(host, mac, ph1, VVqJ5y=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVTZVs(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  try:
   chUrl = self.VVQlcb(self.mode, self.chCm, self.epNum, self.epId)
  except:
   return False
  isDirect = False
  if CCKdjH.VVX3hA(self.chCm):
   chUrl = FFxPTY(self.chCm)
   chUrl = FFrmgH(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
   isDirect = True
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
   isDirect = True
  if not chUrl:
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVQ5Di(chUrl)
  if newIptvRef:
   success = self.VV5xRE(self.iptvRef, newIptvRef, isDirect)
   if passedSELF:
    FFPZFB(passedSELF, newIptvRef, VVhM2K=False, fromPrtalReplay=True, isFromSession=isFromSession)
   else:
    FFPZFB(self, newIptvRef, VVhM2K=False, fromPrtalReplay=True)
   return True
  else:
   return False
 def VVQ5Di(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VV5xRE(self, oldCode, newCode, isDirect):
  bPath = FF5VPS()
  if bPath:
   if isDirect:
    patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
    span = iSearch(patt, newCode, IGNORECASE)
    if span:
     newRef = span.group(1)
     newPar = span.group(2)
     lines = FFHvYZ(bPath)
     for ndx, line in enumerate(lines):
      span = iSearch(patt, line, IGNORECASE)
      if span and newRef == span.group(1) and newPar == span.group(2):
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f:
        for line in lines:
         f.write(line + "\n")
       FFWjYU()
       return True
   else:
    txt = FFWaDF(bPath)
    if oldCode in txt:
     txt = txt.replace(oldCode, newCode)
     with open(bPath, "w") as f:
      f.write(txt)
     FFWjYU()
     return True
  return False
class CCeEiP(CCRIa4):
 def __init__(self, passedSession):
  CCRIa4.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.isFromEOF  = False
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVuryq, iPlayableService.evEOF: self.VVlmoi, iPlayableService.evEnd: self.VVsNg8})
  except:
   pass
 def VVuryq(self):
  self.startTime = iTime()
 def VVlmoi(self):
  global EVENT_STATE
  EVENT_STATE = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self.passedSession, isFromSession=True)
    if iptvRef and not FFvbGL(decodedUrl):
     self.isFromEOF = True
     CCc7Er(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVsNg8(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVF4YW)
  except:
   self.timer1.callback.append(self.VVF4YW)
  self.timer1.start(100, True)
 def VVF4YW(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVAj2I(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CC7tge.VVdfBW:
       self.isFromEOF = False
       self.VVTZVs(self.passedSession, isFromSession=True)
class CCDgHG():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.nameTagPatt = r"\s*.{1,2}\s*[\[(|:]{1,2}\s*(.+)|\s*[\[(|:].{1,5}[\])|:](.+)|\s*(?:[^a-z]+:)*(.+)"
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.missingUtf8 = VVM64s and not VVltWt
  self.adultWords  = ("adult", "aduld", "sex", "porn", "xxx", "xxi", "erotic", "x-rated", "xrated", "skin flick", "dirty movie", "dirty film", "blue movie", "blue film", "18+", "+18", "r18 movie", "r18 film", "r-18 movie", "r-18 film", "r-17 movie", "r-17 film")
  self.adultWords2 = ("\u042d\u0440\u043e\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0435", "dla doros\u0142ych")
 def VVdZu6(self, name,  censored=""):
  if self.missingUtf8:
   name = str(name.encode('ascii', 'replace').decode('utf-8'))
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCmV60.VVB1fn(name):
   return CCmV60.VVehI9(name)
  name = self.VVeE2L(name)
  return name.strip() or name
 def VVeE2L(self, name):
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    return span.group(1) or span.group(2) or span.group(3)
  return name
 def VVFNHE(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVeE2L(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVJwF7(self, name):
  if self.hideAdult:
   if any(x in name.lower() for x in self.adultWords):
    return ""
   elif any(x in name.encode('ascii', 'backslashreplace').decode('utf-8').lower() for x in self.adultWords2):
    return ""
  return name.strip()
 def VVsKi4(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVucJo(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CC7z2E(CCKdjH):
 def __init__(self):
  CCKdjH.__init__(self)
 def VVsGEj(self):
  if CC7z2E.VVrOnV(self):
   FFobhC(self, self.VVLOue, title="Searching ...")
 def VVZybC(self, winSession, url, mac):
  if CC7z2E.VVrOnV(self):
   if self.VV732T(url, mac):
    FFobhC(winSession, self.VVJoL5, title="Checking Server ...")
   else:
    FFBAp7(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VVLOue(self):
  path = CCmV60.VV6FB1()
  lines = FF5Oes('find %s %s \( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"' % (path, FFebM5(1)))
  if lines:
   if len(lines) == 1 and lines[0] == VVzpvL:
    FFBAp7(self, VVzpvL)
   else:
    lines.sort()
    VVJ4VL = []
    for line in lines:
     VVJ4VL.append((line, line))
    OKBtnFnc  = self.VVrkLW
    VVx8rq = ("Delete File", self.VVEj1z)
    FFdrYz(self, None, title="Select Portals File", VVJ4VL=VVJ4VL, width=1200, OKBtnFnc=OKBtnFnc, VVx8rq=VVx8rq)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFBAp7(self, 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt)
 def VVEj1z(self, VVH9sbObj, path):
  FFJWhD(self, boundFunction(self.VVgAWX, VVH9sbObj, path), "Delete this file ?\n\n%s" % path)
 def VVgAWX(self, VVH9sbObj, path):
  os.system(FFps7R("rm -f '%s'" % path))
  if fileExists(path) : FFtMdo(VVH9sbObj, "Not deleted", 1000)
  else    : VVH9sbObj.VV1cyv()
 def VVrkLW(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   enc = CCaMcm.VVQpht(path, self)
   if enc == -1:
    return
   self.session.open(CC1LNl, barTheme=CC1LNl.VVFMDb
       , titlePrefix = "Processing file lines"
       , fncToRun  = boundFunction(self.VVlhyW, path, enc)
       , VVS99s = boundFunction(self.VVDKIQ, menuInstance, path))
 def VVlhyW(self, path, enc, progBarObj):
  urlMacPatt  = r"(.*)(http:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(http:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  progBarObj.VVXZBN(totLines)
  progBarObj.VVx2td = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVjClj(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VV8enA(url)
     mac  = self.VVUWJv(mac)
     if host and mac and progBarObj:
      progBarObj.VVx2td.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VV8enA(url)
      mac  = self.VVUWJv(mac)
      if host and mac and not mac.startswith("AC") and progBarObj:
       progBarObj.VVx2td.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVDKIQ(self, menuInstance, path, VVCeEr, VVx2td, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVx2td:
   VV5uBQ  = ("Home Menu"  , FFAu6q               , [])
   VV3Y5Z = ("Edit File"  , boundFunction(self.VVHvDk, path)       , [])
   VVw8s5 = ("Open as M3U" , self.VVdhuS           , [])
   VVGv9L = ("Check & Filter" , boundFunction(self.VVQqeY, menuInstance, path) , [])
   VV69tn  = ("Select"   , self.VVZybC_fromMacFiles         , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VV32KX  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVByVq = FFN0i6(self, None, title=title, header=header, VV1rg6=VVx2td, VV32KX=VV32KX, VVDe98=widths, VVwZKv=26, VV69tn=VV69tn, VV5uBQ=VV5uBQ, VVw8s5=VVw8s5, VV3Y5Z=VV3Y5Z, VVGv9L=VVGv9L, VVZ7ot="#0a001122", VVuutY="#0a001122", VV5tqg="#0a001122", VVwtgu="#00004455", VVorfQ="#0a333333", VV1sri="#11331100", VVB9Wc=True, searchCol=1)
   if not VVCeEr:
    FFtMdo(VVByVq, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVCeEr:
    FFBAp7(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVdhuS(self, VVByVq, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  FFobhC(VVByVq, boundFunction(self.VV9wqJ, VVByVq, host, mac), title="Checking Server ...")
 def VV9wqJ(self, VVByVq, host, mac):
  p = CCKdjH()
  m3u_Url = ""
  ok = p.VV732T(host, mac, VVqJ5y=False)
  err = ""
  if ok:
   m3u_Url, err = p.VVRp8t(VVqJ5y=False)
  title = "Browsing M3U Server from Portal Data"
  if m3u_Url:
   self.VV1eQ1(title, m3u_Url)
  else:
   FFBAp7(self, err or "No response from Server !", title=title)
 def VVZybC_fromMacFiles(self, VVByVq, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVZybC(VVByVq, url, mac)
 def VVHvDk(self, path, VVByVq, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CC0hs4(self, path, VVS99s=boundFunction(self.VVSKhZ, VVByVq), curRowNum=rowNum)
  else    : FFhMRQ(self, path)
 def VVQqeY(self, menuInstance, path, VVByVq, title, txt, colList):
  self.session.open(CC1LNl, barTheme=CC1LNl.VVLvJ7
      , titlePrefix = "Checking Portals"
      , fncToRun  = boundFunction(self.VV7Pyz, VVByVq)
      , VVS99s = boundFunction(self.VVGCrQ, menuInstance, VVByVq, path))
 def VV7Pyz(self, VVByVq, progBarObj):
  progBarObj.VVx2td = []
  progBarObj.VVXZBN(VVByVq.VVRjIQ())
  for row in VVByVq.VVfKVc():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVjClj(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VV732T(host, mac, VVqJ5y=False):
    token, profile, tErr = self.VVzqe7(VVqJ5y=False)
    if token and progBarObj and not progBarObj.isCancelled:
     res, err = self.VVNrcH(self.VVCUGF("itv"))
     if res and progBarObj and not progBarObj.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       progBarObj.VVjClj(0, showFound=True)
       progBarObj.VVx2td.append((titl, host, mac, cmnt))
      except:
       pass
   if not progBarObj:
    return
 def VVGCrQ(self, menuInstance, VVByVq, path, VVCeEr, VVx2td, threadCounter, threadTotal, threadErr):
  if VVx2td:
   VVByVq.close()
   menuInstance.close()
   newPath = "%s_OK_%s.txt" % (path, FFC5od())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVx2td:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FF2tuT(str(threadCounter), VVpKeT)
    skipped = FF2tuT(str(threadTotal - threadCounter), VVpKeT)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVx2td)
   txt += "%s\n\n%s"    %  (FF2tuT("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
   FFzRpw(self, txt, title="Accessible Portals")
  elif VVCeEr:
   FFBAp7(self, "No portal access found !", title="Accessible Portals")
 def VVJX0K(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFQ0GA(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVJoL5(self):
  token, profile, tErr = self.VVzqe7()
  if token:
   dots = "." * self.portal_moreAuthType
   dots += "+" if self.portal_php[1:2] == "p" else ""
   VVJ4VL  = self.VVxbqK()
   OKBtnFnc = self.VV4dxi
   VVzYgB = ("Home Menu", FFAu6q)
   VVfXyU = ("Bookmark Server", boundFunction(CCmV60.VVIzP6, self, True, self.VVxKP6 + "\t" + self.VV2Jz6))
   FFdrYz(self, None, title="Portal Resources (MAC=%s) %s" % (self.VV2Jz6, dots), VVJ4VL=VVJ4VL, OKBtnFnc=OKBtnFnc, VVzYgB=VVzYgB, VVfXyU=VVfXyU)
 def VV4dxi(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFobhC(menuInstance, boundFunction(self.VVwEKx, mode), title="Reading Categories ...")
   else : FFobhC(menuInstance, boundFunction(self.VVfPp0, menuInstance, title), title="Reading Account ...")
 def VVfPp0(self, menuInstance, title, forceMoreInfo=False):
  rows, totCols = self.VV54Ej(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VV2Jz6)
  VV5uBQ  = ("Home Menu" , FFAu6q            , [])
  VVw8s5  = None
  if VVgFen:
   VVw8s5 = ("Get JS"  , boundFunction(self.VVdcfh, self.VVxKP6) , [])
  if totCols == 2:
   VVGv9L = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVGv9L = ("More Info.", boundFunction(self.VVFLmW, menuInstance) , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFN0i6(self, None, title=title, width=1200, header=header, VV1rg6=rows, VVDe98=widths, VVwZKv=26, VV5uBQ=VV5uBQ, VVw8s5=VVw8s5, VVGv9L=VVGv9L, VVZ7ot="#0a00292B", VVuutY="#0a002126", VV5tqg="#0a002126", VVwtgu="#00000000", searchCol=searchCol)
 def VVdcfh(self, url, VVByVq, title, txt, colList):
  FFobhC(VVByVq, boundFunction(self.VVwm9S, url), title="Getting JS ...")
 def VVwm9S(self, url):
  txt = "// Host\t: %s\n" % url
  res, err = self.VVNrcH("%s/c/version.js" % url)
  if not err: ver = res.text
  else   : ver = "Error: %s" % err
  txt += "// Version\t: %s\n" % ver
  res, err = self.VVNrcH("%s/c/xpcom.common.js" % url)
  if not err: js = res.text
  else   : js = "Error: %s" % err
  txt += "\n%s" % js
  FFzRpw(self, txt, title="JS Info", canSaveToFile="Server_xpcom.common.js")
 def VVFLmW(self, menuInstance, VVByVq, title, txt, colList):
  VVByVq.cancel()
  FFobhC(menuInstance, boundFunction(self.VVfPp0, menuInstance, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVwEKx(self, mode):
  token, profile, tErr = self.VVzqe7()
  if not token:
   return
  res, err = self.VVNrcH(self.VVCUGF(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     processChanName = CCDgHG()
     chList = tDict["js"]
     for item in chList:
      Id   = CCmV60.VVVFIA(item, "id"       )
      Title  = CCmV60.VVVFIA(item, "title"      )
      censored = CCmV60.VVVFIA(item, "censored"     )
      Title = processChanName.VVJwF7(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVgFen:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVEOd3(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVZ7ot, VVuutY, VV5tqg, VVwtgu = self.VVh44S(mode)
   mName = self.VVEOd3(mode)
   VV69tn   = ("Show List"   , boundFunction(self.VVL8Qz, mode) , [])
   VV5uBQ  = ("Home Menu"   , FFAu6q         , [])
   if mode in ("vod", "series"):
    VV3Y5Z = ("Find in %s" % mName , boundFunction(self.VVueTG, mode), [])
   else:
    VV3Y5Z = None
   header   = None #("Category", "catID" )
   widths   = (100   , 0  )
   FFN0i6(self, None, title=title, width=1200, header=header, VV1rg6=list, VVDe98=widths, VVwZKv=30, VV5uBQ=VV5uBQ, VV3Y5Z=VV3Y5Z, VV69tn=VV69tn, VVZ7ot=VVZ7ot, VVuutY=VVuutY, VV5tqg=VV5tqg, VVwtgu=VVwtgu)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.portal_moreAuthMsg:
     txt += "\n\n( %s )" % self.portal_moreAuthMsg
   else:
    txt = "Could not get Categories from server!"
   FFBAp7(self, txt, title=title)
 def VVSs0f(self, mode, VVByVq, title, txt, colList):
  FFobhC(VVByVq, boundFunction(self.VVX13V, mode, VVByVq, title, txt, colList), title="Downloading ...")
 def VVX13V(self, mode, VVByVq, title, txt, colList):
  token, profile, tErr = self.VVzqe7()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVNrcH(self.VVEsT7(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CCmV60.VVVFIA(item, "id"    )
      actors   = CCmV60.VVVFIA(item, "actors"   )
      added   = CCmV60.VVVFIA(item, "added"   )
      age    = CCmV60.VVVFIA(item, "age"   )
      category_id  = CCmV60.VVVFIA(item, "category_id" )
      description  = CCmV60.VVVFIA(item, "description" )
      director  = CCmV60.VVVFIA(item, "director"  )
      genres_str  = CCmV60.VVVFIA(item, "genres_str"  )
      name   = CCmV60.VVVFIA(item, "name"   )
      path   = CCmV60.VVVFIA(item, "path"   )
      screenshot_uri = CCmV60.VVVFIA(item, "screenshot_uri" )
      series   = CCmV60.VVVFIA(item, "series"   )
      cmd    = CCmV60.VVVFIA(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list = sorted(list, key=lambda x: (x[1], int(x[2])))
   VV69tn  = ("Play"    , boundFunction(self.VVwgzI, mode)       , [])
   VVTRSb = (""     , boundFunction(self.VV8Wzk, mode)     , [])
   VV5uBQ = ("Home Menu"   , FFAu6q               , [])
   VVw8s5 = ("Download Options" , boundFunction(self.VVzdL6, mode, "sp", seriesName) , [])
   VV3Y5Z = ("Options" , boundFunction(self.VVUxgD, 0, "pEp", mode, seriesName)  , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VV32KX  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFN0i6(self, None, title=seriesName, width=1200, header=header, VV1rg6=list, VV32KX=VV32KX, VVDe98=widths, VVwZKv=26, VV5uBQ=VV5uBQ, VVw8s5=VVw8s5, VV3Y5Z=VV3Y5Z, VV69tn=VV69tn, VVTRSb=VVTRSb, VVZ7ot="#0a00292B", VVuutY="#0a002126", VV5tqg="#0a002126", VVwtgu="#00000000")
  else:
   FFBAp7(self, "Could not get Episodes from server!", title=seriesName)
 def VVueTG(self, mode, VVByVq, title, txt, colList):
  VVJ4VL = []
  VVJ4VL.append(("Keyboard"  , "manualEntry"))
  VVJ4VL.append(("From Filter" , "fromFilter"))
  FFdrYz(self, boundFunction(self.VVOhTR, VVByVq, mode), title="Input Type", VVJ4VL=VVJ4VL, width=400)
 def VVOhTR(self, VVByVq, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFIilI(self, boundFunction(self.VVZcc4, VVByVq, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCQuuR(self)
    filterObj.VVaSAo(boundFunction(self.VVZcc4, VVByVq, mode))
 def VVZcc4(self, VVByVq, mode, item):
  if item:
   searchName = item.split(",")[0].strip()
   title = self.VVIE3g(mode, searchName)
   if len(searchName) < 3:
    FFBAp7(self, "Enter at least 3 characters.", title=title)
   else:
    processChanName = CCDgHG()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVsKi4([searchName]):
     FFBAp7(self, processChanName.VVucJo(), title=title)
    else:
     self.lastFindIptvName = searchName
     self.VVIMnK(mode, searchName, "", searchName)
 def VVL8Qz(self, mode, VVByVq, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVIMnK(mode, bName, catID, "")
 def VVIMnK(self, mode, bName, catID, searchName):
  self.session.open(CC1LNl, barTheme=CC1LNl.VVFMDb
      , titlePrefix = "Reading from server"
      , fncToRun  = boundFunction(self.VVOAry, mode, bName, catID, searchName)
      , VVS99s = boundFunction(self.VV1101, mode, bName, catID, searchName))
 def VV1101(self, mode, bName, catID, searchName, VVCeEr, VVx2td, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVIE3g(mode, searchName)
  else   : title = "%s : %s" % (self.VVEOd3(mode), bName)
  if VVx2td:
   VVw8s5 = None
   VV3Y5Z = None
   if mode == "series":
    VVZ7ot, VVuutY, VV5tqg, VVwtgu = self.VVh44S("series2")
    VV69tn  = ("Episodes", boundFunction(self.VVSs0f, mode) , [])
   else:
    VVZ7ot, VVuutY, VV5tqg, VVwtgu = self.VVh44S("")
    VV69tn  = ("Play"    , boundFunction(self.VVwgzI, mode)           , [])
    VVw8s5 = ("Download Options" , boundFunction(self.VVzdL6, mode, "vp" if mode == "vod" else "", "") , [])
    VV3Y5Z = ("Options"   , boundFunction(self.VVUxgD, 1, "pCh", mode, bName)      , [])
   VVTRSb = (""      , boundFunction(self.VVo7zo, mode)          , [])
   VV5uBQ = ("Home Menu"    , FFAu6q                   , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" )
   widths   = (10  , 90  , 0   , 0     , 0  , 0  )
   VV32KX  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT )
   VVByVq = FFN0i6(self, None, title=title, header=header, VV1rg6=VVx2td, VV32KX=VV32KX, VVDe98=widths, VVwZKv=26, VV5uBQ=VV5uBQ, VVw8s5=VVw8s5, VV3Y5Z=VV3Y5Z, VV69tn=VV69tn, VVTRSb=VVTRSb, VVZ7ot=VVZ7ot, VVuutY=VVuutY, VV5tqg=VV5tqg, VVwtgu=VVwtgu, VVB9Wc=True, searchCol=1)
   if not VVCeEr:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVByVq.VVEFZZ(VVByVq.VVWtjK() + tot)
    if threadErr: FFtMdo(VVByVq, "Error while reading !", 2000)
    else  : FFtMdo(VVByVq, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFBAp7(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFBAp7(self, "Could not get list from server !", title=title)
 def VVo7zo(self, mode, VVByVq, title, txt, colList):
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFnMVC(self, fncMode=CCipRP.VVVZ8U, portalHost=self.VVxKP6, portalMac=self.VV2Jz6, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVeqXh(mode, VVByVq, title, txt, colList)
 def VV8Wzk(self, mode, VVByVq, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FF2tuT(colList[10], VVQDXE)
  txt += "Description:\n%s" % FF2tuT(colList[11], VVQDXE)
  self.VVeqXh(mode, VVByVq, title, txt, colList)
 def VVeqXh(self, mode, VVByVq, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV1kpu(mode, colList)
  refCode, chUrl = self.VVxFhz(self.VVxKP6, self.VV2Jz6, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFnMVC(self, fncMode=CCipRP.VVB8Lc, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId)
 def VVOAry(self, mode, bName, catID, searchName, progBarObj):
  try:
   token, profile, tErr = self.VVzqe7()
   if not token:
    return
   if progBarObj.isCancelled:
    return
   progBarObj.VVx2td, total_items, max_page_items, err = self.VV9R8C(mode, catID, 1, 1, searchName)
   if progBarObj.isCancelled:
    return
   if progBarObj.VVx2td and total_items > -1 and max_page_items > -1:
    progBarObj.VVXZBN(total_items)
    progBarObj.VVjClj(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if progBarObj.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VV9R8C(mode, catID, page, counter, searchName)
     if err:
      progBarObj.VVuGYr()
     if progBarObj.isCancelled:
      return
     if list:
      progBarObj.VVx2td += list
      progBarObj.VVjClj(len(list), True)
  except:
   pass
 def VV9R8C(self, mode, catID, page, counter, searchName):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVSHl9(mode, searchName, page)
  else   : url = self.VVLgB0(mode, catID, page)
  res, err = self.VVNrcH(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVHLLe(CCmV60.VVVFIA(item, "total_items" ))
     max_page_items = self.VVHLLe(CCmV60.VVVFIA(item, "max_page_items" ))
     processChanName = CCDgHG()
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCmV60.VVVFIA(item, "id"    )
      name   = CCmV60.VVVFIA(item, "name"   )
      o_name   = CCmV60.VVVFIA(item, "o_name"   )
      tv_genre_id  = CCmV60.VVVFIA(item, "tv_genre_id" )
      number   = CCmV60.VVVFIA(item, "number"   ) or str(counter)
      logo   = CCmV60.VVVFIA(item, "logo"   )
      screenshot_uri = CCmV60.VVVFIA(item, "screenshot_uri" )
      cmd    = CCmV60.VVVFIA(item, "cmd"   )
      censored  = CCmV60.VVVFIA(item, "censored"  )
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       span = iSearch(r"stream=(.+)&", cmd)
       if span:
        cmd = "%s%s_" % (cmdStr, span.group(1))
       else:
        span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
      picon = logo or screenshot_uri
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVxKP6 + picon).replace(sp * 2, sp)
      counter += 1
      name = processChanName.VVdZu6(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVFr8y(self, mode, bName, VVByVq, title, txt, colList):
  bNameFile = CCmV60.VV21Ob_forBouquet(bName)
  num  = 0
  path = VVYYh9 + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVYYh9 + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   isMulti = VVByVq.VVTa6z
   for ndx, row in enumerate(VVByVq.VVfKVc()):
    chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV1kpu(mode, row)
    refCode, chUrl = self.VVxFhz(self.VVxKP6, self.VV2Jz6, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    if not isMulti or VVByVq.VVDK6Y(ndx):
     f.write("#SERVICE %s\n"  % chUrl)
     f.write("#DESCRIPTION %s\n" % chName)
     totChange += 1
  FFv9Xh(os.path.basename(path))
  self.VV93Vw(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVHLLe(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVwgzI(self, mode, VVByVq, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV1kpu(mode, colList)
  refCode, chUrl = self.VVxFhz(self.VVxKP6, self.VV2Jz6, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVB1fn(chName):
   FFtMdo(VVByVq, "This is a marker!", 300)
  else:
   FFobhC(VVByVq, boundFunction(self.VVZtnl, mode, VVByVq, chUrl), title="Playing ...")
 def VVZtnl(self, mode, VVByVq, chUrl):
  FFPZFB(self, chUrl, VVhM2K=False)
  self.session.open(CC7tge, portalTableParam=(self, VVByVq, mode))
 def VVSlNc(self, mode, VVByVq, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV1kpu(mode, colList)
  refCode, chUrl = self.VVxFhz(self.VVxKP6, self.VV2Jz6, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VV1kpu(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVrOnV(SELF):
  try:
   import requests
   return True
  except:
   title = 'Install "Requests"'
   VVJ4VL = []
   VVJ4VL.append((title        , "inst" ))
   VVJ4VL.append(("Update Packages then %s" % title , "updInst" ))
   FFdrYz(SELF, boundFunction(CC7z2E.VV9fMt, SELF), title='This requires Python "Requests" library', VVJ4VL=VVJ4VL)
   return False
 @staticmethod
 def VV9fMt(SELF, item=None):
  if item:
   from sys import version_info
   cmdUpd = FFgO5n(VVOJRx, "")
   if cmdUpd:
    cmdInst = FFj0t1(VVSMBq, "python-requests")
    if version_info[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFKyuP(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library')
   else:
    FFhJ5k(SELF)
class CCmV60(Screen, CC7z2E):
 VVbgvJ    = 0
 VVIy1x    = 1
 VVpEl0    = 2
 VVdiYd    = 3
 VVJd3q     = 4
 VVskAj     = 5
 VV1y4r     = 6
 VVARF0     = 7
 VVkW4V      = 8
 VVDiQT     = 9
 VVw2ao     = 10
 VVlBrz     = 11
 VVmZqG     = 12
 VV6Hz2      = 13
 VVIbaA      = 14
 VVLHbp      = 15
 VVkfE3      = 16
 VV9ppd      = 17
 VVAvmz    = 0
 VVkEVz   = 1
 VV96AI   = 2
 VVaKzY   = 3
 VVomyW  = 4
 VVxBNH  = 5
 VVaXq9   = 6
 VVFRmD   = 7
 VVCEw7  = 8
 VVsSqp  = 9
 VVr7O5  = 10
 VVU78z = 0
 VVERvQ = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFbmPq(VVXAn9, 1000, 1000, 50, 40, 30, "#0a00292B", "#0a00272B", 28)
  self.session   = session
  self.m3uOrM3u8File  = m3uOrM3u8File
  self.m3uOrM3u8BName  = ""
  self.VVByVq  = None
  self.tableTitle   = "IPTV Channels List"
  self.VVdMeJData  = {}
  self.lastFindIptvName = ""
  CC7z2E.__init__(self)
  VVJ4VL= self.VVxMrR()
  FF9Cql(self, title="IPTV", VVJ4VL=VVJ4VL)
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FFYI0q(self["myMenu"])
  FFImVi(self)
  FFbUXD(self)
  if self.m3uOrM3u8File:
   self.VVvMVQ(self.m3uOrM3u8File)
 def VVxMrR(self):
  files = self.VVe9Em()
  tList = []
  tList.append(("IPTV Server Browser (from Playlists)"        , "VVdMeJ_fromPlayList" ))
  tList.append(("IPTV Server Browser (from Portal List)"        , "VVdMeJ_fromMac"  ))
  tList.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)"    , "VVdMeJ_fromM3u"  ))
  qUrl, iptvRef = self.VVmCEG()
  if qUrl or "chCode" in iptvRef:
   tList.append(("IPTV Server Browser (from Current Channel)"      , "VVdMeJ_fromCurrChan" ))
  VVJ4VL = []
  if files:
   if self.VVByVq:
    VVJ4VL.append(("Add Current List to a New Bouquet"      , "VVXk4O"  ))
    VVJ4VL.append(VV1dpw)
    VVJ4VL.append(("Change Current List References to Unique Codes"   , "VVdLjN"))
    VVJ4VL.append(("Change Current List References to Identical Codes"  , "VVidI0_rows" ))
    VVJ4VL.append(VV1dpw)
    VVJ4VL.append(("Share Reference with Satellite/C/T Service (manual entry)", "VV90d0"   ))
    VVJ4VL.append(("Share Reference with Satellite/C/T Service (auto-find)" , "VVpvBi"   ))
   else:
    VVJ4VL += tList
    VVJ4VL.append(VV1dpw)
    VVJ4VL.append(("M3U/M3U8 File Browser"         , "VVo89u"   ))
    VVJ4VL.append(("Local IPTV Channels"          , "iptvTable_all"   ))
    if qUrl:
     VVJ4VL.append(VV1dpw)
     VVJ4VL.append(("Update Current Bouquet EPG (from IPTV Server)"  , "refreshIptvEPG"   ))
    VVJ4VL.append(VV1dpw)
    VVJ4VL.append(("Count Available IPTV Channels"       , "VVpmht"    ))
    VVJ4VL.append(("Check Reference Codes Format"        , "VVObc6"   ))
    VVJ4VL.append(("Check System Acceptable Reference Types"     , "VVpxKB"   ))
    VVJ4VL.append(VV1dpw)
    VVJ4VL.append(("Share Reference with Sat./C/T (Only Matching Names)"  , "VVqUCm" ))
    VVJ4VL.append(('Change ALL Ref. Types to (1/4097/5001/5002/8192/8193) ..' , "VVGbO9"  ))
    VVJ4VL.append(("Change ALL References to Unique Codes"     , "VVrJ3t" ))
    VVJ4VL.append(("Change ALL References to Identical Codes"     , "VVidI0_all" ))
  if not self.VVByVq:
   if not files:
    VVJ4VL += tList
   if not CCiRRm.VVA8Ez():
    VVJ4VL.append(VV1dpw)
    VVJ4VL.append(("Download Manager"           , "dload_stat"    ))
  return VVJ4VL
 def VVz7D0(self, item):
  tTitle = "Share Reference with Satellite/C/T Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVXk4O"   : FFIilI(self, self.VVXk4O, defaultText="IPTV_1", title="Create New IPTV Bouquet", message="Enter Bouquet Name:")
   elif item == "VVdLjN" : FFJWhD(self, boundFunction(FFobhC, self.VVByVq, self.VVdLjN ), "Change Current List References to Unique Codes ?")
   elif item == "VVidI0_rows" : FFJWhD(self, boundFunction(FFobhC, self.VVByVq, self.VVidI0   ), "Change Current List References to Identical Codes ?")
   elif item == "VV90d0"   : self.VV90d0(tTitle)
   elif item == "VVpvBi"   : self.VVpvBi(tTitle)
   elif item == "VVdMeJ_fromPlayList" : FFobhC(self, self.VVuaBh, title=title)
   elif item == "VVdMeJ_fromM3u"  : FFobhC(self, boundFunction(self.VV7rrQ, 0), title=title)
   elif item == "VVdMeJ_fromMac"  : self.VVsGEj()
   elif item == "VVdMeJ_fromCurrChan" : self.VVZybC_fromCurrChan()
   elif item == "VVo89u"   : self.VVo89u()
   elif item == "iptvTable_live"   : FFobhC(self, boundFunction(self.VVVXwH, self.VVARF0 ) , title="Loading Channels ...")
   elif item == "iptvTable_all"   : FFobhC(self, boundFunction(self.VVVXwH, self.VVbgvJ) , title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : self.VVyuER()
   elif item == "VVpmht"    : FFobhC(self, self.VVpmht)
   elif item == "VVObc6"    : FFobhC(self, self.VVObc6)
   elif item == "VVpxKB"   : FFobhC(self, self.VVpxKB)
   elif item == "VVqUCm"  : FFJWhD(self, boundFunction(FFobhC, self, self.VVqUCm ), "Continue ?")
   elif item == "VVGbO9"  : self.VVGbO9()
   elif item == "VVrJ3t" : FFJWhD(self, boundFunction(FFobhC, self, self.VVrJ3t ), "Change ALL to Unique Ref. Codes ?")
   elif item == "VVidI0_all" : FFJWhD(self, boundFunction(FFobhC, self, self.VVidI0  ), "Change ALL to Identical Ref. Codes ?")
   elif item == "dload_stat"    : CCiRRm.VVqHgJ(self)
   elif item == "VVkZJ8"   : FFobhC(self, boundFunction(CCqgtV.VVkZJ8, self))
 def VVo89u(self):
  if CC7z2E.VVrOnV(self):
   FFobhC(self, boundFunction(self.VV7rrQ, 1), title="Searching ...")
 def VVFd70(self):
  global VVCBxr
  VVCBxr = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVz7D0(item)
 def VVVXwH(self, mode):
  VVhCPI = self.VV1L9d(mode)
  if VVhCPI:
   VVw8s5 = ("Current Service", self.VVNh6l  , [])
   VV3Y5Z = ("Options"  , self.VVeywx    , [])
   VVGv9L = ("Filter"   , self.VVMpRz    , [])
   VV69tn  = ("Play"   , boundFunction(self.VVSs6v) , [])
   VVTRSb = (""    , self.VVShmE     , [])
   VVDKrQ = (""    , self.VVaXiR      , [])
   header   = ("Num" , "Name" , "Bouquet" , "Type" , "Ref.", "URL" )
   widths   = (9  , 22  , 18  , 6   , 22 , 23 )
   VV32KX  = (CENTER , LEFT  , LEFT  , CENTER, LEFT  , LEFT )
   FFN0i6(self, None, header=header, VV1rg6=VVhCPI, VV32KX=VV32KX, VVDe98=widths, VVwZKv=26
     , VV69tn=VV69tn, VVw8s5=VVw8s5, VV3Y5Z=VV3Y5Z, VVGv9L=VVGv9L, VVTRSb=VVTRSb, VVDKrQ=VVDKrQ
     , VVZ7ot="#0a00292B", VVuutY="#0a002126", VV5tqg="#0a002126", VVwtgu="#00000000", VVB9Wc=True, searchCol=1)
  else:
   if mode == self.VVARF0: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFBAp7(self, err)
 def VVaXiR(self, VVByVq, title, txt, colList):
  self.VVByVq = VVByVq
 def VVeywx(self, VVByVq, title, txt, colList):
  VVJ4VL= self.VVxMrR()
  FFdrYz(self, self.VVz7D0, title="IPTV Tools", VVJ4VL=VVJ4VL)
 def VVMpRz(self, VVByVq, title, txt, colList):
  VVJ4VL = []
  VVJ4VL.append(("All"         , "all"   ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Prefix of Selected Channel"   , "sameName" ))
  VVJ4VL.append(("Suggest Words from Selected Channel" , "partName" ))
  VVJ4VL.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Live TV"        , "live"  ))
  VVJ4VL.append(("VOD"         , "vod"   ))
  VVJ4VL.append(("Series"        , "series"  ))
  VVJ4VL.append(("Uncategorised"      , "uncat"  ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Video"        , "video"  ))
  VVJ4VL.append(("Audio"        , "audio"  ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("MKV"         , "MKV"   ))
  VVJ4VL.append(("MP4"         , "MP4"   ))
  VVJ4VL.append(("MP3"         , "MP3"   ))
  VVJ4VL.append(("AVI"         , "AVI"   ))
  VVJ4VL.append(("FLV"         , "FLV"   ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Duplicate References"     , "depRef"  ))
  bNames = self.VVtURh()
  if bNames:
   bNames.sort()
   VVJ4VL.append(VV1dpw)
   for item in bNames:
    VVJ4VL.append((item, "__b__" + item))
  filterObj = CCQuuR(self)
  filterObj.VV1X6z(VVJ4VL, VVJ4VL, boundFunction(self.VVrGcg, VVByVq))
 def VVrGcg(self, VVByVq, item=None):
  prefix = VVByVq.VVfRxf(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVbgvJ, ""   , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVIy1x , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVpEl0 , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVdiYd , ""  , f + "= Names with Non-English Characters"
   elif item == "live"    : mode, words, title = self.VVARF0  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVkW4V   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVDiQT  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVw2ao  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVlBrz  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVmZqG  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VV6Hz2   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVIbaA   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVLHbp   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVkfE3   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VV9ppd   , ""  , f + "= FLV"
   elif item == "depRef"   : mode, words, title = self.VV1y4r  , ""  , f + "= Duplicate References"
   elif item.startswith("__b__") : mode, words, title = self.VVJd3q  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVskAj  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVpEl0:
   VVJ4VL = []
   chName = VVByVq.VVfRxf(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVJ4VL.append((item, item))
    if not VVJ4VL and chName:
     VVJ4VL.append((chName, chName))
    FFdrYz(self, boundFunction(self.VVpsvi_partOfName, title), title="Words from Current Selection", VVJ4VL=VVJ4VL)
   else:
    VVByVq.VVq6Qj("Invalid Channel Name")
  else:
   words, asPrefix = CCQuuR.VVaZUu(words)
   if not words and mode in (self.VVJd3q, self.VVskAj):
    FFtMdo(self.VVByVq, "Incorrect filter", 2000)
   else:
    FFobhC(self.VVByVq, boundFunction(self.VVLgnW, mode=mode, words=words, asPrefix=asPrefix, title=title), clearMsg=False, title="Filtering ...")
 def VVpsvi_partOfName(self, title, word=None):
  if word:
   words = [word.lower()]
   FFobhC(self.VVByVq, boundFunction(self.VVLgnW, self.VVpEl0, words=words, asPrefix=False, title=title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVehI9(txt):
  return "#f#11ffff00#" + txt
 def VVLgnW(self, mode, words, asPrefix, title):
  VVhCPI = self.VV1L9d(mode=mode, words=words, asPrefix=asPrefix)
  if VVhCPI : self.VVByVq.VVzmZc(VVhCPI, title)
  else  : self.VVByVq.VVq6Qj("Not found")
 def VV1L9d(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  if isStripChan: pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : pattern = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(.+)\n#DESCRIPTION\s+(.+)"
  VVhCPI = []
  files  = self.VVe9Em()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFWaDF(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVz7Hn = span.group(1)
    else : VVz7Hn = ""
    VVz7Hn_lCase = VVz7Hn.lower()
    for match in iFinditer(pattern, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVB1fn(chName): chNameMod = self.VVehI9(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVz7Hn, chType, refCode, url)
     ok = False
     tUrl = FFxPTY(url).lower()
     if mode == self.VVbgvJ       : ok = True
     elif mode == self.VV1y4r       : ok = True
     elif mode == self.VVlBrz:
      if CCmV60.VVxXhs(tUrl, getAudVid=True) == "vid": ok = True
     elif mode == self.VVmZqG:
      if CCmV60.VVxXhs(tUrl, getAudVid=True) == "aud": ok = True
     elif mode == self.VVARF0:
      if CCmV60.VVxXhs(tUrl, compareType="live")  : ok = True
     elif mode == self.VVkW4V:
      if CCmV60.VVxXhs(tUrl, compareType="movie") : ok = True
     elif mode == self.VVDiQT:
      if CCmV60.VVxXhs(tUrl, compareType="series") : ok = True
     elif mode == self.VVw2ao:
      if CCmV60.VVxXhs(tUrl, compareType="")   : ok = True
     elif mode == self.VV6Hz2:
      if CCmV60.VVxXhs(tUrl, compareExt="mkv")  : ok = True
     elif mode == self.VVIbaA:
      if CCmV60.VVxXhs(tUrl, compareExt="mp4")  : ok = True
     elif mode == self.VVLHbp:
      if CCmV60.VVxXhs(tUrl, compareExt="mp3")  : ok = True
     elif mode == self.VVkfE3:
      if CCmV60.VVxXhs(tUrl, compareExt="avi")  : ok = True
     elif mode == self.VV9ppd:
      if CCmV60.VVxXhs(tUrl, compareExt="flv")  : ok = True
     elif mode == self.VVIy1x:
      if chName.lower().startswith(words[0]):
       ok = True
     elif mode == self.VVpEl0:
      if words[0] in chName.lower():
       ok = True
     elif mode == self.VVdiYd:
      span = iSearch(r"[^\x00-\x7F]", chName, IGNORECASE)
      if span:
       ok = True
     elif mode == self.VVJd3q:
      if words[0] == VVz7Hn_lCase:
       ok = True
     elif mode == self.VVskAj:
      name = chName.lower()
      for word in words:
       if asPrefix:
        if name.startswith(word):
         ok = True
         break
       elif word in name:
        ok = True
        break
     if ok:
      VVhCPI.append(row)
      chNum += 1
  if VVhCPI and mode == self.VV1y4r:
   from collections import Counter
   newRows = []
   counted  = Counter(elem[4] for elem in VVhCPI)
   for item in VVhCPI:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   VVhCPI = newRows
  return VVhCPI
 def VVXk4O(self, bName):
  if bName:
   FFobhC(self.VVByVq, boundFunction(self.VVIiGZ, bName), title="Adding Channels ...")
 def VVIiGZ(self, bName):
  num = 0
  path = VVYYh9 + "userbouquet.%s.tv" % bName
  while fileExists(path):
   num += 1
   path = VVYYh9 + "userbouquet.%s_%d.tv" % (bName, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for row in self.VVByVq.VVfKVc():
    f.write("#SERVICE %s\n"  % (row[4] + row[5]))
    f.write("#DESCRIPTION %s\n" % FFWYHc(row[1]))
    totChange += 1
  FFv9Xh(os.path.basename(path))
  self.VV93Vw(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVGbO9(self):
  txt = "Stream Type "
  VVJ4VL = []
  VVJ4VL.append(('%s 1      ( DVB Stream )'  % txt , "RT_1" ))
  VVJ4VL.append(('%s 4097 ( servicemp3 )'  % txt , "RT_4097" ))
  VVJ4VL.append(('%s 5001 ( GST Player )'  % txt , "RT_5001" ))
  VVJ4VL.append(('%s 5002 ( Ext-3 EPlayer )' % txt , "RT_5002" ))
  VVJ4VL.append(('%s 8192 ( HDMI input )'  % txt , "RT_8192" ))
  VVJ4VL.append(('%s 8193 ( eServiceUri )'  % txt , "RT_8193" ))
  FFdrYz(self, self.VVOFyf, title="Change Reference Types to:", VVJ4VL=VVJ4VL)
 def VVOFyf(self, item=None):
  if item:
   if   item == "RT_1"  : self.VVts0F("1"   )
   elif item == "RT_4097" : self.VVts0F("4097")
   elif item == "RT_5001" : self.VVts0F("5001")
   elif item == "RT_5002" : self.VVts0F("5002")
   elif item == "RT_8192" : self.VVts0F("8192")
   elif item == "RT_8193" : self.VVts0F("8193")
 def VVts0F(self, rType):
  FFJWhD(self, boundFunction(FFobhC, self, boundFunction(self.VVyj4P, rType), title="Changing Type ...")
    , "Change to : %s ?" % rType, title="Change ALL Reference Types")
 def VVyj4P(self, refType):
  totChange = 0
  files  = self.VVe9Em()
  if files:
   for path in files:
    txt = FFWaDF(path)
    txt, tot = iSubn(r"(#SERVICE)\s+([A-Fa-f0-9]+[:])(.+)", r"\1 %s:\3" % refType, txt, flags=IGNORECASE)
    if tot:
     totChange += tot
     with open(path, "w") as f:
      f.write(txt)
   FFv9Xh(os.path.basename(path))
  self.VV93Vw(totChange > 0, 'Change Ref. Codes to "%s"' % refType, "Changes = %d  (including Markers)" % totChange)
 def VVpmht(self):
  totFiles = 0
  files  = self.VVe9Em()
  if files:
   totFiles = len(files)
  totChans = 0
  VVhCPI = self.VV1L9d()
  if VVhCPI:
   totChans = len(VVhCPI)
  FFzRpw(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVObc6(self):
  files  = self.VVe9Em()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFWaDF(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVx2Y8
   else    : color = VVpKeT
   totInvalid = FF2tuT(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FF2tuT("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFzRpw(self, txt, title="Check IPTV References")
 def VVpxKB(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  path  = VVYYh9 + userBName
  chPrefix = "Testing RType "
  rTypeList = ("1", "4097", "5001", "5002", "8192", "8193")
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   for rType in (rTypeList):
    chName = "%s%s" % (chPrefix, rType)
    url  = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:%s" % (rType, chName)
    f.write("#SERVICE %s\n" % (url))
    f.write("#DESCRIPTION %s\n" % chName)
  FFv9Xh(os.path.basename(path))
  FFWjYU()
  acceptedList = []
  VV0Y3S = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VV0Y3S:
   VVuyJz = FFhmEb(VV0Y3S)
   if VVuyJz:
    for service in VVuyJz:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVYYh9 + userBName
  bFile = VVYYh9 + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFps7R("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFps7R("rm -f '%s'" % path)
  os.system(cmd)
  FFWjYU()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = "" #"Accepted Types:\n"
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVx2Y8
    else     : res, color = "No" , VVpKeT
    txt += "    %s\t: %s\n" % (item, FF2tuT(res, color))
   FFzRpw(self, txt, title=title)
  else:
   txt = FFBAp7(self, "Could not complete the test on your system!", title=title)
 def VVqUCm(self):
  lameDbChans = CCqgtV.VVxFIz(self, CCqgtV.VV2Ie6)
  if lameDbChans:
   totChannels = 0
   totChange = 0
   for path in self.VVe9Em():
    toSave = False
    txt = FFWaDF(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = lameDbChans.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VV93Vw(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFBAp7(self, 'No channels in "lamedb" !')
 def VVrJ3t(self):
  files  = self.VVe9Em()
  totChange = 0
  SID, TSID, ONID, NS = 0, 0, 0, 0
  if files:
   for path in files:
    lines = FFHvYZ(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      SID, TSID, ONID, NS = self.VV1t5w(SID, TSID, ONID, NS)
      newRC = "%s:%s:%s:%s:0:0:0:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:])
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % newRC, line, IGNORECASE)
      if tot > 0:
       lines[ndx] = txt
       toSave  = True
       totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VV93Vw(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VVdLjN(self):
  iptvRefList = []
  files  = self.VVe9Em()
  if files:
   for path in files:
    txt = FFWaDF(path)
    list = iFindall(r"#SERVICE\s+((?:[A-Fa-f0-9]+[:]){10}).+", txt, IGNORECASE)
    txt = ""
    if list:
     iptvRefList += list
  uniqueRcList = []
  tableRefList = self.VVByVq.VV443b(4)
  SID, TSID, ONID, NS = 1, 1, 0, 0
  if tableRefList:
   for refCode in tableRefList:
    if refCode.count(":") > 8:
     parts = refCode.split(":")
     while True:
      SID, TSID, ONID, NS = self.VV1t5w(SID, TSID, ONID, NS)
      newRC = ":".join(parts[:3]) + ( ":%s:%s:%s:%s:" % (hex(SID)[2:], hex(TSID)[2:], hex(ONID)[2:], hex(NS)[2:]) ) + ":".join(parts[7:])
      newRC = newRC.upper()
      if not newRC in iptvRefList:
       uniqueRcList.append((refCode, newRC))
       break
  iptvRefList = ""
  totChange = 0
  SID, TSID, ONID, NS = 1, 0, 0, 0
  ndx = 0
  files = self.VVe9Em()
  if files:
   for path in files:
    lines = FFHvYZ(path, keepends=True)
    toSave = False
    txt = ""
    for line in lines:
     for ndxTuple, rcTuple in enumerate(uniqueRcList):
      if rcTuple[0] in line.upper():
       line, tot = iSubn(rcTuple[0], rcTuple[1], line, flags=IGNORECASE)
       if tot > 0:
        totChange += 1
        uniqueRcList.pop(ndxTuple)
        toSave = True
        break
     txt += line
    if toSave and txt:
     with open(path, "w") as f:
      f.write(txt)
  self.VV93Vw(totChange > 0, "Change to Unique Ref. Codes", "Changes = %d" % totChange)
 def VV1t5w(self, SID, TSID, ONID, NS):
  MAX = 65535
  SID += 1
  if SID > MAX:
   SID = 0
   TSID += 1
   if TSID > MAX:
    TSID = 0
    ONID += 1
    if ONID > MAX:
     ONID = 0
     NS += 1
     if NS > 4294967295:
      NS = 0
  return SID, TSID, ONID, NS
 def VVidI0(self):
  list = None
  if self.VVByVq:
   list = []
   for row in self.VVByVq.VVfKVc():
    list.append(row[4] + row[5])
  files  = self.VVe9Em()
  totChange = 0
  if files:
   for path in files:
    lines = FFHvYZ(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines))
  self.VV93Vw(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VV93Vw(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFWjYU()
   if refreshTable and self.VVByVq:
    VVhCPI = self.VV1L9d()
    if VVhCPI and self.VVByVq:
     self.VVByVq.VVzmZc(VVhCPI, self.tableTitle)
     self.VVByVq.VVq6Qj(txt)
   FFzRpw(self, txt, title=title)
  else:
   FFSzHX(self, "No changes.")
 def VVtURh(self):
  files = self.VVe9Em()
  bNames = []
  if files:
   fileBNames = set()
   for path in files:
    with ioOpen(path, "r", encoding="utf-8") as f:
     span = iSearch(r"#NAME\s+(.*)", str(f.readline()), IGNORECASE)
     if span:
      fileBNames.add(span.group(1))
   sysBNames = set()
   if fileBNames:
    for b in FF1OCM():
     sysBNames.add(b[0])
   if sysBNames:
    for name in fileBNames:
     name = name.strip()
     if name in sysBNames:
      bNames.append(name)
  return bNames
 def VVe9Em(self):
  return CCmV60.VVqhRn(self)
 @staticmethod
 def VVqhRn(SELF, atLeastOne=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVYYh9 + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFWaDF(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVShmE(self, VVByVq, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFxPTY(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFnMVC(self, fncMode=CCipRP.VVvTs7, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VV9adj(self, VVByVq, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVSs6v(self, VVByVq, title, txt, colList):
  chName, chUrl = self.VV9adj(VVByVq, colList)
  self.VV4TlS(VVByVq, chName, chUrl, "localIptv")
 def VV80M5(self, mode, VVByVq, colList):
  chName, chUrl, picUrl, refCode = self.VVMwre(mode, colList)
  return chName, chUrl
 def VV5xu7(self, mode, VVByVq, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVMwre(mode, colList)
  self.VV4TlS(VVByVq, chName, chUrl, mode)
 def VV4TlS(self, VVByVq, chName, chUrl, playerFlag):
  chName = FFWYHc(chName)
  if self.VVB1fn(chName):
   FFtMdo(VVByVq, "This is a marker!", 300)
  else:
   FFobhC(VVByVq, boundFunction(self.VVEL7J, VVByVq, chUrl, playerFlag), title="Playing ...")
 def VVEL7J(self, VVByVq, chUrl, playerFlag):
  FFPZFB(self, chUrl, VVhM2K=False)
  self.session.open(CC7tge, portalTableParam=(self, VVByVq, playerFlag))
 @staticmethod
 def VVB1fn(chName):
  mark = ("--", "__", "==", "##",  "**", u"\u2605" * 2)
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVNh6l(self, VVByVq, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self)
  if refCode:
   bName = FFBFyz()
   if "chCode" in origUrl:
    i1 = origUrl.find("mode=")
    i2 = origUrl.find("&end=")
    origUrl = origUrl[i1:i2+6].replace(" ", "%20") + chName
    colDict = { 1:chName, 2:bName, 4:refCode, 5:origUrl }
   else:
    colDict = { 2:bName, 4:refCode, 5:FFU1EP(refCode, origUrl, chName) }
   VVByVq.VVdYA0_partial(colDict, VVqJ5y=True)
 def VV7rrQ(self, m3uMode):
  path = CCmV60.VV6FB1()
  lines = FF5Oes("find %s %s -iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'" % (path, FFebM5(1)))
  if lines:
   lines.sort()
   VVJ4VL = []
   for line in lines:
    VVJ4VL.append((line, line))
   if m3uMode == self.VVU78z:
    title = "Browse Server from M3U URLs"
    VVfXyU = ("All to Playlist", self.VV6a7S)
   else:
    title = "M3U/M3U8 File Browser"
    VVfXyU = None
   OKBtnFnc = boundFunction(self.VVbqra, m3uMode, title)
   VVfRF6  = ("Show Full Path", self.VV34cH)
   VVx8rq = ("Delete File", self.VVEj1z)
   FFdrYz(self, None, title=title, VVJ4VL=VVJ4VL, width=1200, OKBtnFnc=OKBtnFnc, VVfRF6=VVfRF6, VVx8rq=VVx8rq, VVfXyU=VVfXyU)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n\n%s" % path
   FFBAp7(self, 'No ".m3u" files found %s' % txt)
 def VV34cH(self, VVH9sbObj, url):
  FFzRpw(self, url, title="Full Path")
 def VVbqra(self, m3uMode, title, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   if m3uMode == self.VVU78z:
    FFobhC(menuInstance, boundFunction(self.VVQRx4, title, path))
   else:
    FFobhC(menuInstance, boundFunction(self.VVvMVQ, path))
 def VVvMVQ(self, srcPath):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(srcPath))[0]
  txt  = FFWaDF(srcPath)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  groups = set()
  processChanName = CCDgHG()
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, url = cols
   group = self.VV6a6N(propLine, "group-title") or "-"
   if not group == "-" and processChanName.VVdZu6(group):
    groups.add(group)
  VVhCPI = []
  if len(groups) > 0:
   title = "Groups"
   for group in groups:
    VVhCPI.append((group, group))
   VVhCPI.append(("ALL", ""))
   VVhCPI.sort(key=lambda x: x[0].lower())
   VVFhJO = self.VV7QVm
   VV69tn  = ("Select" , boundFunction(self.VV913T, srcPath), [])
   widths   = (100  , 0)
   VV32KX  = (LEFT  , LEFT)
   FFN0i6(self, None, title=title, width= 800, header=None, VV1rg6=VVhCPI, VV32KX=VV32KX, VVDe98=widths, VVwZKv=30, VV69tn=VV69tn, VVFhJO=VVFhJO
     , VVZ7ot="#11110022", VVuutY="#11110022", VV5tqg="#11110022", VVwtgu="#00444400")
  else:
   txt = FFWaDF(srcPath)
   self.VVRQWE(txt, filterGroup="")
 def VV913T(self, srcPath, VVByVq, title, txt, colList):
  group = colList[1]
  txt = FFWaDF(srcPath)
  self.VVRQWE(txt, filterGroup=group)
 def VVRQWE(self, txt, filterGroup=""):
  lst = iFindall(r"#EXTINF:(.+),(.+)\n(.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = "Group : %s" % (filterGroup or "ALL")
  if lst:
   self.session.open(CC1LNl, barTheme=CC1LNl.VVFMDb
       , titlePrefix = "Reading File Lines"
       , fncToRun  = boundFunction(self.VVTkTg, lst, filterGroup)
       , VVS99s = boundFunction(self.VVR6Y2, title, bName))
  else:
   self.VVCnWL("No valid lines found !", title)
 def VVTkTg(self, lst, filterGroup, progBarObj):
  progBarObj.VVx2td = []
  progBarObj.VVXZBN(len(lst))
  processChanName = CCDgHG()
  num = 0
  for cols in lst:
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVjClj(1, True)
   cols = list(map(str.strip, cols))
   propLine, chName, url = cols
   picon = self.VV6a6N(propLine, "tvg-logo")
   group = self.VV6a6N(propLine, "group-title")
   if not filterGroup or filterGroup == group:
    skip = False
    if group and not processChanName.VVdZu6(group) : skip = True
    if chName and not processChanName.VVdZu6(chName): skip = True
    if not skip and progBarObj:
     num += 1
     progBarObj.VVx2td.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
  if progBarObj:
   progBarObj.VVYUI4_forcedUpdate("Loading %d Channels" % len(progBarObj.VVx2td))
 def VVR6Y2(self, title, bName, VVCeEr, VVx2td, threadCounter, threadTotal, threadErr):
  if VVx2td:
   VVFhJO = self.VV7QVm
   VV69tn  = ("Select"    , boundFunction(self.VVDtxV, title) , [])
   VVTRSb = (""     , self.VV0qng         , [])
   VVw8s5 = ("Download PIcons" , self.VV3Yqu        , [])
   VV3Y5Z = ("Options" , boundFunction(self.VVUxgD, 1, "m3Ch", "", bName)  , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VV32KX  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFN0i6(self, None, title=title, header=header, VV1rg6=VVx2td, VV32KX=VV32KX, VVDe98=widths, VVwZKv=28, VV69tn=VV69tn, VVFhJO=VVFhJO, VVTRSb=VVTRSb, VVw8s5=VVw8s5, VV3Y5Z=VV3Y5Z, VVB9Wc=True, searchCol=1
     , VVZ7ot="#0a00192B", VVuutY="#0a00192B", VV5tqg="#0a00192B", VVwtgu="#00000000")
  else:
   self.VVCnWL("No valid lines found !", title)
 def VV3Yqu(self, VVByVq, title, txt, colList):
  self.VVYQR0(VVByVq, "m3u/m3u8")
 def VVXJB9(self, mode, bName, VVByVq, title, txt, colList):
  bNameFile = CCmV60.VV21Ob_forBouquet(bName)
  num  = 0
  path = VVYYh9 + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVYYh9 + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   catID = "33"
   rowNum = 0
   isMulti = VVByVq.VVTa6z
   for ndx, row in enumerate(VVByVq.VVfKVc()):
    chName = row[1].strip()
    url  = row[3].strip()
    chUrl = self.VVHOar(rowNum, url, chName)
    rowNum += 1
    if not isMulti or VVByVq.VVDK6Y(ndx):
     f.write("#SERVICE %s\n"  % chUrl)
     f.write("#DESCRIPTION %s\n" % chName)
     totChange += 1
  FFv9Xh(os.path.basename(path))
  self.VV93Vw(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVHOar(self, rowNum, url, chName):
  refCode = self.VVNCg3(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFrmgH(url), chName)
  return chUrl
 def VVNCg3(self, rowNum, url, chName):
  span = iSearch(r"\/(\d{2,})", url, IGNORECASE)
  if span : stID = span.group(1)
  else : stID = "444"
  catID = "333"
  chNum = str(rowNum + 1)
  refCode = self.VVqrfU(catID, stID, chNum)
  return refCode
 def VV6a6N(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVDtxV(self, Title, VVByVq, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFobhC(VVByVq, boundFunction(self.VVwsaa, Title, VVByVq, colList), title="Checking Server ...")
  else:
   self.VVgT1Y(VVByVq, url, chName)
 def VVwsaa(self, title, VVByVq, colList):
  if not CC7z2E.VVrOnV(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCKdjH.VVT0zt(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVJ4VL = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCmV60.VVkK3C(url, fPath)
     VVJ4VL.append((resol, fullUrl))
    if VVJ4VL:
     if len(VVJ4VL) > 1:
      FFdrYz(self, boundFunction(self.VVL6Kp, VVByVq, chName), VVJ4VL=VVJ4VL, title="Resolution", VVYMy8=True, VVEfaQ=True)
     else:
      self.VVgT1Y(VVByVq, VVJ4VL[0][1], chName)
    else:
     self.VVqJ5yor("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVRQWE(txt, filterGroup="")
      return
    self.VVgT1Y(VVByVq, url, chName)
   else:
    self.VVCnWL("Cannot process this channel !", title)
  else:
   self.VVCnWL(err, title)
 def VVL6Kp(self, VVByVq, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVgT1Y(VVByVq, resolUrl, chName)
 def VVgT1Y(self, VVByVq, url, chName):
  FFobhC(VVByVq, boundFunction(self.VVPyae, VVByVq, url, chName), title="Playing ...")
 def VVPyae(self, VVByVq, url, chName):
  chUrl = self.VVHOar(VVByVq.VVwl1D(), url, chName)
  FFPZFB(self, chUrl, VVhM2K=False)
  self.session.open(CC7tge, portalTableParam=(self, VVByVq, "m3u/m3u8"))
 def VV0gVi(self, VVByVq, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVHOar(VVByVq.VVwl1D(), url, chName)
  return chName, chUrl
 def VV0qng(self, VVByVq, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFnMVC(self, fncMode=CCipRP.VVvTs7, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVCnWL(self, err, title):
  FFBAp7(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VV7QVm(self, VVByVq):
  if self.m3uOrM3u8File:
   self.close()
  VVByVq.cancel()
 def VV6a7S(self, VVH9sbObj, item=None):
  FFobhC(VVH9sbObj, boundFunction(self.VVp3hh, VVH9sbObj, item))
 def VVp3hh(self, VVH9sbObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVH9sbObj.VVJ4VL):
    path = item[1]
    if fileExists(path):
     enc = CCaMcm.VVQpht(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = self.VVIinH(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCmV60.VV6FB1(orExportPath=True)
    pListF = "%sPlaylist_%s.txt" % (path, FFC5od())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVH9sbObj.VVJ4VL)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFzRpw(self, txt, title=title)
   else:
    FFBAp7(self, "Could not obtain URLs from this file list !", title=title)
 def VVuaBh(self):
  path = CCmV60.VV6FB1()
  lines = FF5Oes('find %s %s -iname "*playlist*" | grep -i ".txt"' % (path, FFebM5(1)))
  if lines:
   lines.sort()
   VVJ4VL = []
   for line in lines:
    VVJ4VL.append((line, line))
   OKBtnFnc  = self.VV80q9
   VVx8rq = ("Delete File", self.VVEj1z)
   FFdrYz(self, None, title="Select Playlist File", VVJ4VL=VVJ4VL, width=1200, OKBtnFnc=OKBtnFnc, VVx8rq=VVx8rq)
  else:
   if path == "/" : txt = "!"
   else   : txt = "in :\n%s" % path
   FFBAp7(self, 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt)
 def VV80q9(self, item=None):
  if item:
   menuInstance, txt, path, ndx = item
   FFobhC(menuInstance, boundFunction(self.VVqpsj, menuInstance, path), title="Processing File ...")
 def VVqpsj(self, fileMenuInstance, path):
  enc = CCaMcm.VVQpht(path, self)
  if enc == -1:
   return
  VVhCPI = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0]
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FF5gdy(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCmV60.VV9iE3(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVhCPI:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(filter(None, [item[5], item[0]]))
     num += 1
     VVhCPI.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVhCPI:
   title = "Playlist File : %s" % os.path.basename(path)
   VV69tn  = ("Start"    , boundFunction(self.VV2b2t, "Playlist File"), [])
   VV5uBQ = ("Home Menu"   , FFAu6q          , [])
   VVw8s5 = ("Download M3U File" , self.VVOput      , [])
   VV3Y5Z = ("Edit File"   , boundFunction(self.VV4byU, path)  , [])
   VVGv9L = ("Check & Filter"  , boundFunction(self.VVoDsI, fileMenuInstance, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VV32KX  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFN0i6(self, None, title=title, header=header, VV1rg6=VVhCPI, VV32KX=VV32KX, VVDe98=widths, VVwZKv=26, VV69tn=VV69tn, VV5uBQ=VV5uBQ, VVGv9L=VVGv9L, VVw8s5=VVw8s5, VV3Y5Z=VV3Y5Z, VVZ7ot="#11001116", VVuutY="#11001116", VV5tqg="#11001116", VVwtgu="#00003635", VVorfQ="#0a333333", VV1sri="#11331100", VVB9Wc=True)
  else:
   FFBAp7(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVOput(self, VVByVq, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFJWhD(self, boundFunction(FFobhC, VVByVq, boundFunction(self.VV010x, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VV010x(self, title, url):
  path, err = FFSgzY(url, "ajpanel_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFBAp7(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFWaDF(path)
   if '{"user_info":{"auth":0}}' in txt:
    os.system(FFps7R("rm -f '%s'" % path))
    FFBAp7(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    os.system(FFps7R("rm -f '%s'" % path))
    FFBAp7(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCmV60.VV6FB1(orExportPath=True) + fName
    os.system(FFps7R("mv -f '%s' '%s'" % (path, newPath)))
    if fileExists(newPath):
     path = newPath
    FFSzHX(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFBAp7(self, "Could not download the M3U file!", title=errTitle)
 def VV2b2t(self, Title, VVByVq, title, txt, colList):
  url = colList[6]
  FFobhC(VVByVq, boundFunction(self.VV1eQ1, Title, url), title="Checking Server ...")
 def VV4byU(self, path, VVByVq, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CC0hs4(self, path, VVS99s=boundFunction(self.VVSKhZ, VVByVq), curRowNum=rowNum)
  else    : FFhMRQ(self, path)
 def VVSKhZ(self, VVByVq, fileChanged):
  if fileChanged:
   VVByVq.cancel()
 def VV90d0(self, title):
  curChName = self.VVByVq.VVfRxf(1)
  FFIilI(self, boundFunction(self.VVbzYr, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVbzYr(self, title, name):
  if name:
   lameDbChans = CCqgtV.VVxFIz(self, CCqgtV.VVrMwQ, VVO5r1=False, VVaKKN=False)
   list = []
   if lameDbChans:
    processChanName = CCDgHG()
    name = processChanName.VVFNHE(name)
    ratio = "1"
    for item in lameDbChans:
     if name in item[0].lower():
      list.append((item[0], FFEeIv(item[2]), item[3], ratio))
   if list : self.VVbwAs(list, title)
   else : FFBAp7(self, "Not found:\n\n%s" % name, title=title)
 def VVpvBi(self, title):
  curChName = self.VVByVq.VVfRxf(1)
  self.session.open(CC1LNl, barTheme=CC1LNl.VVFMDb
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVd1hO
      , VVS99s = boundFunction(self.VVLO5K, title, curChName))
 def VVd1hO(self, progBarObj):
  curChName = self.VVByVq.VVfRxf(1)
  lameDbChans = CCqgtV.VVxFIz(self, CCqgtV.VVehSi, VVO5r1=False, VVaKKN=False)
  if not lameDbChans or not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVx2td = []
  progBarObj.VVXZBN(len(lameDbChans))
  processChanName = CCDgHG()
  curCh = processChanName.VVFNHE(curChName)
  for refCode in lameDbChans:
   chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
   ratio = CCYaR2.VV3co7(chName.lower(), curCh)
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVjClj(1, True)
   if progBarObj and ratio > 50:
    progBarObj.VVx2td.append((chName, FFEeIv(sat), refCode.replace("_", ":"), str(ratio)))
 def VVLO5K(self, title, curChName, VVCeEr, VVx2td, threadCounter, threadTotal, threadErr):
  if VVx2td: self.VVbwAs(VVx2td, title)
  elif VVCeEr: FFBAp7(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVbwAs(self, VVhCPI, title):
  curChName = self.VVByVq.VVfRxf(1)
  curRefCode = self.VVByVq.VVfRxf(4)
  curUrl  = self.VVByVq.VVfRxf(5)
  VVhCPI = sorted(VVhCPI, key=lambda x: (100-int(x[3]), x[0].lower()))
  VV69tn  = ("Share Sat/C/T Ref.", boundFunction(self.VVrtFY, title, curChName, curRefCode, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFN0i6(self, None, title=title, header=header, VV1rg6=VVhCPI, VVDe98=widths, VVwZKv=26, VV69tn=VV69tn, VVZ7ot="#0a00112B", VVuutY="#0a001126", VV5tqg="#0a001126", VVwtgu="#00000000")
 def VVrtFY(self, newtitle, curChName, curRefCode, curUrl, VVByVq, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, curRefCode, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFJWhD(self.VVByVq, boundFunction(FFobhC, self.VVByVq, boundFunction(self.VVXWSb, VVByVq, data)), ques, title=newtitle, VVIDtV=True)
 def VVXWSb(self, VVByVq, data):
  VVByVq.cancel()
  title, curChName, curRefCode, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  curRefCode = curRefCode.strip()
  newRefCode = newRefCode.strip()
  if not curRefCode.endswith(":") : curRefCode += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", curRefCode, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = curRefCode + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in self.VVe9Em():
    txt = FFWaDF(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFWjYU()
    newRow = []
    for i in range(6):
     newRow.append(self.VVByVq.VVfRxf(i))
    newRow[4] = newRefCode
    done = self.VVByVq.VVFmzh(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFOFIS(boundFunction(FFSzHX , self, resTxt, title=title))
  elif resErr: FFOFIS(boundFunction(FFBAp7 , self, resErr, title=title))
 def VVoDsI(self, fileMenuInstance, path, VVByVq, title, txt, colList):
  self.session.open(CC1LNl, barTheme=CC1LNl.VVLvJ7
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = boundFunction(self.VV0BKH, VVByVq)
      , VVS99s = boundFunction(self.VVolLO, fileMenuInstance, path, VVByVq))
 def VV0BKH(self, VVByVq, progBarObj):
  progBarObj.VVXZBN(VVByVq.VVlbt7())
  progBarObj.VVx2td = []
  for row in VVByVq.VVfKVc():
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVjClj(1, True)
   qUrl = self.VVdEXl(self.VVAvmz, row[6])
   txt, err = self.VVI40b(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVVFIA(item, "auth") == "0":
       progBarObj.VVx2td.append(qUrl)
    except:
     pass
 def VVolLO(self, fileMenuInstance, path, VVByVq, VVCeEr, VVx2td, threadCounter, threadTotal, threadErr):
  if VVCeEr:
   list = VVx2td
   title = "Authorized Servers"
   if list:
    totChk = VVByVq.VVlbt7()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFC5od()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVuaBh()
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FF2tuT(str(totAuth), VVx2Y8)
     txt += "%s\n\n%s"    %  (FF2tuT("Result File:", COLOR_CONS_BRIGHT_YELLOW), newPath)
     FFzRpw(self, txt, title=title)
     VVByVq.close()
     fileMenuInstance.close()
    else:
     FFSzHX(self, "All URLs are authorized.", title=title)
   else:
    FFBAp7(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVI40b(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   cont = res.headers.get("Content-Type")
   if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
    return "", "Unexpected server data type ( %s )" % cont
   res = res.read().decode("UTF-8")
   if res:
    if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server !"
    else           : return res, ""
   else:
    return "", ""
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VV9iE3(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVxXhs(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) > 2:
   username = parts[0]
   password = parts[1]
   tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  parts = fileName.split(".")
  if len(parts) > 1: streamId, ext = parts[0], parts[1]
  else    : streamId, ext = parts[0], ""
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    if ext in ("avi", "flv", "h264", "h265", "m2ts", "m4v", "mjpeg", "mk3d", "mks", "mkv", "mov", "mp4", "mpg", "mts", "vob", "webm", "wmv", "xvid"):
     return "vid"
    elif ext in ("aac", "ac3", "m3u", "m4a", "m4b", "m4p", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "wav", "wma", "wpl"):
     return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
   username = ""
   password = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 def VVdEXl(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VV9iE3(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVAvmz   : return "%s"            % url
  elif mode == self.VVkEVz   : return "%s&action=get_live_categories"     % url
  elif mode == self.VV96AI   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVaKzY  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVomyW  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVxBNH : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVaXq9   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVFRmD    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVCEw7  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVr7O5 : return "%s&action=get_live_streams"      % url
  elif mode == self.VVsSqp  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVVFIA(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FF78kj(int(val))
    elif is_base64 : val = FFQ0GA(val)
    elif isToHHMMSS : val = FFi4q2(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVQRx4(self, title, path):
  if fileExists(path):
   enc = CCaMcm.VVQpht(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = self.VVIinH(line)
     if qUrl:
      break
   if qUrl : self.VV1eQ1(title, qUrl)
   else : FFBAp7(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFBAp7(self, "Cannot open file :\n\n%s" % path, title=title)
 def VVZybC_fromCurrChan(self):
  title = "Current Channel Server"
  qUrl, iptvRef = self.VVmCEG()
  if qUrl or "chCode" in iptvRef:
   p = CCKdjH()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, query = p.VVWAZY(iptvRef)
   if valid:
    self.VVZybC(self, host, mac)
    return
   elif qUrl:
    FFobhC(self, boundFunction(self.VV1eQ1, title, qUrl), title="Checking Server ...")
    return
  FFBAp7(self, "Error in current channel URL !", title=title)
 def VVmCEG(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self)
  qUrl = self.VVIinH(decodedUrl)
  return qUrl, iptvRef
 def VVIinH(self, url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VV1eQ1(self, title, url):
  self.VVdMeJData = {}
  qUrl = self.VVdEXl(self.VVAvmz, url)
  txt, err = self.VVI40b(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVdMeJData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVdMeJData["username"    ] = self.VVVFIA(item, "username"        )
    self.VVdMeJData["password"    ] = self.VVVFIA(item, "password"        )
    self.VVdMeJData["message"    ] = self.VVVFIA(item, "message"        )
    self.VVdMeJData["auth"     ] = self.VVVFIA(item, "auth"         )
    self.VVdMeJData["status"    ] = self.VVVFIA(item, "status"        )
    self.VVdMeJData["exp_date"    ] = self.VVVFIA(item, "exp_date"    , isDate=True )
    self.VVdMeJData["is_trial"    ] = self.VVVFIA(item, "is_trial"        )
    self.VVdMeJData["active_cons"   ] = self.VVVFIA(item, "active_cons"       )
    self.VVdMeJData["created_at"   ] = self.VVVFIA(item, "created_at"   , isDate=True )
    self.VVdMeJData["max_connections"  ] = self.VVVFIA(item, "max_connections"      )
    self.VVdMeJData["allowed_output_formats"] = self.VVVFIA(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVdMeJData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVdMeJData["url"    ] = self.VVVFIA(item, "url"        )
    self.VVdMeJData["port"    ] = self.VVVFIA(item, "port"        )
    self.VVdMeJData["https_port"  ] = self.VVVFIA(item, "https_port"      )
    self.VVdMeJData["server_protocol" ] = self.VVVFIA(item, "server_protocol"     )
    self.VVdMeJData["rtmp_port"   ] = self.VVVFIA(item, "rtmp_port"       )
    self.VVdMeJData["timezone"   ] = self.VVVFIA(item, "timezone"       )
    self.VVdMeJData["timestamp_now"  ] = self.VVVFIA(item, "timestamp_now"  , isDate=True )
    self.VVdMeJData["time_now"   ] = self.VVVFIA(item, "time_now"       )
    VVJ4VL  = self.VVxbqK(True)
    OKBtnFnc = self.VVdMeJOptions
    VVzYgB = ("Home Menu", FFAu6q)
    VVfXyU = ("Bookmark Server", boundFunction(CCmV60.VVIzP6, self, False, self.VVdMeJData["playListURL"]))
    FFdrYz(self, None, title="IPTV Server Resources", VVJ4VL=VVJ4VL, OKBtnFnc=OKBtnFnc, VVzYgB=VVzYgB, VVfXyU=VVfXyU)
   else:
    err = "Could not get data from server !"
  if err:
   FFBAp7(self, err, title=title)
  FFtMdo(self)
 def VVdMeJOptions(self, item=None):
  if item:
   menuInstance, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFobhC(menuInstance, boundFunction(self.VVgUTD, self.VVkEVz  , title=title), title=wTxt)
   elif ref == "vod"   : FFobhC(menuInstance, boundFunction(self.VVgUTD, self.VV96AI  , title=title), title=wTxt)
   elif ref == "series"  : FFobhC(menuInstance, boundFunction(self.VVgUTD, self.VVaKzY , title=title), title=wTxt)
   elif ref == "catchup"  : FFobhC(menuInstance, boundFunction(self.VVgUTD, self.VVomyW , title=title), title=wTxt)
   elif ref == "accountInfo" : FFobhC(menuInstance, boundFunction(self.VVDqgK           , title=title), title=wTxt)
 def VVDqgK(self, title):
  rows = []
  for key, val in self.VVdMeJData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.colored_server
   else:
    num, part = "1", self.colored_user
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows = sorted(rows, key=lambda x: (x[0], x[2]))
  VV5uBQ  = ("Home Menu", FFAu6q, [])
  VVw8s5  = None
  if VVgFen:
   VVw8s5 = ("Get JS" , boundFunction(self.VVdcfh, "/".join(self.VVdMeJData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFN0i6(self, None, title=title, width=1200, header=header, VV1rg6=rows, VVDe98=widths, VVwZKv=26, VV5uBQ=VV5uBQ, VVw8s5=VVw8s5, VVZ7ot="#0a00292B", VVuutY="#0a002126", VV5tqg="#0a002126", VVwtgu="#00000000", searchCol=2)
 def VV9kct(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    processChanName = CCDgHG()
    if mode in (self.VVaXq9, self.VVsSqp):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVVFIA(item, "num"         )
      name     = self.VVVFIA(item, "name"        )
      stream_id    = self.VVVFIA(item, "stream_id"       )
      stream_icon    = self.VVVFIA(item, "stream_icon"       )
      epg_channel_id   = self.VVVFIA(item, "epg_channel_id"      )
      added     = self.VVVFIA(item, "added"    , isDate=True )
      is_adult    = self.VVVFIA(item, "is_adult"       )
      category_id    = self.VVVFIA(item, "category_id"       )
      tv_archive    = self.VVVFIA(item, "tv_archive"       )
      name = processChanName.VVdZu6(name)
      if name:
       if mode == self.VVaXq9 or mode == self.VVsSqp and tv_archive == "1":
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult))
    elif mode == self.VVFRmD:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVVFIA(item, "num"         )
      name    = self.VVVFIA(item, "name"        )
      stream_id   = self.VVVFIA(item, "stream_id"       )
      stream_icon   = self.VVVFIA(item, "stream_icon"       )
      added    = self.VVVFIA(item, "added"    , isDate=True )
      is_adult   = self.VVVFIA(item, "is_adult"       )
      category_id   = self.VVVFIA(item, "category_id"       )
      container_extension = self.VVVFIA(item, "container_extension"     ) or "mp4"
      name = processChanName.VVdZu6(name)
      if name:
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension))
    elif mode == self.VVCEw7:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVVFIA(item, "num"        )
      name    = self.VVVFIA(item, "name"       )
      series_id   = self.VVVFIA(item, "series_id"      )
      cover    = self.VVVFIA(item, "cover"       )
      genre    = self.VVVFIA(item, "genre"       )
      episode_run_time = self.VVVFIA(item, "episode_run_time"    )
      category_id   = self.VVVFIA(item, "category_id"      )
      container_extension = self.VVVFIA(item, "container_extension"    ) or "mp4"
      name = processChanName.VVdZu6(name)
      if name:
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVgUTD(self, mode, title):
  cList, err = self.VVnos4(mode)
  if cList and mode == self.VVomyW:
   cList = self.VV6in4(cList)
  if err:
   FFBAp7(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVZ7ot, VVuutY, VV5tqg, VVwtgu = self.VVh44S(mode)
   mName = self.VVEOd3(mode)
   if   mode == self.VVkEVz  : fMode = self.VVaXq9
   elif mode == self.VV96AI  : fMode = self.VVFRmD
   elif mode == self.VVaKzY : fMode = self.VVCEw7
   elif mode == self.VVomyW : fMode = self.VVsSqp
   if mode == self.VVomyW:
    VV3Y5Z = None
   else:
    VV3Y5Z = ("Find in %s" % mName , boundFunction(self.VVITBn, fMode) , [])
   VV69tn   = ("Show List"   , boundFunction(self.VVfHmy, mode) , [])
   VV5uBQ  = ("Home Menu"   , FFAu6q          , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFN0i6(self, None, title=title, width=1200, header=header, VV1rg6=cList, VVDe98=widths, VVwZKv=30, VV5uBQ=VV5uBQ, VV3Y5Z=VV3Y5Z, VV69tn=VV69tn, VVZ7ot=VVZ7ot, VVuutY=VVuutY, VV5tqg=VV5tqg, VVwtgu=VVwtgu)
  else:
   FFBAp7(self, "No list from server !", title=title)
  FFtMdo(self)
 def VVnos4(self, mode):
  qUrl  = self.VVdEXl(mode, self.VVdMeJData["playListURL"])
  txt, err = self.VVI40b(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    processChanName = CCDgHG()
    for item in tDict:
     category_id  = self.VVVFIA(item, "category_id"  )
     category_name = self.VVVFIA(item, "category_name" )
     parent_id  = self.VVVFIA(item, "parent_id"  )
     category_name = processChanName.VVJwF7(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VV6in4(self, catList):
  mode  = self.VVsSqp
  qUrl  = self.VVdEXl(mode, self.VVdMeJData["playListURL"])
  txt, err = self.VVI40b(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VV9kct(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVfHmy(self, mode, VVByVq, title, txt, colList):
  title = colList[1]
  FFobhC(VVByVq, boundFunction(self.VVSxEm, mode, VVByVq, title, txt, colList), title="Downloading ...")
 def VVSxEm(self, mode, VVByVq, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVEOd3(mode) + " : "+ bName
  if   mode == self.VVkEVz  : mode = self.VVaXq9
  elif mode == self.VV96AI  : mode = self.VVFRmD
  elif mode == self.VVaKzY : mode = self.VVCEw7
  elif mode == self.VVomyW : mode = self.VVsSqp
  qUrl  = self.VVdEXl(mode, self.VVdMeJData["playListURL"], catID)
  txt, err = self.VVI40b(qUrl)
  list  = []
  if not err and mode in (self.VVaXq9, self.VVFRmD, self.VVCEw7, self.VVsSqp):
   list, err = self.VV9kct(mode, txt)
  if err:
   FFBAp7(self, err, title=title)
  elif list:
   VV5uBQ  = ("Home Menu"   , FFAu6q             , [])
   if mode in (self.VVaXq9, self.VVsSqp):
    VVZ7ot, VVuutY, VV5tqg, VVwtgu = self.VVh44S(mode)
    VVTRSb = (""     , boundFunction(self.VVkjZn, mode)     , [])
    VVw8s5 = ("Download Options" , boundFunction(self.VVzdL6, mode, "", "")  , [])
    VV3Y5Z = ("Options" , boundFunction(self.VVUxgD, 1, "lv", mode, bName)  , [])
    if mode == self.VVaXq9:
     VV69tn = ("Play"    , boundFunction(self.VV5xu7, mode)     , [])
    elif mode == self.VVsSqp:
     VV69tn  = ("Programs", boundFunction(self.VVZbpP_fromIptvTable, mode, bName) , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult")
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0   )
    VV32KX  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER )
   elif mode == self.VVFRmD:
    VVZ7ot, VVuutY, VV5tqg, VVwtgu = self.VVh44S(mode)
    VV69tn  = ("Play"    , boundFunction(self.VV5xu7, mode)    , [])
    VVTRSb = (""     , boundFunction(self.VVkjZn, mode)    , [])
    VVw8s5 = ("Download Options" , boundFunction(self.VVzdL6, mode, "v", ""), [])
    VV3Y5Z = ("Options" , boundFunction(self.VVUxgD, 1, "v", mode, bName)  , [])
    header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" )
    widths   = (8  , 66  , 0   , 0   , 0  , 26  , 0   , 0  )
    VV32KX  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER)
   elif mode == self.VVCEw7:
    VVZ7ot, VVuutY, VV5tqg, VVwtgu = self.VVh44S("series2")
    VV69tn  = ("Show Seasons", boundFunction(self.VVfYBI, mode) , [])
    VVTRSb = ("", boundFunction(self.VVq40f, mode)  , [])
    VVw8s5 = None
    VV3Y5Z = None
    header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" )
    widths   = (8  , 62  , 0   , 0   , 30  , 0  , 0  , 0   )
    VV32KX  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  )
   FFN0i6(self, None, title=title, header=header, VV1rg6=list, VV32KX=VV32KX, VVDe98=widths, VVwZKv=26, VV69tn=VV69tn, VV5uBQ=VV5uBQ, VVw8s5=VVw8s5, VV3Y5Z=VV3Y5Z, VVTRSb=VVTRSb, VVZ7ot=VVZ7ot, VVuutY=VVuutY, VV5tqg=VV5tqg, VVwtgu=VVwtgu, VVB9Wc=True, searchCol=1)
  else:
   FFBAp7(self, "No Channels found !", title=title)
  FFtMdo(self)
 def VVZbpP_fromIptvTable(self, mode, bName, VVByVq, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVdMeJData["playListURL"]
  ok_fnc  = boundFunction(self.VVr5rq, hostUrl, chName, catId, streamId)
  FFobhC(VVByVq, boundFunction(CCmV60.VVZbpP, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVr5rq(self, chUrl, chName, catId, streamId, VVByVq, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCmV60.VV9iE3(chUrl)
   chNum = "333"
   refCode = CCmV60.VVqrfU(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFPZFB(self, chUrl, VVhM2K=False)
   self.session.open(CC7tge)
  else:
   FFBAp7(self, "Incorrect Timestamp", pTitle)
 def VVfYBI(self, mode, VVByVq, title, txt, colList):
  title = colList[1]
  FFobhC(VVByVq, boundFunction(self.VVjige, mode, VVByVq, title, txt, colList), title="Downloading ...")
 def VVjige(self, mode, VVByVq, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVdEXl(self.VVxBNH, self.VVdMeJData["playListURL"], series_id)
  txt, err = self.VVI40b(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVVFIA(tDict["info"], "name"   )
      category_id = self.VVVFIA(tDict["info"], "category_id" )
      icon  = self.VVVFIA(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      processChanName = CCDgHG()
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVVFIA(EP, "id"     )
        episode_num   = self.VVVFIA(EP, "episode_num"   )
        epTitle    = self.VVVFIA(EP, "title"     )
        container_extension = self.VVVFIA(EP, "container_extension" )
        seasonNum   = self.VVVFIA(EP, "season"    )
        epTitle = processChanName.VVdZu6(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFBAp7(self, err, title=title)
  elif list:
   VV5uBQ = ("Home Menu"   , FFAu6q             , [])
   VVw8s5 = ("Download Options" , boundFunction(self.VVzdL6, mode, "s", title) , [])
   VV3Y5Z = ("Options" , boundFunction(self.VVUxgD, 0, "s", mode, title)  , [])
   VVTRSb = (""     , boundFunction(self.VVkjZn, mode)     , [])
   VV69tn  = ("Play"    , boundFunction(self.VV5xu7, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VV32KX  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFN0i6(self, None, title=title, header=header, VV1rg6=list, VV32KX=VV32KX, VVDe98=widths, VVwZKv=26, VV5uBQ=VV5uBQ, VVw8s5=VVw8s5, VV69tn=VV69tn, VVTRSb=VVTRSb, VV3Y5Z=VV3Y5Z, VVZ7ot="#0a00292B", VVuutY="#0a002126", VV5tqg="#0a002126", VVwtgu="#00000000")
  else:
   FFBAp7(self, "No Channels found !", title=title)
  FFtMdo(self)
 def VVITBn(self, mode, VVByVq, title, txt, colList):
  VVJ4VL = []
  VVJ4VL.append(("Keyboard"  , "manualEntry"))
  VVJ4VL.append(("From Filter" , "fromFilter"))
  FFdrYz(self, boundFunction(self.VVYC1x, VVByVq, mode), title="Input Type", VVJ4VL=VVJ4VL, width=400)
 def VVYC1x(self, VVByVq, mode, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFIilI(self, boundFunction(self.VVZRG7, VVByVq, mode), defaultText=self.lastFindIptvName, title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCQuuR(self)
    filterObj.VVaSAo(boundFunction(self.VVZRG7, VVByVq, mode))
 def VVZRG7(self, VVByVq, mode, item):
  if item:
   title = "Find in names"
   toFind = item.strip()
   self.lastFindIptvName = toFind
   words = []
   for w in toFind.split(","):
    w = w.strip()
    if w and not w in words:
     words.append(w.lower())
   if words:
    if words[0] == "^" and len(words) > 1:
     asPrefix = True
     words = words[1:]
    else:
     asPrefix = False
    words = tuple(words)
   if words:
    processChanName = CCDgHG()
    if CFG.hideIptvServerAdultWords.getValue() and processChanName.VVsKi4(words):
     FFBAp7(self, processChanName.VVucJo(), title="Find: %s" % " , ".join(words))
    else:
     self.session.open(CC1LNl, barTheme=CC1LNl.VVFMDb
         , titlePrefix = "Searching for:%s" % toFind[:15]
         , fncToRun  = boundFunction(self.VVXsAr, VVByVq, mode, title, words, toFind, asPrefix, processChanName)
         , VVS99s = boundFunction(self.VV1yvG, mode, toFind, title))
   else:
    FFBAp7(self, "Unaccepted name !\n\n( %s )" % toFind, title=title)
 def VVXsAr(self, VVByVq, mode, title, words, toFind, asPrefix, processChanName, progBarObj):
  progBarObj.VVXZBN(VVByVq.VVRjIQ())
  progBarObj.VVx2td = []
  for row in VVByVq.VVfKVc():
   catName = row[0]
   catID = row[1]
   if not progBarObj or progBarObj.isCancelled:
    return
   progBarObj.VVjClj(1)
   progBarObj.VVYUI4_fromIptvFind(catName)
   qUrl  = self.VVdEXl(mode, self.VVdMeJData["playListURL"], catID)
   txt, err = self.VVI40b(qUrl)
   if not err:
    tList, err = self.VV9kct(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = processChanName.VVdZu6(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if mode == self.VVaXq9:
        num, name, catID, ID, Icon, added, epgID, isAdult = item
        progBarObj.VVx2td.append((num, name, catID, ID, Icon, catName, epgID, isAdult))
       elif mode == self.VVFRmD:
        num, name, catID, ID, Icon, added, isAdult, ext = item
        progBarObj.VVx2td.append((num, name, catID, ID, Icon, catName, isAdult, ext))
       elif mode == self.VVCEw7:
        num, name, catID, ID, genre, dur, ext, cover = item
        progBarObj.VVx2td.append((num, name, catID, ID, genre, catName, ext, cover))
 def VV1yvG(self, mode, toFind, title, VVCeEr, VVx2td, threadCounter, threadTotal, threadErr):
  if VVx2td:
   title = self.VVIE3g(mode, toFind)
   if mode == self.VVaXq9 or mode == self.VVFRmD:
    if mode == self.VVFRmD : typ = "v"
    else          : typ = ""
    bName   = CCmV60.VV21Ob_forBouquet(toFind)
    VV69tn  = ("Play"     , boundFunction(self.VV5xu7, mode)    , [])
    VVw8s5 = ("Download Options" , boundFunction(self.VVzdL6, mode, typ, ""), [])
    VV3Y5Z = ("Options" , boundFunction(self.VVUxgD, 1, "fnd", mode, bName)  , [])
   elif mode == self.VVCEw7:
    VV69tn  = ("Show Seasons"  , boundFunction(self.VVfYBI, mode)    , [])
    VV3Y5Z = None
    VVw8s5 = None
   VVTRSb  = (""     , boundFunction(self.VVkjZn, mode)    , [])
   VV5uBQ  = ("Home Menu"   , FFAu6q            , [])
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Category", "isAdult" , "Ext" )
   widths   = (8  , 57  , 0   , 0   , 0  , 35  , 0   , 0  )
   VV32KX  = (CENTER, LEFT  , CENTER , CENTER, LEFT , LEFT  , CENTER , CENTER)
   VVByVq = FFN0i6(self, None, title=title, header=header, VV1rg6=VVx2td, VV32KX=VV32KX, VVDe98=widths, VVwZKv=26, VV69tn=VV69tn, VV5uBQ=VV5uBQ, VVw8s5=VVw8s5, VV3Y5Z=VV3Y5Z, VVTRSb=VVTRSb, VVZ7ot="#0a00292B", VVuutY="#0a002126", VV5tqg="#0a002126", VVwtgu="#00000000", VVB9Wc=True, searchCol=1)
   if not VVCeEr:
    FFtMdo(VVByVq, "Stopped" , 1000)
  else:
   if VVCeEr:
    FFBAp7(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVMwre(self, mode, colList):
  if mode in (self.VVaXq9, self.VVsSqp):
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = ""
   uCat = ""
  elif mode == self.VVFRmD:
   chNum = colList[0].strip()
   chName = colList[1].strip()
   catID = colList[2].strip()
   stID = colList[3].strip()
   picUrl = colList[4].strip()
   ext  = "." + colList[7].strip()
   uCat = "movie/"
  else:
   chNum = "222"
   chName = colList[2].strip()
   catID = colList[3].strip()
   stID = colList[4].strip()
   picUrl = colList[5].strip()
   ext  = "." + colList[6].strip()
   uCat = "series/"
  chName = FFWYHc(chName)
  url = self.VVdMeJData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VV9iE3(url)
  refCode = self.VVqrfU(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVkjZn(self, mode, VVByVq, title, txt, colList):
  FFobhC(VVByVq, boundFunction(self.VVp3T8, mode, VVByVq, title, txt, colList))
 def VVp3T8(self, mode, VVByVq, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVMwre(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFnMVC(self, fncMode=CCipRP.VV8Ny9, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVq40f(self, mode, VVByVq, title, txt, colList):
  FFobhC(VVByVq, boundFunction(self.VVUdK1, mode, VVByVq, title, txt, colList))
 def VVUdK1(self, mode, VVByVq, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFnMVC(self, fncMode=CCipRP.VVL54a, chName=name, text=txt, picUrl=Cover)
 def VVfvte(self, mode, bName, VVByVq, title, txt, colList):
  url = self.VVdMeJData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VV9iE3(url)
  bNameFile = CCmV60.VV21Ob_forBouquet(bName)
  num  = 0
  path = VVYYh9 + "userbouquet.%s.tv" % bNameFile
  while fileExists(path):
   num += 1
   path = VVYYh9 + "userbouquet.%s_%d.tv" % (bNameFile, num)
  totChange = 0
  with open(path, "w") as f:
   f.write("#NAME %s\n" % bName)
   isMulti = VVByVq.VVTa6z
   for ndx, row in enumerate(VVByVq.VVfKVc()):
    chName, chUrl, picUrl, refCode = self.VVMwre(mode, row)
    if not isMulti or VVByVq.VVDK6Y(ndx):
     f.write("#SERVICE %s\n"  % chUrl) #SERVICE 4097:0:1:62:0:0:0:0:0:0:http%3a//cdn.webtv4.cdnfr.orange.fr/hs/HALO3/hls/france2live-12471/hls/index.m3u8:France 2
     f.write("#DESCRIPTION %s\n" % chName) #DESCRIPTION France 2
     totChange += 1
  FFv9Xh(os.path.basename(path))
  self.VV93Vw(totChange > 0, "Add to new Bouquet", "Done.\n\nBouquet\t: %s\nChannels \t: %d" % (bName, totChange), False)
 def VVzdL6(self, mode, typ, seriesName, VVByVq, title, txt, colList):
  VVJ4VL = []
  isMulti = VVByVq.VVTa6z
  tot  = VVByVq.VVGUaE()
  if isMulti:
   if tot < 1:
    FFtMdo(VVByVq, "Select rows first.", 1000)
    return
   else:
    s = "s" if tot > 1 else ""
    name = "%d Selected" % tot
  else:
   s = "s"
   name = "ALL"
  VVJ4VL.append(("Download %s PIcon%s" % (name, s), "dnldPicons" ))
  if typ:
   VVJ4VL.append(VV1dpw)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVJ4VL.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVJ4VL.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVJ4VL.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCiRRm.VVA8Ez():
    VVJ4VL.append(VV1dpw)
    VVJ4VL.append(("Download Manager"      , "dload_stat" ))
  FFdrYz(self, boundFunction(self.VVz7D0_VVXLdc, VVByVq, mode, typ, seriesName, colList), title="Download Options", VVJ4VL=VVJ4VL)
 def VVz7D0_VVXLdc(self, VVByVq, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVYQR0(VVByVq, mode)
   elif item == "dnldSel"  : self.VVneaF(VVByVq, mode, typ, colList, True)
   elif item == "addSel"  : self.VVneaF(VVByVq, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVKlI5(VVByVq, mode, typ, seriesName)
   elif item == "dload_stat" : CCiRRm.VVqHgJ(self)
 def VVneaF(self, VVByVq, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVxbI8(mode, typ, colList)
  if startDnld:
   CCiRRm.VVv8gy_url(self, decodedUrl)
  else:
   self.VVXLdc_FFJWhD(VVByVq, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVKlI5(self, VVByVq, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVByVq.VVfKVc():
   chName, decodedUrl = self.VVxbI8(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVXLdc_FFJWhD(VVByVq, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVXLdc_FFJWhD(self, VVByVq, title, chName, decodedUrl_list, startDnld):
  FFJWhD(self, boundFunction(self.VVYoHY, VVByVq, decodedUrl_list, startDnld), chName, title=title)
 def VVYoHY(self, VVByVq, decodedUrl_list, startDnld):
  added, skipped = CCiRRm.VVgkFlList(decodedUrl_list)
  FFtMdo(VVByVq, "Added", 1000)
 def VVxbI8(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVMwre(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV1kpu(mode, colList)
   refCode, chUrl = self.VVxFhz(self.VVxKP6, self.VV2Jz6, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFF7xE(chUrl)
  return chName, decodedUrl
 def VVYQR0(self, VVByVq, mode):
  if os.system(FFps7R("which ffmpeg")) == 0:
   self.session.open(CC1LNl, barTheme=CC1LNl.VVLvJ7
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = boundFunction(self.VV733S, VVByVq, mode)
       , VVS99s = self.VV3Dpp)
  else:
   FFJWhD(self, boundFunction(CCmV60.VVUevi, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VV3Dpp(self, VVCeEr, VVx2td, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVx2td["proces"], VVx2td["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVx2td["ok"], VVx2td["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVx2td["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVx2td["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVx2td["badURL"]
  txt += "Download Failure\t: %d\n"   % VVx2td["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVx2td["path"]
  if not VVCeEr  : color = "#11402000"
  elif VVx2td["err"]: color = "#11201000"
  else     : color = None
  if VVx2td["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVx2td["err"], txt)
  title = "PIcons Download Result"
  if not VVCeEr:
   title += "  (cancelled)"
  FFzRpw(self, txt, title=title, VV5tqg=color)
 def VV733S(self, VVByVq, mode, progBarObj):
  isMulti = VVByVq.VVTa6z
  if isMulti : totRows = VVByVq.VVGUaE()
  else  : totRows = VVByVq.VVRjIQ()
  progBarObj.VVXZBN(totRows)
  counter     = progBarObj.counter
  maxValue    = progBarObj.maxValue
  pPath     = CCYaR2.VVQI8K()
  progBarObj.VVx2td = {   "total"  : totRows
         , "proces"  : 0
         , "attempt"  : 0
         , "fail"  : 0
         , "ok"   : 0
         , "size0"  : 0
         , "exist"  : 0
         , "badURL"  : 0
         , "path"  : pPath
         , "err"   : "" }
  try:
   for rowNum, row in enumerate(VVByVq.VVfKVc()):
    if progBarObj.isCancelled:
     break
    if not isMulti or VVByVq.VVDK6Y(rowNum):
     progBarObj.VVx2td["proces"] += 1
     progBarObj.VVjClj(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VV1kpu(mode, row)
      refCode = CCmV60.VVqrfU(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVNCg3(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVMwre(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       progBarObj.VVx2td["attempt"] += 1
       path, err = FFSgzY(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        progBarObj.VVx2td["ok"] += 1
        if FFuS3Z(path) > 0:
         cmd = ""
         if not mode == CCmV60.VVaXq9:
          cmd += "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
         cmd += FFps7R("mv -f '%s' '%s'" % (path, pPath)) + ";"
         os.system(cmd)
        else:
         progBarObj.VVx2td["size0"] += 1
         os.system(FFps7R("rm -f '%s'" % path))
       elif err:
        progBarObj.VVx2td["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         progBarObj.VVx2td["err"] = err.title()
         break
      else:
       progBarObj.VVx2td["exist"] += 1
     else:
      progBarObj.VVx2td["badURL"] += 1
  except:
   pass
 @staticmethod
 def VVUevi(SELF):
  cmd = FFj0t1(VVSMBq, "ffmpeg")
  if cmd : FFKyuP(SELF, cmd, title="Installing FFmpeg")
  else : FFhJ5k(SELF)
 def VVyuER(self):
  self.session.open(CC1LNl, barTheme=CC1LNl.VVLvJ7
      , titlePrefix = ""
      , fncToRun  = self.VVOAbL
      , VVS99s = self.VVCMIN)
 def VVOAbL(self, progBarObj):
  bName = FFBFyz()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  progBarObj.VVx2td = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = FFb3AA()
  if not progBarObj or progBarObj.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   progBarObj.VVXZBN(totCh)
   for serv in services:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVjClj(1)
    progBarObj.VVYUI4_fromImportEPG(totEpgOK, uChName)
    fullRef  = serv[0]
    if FFsGsn(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFF7xE(fullRef)
     span = iSearch(r"(mode=.+end=)", fullRef, IGNORECASE)
     if span:
      m3u_Url = CCKdjH.VVxJVO(fullRef)
      uType, uHost, uUser, uPass, uId, uChName  = CCmV60.VVxXhs(fullRef)
      uType, uHost, uUser, uPass, uId, uChName1 = CCmV60.VVxXhs(m3u_Url)
     else:
      m3u_Url = decodedUrl
      uType, uHost, uUser, uPass, uId, uChName = CCmV60.VVxXhs(m3u_Url)
     if all([uHost, uUser, uPass, uId]):
      url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
      pList, err = CCmV60.VVCCns(url, uId)
      if err:
       totServErr += 1
       if "Unauth" in err:
        totUnauth += 1
      elif pList:
       totEv, totOK = CCipRP.VVl8S9(refCode, pList)
       totEpg += totEv
       totEpgOK += totOK
      else:
       pass
     else:
      totInv += 1
    else:
     totNotIptv += 1
    if progBarObj:
     progBarObj.VVx2td = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   progBarObj.VVx2td = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 def VVCMIN(self, VVCeEr, VVx2td, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVx2td
  title = "IPTV EPG Import"
  if err:
   FFBAp7(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FF2tuT(str(totNotIptv), VVpKeT)
    if totServErr : txt += "Server Errors\t: %s\n" % FF2tuT(str(totServErr) + t1, VVpKeT)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FF2tuT(str(totInv), VVpKeT)
   if not VVCeEr:
    title += "  (stopped)"
   FFzRpw(self, txt, title=title)
 @staticmethod
 def VVCCns(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCmV60.VV9iE3(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCmV60.VVI40b(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCmV60.VVVFIA(item, "description" , is_base64=True ).replace("\n", " .. ")
    has_archive   = CCmV60.VVVFIA(item, "has_archive"      )
    lang    = CCmV60.VVVFIA(item, "lang"        ).upper()
    now_playing   = CCmV60.VVVFIA(item, "now_playing"      )
    start    = CCmV60.VVVFIA(item, "start"        )
    start_timestamp  = CCmV60.VVVFIA(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCmV60.VVVFIA(item, "start_timestamp"     )
    stop_timestamp  = CCmV60.VVVFIA(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCmV60.VVVFIA(item, "stop_timestamp"      )
    tTitle    = CCmV60.VVVFIA(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVqrfU(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCmV60.VVWpJW(catID, MAX_4b)
  TSID = CCmV60.VVWpJW(chNum, MAX_4b)
  ONID = CCmV60.VVWpJW(chNum, MAX_4b)
  NS  = CCmV60.VVWpJW(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVWpJW(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VV21Ob_forBouquet(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVh44S(mode):
  if   mode in ("itv"  , CCmV60.VVkEVz)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCmV60.VV96AI)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCmV60.VVaKzY) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCmV60.VVomyW) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCmV60.VVsSqp    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 @staticmethod
 def VV6FB1(orExportPath=False):
  path = CFG.iptvHostsPath.getValue()
  if not pathExists(path) or path == VVIhrd:
   if orExportPath : path = CFG.exportedTablesPath.getValue()
   else   : path ="/"
  return FF5gdy(path)
 @staticmethod
 def VVZbpP(SELF, hostUrl, chName, streamId, ok_fnc):
  title = "Catchup TV Programs"
  pList, err = CCmV60.VVCCns(hostUrl, streamId, True)
  if err:
   FFBAp7(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVZ7ot, VVuutY, VV5tqg, VVwtgu = CCmV60.VVh44S("")
   VV5uBQ = ("Home Menu" , FFAu6q, [])
   VV69tn  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VV32KX  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFN0i6(SELF, None, title="Programs for : " + chName, header=header, VV1rg6=pList, VV32KX=VV32KX, VVDe98=widths, VVwZKv=24, VV69tn=VV69tn, VV5uBQ=VV5uBQ, VVZ7ot=VVZ7ot, VVuutY=VVuutY, VV5tqg=VV5tqg, VVwtgu=VVwtgu)
  else:
   FFBAp7(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVkK3C(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 @staticmethod
 def VVIzP6(SELF, isPortal, line, VVH9sbObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCmV60.VV6FB1(orExportPath=True)
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFBAp7(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFSzHX(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFBAp7(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVUxgD(self, nameCol, source, mode, bName, VVByVq, title, txt, colList):
  isMulti = VVByVq.VVTa6z
  mSel = CCn4gV(self, VVByVq, nameCol, addSep=False)
  title = ""
  if isMulti:
   tot = VVByVq.VVGUaE()
   if tot > 0:
    s = "s" if tot > 1 else ""
    title = "Add %d Service%s to Bouquet" % (tot, s)
  else:
   title = "Add ALL to Bouquet"
  if title:
   mSel.VVJ4VL.append(VV1dpw)
   mSel.VVJ4VL.append((title        , "addToBoquet"))
  FFdrYz(self, boundFunction(self.VVgKxT, mSel, source, mode, bName, VVByVq, title, txt, colList), title="Options", VVJ4VL=mSel.VVJ4VL)
 def VVgKxT(self, mSelObj, source, mode, bName, VVByVq, title, txt, colList, item):
  if item:
   if   item == "multSelEnab"     : mSelObj.VVByVq.VVHK3s(True)
   elif item == "MultSelDisab"     : mSelObj.VVByVq.VVHK3s(False)
   elif item == "selectAll"     : mSelObj.VVByVq.VVrbd3()
   elif item == "unselectAll"     : mSelObj.VVByVq.VV6cA9()
   elif item == "addToBoquet"     :
    if   source == "pEp" : fnc = self.VVFr8y
    elif source == "pCh" : fnc = self.VVFr8y
    elif source == "m3Ch" : fnc = self.VVXJB9
    elif source == "lv"  : fnc = self.VVfvte
    elif source == "v"  : fnc = self.VVfvte
    elif source == "s"  : fnc = self.VVfvte
    elif source == "fnd" : fnc = self.VVfvte
    else     : return
    FFobhC(VVByVq, boundFunction(fnc, mode, bName, VVByVq, title, txt, colList), title="Adding Channels ...")
class CCkIH2(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", bouquetRoot="", isFind=False):
  self.skin, self.skinParam = FFbmPq(VVXAn9, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.bouquetRoot    = bouquetRoot
  self.isFindMode     = isFind
  self.VVfFAK  = 0
  self.VV6jaZ = 1
  self.VVaVok  = 2
  VVJ4VL = []
  VVJ4VL.append(("Find in All Service (from filter)" , "VV9ejj" ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Find in All (Manual Entry)"   , "VVTj49"    ))
  VVJ4VL.append(("Find in TV"       , "VV3Tsf"    ))
  VVJ4VL.append(("Find in Radio"      , "VVNzRr"   ))
  if self.VVesDQ():
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append(("Hide Channel: %s" % self.servName , "VVLxOp"   ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Zap History"       , "VVSU0p"    ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("IPTV Tools"       , "iptv"      ))
  VVJ4VL.append(("PIcons Tools"       , "PIconsTools"     ))
  VVJ4VL.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  FF9Cql(self, VVJ4VL=VVJ4VL, title=title)
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FFYI0q(self["myMenu"])
  FFImVi(self)
  if self.isFindMode:
   self.VVITlO(self.VVYVlh())
 def VVFd70(self):
  global VVCBxr
  VVCBxr = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVTj49"    : self.VVTj49()
   elif item == "VV9ejj" : self.VV9ejj()
   elif item == "VV3Tsf"    : self.VV3Tsf()
   elif item == "VVNzRr"   : self.VVNzRr()
   elif item == "VVLxOp"   : self.VVLxOp()
   elif item == "VVSU0p"    : self.VVSU0p()
   elif item == "iptv"       : self.session.open(CCmV60)
   elif item == "PIconsTools"     : self.session.open(CCYaR2)
   elif item == "ChannelsTools"    : self.session.open(CCqgtV)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VV3Tsf(self) : self.VVITlO(self.VVfFAK)
 def VVNzRr(self) : self.VVITlO(self.VV6jaZ)
 def VVTj49(self) : self.VVITlO(self.VVaVok)
 def VVITlO(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFIilI(self, boundFunction(self.VV3LLe, mode), defaultText=self.findTxt, title=title, message="Enter Name:", isTrimEnds=False)
 def VV9ejj(self):
  filterObj = CCQuuR(self)
  filterObj.VVaSAo(self.VVHR4u)
 def VVHR4u(self, item):
  self.VV3LLe(self.VVaVok, item)
 def VVesDQ(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFsGsn(self.refCode)        : return False
  return True
 def VV3LLe(self, mode, VVTxPr):
  FFobhC(self, boundFunction(self.VVCT9S, mode, VVTxPr), title="Searching ...")
 def VVCT9S(self, mode, VVTxPr):
  if VVTxPr:
   self.findTxt = VVTxPr
   if   mode == self.VVfFAK  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VV6jaZ : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVTxPr)
   if len(title) > 55:
    title = title[:55] + ".."
   VVhCPI = self.VVZOI7(VVTxPr, servTypes)
   if self.isFindMode or mode == self.VVaVok:
    VVhCPI += self.VVRdbv(VVTxPr)
   if VVhCPI:
    VVhCPI.sort(key=lambda x: x[0].lower())
    VVFhJO = self.VVEdB5
    VV69tn  = ("Zap"   , self.VV9vO1    , [])
    VVw8s5 = ("Current Service", self.VVWRMx , [])
    VV3Y5Z = ("Options"  , self.VVCmFi , [])
    VVTRSb = (""    , self.VVE3v5 , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VV32KX  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFN0i6(self, None, title=title, header=header, VV1rg6=VVhCPI, VV32KX=VV32KX, VVDe98=widths, VVwZKv=26, VV69tn=VV69tn, VVFhJO=VVFhJO, VVw8s5=VVw8s5, VV3Y5Z=VV3Y5Z, VVTRSb=VVTRSb)
   else:
    self.VVITlO(self.VVYVlh())
    FFSzHX(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVZOI7(self, VVTxPr, servTypes):
  VVhCPI = []
  if CCqgtV.VVn1cj(servTypes):
   VV8Mu4, VVjaEE = FFZHPK()
   tp   = CCYelw()
   words, asPrefix = CCQuuR.VVaZUu(VVTxPr)
   colorYellow  = CCRLh1.VVRG9q(VVWvE3)
   colorWhite  = CCRLh1.VVRG9q(VVjMps)
   for s in VV1rg6:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFQ6pE(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VV8Mu4:
        STYPE = VVjaEE[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVWYTS(refCode)
       if not "-S" in syst:
        sat = syst
       VVhCPI.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVhCPI
 def VVRdbv(self, VVTxPr):
  VVTxPr = VVTxPr.lower()
  VVhCPI = []
  colorYellow  = CCRLh1.VVRG9q(VVWvE3)
  colorWhite  = CCRLh1.VVRG9q(VVjMps)
  for b in FF1OCM():
   VVz7Hn  = b[0]
   VVjCjC  = b[1].toString()
   VV0Y3S = eServiceReference(VVjCjC)
   VVuyJz = FFhmEb(VV0Y3S)
   for service in VVuyJz:
    refCode  = service[0]
    if FFsGsn(refCode):
     servName = service[1]
     if VVTxPr in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVTxPr), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVhCPI.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVhCPI
 def VVYVlh(self):
  VVw7XZ = InfoBar.instance
  if VVw7XZ:
   VV7u2w = VVw7XZ.servicelist
   if VV7u2w:
    return VV7u2w.mode == 1
  return self.VVaVok
 def VVEdB5(self, VVByVq):
  self.close()
  VVByVq.cancel()
 def VV9vO1(self, VVByVq, title, txt, colList):
  FFPZFB(VVByVq, colList[2], VVhM2K=False, checkParentalControl=True)
 def VVWRMx(self, VVByVq, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(VVByVq)
  if refCode:
   VVByVq.VVgUPC(2, FFU1EP(refCode, iptvRef, chName), True)
 def VVCmFi(self, VVByVq, title, txt, colList):
  servName = colList[0]
  refCode  = colList[2]
  mSel  = CCn4gV(self, VVByVq, 2)
  mSel.VVORrI(servName, refCode)
 def VVE3v5(self, VVByVq, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFnMVC(self, fncMode=CCipRP.VVRb2H, refCode=refCode, chName=chName, text=txt)
 def VVLxOp(self):
  FFJWhD(self, self.VVjzlr, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVjzlr(self):
  ret = FFNjm6(self.refCode, True)
  if ret:
   self.VVqHaN()
   self.close()
  else:
   FFtMdo(self, "Cannot change state" , 1000)
 def VVqHaN(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VV785t()
  except:
   self.VVqZFU()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FF2xwS(self, serviceRef)
 def VVKm7Z(self):
  VVw7XZ = InfoBar.instance
  if VVw7XZ:
   VV7u2w = VVw7XZ.servicelist
   if VV7u2w:
    VV7u2w.setMode()
 def VV785t(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVw7XZ = InfoBar.instance
   if VVw7XZ:
    VV7u2w = VVw7XZ.servicelist
    if VV7u2w:
     hList = VV7u2w.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VV7u2w.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VV7u2w.history  = newList
       VV7u2w.history_pos = pos
 def VVqZFU(self):
  VVw7XZ = InfoBar.instance
  if VVw7XZ:
   VV7u2w = VVw7XZ.servicelist
   if VV7u2w:
    VV7u2w.history  = []
    VV7u2w.history_pos = 0
 def VVSU0p(self):
  VVw7XZ = InfoBar.instance
  VVhCPI = []
  if VVw7XZ:
   VV7u2w = VVw7XZ.servicelist
   if VV7u2w:
    VV8Mu4, VVjaEE = FFZHPK()
    for chParams in VV7u2w.history:
     refCode = chParams[-1].toString()
     chName = FFquq9(refCode)
     isIptv = FFsGsn(refCode)
     if isIptv: sat = "-"
     else  : sat = FFQ6pE(refCode, True)
     if isIptv:
      STYPE = "IPTV"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VV8Mu4:
       STYPE = VVjaEE[sTypeInt]
     VVhCPI.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVhCPI:
   VV69tn  = ("Zap"   , self.VV4FRh   , [])
   VV3Y5Z = ("Clear History" , self.VVYazm   , [])
   VVTRSb = (""    , self.VVkdxsFromZapHistory , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VV32KX  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFN0i6(self, None, title=title, header=header, VV1rg6=VVhCPI, VV32KX=VV32KX, VVDe98=widths, VVwZKv=28, VV69tn=VV69tn, VV3Y5Z=VV3Y5Z, VVTRSb=VVTRSb)
  else:
   FFSzHX(self, "Not found", title=title)
 def VV4FRh(self, VVByVq, title, txt, colList):
  FFPZFB(VVByVq, colList[3], VVhM2K=False, checkParentalControl=True)
 def VVYazm(self, VVByVq, title, txt, colList):
  FFJWhD(self, boundFunction(self.VVVj7b, VVByVq), "Clear Zap History ?")
 def VVVj7b(self, VVByVq):
  self.VVqZFU()
  VVByVq.cancel()
 def VVkdxsFromZapHistory(self, VVByVq, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFnMVC(self, fncMode=CCipRP.VVzdCa, refCode=refCode, chName=chName, text=txt)
class CCYaR2(Screen):
 VVqhKt   = 0
 VVQZTE  = 1
 VVfcPu  = 2
 VVpJ4g  = 3
 VVigVQ  = 4
 VVaUC8  = 5
 VVPD1Q  = 6
 VV50dg  = 7
 VVYMQd = 8
 VV6zeS = 9
 def __init__(self, session):
  self.skin, self.skinParam = FFbmPq(VVm2MP, 1400, 840, 30, 10, 14, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  self.Title    = "PIcons Tools"
  FF9Cql(self, self.Title)
  FFCpCt(self["keyRed"] , "OK = Zap")
  FFCpCt(self["keyGreen"] , "Current Service")
  FFCpCt(self["keyYellow"], "Page Options")
  FFCpCt(self["keyBlue"] , "Filter")
  self.TOTAL_ROWS   = 5
  self.TOTAL_COLS   = 7
  self.PAGE_PICONS  = self.TOTAL_ROWS * self.TOTAL_COLS
  self.pPath    = CCYaR2.VVQI8K()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VV1rg6    = []
  self.totalPIcons  = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastFind   = ""
  self.filterTitle  = ""
  self.isBusy    = True
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)] = Pixmap()
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)] = Label()
    self["myPiconLbl%d%d" % (row, col)].hide()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVkKYs        ,
   "green"   : self.VVXzde       ,
   "yellow"  : self.VV6ePo        ,
   "blue"   : self.VVqFIQ        ,
   "menu"   : self.VVydo0        ,
   "info"   : self.VVkdxs         ,
   "up"   : self.VVgxd0          ,
   "down"   : self.VVzN12         ,
   "left"   : self.VVTvlD         ,
   "right"   : self.VVrNqN         ,
   "pageUp"  : boundFunction(self.VV40jO, True) ,
   "chanUp"  : boundFunction(self.VV40jO, True) ,
   "pageDown"  : boundFunction(self.VV40jO, False) ,
   "chanDown"  : boundFunction(self.VV40jO, False) ,
   "next"   : self.VVlmjb        ,
   "last"   : self.VVjPbK         ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FFGuuf(self)
  FF4l2q(self)
  FF3luO(self["keyRed"], "#0a333333")
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].instance.setScale(1)
    self["myPiconLbl%d%d" % (row, col)].instance.setNoWrap(True)
  self["myPiconPtr"].hide()
  FFobhC(self, boundFunction(self.VVTBh6, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVydo0(self):
  if not self.isBusy:
   VVJ4VL = []
   VVJ4VL.append(("Statistics"           , "VVYnxG"    ))
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append(("Suggest PIcons for Current Channel"     , "VV09ok"   ))
   VVJ4VL.append(("Set to Current Channel (copy file)"     , "VV7olK_file"  ))
   VVJ4VL.append(("Set to Current Channel (as SymLink)"     , "VV7olK_link"  ))
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append(CCYaR2.VV7U1X())
   VVJ4VL.append(VV1dpw)
   if self.filterTitle == "PIcons without Channels":
    c = VVpKeT
    VVJ4VL.append((FF2tuT("Move Unused PIcons to a Directory", c) , "VVdS07"  ))
    VVJ4VL.append((FF2tuT("DELETE Unused PIcons", c)    , "VV9KyF" ))
    VVJ4VL.append(VV1dpw)
   VVJ4VL.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVNUSW"  ))
   VVJ4VL.append(VV1dpw)
   VVJ4VL += CCYaR2.VV3ruH()
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append(("RCU Keys Help"          , "VVL9hp"    ))
   FFdrYz(self, self.VVz7D0, title=self.Title, VVJ4VL=VVJ4VL)
 def VVz7D0(self, item=None):
  if item is not None:
   if   item == "VVYnxG"     : self.VVYnxG()
   elif item == "VV09ok"    : self.VV09ok()
   elif item == "VV7olK_file"   : self.VV7olK(0)
   elif item == "VV7olK_link"   : self.VV7olK(1)
   elif item == "VVcXLL_file"  : self.VVcXLL(0)
   elif item == "VVcXLL_link"  : self.VVcXLL(1)
   elif item == "VVEwvf"   : self.VVEwvf()
   elif item == "VV4NTG"  : self.VV4NTG()
   elif item == "VVdS07"    : self.VVdS07()
   elif item == "VV9KyF"   : self.VV9KyF()
   elif item == "VVNUSW"   : self.VVNUSW()
   elif item == "VV8BHx"   : CCYaR2.VV8BHx(self)
   elif item == "VVD7m5"   : CCYaR2.VVD7m5(self)
   elif item == "findPiconBrokenSymLinks"  : CCYaR2.VVkgX9(self, True)
   elif item == "FindAllBrokenSymLinks"  : CCYaR2.VVkgX9(self, False)
   elif item == "VVL9hp"      : self.VVL9hp()
 def VV6ePo(self):
  if not self.isBusy:
   VVJ4VL = []
   VVJ4VL.append(("Go to First PIcon"  , "VVCZ4E"  ))
   VVJ4VL.append(("Go to Last PIcon"   , "VVlo07"  ))
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append(("Sort by Channel Name"     , "sortByChan" ))
   VVJ4VL.append(("Sort by File Name"  , "sortByFile" ))
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append(("Find from File List .." , "VVKxtc" ))
   FFdrYz(self, self.VV6Ckb, title=self.Title, VVJ4VL=VVJ4VL)
 def VV6Ckb(self, item=None):
  if item is not None:
   if   item == "VVCZ4E"   : self.VVCZ4E()
   elif item == "VVlo07"   : self.VVlo07()
   elif item == "sortByChan"  : self.VVzPrW(2)
   elif item == "sortByFile"  : self.VVzPrW(0)
   elif item == "VVKxtc"  : self.VVKxtc()
 def VVL9hp(self):
  FFf485(self, VVqrRB + "_help_picons", "PIcons Manager (Keys Help)")
 def VVgxd0(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVlo07()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVrD8t()
 def VVzN12(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVCZ4E()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVrD8t()
 def VVTvlD(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVlo07()
  else:
   self.curCol -= 1
   self.VVrD8t()
 def VVrNqN(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVCZ4E()
  else:
   self.curCol += 1
   self.VVrD8t()
 def VVjPbK(self):
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVrD8t(True)
 def VVlmjb(self):
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVrD8t(True)
 def VVCZ4E(self):
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVrD8t(True)
 def VVlo07(self):
  self.curPage = self.totalPages -1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVrD8t(True)
 def VVKxtc(self):
  VVJ4VL = []
  for item in self.VV1rg6:
   VVJ4VL.append((item[0], item[0]))
  FFdrYz(self, self.VV28Kd, title='PIcons ".png" Files', VVJ4VL=VVJ4VL, VVYMy8=True)
 def VV28Kd(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VV5MeH(ndx)
 def VVkKYs(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVaHNa()
   if refCode:
    FFPZFB(self, refCode)
    self.VVvUqM()
    self.VVYXQt()
 def VV40jO(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVvUqM()
   self.VVYXQt()
  except:
   pass
 def VVXzde(self):
  if self["keyGreen"].getVisible():
   self.VV5MeH(self.curChanIndex)
 def VV5MeH(self, ndx):
  if ndx > -1 and ndx < self.totalPIcons:
   self.curPage = int(ndx / self.PAGE_PICONS)
   firstInPage  = self.curPage * self.PAGE_PICONS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVrD8t(True)
  else:
   FFtMdo(self, "Not found", 1000)
 def VVzPrW(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFobhC(self, boundFunction(self.VVTBh6, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VV7olK(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVaHNa()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVJ4VL = []
     VVJ4VL.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVJ4VL.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFdrYz(self, boundFunction(self.VVf9Ip, mode, curChF, selPiconF), VVJ4VL=VVJ4VL, title="Current Channel PIcon (already exists)")
    else:
     self.VVf9Ip(mode, curChF, selPiconF, "overwrite")
   else:
    FFBAp7(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFBAp7(self, "Could not read current channel info. !", title=title)
 def VVf9Ip(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   os.system(cmd)
   FFobhC(self, boundFunction(self.VVTBh6, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVcXLL(self, mode):
  pass
 def VVEwvf(self):
  pass
 def VV4NTG(self):
  pass
 def VVdS07(self):
  defDir = FF5gdy(CCYaR2.VVQI8K() + "picons_backup")
  os.system(FFps7R("mkdir '%s'" % (defDir)))
  self.session.openWithCallback(boundFunction(self.VVlDkX, defDir), boundFunction(CCsPG3
         , mode=CCsPG3.VVHqWs, VV0Jhk=CCYaR2.VVQI8K()))
 def VVlDkX(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCYaR2.VVQI8K():
    FFBAp7(self, "Cannot move to same directory !", title=title)
   else:
    if not FF5gdy(path) == FF5gdy(defDir):
     self.VV63h9(defDir)
    FFJWhD(self, boundFunction(FFobhC, self, boundFunction(self.VVgJxb, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VV1rg6), path), title=title)
  else:
   self.VV63h9(defDir)
 def VVgJxb(self, title, defDir, toPath):
  try:
   from shutil import move as iMove
  except:
   self.VV63h9(defDir)
   FFBAp7(self, 'Could not load "shutil" module !', title=title)
   return
  toPath = FF5gdy(toPath)
  pPath = CCYaR2.VVQI8K()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VV1rg6:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VV1rg6)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFzRpw(self, txt, title=title, VV5tqg="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVpsvi("all")
 def VV63h9(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VV9KyF(self):
  title = "Delete Unused PIcons"
  tot = len(self.VV1rg6)
  s = "s" if tot > 1 else ""
  FFJWhD(self, boundFunction(FFobhC, self, boundFunction(self.VVicK2, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, s), title=title)
 def VVicK2(self, title):
  pPath = CCYaR2.VVQI8K()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VV1rg6:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VV1rg6)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FF2tuT(str(totErr), VVpKeT)
  FFzRpw(self, txt, title=title)
 def VVNUSW(self):
  lines = FF5Oes("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   s = "s" if tot > 1 else ""
   FFJWhD(self, boundFunction(self.VVDTLH, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, s), VVIDtV=True)
  else:
   FFSzHX(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVDTLH(self, fList):
  os.system(FFps7R("find -L '%s' -type l -delete" % self.pPath))
  FFSzHX(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVkdxs(self):
  FFobhC(self, self.VVw50T)
 def VVw50T(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVaHNa()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FF2tuT("PIcon Directory:\n", VVpg8I)
   txt += "  Path\t: %s\n"  % self.pPath
   chkDir = self.pPath
   target = FFfoid(self.pPath)
   if target:
    chkDir = target
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFfoid(path)
   txt += FF2tuT("PIcon File:\n", VVpg8I)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   cmd = "ls '%s' -la | grep '\-> %s' | awk '{print $9}'" % (chkDir, chkDir + "/" + filName)
   symLinks = FF5Oes(cmd)
   if symLinks:
    tot = len(symLinks)
    s = "s" if tot > 1 else ""
    txt += FF2tuT("Found %d SymLink%s to this file from:\n" % (tot, s), VVpg8I)
    for line in symLinks:
     tRefCode = line.replace("_", ":").replace(".png", "")
     tChName = FFquq9(tRefCode)
     if tChName : tChName = "\t ... Used by: %s" % FF2tuT(tChName, VVx2Y8)
     else  : tChName = ""
     txt += "  %s%s\n" % (FF2tuT(line, VVQDXE), tChName)
    txt += "\n"
   if chName:
    txt += FF2tuT("Channel:\n", VVpg8I)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FF2tuT(chName, VVx2Y8)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not symLinks:
    txt += FF2tuT("Remarks:\n", VVpg8I)
    txt += "  %s\n" % FF2tuT("Unused", VVpKeT)
  else:
   txt = "No info found"
  FFnMVC(self, fncMode=CCipRP.VVokK3, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVaHNa(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalPIcons:
   fName, fType, chName, sat, inDB = self.VV1rg6[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FFEeIv(sat)
  return fName, refCode, chName, sat, inDB
 def VVvUqM(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VV1rg6):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVYXQt(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVaHNa()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalPIcons)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FF2tuT("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVpg8I))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVaHNa()[1]))
  if self.curChanIptvRef : typ = "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FF2tuT(self.curChanName, VVWvE3)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
 def VVYnxG(self):
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  for fName, fType, chName, sat, inDB in self.VV1rg6:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
  totBrokSL = FFDup1("find -L '%s' -type l -print | wc -l" % self.pPath)
  txt  = "PIcons\t\t: %d\tUsed = %s\n"  % (self.totalPIcons, totUsedFiles + totUsedLinks)
  txt += "Files\t\t: %d\tUsed = %s\n"   % (self.totalPIcons - totSymLinks, totUsedFiles)
  txt += "SymLinks\t\t: %d\tUsed = %s\n"  % (totSymLinks, totUsedLinks)
  txt += "\n"
  txt += "In Database (lamedb)\t: %d\n"  % (totInDB)
  txt += "Not In Database (lamedb)\t: %d\n" % (self.totalPIcons - totInDB)
  txt += "Satellites\t\t: %d\n"    % len(self.nsList)
  txt += "\n"
  txt += "Broken SymLinks\t: %s\n"   % totBrokSL
  FFzRpw(self, txt, title=self.Title)
 def VVqFIQ(self):
  if not self.isBusy:
   VVJ4VL = []
   VVJ4VL.append(("All"         , "all"   ))
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append(("Used by Channels"      , "used"  ))
   VVJ4VL.append(("Unused PIcons"      , "unused"  ))
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append(("PIcons Files"       , "pFiles"  ))
   VVJ4VL.append(("SymLinks to PIcons"     , "pLinks"  ))
   VVJ4VL.append(("PIcons Files Targeted by SymLinks" , "pTargets" ))
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append(("IPTV PIcons"       , "iptv"  ))
   if self.nsList:
    VVJ4VL.append(VV1dpw)
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFAmCN(val)
      VVJ4VL.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCQuuR(self)
   filterObj.VV1X6z(VVJ4VL, self.nsList, self.VV9fhr)
 def VV9fhr(self, item=None):
  if item is not None:
   self.VVpsvi(item)
 def VVpsvi(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVqhKt   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVQZTE   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVfcPu  , ""  , "PIcons without Channels"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVpJ4g  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVigVQ  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVaUC8  , ""  , "Targets"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVPD1Q   , "iptv" , "IPTV PIcons"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VV50dg   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVYMQd , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVaUC8:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FF5Oes("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = os.path.basename(os.path.normpath(f))
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFtMdo(self, "Not found", 1000)
     return
   elif mode == self.VV6zeS:
    return
   else:
    words, asPrefix = CCQuuR.VVaZUu(words)
   if not words and mode in (self.VV50dg, self.VVYMQd):
    FFtMdo(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFobhC(self, boundFunction(self.VVTBh6, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VV09ok(self):
  self.session.open(CC1LNl, barTheme=CC1LNl.VVFMDb
      , titlePrefix = ""
      , fncToRun  = self.VVdqPT
      , VVS99s = self.VVgGek)
 def VVdqPT(self, progBarObj):
  lameDbChans = CCqgtV.VVxFIz(self, CCqgtV.VVehSi, VVO5r1=False, VVaKKN=False)
  files = []
  words = []
  if not progBarObj or progBarObj.isCancelled:
   return
  progBarObj.VVx2td = []
  progBarObj.VVXZBN(len(lameDbChans))
  if lameDbChans:
   processChanName = CCDgHG()
   curCh = processChanName.VVFNHE(self.curChanName)
   for refCode in lameDbChans:
    if not progBarObj or progBarObj.isCancelled:
     return
    progBarObj.VVjClj(1, True)
    chName, sat, inDB = lameDbChans.get(refCode, ("", "", 0))
    ratio = CCYaR2.VV3co7(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCYaR2.VV4GG4(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = os.path.basename(os.path.normpath(f))
       progBarObj.VVx2td.append(f.replace(".png", ""))
 def VVgGek(self, VVCeEr, VVx2td, threadCounter, threadTotal, threadErr):
  if VVx2td:
   self.timer = eTimer()
   fnc = boundFunction(FFobhC, self, boundFunction(self.VVTBh6, mode=self.VV6zeS, words=VVx2td), title="Loading ...")
   try:
    self.timer_conn = self.timer.timeout.connect(fnc)
   except:
    self.timer.callback.append(fnc)
   self.timer.start(50, True)
  else:
   FFtMdo(self, "Not found", 2000)
 def VVTBh6(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True):
  if not self.VVzuRS(isFirstTime):
   return
  self.isBusy = True
  lameDbChans = CCqgtV.VVxFIz(self, CCqgtV.VVehSi, VVO5r1=False, VVaKKN=False)
  iptvRefList = self.VVQ3iJ()
  tList = []
  for fName, fType in CCYaR2.VVNhPR(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and lameDbChans:
    if fName in lameDbChans:
     chName, sat, inDB = lameDbChans.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVqhKt:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVQZTE  and chName         : isAdd = True
   elif mode == self.VVfcPu and not chName        : isAdd = True
   elif mode == self.VVpJ4g  and fType == 0        : isAdd = True
   elif mode == self.VVigVQ  and fType == 1        : isAdd = True
   elif mode == self.VVaUC8  and fName in words       : isAdd = True
   elif mode == self.VV6zeS and fName in words       : isAdd = True
   elif mode == self.VVPD1Q  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VV50dg  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVYMQd:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   else                    : isAdd = False
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VV1rg6   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   FFtMdo(self)
  else:
   self.isBusy = False
   FFtMdo(self, "Not found", 1000)
   return
  self.VV1rg6.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVvUqM()
  self.totalPIcons = len(self.VV1rg6)
  self.totalPages  = int(self.totalPIcons / self.PAGE_PICONS) + (self.totalPIcons % self.PAGE_PICONS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self["myPiconPtr"].show()
  self.isBusy = False
  self.VVrD8t(True)
 def VVzuRS(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCYaR2.VVNhPR(self.pPath):
    if fName:
     return True
   if isFirstTime : FFBAp7(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFtMdo(self, "Not found", 1000)
  else:
   FFBAp7(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVQ3iJ(self):
  VVhCPI = {}
  files  = CCmV60.VVqhRn(self)
  if files:
   for path in files:
    txt = FFWaDF(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVhCPI[refCode] = item[1]
  return VVhCPI
 def VVrD8t(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVAscL = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVAscL: self.curPage = VVAscL
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  if force or not oldPage == self.curPage:
   self.VVkMDb()
  if self.curPage == VVAscL:
   if self.curRow > self.lastRow:
    self.curRow = self.lastRow
   if self.curRow == self.lastRow and self.curCol > self.lastCol:
    self.curCol = self.lastCol
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myPicon%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myPiconPtr"].instance.move(ePoint(pos[0]-gap, pos[1]-gap))
  self.curIndex = self.curPage * self.PAGE_PICONS + self.curRow * self.TOTAL_COLS + self.curCol
  self.VVYXQt()
  filName, refCode, chName, sat, inDB = self.VVaHNa()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVkMDb(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPicon%d%d" % (row, col)].hide()
    self["myPiconLbl%d%d" % (row, col)].hide()
  last = self.totalPIcons
  f1 = self.curPage * self.PAGE_PICONS
  f2 = f1 + self.PAGE_PICONS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VV1rg6[ndx]
   fName = self.VV1rg6[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   pic = self["myPicon%d%d" % (row, col)]
   lbl = self["myPiconLbl%d%d" % (row, col)]
   lbl.show()
   try:
    pic.instance.setPixmapFromFile(path)
    pic.show()
    if inDB : lbl.setText(FF2tuT(chName, VVx2Y8))
    else : lbl.setText("-")
   except:
    lbl.setText(FF2tuT(chName, VVNLkI))
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VV3co7(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VV7U1X():
  return ("Copy Current Channel PIcon (to PIcons Export Path)" , "VV8BHx"   )
 @staticmethod
 def VV3ruH():
  VVJ4VL = []
  VVJ4VL.append(("Find SymLinks (to PIcon Directory)"   , "VVD7m5"   ))
  VVJ4VL.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks"  ))
  VVJ4VL.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks"  ))
  return VVJ4VL
 @staticmethod
 def VV8BHx(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(SELF)
  png, path = CCYaR2.VVt4fS(refCode)
  if path : CCYaR2.VV9Y13(SELF, png, path)
  else : FFBAp7(SELF, "No PIcon found for current channel in:\n\n%s" % CCYaR2.VVQI8K())
 @staticmethod
 def VVD7m5(SELF):
  if VVWvE3:
   sed1 = FFOCvV("->", VVWvE3)
   sed2 = FFOCvV("picon", VVpKeT)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVNLkI, VVjMps)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFa7xk(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFebM5(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVkgX9(SELF, isPIcon):
  sed1 = FFOCvV("->", VVNLkI)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFOCvV("picon", VVpKeT)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFa7xk(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFebM5(), grep, sed1, sed2))
 @staticmethod
 def VVNhPR(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVQI8K():
  path = CFG.PIconsPath.getValue()
  return FF5gdy(path)
 @staticmethod
 def VVt4fS(refCode, chName=None):
  if FFsGsn(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFF7xE(refCode)
  allPath, fName, refCodeFile, pList = CCYaR2.VV4GG4(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return None, None
 @staticmethod
 def VV9Y13(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFOCvV("%s%s" % (dest, png), VVx2Y8))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFOCvV(errTxt, VVUq52))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FF4pyg(SELF, cmd)
 @staticmethod
 def VV4GG4(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   if fName.endswith(":"):
    fName = fName[:-1]
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCYaR2.VVQI8K()
   pList = []
   pat = allPath + "*_" + "_".join(fName.split("_")[3:])
   lst = iGlob(pat)
   if lst:
    pList += lst
   if chName:
    chName = FFWYHc(chName)
    try:
     lst = iGlob(allPath + chName + ".png")
     if lst:
      pList += lst
    except:
     pass
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == os.path.basename(os.path.normpath(item)):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCfM78():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVy8LD  = None
  self.VVYZbW = ""
  self.VV1qHY  = noService
  self.VVTftc = 0
  self.VVz84O  = noService
  self.VVwnCa = 0
  self.VVEFjq  = "-"
  self.VVMbsP = 0
  self.VVpnq5  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VV7YR1(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVy8LD = frontEndStatus
     self.VV26dn()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VV26dn(self):
  if self.VVy8LD:
   val = self.VVy8LD.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVYZbW = "%3.02f dB" % (val / 100.0)
   else         : self.VVYZbW = ""
   val = self.VVy8LD.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVTftc = int(val)
   self.VV1qHY  = "%d%%" % val
   val = self.VVy8LD.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVwnCa = int(val)
   self.VVz84O  = "%d%%" % val
   val = self.VVy8LD.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVEFjq  = "%d" % val
   val = int(val * 100 / 500)
   self.VVMbsP = min(500, val)
   val = self.VVy8LD.get("tuner_locked", 0)
   if val == 1 : self.VVpnq5 = "Locked"
   else  : self.VVpnq5 = "Not locked"
 def VV416K(self)   : return self.VVYZbW
 def VVN2kz(self)   : return self.VV1qHY
 def VVR1ED(self)  : return self.VVTftc
 def VV2zAV(self)   : return self.VVz84O
 def VVeQS1(self)  : return self.VVwnCa
 def VVuUCa(self)   : return self.VVEFjq
 def VVXm1M(self)  : return self.VVMbsP
 def VVktJ8(self)   : return self.VVpnq5
 def VV99Ld(self) : return self.serviceName
class CCYelw():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVGsIM(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFAL9w(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVu7wp(self.ORPOS  , mod=1   )
      self.sat2  = self.VVu7wp(self.ORPOS  , mod=2   )
      self.freq  = self.VVu7wp(self.FREQ  , mod=3   )
      self.sr   = self.VVu7wp(self.SR   , mod=4   )
      self.inv  = self.VVu7wp(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVu7wp(self.POL  , self.D_POL )
      self.fec  = self.VVu7wp(self.FEC  , self.D_FEC )
      self.syst  = self.VVu7wp(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVu7wp("modulation" , self.D_MOD )
       self.rolof = self.VVu7wp("rolloff"  , self.D_ROLOF )
       self.pil = self.VVu7wp("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVu7wp("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVu7wp("pls_code"  )
       self.iStId = self.VVu7wp("is_id"   )
       self.t2PlId = self.VVu7wp("t2mi_plp_id" )
       self.t2PId = self.VVu7wp("t2mi_pid"  )
 def VVu7wp(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFAmCN(val)
  elif mod == 2   : return FF7EuD(val)
  elif mod == 3   : return str(int(val) / 1000)
  elif mod == 4   : return str(int(val) / 1000)
  else     : return str(val)
 def VVjZZL(self, refCode):
  txt = ""
  self.VVGsIM(refCode)
  if self.data:
   def VV1j34(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VV1j34("System"   , self.syst)
    txt += VV1j34("Satellite"  , self.sat2)
    txt += VV1j34("Frequency"  , self.freq)
    txt += VV1j34("Inversion"  , self.inv)
    txt += VV1j34("Symbol Rate"  , self.sr)
    txt += VV1j34("Polarization" , self.pol)
    txt += VV1j34("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VV1j34("Modulation" , self.mod)
     txt += VV1j34("Roll-Off" , self.rolof)
     txt += VV1j34("Pilot"  , self.pil)
     txt += VV1j34("Input Stream", self.iStId)
     txt += VV1j34("T2MI PLP ID" , self.t2PlId)
     txt += VV1j34("T2MI PID" , self.t2PId)
     txt += VV1j34("PLS Mode" , self.plsMod)
     txt += VV1j34("PLS Code" , self.plsCod)
   else:
    txt += VV1j34("System"   , self.txMedia)
    txt += VV1j34("Frequency"  , self.freq)
  return txt, self.namespace
 def VV8OWb(self, refCode):
  txt = "Transpoder : ?"
  self.VVGsIM(refCode)
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s  %s" % (self.freq, self.pol[:1], self.fec, self.sr, VVpg8I + self.sat2)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return txt
 def VVWYTS(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFAL9w(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVu7wp(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVu7wp(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVu7wp(self.SYST, self.D_SYS_S)
     freq = self.VVu7wp(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVu7wp(self.POL , self.D_POL)
      fec = self.VVu7wp(self.FEC , self.D_FEC)
      sr = self.VVu7wp(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VV9B7N(self, refCode):
  self.data = None
  self.VVGsIM(refCode)
  if self.data and self.freq : return True
  else      : return False
class CC0hs4():
 def __init__(self, VVaB13, path, VVS99s=None, curRowNum=-1):
  self.VVaB13  = VVaB13
  self.origFile   = path
  self.Title    = "File Editor: " + os.path.basename(os.path.normpath(path))
  self.VVS99s  = VVS99s
  self.tmpFile   = "/tmp/ajpanel_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  response = os.system(FFps7R("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)))
  if response == 0:
   self.VV3TvM(curRowNum)
  else:
   FFBAp7(self.VVaB13, "Error while preparing edit!")
 def VV3TvM(self, curRowNum):
  VVhCPI = self.VVUdxv()
  VV5uBQ = None #("Delete Line" , self.deleteLine  , [])
  VVw8s5 = ("Save Changes" , self.VV0nsJ   , [])
  VV69tn  = ("Edit Line"  , self.VVYjpn    , [])
  VVGv9L = ("Line Options" , self.VVU3sJ   , [])
  VVDKrQ = (""    , self.VVDdgg , [])
  VVFhJO = self.VVVIlr
  VVezXI  = self.VVzjMx
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VV32KX  = (CENTER  , LEFT  )
  VVByVq = FFN0i6(self.VVaB13, None, title=self.Title, header=header, VV1rg6=VVhCPI, VV32KX=VV32KX, VVDe98=widths, VVwZKv=26, VV5uBQ=VV5uBQ, VVw8s5=VVw8s5, VV69tn=VV69tn, VVGv9L=VVGv9L, VVFhJO=VVFhJO, VVezXI=VVezXI, VVDKrQ=VVDKrQ, VVB9Wc=True
    , VVZ7ot   = "#11001111"
    , VVuutY   = "#11001111"
    , VV5tqg   = "#11001111"
    , VVwtgu  = "#05333333"
    , VVorfQ  = "#00222222"
    , VV1sri  = "#11331133"
    )
  VVByVq.VV5bpT(curRowNum)
 def VVU3sJ(self, VVByVq, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVByVq.VVlbt7()
  VVJ4VL = []
  VVJ4VL.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVJ4VL.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVicup"  ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVyLHd:
   VVJ4VL.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(  ("Delete Line"         , "deleteLine"   ))
  FFdrYz(self.VVaB13, boundFunction(self.VVkV7J, VVByVq, lineNum), VVJ4VL=VVJ4VL, title="Line Options")
 def VVkV7J(self, VVByVq, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVfk5U("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVByVq)
   elif item == "VVicup"  : self.VVicup(VVByVq, lineNum)
   elif item == "copyToClipboard"  : self.VVFYGF(VVByVq, lineNum)
   elif item == "pasteFromClipboard" : self.VVTeiB(VVByVq, lineNum)
   elif item == "deleteLine"   : self.VVfk5U("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVByVq)
 def VVzjMx(self, VVByVq):
  VVByVq.VV7p6f()
 def VVDdgg(self, VVByVq, title, txt, colList):
  if   self.insertMode == 1: VVByVq.VVL0qS()
  elif self.insertMode == 2: VVByVq.VVqO3b()
  self.insertMode = 0
 def VVicup(self, VVByVq, lineNum):
  if lineNum == VVByVq.VVlbt7():
   self.insertMode = 1
   self.VVfk5U("echo '' >> '%s'" % self.tmpFile, VVByVq)
  else:
   self.insertMode = 2
   self.VVfk5U("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVByVq)
 def VVFYGF(self, VVByVq, lineNum):
  global VVyLHd
  VVyLHd = FFDup1("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVByVq.VVq6Qj("Copied to clipboard")
 def VV0nsJ(self, VVByVq, title, txt, colList):
  if self.fileChanged:
   backupOK = os.system(FFps7R("cp -f '%s' '%s'" % (self.origFile, self.origFile + ".bak")))
   if backupOK == 0:
    finalOK = os.system(FFps7R("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
    if finalOK == 0:
     VVByVq.VVq6Qj("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVByVq.VV7p6f()
    else:
     FFBAp7(self.VVaB13, "Cannot save file!")
   else:
    FFBAp7(self.VVaB13, "Cannot create backup copy of original file!")
 def VVVIlr(self, VVByVq):
  if self.fileChanged:
   FFJWhD(self.VVaB13, boundFunction(self.VVoc6N, VVByVq), "Cancel changes ?")
  else:
   finalOK = os.system(FFps7R("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)))
   self.VVoc6N(VVByVq)
 def VVoc6N(self, VVByVq):
  VVByVq.cancel()
  os.system(FFps7R("rm -f '%s'" % self.tmpFile))
  if self.VVS99s:
   self.VVS99s(self.fileSaved)
 def VVYjpn(self, VVByVq, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVjMps + "ORIGINAL TEXT:\n" + VVQDXE + lineTxt
  FFIilI(self.VVaB13, boundFunction(self.VVP7qA, lineNum, VVByVq), title="File Line", defaultText=lineTxt, message=message)
 def VVP7qA(self, lineNum, VVByVq, VVVjkg):
  if not VVVjkg is None:
   if VVByVq.VVlbt7() <= 1:
    self.VVfk5U("echo %s > '%s'" % (VVVjkg, self.tmpFile), VVByVq)
   else:
    self.VVgLOC(VVByVq, lineNum, VVVjkg)
 def VVTeiB(self, VVByVq, lineNum):
  if lineNum == VVByVq.VVlbt7() and VVByVq.VVlbt7() == 1:
   self.VVfk5U("echo %s >> '%s'" % (VVyLHd, self.tmpFile), VVByVq)
  else:
   self.VVgLOC(VVByVq, lineNum, VVyLHd)
 def VVgLOC(self, VVByVq, lineNum, newTxt):
  VVByVq.VVCgW1("Saving ...")
  lines = FFHvYZ(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVByVq.VVor9V()
  VVhCPI = self.VVUdxv()
  VVByVq.VVzmZc(VVhCPI)
 def VVfk5U(self, cmd, VVByVq):
  tCons = CCHJqS()
  tCons.ePopen(cmd, boundFunction(self.VV9zyE, VVByVq))
  self.fileChanged = True
  VVByVq.VVor9V()
 def VV9zyE(self, VVByVq, result, retval):
  VVhCPI = self.VVUdxv()
  VVByVq.VVzmZc(VVhCPI)
 def VVUdxv(self):
  if fileExists(self.tmpFile):
   lines = FFHvYZ(self.tmpFile)
   VVhCPI = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVhCPI.append((str(ndx), line.strip()))
   if not VVhCPI:
    VVhCPI.append((str(1), ""))
   return VVhCPI
  else:
   FFhMRQ(self.VVaB13, self.tmpFile)
class CCQuuR():
 def __init__(self, callingSELF):
  self.callingSELF  = callingSELF
  self.VVJ4VL   = []
  self.satList   = []
 def VVaSAo(self, VVS99s):
  self.VVJ4VL = []
  VVJ4VL, VVxMbJ = self.VVWYX6(False, True)
  if VVJ4VL:
   self.VVJ4VL += VVJ4VL
   self.VVNxD2(VVS99s, VVxMbJ)
 def VVrnLF(self, mode, VVByVq, satCol, VVS99s):
  VVByVq.VVCgW1("Loading Filters ...")
  self.VVJ4VL = []
  self.VVJ4VL.append(("All Services" , "all"))
  if mode == 1:
   self.VVJ4VL.append(VV1dpw)
   self.VVJ4VL.append(("Parental Control", "parentalControl"))
   self.VVJ4VL.append(("Hidden Services" , "hiddenServices"))
  elif mode == 2:
   self.VVJ4VL.append(VV1dpw)
   self.VVJ4VL.append(("Selected Transponder"   , "selectedTP" ))
   self.VVJ4VL.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VVcmtB(VVByVq, satCol)
  VVJ4VL, VVxMbJ = self.VVWYX6(True, False)
  if VVJ4VL:
   VVJ4VL.insert(0, VV1dpw)
   self.VVJ4VL += VVJ4VL
  VVByVq.VVZQH0()
  self.VVNxD2(VVS99s, VVxMbJ)
 def VV1X6z(self, VVJ4VL, sats, VVS99s):
  self.VVJ4VL = VVJ4VL
  VVJ4VL, VVxMbJ = self.VVWYX6(True, False)
  if VVJ4VL:
   self.VVJ4VL.append(VV1dpw)
   self.VVJ4VL += VVJ4VL
  self.VVNxD2(VVS99s, VVxMbJ)
 def VVNxD2(self, VVS99s, VVxMbJ):
  VVx8rq = ("Edit Filter", boundFunction(self.VVgD1i, VVxMbJ))
  VVfXyU  = ("Filter Help", boundFunction(self.VVKAIV, VVxMbJ))
  FFdrYz(self.callingSELF, boundFunction(self.VVsgUV, VVS99s), VVJ4VL=self.VVJ4VL, title="Select Filter", VVx8rq=VVx8rq, VVfXyU=VVfXyU)
 def VVsgUV(self, VVS99s, item):
  if item:
   VVS99s(item)
 def VVgD1i(self, VVxMbJ, VVH9sbObj, sel):
  if fileExists(VVxMbJ) : CC0hs4(self.callingSELF, VVxMbJ, VVS99s=None)
  else       : FFhMRQ(self.callingSELF, VVxMbJ)
  VVH9sbObj.cancel()
 def VVKAIV(self, VVxMbJ, VVH9sbObj, sel):
  FFf485(self.callingSELF, VVqrRB + "_help_service_filter", "Service Filter")
 def VVcmtB(self, VVByVq, satColNum):
  if not self.satList:
   satList = VVByVq.VV443b(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FFEeIv(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, VV1dpw)
  if self.VVJ4VL:
   self.VVJ4VL += self.satList
 def VVWYX6(self, addTag, VVqJ5y):
  FFV4Ub()
  fileName  = "ajpanel_services_filter"
  VVxMbJ = VVmnJB + fileName
  VVJ4VL  = []
  if not fileExists(VVxMbJ):
   os.system(FFps7R("cp -f '%s' '%s'" % (VVqrRB + fileName, VVxMbJ)))
  fileFound = False
  if fileExists(VVxMbJ):
   fileFound = True
   lines = FFHvYZ(VVxMbJ)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       parts = line.split(",")
       newWords = []
       for item in parts:
        item = item.strip()
        if item:
         newWords.append(item)
       if newWords:
        line = ",".join(newWords)
      if line:
       if addTag: VVJ4VL.append((line, "__w__" + line))
       else  : VVJ4VL.append((line, line))
  if VVqJ5y:
   if   not fileFound : FFhMRQ(self.callingSELF , VVxMbJ)
   elif not VVJ4VL : FFY69f(self.callingSELF , VVxMbJ)
  return VVJ4VL, VVxMbJ
 @staticmethod
 def VVaZUu(words):
  asPrefix = False
  if words:
   tmp = words.strip().lower()
   if tmp[:1] == "^":
    tmp = tmp[1:]
    asPrefix = True
   if "," in tmp: tmp = tmp.split(",")
   else   : tmp = [tmp]
   words = []
   for w in tmp:
    w = w.strip()
    if w:
     words.append(w)
  return words, asPrefix
class CCn4gV():
 def __init__(self, callingSELF, VVByVq, refCodeColNum, addSep=True):
  self.callingSELF = callingSELF
  self.VVByVq = VVByVq
  self.refCodeColNum = refCodeColNum
  self.VVJ4VL = []
  iMulSel = self.VVByVq.VVqRGP()
  if iMulSel : self.VVJ4VL.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVJ4VL.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVByVq.VVGUaE()
  self.VVJ4VL.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVJ4VL.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVJ4VL.append(VV1dpw)
 def VVY92X(self, servName):
  tot = self.VVByVq.VVGUaE()
  s = "s" if tot > 1 else ""
  if tot > 0   : self.VVJ4VL.append( ("Add to Bouquet : %d selected channel%s" % (tot, s) , "VVcxT6_multi" ))
  else    : self.VVJ4VL.append( ("Add to Bouquet : %s"      % servName , "VVcxT6_one" ))
 def VVORrI(self, servName, refCode):
  self.VVY92X(servName)
  self.VVLCzt(servName, refCode)
 def VVykF8(self, servName, refCode, pcState, hidState):
  isMulti = self.VVByVq.VVTa6z
  if isMulti:
   refCodeList = self.VVByVq.VVcoGn(3)
   if refCodeList:
    self.VVJ4VL.append(("Add Selection to Parental Control"    , "parentalControl_sel_add"  ))
    self.VVJ4VL.append(("Remove Selection from Parental Control"   , "parentalControl_sel_remove" ))
    self.VVJ4VL.append(VV1dpw)
    self.VVJ4VL.append(("Add Selection to Hidden Services"    , "hiddenServices_sel_add"  ))
    self.VVJ4VL.append(("Remove Selection from Hidden Services"   , "hiddenServices_sel_remove" ))
   else:
    self.VVJ4VL.pop(len(self.VVJ4VL) - 1)
  else:
   if pcState == "No" : self.VVJ4VL.append(("Add to Parental Control"  , "parentalControl_add"   ))
   else    : self.VVJ4VL.append(("Remove from Parental Control" , "parentalControl_remove"  ))
   self.VVJ4VL.append(VV1dpw)
   if hidState == "No" : self.VVJ4VL.append(("Add to Hidden Services"  , "hiddenServices_add"   ))
   else    : self.VVJ4VL.append(("Remove from Hidden Services" , "hiddenServices_remove"  ))
  self.VVJ4VL.append(VV1dpw)
  self.VVY92X(servName)
  self.VVLCzt(servName, refCode)
 def VVLCzt(self, servName, refCode):
  FFdrYz(self.callingSELF, boundFunction(self.VVmk8d, servName, refCode), title="Options", VVJ4VL=self.VVJ4VL)
 def VVmk8d(self, servName, refCode, item=None):
  if item:
   if   item == "multSelEnab"     : self.VVByVq.VVHK3s(True)
   elif item == "MultSelDisab"     : self.VVByVq.VVHK3s(False)
   elif item == "selectAll"     : self.VVByVq.VVrbd3()
   elif item == "unselectAll"     : self.VVByVq.VV6cA9()
   elif item == "parentalControl_add"   : self.callingSELF.VVU3jm(self.VVByVq, refCode, True)
   elif item == "parentalControl_remove"  : self.callingSELF.VVU3jm(self.VVByVq, refCode, False)
   elif item == "hiddenServices_add"   : self.callingSELF.VVN3fs(self.VVByVq, refCode, True)
   elif item == "hiddenServices_remove"  : self.callingSELF.VVN3fs(self.VVByVq, refCode, False)
   elif item == "parentalControl_sel_add"  : self.callingSELF.VVswGt(self.VVByVq, True)
   elif item == "parentalControl_sel_remove" : self.callingSELF.VVswGt(self.VVByVq, False)
   elif item == "hiddenServices_sel_add"  : self.callingSELF.VVTSwS(self.VVByVq, True)
   elif item == "hiddenServices_sel_remove" : self.callingSELF.VVTSwS(self.VVByVq, False)
   elif item == "VVcxT6_multi"  : self.VVcxT6(refCode, True)
   elif item == "VVcxT6_one"  : self.VVcxT6(refCode, False)
 def VVlcGm(self, VVByVq):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  mSel   = CCn4gV(self, VVByVq, 3)
  mSel.VVORrI(servName, refCode)
 def VVcxT6(self, refCode, isMulti):
  bouquets = FF1OCM()
  if bouquets:
   VVJ4VL = []
   for item in bouquets:
    VVJ4VL.append((item[0], item[1].toString()))
   VVx8rq = ("Create New", boundFunction(self.VVQbNC, refCode, isMulti))
   FFdrYz(self.callingSELF, boundFunction(self.VVgwvQ, refCode, isMulti), VVJ4VL=VVJ4VL, title="Add to Bouquet", VVx8rq=VVx8rq, VVYMy8=True, VVEfaQ=True)
  else:
   FFJWhD(self.callingSELF, boundFunction(self.VV3HzZ, refCode, isMulti), "No Bouquets found!\n\nCreate New ?")
 def VVgwvQ(self, refCode, isMulti, bName=None):
  if bName:
   FFobhC(self.VVByVq, boundFunction(self.VVP6h5, refCode, isMulti, bName), title="Adding Channels ...")
 def VVP6h5(self, refCode, isMulti, bName=None):
  txt, ref, ndx = bName
  refCodeList = self.VVDk82(refCode, isMulti)
  tot   = 0
  if refCodeList:
   bRef = eServiceReference(ref)
   if bRef:
    VVw7XZ = InfoBar.instance
    if VVw7XZ:
     VV7u2w = VVw7XZ.servicelist
     if VV7u2w:
      mutableList = VV7u2w.getMutableList(bRef)
      if not mutableList is None:
       for refCode in refCodeList:
        rej = mutableList.addService(eServiceReference(refCode))
        if not rej:
         tot += 1
       mutableList.flushChanges()
  self.VVByVq.VVZQH0()
  title = "Add to Bouquet"
  s = "s" if tot > 1 else ""
  if tot > 0 : FFSzHX(self.callingSELF  , "Added %d service%s to : %s" % (tot, s, txt) , title=title)
  else  : FFBAp7(self.callingSELF, "Nothing added to : %s"  % txt   , title=title)
 def VVDk82(self, refCode, isMulti):
  if isMulti : refCodeList = self.VVByVq.VVcoGn(self.refCodeColNum)
  else  : refCodeList = [refCode]
  return refCodeList
 def VVQbNC(self, refCode, isMulti, VVH9sbObj, path):
  self.VV3HzZ(refCode, isMulti)
 def VV3HzZ(self, refCode, isMulti):
  FFIilI(self.callingSELF, boundFunction(self.VVvMVw, refCode, isMulti), defaultText="Bouquet1", title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVvMVw(self, refCode, isMulti, name):
  if name:
   FFobhC(self.VVByVq, boundFunction(self.VVhWGz, refCode, isMulti, name), title="Adding Channels ...")
 def VVhWGz(self, refCode, isMulti, name):
   allOK  = False
   refCodeList = self.VVDk82(refCode, isMulti)
   if refCodeList:
    services = []
    for refCode in refCodeList:
     services.append(eServiceReference(refCode))
    refCodeList = None
    VVw7XZ = InfoBar.instance
    if VVw7XZ:
     VV7u2w = VVw7XZ.servicelist
     if VV7u2w:
      try:
       VV7u2w.addBouquet(name, services)
       allOK = True
      except:
       try:
        VV7u2w.addBouquet(name, 0, services)
        allOK = True
       except:
        pass
   self.VVByVq.VVZQH0()
   title = "Add to Bouquet"
   if allOK: FFSzHX(self.callingSELF, "Added to : %s" % name, title=title)
   else : FFBAp7(self.callingSELF, "Nothing added!", title=title)
class CCzfDX(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFbmPq(VVaU94, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF9Cql(self)
  FFCpCt(self["keyRed"]  , "Exit")
  FFCpCt(self["keyGreen"]  , "Save")
  FFCpCt(self["keyYellow"] , "Refresh")
  FFCpCt(self["keyBlue"]  , "NTP Mode")
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVBFS4  ,
   "green"   : self.VVapqB ,
   "yellow"  : self.VV0OnV  ,
   "blue"   : self.VVy0wY   ,
   "up"   : self.VVgxd0    ,
   "down"   : self.VVzN12   ,
   "left"   : self.VVTvlD   ,
   "right"   : self.VVrNqN   ,
   "cancel"  : self.VVBFS4
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShow.append(self.start)
 def start(self):
  self.VV0OnV()
  self.VVxnpl()
  FF4l2q(self)
 def VVBFS4(self) : self.close(True)
 def VVnq8m(self) : self.close(False)
 def VVy0wY(self):
  self.session.openWithCallback(self.VVWhwy, boundFunction(CCPZMX))
 def VVWhwy(self, closeAll):
  if closeAll:
   self.close()
 def VVgxd0(self):
  self.VVqYIo(1)
 def VVzN12(self):
  self.VVqYIo(-1)
 def VVTvlD(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVxnpl()
 def VVrNqN(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVxnpl()
 def VVqYIo(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVjipL(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVjipL(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVjipL(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VV4Rz9(year)):
   days += 1 #29 days in a leap year February
  return days
 def VV4Rz9(self, year):
  if year%4 == 0:
   if year%100 == 0:
    if year%400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVxnpl(self):
  for obj in self.list:
   FF3luO(obj, "#11404040")
  FF3luO(self.list[self.index], "#11ff8000")
 def VV0OnV(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVapqB(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCHJqS()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVFLxz)
 def VVFLxz(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FFSzHX(self, "Nothing returned from the system!")
  else:
   FFSzHX(self, str(result))
class CCPZMX(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFbmPq(VVDouV, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FF9Cql(self, addLabel=True)
  FFCpCt(self["keyRed"]  , "Exit")
  FFCpCt(self["keyGreen"]  , "Sync")
  FFCpCt(self["keyYellow"] , "Refresh")
  FFCpCt(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVBFS4   ,
   "green"   : self.VVhr4v  ,
   "yellow"  : self.VV2CDE ,
   "blue"   : self.VVOUVl  ,
   "cancel"  : self.VVBFS4
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVJJvT()
  self.onShow.append(self.start)
 def start(self):
  FFOFIS(self.refresh)
  FF4l2q(self)
 def refresh(self):
  self.VVsepI()
  self.VVqM90(False)
 def VVBFS4(self)  : self.close(True)
 def VVOUVl(self) : self.close(False)
 def VVJJvT(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVsepI(self):
  self.VV7Zqr()
  self.VVDyNL()
  self.VVk73E()
  self.VVxjXe()
 def VV2CDE(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVJJvT()
   self.VVsepI()
   FFOFIS(self.refresh)
 def VVhr4v(self):
  if len(self["keyGreen"].getText()) > 0:
   FFJWhD(self, self.VV7n1e, "Synchronize with Internet Date/Time ?")
 def VV7n1e(self):
  self.VVsepI()
  FFOFIS(boundFunction(self.VVqM90, True))
 def VV7Zqr(self)  : self["keyRed"].show()
 def VVqLxh(self)  : self["keyGreen"].show()
 def VVXuhM(self) : self["keyYellow"].show()
 def VVZEAF(self)  : self["keyBlue"].show()
 def VVDyNL(self)  : self["keyGreen"].hide()
 def VVk73E(self) : self["keyYellow"].hide()
 def VVxjXe(self)  : self["keyBlue"].hide()
 def VVqM90(self, sync):
  localTime = FFqUqE()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVD3Ca(server)
   if epoch_time is not None:
    ntpTime = FF78kj(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCHJqS()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, boundFunction(self.VVFLxz, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVXuhM()
  self.VVZEAF()
  if ok:
   self.VVqLxh()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVFLxz(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVqM90(False)
  except:
   pass
 def VVD3Ca(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if FFFIVQ():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCinGe(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFbmPq(VVl5Hy, 900, 300, 50, 20, 0, "#22000060", "#22002020", 35)
  self.session  = session
  FF9Cql(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FFOFIS(self.VVCNHn)
 def VVCNHn(self):
  if FFFIVQ(): color, txt = "#22002020", "Internet Connection = Successful."
  else   : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FF3luO(self["myBody"], color)
   FF3luO(self["myLabel"], color)
  except:
   pass
class CCIaJa(Screen):
 def __init__(self, session, isFromExternal=False):
  size = CFG.signalSize.getValue()
  screenW = FFTeeG()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFbmPq(VVp0oQ, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self.isFromExternal  = isFromExternal
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCdSuX(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCdSuX(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCdSuX(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCfM78()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FF9Cql(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close         ,
   "up"  : self.VVgxd0          ,
   "down"  : self.VVzN12         ,
   "left"  : self.VVTvlD         ,
   "right"  : self.VVrNqN         ,
   "info"  : self.VVPFTE        ,
   "epg"  : self.VVPFTE        ,
   "menu"  : self.VVL9hp         ,
   "cancel" : self.close         ,
   "red"  : self.close         ,
   "blue"  : self.VVFjPA       ,
   "last"  : boundFunction(self.VVHOdH, -1)  ,
   "next"  : boundFunction(self.VVHOdH, 1)  ,
   "pageUp" : boundFunction(self.VV60iQ, True) ,
   "chanUp" : boundFunction(self.VV60iQ, True) ,
   "pageDown" : boundFunction(self.VV60iQ, False) ,
   "chanDown" : boundFunction(self.VV60iQ, False) ,
   "0"   : boundFunction(self.VVHOdH, 0)  ,
   "1"   : boundFunction(self.VVZUzN, pos=1) ,
   "2"   : boundFunction(self.VVZUzN, pos=2) ,
   "3"   : boundFunction(self.VVZUzN, pos=3) ,
   "4"   : boundFunction(self.VVZUzN, pos=4) ,
   "5"   : boundFunction(self.VVZUzN, pos=5) ,
   "6"   : boundFunction(self.VVZUzN, pos=6) ,
   "7"   : boundFunction(self.VVZUzN, pos=7) ,
   "8"   : boundFunction(self.VVZUzN, pos=8) ,
   "9"   : boundFunction(self.VVZUzN, pos=9) ,
  }, -1)
  self.onShown.append(self.VVJGeB)
  self.onClose.append(self.onExit)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  self.sliderSNR.VV2hdR()
  self.sliderAGC.VV2hdR()
  self.sliderBER.VV2hdR(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVZUzN()
  self.VVZKxGInfo()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVZKxG)
  except:
   self.timer.callback.append(self.VVZKxG)
  self.timer.start(500, False)
 def VVZKxGInfo(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VV7YR1(service)
  serviceName = self.tunerInfo.VV99Ld()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self)
  tp = CCYelw()
  txt = tp.VV8OWb(refCode)
  del tp
  self["myTPInfo"].setText(txt)
 def VVZKxG(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VV7YR1(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VV416K())
   self["mySNR"].setText(self.tunerInfo.VVN2kz())
   self["myAGC"].setText(self.tunerInfo.VV2zAV())
   self["myBER"].setText(self.tunerInfo.VVuUCa())
   self.sliderSNR.VVhaZE(self.tunerInfo.VVR1ED())
   self.sliderAGC.VVhaZE(self.tunerInfo.VVeQS1())
   self.sliderBER.VVhaZE(self.tunerInfo.VVXm1M())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVhaZE(0)
   self.sliderAGC.VVhaZE(0)
   self.sliderBER.VVhaZE(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self)
    if state and not state == "Tuned":
     FFtMdo(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVPFTE(self):
  FFnMVC(self, fncMode=CCipRP.VV7ysN)
 def VVL9hp(self):
  FFf485(self, VVqrRB + "_help_signal", "Signal Monitor (Keys)")
 def VVFjPA(self):
  self.session.open(CC7tge, isFromExternal=self.isFromExternal)
  self.close()
 def VVgxd0(self)  : self.VVZUzN(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVzN12(self) : self.VVZUzN(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVTvlD(self) : self.VVZUzN(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVrNqN(self) : self.VVZUzN(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVZUzN(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   CFG.signalPos.setValue(self.curPosNum)
   CFG.signalPos.save()
   configfile.save()
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVHOdH(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFIeYG(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   CFG.signalSize.setValue(sizeNum)
   CFG.signalSize.save()
   configfile.save()
   self.close(True)
 def onExit(self):
  self.timer.stop()
 def VV60iQ(self, isUp):
  FFtMdo(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVZKxGInfo()
  except:
   pass
class CCdSuX(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VV2hdR(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FF3luO(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVqrRB +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FF3luO(self.covObj, self.covColor)
   else:
    FF3luO(self.covObj, "#00006688")
    self.isColormode = True
  self.VVhaZE(0)
 def VVhaZE(self, val):
  val  = FFIeYG(val, self.minN, self.maxN)
  width = int(FFOZ0S(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFIeYG(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CC1LNl(Screen):
 VVFMDb    = 0
 VVLvJ7 = 1
 VVpzDK = 2
 def __init__(self, session, titlePrefix="Processing ...", fncToRun=None, VVS99s=None, barTheme=VVFMDb):
  ratio = self.VVYopJ(barTheme)
  self.skin, self.skinParam = FFbmPq(VVyrEB, 900, 200, 30, 40, 30, "#0a042328", "#0a042328", 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.fncToRun  = fncToRun
  self.VVS99s = VVS99s
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVx2td = None
  self.timer   = eTimer()
  self.myThread  = None
  FF9Cql(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "cancel"  : self.cancel
  }, -1)
  self.onShown.append(self.VVJGeB)
  self.onClose.append(self.onExit)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  self.VVp800()
  self["myProgBarVal"].setText("0%")
  FF3luO(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVxXen()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVxXen)
  except:
   self.timer.callback.append(self.VVxXen)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=boundFunction(self.fncToRun, self))
  self.myThread.start()
 def VVXZBN(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVYUI4_fromIptvFind(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVx2td), self.counter, self.maxValue, catName)
 def VVYUI4_fromImportEPG(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVYUI4_forcedUpdate(self, title):
  self.newTitle = title
  try:
   self.VVxXen()
  except:
   pass
 def VVjClj(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\tProcessed : %d of %d" % (len(self.VVx2td), self.counter, self.maxValue)
  except:
   pass
 def VVadmW(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVCjQV(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVuGYr(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFtMdo(self, "Cancelling ...")
  self.isCancelled = True
  self.VV1Imn(False)
 def VV1Imn(self, isDone):
  if self.VVS99s:
   self.VVS99s(isDone, self.VVx2td, self.counter, self.maxValue, self.isError)
  self.close()
 def VVxXen(self):
  val = FFIeYG(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFOZ0S(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self.VV1Imn(True)
 def VVp800(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VVLvJ7, self.VVpzDK):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVYopJ(self, barTheme):
  if   barTheme == self.VVLvJ7 : return 0.7
  if   barTheme == self.VVpzDK : return 0.5
  else             : return 1
class CCHJqS(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVS99s = {}
  self.commandRunning = False
  self.VV2ASm  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVS99s, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVS99s[name] = VVS99s
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VV2ASm:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(boundFunction(self.VVrxM2, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(boundFunction(self.VV6wpK , name))
   else:
    self.appContainers[name].dataAvail.append(boundFunction(self.VVrxM2, name))
    self.appContainers[name].appClosed.append(boundFunction(self.VV6wpK , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VV6wpK(name, retval)
  return True
 def VVrxM2(self, name, data):
  data = data.decode("UTF-8")
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VV6wpK(self, name, retval):
  if not self.VV2ASm:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVS99s[name]:
   self.VVS99s[name](self.appResults[name], retval)
  del self.VVS99s[name]
 def VVibuB(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCA5J7(Screen):
 def __init__(self, session, title="", VVAIfv=None, VVJIg6=False, VVn7rS=False, VVyEiS=False, VVBv1I=False, VVotGp=False, VVin47=False, VVFuWe=VVdoHn, VVrZnU=None, VVTvTM=False, VVgVVL=None, VVDFjd="", checkNetAccess=False, enableSaveRes=True):
  self.skin, self.skinParam = FFbmPq(VVukgN, 1400, 800, 50, 40, 20, "#22003040", "#22001122", 30)
  self.session   = session
  FF9Cql(self, addScrollLabel=True)
  if not VVDFjd:
   VVDFjd = "Processing ..."
  self["myLabel"].setText("   %s" % VVDFjd)
  self.VVJIg6   = VVJIg6
  self.VVn7rS   = VVn7rS
  self.VVyEiS   = VVyEiS
  self.VVBv1I  = VVBv1I
  self.VVotGp = VVotGp
  self.VVin47 = VVin47
  self.VVFuWe   = VVFuWe
  self.VVrZnU = VVrZnU
  self.VVTvTM  = VVTvTM
  self.VVgVVL  = VVgVVL
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCHJqS()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFmdhR()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVAIfv, str):
   self.VVAIfv = [VVAIfv]
  else:
   self.VVAIfv = VVAIfv
  if self.VVyEiS or self.VVBv1I:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (VVlhhY, VVlhhY)
   self.VVAIfv.append("echo -e '\n%s\n' %s" % (restartNote, FFOCvV(restartNote, VVWvE3)))
   if self.VVyEiS:
    self.VVAIfv.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVAIfv.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVotGp:
   FFtMdo(self, "Processing ...")
  self.onLayoutFinish.append(self.VVzWZr)
  self.onClose.append(self.VVVKtb)
 def VVzWZr(self):
  self["myLabel"].VVmT9l(textOutFile="console" if self.enableSaveRes else "")
  if self.VVJIg6:
   self["myLabel"].VV1ZXK()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VVuTtA()
  else:
   self.VVYMBK()
 def VVuTtA(self):
  if FFFIVQ():
   self["myLabel"].setText("Processing ...")
   self.VVYMBK()
  else:
   self["myLabel"].setText(FF2tuT("\n   No connection to internet!", VVpKeT))
 def VVYMBK(self):
  allOK = self.container.ePopen(self.VVAIfv[0], self.VVb3ox, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVb3ox("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVin47 or self.VVyEiS or self.VVBv1I:
    self["myLabel"].setText(FFZuRe("STARTED", VVWvE3) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVgVVL:
   colorWhite = CCRLh1.VVRG9q(VVjMps)
   color  = CCRLh1.VVRG9q(self.VVgVVL[0])
   words  = self.VVgVVL[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVFuWe=self.VVFuWe)
 def VVb3ox(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVAIfv):
   allOK = self.container.ePopen(self.VVAIfv[self.cmdNum], self.VVb3ox, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVb3ox("Cannot connect to Console!", -1)
  else:
   if self.VVotGp and FFTKsv(self):
    FFtMdo(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVin47:
    self["myLabel"].appendText("\n" + FFZuRe("FINISHED", VVWvE3), self.VVFuWe)
   if self.VVJIg6 or self.VVn7rS:
    self["myLabel"].VV1ZXK()
   if self.VVrZnU is not None:
    self.VVrZnU()
   if not retval and self.VVTvTM:
    self.VVVKtb()
 def VVVKtb(self):
  if self.container.VVibuB():
   self.container.killAll()
class CCAoKc(Screen):
 def __init__(self, session, VVAIfv=None, VVotGp=False):
  self.skin, self.skinParam = FFbmPq(VVukgN, 1600, 900, 50, 40, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVmnJB + "ajpanel_terminal.history"
  self.customCommandsFile = VVmnJB + "LinuxCommands.lst"
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFDup1("pwd") or "/home/root"
  self.container   = CCHJqS()
  FF9Cql(self, addScrollLabel=True)
  FFCpCt(self["keyRed"] , "Exit = Stop Command")
  FFCpCt(self["keyGreen"] , "OK = History")
  FFCpCt(self["keyYellow"], "Menu = Custom Cmds")
  FFCpCt(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVw3ym ,
   "cancel" : self.VVnavH  ,
   "menu"  : self.VVILWR ,
   "last"  : self.VVmEYZ  ,
   "next"  : self.VVmEYZ  ,
   "1"   : self.VVmEYZ  ,
   "2"   : self.VVmEYZ  ,
   "3"   : self.VVmEYZ  ,
   "4"   : self.VVmEYZ  ,
   "5"   : self.VVmEYZ  ,
   "6"   : self.VVmEYZ  ,
   "7"   : self.VVmEYZ  ,
   "8"   : self.VVmEYZ  ,
   "9"   : self.VVmEYZ  ,
   "0"   : self.VVmEYZ
  })
  self.onLayoutFinish.append(self.VVJGeB)
  self.onClose.append(self.VV2AOz)
 def VVJGeB(self):
  self["myLabel"].VVmT9l(isResizable=False, textOutFile="terminal")
  FFZkbe(self["keyRed"]  , "#00ff8000")
  FF3luO(self["keyRed"]  , self.skinParam["titleColor"])
  FF3luO(self["keyGreen"]  , self.skinParam["titleColor"])
  FF3luO(self["keyYellow"] , self.skinParam["titleColor"])
  FF3luO(self["keyBlue"] , self.skinParam["titleColor"])
  self.VV6nD9(FFDup1("date"), 5)
  result = FFDup1("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVMAG0()
  if not fileExists(self.customCommandsFile):
   oldTemplate = VVqrRB + "LinuxCommands.lst"
   newTemplate = VVqrRB + "ajpanel_cmd_list"
   if   fileExists(oldTemplate): os.system(FFps7R("mv -f '%s' '%s'" % (oldTemplate, self.customCommandsFile)))
   elif fileExists(newTemplate): os.system(FFps7R("cp -f '%s' '%s'" % (newTemplate, self.customCommandsFile)))
 def VV2AOz(self):
  if self.container.VVibuB():
   self.container.killAll()
   self.VV6nD9("Process killed\n", 4)
   self.VVMAG0()
 def VVnavH(self):
  if self.container.VVibuB():
   self.VV2AOz()
  else:
   FFJWhD(self, self.close, "Exit ?", VVxElG=False)
 def VVMAG0(self):
  self.VV6nD9(self.prompt, 1)
  self["keyRed"].hide()
 def VV6nD9(self, txt, mode):
  if   mode == 1 : color = VVWvE3
  elif mode == 2 : color = VVpg8I
  elif mode == 3 : color = VVjMps
  elif mode == 4 : color = VVpKeT
  elif mode == 5 : color = VVQDXE
  elif mode == 6 : color = VVaVAY
  else   : color = VVjMps
  try:
   self["myLabel"].appendText(FF2tuT(txt, color))
  except:
   pass
 def VVHZjG(self, cmd):
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VV6nD9(cmd, 2)
   self.VV6nD9("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VV6nD9(ch, 0)
   self.VV6nD9("\nor\n", 4)
   self.VV6nD9("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVMAG0()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FF2tuT(parts[0].strip(), VVpg8I)
    right = FF2tuT("#" + parts[1].strip(), VVaVAY)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VV6nD9(txt, 2)
   lastLine = self.VVaVEP()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVC8FZ(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVb3ox, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFBAp7(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VV6nD9(data, 3)
 def VVb3ox(self, data, retval):
  if not retval == 0:
   self.VV6nD9("Exit Code : %d\n" % retval, 4)
  self.VVMAG0()
 def VVw3ym(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVaVEP() == "":
   self.VVC8FZ("cd /tmp")
   self.VVC8FZ("ls")
  VVhCPI = []
  if fileExists(self.commandHistoryFile):
   lines  = FFHvYZ(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVhCPI.append((str(c), line, str(lNum)))
   self.VVUkbK(VVhCPI, title, self.commandHistoryFile, isHistory=True)
  else:
   FFhMRQ(self, self.commandHistoryFile, title=title)
 def VVaVEP(self):
  lastLine = FFDup1("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVC8FZ(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVILWR(self):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines  = FFHvYZ(self.customCommandsFile)
   lastLineIsSep = False
   VVhCPI = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVhCPI.append((str(c), line, str(lNum)))
   self.VVUkbK(VVhCPI, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFhMRQ(self, self.customCommandsFile, title=title)
 def VVUkbK(self, VVhCPI, title, filePath=None, isHistory=False):
  if VVhCPI:
   VVwtgu = "#05333333"
   if isHistory: VVZ7ot = VVuutY = VV5tqg = "#11000020"
   else  : VVZ7ot = VVuutY = VV5tqg = "#06002020"
   VV3Y5Z = VVGv9L = None
   VV69tn   = ("Send"   , self.VV2w6J        , [])
   VVw8s5  = ("Modify & Send" , self.VV1o8U        , [])
   if isHistory:
    VV3Y5Z = ("Clear History" , self.VVHlUM        , [])
   elif filePath:
    VVGv9L = ("Edit File"  , boundFunction(self.VVZCN9, filePath) , [])
   header      = ("No."  , "Commands", "LineNum")
   widths      = (7   , 93   , 0    )
   VV32KX     = (CENTER  , LEFT   , CENTER )
   FFN0i6(self, None, title=title, header=header, VV1rg6=VVhCPI, VV32KX=VV32KX, VVDe98=widths, VVwZKv=26, VV69tn=VV69tn, VVw8s5=VVw8s5, VV3Y5Z=VV3Y5Z, VVGv9L=VVGv9L, VVB9Wc=True
     , VVZ7ot   = VVZ7ot
     , VVuutY   = VVuutY
     , VV5tqg   = VV5tqg
     , VVLZXK  = "#05ffff00"
     , VVwtgu  = VVwtgu
    )
  else:
   FFY69f(self, filePath, title=title)
 def VV2w6J(self, VVByVq, title, txt, colList):
  cmd = colList[1].strip()
  VVByVq.cancel()
  if not iMatch("^[a-zA-Z0-9_]", cmd):
   self.VV6nD9("\n%s\n" % cmd, 6)
   self.VV6nD9(self.prompt, 1)
  else:
   self.VVHZjG(cmd)
 def VV1o8U(self, VVByVq, title, txt, colList):
  cmd = colList[1]
  self.VVRcmG(VVByVq, cmd)
 def VVHlUM(self, VVByVq, title, txt, colList):
  FFJWhD(self, boundFunction(self.VVT3cX, VVByVq), "Reset History File ?", title="Command History")
 def VVT3cX(self, VVByVq):
  os.system(FFps7R("echo '' > %s" % self.commandHistoryFile))
  VVByVq.cancel()
 def VVZCN9(self, filePath, VVByVq, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CC0hs4(self, filePath, VVS99s=boundFunction(self.VVqkn9, VVByVq), curRowNum=rowNum)
  else     : FFhMRQ(self, filePath)
 def VVqkn9(self, VVByVq, fileChanged):
  if fileChanged:
   VVByVq.cancel()
   FFOFIS(self.VVILWR)
 def VVmEYZ(self):
  self.VVRcmG(None, self.lastCommand)
 def VVRcmG(self, VVByVq, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFIilI(self, boundFunction(self.VVFSpp, VVByVq), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVFSpp(self, VVByVq, cmd):
  if cmd and len(cmd) > 0:
   self.VVHZjG(cmd)
   if VVByVq:
    VVByVq.cancel()
class CCstQ0(Screen):
 from Components.Input  import Input
 from Components.ActionMap import NumberActionMap
 from enigma     import eRCInput
 def __init__(self, session, title="", message="", VVVjkg="", VVKfUk=False, VVOG4W=False, isTrimEnds=True):
  self.skin, self.skinParam = FFbmPq(VVcnnT, 1200, 400, 50, 80, 30, "#11440044", "#11220022", 22, topRightBtns=1, barHeight=40)
  self.session   = session
  self.message   = message
  FF9Cql(self, title, addLabel=True)
  FFCpCt(self["keyRed"] , "Up/Down = Change")
  FFCpCt(self["keyGreen"] , "Overwrite")
  FFCpCt(self["keyYellow"], "Pick Key Map")
  FFCpCt(self["keyBlue"] , "All Char.")
  self["myKeyMap"]  = Label("")
  self.charMode   = 0
  self.VVOG4W   = VVOG4W
  self.VVKfUk  = VVKfUk
  self.timer    = eTimer()
  self.isTrimEnds   = isTrimEnds
  self["myInput"]  = self.Input(text=VVVjkg, visible_width=50)
  self["actions"]  = self.NumberActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VV8air      ,
   "green"    : self.VVfFz2    ,
   "yellow"   : self.VVQzQm      ,
   "blue"    : self.VV72Av     ,
   "menu"    : self.VVLkJ1     ,
   "cancel"   : self.cancel       ,
   "up"    : boundFunction(self.VVMxVj, True) ,
   "down"    : boundFunction(self.VVMxVj, False) ,
   "left"    : self.VVuiTo       ,
   "right"    : self.VVDhBf       ,
   "home"    : self.VVbBtd       ,
   "end"    : self.VVBSim       ,
   "next"    : self.VVaFFN      ,
   "last"    : self.VVDhDd      ,
   "deleteForward"  : self.VVaFFN      ,
   "deleteBackward" : self.VVDhDd      ,
   "tab"    : self.VVx6QI       ,
   "toggleOverwrite" : self.VVfFz2    ,
   "0"     : self.VVfWaJ     ,
   "1"     : self.VVfWaJ     ,
   "2"     : self.VVfWaJ     ,
   "3"     : self.VVfWaJ     ,
   "4"     : self.VVfWaJ     ,
   "5"     : self.VVfWaJ     ,
   "6"     : self.VVfWaJ     ,
   "7"     : self.VVfWaJ     ,
   "8"     : self.VVfWaJ     ,
   "9"     : self.VVfWaJ
  }, -1)
  if self["myInput"].type == self.Input.TEXT:
   self.VVdRqc()
  self.onShown.append(self.VVJGeB)
  self.onClose.append(self.onExit)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FFGuuf(self)
  self["myLabel"].setText(self.message)
  self.VVFpaf()
  if self.VVKfUk : self.VVfFz2()
  else    : self.VVwDf0()
  FF4l2q(self)
  FF3luO(self["keyRed"], self.skinParam["titleColor"])
  self["myKeyMap"].hide()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVAu5z)
  except:
   self.timer.callback.append(self.VVAu5z)
 def onExit(self):
  self.timer.stop()
 def VV8air(self):
  self.VVGIK7()
  txt = self["myInput"].getText()
  if self.isTrimEnds:
   txt = txt.strip()
  self.close(txt)
 def cancel(self):
  self.VVGIK7()
  self.close(None)
 def VVLkJ1(self):
  VVJ4VL = []
  VVJ4VL.append(("Home"         , "home"    ))
  VVJ4VL.append(("End"         , "end"     ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Clear All"       , "clearAll"   ))
  VVJ4VL.append(("Clear To Home"      , "clearToHome"   ))
  VVJ4VL.append(("Clear To End"       , "clearToEnd"   ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Copy all to clipboard"    , "copyToClipboard"  ))
  if VVyLHd:
   VVJ4VL.append(("Paste from clipboard (overwrite)" , "pasteFromClipboard" ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("To Capital Letters"     , "toCapital"   ))
  VVJ4VL.append(("To Small Letters"      , "toSmall"    ))
  FFdrYz(self, self.VVhaGr, title="Edit Options", VVJ4VL=VVJ4VL)
 def VVhaGr(self, item=None):
  if item is not None:
   if   item == "home"     : self.VVbBtd()
   elif item == "end"     : self.VVBSim()
   elif item == "clearAll"    : self.VVuPrj()
   elif item == "clearToHome"   :
    self["myInput"].setText(self["myInput"].Text[self["myInput"].currPos:])
    self.VVbBtd()
   elif item == "clearToEnd"   : self["myInput"].setText(self["myInput"].Text[:self["myInput"].currPos])
   elif item == "copyToClipboard"  :
    global VVyLHd
    VVyLHd = self["myInput"].getText()
   elif item == "pasteFromClipboard" :
    self["myInput"].setText(VVyLHd)
    self.VVbBtd()
   elif item == "toCapital"   : self["myInput"].setText(self["myInput"].Text.upper())
   elif item == "toSmall"    : self["myInput"].setText(self["myInput"].Text.lower())
 def VVAu5z(self):
  self.timer.stop()
  self["myKeyMap"].hide()
 def VVfFz2(self):
  self["myInput"].toggleOverwrite()
  self.VVwDf0()
 def VVQzQm(self):
  self.session.openWithCallback(self.VVJQFJ, boundFunction(CCvXkC, mode=self.charMode, VVOG4W=self.VVOG4W))
 def VVJQFJ(self, mode):
  if mode is not None:
   self.charMode = mode
   self.VVFpaf()
 def VVwDf0(self):
  if self["myInput"].overwrite : self["keyGreen"].setText("Overwrite Mode")
  else       : self["keyGreen"].setText("Insert Mode")
 def VVdRqc(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmAscii)
 def VVGIK7(self):
  rcinput = self.eRCInput.getInstance()
  rcinput.setKeyboardMode(rcinput.kmNone)
 def VVhkO3(self, newChar, overwrite):
  if self["myInput"].allmarked:
   self["myInput"].deleteAllChars()
   self["myInput"].allmarked = False
  self["myInput"].insertChar(str(newChar), self["myInput"].currPos, overwrite, False)
  self["myInput"].update()
 def VVuiTo(self)     : self.VVwuuA(self["myInput"].left)
 def VVDhBf(self)     : self.VVwuuA(self["myInput"].right)
 def VVaFFN(self)     : self.VVwuuA(self["myInput"].delete)
 def VVbBtd(self)     : self.VVwuuA(self["myInput"].home)
 def VVBSim(self)     : self.VVwuuA(self["myInput"].end)
 def VVDhDd(self)    : self.VVwuuA(self["myInput"].deleteBackward)
 def VVx6QI(self)     : self.VVwuuA(self["myInput"].tab)
 def VVuPrj(self)     : self["myInput"].setText("")
 def VVwuuA(self, fnc):
  fnc()
  self.VVAu5z()
 def VVfWaJ(self, number) :
  overwrite = self["myInput"].lastKey == number
  newChar = self["myInput"].getKey(number)
  if newChar:
   self.VVhkO3(newChar, overwrite)
   self.VV7rxN(newChar, self["myInput"].mapping[number])
 def VVMxVj(self, isUp):
  try:
   char = self["myInput"].Text[self["myInput"].currPos]
  except:
   char = ""
  groups = CCvXkC.RCU_MAP_CHAR_SET[self.charMode]
  charStr = "".join(groups)
  if not char or not char in charStr:
   upChar, downChar = CCvXkC.RCU_MAP_CHAR_ENDS[self.charMode]
   if isUp : char = upChar
   else : char = downChar
  if char in charStr:
   ndx = charStr.find(char)
   if isUp:
    if ndx < len(charStr) - 1 : ndx = ndx + 1
    else      : ndx = 0
   else:
    if ndx > 0     : ndx = ndx - 1
    else      : ndx = len(charStr) - 1
   newChar = charStr[ndx]
   self.VVhkO3(newChar, True)
   for group in groups:
    if newChar in group:
     self.VV7rxN(newChar, group)
     break
 def VV7rxN(self, newChar, group):
  if newChar in group:
   h = self["myKeyMap"].instance.size().height()
   w = self.instance.size().width()
   self["myKeyMap"].instance.resize(eSize(*(w, h)))
   if VVjMps:
    group = VVQDXE + group.replace(newChar, FF2tuT(newChar, VVjMps, VVQDXE))
   else:
    group = group.replace(newChar, "[%s]" % newChar)
   self["myKeyMap"].setText(str(group))
   self["myKeyMap"].show()
   newW = self["myKeyMap"].instance.calculateSize().width()
   self["myKeyMap"].instance.resize(eSize(*(newW + 30, h)))
   self.timer.start(1000, False)
  else:
   self.timer.stop()
 def VV72Av(self):
  if self.VVOG4W : total = 5
  else    : total = 3
  self.charMode += 1
  if self.charMode > total:
   self.charMode = 0
  self.VVFpaf()
 def VVFpaf(self):
  self["myInput"].mapping = CCvXkC.RCU_MAP_LISTS[self.charMode]
  self["keyBlue"].setText(CCvXkC.RCU_MAP_TITLES[self.charMode])
class CCvXkC(Screen):
 VVN8D5  = 0
 VV3x4o  = 1
 VVj3c7  = 2
 VVyh3B  = 3
 VVhvED = 4
 VVxgxC = 5
 RCU_MAP_TITLES  = ("All Characters", "Digits", "Small Letters", "Capital Letters", "Arabic-1", "Arabic-2")
 RCU_MAP_SYMBOL0  = "0 .-_,'~;:\"^`!?=+*"
 RCU_MAP_SYMBOL1  = "1 #%&@$\\|/<>()[]{}"
 arabic0 = u"\u0660" + RCU_MAP_SYMBOL0[1:]
 arabic1 = u"\u0661" + RCU_MAP_SYMBOL1[1:]
 arabic1_2 = u"\u0662 \u0627 \u0628 \u062A \u062B"
 arabic1_3 = u"\u0663 \u062C \u062D \u062E"
 arabic1_4 = u"\u0664 \u062F \u0630 \u0631 \u0632"
 arabic1_5 = u"\u0665 \u0633 \u0634 \u0635 \u0636"
 arabic1_6 = u"\u0666 \u0637 \u0638 \u0639 \u063A"
 arabic1_7 = u"\u0667 \u0641 \u0642 \u0643"
 arabic1_8 = u"\u0668 \u0644 \u0645 \u0646"
 arabic1_9 = u"\u0669 \u0647 \u0629 \u0648 \u0649 \u064A"
 arabic2_2 = u"\u062B \u062A \u0628 \u0627 \u0662"
 arabic2_3 = u"\u062E \u062D \u062C \u0663"
 arabic2_4 = u"\u0632 \u0631 \u0630 \u062F \u0664"
 arabic2_5 = u"\u0636 \u0635 \u0634 \u0633 \u0665"
 arabic2_6 = u"\u063A \u0639 \u0638 \u0637 \u0666"
 arabic2_7 = u"\u0643 \u0642 \u0641 \u0667"
 arabic2_8 = u"\u0646 \u0645 \u0644 \u0668"
 arabic2_9 = u"\u064A  \u0649 \u0648 \u0629 \u0647 \u0669"
 RCU_MAP_LISTS = ( ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abcABC" , "3defDEF" , "4ghiGHI" , "5jklJKL" , "6mnoMNO" , "7pqrsPQRS", "8tuvTUV", "9wxyzWXYZ" )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2"  , "3"  , "4"  , "5"  , "6"  , "7"   , "8"  , "9"   )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2abc" , "3def" , "4ghi" , "5jkl" , "6mno" , "7pqrs"  , "8tuv" , "9wxyz"  )
     , ( RCU_MAP_SYMBOL0 , RCU_MAP_SYMBOL1 , "2ABC" , "3DEF" , "4GHI" , "5JKL" , "6MNO" , "7PQRS"  , "8TUV" , "9WXYZ"  )
     , ( arabic0    , arabic1    , arabic1_2 , arabic1_3 , arabic1_4 , arabic1_5 , arabic1_6 , arabic1_7  , arabic1_8, arabic1_9  )
     , ( arabic0    , arabic1    , arabic2_2 , arabic2_3 , arabic2_4 , arabic2_5 , arabic2_6 , arabic2_7  , arabic2_8, arabic2_9  )
     )
 nums    = "0123456789"
 small    = "abcdefghijklmnopqrstuvwxyz"
 caps    = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 arabic_nums1  = u"\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
 arabic_nums2  = u"\u0669\u0668\u0667\u0666\u0665\u0664\u0663\u0662\u0661\u0660"
 arabic1    = u"\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0629\u0648\u0649\u064A"
 arabic2    = u"\u062B\u062A\u0628\u0627\u062E\u062D\u062C\u0632\u0631\u0630\u062F\u0636\u0635\u0634\u0633\u063A\u0639\u0638\u0637\u0643\u0642\u0641\u0646\u0645\u0644\u064A\u0649\u0648\u0629\u0647"
 symbols    = RCU_MAP_SYMBOL0.replace("0 ", "") + RCU_MAP_SYMBOL1.replace("1 ", "")
 RCU_MAP_CHAR_SET = ( ( symbols, nums, small, caps )
       , ( nums , )
       , ( small , )
       , ( caps , )
       , ( symbols , arabic_nums1, arabic1)
       , ( symbols , arabic_nums2, arabic2)
       )
 RCU_MAP_CHAR_ENDS = ( ("9"  , "b")
       , ("9"  , "0")
       , ("z"  , "b")
       , ("Z"  , "B")
       , (u"\u064A", u"\u0628")
       , (u"\u0647", u"\u062A")
       )
 def __init__(self, session, mode=VVN8D5, VVOG4W=False):
  self.skin, self.skinParam = FFbmPq(VVCObr, 1200, 500, 50, 20, 20, "#11663366", "#11444444", 25, barHeight=40)
  self.session  = session
  self.Title   = "Key Mapping"
  self.mode   = mode
  self.VVOG4W  = VVOG4W
  names = ["1", "2", "3", "4", "5", "6", "7" , "8", "9", "L", "0", "R"] #
  for item in names:
   if   item == "L": itemMarker, txt = "<"  , "Del. <"
   elif item == "R": itemMarker, txt = ">"  , "Del. >"
   else   : itemMarker, txt = item , item
   self["myRcu%s"  % item] = Label(txt)
   self["myRcuF%s" % item] = Label(itemMarker)
  FF9Cql(self, title=self.Title)
  FFCpCt(self["keyRed"] ,"OK = Select")
  FFCpCt(self["keyGreen"], "<> = Change")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVZ8Hf     ,
   "cancel" : self.cancel      ,
   "last"  : boundFunction(self.VV2SKj, -1) ,
   "next"  : boundFunction(self.VV2SKj, +1) ,
   "left"  : boundFunction(self.VV2SKj, -1) ,
   "right"  : boundFunction(self.VV2SKj, +1) ,
  }, -1)
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FF3luO(self["keyRed"], "#11222222")
  FF3luO(self["keyGreen"], "#11222222")
  self.VVju4t()
 def VVju4t(self):
  self.VVlFB1()
  keyMapList = self.RCU_MAP_LISTS[self.mode]
  for i in range(10):
   name = "myRcu%d" % i
   self[name].setText(keyMapList[i].encode("utf-8", "ignore"))
 def VVlFB1(self):
  self["myTitle"].setText("  %s (%s)" % (self.Title, self.RCU_MAP_TITLES[self.mode]))
 def VV2SKj(self, direction):
  if self.VVOG4W : total = 5
  else    : total = 3
  mode = self.mode + direction
  if   mode > total : self.mode = 0
  elif mode < 0  : self.mode = total
  else    : self.mode = mode
  self.VVju4t()
 def VVZ8Hf(self):
  self.close(self.mode)
 def cancel(self):
  self.close(None)
class CCSeKr(Screen):
 def __init__(self, session, title="", message="", VVFuWe=VVdoHn, VV1OEk=False, VV5tqg=None, VVwZKv=30, canSaveToFile=""):
  self.skin, self.skinParam = FFbmPq(VVukgN, 1400, 800, 50, 30, 20, "#22002020", "#22001122", VVwZKv)
  self.session   = session
  FF9Cql(self, title, addScrollLabel=True)
  self.VVFuWe   = VVFuWe
  self.VV1OEk   = VV1OEk
  self.VV5tqg   = VV5tqg
  self.canSaveToFile  = canSaveToFile
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    self.message = str(message)
  else:
   self.message = str(message)
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  self["myLabel"].VVmT9l(VV1OEk=self.VV1OEk, textOutFile=self.canSaveToFile)
  self["myLabel"].setText(self.message, self.VVFuWe)
  if self.VV5tqg:
   FF3luO(self["myBody"], self.VV5tqg)
   FF3luO(self["myLabel"], self.VV5tqg)
   FFHpgH(self["myLabel"], self.VV5tqg)
  self["myLabel"].VV1ZXK()
class CCbAFE(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFbmPq(VVUtFT, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FF9Cql(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FFDeL6(self["errPic"], "err")
class CCWGcJ(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FFbmPq(VVMKe8, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", 20)
  self.session  = session
  self["myWinTitle"] = Label(txt)
  FF9Cql(self, " ", addCloser=True)
class CCc7Er():
 def __init__(self, session, txt):
  self.win = session.instantiateDialog(CCWGcJ, txt)
  self.win.instance.move(ePoint(30, 20))
  self.win.show()
  self.session = session
  self.timer  = eTimer()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVk4Vk)
  except:
   self.timer.callback.append(self.VVk4Vk)
  self.timer.start(1500, True)
 def VVk4Vk(self):
  self.session.deleteDialog(self.win)
class CCiRRm():
 VVD3sY    = 0
 VVarG4  = 1
 VVpLRc   = ""
 VVtVTX    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVByVq   = None
  self.timer     = eTimer()
  self.VVbno9   = 0
  self.VVQZ1W  = 1
  self.VV1Py3  = 2
  self.VVP3Fe   = 3
  self.VVGOrg   = 4
  VVhCPI = self.VVCxk6()
  if VVhCPI:
   self.VVByVq = self.VVlsw3(VVhCPI)
  if not VVhCPI and mode == self.VVD3sY:
   self.VVqJ5yor("Download list is empty !")
   self.cancel()
  if mode == self.VVarG4:
   FFobhC(self.VVByVq or self.SELF, boundFunction(self.VVkbHx, startDnld, decodedUrl), title="Checking Server ...")
  self.VVPmwu(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVPmwu)
  except:
   self.timer.callback.append(self.VVPmwu)
  self.timer.start(1000, False)
 def VVlsw3(self, VVhCPI):
  VVhCPI.sort(key=lambda x: int(x[0]))
  VVFhJO = self.VVBxjD
  VV69tn  = ("Play"  , self.VVDai2 , [])
  VVTRSb = (""   , self.VVw4pL  , [])
  VV5uBQ = ("Stop"  , self.VVWPah  , [])
  VVw8s5 = ("Resume"  , self.VVkGek , [])
  VV3Y5Z = ("Options" , self.VVydo0  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VV32KX  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFN0i6(self.SELF, None, title=self.Title, header=header, VV1rg6=VVhCPI, VV32KX=VV32KX, VVDe98=widths, VVwZKv=26, VV69tn=VV69tn, VVTRSb=VVTRSb, VVFhJO=VVFhJO, VV5uBQ=VV5uBQ, VVw8s5=VVw8s5, VV3Y5Z=VV3Y5Z, VVuutY="#11110011", VVZ7ot="#11220022", VV5tqg="#11110011", VVLZXK="#00ffff00", VVwtgu="#00223025", VVorfQ="#0a333333", VV1sri="#0a400040", VVB9Wc=True, searchCol=1)
 def VVCxk6(self):
  lines = CCiRRm.VVtCvo()
  VVhCPI = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",")
     left  = parts[0].strip()
     decodedUrl = ",".join(parts[1:]).strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVQ4mZ(decodedUrl)
      if fName:
       if   FFbpLk(decodedUrl) : sType = "Movie"
       elif FFRfoo(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVYEsZ(decodedUrl, fName)
       if size > -1: sizeTxt = CCsPG3.VVekPE(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVhCPI.append((str(len(VVhCPI) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVhCPI
 def VVJ1gU(self):
  VVhCPI = self.VVCxk6()
  if VVhCPI:
   if self.VVByVq : self.VVByVq.VVzmZc(VVhCPI, VVJJvTMsg=False)
   else     : self.VVByVq = self.VVlsw3(VVhCPI)
  else:
   self.cancel()
 def VVPmwu(self, force=False):
  if self.VVByVq:
   thrList = self.VVk5XC()
   VVhCPI = []
   changed = False
   for ndx, row in enumerate(self.VVByVq.VVfKVc()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVbno9
    if m3u8Log:
     percent = self.VVKujc(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVP3Fe , "%.2f %%" % percent
      else   : flag, progr = self.VVGOrg , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFuS3Z(mPath)
     if curSize > -1:
      fSize = CCsPG3.VVekPE(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCsPG3.VVekPE(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFuS3Z(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVP3Fe , "%.2f %%" % percent
       else   : flag, progr = self.VVGOrg , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCsPG3.VVekPE(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrList:
     flag = self.VV1Py3
     if m3u8Log :
      if not speed and not force : flag = self.VVQZ1W
      elif curSize == -1   : self.VVoePZ(False)
    elif flag == self.VVbno9  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVbno9  : color2 = "#f#00555555#"
    elif flag == self.VVQZ1W : color2 = "#f#0000FFFF#"
    elif flag == self.VV1Py3 : color2 = "#f#0000FFFF#"
    elif flag == self.VVP3Fe  : color2 = "#f#00FF8000#"
    elif flag == self.VVGOrg  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VV3orO(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVhCPI.append(row)
   if changed or force:
    self.VVByVq.VVzmZc(VVhCPI, VVJJvTMsg=False)
 def VV3orO(self, flag):
  tDict = self.VVtIqC()
  return tDict.get(flag, "?")
 def VVpMYA(self, state):
  for flag, txt in self.VVtIqC().items():
   if txt == state:
    return flag
  return -1
 def VVtIqC(self):
  return { self.VVbno9: "Not started", self.VVQZ1W: "Connecting", self.VV1Py3: "Downloading", self.VVP3Fe: "Stopped", self.VVGOrg: "Completed" }
 def VV16VF(self, title):
  colList = self.VVByVq.VVBNVx()
  path = colList[6]
  url  = colList[8]
  if self.VVc0U6() : self.VVqJ5yor("Cannot delete !\n\nFile is downloading.")
  else      : FFJWhD(self.SELF, boundFunction(self.VV6qi4, path, url), "Delete ?\n\n%s" % path, title=title)
 def VV6qi4(self, path, url):
  m3u8Log = self.VVByVq.VVBNVx()[12].strip()
  if m3u8Log : os.system(FFps7R("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  else  : os.system(FFps7R("rm -r '%s'" % path))
  self.VVIarw(False)
  self.VVJ1gU()
 def VVIarw(self, VVqJ5y=True):
  if self.VVc0U6():
   FFtMdo(self.VVByVq, self.VV3orO(self.VV1Py3), 500)
  else:
   colList  = self.VVByVq.VVBNVx()
   state  = colList[4].strip()
   decodedUrl = colList[9].strip()
   if self.VVpMYA(state) in (self.VVbno9, self.VVGOrg, self.VVP3Fe):
    lines = CCiRRm.VVtCvo()
    newLines = []
    found = False
    for line in lines:
     if CCiRRm.VVq1Qe(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVaZKf(newLines)
     self.VVJ1gU()
     FFtMdo(self.VVByVq, "Removed.", 1000)
    else:
     FFtMdo(self.VVByVq, "Not found.", 1000)
   elif VVqJ5y:
    self.VVqJ5yor("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVHtwT(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFJWhD(self.SELF, boundFunction(self.VVcB0X, flag), ques, title=title)
 def VVcB0X(self, flag):
  list = []
  for ndx, row in enumerate(self.VVByVq.VVfKVc()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVpMYA(state)
   if   flag == flagVal == self.VVGOrg: list.append(decodedUrl)
   elif flag == flagVal == self.VVbno9 : list.append(decodedUrl)
  lines = CCiRRm.VVtCvo()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVaZKf(newLines)
   self.VVJ1gU()
   FFtMdo(self.VVByVq, "%d removed." % totRem, 1000)
  else:
   FFtMdo(self.VVByVq, "Not found.", 1000)
 def VVqJwB(self):
  colList  = self.VVByVq.VVBNVx()
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFtMdo(self.VVByVq, "Poster exists", 1500)
  else    : FFobhC(self.VVByVq, boundFunction(self.VVvaBn, decodedUrl, path, png), title="Checking Server ...")
 def VVvaBn(self, decodedUrl, path, png):
  err = self.VV33RI(decodedUrl, path, png)
  if err:
   FFBAp7(self.SELF, err, title="Poster Download")
 def VV33RI(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCKdjH.VVmCee(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCmV60.VVxXhs(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCmV60.VVI40b(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCmV60.VVVFIA(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFSgzY(pUrl, "ajpanel_tmp%s", timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   os.system(FFps7R("mv -f '%s' '%s'" % (tPath, png)))
   CCv4E7.VV2MIq(self.SELF, VVYQGM=png, showGrnMsg="Downloaded")
   return ""
 def VVw4pL(self, VVByVq, title, txt, colList):
  def VVu5M6(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VV1j34(key, val) : return "\n%s:\n%s\n" % (FF2tuT(key, COLOR_CONS_BRIGHT_YELLOW), val.strip())
  heads  = self.VVByVq.VVFX2i()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVu5M6(heads[i]  , CCsPG3.VVekPE(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVu5M6("Downloaded" , CCsPG3.VVekPE(int(curSize), mode=0))
   else:
    txt += VVu5M6(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VV1j34(heads[i], colList[i])
  FFzRpw(self.SELF, txt, title=title)
 def VVDai2(self, VVByVq, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCsPG3.VVw2yu(self.SELF, path)
  else    : FFtMdo(self.VVByVq, "File not found", 1000)
 def VVBxjD(self, VVByVq):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVByVq:
   self.VVByVq.cancel()
  del self
 def VVydo0(self, VVByVq, title, txt, colList):
  decodedUrl = colList[9].strip()
  if CFG.downloadAutoResume.getValue(): resumeTxt = "Disable"
  else        : resumeTxt = "Enable"
  VVJ4VL = []
  VVJ4VL.append(("Remove current row"      , "VVIarw"  ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(('Remove all "Completed"'     , "remFinished"    ))
  VVJ4VL.append(('Remove all "Not started"'     , "remPending"    ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Delete the file (and remove from list)" , "VV16VF" ))
  if FFbpLk(decodedUrl):
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append(("Download Movie Poster (from server)" , "VVqJwB"   ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append((resumeTxt + " Auto Resume"     , "VVSOEP"  ))
  FFdrYz(self.SELF, self.VVKmlV, VVJ4VL=VVJ4VL, title=self.Title, VVYMy8=True, VVEfaQ=True)
 def VVKmlV(self, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVIarw"  : self.VVIarw()
   elif ref == "remFinished"   : self.VVHtwT(self.VVGOrg, txt)
   elif ref == "remPending"   : self.VVHtwT(self.VVbno9, txt)
   elif ref == "VV16VF" : self.VV16VF(txt)
   elif ref == "VVqJwB"  : self.VVqJwB()
   elif ref == "VVSOEP"  : self.VVSOEP()
 def VVkbHx(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCKdjH.VVmCee(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVqJ5yor("Could not get download link !\n\nTry again later.")
     return
  for line in CCiRRm.VVtCvo():
   if CCiRRm.VVq1Qe(decodedUrl, line):
    self.VVX6in(decodedUrl)
    FFOFIS(boundFunction(FFtMdo, self.VVByVq, "Already listed !", 2000))
    break
  else:
   params = self.VVQgIZ(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVqJ5yor(params[0])
   elif len(params) == 2:
    FFJWhD(self.SELF, boundFunction(self.VVb2dP, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCsPG3.VVekPE(fSize)
    FFJWhD(self.SELF, boundFunction(self.VVKuRc, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVKuRc(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCiRRm.VVH90C(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVJ1gU()
  if self.VVByVq:
   self.VVByVq.VVqO3b()
  if startDnld:
   threadName = self.VVtVTX + decodedUrl
   self.VVWm9m(threadName, url, decodedUrl, path, resp)
 def VVX6in(self, decodedUrl):
  for ndx, row in enumerate(self.VVByVq.VVfKVc()):
   decodedUrl2 = row[9].strip()
   if decodedUrl == decodedUrl2 and self.VVByVq:
    self.VVByVq.VVSgIu(ndx)
    break
 def VVQgIZ(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVQ4mZ(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVYEsZ(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCKdjH.VVmCee(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCKdjH.VVT7g6Header()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCiRRm.VVXwF1(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCiRRm.VVzGbm(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVb2dP(self, resp, decodedUrl):
  if not os.system(FFps7R("which ffmpeg")) == 0:
   FFJWhD(self.SELF, boundFunction(CCmV60.VVUevi, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVQ4mZ(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VV3rmJ(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFJWhD(self.SELF, boundFunction(self.VVounF, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVounF(rTxt, rUrl)
  else:
   self.VVqJ5yor("Cannot process m3u8 file !")
 def VV3rmJ(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVJ4VL = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCmV60.VVkK3C(rUrl, fPath)
   VVJ4VL.append((resol, fullUrl))
  if VVJ4VL:
   FFdrYz(self.SELF, self.VV9yG3, VVJ4VL=VVJ4VL, title="Resolution", VVYMy8=True, VVEfaQ=True)
  else:
   self.VVqJ5yor("Cannot get Resolutions list from server !")
 def VV9yG3(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFJWhD(self.SELF, boundFunction(FFOFIS, boundFunction(self.VVzXHK, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFOFIS(boundFunction(self.VVzXHK, resolUrl))
 def VVzXHK(self, resolUrl):
  txt, err = CCKdjH.VVT0zt(resolUrl)
  if err : self.VVqJ5yor(err)
  else : self.VVounF(txt, resolUrl)
 def VVVHK4(self, logF, decodedUrl):
  found = False
  lines = CCiRRm.VVtCvo()
  with open(CCiRRm.VVH90C(), "w") as f:
   for line in lines:
    if CCiRRm.VVq1Qe(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCiRRm.VVH90C(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVJ1gU()
  if self.VVByVq:
   self.VVByVq.VVqO3b()
 def VVounF(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCmV60.VVkK3C(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVqJ5yor("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVVHK4(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFps7R("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = self.VVtVTX + decodedUrl
  myThread = iThread(name=threadName, target=boundFunction(os.system, cmd))
  myThread.start()
 def VVKujc(self, dnldLog):
  if fileExists(dnldLog):
   dur = self.VVX7FS(dnldLog)
   if dur > -1:
    tim = self.VVBNGB(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 def VVX7FS(self, dnldLog):
  lines = FF5Oes("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVBNGB(self, dnldLog):
  lines = FF5Oes("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVYEsZ(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFRfoo(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    os.system(FFps7R("mkdir '%s'" % path1))
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVWm9m(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVByVq.VVBNVx()[7].strip())
  myThread = iThread(name=threadName, target=boundFunction(self.VVOcWS, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVOcWS(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if CCiRRm.VVpLRc == path:
       break
     else:
      break
  except:
   return
  if CCiRRm.VVpLRc:
   CCiRRm.VVpLRc = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFuS3Z(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVQgIZ(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVOcWS(url, decodedUrl, path, resp, totFileSize, True)
 def VVWPah(self, VVByVq, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVdjDk() : FFtMdo(self.VVByVq, self.VV3orO(self.VVGOrg), 500)
  elif not self.VVc0U6() : FFtMdo(self.VVByVq, self.VV3orO(self.VVP3Fe), 500)
  elif m3u8Log      : FFJWhD(self.SELF, self.VVoePZ, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVk5XC():
    CCiRRm.VVpLRc = colList[6]
    FFtMdo(self.VVByVq, "Stopping ...", 1000)
   else:
    FFtMdo(self.VVByVq, "Stopped", 500)
 def VVoePZ(self, withMsg=True):
  if withMsg:
   FFtMdo(self.VVByVq, "Stopping ...", 1000)
  os.system(FFps7R("killall -INT ffmpeg"))
 def VVSOEP(self):
  CFG.downloadAutoResume.setValue(not CFG.downloadAutoResume.getValue())
  CFG.downloadAutoResume.save()
  configfile.save()
 def VVkGek(self, *args):
  if   self.VVdjDk() : FFtMdo(self.VVByVq, self.VV3orO(self.VVGOrg) , 500)
  elif self.VVc0U6() : FFtMdo(self.VVByVq, self.VV3orO(self.VV1Py3), 500)
  else:
   resume = False
   m3u8Log = self.VVByVq.VVBNVx()[12].strip()
   if m3u8Log:
    if fileExists(m3u8Log) : FFJWhD(self.SELF, boundFunction(self.VVuZ7m, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VV1ivv():
    resume = True
   if resume: FFobhC(self.VVByVq, boundFunction(self.VVnGvx), title="Checking Server ...")
   else  : FFtMdo(self.VVByVq, "Cannot resume !", 500)
 def VVuZ7m(self, m3u8Log):
  os.system(FFps7R("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9])))
  FFobhC(self.VVByVq, boundFunction(self.VVnGvx), title="Checking Server ...")
 def VVnGvx(self):
  colList  = self.VVByVq.VVBNVx()
  path  = colList[6].strip()
  size  = colList[7].strip()
  decodedUrl = colList[9].strip()
  if "j.php" in decodedUrl:
   url = CCKdjH.VVmCee(decodedUrl)
   if url:
    decodedUrl = self.VVQYEI(decodedUrl, url)
   else:
    self.VVqJ5yor("Could not get download link !\n\nTry again later.")
    return
  curSize = FFuS3Z(path)
  params = self.VVQgIZ(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVqJ5yor(params[0])
   return
  elif len(params) == 2:
   self.VVb2dP(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVQYEI(decodedUrl, url, fSize)
  threadName = self.VVtVTX + decodedUrl
  if resumable: self.VVWm9m(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVqJ5yor("Cannot resume from server !")
 def VVQ4mZ(self, decodedUrl):
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(http:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   x = decodedUrl.find("&mode")
   if x > -1: url = decodedUrl[:x]
   fName = ".mp4"
   x = decodedUrl.find("&end=")
   if x > -1: chName = decodedUrl[x+5:]
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + ".mp4"
     fixName = False
     ok  = True
   if not ok and FFvbGL(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + ".mp4"
     fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    fName =  mix.split(":")[0]
    chName = ":".join(mix.split(":")[1:])
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVqJ5yor(self, txt):
  FFBAp7(self.SELF, txt, title=self.Title)
 def VVk5XC(self):
  thrList = []
  for thr in iEnumerate():
   if self.VVtVTX in thr.name:
    thrList.append(thr.name.replace(self.VVtVTX, ""))
  return thrList
 def VVc0U6(self):
  decodedUrl = self.VVByVq.VVBNVx()[9].strip()
  return decodedUrl in self.VVk5XC()
 def VVdjDk(self):
  colList = self.VVByVq.VVBNVx()
  path = colList[6].strip()
  size = colList[7].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFuS3Z(path)) == size
 def VV1ivv(self):
  colList = self.VVByVq.VVBNVx()
  path = colList[6].strip()
  size = int(colList[7].strip())
  curSize = FFuS3Z(path)
  if curSize > -1:
   size -= curSize
  err = CCiRRm.VVzGbm(size)
  if err:
   FFBAp7(self.SELF, err, title=self.Title)
   return False
  return True
 def VVaZKf(self, list):
  with open(CCiRRm.VVH90C(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVQYEI(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCiRRm.VVtCvo()
  url = decodedUrl
  with open(CCiRRm.VVH90C(), "w") as f:
   for line in lines:
    if CCiRRm.VVq1Qe(decodedUrl, line):
     parts = line.split(",")
     oldUrl = ",".join(parts[1:]).strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVJ1gU()
  return url
 @staticmethod
 def VVtCvo():
  list = []
  if fileExists(CCiRRm.VVH90C()):
   for line in FFHvYZ(CCiRRm.VVH90C()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVq1Qe(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVzGbm(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCsPG3.VVWrl8(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCsPG3.VVekPE(size), CCsPG3.VVekPE(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VV42c0(SELF):
  tot = CCiRRm.VV1s8M()
  if tot:
   FFBAp7(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VV1s8M():
  c = 0
  for thread in iEnumerate():
   if thread.name.startswith(CCiRRm.VVtVTX):
    c += 1
  return c
 @staticmethod
 def VVA8Ez():
  return len(CCiRRm.VVtCvo()) == 0
 @staticmethod
 def VVaKA1():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VV8UgT():
  mPoints = CCiRRm.VVaKA1()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    os.system(FFps7R("mkdir '%s'" % path))
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVH90C():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVqHgJ(SELF):
  CCiRRm.VV8Ro6(SELF, CCiRRm.VVD3sY)
 @staticmethod
 def VVv8gy_cur(SELF):
  CCiRRm.VV8Ro6(SELF, CCiRRm.VVarG4, startDnld=True)
 @staticmethod
 def VVv8gy_url(SELF, url):
  CCiRRm.VV8Ro6(SELF, CCiRRm.VVarG4, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVgkFlCurrent(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(SELF)
  added, skipped = CCiRRm.VVgkFlList([decodedUrl])
  FFtMdo(SELF, "Added", 1000)
 @staticmethod
 def VVgkFlList(list):
  added = skipped = 0
  for line in CCiRRm.VVtCvo():
   for ndx, url in enumerate(list):
    if url and CCiRRm.VVq1Qe(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCiRRm.VVH90C(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VV8Ro6(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CC7z2E.VVrOnV(SELF):
   return
  if mode == CCiRRm.VVD3sY and CCiRRm.VVA8Ez():
   FFBAp7(SELF, "Download list is empty !", title=title)
  else:
   inst = CCiRRm(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVXwF1(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CC7tge(Screen, CCRIa4):
 VVdfBW = None
 def __init__(self, session, enableZapping=True, portalTableParam=None, isFromExternal=False, enableDownloadMenu=True):
  self.skin, self.skinParam = FFbmPq(VVXlNP, 1500, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCRIa4.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.portalTableParam  = portalTableParam
  self.isFromExternal   = isFromExternal
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.lastPlayPos   = 0
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  self.SubtWin    = None
  FF9Cql(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVBATd())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<<  ||  >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label("Cut-List")
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVFd70         ,
   "info"  : self.VVPFTE        ,
   "epg"  : self.VVPFTE        ,
   "menu"  : self.VVXDMl       ,
   "cancel" : self.cancel         ,
   "blue"  : self.VVMd0R        ,
   "green"  : self.VVvLlj    ,
   "yellow" : self.VVqf2f   ,
   "left"  : boundFunction(self.VVl2Om, -1)   ,
   "right"  : boundFunction(self.VVl2Om,  1)   ,
   "play"  : self.VVYU7F        ,
   "pause"  : self.VVYU7F        ,
   "playPause" : self.VVYU7F        ,
   "stop"  : self.VVYU7F        ,
   "rewind" : self.VVqRCn        ,
   "forward" : self.VV1uq3        ,
   "rewindDm" : self.VVqRCn        ,
   "forwardDm" : self.VV1uq3        ,
   "last"  : self.VVFtY3        ,
   "next"  : self.VVvtNR        ,
   "pageUp" : boundFunction(self.VVu6TJ, True) ,
   "pageDown" : boundFunction(self.VVu6TJ, False) ,
   "chanUp" : boundFunction(self.VVu6TJ, True) ,
   "chanDown" : boundFunction(self.VVu6TJ, False) ,
   "up"  : boundFunction(self.VVu6TJ, True) ,
   "down"  : boundFunction(self.VVu6TJ, False) ,
   "audio"  : boundFunction(self.VVF8Qo, True) ,
   "subtitle" : boundFunction(self.VVF8Qo, False) ,
   "0"   : boundFunction(self.VVAGSq , 10)  ,
   "1"   : boundFunction(self.VVAGSq , 1)  ,
   "2"   : boundFunction(self.VVAGSq , 2)  ,
   "3"   : boundFunction(self.VVAGSq , 3)  ,
   "4"   : boundFunction(self.VVAGSq , 4)  ,
   "5"   : boundFunction(self.VVAGSq , 5)  ,
   "6"   : boundFunction(self.VVAGSq , 6)  ,
   "7"   : boundFunction(self.VVAGSq , 7)  ,
   "8"   : boundFunction(self.VVAGSq , 8)  ,
   "9"   : boundFunction(self.VVAGSq , 9)
  }, -1)
  self.onShown.append(self.VVJGeB)
  self.onClose.append(self.onExit)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FFGuuf(self)
  if not CC7tge.VVdfBW:
   CC7tge.VVdfBW = self
  else:
   self.close()
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFDeL6(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFDeL6(self["myPlayRpt"], "rpt")
  self.VVqcQw()
  self.instance.move(ePoint(40, 40))
  self.VVxFpK(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  self["myPlayBlu"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVCGm5)
  except:
   self.timer.callback.append(self.VVCGm5)
  self.timer.start(250, False)
  self.VVCGm5("Checking ...")
  self.VVDTzr()
 def VVvLlj(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self)
  if "chCode" in iptvRef:
   if CC7z2E.VVrOnV(self):
    self.VVDTzr(True)
 def VVqcQw(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self)
  self.Title = chName
  self["myTitle"].setText("  " + self.Title + "  ")
  if "chCode" in origUrl:
   if "get_download_link" in origUrl: color = "#1120101a"
   else        : color = "#1120002a"
   self["myPlayGrn"].show()
  else:
   color = "#1100202a"
   self["myPlayGrn"].hide()
  FF3luO(self["myTitle"], color)
 def VVXDMl(self):
  if self.SubtWin:
   self.SubtWin.VVeIFv()
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self)
  VVJ4VL = []
  if self.isFromExternal:
   VVJ4VL.append(("IPTV Menu"     , "iptv"  ))
   VVJ4VL.append(VV1dpw)
  if FFsGsn(iptvRef) and not "&end=" in decodedUrl and not FFvbGL(decodedUrl):
   uType, uHost, uUser, uPass, uId, uChName = CCmV60.VVxXhs(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVJ4VL.append(("Catchup Programs"   , "catchup"  ))
    VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Stop Current Service"    , "stop"  ))
  VVJ4VL.append(("Restart Current Service"   , "restart"  ))
  VVJ4VL.append(VV1dpw)
  FFbpLkSeries = FFvbGL(decodedUrl)
  if FFbpLkSeries:
   VVJ4VL.append(("File Size"     , "fileSize" ))
   VVJ4VL.append(VV1dpw)
  if self.enableDownloadMenu:
   addSep = False
   if FFsGsn(iptvRef) and FFbpLkSeries:
    VVJ4VL.append(("Start Download"   , "dload_cur" ))
    VVJ4VL.append(("Add to Download List"  , "addToDload" ))
    addSep = True
   if not CCiRRm.VVA8Ez():
    VVJ4VL.append(("Download Manager"   , "dload_stat" ))
    addSep = True
   if addSep:
    VVJ4VL.append(VV1dpw)
  fPath, fDir, fName = CCsPG3.VVKA14(self)
  if fPath:
   if not CCsPG3.VVwvyM:
    VVJ4VL.append((VVWvE3 + "Open path in File Manager", "VVDTyj" ))
   VVJ4VL.append((VVWvE3 + 'Add to "My Movies" Bouquet' , "VVC1GA" ))
   VVJ4VL.append(("%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VV3THy" ))
   VVJ4VL.append(VV1dpw)
  enabl = False
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC7tge.VVuQi4(self)
  if posVal and durVal:
   enabl = True
  else:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCipRP.VVX9la(self)
   enabl = evName and evTime and evDur
  if enabl:
   VVJ4VL.append((VVWvE3 + "Start Subtitle"    , "VVdobw"  ))
   VVJ4VL.append(VV1dpw)
  if CFG.playerPos.getValue() : VVJ4VL.append(("Move Bar to Bottom"  , "botm"  ))
  else      : VVJ4VL.append(("Move Bar to Top"  , "top"   ))
  VVJ4VL.append(("Help"             , "help"  ))
  FFdrYz(self, self.VVAl7x, VVJ4VL=VVJ4VL, width=550, title="Options")
 def VVAl7x(self, item=None):
  if item:
   if item == "iptv"     : self.VVRAPA()
   elif item == "catchup"    : self.VVqf2f()
   elif item == "stop"     : self.VVJ0GP(0)
   elif item == "restart"    : self.VVJ0GP(1)
   elif item == "fileSize"    : FFobhC(self, boundFunction(CCipRP.VV0oX9, self), title="Checking Server")
   elif item == "dload_cur"   : CCiRRm.VVv8gy_cur(self)
   elif item == "addToDload"   : CCiRRm.VVgkFlCurrent(self)
   elif item == "dload_stat"   : CCiRRm.VVqHgJ(self)
   elif item == "VVDTyj" : self.VVDTyj()
   elif item == "VVC1GA" : FFobhC(self, self.VVC1GA)
   elif item == "VVdobw"  : self.VVdobw(CCjkQS.VVxDaO)
   elif item == "VV3THy"  : self.VV3THy()
   elif item == "botm"     : self.VVxFpK(0)
   elif item == "top"     : self.VVxFpK(1)
   elif item == "help"     : FFf485(self, VVqrRB + "_help_player", "Player Controller (Keys)")
 def onExit(self):
  self.timer.stop()
  CC7tge.VVdfBW = None
  self.VVaFMF()
 def VViP3t(self):
  if CC7tge.VVdfBW:
   self.session.open(CC7tge, enableZapping= False, enableDownloadMenu=False)
  self.close()
 def VVDTyj(self):
  self.session.open(CCsPG3, gotoMovie=True)
  self.VViP3t()
 def VVRAPA(self):
  self.session.open(CCmV60)
  self.VViP3t()
 def VVJ0GP(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.close()
   elif typ == 1:
    self.VVCGm5("Restarting Service ...")
    FFOFIS(boundFunction(self.VVh4th, serv))
 def VVh4th(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self)
  if "&end=" in decodedUrl: boundFunction(self.VVDTzr, True)
  else     : self.session.nav.playService(serv)
 def VVC1GA(self):
  title = "Add Movie to Bouquet"
  bName = "My Movies"
  path  = VVYYh9 + "userbouquet.my_local_movies.tv"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self)
  fPath, fDir, fName = CCsPG3.VVKA14(self)
  if not fPath or not chName:
   FFBAp7(self, "Cannot read Path or Channel Name", title=title)
   return
  isNew = False
  if not fileExists(path):
   isNew = True
   with open(path, "w") as f:
    f.write("#NAME %s\n" % bName)
  catID, stID, chNum = "1638", "6", "6"
  refCode = CCmV60.VVqrfU(catID, stID, chNum)
  if not isNew:
   fTxt = FFWaDF(path)
   chUrl_noRef = "%s:%s" % (fPath, chName)
   if chUrl_noRef in fTxt:
    FFBAp7(self, "Already added to bouquet:\n\n%s" % bName, title=title)
    return
   for ns in range(1, 65535 - 1):
    catID, stID, chNum = "1638", str(ns), "6"
    refCode = CCmV60.VVqrfU(catID, stID, chNum)
    if not refCode in fTxt:
     break
   else:
    FFBAp7(self, "Cannot create a unique Reference Code", title=title)
    return
  if refCode and fPath and chName:
   chUrl = "%s%s:%s" % (refCode, fPath, chName)
   with open(path, "a") as f:
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
   piconOk = self.VVED7R(refCode)
   FFv9Xh(os.path.basename(path))
   FFWjYU()
   FFSzHX(self, "Added to bouquet:\n\n%s" % bName, title=title + (" (with PIcon)" if piconOk else ""))
  else:
   FFBAp7(self, "Cannot create a unique Reference Code", title=title)
   return
 def VV3THy(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC7tge.VVuQi4(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVCGm5(txt, highlight=ok)
 def VVdobw(self, mode, useSubtFile=""):
  self.hide()
  self.SubtWin = self.session.instantiateDialog(CCjkQS, mode=mode, endCallback=self.VVPsLu)
  self.SubtWin.show()
  self.SubtWin.VVvKIN(useSubtFile)
 def VVPsLu(self, err):
  if err:
   if err == "noResume": self.VVaFMF(False)
   else    : self.VVaFMF(True)
   if   err == "noResume" : return
   if   err == "noErr"  : return
   elif err == "noAutoSrt" : CCjkQS.VVuQgB(self, self.VVVKRw)
   else      : FFtMdo(self, err, 2000)
 def VVVKRw(self, path):
  if path:
   self.VVdobw(CCjkQS.VVxDaO, useSubtFile=path)
 def VVED7R(self, refCode):
  fPath, fDir, fName, picFile = CCipRP.VVd5Qs(self)
  pPath = CCYaR2.VVQI8K()
  if fileExists(pPath) and pathExists(picFile):
   pFile = refCode.replace(":", "_").strip("_") + ".png"
   dest = os.path.join(pPath, pFile)
   os.system(FFps7R("cp -f '%s' '%s'" % (picFile, dest)))
   os.system(FFps7R("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (dest, dest)))
   return True
  return False
 def VVxFpK(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   CFG.playerPos.setValue(pos)
   CFG.playerPos.save()
   configfile.save()
 def VVFd70(self):
  if self.isManualSeek:
   self.VV9hyw()
   self.VVUNOJ(self.manualSeekPts)
  else:
   if self.shown:
    self.hide()
    self.VVdobw(CCjkQS.VV44Ap)
   else:
    self.VVaFMF()
 def VVaFMF(self, showBar=True):
  if self.SubtWin:
   self.session.deleteDialog(self.SubtWin)
   self.SubtWin = None
  if showBar:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VV9hyw()
  elif self.SubtWin : self.VVaFMF()
  else    : self.close()
 def VVPFTE(self):
  if self.SubtWin:
   self.SubtWin.VVk2b8("noErr")
  FFnMVC(self, fncMode=CCipRP.VVik0v)
 def VVYU7F(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except Exception as e:
   pass
  self.VVCGm5("Toggling Play/Pause ...")
 def VV9hyw(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVl2Om(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC7tge.VVuQi4(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVEWEo()
   else:
    self.manualSeekSec += direc * self.VVEWEo()
    self.manualSeekSec = FFIeYG(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFOZ0S(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFi4q2(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVAGSq(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVBATd())
   CFG.playerJumpMin.setValue(self.jumpMinutes)
   CFG.playerJumpMin.save()
   configfile.save()
  self.VVCGm5("Changed Seek Time to : %d%s" % (val, self.VVXVHU()))
 def VVBATd(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVXVHU())
 def VVXVHU(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVaMih(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVEWEo(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVCGm5(self, stateTxt="", highlight=False):
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFCcWd(self, addInfoObj=True)
  fr = res = ""
  if info:
   w = FFZXBZ(info, iServiceInformation.sVideoWidth) or -1
   h = FFZXBZ(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFZXBZ(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  self["myPlayFps"].setText(fr)
  self["myPlayRes"].setText(res)
  self["myPlayAsp"].setText(CCipRP.VVmVv7(info))
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC7tge.VVuQi4(self)
  width = 0
  if seekable:
   if posTxt:
    self["myPlayPos"].setText(posTxt)
    self["myPlayVal"].setText(percTxt)
    if int(remVal) > 0:
     self["myPlayRem"].setText("-%s" % remTxt)
    percent = FFIeYG(percVal, 0, 100)
    width = int(FFOZ0S(percent, 0, 100, 0, self.barWidth))
   self["myPlayDur"].setText(durTxt if durTxt else "")
  else:
   self["myPlayPos"].setText("")
   self["myPlayDur"].setText("")
  if not posTxt: self["myPlayPos"].setText("")
  if not remTxt: self["myPlayRem"].setText("")
  if not durTxt:
   if   prov : txt = prov
   elif posTxt : txt = ">>>>"
   else  : txt = "...."
   self["myPlayVal"].setText(txt)
   self["myPlayRem"].setText("")
   self["myPlayDur"].setText("")
   FF3luO(self["myPlayBarBG"], "#1100202a")
   self["myPlayBarF"].hide()
  else:
   FF3luO(self["myPlayBarBG"], "#11000000")
   self["myPlayBarF"].show()
  self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.VVid2T() : self["myPlayBlu"].show()
  else     : self["myPlayBlu"].hide()
  if stateTxt:
   if highlight: FFZkbe(self["myPlayMsg"], "#0000ffff")
   else  : FFZkbe(self["myPlayMsg"], "#00ff8000")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1: return
  else           : self.noteTime = 0
  if not seekable:
   self["myPlayMsg"].setText("-" if decodedUrl else FFQ6pE(refCode, True))
   FFZkbe(self["myPlayMsg"], "#00ff8066")
  tot = CCiRRm.VV1s8M()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVFBrC()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     self.restoreLastPlayPos = False
     if self.lastPlayPos > 0:
      stateTxt = "Restoring Pos. ..."
      self.VVUNOJ(self.lastPlayPos * 90000.0)
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVFtY3()
  state = self.VV7lZm()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFZkbe(self["myPlayMsg"], "#0000ff00")
  else     : FFZkbe(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 @staticmethod
 def VVuQi4(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFi4q2(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFi4q2(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFi4q2(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVFBrC(self):
  if "EVENT_STATE" in globals():
   global EVENT_STATE
   if EVENT_STATE:
    EVENT_STATE = EVENT_STATE[1:-1]
    if len(EVENT_STATE) == 3: EVENT_STATE = ""
    else     : return EVENT_STATE
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVMd0R(self):
  if self["myPlayBlu"].getVisible():
   cList = self.VVid2T()
   if cList:
    VVJ4VL = []
    for pts, what in cList:
     txt = FFi4q2(int(pts) / 90000.0)
     if   what == 0 : t = "In"
     elif what == 1 : t = "Out"
     elif what == 2 : t = "Mark"
     elif what == 3 : t = "Last"
     else   : t = ""
     if t: txt += "  ( %s )" % t
     VVJ4VL.append((txt, pts))
    FFdrYz(self, self.VVdFFb, VVJ4VL=VVJ4VL, title="Cut List")
   else:
    self.VVCGm5("No Cut-List for this channel !")
 def VVdFFb(self, item=None):
  if item:
   self.VVUNOJ(item)
 def VVid2T(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VV1uq3(self) : self.VVAfR1(1)
 def VVqRCn(self) : self.VVAfR1(-1)
 def VVAfR1(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC7tge.VVuQi4(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVEWEo() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVaMih())
    self.VVCGm5(txt)
  except:
   self.VVCGm5("Cannot jump")
 def VVUNOJ(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVCGm5("Changing Time ...")
 def VVFtY3(self):
  self.VVJ0GP(1)
  self.VVCGm5("Replaying ...")
  self.VV9hyw()
 def VVvtNR(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC7tge.VVuQi4(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVCGm5("Jumping to end ...")
  except:
   pass
 def VV7lZm(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVu6TJ(self, isUp):
  if self.enableZapping:
   self.VVCGm5("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VV9hyw()
   if self.portalTableParam:
    FFOFIS(boundFunction(self.VV7VB5, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self)
    if "/timeshift/" in decodedUrl:
     self.VVCGm5("Cannot Zap Catcup TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVvhRQ()
 def VVvhRQ(self):
  self.lastPlayPos = 0
  self.VVqcQw()
  self.VVDTzr()
 def VV7VB5(self, isUp):
  CCmV60_inatance, VVByVq, mode = self.portalTableParam
  if isUp : VVByVq.VVZkfV()
  else : VVByVq.VVZYKl()
  colList = VVByVq.VVBNVx()
  if mode == "localIptv":
   chName, chUrl = CCmV60_inatance.VV9adj(VVByVq, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCmV60_inatance.VV0gVi(VVByVq, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCmV60_inatance.VV80M5(mode, VVByVq, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCmV60_inatance.VVSlNc(mode, VVByVq, colList)
  else:
   self.VVCGm5("Cannot Zap")
   return
  FFPZFB(self, chUrl, VVhM2K=False)
  self.VVvhRQ()
 def VVDTzr(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC7tge.VVuQi4(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self)
   if not self.VVAj2I(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVCGm5("Refreshing Portal")
   FFOFIS(self.VVmwHD)
  except:
   pass
 def VVmwHD(self):
  self.restoreLastPlayPos = self.VVTZVs()
 def VVqf2f(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self)
  if not decodedUrl or FFvbGL(decodedUrl):
   self.VVCGm5("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCmV60.VVxXhs(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVCGm5("Reading Program List ...")
   ok_fnc = boundFunction(self.VVYxkj, refCode, chName, streamId, uHost, uUser, uPass)
   FFOFIS(boundFunction(CCmV60.VVZbpP, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVCGm5("Cannot process this channel")
 def VVYxkj(self, refCode, chName, streamId, uHost, uUser, uPass, VVByVq, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVByVq.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVCGm5("Changing Program ...")
   FFOFIS(boundFunction(self.VV4g2q, chUrl))
  else:
   self.VVCGm5("Incorrect Timestamp !")
 def VV4g2q(self, chUrl):
   FFPZFB(self, chUrl, VVhM2K=False)
   self.lastPlayPos = 0
   self.VVqcQw()
 def VVF8Qo(self, isAudio):
  try:
   VVw7XZ = InfoBar.instance
   if VVw7XZ:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVw7XZ)
    else  : self.session.open(SubtitleSelection, VVw7XZ)
  except:
   pass
class CCwb3a(Screen):
 def __init__(self, session, title="", VVoqcK="Continue?", VVxElG=True, VVIDtV=False):
  self.skin, self.skinParam = FFbmPq(VV0fqG, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVoqcK = VVoqcK
  self.VVIDtV = VVIDtV
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVxElG : VVJ4VL = [no , yes]
  else   : VVJ4VL = [yes, no ]
  FF9Cql(self, title, VVJ4VL=VVJ4VL, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVFd70 ,
   "cancel" : self.cancel ,
   "red"  : self.cancel ,
  }, -1)
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVoqcK)
  if self.VVIDtV:
   self["myLabel"].instance.setHAlign(0)
  self.VVoxfu()
  FFYI0q(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFGNTa(self["myMenu"])
  FFFCQO(self, self["myMenu"])
 def VVFd70(self):
  item = FFTSK4(self, False)
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVoxfu(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  textW  = textSize.width()
  textH  = textSize.height()
  diff  = textH - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CC9g1v(Screen):
 def __init__(self, session, title="", VVJ4VL=None, width=1000, height=0, OKBtnFnc=None, VVzYgB=None, VVfRF6=None, VVx8rq=None, VVfXyU=None, VVYMy8=False, VVEfaQ=False):
  if height == 0: height = 850
  self.skin, self.skinParam = FFbmPq(VVXAn9, width, height, 50, 40, 30, "#22003344", "#22002233", 30, barHeight=40)
  self.session   = session
  self.VVJ4VL   = VVJ4VL
  self.OKBtnFnc   = OKBtnFnc
  self.VVzYgB   = VVzYgB
  self.VVfRF6  = VVfRF6
  self.VVx8rq  = VVx8rq
  self.VVfXyU   = VVfXyU
  self.VVYMy8  = VVYMy8
  self.VVEfaQ  = VVEfaQ
  FF9Cql(self, title, VVJ4VL=VVJ4VL)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVFd70          ,
   "cancel" : self.cancel          ,
   "red"  : self.VV9vHa         ,
   "green"  : self.VVOOna         ,
   "yellow" : self.VVMcy5         ,
   "blue"  : self.VVii7U         ,
   "pageUp" : self.VVZnIl       ,
   "chanUp" : self.VVZnIl       ,
   "pageDown" : self.VVXzSj        ,
   "chanDown" : self.VVXzSj
  }, -1)
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FFYI0q(self["myMenu"])
  FFImVi(self)
  self.VVmKTH(self["keyRed"]  , self.VVzYgB )
  self.VVmKTH(self["keyGreen"] , self.VVfRF6 )
  self.VVmKTH(self["keyYellow"] , self.VVx8rq )
  self.VVmKTH(self["keyBlue"]  , self.VVfXyU )
  if not self["keyRed"].getVisible() : self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FF4l2q(self)
 def VVmKTH(self, btnObj, btnFnc):
  if btnFnc:
   FFCpCt(btnObj, btnFnc[0])
 def VVFd70(self):
  item = FFTSK4(self, False)
  if item is not None:
   txt = self["myMenu"].l.getCurrentSelection()[0]
   ref = self["myMenu"].l.getCurrentSelection()[1]
   ndx = self["myMenu"].l.getCurrentSelectionIndex()
   if self.OKBtnFnc:
    self.OKBtnFnc((self, txt, ref, ndx))
   else:
    if self.VVYMy8: self.close((txt, ref, ndx))
    else     : self.close(item)
 def cancel(self):
  self.close(None)
 def VV9vHa(self)  : self.VVwuuA(self.VVzYgB)
 def VVOOna(self) : self.VVwuuA(self.VVfRF6)
 def VVMcy5(self) : self.VVwuuA(self.VVx8rq)
 def VVii7U(self) : self.VVwuuA(self.VVfXyU)
 def VVwuuA(self, btnFnc):
  if btnFnc:
   item = FFTSK4(self, False)
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVEfaQ:
    self.cancel()
 def VV1cyv(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVJ4VL = self["myMenu"].list
  VVJ4VL.pop(ndx)
  if len(VVJ4VL) > 0: self["myMenu"].setList(VVJ4VL)
  else    : self.close()
 def VV9q0E(self, VVJ4VL):
  if len(VVJ4VL) > 0:
   newList = []
   for item in VVJ4VL:
    newList.append((item, item))
   self["myMenu"].setList(newList)
  else:
   self.close("")
 def VVAGtY(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVZnIl(self):
  self["myMenu"].moveToIndex(0)
 def VVXzSj(self) :
  self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCt6LB(Screen):
 def __init__(self, session, title="", width=1600, height=900, header=None, VV1rg6=None, VV32KX=None, VVDe98=None, VVwZKv=26, VVB9Wc=False, VV69tn=None, VVTRSb=None, VV5uBQ=None, VVw8s5=None, VV3Y5Z=None, VVGv9L=None, VVezXI=None, VVDKrQ=None, VVFhJO=None, VVQTvb=-1, VVtgEG=False, searchCol=0, VVZ7ot=None, VVuutY=None, VVIzlJ="#00dddddd", VV5tqg="#11002233", VVLZXK="#00ff8833", VVwtgu="#11111111", VVorfQ="#0a555555", VVYxpD="#0affffff", VV1sri="#11552200", VVlZk2="#0055ff55"):
  self.skin, self.skinParam = FFbmPq(VVJ5AW, width, height, 50, 10, 5, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FF9Cql(self, title)
  self.header     = header
  self.VV1rg6     = VV1rg6
  self.totalCols    = len(VV1rg6[0])
  self.VVNHnp   = 0
  self.lastSortModeIsReverese = False
  self.VVB9Wc   = VVB9Wc
  self.VVijGb   = 0.01
  self.VVk83k   = 0.02
  self.VVOfRs = 0.03
  self.VVsjMy  = 1
  self.VVDe98 = VVDe98
  self.colWidthPixels   = []
  self.VV69tn   = VV69tn
  self.OKButtonObj   = None
  self.VVTRSb   = VVTRSb
  self.VV5uBQ   = VV5uBQ
  self.VVw8s5   = VVw8s5
  self.VV3Y5Z  = VV3Y5Z
  self.VVGv9L   = VVGv9L
  self.VVezXI    = VVezXI
  self.VVDKrQ   = VVDKrQ
  self.VVFhJO  = VVFhJO
  self.VVQTvb    = VVQTvb
  self.VVtgEG   = VVtgEG
  self.searchCol    = searchCol
  self.VV32KX    = VV32KX
  self.keyPressed    = -1
  self.VVwZKv    = FF5pbP(VVwZKv)
  self.VVkqvP    = FFVZvQ(self.VVwZKv, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVZ7ot    = VVZ7ot
  self.VVuutY      = VVuutY
  self.VVIzlJ    = FFmdyN(VVIzlJ)
  self.VV5tqg    = FFmdyN(VV5tqg)
  self.VVLZXK    = FFmdyN(VVLZXK)
  self.VVwtgu    = FFmdyN(VVwtgu)
  self.VVorfQ   = FFmdyN(VVorfQ)
  self.VVYxpD    = FFmdyN(VVYxpD)
  self.VV1sri    = FFmdyN(VV1sri)
  self.VVlZk2   = FFmdyN(VVlZk2)
  self.VVTa6z  = False
  self.selectedItems   = 0
  self.VVjIRl   = FFmdyN("#01fefe01")
  self.VVxZAT   = FFmdyN("#11400040")
  self.VVfpIC  = self.VVjIRl
  self.VVCPzn  = self.VVwtgu
  if self.VVtgEG:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] =  MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  =  MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVYQfj  ,
   "red"   : self.VVDLXE  ,
   "green"   : self.VVu1IW ,
   "yellow"  : self.VVZvmQ ,
   "blue"   : self.VVVkrB  ,
   "menu"   : self.VVwvPT ,
   "info"   : self.VVWGeN  ,
   "cancel"  : self.VVNu7X  ,
   "up"   : self.VVZYKl    ,
   "down"   : self.VVZkfV  ,
   "left"   : self.VVjPbK   ,
   "right"   : self.VVlmjb  ,
   "pageUp"  : self.VVc6UV  ,
   "chanUp"  : self.VVc6UV  ,
   "pageDown"  : self.VVqO3b  ,
   "chanDown"  : self.VVqO3b
  }, -1)
  FFYrbe(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FFGuuf(self)
  try:
   self.VVnygK()
  except Exception as err:
   FFBAp7(self, str(err))
   self.close(None)
 def VVnygK(self):
  FF4l2q(self)
  if self.VVZ7ot:
   FF3luO(self["myTitle"], self.VVZ7ot)
  if self.VVuutY:
   FF3luO(self["myBody"] , self.VVuutY)
   FF3luO(self["myTableH"] , self.VVuutY)
   FF3luO(self["myTable"] , self.VVuutY)
   FF3luO(self["myBar"]  , self.VVuutY)
  self.VVmKTH(self.VV5uBQ  , self["keyRed"])
  self.VVmKTH(self.VVw8s5  , self["keyGreen"])
  self.VVmKTH(self.VV3Y5Z , self["keyYellow"])
  self.VVmKTH(self.VVGv9L  , self["keyBlue"])
  if self.VV69tn:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VV69tn[0])
    FF3luO(self.OKButtonObj, "#000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVkqvP)
  self["myTableH"].l.setFont(0, gFont(VVs8av, self.VVwZKv))
  self["myTable"].l.setItemHeight(self.VVkqvP)
  self["myTable"].l.setFont(0, gFont(VVs8av, self.VVwZKv))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w  = self["myTable"].instance.size().width()
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVkqvP)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVkqvP))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVkqvP)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVkqvP
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVkqvP * len(self.VV1rg6) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVDe98:
   self.VVDe98 = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVDe98)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VV32KX:
   self.VV32KX = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VV32KX
   self.VV32KX = []
   for item in tmpList:
    self.VV32KX.append(item | RT_VALIGN_CENTER)
  self.VVDABt()
  if self.VVezXI:
   self.VVezXI(self)
 def VVmKTH(self, btnFnc, btn):
  if btnFnc : FFCpCt(btn, btnFnc[0])
  else  : FFCpCt(btn, "")
 def VVYE4J(self, waitTxt):
  FFobhC(self, self.VVDABt, title=waitTxt)
 def VVDABt(self):
  try:
   if self.header:
    self["myTableH"].setList([self.VVV3Pz(0, self.header, self.VVYxpD, self.VV1sri, self.VVYxpD, self.VV1sri, self.VVlZk2)])
   rows = []
   for c, row in enumerate(self.VV1rg6):
    rows.append(self.VVV3Pz(c, row, self.VVIzlJ, self.VV5tqg, self.VVLZXK, self.VVwtgu, None))
   self["myTable"].setList(rows)
   rows = None
   if self.VVQTvb > -1:
    self["myTable"].moveToIndex(self.VVQTvb )
   self.VVFpIq()
   if self.VVtgEG:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVkqvP * len(self.VV1rg6)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
   if self.VVDKrQ:
    self.VVwuuA(self.VVDKrQ, None)
  except AttributeError as attrErr:
   pass
  except Exception as err:
   try:
    FFBAp7(self, str(err))
    self.close()
   except:
    pass
 def VVV3Pz(self, keyIndex, columns, VVIzlJ, VV5tqg, VVLZXK, VVwtgu, VVlZk2):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVlZk2 and ndx == self.VVNHnp : textColor = VVlZk2
   else           : textColor = VVIzlJ
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFmdyN(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VV5tqg = c
    entry = span.group(3)
   if self.VV32KX[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVkqvP)
           , font   = 0
           , flags   = self.VV32KX[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VV5tqg
           , color_sel  = VVLZXK
           , backcolor_sel = VVwtgu
           , border_width = 1
           , border_color = self.VVorfQ
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVWGeN(self):
  rowData = self.VVcSD8()
  if rowData:
   title, txt, colList = rowData
   if self.VVTRSb:
    fnc  = self.VVTRSb[1]
    params = self.VVTRSb[2]
    fnc(self, title, txt, colList)
   else:
    FFzRpw(self, txt, title)
 def VVYQfj(self):
  if   self.VVTa6z : self.VV6Dw0(self.VVwl1D(), mode=2)
  elif self.VV69tn  : self.VVwuuA(self.VV69tn, None)
  else      : self.VVWGeN()
 def VVDLXE(self) : self.VVwuuA(self.VV5uBQ , self["keyRed"])
 def VVu1IW(self) : self.VVwuuA(self.VVw8s5 , self["keyGreen"])
 def VVZvmQ(self): self.VVwuuA(self.VV3Y5Z , self["keyYellow"])
 def VVVkrB(self) : self.VVwuuA(self.VVGv9L , self["keyBlue"])
 def VVwuuA(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFtMdo(self, buttonFnc[3])
    FFOFIS(boundFunction(self.VV5pEb, buttonFnc))
   else:
    self.VV5pEb(buttonFnc)
 def VV5pEb(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVcSD8()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VV6Dw0(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   item = self.VV1rg6[ndx]
   isSelected = row[1][9] == self.VVjIRl
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VVV3Pz(ndx, item, self.VVIzlJ, self.VV5tqg, self.VVLZXK, self.VVwtgu, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VVV3Pz(ndx, item, self.VVjIRl, self.VVxZAT, self.VVfpIC, self.VVCPzn, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   self.VVFpIq()
 def VVrbd3(self):
  FFobhC(self, self.VVvaLa, title="Selecting all ...")
 def VVvaLa(self):
  self.VVHK3s(True)
  for ndx, row in enumerate(self["myTable"].list):
   isSelected = row[1][9] == self.VVjIRl
   if not isSelected:
    item = self.VV1rg6[ndx]
    newRow = self.VVV3Pz(ndx, item, self.VVjIRl, self.VVxZAT, self.VVfpIC, self.VVCPzn, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = len(self["myTable"].list)
  self.VVFpIq()
  self.VVZ4tf()
 def VV6cA9(self):
  FFobhC(self, self.VVP6dV, title="Unselecting all ...")
 def VVP6dV(self):
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVjIRl:
    item = self.VV1rg6[ndx]
    newRow = self.VVV3Pz(ndx, item, self.VVIzlJ, self.VV5tqg, self.VVLZXK, self.VVwtgu, None)
    self["myTable"].list.pop(ndx)
    self["myTable"].list.insert(ndx, newRow)
  self.selectedItems = 0
  self.VVFpIq()
  self.VVZ4tf()
 def VVZ4tf(self):
  self.hide()
  self.show()
 def VVcSD8(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVDe98[i] > 1 or self.VVDe98[i] == self.VVijGb or self.VVDe98[i] == self.VVOfRs:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self.VV1rg6))
   return rowNum, txt, colList
  else:
   return None
 def VVNu7X(self):
  if self.VVFhJO : self.VVFhJO(self)
  else     : self.close(None)
 def cancel(self):
  self.close(None)
 def VVWtjK(self):
  return self["myTitle"].getText().strip()
 def VVFX2i(self):
  return self.header
 def VVEFZZ(self, title):
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVCgW1(self, txt):
  FFtMdo(self, txt)
 def VVq6Qj(self, txt):
  FFtMdo(self, txt, 1000)
 def VVZQH0(self):
  FFtMdo(self)
 def VVlbt7(self):
  return len(self.VV1rg6)
 def VVor9V(self): self["keyGreen"].show()
 def VV7p6f(self): self["keyGreen"].hide()
 def VVwl1D(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVRjIQ(self):
  return len(self["myTable"].list)
 def VVHK3s(self, isOn):
  self.VVTa6z = isOn
  if isOn:
   color = "#01550033"
   self["keyMenu"].hide()
   if self.VVGv9L: self["keyBlue"].hide()
   if self.VV69tn and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVGv9L: self["keyBlue"].show()
   if self.VV69tn and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VV69tn[0])
   self.VV6cA9()
  FF3luO(self["myTitle"], color)
  FF3luO(self["myBar"]  , color)
 def VVqRGP(self):
  return self.VVTa6z
 def VVGUaE(self):
  return self.selectedItems
 def VV5bpT(self, rowNum):
  if rowNum >= 0 and rowNum < len(self["myTable"].list):
   self["myTable"].moveToIndex(rowNum)
   self.VVFpIq()
 def VVL0qS(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVFpIq()
 def VVCgPx(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self.VV1rg6:
    lst.add(item[colNum])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVtQoB(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVlbt7()
  txt += FFZuRe("Total Unique Items", VVpKeT)
  for i in range(self.totalCols):
   if self.VVDe98[i - 1] > 1 or self.VVDe98[i - 1] == self.VVijGb or self.VVDe98[i - 1] == self.VVOfRs:
    name, tot = self.VVCgPx(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFzRpw(self, txt)
 def VVfRxf(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVBNVx(self):
  item = self["myTable"].getCurrent()
  colList = []
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVzmZc(self, newList, newTitle="", VVJJvTMsg=True):
  if newList:
   self.VV1rg6 = newList
   if self.VVB9Wc and self.VVNHnp == 0:
    self.VV1rg6 = sorted(self.VV1rg6, key=lambda x: int(x[self.VVNHnp])   , reverse=self.lastSortModeIsReverese)
   else:
    self.VV1rg6 = sorted(self.VV1rg6, key=lambda x: x[self.VVNHnp].lower(), reverse=self.lastSortModeIsReverese)
   if VVJJvTMsg : self.VVYE4J("Refreshing ...")
   else   : self.VVDABt()
   if newTitle:
    self.VVEFZZ(newTitle)
  else:
   FFBAp7(self, "Cannot refresh list")
   self.cancel()
 def VVFmzh(self, data):
  ndx = self.VVwl1D()
  newRow = self.VVV3Pz(ndx, data, self.VVIzlJ, self.VV5tqg, self.VVLZXK, self.VVwtgu, None)
  if newRow:
   self.VV1rg6[ndx] = data
   self["myTable"].list[ndx] = newRow
   self.VVFpIq()
   return True
  else:
   return False
 def VVgUPC(self, colNum, textToFind, VVqJ5y=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVFpIq()
    break
  else:
   if VVqJ5y:
    FFtMdo(self, "Not found", 1000)
 def VVdYA0(self, colDict, VVqJ5y=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVFpIq()
    return
  if VVqJ5y:
   FFtMdo(self, "Not found", 1000)
 def VVdYA0_partial(self, colDict, VVqJ5y=False):
  length = len(colDict)
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    span = iSearch(iEscape(txt), self["myTable"].list[i][colNum + 1][7].strip(), IGNORECASE)
    if not span:
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVFpIq()
    return
  if VVqJ5y:
   FFtMdo(self, "Not found", 1000)
 def VV443b(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVcoGn(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVjIRl:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVDK6Y(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VVjIRl: return True
  else        : return False
 def VVfKVc(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVwvPT(self):
  if not self["keyMenu"].getVisible() or self.VVtgEG:
   return
  VVJ4VL = []
  VVJ4VL.append(("Table Statistcis"             , "tableStat"  ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append((FF2tuT("Export Table to .html"     , VVpKeT) , "VVxfH7" ))
  VVJ4VL.append((FF2tuT("Export Table to .csv"     , VVpKeT) , "VVAYSJ" ))
  VVJ4VL.append((FF2tuT("Export Table to .txt (Tab Separated)", VVpKeT) , "VVcPSl" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVDe98[i] > 1 or self.VVDe98[i] == self.VVk83k:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVJ4VL.append(VV1dpw)
   if tot == 1 : VVJ4VL.append(("Sort", sList[0][1]))
   else  : VVJ4VL += sList
  FFdrYz(self, self.VV5Igv, VVJ4VL=VVJ4VL, title=self.VVWtjK())
 def VV5Igv(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "tableStat" : self.VVtQoB()
   elif item == "VVxfH7": FFobhC(self, self.VVxfH7, title=title)
   elif item == "VVAYSJ" : FFobhC(self, self.VVAYSJ , title=title)
   elif item == "VVcPSl" : FFobhC(self, self.VVcPSl , title=title)
   else:
    isReversed = False
    if self.VVNHnp == item:
     isReversed = not self.lastSortModeIsReverese
    self.lastSortModeIsReverese = isReversed
    if self.VVB9Wc and item == 0:
     self.VV1rg6 = sorted(self.VV1rg6, key=lambda x: int(x[item]), reverse=isReversed)
    else:
     self.VV1rg6 = sorted(self.VV1rg6, key=lambda x: x[item].lower(), reverse=isReversed)
    self.VVNHnp = item
    self.VVYE4J("Sorting ...")
 def VVZYKl(self):
  self["myTable"].up()
  self.VVFpIq()
 def VVZkfV(self):
  self["myTable"].down()
  self.VVFpIq()
 def VVjPbK(self):
  self["myTable"].pageUp()
  self.VVFpIq()
 def VVlmjb(self):
  self["myTable"].pageDown()
  self.VVFpIq()
 def VVc6UV(self):
  self["myTable"].moveToIndex(0)
  self.VVFpIq()
 def VVqO3b(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVFpIq()
 def VVSgIu(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVFpIq()
 def VVcPSl(self):
  expFile = self.VVOymf() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVrapd()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for row in self.VV1rg6:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVDe98[ndx] > self.VVsjMy or self.VVDe98[ndx] == self.VVOfRs:
      col = self.VVwJ5p(col)
      newRow.append(col.strip())
    f.write("\t".join(newRow) + "\n")
  self.VVfgAN(expFile)
 def VVAYSJ(self):
  expFile = self.VVOymf() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVrapd()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for row in self.VV1rg6:
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVDe98[ndx] > self.VVsjMy or self.VVDe98[ndx] == self.VVOfRs:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      if "," in col   : col = col.replace(",", "_")
      col = self.VVwJ5p(col)
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVfgAN(expFile)
 def VVxfH7(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVWtjK(), PLUGIN_NAME, VVy0i9)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVWtjK()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVrapd()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVDe98:
   colgroup += '   <colgroup>'
   for w in self.VVDe98:
    if w > self.VVsjMy or w == self.VVOfRs:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVOymf() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for row in self.VV1rg6:
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVDe98[ndx] > self.VVsjMy or self.VVDe98[ndx] == self.VVOfRs:
      col = self.VVwJ5p(col)
      newRow += '<td>%s</td>' % col.strip()
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVfgAN(expFile)
 def VVrapd(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVDe98[ndx] > self.VVsjMy or self.VVDe98[ndx] == self.VVOfRs:
     newRow.append(col.strip())
  return newRow
 def VVwJ5p(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFWYHc(col)
 def VVOymf(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVWtjK())
  fileName = fileName.replace("__", "_")
  path  = FF5gdy(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFC5od()
  return expFile
 def VVfgAN(self, expFile):
  FFSzHX(self, "File exported to:\n\n%s" % expFile, title=self.VVWtjK())
 def VVFpIq(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CC0FUZ():
 def __init__(self, pixmapObj, picPath):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
 def VVI4bZ(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVi2sy)
    except Exception as e:
     self.picLoad.PictureData.get().append(self.VVi2sy)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, "#2200002a"])
    self.picLoad.startDecode(self.picPath)
    return True
   except Exception as e:
    pass
  return False
 def VVi2sy(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    self.pixmapObj.instance.setPixmap(ptr)
 def VVQ3cj(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VV98pS(pixmapObj, path):
  cl = CC0FUZ(pixmapObj, path)
  ok = cl.VVI4bZ()
  if ok: return cl
  else : return None
class CCv4E7(Screen):
 def __init__(self, session, title="", VVYQGM=None, showGrnMsg=""):
  self.skin, self.skinParam = FFbmPq(VV3w8V, 1400, 800, 30, 40, 20, "#22000060", "#2200002a", 30)
  if not title:
   title = os.path.basename(VVYQGM),
  self.session = session
  FF9Cql(self, title, addCloser=True)
  self["myPic"]  = Pixmap()
  self.VVYQGM = VVYQGM
  self.showGrnMsg  = showGrnMsg
  self.picViewer  = None
  self.onShown.append(self.VVJGeB)
  self.onClose.append(self.onExit)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  self.picViewer = CC0FUZ.VV98pS(self["myPic"], self.VVYQGM)
  if self.picViewer:
   if self.showGrnMsg:
    FFtMdo(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFBAp7(self, "Cannot view picture file:\n\n%s" % self.VVYQGM)
   self.close()
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVQ3cj()
 @staticmethod
 def VV2MIq(SELF, VVYQGM, title="", showGrnMsg=""):
  SELF.session.open(boundFunction(CCv4E7, title=title, VVYQGM=VVYQGM, showGrnMsg=showGrnMsg))
class CCqqrI(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFbmPq(VVeULt, 1400, 1000, 50, 40, 40, "#11201010", "#11101010", 26, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FF9Cql(self, title=self.Title)
  FFCpCt(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Signal & Player Cotroller Hotkey"       , CFG.hotkey_signal    ))
  if VVDsHP:
   lst.append(getConfigListEntry("EPG Translation Language"        , CFG.epgLanguage    ))
  if VVM64s:
   lst.append(getConfigListEntry("Force UTF-8 Encoding (only OpenVision Python-3.10.2+)" , CFG.forceUtf8Encoding   ))
  lst.append(getConfigListEntry(VVlhhY *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type"         , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsPath    ))
  lst.append(getConfigListEntry("Movie/Series Download Path"         , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(VVlhhY *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(VVlhhY *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB)"        , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons"            , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVwJua()
  self.onShown.append(self.VVJGeB)
 def VVwJua(self):
  kList = {
    "ok"  : self.VVFd70    ,
    "green"  : self.VVzDwi   ,
    "menu"  : self.VVH073  ,
    "cancel" : self.VVFckC  ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"]  = boundFunction(self["config"].handleKey, kLeft)
   kList["right"]  = boundFunction(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = boundFunction(self["config"].VVaZs3, 0)
     kList["chanDown"] = boundFunction(self["config"].VVaZs3, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FFGuuf(self)
  FFYI0q(self["config"])
  FFImVi(self, self["config"])
  FF4l2q(self)
 def VVFd70(self):
  item = self["config"].getCurrent()[1]
  if item:
   if   item == CFG.iptvHostsPath   : self.VVvvUJ()
   elif item == CFG.MovieDownloadPath   : self.VV7fqL(item, self["config"].getCurrent()[0])
   elif item == CFG.PIconsPath    : self.VVUbEq(item)
   elif item == CFG.backupPath    : self.VVUbEq(item)
   elif item == CFG.packageOutputPath  : self.VVUbEq(item)
   elif item == CFG.downloadedPackagesPath : self.VVUbEq(item)
   elif item == CFG.exportedTablesPath  : self.VVUbEq(item)
   elif item == CFG.exportedPIconsPath  : self.VVUbEq(item)
 def VV7fqL(self, item, title):
  tot = CCiRRm.VV1s8M()
  if tot : FFBAp7(self, "Cannot change while downloading.", title=title)
  else : self.VVUbEq(item)
 def VVvvUJ(self):
  VVJ4VL = []
  VVJ4VL.append(("Auto Find" , "auto"))
  VVJ4VL.append(("Custom Path" , "path"))
  FFdrYz(self, self.VVyGVx, VVJ4VL=VVJ4VL, title="IPTV Hosts Files Path")
 def VVyGVx(self, item=None):
  if item:
   if   item == "auto": CFG.iptvHostsPath.setValue(VVIhrd)
   elif item == "path": self.VVUbEq(CFG.iptvHostsPath)
 def VVUbEq(self, configObj):
  sDir = configObj.getValue()
  if sDir == VVIhrd:
   sDir = "/"
  self.session.openWithCallback(boundFunction(self.VVwPJe, configObj)
         , boundFunction(CCsPG3, mode=CCsPG3.VVHqWs, VV0Jhk=sDir))
 def VVwPJe(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVFckC(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFJWhD(self, self.VVzDwi, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVzDwi(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVBUyY()
  self.VViGwT()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VViGwT(self):
  CCaMcm.VVPDqQ()
 def VVH073(self):
  VVJ4VL = []
  VVJ4VL.append(("Use Backup directory in all other paths"      , "VVdXNl"   ))
  VVJ4VL.append(("Reset all to default (including File Manager bookmarks)"  , "VV7vGm"   ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Change Text Color Scheme (fix Transparent Text)"    , "changeColorScheme" ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Backup %s Settings" % PLUGIN_NAME        , "VV5cD5"  ))
  VVJ4VL.append(("Restore %s Settings" % PLUGIN_NAME       , "VVlE6Z"  ))
  if fileExists(VVmnJB + VVLwsT):
   VVJ4VL.append(VV1dpw)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable"  , "disableChkUpdate"
   else          : txt1, txt2 = "Enable"   , "enableChkUpdate"
   VVJ4VL.append(('%s Checking for Update' % txt1       , txt2     ))
   VVJ4VL.append(("Reinstall %s" % PLUGIN_NAME        , "VVbFJ7"  ))
   VVJ4VL.append(("Update %s" % PLUGIN_NAME        , "VVUI69"   ))
  FFdrYz(self, self.VVGrw2, VVJ4VL=VVJ4VL, title="Config. Options")
 def VVGrw2(self, item=None):
  if item:
   if   item == "VVdXNl"  : FFJWhD(self, self.VVdXNl , "Use Backup directory in all other paths (and save) ?")
   elif item == "VV7vGm"  : FFJWhD(self, self.VV7vGm, "Clear all settings (including File Manager bookmarks) ?")
   elif item == "changeColorScheme": self.session.open(CCRLh1)
   elif item == "VV5cD5" : self.VV5cD5()
   elif item == "VVlE6Z" : FFobhC(self, self.VVlE6Z, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : self.VVkl81(True)
   elif item == "disableChkUpdate" : self.VVkl81(False)
   elif item == "VVbFJ7" : FFobhC(self, self.VVbFJ7 , "Checking Server ...")
   elif item == "VVUI69"  : FFobhC(self, self.VVUI69  , "Checking Server ...")
 def VV5cD5(self):
  path = "%sajpanel_settings_%s" % (VVmnJB, FFC5od())
  os.system("grep .%s. /etc/enigma2/settings > %s" % (PLUGIN_NAME, path))
  FFSzHX(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVlE6Z(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name = "ajpanel_settings_"
  lines = FF5Oes("find / %s -iname '%s*' | grep %s" % (FFebM5(1), name, name))
  if lines:
   lines.sort()
   VVJ4VL = []
   for line in lines:
    VVJ4VL.append((line, line))
   FFdrYz(self, boundFunction(self.VV8TSG, title), title=title, VVJ4VL=VVJ4VL, width=1200)
  else:
   FFBAp7(self, "No settings files found !", title=title)
 def VV8TSG(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFHvYZ(path)
    for line in lines:
     eqNdx = line.find('=')
     if eqNdx > -1:
      name = line[:eqNdx].strip()
      val  = line[eqNdx + 1:].strip()
      try:
       configEntry = eval(name)
       if configEntry is not None:
        if   isinstance(configEntry, ConfigInteger)  : val = int(val)
        elif isinstance(configEntry, ConfigYesNo)  : val = { "true": True, "false": False }.get(val)
        if not val is None:
         configEntry.value = val
         configEntry.save()
      except:
       pass
    self.VVBUyY()
    FFV4Ub()
   else:
    FFhMRQ(SELF, path, title=title)
 def VVkl81(self, isEnable):
  CFG.checkForUpdateAtStartup.setValue(isEnable)
  CFG.checkForUpdateAtStartup.save()
  configfile.save()
 def VVdXNl(self):
  newPath = FF5gdy(VVmnJB)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVBUyY()
 @staticmethod
 def VVdeeP():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VV7vGm(self):
  CFG.showInMainMenu.setValue(False)
  CFG.showInExtensionMenu.setValue(True)
  CFG.showInChannelListMenu.setValue(True)
  CFG.EventsInfoMenu.setValue(True)
  CFG.keyboard.setValue("v")
  CFG.hotkey_signal.setValue("lesc")
  CFG.epgLanguage.setValue("off")
  CFG.forceUtf8Encoding.setValue(True)
  CFG.iptvAddToBouquetRefType.setValue("4097")
  CFG.autoResetFrozenIptvChan.setValue(True)
  CFG.hideIptvServerAdultWords.setValue(False)
  CFG.hideIptvServerChannPrefix.setValue(False)
  CFG.iptvHostsPath.setValue(VVIhrd)
  CFG.MovieDownloadPath.setValue(CCiRRm.VV8UgT())
  CFG.PIconsPath.setValue(VVwNbm)
  CFG.backupPath.setValue(CCqqrI.VVdeeP())
  CFG.packageOutputPath.setValue("/tmp/")
  CFG.downloadedPackagesPath.setValue("/tmp/")
  CFG.exportedTablesPath.setValue("/tmp/")
  CFG.exportedPIconsPath.setValue("/tmp/")
  CFG.browserStartPath.setValue("/")
  CFG.browserBookmarks.setValue("")
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVBUyY()
  self.close()
 def VVBUyY(self):
  configfile.save()
  global VVmnJB
  VVmnJB = CFG.backupPath.getValue()
  FFpFFC()
 def VVUI69(self):
  title = "Update %s (from server)" % PLUGIN_NAME
  webVer = self.VV2DuP(title)
  if webVer:
   FFJWhD(self, boundFunction(FFobhC, self, boundFunction(self.VVT9lf, webVer, title)), "Update with v%s and Restart ?" % webVer, title=title)
 def VVbFJ7(self):
  title = "Reinstall %s (from server)" % PLUGIN_NAME
  webVer = self.VV2DuP(title, True)
  if webVer:
   FFJWhD(self, boundFunction(FFobhC, self, boundFunction(self.VVT9lf, webVer, title, True)), "Install and Restart ?", title=title)
 def VVT9lf(self, webVer, title, isReinst=False):
  url = self.VVoe7c(self, title)
  if url:
   VV2ASm = FF57GN() == "dpkg"
   if VV2ASm == "dpkg" : ext = "deb"
   else     : ext = "ipk"
   fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if VV2ASm else "ipk")
   path, err = FFSgzY(url + fName, fName, timeout=2)
   if path:
    if isReinst : cmd = FFj0t1(VVJUEs, path)
    else  : cmd = FFj0t1(VV1Ulm, path)
    if cmd:
     cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -r '%s'" % (cmd, path)
     FFKyuP(self, cmd)
    else:
     FFhJ5k(self, title=title)
   else:
    FFBAp7(self, err, title=title)
 def VV2DuP(self, title, anyVer=False):
  url = self.VVoe7c(self, title)
  if not url:
   return ""
  path, err = FFSgzY(url + "version", "ajpanel_tmp.ver", timeout=2)
  if not path:
   FFBAp7(self, err, title)
   return ""
  webVer = ""
  if fileExists(path):
   txt  = FFWaDF(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span : webVer = span.group(1)
   else : err = 'Server version not found !'
  else:
   err = 'Cannot download server "version" file !'
  if err:
   FFBAp7(self, err, title)
   return ""
  if anyVer:
   return webVer
  curVer = VVy0i9.lstrip("v").lstrip("V")
  if not curVer == webVer:
   cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
   list = FF5Oes(cmd)
   if list and curVer == list[0]:
    return webVer
  FFSzHX(self, FF2tuT("No update required.", VVx2Y8) + "\n\nCurrent Version = %s\n\nWeb Version = %s" % (curVer, webVer), title)
  return ""
 @staticmethod
 def VVoe7c(SELF=None, title=None):
  url  = ""
  err  = ""
  path = VVmnJB + VVLwsT
  if fileExists(path):
   span = iSearch(r"(http.+)", FFWaDF(path), IGNORECASE)
   if span : url = FF5gdy(span.group(1))
   else : err = "No URL in:\n\n%s" % path
  else:
   err = "Update File not found:\n\n%s" % path
  if err and SELF and title:
   FFBAp7(SELF, err, title)
  return url
 @staticmethod
 def VVDRHC(url):
  path, err = FFSgzY(url + "version", "ajpanel_tmp.ver", timeout=2)
  if path and fileExists(path):
   txt  = FFWaDF(path)
   txt  = txt.replace(" ", "")
   span = iSearch(r"version\s*\=\s*v*(.+)", txt, IGNORECASE)
   if span:
    webVer = span.group(1)
    curVer = VVy0i9.lstrip("v").lstrip("V")
    if not curVer == webVer:
     cmd = "printf '%s\n%s\n' | sort -V" % (curVer, webVer)
     list = FF5Oes(cmd)
     if list and curVer == list[0]:
      return "v" + webVer
  return ""
class CCRLh1(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFbmPq(VVDZov, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVor0l
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FF9Cql(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVl3WM("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVl3WM("\c00888888", i) + sp + "GREY\n"
   txt += self.VVl3WM("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVl3WM("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVl3WM("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVl3WM("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVl3WM("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVl3WM("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVl3WM("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVl3WM("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVl3WM("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVl3WM("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVFd70 ,
   "green"   : self.VVFd70 ,
   "left"   : self.VVTvlD ,
   "right"   : self.VVrNqN ,
   "cancel"  : self.close
  }, -1)
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  self.VVp4xd()
 def VVFd70(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFJWhD(self, self.VVt2Ua, "Change to : %s" % txt, title=self.Title)
 def VVt2Ua(self):
  CFG.mixedColorScheme.setValue(self.cursorPos)
  CFG.mixedColorScheme.save()
  configfile.save()
  global VVor0l
  VVor0l = self.cursorPos
  self.VVQAJs()
  self.close()
 def VVTvlD(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVp4xd()
 def VVrNqN(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVp4xd()
 def VVp4xd(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVl3WM(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVRG9q(color):
  if VVWvE3: return "\\" + color
  else    : return ""
 @staticmethod
 def VVQAJs():
  global VVaVAY, VVQDXE, VVUq52, VVpKeT, VVY5Zb, VVhTxz, VVx2Y8, VVWvE3, COLOR_CONS_BRIGHT_YELLOW, VVpg8I, VVXXzX, VVNLkI, VVjMps
  VVjMps   = CCRLh1.VVl3WM("\c00FFFFFF", VVor0l)
  VVQDXE    = CCRLh1.VVl3WM("\c00888888", VVor0l)
  VVaVAY  = CCRLh1.VVl3WM("\c005A5A5A", VVor0l)
  VVhTxz    = CCRLh1.VVl3WM("\c00FF0000", VVor0l)
  VVUq52   = CCRLh1.VVl3WM("\c00FF5000", VVor0l)
  VVWvE3   = CCRLh1.VVl3WM("\c00FFFF00", VVor0l)
  COLOR_CONS_BRIGHT_YELLOW = CCRLh1.VVl3WM("\c00FFFFAA", VVor0l)
  VVx2Y8   = CCRLh1.VVl3WM("\c0000FF00", VVor0l)
  VVY5Zb    = CCRLh1.VVl3WM("\c000066FF", VVor0l)
  VVpg8I    = CCRLh1.VVl3WM("\c0000FFFF", VVor0l)
  VVXXzX  = CCRLh1.VVl3WM("\c00DSFFFF", VVor0l)  #
  VVNLkI   = CCRLh1.VVl3WM("\c00FA55E7", VVor0l)
  VVpKeT    = CCRLh1.VVl3WM("\c00FF8F5F", VVor0l)
CCRLh1.VVQAJs()
class CCV26k(Screen):
 def __init__(self, session, path, VV2ASm):
  self.skin, self.skinParam = FFbmPq(VVDouV, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVVy9Z   = path
  self.VVVRLA   = ""
  self.VVwbGZ   = ""
  self.VV2ASm    = VV2ASm
  self.VVwuiv    = ""
  self.VV41DS  = ""
  self.VVgSNp    = False
  self.VVHWcX  = False
  self.postInstAcion   = 0
  self.VVNLsb  = "enigma2-plugin-extensions"
  self.VV3UDK  = "enigma2-plugin-systemplugins"
  self.VVYSnO = "enigma2"
  self.VVNnDM  = 0
  self.VVNIFT  = 1
  self.VVowMk  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVzX6u = "DEBIAN"
  else        : self.VVzX6u = "CONTROL"
  self.controlPath = self.Path + self.VVzX6u
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VV2ASm:
   self.packageExt  = ".deb"
   self.VV5tqg  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VV5tqg  = "#11001020"
  FF9Cql(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFCpCt(self["keyRed"] , "Create")
  FFCpCt(self["keyGreen"] , "Post Install")
  FFCpCt(self["keyYellow"], "Installation Path")
  FFCpCt(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVm4zd  ,
   "green"   : self.VVQZJS ,
   "yellow"  : self.VVzdYh  ,
   "blue"   : self.VVMq4e  ,
   "cancel"  : self.VVBFS4
  }, -1)
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FF4l2q(self)
  if self.VV5tqg:
   FF3luO(self["myBody"], self.VV5tqg)
   FF3luO(self["myLabel"], self.VV5tqg)
  self.VVtFTL(True)
  self.VVkdxs(True)
 def VVkdxs(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVMOci()
  if isFirstTime:
   if   package.startswith(self.VVNLsb) : self.VVVy9Z = VVMMWP + self.VVwuiv + "/"
   elif package.startswith(self.VV3UDK) : self.VVVy9Z = VVpZJm + self.VVwuiv + "/"
   else            : self.VVVy9Z = self.Path
  if self.VVgSNp : myColor = VVpKeT
  else    : myColor = VVjMps
  txt  = ""
  txt += "Source Path\t: %s\n" % FF2tuT(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FF2tuT(self.VVVy9Z, VVWvE3)
  if self.VVwbGZ : txt += "Package File\t: %s\n" % FF2tuT(self.VVwbGZ, VVQDXE)
  elif errTxt   : txt += "Warning\t: %s\n"  % FF2tuT("Check Control File fields : %s" % errTxt, VVUq52)
  if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FF2tuT("Restart GUI", VVpKeT)
  elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FF2tuT("Reboot Device", VVpKeT)
  else      : act = "No action."
  txt += "\n%s\t: %s\n" % (FF2tuT("Post Install", VVx2Y8), act)
  if not errTxt and VVUq52 in controlInfo:
   txt += "Warning\t: %s\n" % FF2tuT("Errors in control file may affect the result package.", VVUq52)
  txt += "\nControl File\t: %s\n" % FF2tuT(self.controlFile, VVQDXE)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVQZJS(self):
  VVJ4VL = []
  VVJ4VL.append(("No Action"    , "noAction"  ))
  VVJ4VL.append(("Restart GUI"    , "VVyEiS"  ))
  VVJ4VL.append(("Reboot Device"   , "rebootDev"  ))
  FFdrYz(self, self.VVz4ca, title="Package Installation Option (after completing installation)", VVJ4VL=VVJ4VL)
 def VVz4ca(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVyEiS"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVtFTL(False)
   self.VVkdxs()
 def VVzdYh(self):
  rootPath = FF2tuT("/%s/" % self.VVwuiv, VVaVAY)
  VVJ4VL = []
  VVJ4VL.append(("Current Path"        , "toCurrent"  ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Extension Path"       , "toExtensions" ))
  VVJ4VL.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVJ4VL.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFdrYz(self, self.VV2U3x, title="Installation Path", VVJ4VL=VVJ4VL)
 def VV2U3x(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVaZFl(FFA44u(self.Path, True))
   elif item == "toExtensions"  : self.VVaZFl(VVMMWP)
   elif item == "toSystemPlugins" : self.VVaZFl(VVpZJm)
   elif item == "toRootPath"  : self.VVaZFl("/")
   elif item == "toRoot"   : self.VVaZFl("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVXYFr, boundFunction(CCsPG3, mode=CCsPG3.VVHqWs, VV0Jhk=VVmnJB))
 def VVXYFr(self, path):
  if len(path) > 0:
   self.VVaZFl(path)
 def VVaZFl(self, parent, withPackageName=True):
  if withPackageName : self.VVVy9Z = parent + self.VVwuiv + "/"
  else    : self.VVVy9Z = "/"
  mode = self.VVcFYY()
  os.system("sed -i '/Package/c\Package: %s' %s" % (self.VVOQ5j(mode), self.controlFile))
  self.VVkdxs()
 def VVMq4e(self):
  if fileExists(self.controlFile):
   lines = FFHvYZ(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFIilI(self, self.VVlPXW, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFBAp7(self, "Version not found or incorrectly set !")
  else:
   FFhMRQ(self, self.controlFile)
 def VVlPXW(self, VVVjkg):
  if VVVjkg:
   version, color = self.VVp8q0(VVVjkg, False)
   if color == VVpg8I:
    os.system("sed -i '/Version:/c\Version: %s' %s" % (VVVjkg, self.controlFile))
    self.VVkdxs()
   else:
    FFBAp7(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVBFS4(self):
  if self.newControlPath:
   if self.VVgSNp:
    self.VVT3Tt()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FF2tuT(self.newControlPath, VVQDXE)
    txt += FF2tuT("Do you want to keep these files ?", VVWvE3)
    FFJWhD(self, self.close, txt, callBack_No=self.VVT3Tt, title="Create Package", VVIDtV=True)
  else:
   self.close()
 def VVT3Tt(self):
  os.system(FFps7R("rm -r '%s'" % self.newControlPath))
  self.close()
 def VVOQ5j(self, mode):
  if   mode == self.VVNIFT : prefix = self.VVNLsb
  elif mode == self.VVowMk : prefix = self.VV3UDK
  else        : prefix = self.VVYSnO
  return prefix + "-" + self.VV41DS
 def VVcFYY(self):
  if   self.VVVy9Z.startswith(VVMMWP) : return self.VVNIFT
  elif self.VVVy9Z.startswith(VVpZJm) : return self.VVowMk
  else            : return self.VVNnDM
 def VVtFTL(self, isFirstTime):
  self.VVwuiv   = os.path.basename(os.path.normpath(self.Path))
  self.VVwuiv   = "_".join(self.VVwuiv.split())
  self.VV41DS = self.VVwuiv.lower()
  self.VVgSNp = self.VV41DS == VVlvoG.lower()
  if self.VVgSNp and self.VV41DS.endswith("ajpan"):
   self.VV41DS += "el"
  if self.VVgSNp : self.VVVRLA = VVmnJB
  else    : self.VVVRLA = CFG.packageOutputPath.getValue()
  self.VVVRLA = FF5gdy(self.VVVRLA)
  if not pathExists(self.controlPath):
   os.system(FFps7R("mkdir '%s'" % self.controlPath))
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  if self.VVgSNp : t = PLUGIN_NAME
  else    : t = self.VVwuiv
  self.VVkItH(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  myPath = VV3v04.rstrip("/")
  rmCmd  = "rm -rf '%s'  > /dev/null 2>&1\n" % myPath
  rmCmd += "rm -rf '.%s' > /dev/null 2>&1\n" % myPath
  if self.VVgSNp : txt = rmCmd
  else    : txt = "echo 'Package removed.'\n"
  self.VVkItH(self.postrmFile, txt)
  if self.VVgSNp:
   myOldPath = myPath + "el"
   txt = "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVy0i9)
   self.VVkItH(self.preinstFile, txt)
  else:
   self.VVkItH(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVwuiv)
  mode = self.VVcFYY()
  if isFirstTime and not mode == self.VVNnDM:
   self.postInstAcion = 1
  sep  = "echo '%s'\n" % VVlhhY
  txt  = sep
  if self.postInstAcion == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl > /dev/null 2>&1; then sleep 2; systemctl restart enigma2; else init 4; sleep 4; init 3; fi\n"
  elif self.postInstAcion == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  self.VVkItH(self.postinstFile, txt, VVKfUk=True)
  os.system(FFps7R("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile)))
  if not fileExists(self.controlFile):
   if self.VVgSNp : version, descripton, maintainer = VVy0i9 , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVwuiv , self.VVwuiv
   txt = ""
   txt += "Package: %s\n"  % self.VVOQ5j(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
 def VVkItH(self, path, lines, VVKfUk=False):
  if not fileExists(path) or VVKfUk:
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0")
 def VVMOci(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFHvYZ(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
     if key == "Description" and key.istitle():
      isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FF2tuT(line, VVUq52)
     elif not line.startswith(" ")    : line = FF2tuT(line, VVUq52)
     else          : line = FF2tuT(line, VVpg8I)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVpg8I
   else   : color = VVUq52
   descr = FF2tuT(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVUq52
     elif line.startswith((" ", "\t")) : color = VVUq52
     elif line.startswith("#")   : color = VVQDXE
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVp8q0(val, True)
      elif key == "Version"  : version, color = self.VVp8q0(val, False)
      elif key == "Maintainer" : maint  , color = val, VVpg8I
      elif key == "Architecture" : arch  , color = val, VVpg8I
      else:
       color = VVpg8I
      if not key == "OE" and not key.istitle():
       color = VVUq52
     else:
      color = VVpKeT
     txt += FF2tuT(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVwbGZ = self.VVVRLA + packageName
   self.VVHWcX = True
   errTxt = ""
  else:
   self.VVwbGZ  = ""
   self.VVHWcX = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVp8q0(self, val, isPackage):
  if   isPackage : pattern = "^[a-z0-9+-.]*$"
  else   : pattern = "^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVpg8I
  else          : return val, VVUq52
 def VVm4zd(self):
  if not self.VVHWcX:
   FFBAp7(self, "Please fix Control File errors first.")
   return
  if self.VV2ASm: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFA44u(self.VVVy9Z, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVwuiv
  symlinkTo  = FFaBTr(self.Path)
  dataDir   = self.VVVy9Z.rstrip("/")
  removePorjDir = FFps7R("rm -r '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFps7R("rm -f '%s'" % self.VVwbGZ) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FF65DH()
  if self.VV2ASm:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFPsnd("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVgSNp:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVVy9Z == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVzX6u)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Colud not create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVwbGZ, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVwbGZ
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVwbGZ, FFOCvV(result  , VVx2Y8))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVVy9Z, FFOCvV(instPath, VVpg8I))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFOCvV(failed, VVUq52))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFKyuP(self, cmd)
class CCsPG3(Screen):
 VVU3MM   = 0
 VVHqWs  = 1
 VVlZHt = 20
 VVwvyM  = None
 def __init__(self, session, VV0Jhk="/", mode=VVU3MM, VVlM9M="Select", VVwZKv=30, gotoMovie=False):
  self.skin, self.skinParam = FFbmPq(VVXAn9, 1400, 920, 30, 40, 20, "#22001111", "#22000000", 30, barHeight=40, topRightBtns=2)
  self.session   = session
  FF9Cql(self)
  FFCpCt(self["keyRed"] , "Exit")
  FFCpCt(self["keyBlue"], "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVlM9M = VVlM9M
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  CCsPG3.VVwvyM = self
  if   self.gotoMovie        : VVmMFw, self.VV0Jhk = True , CCsPG3.VVKA14(self)[1] or "/"
  elif self.mode == self.VVU3MM  : VVmMFw, self.VV0Jhk = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVHqWs : VVmMFw, self.VV0Jhk = False, VV0Jhk
  else           : VVmMFw, self.VV0Jhk = True , VV0Jhk
  self.VV0Jhk = FF5gdy(self.VV0Jhk)
  self["myMenu"] = CCmS9C(  directory   = "/"
         , VVmMFw   = VVmMFw
         , VVZbp3 = True
         , VVX2SU   = self.skinParam["width"]
         , VVwZKv   = self.skinParam["bodyFontSize"]
         , VVkqvP  = self.skinParam["bodyLineH"]
         , VVzQhD  = self.skinParam["bodyColor"])
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"    : self.VVFd70      ,
   "red"    : self.VVcE4z     ,
   "green"    : self.VVHVKp    ,
   "yellow"   : self.VV6aeq   ,
   "blue"    : self.VV6C5P   ,
   "menu"    : self.VVxg2H    ,
   "info"    : self.VV3YWS    ,
   "cancel"   : self.VVfxIN     ,
   "pageUp"   : self.VVfxIN     ,
   "chanUp"   : self.VVfxIN
  }, -1)
  FFYrbe(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVxnpl)
 def onExit(self):
  CCsPG3.VVwvyM = None
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVxnpl)
  FFGuuf(self)
  FFYI0q(self["myMenu"], bg="#06003333")
  FF4l2q(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode == self.VVHqWs:
   FFCpCt(self["keyGreen"], self.VVlM9M)
   color = "#22000022"
   FF3luO(self["myBody"], color)
   FF3luO(self["myMenu"], color)
   color = "#22220000"
   FF3luO(self["myTitle"], color)
   FF3luO(self["myBar"], color)
  self.VVxnpl()
  if self.VVW87a(self.VV0Jhk) > self.bigDirSize:
   FFtMdo(self, "Changing directory...")
   FFOFIS(self.VVwE0o)
  else:
   self.VVwE0o()
 def VVwE0o(self):
  self["myMenu"].VVbgQJ(self.VV0Jhk)
  if self.gotoMovie:
   self.VVbwom(chDir=False)
 def VVSgIu(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVTsrt(self):
  self["myMenu"].refresh()
  FFVuPM()
 def VVW87a(self, folder):
  totalItems = 0
  if pathExists(folder):
   try:
    totalItems = len(os.listdir(folder))
   except:
    pass
  return totalItems
 def VVFd70(self):
  if self["myMenu"].VVmFFr():
   path = self.VVWibK(self.VVH9sb())
   if self.VVW87a(path) > self.bigDirSize:
    FFtMdo(self, "Changing directory...")
    FFOFIS(self.VVhwnX)
   else:
    self.VVhwnX()
  else:
   self.VVAHuT()
 def VVhwnX(self):
  self["myMenu"].descent()
  self.VVxnpl()
 def VVfxIN(self):
  if self["myMenu"].VV1NfB():
   self["myMenu"].moveToIndex(0)
   self.VVhwnX()
 def VVcE4z(self):
  if not FFTKsv(self):
   self.close("")
 def VVHVKp(self):
  if self.mode == self.VVHqWs:
   path = self.VVWibK(self.VVH9sb())
   self.close(path)
 def VV3YWS(self):
  FFobhC(self, self.VVZSPW, title="Calculating size ...")
 def VVZSPW(self):
  path = self.VVWibK(self.VVH9sb())
  param = self.VVfJ0q(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFDup1("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCsPG3.VVFx8W(path)
     freeSize = CCsPG3.VVWrl8(path)
     size = totSize - freeSize
     totSize  = CCsPG3.VVekPE(totSize)
     freeSize = CCsPG3.VVekPE(freeSize)
    else:
     size = FFDup1("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
     size = int(size)
   usedSize = CCsPG3.VVekPE(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FF2tuT(pathTxt, VVpKeT) + "\n"
   if slBroken : fileTime = self.VV7hUd(path)
   else  : fileTime = self.VVKkwh(path)
   def VVu5M6(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVu5M6("Path"    , pathTxt)
   txt += VVu5M6("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVu5M6("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVu5M6("Total Size"   , "%s" % totSize)
    txt += VVu5M6("Used Size"   , "%s" % usedSize)
    txt += VVu5M6("Free Size"   , "%s" % freeSize)
   else:
    txt += VVu5M6("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVu5M6("Owner"    , owner)
   txt += VVu5M6("Group"    , group)
   txt += VVu5M6("Perm. (User)"  , permUser)
   txt += VVu5M6("Perm. (Group)"  , permGroup)
   txt += VVu5M6("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVu5M6("Perm. (Ext.)" , permExtra)
   txt += VVu5M6("iNode"    , iNode)
   txt += VVu5M6("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (VVlhhY, VVlhhY)
    txt += hLinkedFiles
   txt += self.VVaMYb(path)
  else:
   FFBAp7(self, "Cannot access information !")
  if len(txt) > 0:
   FFzRpw(self, txt)
 def VVfJ0q(self, path):
  path = path.strip()
  path = FFaBTr(path)
  result = FFDup1("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVwFSk(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVwFSk(perm, 1, 4)
   permGroup = VVwFSk(perm, 4, 7)
   permOther = VVwFSk(perm, 7, 10)
   permExtra = VVwFSk(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFi677("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVaMYb(self, path):
  txt  = ""
  res  = FFDup1("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FF2tuT("File Attributes:", VVNLkI), txt)
  return txt
 def VVKkwh(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FF78kj(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FF78kj(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FF78kj(os.path.getctime(path))
  return txt
 def VV7hUd(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFDup1("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFDup1("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFDup1("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVWibK(self, currentSel):
  currentDir  = self["myMenu"].VV1NfB()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVmFFr():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVH9sb(self):
  return self["myMenu"].getSelection()[0]
 def VVxnpl(self):
  FFtMdo(self)
  path = self.VVWibK(self.VVH9sb())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  VV1rg6 = self.VVzoWe()
  if VV1rg6 and len(VV1rg6) > 0 : self["keyBlue"].show()
  else       : self["keyBlue"].hide()
  self.VViUNN(path)
  if self.mode == self.VVU3MM and len(path) > 0 : self["keyMenu"].show()
  else              : self["keyMenu"].hide()
 def VViUNN(self, path):
  if os.path.isdir(path):
   self["keyYellow"].show()
   if not self.VVgrZn(path):
    self["keyYellow"].setText("Add bookmark")
    return 1
   else:
    self["keyYellow"].setText("Del. bookmark")
    return -1
  else:
   self["keyYellow"].hide()
   return 0
 def VVxg2H(self):
  if self.mode == self.VVU3MM:
   path  = self.VVWibK(self.VVH9sb())
   isDir  = os.path.isdir(path)
   VVJ4VL = []
   VVJ4VL.append(   ("Properties"          , "properties"    ))
   if isDir:
    sepShown = False
    if not self.VVqgRz(path):
     sepShown = True
     VVJ4VL.append(VV1dpw)
     VVJ4VL.append( (VVpKeT + "Archiving / Packaging"      , "VV8C9i"  ))
    if self.VVQWTf(path):
     if not sepShown:
      VVJ4VL.append(VV1dpw)
     VVJ4VL.append( (VVpKeT + "Read Backup information"     , "VVXcZM"  ))
     VVJ4VL.append( (VVpKeT + "Compress Octagon Image (to zip File)"  , "VVeVWg" ))
   elif os.path.isfile(path):
    selFile = self.VVH9sb()
    txt = ""
    if   selFile.endswith((".tar", ".tar.gz", ".tar.bz2", "tar.xz", ".zip", ".rar")) : VVJ4VL.extend(self.VVXWjX(path, True))
    elif selFile.endswith(".bootlogo.tar.gz")           : txt = "Replace Bootloader"
    elif selFile.endswith((".ipk", ".deb"))            : txt = "Package Tools"
    elif selFile.endswith((".jpg", ".jpeg", ".jpe", ".png", ".bmp"))     : txt = "View Picture"
    elif selFile.endswith(".sh")              : VVJ4VL.extend(self.VVQgw2(True))
    elif selFile.endswith(".m3u")              : VVJ4VL.extend(self.VVz0iL(True))
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not FF9Lu1(path):
     VVJ4VL.append(VV1dpw)
     VVJ4VL.append((VVpKeT + "View"     , "textView_def" ))
     VVJ4VL.append((VVpKeT + "View (Select Encoder)" , "textView_enc" ))
     VVJ4VL.append((VVpKeT + "Edit"     , "text_Edit"  ))
    if len(txt) > 0:
     VVJ4VL.append(VV1dpw)
     VVJ4VL.append(   (VVpKeT + txt      , "VVAHuT"  ))
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append(     ("Create SymLink"       , "VVeEtU" ))
   if not self.VVqgRz(path):
    VVJ4VL.append(   ("Rename"          , "VV3YvK" ))
    VVJ4VL.append(   ("Copy"           , "copyFileOrDir" ))
    VVJ4VL.append(   ("Move"           , "moveFileOrDir" ))
    VVJ4VL.append(   ("DELETE"          , "VVzMcl" ))
    if fileExists(path):
     VVJ4VL.append(VV1dpw)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVJ4VL.append( (chmodTxt + "644)"       , "chmod644"  ))
     if show755 : VVJ4VL.append( (chmodTxt + "755)"       , "chmod755"  ))
     if show777 : VVJ4VL.append( (chmodTxt + "777)"       , "chmod777"  ))
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append(    ("Create New File (in current directory)"  , "createNewFile" ))
   VVJ4VL.append(    ("Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCsPG3.VVKA14(self)
   if fPath:
    VVJ4VL.append(VV1dpw)
    VVJ4VL.append(   (VVWvE3 + "Go to current movie"  , "VVbwom"))
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append(    ("Set current directory as \"Startup Path\"" , "VV76lj" ))
   FFdrYz(self, self.VV2dda, title="Options", VVJ4VL=VVJ4VL)
 def VV2dda(self, item=None):
  if self.mode == self.VVU3MM:
   if item is not None:
    path = self.VVWibK(self.VVH9sb())
    selFile = self.VVH9sb()
    if   item == "properties"    : self.VV3YWS()
    elif item == "VV8C9i"  : self.VV8C9i(path)
    elif item == "VVXcZM"  : self.VVXcZM(path)
    elif item == "VVeVWg" : self.VVeVWg(path)
    elif item.startswith("extract_")  : self.VVdjMt(path, selFile, item)
    elif item.startswith("script_")   : self.VVDyNY(path, selFile, item)
    elif item.startswith("m3u_")   : self.VVz7D0Item_m3u(path, selFile, item)
    elif item.startswith("textView_def") : FFfN74(self, path)
    elif item.startswith("textView_enc") : self.VVtDne(path)
    elif item.startswith("text_Edit")  : CC0hs4(self, path)
    elif item == "chmod644"     : self.VVmj3C(path, selFile, "644")
    elif item == "chmod755"     : self.VVmj3C(path, selFile, "755")
    elif item == "chmod777"     : self.VVmj3C(path, selFile, "777")
    elif item == "VVeEtU"   : self.VVeEtU(path, selFile)
    elif item == "VV3YvK"   : self.VV3YvK(path, selFile)
    elif item == "copyFileOrDir"   : self.VVyz4f(path, selFile, False)
    elif item == "moveFileOrDir"   : self.VVyz4f(path, selFile, True)
    elif item == "VVzMcl"   : self.VVzMcl(path, selFile)
    elif item == "createNewFile"   : self.VVbNpp(path, True)
    elif item == "createNewDir"    : self.VVbNpp(path, False)
    elif item == "VVbwom"   : self.VVbwom()
    elif item == "VV76lj"   : self.VV76lj(path)
    elif item == "VVAHuT"    : self.VVAHuT()
    else         : self.close()
 def VVAHuT(self):
  selFile = self.VVH9sb()
  path  = self.VVWibK(selFile)
  if os.path.isfile(path):
   VVAIfv = []
   category = self["myMenu"].VViHUD(path)
   if   selFile.endswith(".bootlogo.tar.gz")    : self.VV1xiH(selFile, "Replace Bootloader ?", "mount -rw /boot -o remount", "sleep 3","tar -xzvf '" + path + "' -C /", "mount -ro /boot -o remount")
   elif category == "pic"         : CCv4E7.VV2MIq(self, path)
   elif category == "txt"         : FFfN74(self, path)
   elif category in ("tar", "zip", "rar")     : self.VVvAeG(path, selFile)
   elif category == "scr"         : self.VVuuOp(path, selFile)
   elif category == "m3u"         : self.VVeBKI(path, selFile)
   elif category in ("ipk", "deb")       : self.VVbu2a(path, selFile)
   elif category == "mus"         : self.VVw2yu(self, path)
   elif category == "mov"         : self.VVw2yu(self, path)
   elif not FF9Lu1(path)        : FFfN74(self, path)
 def VV6aeq(self):
  path = self.VVWibK(self.VVH9sb())
  action = self.VViUNN(path)
  if action == 1:
   self.VVxvJI(path)
   FFtMdo(self, "Added", 500)
  elif action == -1:
   self.VVDEyQ(path)
   FFtMdo(self, "Removed", 500)
  self.VViUNN(path)
 def VVxvJI(self, path):
  VV1rg6 = self.VVzoWe()
  if not VV1rg6:
   VV1rg6 = []
  if len(VV1rg6) >= self.VVlZHt:
   FFBAp7(SELF, "Max bookmarks reached (max=%d)." % self.VVlZHt)
  elif not path in VV1rg6:
   VV1rg6 = [path] + VV1rg6
   self.VVow71(VV1rg6)
 def VV6C5P(self):
  VV1rg6 = self.VVzoWe()
  if VV1rg6:
   newList = []
   for line in VV1rg6:
    newList.append((line, line))
   VVzYgB  = ("Delete"  , self.VV2KKp )
   VVx8rq = ("Move Up"   , self.VVDqRC )
   VVfXyU  = ("Move Down" , self.VVxdh5 )
   self.bookmarkMenu = FFdrYz(self, self.VVLHQ0, title="Bookmarks", VVJ4VL=newList, VVzYgB=VVzYgB, VVx8rq=VVx8rq, VVfXyU=VVfXyU)
 def VV2KKp(self, VVH9sbObj, path):
  if self.bookmarkMenu:
   VV1rg6 = self.VVDEyQ(path)
   self.bookmarkMenu.VV9q0E(VV1rg6)
 def VVDqRC(self, VVH9sbObj, path):
  if self.bookmarkMenu:
   VV1rg6 = self.bookmarkMenu.VVAGtY(True)
   if VV1rg6:
    self.VVow71(VV1rg6)
 def VVxdh5(self, VVH9sbObj, path):
  if self.bookmarkMenu:
   VV1rg6 = self.bookmarkMenu.VVAGtY(False)
   if VV1rg6:
    self.VVow71(VV1rg6)
 def VVLHQ0(self, folder=None):
  if folder:
   folder = FF5gdy(folder)
   self["myMenu"].VVbgQJ(folder)
   self["myMenu"].moveToIndex(0)
  self.VVxnpl()
 def VVzoWe(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return None
 def VVgrZn(self, path):
  VV1rg6 = self.VVzoWe()
  if VV1rg6 and path in VV1rg6:
   return True
  else:
   return False
 def VVwFTW(self):
  if VVzoWe():
   return True
  else:
   return False
 def VVow71(self, VV1rg6):
  line = ",".join(VV1rg6)
  CFG.browserBookmarks.setValue(line)
  CFG.browserBookmarks.save()
  configfile.save()
 def VVDEyQ(self, path):
  VV1rg6 = self.VVzoWe()
  if VV1rg6:
   while path in VV1rg6:
    VV1rg6.remove(path)
   self.VVow71(VV1rg6)
   return VV1rg6
 def VVbwom(self, chDir=True):
  fPath, fDir, fName = CCsPG3.VVKA14(self)
  if fPath:
   if chDir:
    self["myMenu"].VVbgQJ(fDir)
   for ndx, item in enumerate(self["myMenu"].list):
    colNum = 1
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFtMdo(self, "Not found", 1000)
 def VV76lj(self, path):
  if not os.path.isdir(path):
   path = FFA44u(path, True)
  CFG.browserStartPath.setValue(path)
  CFG.browserStartPath.save()
  configfile.save()
 def VV1xiH(self, selFile, VVoqcK, command):
  FFJWhD(self, boundFunction(FFKyuP, self, command, VVrZnU=self.VVTsrt), "%s\n\n%s" % (VVoqcK, selFile))
 def VVXWjX(self, path, calledFromMenu):
  destPath = self.VVSA3t(path)
  lastPart = os.path.basename(os.path.normpath(destPath))
  VVJ4VL = []
  if calledFromMenu:
   VVJ4VL.append(VV1dpw)
   color = VVpKeT
  else:
   color = ""
  VVJ4VL.append((color + "List Archived Files"          , "extract_listFiles" ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
  VVJ4VL.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
  VVJ4VL.append((color + "Extract Here"            , "extract_here"  ))
  if VV5KEQ and path.endswith(".tar.gz"):
   VVJ4VL.append(VV1dpw)
   VVJ4VL.append((color + 'Convert to ".ipk" Package' , "VVaEfR"  ))
   VVJ4VL.append((color + 'Convert to ".deb" Package' , "VVx3J7"  ))
  return VVJ4VL
 def VVvAeG(self, path, selFile):
  FFdrYz(self, boundFunction(self.VVdjMt, path, selFile), title="Compressed File Options", VVJ4VL=self.VVXWjX(path, False))
 def VVdjMt(self, path, selFile, item=None):
  if item is not None:
   parent  = FFA44u(path, False)
   destPath = self.VVSA3t(path)
   lastPart = os.path.basename(os.path.normpath(destPath))
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % VVlhhY
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFPsnd("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFPsnd("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (VVlhhY, VVlhhY)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFa7xk(self, cmd)
   elif path.endswith(".zip"):
    self.VVywNz(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif path.endswith(".rar"):
    self.VVGB6L(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFps7R("mkdir '%s'"  % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then ' % lastPart
    cmd += " tar -xvf '%s' -C %s;" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VV1xiH(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VV1xiH(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here" :
    parent = FFA44u(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VV1xiH(selFile, "Extract Here ?"      , cmd)
   elif item == "VVaEfR" : self.VVaEfR(path)
   elif item == "VVx3J7" : self.VVx3J7(path)
 def VVSA3t(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVywNz(self, item, path, parent, destPath, VVoqcK):
  FFJWhD(self, boundFunction(self.VVOSeX, item, path, parent, destPath), VVoqcK)
 def VVOSeX(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVlhhY
  cmd  = FFPsnd("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFOCvV(destPath, VVx2Y8))
  cmd +=   sep
  cmd += "fi;"
  FFq1pL(self, cmd, VVrZnU=self.VVTsrt)
 def VVGB6L(self, item, path, parent, destPath, VVoqcK):
  FFJWhD(self, boundFunction(self.VV43ow, item, path, parent, destPath), VVoqcK)
 def VV43ow(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FF5gdy(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % VVlhhY
  cmd  = FFPsnd("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFOCvV(destPath, VVx2Y8))
  cmd +=   sep
  cmd += "fi;"
  FFq1pL(self, cmd, VVrZnU=self.VVTsrt)
 def VVQgw2(self, addSep=False):
  VVJ4VL = []
  if addSep:
   VVJ4VL.append(VV1dpw)
  VVJ4VL.append((VVpKeT + "View Script File"  , "script_View"  ))
  VVJ4VL.append((VVpKeT + "Execute Script File" , "script_Execute" ))
  VVJ4VL.append((VVpKeT + "Edit"     , "script_Edit" ))
  return VVJ4VL
 def VVuuOp(self, path, selFile):
  FFdrYz(self, boundFunction(self.VVDyNY, path, selFile), title="Script File Options", VVJ4VL=self.VVQgw2())
 def VVDyNY(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFfN74(self, path)
   elif item == "script_Execute" : self.VV1xiH(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CC0hs4(self, path)
 def VVz0iL(self, addSep=False):
  VVJ4VL = []
  if addSep:
   VVJ4VL.append(VV1dpw)
  VVJ4VL.append((VVpKeT + "Browse IPTV Channels"  , "m3u_Browse" ))
  VVJ4VL.append((VVpKeT + "Edit"      , "m3u_Edit" ))
  VVJ4VL.append((VVpKeT + "View"      , "m3u_View" ))
  return VVJ4VL
 def VVeBKI(self, path, selFile):
  FFdrYz(self, boundFunction(self.VVz7D0Item_m3u, path, selFile), title="M3U/M3U8 File Options", VVJ4VL=self.VVz0iL())
 def VVz7D0Item_m3u(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFobhC(self, boundFunction(self.session.open, CCmV60, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CC0hs4(self, path)
   elif item == "m3u_View"  : FFfN74(self, path)
 def VVtDne(self, path):
  if fileExists(path) : FFobhC(self, boundFunction(CCaMcm.VVhF4K, self, path, boundFunction(self.VVgMLW, path), defEnc=None), title="Loading Codecs ...", clearMsg=False)
  else    : FFhMRQ(self, path)
 def VVgMLW(self, path, item=None):
  if item:
   FFfN74(self, path, encLst=item)
 def VVmj3C(self, path, selFile, newChmod):
  FFJWhD(self, boundFunction(self.VVlQbm, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVlQbm(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VVFyCE)
  result = FFDup1(cmd)
  if result == "Successful" : FFSzHX(self, result)
  else      : FFBAp7(self, result)
 def VVeEtU(self, path, selFile):
  parent = FFA44u(path, False)
  self.session.openWithCallback(self.VVbb2w, boundFunction(CCsPG3, mode=CCsPG3.VVHqWs, VV0Jhk=parent, VVlM9M="Create Symlink here"))
 def VVbb2w(self, newPath):
  if len(newPath) > 0:
   target = self.VVWibK(self.VVH9sb())
   target = FFaBTr(target)
   linkName = os.path.basename(os.path.normpath(target))
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FF5gdy(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFBAp7(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFJWhD(self, boundFunction(self.VVlz9z, target, link), "Create Soft Link ?\n\n%s" % txt, VVIDtV=True)
 def VVlz9z(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VVFyCE)
  result = FFDup1(cmd)
  if result == "Successful" : FFSzHX(self, result)
  else      : FFBAp7(self, result)
 def VV3YvK(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  FFIilI(self, boundFunction(self.VVYdC5, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVYdC5(self, path, selFile, VVVjkg):
  if VVVjkg:
   parent = FFA44u(path, True)
   if os.path.isdir(path):
    path = FFaBTr(path)
   newName = parent + VVVjkg
   cmd = "mv '%s' '%s' %s" % (path, newName, VVFyCE)
   if VVVjkg:
    if selFile != VVVjkg:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFJWhD(self, boundFunction(self.VVdaUg, cmd), message, title="Rename file?")
    else:
     FFBAp7(self, "Cannot use same name!", title="Rename")
 def VVdaUg(self, cmd):
  result = FFDup1(cmd)
  if "Fail" in result:
   FFBAp7(self, result)
  self.VVTsrt()
 def VVyz4f(self, path, selFile, isMove):
  if isMove : VVlM9M = "Move to here"
  else  : VVlM9M = "Copy to here"
  parent = FFA44u(path, False)
  self.session.openWithCallback(boundFunction(self.VVN8Wd, isMove, path, selFile)
         , boundFunction(CCsPG3, mode=CCsPG3.VVHqWs, VV0Jhk=parent, VVlM9M=VVlM9M))
 def VVN8Wd(self, isMove, path, selFile, newPath):
  if len(newPath) > 0:
   lastPart = os.path.basename(os.path.normpath(path))
   if os.path.isdir(path):
    path = FFaBTr(path)
   newPath = FF5gdy(newPath)
   dest = newPath + lastPart
   if os.path.isdir(path) and os.path.isdir(dest):
    if isMove:
     FFBAp7(self, 'Same directory already exists:\n\n%s\n\n( Try to copy then delete the source )' % dest)
     return
    else:
     dest = newPath
   if isMove : action, cmd = "Move", "mv"
   else  : action, cmd = "Copy", "cp -rf"
   txt  = "%s\t: %s\n" % (action, lastPart)
   txt += "to\t: %s\n\n" % newPath
   if fileExists(dest) : txt += "%s (overwrite) ?" % action
   else    : txt += "%s now ?"   % action
   if not path == dest:
    cmd = "RES=$(%s '%s' '%s') && echo Successful || echo $RES" % (cmd, path, dest)
    FFJWhD(self, boundFunction(FF4pyg, self, cmd, VVrZnU=self.VVTsrt), txt, VVIDtV=True)
   else:
    FFBAp7(self, "Cannot %s to same directory !" % action.lower())
 def VVzMcl(self, path, fileName):
  path = FFaBTr(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFJWhD(self, boundFunction(self.VVfghA, path), "Delete %s ?\n\n%s" % (pathType, path))
 def VVfghA(self, path):
  opt = "-f"
  if os.path.isdir(path):
   opt = "-r"
  os.system("chattr -iR '%s' > /dev/null 2>&1; rm %s '%s'" % (path, opt, path))
  self.VVTsrt()
 def VVqgRz(self, path):
  if self["myMenu"].l.getCurrentSelectionIndex() == 0      : return True
  elif self["myMenu"].mountpoints and path in self["myMenu"].mountpoints : return True
  elif not VVgFen and path in [ "/DEBIAN/"
          , "/bin/"
          , "/boot/"
          , "/dev/"
          , "/etc/"
          , "/hdd/"
          , "/home/"
          , "/lib/"
          , "/media/"
          , "/mnt/"
          , "/network/"
          , "/proc/"
          , "/run/"
          , "/sbin/"
          , "/sys/"
          , "/tmp/"
          , "/usr/"
          , "/var/"]     : return True
  return False
 def VVbNpp(self, path, isFile):
  dirName = FF5gdy(os.path.dirname(path))
  if isFile : objName, VVVjkg = "File"  , self.edited_newFile
  else  : objName, VVVjkg = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFIilI(self, boundFunction(self.VVRza0, dirName, isFile, title), title=title, defaultText=VVVjkg, message="Enter %s Name:" % objName)
 def VVRza0(self, dirName, isFile, title, VVVjkg):
  if VVVjkg:
   if isFile : self.edited_newFile = VVVjkg
   else  : self.edited_newDir  = VVVjkg
   path = dirName + VVVjkg
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VVFyCE)
    else  : cmd = "mkdir '%s' %s" % (path, VVFyCE)
    result = FFDup1(cmd)
    if "Fail" in result:
     FFBAp7(self, result)
    self.VVTsrt()
   else:
    FFBAp7(self, "Name already exists !\n\n%s" % path, title)
 def VVbu2a(self, path, selFile):
  VVJ4VL = []
  VVJ4VL.append(("List Package Files"          , "VVwZsq"     ))
  VVJ4VL.append(("Package Information"          , "VVKEN6"     ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Install Package"           , "VVQhKw_CheckVersion" ))
  VVJ4VL.append(("Install Package (force reinstall)"      , "VVQhKw_ForceReinstall" ))
  VVJ4VL.append(("Install Package (force overwrite)"      , "VVQhKw_ForceOverwrite" ))
  VVJ4VL.append(("Install Package (force downgrade)"      , "VVQhKw_ForceDowngrade" ))
  VVJ4VL.append(("Install Package (ignore failed dependencies)"    , "VVQhKw_IgnoreDepends" ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Remove Related Package"         , "VVzc6j_ExistingPackage" ))
  VVJ4VL.append(("Remove Related Package (force remove)"     , "VVzc6j_ForceRemove"  ))
  VVJ4VL.append(("Remove Related Package (ignore failed dependencies)"  , "VVzc6j_IgnoreDepends" ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Extract Files"           , "VVZrbq"     ))
  VVJ4VL.append(("Unbuild Package"           , "VV66D3"     ))
  FFdrYz(self, boundFunction(self.VVMorg, path, selFile), VVJ4VL=VVJ4VL)
 def VVMorg(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVwZsq"      : self.VVwZsq(path, selFile)
   elif item == "VVKEN6"      : self.VVKEN6(path)
   elif item == "VVQhKw_CheckVersion"  : self.VVQhKw(path, selFile, VVSMBq     )
   elif item == "VVQhKw_ForceReinstall" : self.VVQhKw(path, selFile, VVJUEs )
   elif item == "VVQhKw_ForceOverwrite" : self.VVQhKw(path, selFile, VV1Ulm )
   elif item == "VVQhKw_ForceDowngrade" : self.VVQhKw(path, selFile, VVptud )
   elif item == "VVQhKw_IgnoreDepends" : self.VVQhKw(path, selFile, VV24AE )
   elif item == "VVzc6j_ExistingPackage" : self.VVzc6j(path, selFile, VVXgHo     )
   elif item == "VVzc6j_ForceRemove"  : self.VVzc6j(path, selFile, VVhvpp  )
   elif item == "VVzc6j_IgnoreDepends"  : self.VVzc6j(path, selFile, VVzzTf )
   elif item == "VVZrbq"     : self.VVZrbq(path, selFile)
   elif item == "VV66D3"     : self.VV66D3(path, selFile)
   else           : self.close()
 def VVwZsq(self, path, selFile):
  if FFosbb("ar") : cmd = "allOK='1';"
  else    : cmd  = FF65DH()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (VVlhhY, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (VVlhhY, VVlhhY)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFtWHX(self, cmd, VVrZnU=self.VVTsrt)
 def VVZrbq(self, path, selFile):
  lastPart = os.path.basename(os.path.normpath(path))
  dest  = FFA44u(path, True) + selFile[:-4]
  cmd  =  FF65DH()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFps7R("mkdir '%s'" % dest) + ";"
  cmd +=    FFps7R("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFOCvV(dest, VVx2Y8))
  cmd += "fi;"
  FFKyuP(self, cmd, VVrZnU=self.VVTsrt)
 def VV66D3(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VV9Xey = os.path.splitext(path)[0]
  else        : VV9Xey = path + "_"
  if path.endswith(".deb")   : VVzX6u = "DEBIAN"
  else        : VVzX6u = "CONTROL"
  cmd  = FF65DH()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -r '%s' %s;"   % (VV9Xey, FFp04w())
  cmd += "  mkdir '%s';"    % VV9Xey
  cmd += "  CONTPATH='%s/%s';"  % (VV9Xey, VVzX6u)
  cmd += "  mkdir $CONTPATH;"
  cmd += "  cd '%s';"     % VV9Xey
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f $FILE ] && tar -xzf $FILE -C '%s'      && rm -f $FILE;" % (VV9Xey, VV9Xey)
  cmd += "  FILE='%s/control.tar.gz'; [ -f $FILE ] && tar -xzf $FILE -C $CONTPATH && rm -f $FILE;" %  VV9Xey
  cmd += "  FILE='%s/data.tar.xz';    [ -f $FILE ] && tar -xJf $FILE -C '%s'      && rm -f $FILE;" % (VV9Xey, VV9Xey)
  cmd += "  FILE='%s/control.tar.xz'; [ -f $FILE ] && tar -xJf $FILE -C $CONTPATH && rm -f $FILE;" %  VV9Xey
  cmd += "  FILE='%s/debian-binary';  [ -f $FILE ]                                && rm -f $FILE;" %  VV9Xey
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (VV9Xey, FFOCvV(VV9Xey, VVx2Y8))
  cmd += "fi;"
  FFKyuP(self, cmd, VVrZnU=self.VVTsrt)
 def VVKEN6(self, path):
  listCmd  = FFgO5n(VVi1qq, "")
  infoCmd  = FFj0t1(VVhPIi , "")
  filesCmd = FFj0t1(VVv0Zt, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFv4kb(VVWvE3)
   notInst = "Package not installed."
   cmd  = FFAhCU("File Info", VVWvE3)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFAhCU("System Info", VVWvE3)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFOCvV(notInst, VVpKeT))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFAhCU("Related Files", VVWvE3)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFa7xk(self, cmd)
  else:
   FFhJ5k(self)
 def VVQhKw(self, path, selFile, cmdOpt):
  cmd = FFj0t1(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFJWhD(self, boundFunction(FFKyuP, self, cmd, VVrZnU=FFVuPM), "Install Package ?\n\n%s" % selFile)
  else:
   FFhJ5k(self)
 def VVzc6j(self, path, selFile, cmdOpt):
  listCmd  = FFgO5n(VVi1qq, "")
  infoCmd  = FFj0t1(VVhPIi, "")
  instRemCmd = FFj0t1(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFOCvV(errTxt, VVpKeT))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFOCvV(cannotTxt, VVpKeT))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFOCvV(tryTxt, VVpKeT))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFJWhD(self, boundFunction(FFKyuP, self, cmd, VVrZnU=FFVuPM), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFhJ5k(self)
 def VVaKUT(self, path):
  hostName = FFDup1("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVQWTf(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVaKUT(path)
  if fileExists(kernelFile) and fileExists(rootfsFile):
   return True
  else:
   return False
 def VV8C9i(self, path):
  Dir  = "Archive to "
  Path = "Archive (Preserve Path Structure) to "
  VVJ4VL = []
  VVJ4VL.append(("%s.tar"  % Dir   , "archDir_tar"   ))
  VVJ4VL.append(("%s.tar.gz" % Dir   , "archDir_tar_gz"  ))
  VVJ4VL.append(("%s.tar.xz" % Dir   , "archDir_tar_xz"  ))
  VVJ4VL.append(("%s.tar.bz2" % Dir   , "archDir_tar_bz2"  ))
  VVJ4VL.append(("%s.zip"  % Dir   , "archDir_zip"   ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("%s.tar"  % Path   , "archPath_tar"  ))
  VVJ4VL.append(("%s.tar.gz" % Path   , "archPath_tar_gz"  ))
  VVJ4VL.append(("%s.tar.xz" % Path   , "archPath_tar_xz"  ))
  VVJ4VL.append(("%s.tar.bz2" % Path   , "archPath_tar_bz2" ))
  VVJ4VL.append(("%s.zip"  % Path   , "archPath_zip"  ))
  VVJ4VL.append(VV1dpw)
  VVJ4VL.append(('Convert to ".ipk" Package' , "convertDirToIpk"  ))
  VVJ4VL.append(('Convert to ".deb" Package' , "convertDirToDeb"  ))
  FFdrYz(self, boundFunction(self.VVpcpl, path), VVJ4VL=VVJ4VL)
 def VVpcpl(self, path, item):
  if item is not None:
   if   item == "archDir_tar"    : self.VVKCXJ(path, ".tar"  , False)
   elif item == "archDir_tar_gz"   : self.VVKCXJ(path, ".tar.gz" , False)
   elif item == "archDir_tar_xz"   : self.VVKCXJ(path, ".tar.xz" , False)
   elif item == "archDir_tar_bz2"   : self.VVKCXJ(path, ".tar.bz2" , False)
   elif item == "archDir_zip"    : self.VVKCXJ(path, ".zip"  , False)
   elif item == "archPath_tar"    : self.VVKCXJ(path, ".tar"  , True)
   elif item == "archPath_tar_gz"   : self.VVKCXJ(path, ".tar.gz" , True)
   elif item == "archPath_tar_xz"   : self.VVKCXJ(path, ".tar.xz" , True)
   elif item == "archPath_tar_bz2"   : self.VVKCXJ(path, ".tar.bz2" , True)
   elif item == "archPath_zip"    : self.VVKCXJ(path, ".zip"  , True)
   elif item == "convertDirToIpk"   : self.VVYuXE(path, False)
   elif item == "convertDirToDeb"   : self.VVYuXE(path, True)
   else         : self.close()
 def VVYuXE(self, path, VV2ASm):
  self.session.openWithCallback(self.VVTsrt, boundFunction(CCV26k, path=path, VV2ASm=VV2ASm))
 def VVKCXJ(self, path, fileExt, preserveDirStruct):
  parent  = FFA44u(path, True)
  lastPart = os.path.basename(os.path.normpath(path))
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
   cmd   = ""
  else:
   targetDir = lastPart
   cmd   = "cd '%s';" % parent
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFPsnd("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFPsnd("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFPsnd("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = " %s %s %s;" % (archCmd, archFile, "-C / %s" % targetDir[1:])
   else              : archCmd = " %s %s %s;" % (archCmd, archFile, targetDir)
  else:
   archCmd = "%s ../%s *;" % (archCmd, archFile)
   archCmd = ("  cd '%s';" % path) + archCmd
  failed = "Process failed !"
  sep  = " echo -e '%s';" % VVlhhY
  cmd += toolCmd
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFps7R("rm -f '%s';" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';" % parent
  cmd +=   sep
  cmd += " if [ -f '%s' ]; then " % archFile
  cmd += "  chmod 644 %s;" % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e 'File:\n%s\n' %s;" % (resultFile, FFOCvV(resultFile, VVx2Y8))
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;" % (failed, FFOCvV(failed, VVUq52))
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFtWHX(self, cmd, VVrZnU=self.VVTsrt)
 def VVXcZM(self, path):
  versionFile = path + "sf8008/imageversion"
  if fileExists(versionFile):
   FFfN74(self, versionFile)
 def VVeVWg(self, path):
  hostName, kernelFile, rootfsFile, versionFile = self.VVaKUT(path)
  if not fileExists(kernelFile) or not fileExists(rootfsFile):
   FFBAp7(self, "Essential files not found !")
   return
  fileUnixTime = os.path.getmtime(rootfsFile)
  backupDate  = datetime.fromtimestamp(fileUnixTime).strftime('%Y%m%d')
  outpuFileName = "octagon-backup-%s-%s" % (hostName, backupDate)
  version = ""
  if fileExists(versionFile):
   c = 0
   for line in FFHvYZ(versionFile):
    if "Version = " in line:
     version = (line.split("=", 1)[1]).strip().replace(" ", "-")
     outpuFileName = "%s-%s-%s" % (version, hostName, backupDate)
     version + "-" + hostName + backupDate
     break
    elif line.count("-") == 3:
     outpuFileName = line
     break
    c += 1
    if c > 7:
     break
  parent  = FFA44u(path, False)
  VV9Xey = ("%s/%s_mmc.zip" % (parent, outpuFileName))
  errCmd  = "Zipping tools not found (zip , p7zip)!"
  errCmd  = " echo -e '\n%s' %s;" % (errCmd, FFOCvV(errCmd, VVUq52))
  installCmd = FFj0t1(VVSMBq , "")
  cmd  = 'FOUND=$(which zip);'
  cmd += 'if [[ -z "$FOUND" ]]; then '
  cmd += '  FOUND=$(which 7za);'
  cmd += 'fi;'
  if installCmd:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Zip not found ...";'
   cmd += '  echo -e "Installing zip ...";'
   cmd += '  %s install zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which zip);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install zip!";'
   cmd += '  echo -e "Installing p7zip ...";'
   cmd += '  %s install p7zip >/dev/null;' % installCmd
   cmd += '  FOUND=$(which 7za);'
   cmd += 'fi;'
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd += '  echo -e "Could not install p7zip!";'
   cmd +=    errCmd
   cmd += 'else'
   cmd += ' echo -e "\nPlease wait ...";'
   cmd += '  if [ -f "%s" ]; then rm "%s"; fi;' % (VV9Xey, VV9Xey)
   cmd += '  cd "%s";'        % parent
   cmd += '  if [[ $(which zip) ]]; then '
   cmd += '    zip -r "%s" ./octagon/*;'   % VV9Xey
   cmd += '  elif [[  $(which 7za) ]]; then '
   cmd += '    7za a "%s" octagon/;'    % VV9Xey
   cmd += '  else'
   cmd += '    echo -e "\nZipping tool not found!";'
   cmd += '  fi;'
   cmd += '  if [ -f "%s" ]; then echo -e "\nOutput File:\n%s"; fi;' % (VV9Xey, VV9Xey)
   cmd += 'fi'
  else:
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=    errCmd
   cmd += 'fi;'
  FFKyuP(self, cmd, VVrZnU=self.VVTsrt)
 def VVaEfR(self, path):
  FFBAp7(self, "Under Construction.")
 def VVx3J7(self, path):
  FFBAp7(self, "Under Construction.")
 @staticmethod
 def VVw2yu(SELF, path):
  try:
   if   path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   SELF.session.open(CC7tge, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVKA14(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FF5gdy(fDir), fName
  return "", "", ""
 @staticmethod
 def VVFx8W(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVWrl8(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVekPE(size, mode=0):
  txt = CCsPG3.VVYmgh(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVYmgh(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
class CCmS9C(MenuList):
 def __init__(self, VVZbp3=False, directory="/", VV75IE=True, VVmMFw=True, VVRw5D=True, VVAu8j=None, VVh8dY=False, VV37FC=False, VV8NEH=False, isTop=False, VVM6Bg=None, VVX2SU=1000, VVwZKv=30, VVkqvP=30, VVzQhD="#00000000"):
  MenuList.__init__(self, list, VVZbp3, eListboxPythonMultiContent)
  self.VV75IE  = VV75IE
  self.VVmMFw    = VVmMFw
  self.VVRw5D  = VVRw5D
  self.VVAu8j  = VVAu8j
  self.VVh8dY   = VVh8dY
  self.VV37FC   = VV37FC or []
  self.VV8NEH   = VV8NEH or []
  self.isTop     = isTop
  self.additional_extensions = VVM6Bg
  self.VVX2SU    = VVX2SU
  self.VVwZKv    = VVwZKv
  self.VVkqvP    = VVkqvP
  self.pngBGColor    = FFmdyN(VVzQhD)
  self.EXTENSIONS    = self.VVyQu3()
  self.VVm0NB   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.sortMode    = 0
  self.l.setFont(0, gFont(VVs8av, self.VVwZKv))
  self.l.setItemHeight(self.VVkqvP)
  self.png_mem   = self.VVZSTI("mem")
  self.png_usb   = self.VVZSTI("usb")
  self.png_fil   = self.VVZSTI("fil")
  self.png_dir   = self.VVZSTI("dir")
  self.png_dirup   = self.VVZSTI("dirup")
  self.png_srv   = self.VVZSTI("srv")
  self.png_slwfil   = self.VVZSTI("slwfil")
  self.png_slbfil   = self.VVZSTI("slbfil")
  self.png_slwdir   = self.VVZSTI("slwdir")
  self.VVNjNZ()
  self.VVbgQJ(directory)
 def VVZSTI(self, category):
  return LoadPixmap("%s%s.png" % (VVqrRB, category), getDesktop(0))
 def VVyQu3(self):
  return {
   "3g2" : "mov" ,
   "3gp" : "mov" ,
   "asf" : "mov" ,
   "avi" : "mov" ,
   "divx" : "mov" ,
   "flv" : "mov" ,
   "ifo" : "mov" ,
   "iso" : "mov" ,
   "m2ts" : "mov" ,
   "m4v" : "mov" ,
   "mkv" : "mov" ,
   "mod" : "mov" ,
   "mov" : "mov" ,
   "mp4" : "mov" ,
   "mpe" : "mov" ,
   "mpeg" : "mov" ,
   "mpg" : "mov" ,
   "mts" : "mov" ,
   "ogm" : "mov" ,
   "ogv" : "mov" ,
   "pva" : "mov" ,
   "rm" : "mov" ,
   "rmvb" : "mov" ,
   "ts" : "mov" ,
   "vob" : "mov" ,
   "webm" : "mov" ,
   "wmv" : "mov" ,
   "wtv" : "mov" ,
   "aac" : "mus" ,
   "ac3" : "mus" ,
   "alac" : "mus" ,
   "amr" : "mus" ,
   "ape" : "mus" ,
   "au" : "mus" ,
   "dts" : "mus" ,
   "flac" : "mus" ,
   "m2a" : "mus" ,
   "m4a" : "mus" ,
   "mid" : "mus" ,
   "mka" : "mus" ,
   "mp2" : "mus" ,
   "mp3" : "mus" ,
   "oga" : "mus" ,
   "ogg" : "mus" ,
   "wav" : "mus" ,
   "wave" : "mus" ,
   "wma" : "mus" ,
   "wv" : "mus" ,
   "bmp" : "pic" ,
   "gif" : "pic" ,
   "jpe" : "pic" ,
   "jpeg" : "pic" ,
   "jpg" : "pic" ,
   "mvi" : "pic" ,
   "png" : "pic" ,
   "cfg" : "txt" ,
   "conf" : "txt" ,
   "htm" : "txt" ,
   "html" : "txt" ,
   "py" : "txt" ,
   "txt" : "txt" ,
   "xml" : "txt" ,
   "bz2" : "tar" ,
   "gz" : "tar" ,
   "tar" : "tar" ,
   "xz" : "tar" ,
   "rar" : "rar" ,
   "zip" : "zip" ,
   "ipk" : "ipk" ,
   "deb" : "deb" ,
   "sh" : "scr" ,
   "m3u" : "m3u" ,
   "m3u8" : "m3u"
  }
 def VV529T(self, name, absolute=None, isDir=False, png=None):
  if absolute and isDir:
   path = absolute
   path = FFaBTr(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FF2tuT(" -> " , VVWvE3) + FF2tuT(os.readlink(path), VVx2Y8)
  tableRow = [ (absolute, isDir) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVkqvP + 10, 0, self.VVX2SU, self.VVkqvP, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVVbjX: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVkqvP-4, self.VVkqvP-4, png, self.pngBGColor, self.pngBGColor, VVVbjX))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVkqvP-4, self.VVkqvP-4, png, self.pngBGColor, self.pngBGColor))
  return tableRow
 def VViHUD(self, name):
  fileExt = name.split('.')[-1].lower()
  if fileExt in self.EXTENSIONS : return self.EXTENSIONS[fileExt]
  else       : return ""
 def VVNjNZ(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse = True)
 def VVQLzo(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVH3W9(self, file):
  if os.path.realpath(file) == file:
   return self.VVQLzo(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVQLzo(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVQLzo(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVqmIY(self):
  l = self.l.getCurrentSelection()
  if not l or l[0][1] == True:
   return None
  else:
   return self.VVm0NB.info(l[0][0]).getEvent(l[0][0])
 def VVrGzl(self):
  return self.list
 def VVkINU(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVbgQJ(self, directory, select = None):
  self.list = []
  if self.current_directory is None:
   if directory and self.VVRw5D:
    self.current_mountpoint = self.VVH3W9(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  directories = []
  files = []
  if directory is None and self.VVRw5D:
   for p in harddiskmanager.getMountedPartitions():
    path = os.path.join(p.mountpoint, "")
    if path not in self.VV8NEH and not self.VVkINU(path, self.VV37FC):
     if path == "/" : png = self.png_mem
     else   : png = self.png_usb
     self.list.append(self.VV529T(name = p.description, absolute = path, isDir = True, png = png))
   files = [ ]
   directories = [ ]
  elif directory is None:
   files = [ ]
   directories = [ ]
  elif self.VVh8dY:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVm0NB = eServiceCenter.getInstance()
   list = VVm0NB.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
   directories.sort()
   files.sort()
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    files.sort()
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VV75IE and not self.isTop:
   if directory == self.current_mountpoint and self.VVRw5D:
    self.list.append(self.VV529T(name = "<List of Storage Devices>", absolute = None, isDir = True, png = self.png_dirup))
   elif (directory != "/") and not (self.VV8NEH and self.VVQLzo(directory) in self.VV8NEH):
    self.list.append(self.VV529T(name = "<Parent Directory>", absolute = '/'.join(directory.split('/')[:-2]) + '/', isDir = True, png = self.png_dirup))
  if self.VV75IE:
   for x in directories:
    if not (self.VV8NEH and self.VVQLzo(x) in self.VV8NEH) and not self.VVkINU(x, self.VV37FC):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VV529T(name = name, absolute = x, isDir = True, png = png))
  if self.VVmMFw:
   for x in files:
    if self.VVh8dY:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(self.current_directory + target):
        png = self.png_slwfil
        name += FF2tuT(" -> " , VVWvE3) + FF2tuT(target, VVx2Y8)
       else:
        png = self.png_slbfil
        name += FF2tuT(" -> " , VVWvE3) + FF2tuT(target, VVUq52)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VViHUD(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVqrRB, category))
    if (self.VVAu8j is None) or iCompile(self.VVAu8j).search(path):
     self.list.append(self.VV529T(name = name, absolute = x , isDir = False, png = png))
  if self.VVRw5D and len(self.list) == 0:
   self.list.append(self.VV529T(name = FF2tuT("No USB connected", VVQDXE), absolute = None, isDir = False, png = self.png_usb))
  self.l.setList(self.list)
  if select is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference):
     p = p.getPath()
    if p == select:
     self.moveToIndex(i)
    i += 1
 def VV1NfB(self):
  return self.current_directory
 def VVmFFr(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVbgQJ(self.getSelection()[0], select = self.current_directory)
 def VVEAAk(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def VVD74R(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   return x
  return None
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVYhFQ)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVYhFQ)
 def refresh(self):
  self.VVbgQJ(self.current_directory, self.VVEAAk())
 def VVYhFQ(self, action, device):
  self.VVNjNZ()
  if self.current_directory is None:
   self.refresh()
class CC3kG9(Screen):
 def __init__(self, session, defFG="", defBG=""):
  self.skin, self.skinParam = FFbmPq(VVRQc2, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.Title   = "Color Picker"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VV1rg6   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVNzfL(defFG, "#00FFFFFF")
  self.defBG   = self.VVNzfL(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FF9Cql(self, self.Title)
  self["keyRed"].show()
  FFCpCt(self["keyGreen"] , "< > Transp.")
  FFCpCt(self["keyYellow"], "Foreground")
  FFCpCt(self["keyBlue"] , "Background")
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVGUiM        ,
   "yellow"   : boundFunction(self.VVhIKL, False)  ,
   "blue"   : boundFunction(self.VVhIKL, True)  ,
   "up"   : self.VVgxd0          ,
   "down"   : self.VVzN12         ,
   "left"   : self.VVTvlD         ,
   "right"   : self.VVrNqN         ,
   "last"   : boundFunction(self.VV03zx, -5) ,
   "next"   : boundFunction(self.VV03zx, 5) ,
   "cancel"  : boundFunction(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FF3luO(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FF3luO(self["keyRed"] , c)
  FF3luO(self["keyGreen"] , c)
  self.VVop0N()
  self.VVCylx()
  FFZkbe(self["myColorTst"], self.defFG)
  FF3luO(self["myColorTst"], self.defBG)
 def VVNzfL(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVCylx(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVw5eB(0, 0)
     return
 def VVGUiM(self):
  self.close(self.defFG, self.defBG)
 def VVgxd0(self): self.VVw5eB(-1, 0)
 def VVzN12(self): self.VVw5eB(1, 0)
 def VVTvlD(self): self.VVw5eB(0, -1)
 def VVrNqN(self): self.VVw5eB(0, 1)
 def VVw5eB(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VV23fR()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVcYhf()
 def VVop0N(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVcYhf(self):
  color = self.VV23fR()
  if self.isBgMode: FF3luO(self["myColorTst"], color)
  else   : FFZkbe(self["myColorTst"], color)
 def VVhIKL(self, isBg):
  self.isBgMode = isBg
  self.VVop0N()
  self.VVCylx()
 def VV03zx(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVw5eB(0, 0)
 def VVxroF(self):
  return hex(self.transp)[2:].zfill(2)
 def VV23fR(self):
  return ("#%s%s" % (self.VVxroF(), self.colors[self.curRow][self.curCol])).upper()
class CCjkQS(Screen):
 VVxDaO  = 0
 VV44Ap = 1
 def __init__(self, session, mode, endCallback):
  self.session  = session
  margin    = 50
  screenSize   = FFTeeG()
  w     = int(screenSize[0] - margin)
  h     = int(screenSize[1] / 2.0)
  self.skin, self.skinParam = FFbmPq(WINDOW_SUBTITLE, w, h, 35, 20, 30, "#ff000000", "#ff000000", 60)
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.currentIndex  = -1
  self.subtitleMode  = mode
  self.defaultY   = 0
  self.endCallback  = endCallback
  FF9Cql(self)
  self["myTitle"].hide()
  self["mySubtFr"] = Label()
  self["mySubtFr"].hide()
  for i in range(3):
   self["mySubt%d" % i] = Label()
  self.onClose.append(self.VVk2b8)
 def VVvKIN(self, path=""):
  if path :
   self.VVx72i()
   FFobhC(self, boundFunction(self.VV1PqY, path), title="Checking file ...", clearMsg=False)
  else:
   self.VV1PqY()
 def VV1PqY(self, path=""):
  if path:
   subtList, err = self.VVlFfh(path)
   if err    : self.VVk2b8(err)
   elif not subtList : self.VVk2b8("Invalid srt file")
   else    :
    self.subtList = subtList
    self.VVXfIL()
  else:
   if self.VVXbLa():
    self.VVXfIL()
   elif self.subtitleMode == CCjkQS.VV44Ap:
    self.VVk2b8("noResume")
   else:
    if self.VVK63K(): self.VVXfIL()
    else         : self.VVk2b8("noAutoSrt")
 def VVXfIL(self):
  try:
   InfoBar.instance.enableSubtitle(None)
  except:
   try:
    InfoBar.instance.setSubtitlesEnable(False)
   except:
    pass
  FFtMdo(self, "Subtitle started", 1000, isGrn=True)
  self.VVx72i()
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVMJvu)
  except:
   self.timerUpdate.callback.append(self.VVMJvu)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVe9qq)
  except:
   self.timerEndText.callback.append(self.VVe9qq)
  self.VVNfMC(True)
 def VVk2b8(self, res=""):
  self.timerUpdate.stop()
  self.timerEndText.stop()
  self.VVNfMC(False)
  self.endCallback(res)
 def VVNfMC(self, isAdd):
  lst = [CFG.subtDelay, CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextSize, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtShadowSize, CFG.subtVerticalPos]
  notifier = self.VVx72i
  for item in lst:
   if isAdd:
    item.addNotifier(notifier, initial_call=False)
   else:
    try:
     item.removeNotifier(notifier)
    except:
     try:
      notifier in item.notifiers and item.notifiers.remove(notifier)
      notifier in item.notifiers_final and item.notifiers_final.remove(notifier)
     except Exception as e:
      pass
 def VVXbLa(self):
  path = self.VVh57t()
  if path:
   if fileExists(path):
    lines = FFHvYZ(path)
    srt = delay = enc = ""
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : srtPath = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay   = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc   = line.split("=")[1].strip()
    if srtPath and fileExists(srtPath):
     subtList, err = self.VVlFfh(srtPath, enc)
     if subtList:
      self.lastSubtEnc = enc
      self.subtList = subtList
      try:
       CFG.subtDelay.setValue("%.1f" % float(delay))
      except:
       pass
      return True
  return False
 def VVK63K(self):
  bestSrt, bestRatio = CCjkQS.VVUZ42(self)
  if bestSrt and bestRatio > 40:
   subtList, err = self.VVlFfh(bestSrt)
   if subtList:
    self.subtList = subtList
    return True
  return False
 def VVeIFv(self):
  VVJ4VL = []
  if self.lastSubtFile:
   VVJ4VL.append(("Settings"      , "set"  ))
   VVJ4VL.append(("Change Encoding"    , "enc"  ))
   VVJ4VL.append(("Disable Current Subtitle"  , "disab" ))
   VVJ4VL.append(VV1dpw)
  VVJ4VL.append(("Find all srt file"    , "findSrt" ))
  lst = CCjkQS.VVNnz3(self)
  if lst:
   VVJ4VL.append(VV1dpw)
   for item in lst:
    fName = os.path.basename(item)
    if self.lastSubtFile == item:
     fName = FF2tuT(fName, VVx2Y8)
    VVJ4VL.append((fName, item))
  win = FFdrYz(self, self.VVwrlr, VVJ4VL=VVJ4VL, width=1200, title="Subtitle Options")
  win.instance.move(ePoint(40, 40))
 def VVwrlr(self, item=None):
  if item:
   if item == "set":
    self["mySubtFr"].show()
    for i in range(3):
     FF3luO(self["mySubt%d" % i], "#55000000")
    self.session.openWithCallback(self.VV8YEk, CCgs7O)
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile):
     FFobhC(self, boundFunction(CCaMcm.VVhF4K, self, self.lastSubtFile, self.VVGVuc, defEnc=self.lastSubtEnc, pos=1), title="Loading Codecs ...", clearMsg=False)
    else:
     FFtMdo(self, "SRT File error", 1000)
   elif item == "disab":
    path = self.VVh57t()
    os.system(FFps7R("rm -f '%s'" % path))
    self.VVk2b8("noErr")
   elif item == "findSrt":
    CCjkQS.VVuQgB(self, self.VVAgp8, defSrt=self.lastSubtFile, pos=1)
   else:
    self.VVAgp8(item)
 def VV8YEk(self, res):
  self["mySubtFr"].hide()
  for i in range(3):
   FF3luO(self["mySubt%d" % i], "#FF000000")
  if res:
   self.VVVMHh()
   self.VVx72i()
 def VVx72i(self, configElement=None):
  fnt = CFG.subtTextFont.getValue()
  if not fnt in FFCu92():
   fnt = VVs8av
  lineH = 0
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFZkbe(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    inst.setHAlign(int(CFG.subtTextAlign.getValue()))
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    inst.setNoWrap(True)
    lineH = FFVZvQ(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    inst.move(ePoint(int(inst.position().x()), int(lineH * i + 1)))
  except:
   pass
  try:
   height = lineH * 3 + 2
   if not self.defaultY:
    self.defaultY = int(getDesktop(0).size().height() - height - self.skinParam["marginTop"])
   if lineH:
    self.instance.resize(eSize(*(int(self.instance.size().width()), height)))
   y = int(self.defaultY + CFG.subtVerticalPos.getValue())
   y = min(y, getDesktop(0).size().height() - height - 5)
   self.instance.move(ePoint(int(self.instance.position().x()), int(y)))
   inst = self["myInfoFrame"].instance
   inst.move(ePoint(int(inst.position().x()), 2))
   inst = self["myInfoBody"].instance
   inst.move(ePoint(int(inst.position().x()), 4))
  except:
   pass
 def VVAgp8(self, path, enc=None):
  self.timerUpdate.stop()
  subtList, err = self.VVlFfh(path, enc)
  if err    : FFtMdo(self, err, 2000)
  elif not subtList : FFtMdo(self, "Invalid SRT file", 2000)
  else    :
   self.subtList  = subtList
   self.lastSubtInfo = ""
   self.lastSubtEnc = ""
   self.currentIndex = 0
   CFG.subtDelay.setValue("0.0")
   for i in range(3):
    FFZkbe(self["mySubt%d" % i], "#ffffff")
    self["mySubt%d" % i].setText("")
   FFtMdo(self, "Subtitle started", 1000, isGrn=True)
  self.timerUpdate.start(500, False)
 def VVGVuc(self, item=None):
  if item:
   self.VVAgp8(self.lastSubtFile, item)
 @staticmethod
 def VVNnz3(SELF):
  fPath, fDir, fName = CCsPG3.VVKA14(SELF)
  if pathExists(fDir):
   files = iGlob("%s*.srt" % fDir)
   if files:
    return files
  return []
 @staticmethod
 def VVUZ42(SELF):
  bestSrt = ""
  bestRatio = 0
  fPath, fDir, fName = CCsPG3.VVKA14(SELF)
  if fName:
   movName = os.path.splitext(fName)[0].lower()
   files = CCjkQS.VVNnz3(SELF)
   for path in files:
    fName = os.path.basename(path)
    fName = os.path.splitext(fName)[0]
    ratio = CCYaR2.VV3co7(movName.lower(), fName.lower())
    if ratio > bestRatio:
     bestRatio = ratio
     bestSrt = path
  return bestSrt, bestRatio
 def VVyMKK(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVlFfh(self, path, enc=None):
  if not fileExists(path):
   return [], "File not found"
  if (FFuS3Z(path) > 1024 * 700):
   return [], "File too big"
  capNum = frmSec = toSec = bold = italic = under = 0
  color  = ""
  subtLines = []
  subtList = []
  capFound = False
  lines  = FFHvYZ(path, encLst=enc if enc else None)
  for line in lines:
   line = line.strip()
   if line:
    if not capFound and line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVyMKK(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      subtLines.append((line.strip(), color, bold, italic, under))
   else:
    if (toSec - frmSec) > 0:
     subtList.append((capNum, frmSec, toSec, subtLines))
    capFound = False
    subtLines = []
    color = ""
    capNum = frmSec = toSec = bold = italic = under = 0
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVVMHh()
  return subtList, ""
 def VVVMHh(self):
  path = self.VVh57t()
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelay.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVh57t(self):
  fPath, fDir, fName = CCsPG3.VVKA14(self)
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFCcWd(self)
   if iptvRef: fPath = "/tmp/" + chName
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCipRP.VVX9la(self)
   if evName and evTime and evDur: fPath = "/tmp/" + evName
  if fPath: return fPath + ".ajp"
  else : return ""
 def VVMJvu(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CC7tge.VVuQi4(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCipRP.VVX9la(self)
   if evTime and evDur:
    posVal = iTime() - evTime
  self.VVOb4F(posVal)
  if self.currentIndex == -2:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[self.currentIndex]
   if not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    for i in range(3):
     FFZkbe(self["mySubt%d" % i], "#ffffff")
     self["mySubt%d" % i].setText("")
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
     txtDur = int(toSec * 1000 - frmSec * 1000)
     if txtDur > 0:
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        line = line.replace(u"\u202A", "")
        line = line.replace(u"\u202B", "")
        line = line.replace(u"\u202C", "")
        line = str(line)
        if newColor:
         FFZkbe(self["mySubt%d" % ndx], newColor)
        self["mySubt%d" % ndx].setText(line)
      self.timerEndText.start(txtDur, True)
 def VVOb4F(self, posVal):
  if posVal > 0:
   delay = float(CFG.subtDelay.getValue())
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     self.currentIndex = ndx
     return
  self.currentIndex = -2
 def VVe9qq(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
 @staticmethod
 def VVuQgB(SELF, cbFnc, defSrt="", pos=0):
  FFobhC(SELF, boundFunction(CCjkQS.VVUOkC, SELF, cbFnc, defSrt, pos), title="Searching for srt files", clearMsg=False)
 @staticmethod
 def VVUOkC(SELF, cbFnc, defSrt="", pos=0):
  FFtMdo(SELF)
  lines = FF5Oes('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFebM5(1)))
  if lines:
   lines.sort()
   VVJ4VL = []
   for item in lines:
    VVJ4VL.append(((VVx2Y8 if defSrt == item else "") + item, item))
   VVfRF6 = ("Show Full Path", CCjkQS.VV34cH)
   win = FFdrYz(SELF, boundFunction(CCjkQS.VVJJXq, cbFnc), title="Subtitle Files", VVJ4VL=VVJ4VL, width=1200, height=500 if pos == 1 else 900, VVfRF6=VVfRF6)
   if pos == 1:
    win.instance.move(ePoint(40, 40))
  else:
   FFtMdo(SELF, "No srt files found !", 2000)
 @staticmethod
 def VV34cH(VVH9sbObj, path):
  FFzRpw(VVH9sbObj, path, title="Full Path")
 @staticmethod
 def VVJJXq(cbFnc, item):
  if item:
   cbFnc(item)
 @staticmethod
 def VVt6MZ():
  c = s = m = h = 0
  with open(VVmnJB + "AJPanel_test.srt", "w") as f:
   for i in range(1, 5401):
    s += 2
    if s >= 60:
     s = 0
     m += 1
     if m >= 60:
      m = 0
      h += 1
    if i < 6:
     txt  = '<font color="#ffff00">Created by AJPanel</font>\n'
     txt += '<font color="#00ffff">Testing Subtitle Files</font>\n'
     txt += '<font color="#00ff00">Line - %d</font>\n\n' % i
    else:
     txt = '<font color="#ffffbb">Subtitle Line - %d</font>\n\n' % i
    f.write("%d\n" % i)
    f.write("%02d:%02d:%02d,001 --> %02d:%02d:%02d,001\n" % (h, m, s, h, m, s+1))
    f.write(txt)
class CCgs7O(Screen, ConfigListScreen):
 def __init__(self, session):
  self.skin, self.skinParam = FFbmPq(VVeULt, 600, 600, 40, 30, 10, "#11331010", "#11442020", 30, barHeight=40)
  self.session  = session
  self.Title   = "Subtitle Settings"
  FF9Cql(self, title=self.Title)
  FFCpCt(self["keyRed"] , "Exit")
  FFCpCt(self["keyGreen"] , "Save")
  FFCpCt(self["keyYellow"], "Reset")
  self.confList = []
  self.confList.append(getConfigListEntry("Delay (current movie)" , CFG.subtDelay   ))
  self.confList.append(getConfigListEntry(VVlhhY *2     ,       ))
  self.confList.append(getConfigListEntry("Text Color"   , CFG.subtTextFg  ))
  self.confList.append(getConfigListEntry("Text Font"    , CFG.subtTextFont  ))
  self.confList.append(getConfigListEntry("Text Size"    , CFG.subtTextSize  ))
  self.confList.append(getConfigListEntry("Alignment"    , CFG.subtTextAlign  ))
  self.confList.append(getConfigListEntry("Shadow Color"   , CFG.subtShadowColor ))
  self.confList.append(getConfigListEntry("Shadow Size"   , CFG.subtShadowSize ))
  self.confList.append(getConfigListEntry(VVlhhY *2     ,       ))
  self.confList.append(getConfigListEntry("Vertical Pos"   , CFG.subtVerticalPos ))
  ConfigListScreen.__init__(self, self.confList, session)
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVFckC  ,
   "green"   : self.VVzDwi   ,
   "yellow"  : boundFunction(FFJWhD, self, self.VV7vGm, "Reset Subtitle Settings to default ?", title="Subtitle Settings"),
   "cancel"  : self.VVFckC
  }, -1)
  self.onShown.append(self.VVJGeB)
 def VVJGeB(self):
  self.onShown.remove(self.VVJGeB)
  FFYI0q(self["config"])
  FFImVi(self, self["config"])
  FF4l2q(self)
  self.instance.move(ePoint(40, 40))
 def VVFckC(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFJWhD(self, self.VVzDwi, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVzDwi(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  configfile.save()
  self.close(True)
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close(False)
 def VV7vGm(self):
  CFG.subtDelay.setValue("0.0")
  CFG.subtTextFg.setValue("srt")
  CFG.subtTextFont.setValue(VVs8av)
  CFG.subtTextSize.setValue(50)
  CFG.subtTextAlign.setValue("1")
  CFG.subtShadowColor.setValue("#000080")
  CFG.subtShadowSize.setValue(5)
  CFG.subtVerticalPos.setValue(0)
  self.VVzDwi()
class CCw6AU(ScrollLabel):
 def __init__(self, parentSELF, text="", VVrwoD=True):
  ScrollLabel.__init__(self, text)
  self.VVrwoD=VVrwoD
  self.instance    = None
  self.long_text    = None
  self.scrollbar    = None
  self.VVUv4Z  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.column     = 0
  self.textOutFile   = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.minHeight    = 40
  self.fontFamily    = None
  self.VVwZKv    = None
  self.parentW    = None
  self.parentH    = None
  self.firstTime    = True
  parentSELF["keyRedTop"]  = Label("Save")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["keyRedTop"].hide()
  parentSELF["keyRedTop1"].hide()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close     ,
   "cancel"  : parentSELF.close     ,
   "red"   : self.VVtG5c     ,
   "green"   : self.VVw7iw    ,
   "yellow"  : self.VVXf9m    ,
   "blue"   : self.VVmpZ9    ,
   "up"   : self.pageUp      ,
   "down"   : self.pageDown      ,
   "left"   : self.pageUp      ,
   "right"   : self.pageDown      ,
   "last"   : boundFunction(self.VVcwav, 0) ,
   "next"   : boundFunction(self.VVcwav, 2) ,
   "0"    : boundFunction(self.VVcwav, 1) ,
   "pageUp"  : self.VVW22H      ,
   "chanUp"  : self.VVW22H      ,
   "pageDown"  : self.VVAscL      ,
   "chanDown"  : self.VVAscL
  }, -1)
 def VVmT9l(self, isResizable=True, VV1OEk=False, textOutFile=""):
  self.textOutFile = textOutFile
  if self.textOutFile:
   self.parentSELF["keyRedTop"].show()
   self.parentSELF["keyRedTop1"].show()
  FF4l2q(self.parentSELF, True)
  self.isResizable = isResizable
  if VV1OEk:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVwZKv  = font.pointSize
  try: self.scrollbar.setBorderWidth(1)
  except: pass
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FF3luO(self, color)
 def FF3luOColor(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVUv4Z - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVfo7U()
 def pageUp(self):
  if self.VVUv4Z > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def pageDown(self):
  if self.VVUv4Z > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVW22H(self):
  self.setPos(0)
 def VVAscL(self):
  self.setPos(self.VVUv4Z-self.pageHeight)
 def VVFkEl(self):
  return self.VVUv4Z <= self.pageHeight or self.curPos == self.VVUv4Z - self.pageHeight
 def VVfo7U(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVUv4Z, 3))
   start = int((100 - vis) * self.curPos / (self.VVUv4Z - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def getText(self):
  return self.message
 def setText(self, text, VVFuWe=VVdoHn):
  old_VVFkEl = self.VVFkEl()
  self.message = str(text)
  if self.pageHeight:
   self.long_text.setText(self.message)
   self.VVUv4Z = self.long_text.calculateSize().height()
   if self.VVrwoD and self.VVUv4Z > self.pageHeight:
    self.scrollbar.show()
    self.VVfo7U()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
   else:
    self.scrollbar.hide()
    w = 0
   pageWidth  = self.instance.size().width()
   self.long_text.resize(eSize(pageWidth - w, self.VVUv4Z))
   if   VVFuWe == VVtYyU: self.setPos(0)
   elif VVFuWe == VVHjEe : self.VVAscL()
   elif old_VVFkEl    : self.VVAscL()
   if self.firstTime and len(self.message) > 0:
    self.firstTime = False
    self.setText(self.message, VVFuWe=VVFuWe)
 def appendText(self, text, VVFuWe=VVHjEe):
  self.setText(self.message + str(text), VVFuWe=VVFuWe)
 def VVXf9m(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VV72Rl(size)
 def VVmpZ9(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VV72Rl(size)
 def VVw7iw(self):
  self.VV72Rl(self.VVwZKv)
 def VV72Rl(self, VVwZKv):
  self.long_text.setFont(gFont(self.fontFamily, VVwZKv))
  self.setText(self.message, VVFuWe=VVdoHn)
  self.VV1ZXK(calledFromFontSizer=True)
 def VVcwav(self, align):
  self.long_text.setHAlign(align)
 def VVtG5c(self):
  if self.parentSELF["keyRedTop"].getVisible():
   title = "%s Log File" % self.textOutFile.capitalize()
   expPath = CFG.exportedTablesPath.getValue()
   try:
    outF = "%sAJPanel_log_%s_%s.txt" % (FF5gdy(expPath), self.textOutFile, FFC5od())
    with open(outF, "w") as f:
     f.write(FFWYHc(self.message))
    FFSzHX(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
   except:
    FFBAp7(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VV1ZXK(self, calledFromFontSizer=False, minHeight=0):
  if minHeight > 0:
   self.minHeight = minHeight
  if not calledFromFontSizer and self.VVUv4Z > 0 and self.pageHeight > 0:
   if self.VVUv4Z < self.pageHeight * 0.8:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.setText(self.message.rstrip() + "\n")
  if self.isResizable:
   pageH = self.pageHeight
   textH = self.VVUv4Z
   diff = pageH - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   self.resize(eSize(*(self.instance.size().width(), min(textH, pageH) + 6)))
   newH = min(self.parentH, self.getPosition()[1] + textH + self.parentSELF.skinParam["marginTop"])
   if self.minHeight > 0:
    newH = max(newH, self.minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, newH)))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
